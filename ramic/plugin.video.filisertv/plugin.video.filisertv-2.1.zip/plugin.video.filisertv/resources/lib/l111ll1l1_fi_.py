# coding: UTF-8
import sys
l1111_fi_ = sys.version_info [0] == 2
l1lll1_fi_ = 2048
l1l11_fi_ = 7
def l11l_fi_ (ll_fi_):
	global l1l11l_fi_
	l1l1l1_fi_ = ord (ll_fi_ [-1])
	l11ll_fi_ = ll_fi_ [:-1]
	l1l_fi_ = l1l1l1_fi_ % len (l11ll_fi_)
	l11_fi_ = l11ll_fi_ [:l1l_fi_] + l11ll_fi_ [l1l_fi_:]
	if l1111_fi_:
		l1llll_fi_ = unicode () .join ([unichr (ord (char) - l1lll1_fi_ - (l1l1l_fi_ + l1l1l1_fi_) % l1l11_fi_) for l1l1l_fi_, char in enumerate (l11_fi_)])
	else:
		l1llll_fi_ = str () .join ([chr (ord (char) - l1lll1_fi_ - (l1l1l_fi_ + l1l1l1_fi_) % l1l11_fi_) for l1l1l_fi_, char in enumerate (l11_fi_)])
	return eval (l1llll_fi_)
import urlparse,cookielib,urllib2,urllib
import time,re,os
url=l11l_fi_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡪ࡮࡬ࡷࡪࡸ࠮ࡤࡱ࠲ࠫ৏")
l11l11l11_fi_= cookielib.LWPCookieJar()
l111l11ll_fi_=l11l_fi_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠰࠯࠲࠱࠶࠻࠼࠱࠯࠳࠳࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬ৐")
l111llll1_fi_=l111l11ll_fi_
def l111ll11l_fi_(url,l11l11l11_fi_=l11l11l11_fi_,l111llll1_fi_=l111l11ll_fi_):
    l11l11111_fi_=l11l_fi_ (u"ࠧࠨ৑")
    try:
        class l111ll1ll_fi_(urllib2.HTTPErrorProcessor):
            def http_response(self, request, response):
                return response
        def l111l1ll1_fi_(s):
            try:
                offset=1 if s[0]==l11l_fi_ (u"ࠨ࠭ࠪ৒") else 0
                val = int(eval(s.replace(l11l_fi_ (u"ࠩࠤ࠯ࡠࡣࠧ৓"),l11l_fi_ (u"ࠪ࠵ࠬ৔")).replace(l11l_fi_ (u"࡛ࠫࠦࠧ࡞ࠩ৕"),l11l_fi_ (u"ࠬ࠷ࠧ৖")).replace(l11l_fi_ (u"࡛࠭࡞ࠩৗ"),l11l_fi_ (u"ࠧ࠱ࠩ৘")).replace(l11l_fi_ (u"ࠨࠪࠪ৙"),l11l_fi_ (u"ࠩࡶࡸࡷ࠮ࠧ৚"))[offset:]))
                return val
            except:
                pass
        if l11l11l11_fi_==None:
            l11l11l11_fi_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(l111ll1ll_fi_, urllib2.HTTPCookieProcessor(l11l11l11_fi_))
        opener.addheaders = [(l11l_fi_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ৛"), l111llll1_fi_)]
        try:
            response = opener.open(url)
            result=l11l11111_fi_ = response.read()
            response.close()
        except urllib2.HTTPError as e:
            result=l11l11111_fi_ = e.read()
        l11l111ll_fi_ = re.compile(l11l_fi_ (u"ࠫࡳࡧ࡭ࡦ࠿ࠥ࡮ࡸࡩࡨ࡭ࡡࡹࡧࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯࠭ࡂ࠭ࠧ࠵࠾ࠨড়")).findall(result)[0]
        init = re.compile(l11l_fi_ (u"ࠬࡹࡥࡵࡖ࡬ࡱࡪࡵࡵࡵ࡞ࠫࡪࡺࡴࡣࡵ࡫ࡲࡲࡡ࠮࡜ࠪࡽ࡟ࡷ࠯࠴ࠪࡀ࠰࠭࠾࠭࠴ࠪࡀࠫࢀ࠿ࠬঢ়")).findall(result)[0]
        l11l111l1_fi_ = re.compile(l11l_fi_ (u"ࡸࠢࡤࡪࡤࡰࡱ࡫࡮ࡨࡧ࠰ࡪࡴࡸ࡭࡝ࠩ࡟࠭ࡀࡢࡳࠫࠪ࠱࠮࠮ࡧ࠮ࡷࠤ৞")).findall(result)[0]
        l111lllll_fi_ = l111l1ll1_fi_(init)
        lines = l11l111l1_fi_.split(l11l_fi_ (u"ࠧ࠼ࠩয়"))
        if l11l111ll_fi_:
            for line in lines:
                if len(line)>0 and l11l_fi_ (u"ࠨ࠿ࠪৠ") in line:
                    l111l1l1l_fi_=line.split(l11l_fi_ (u"ࠩࡀࠫৡ"))
                    l111l1l11_fi_ = l111l1ll1_fi_(l111l1l1l_fi_[1])
                    l111lllll_fi_ = int(eval(str(l111lllll_fi_)+l111l1l1l_fi_[0][-1]+str(l111l1l11_fi_)))
            l111ll111_fi_ = l111lllll_fi_ + len(urlparse.urlparse(url).netloc)
            u=url
            query = l11l_fi_ (u"ࠪࠩࡸ࠵ࡣࡥࡰ࠰ࡧ࡬࡯࠯࡭࠱ࡦ࡬ࡰࡥࡪࡴࡥ࡫ࡰࡄࡰࡳࡤࡪ࡯ࡣࡻࡩ࠽ࠦࡵࠩ࡮ࡸࡩࡨ࡭ࡡࡤࡲࡸࡽࡥࡳ࠿ࠨࡷࠬৢ") % (u, l11l111ll_fi_, l111ll111_fi_)
            if l11l_fi_ (u"ࠫࡹࡿࡰࡦ࠿ࠥ࡬࡮ࡪࡤࡦࡰࠥࠤࡳࡧ࡭ࡦ࠿ࠥࡴࡦࡹࡳࠣࠩৣ") in result:
                l111lll1l_fi_=re.compile(l11l_fi_ (u"ࠬࡴࡡ࡮ࡧࡀࠦࡵࡧࡳࡴࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ৤")).findall(result)[0]
                query = l11l_fi_ (u"࠭ࠥࡴ࠱ࡦࡨࡳ࠳ࡣࡨ࡫࠲ࡰ࠴ࡩࡨ࡬ࡡ࡭ࡷࡨ࡮࡬ࡀࡲࡤࡷࡸࡃࠥࡴࠨ࡭ࡷࡨ࡮࡬ࡠࡸࡦࡁࠪࡹࠦ࡫ࡵࡦ࡬ࡱࡥࡡ࡯ࡵࡺࡩࡷࡃࠥࡴࠩ৥") % (u,urllib.quote_plus(l111lll1l_fi_), l11l111ll_fi_, l111ll111_fi_)
                time.sleep(5)
            l111l1lll_fi_ =l11l_fi_ (u"ࠧࠨ০").join([l11l_fi_ (u"ࠨࠧࡶࡁࠪࡹ࠻ࠨ১")%(c.name, c.value) for c in l11l11l11_fi_])
            opener = urllib2.build_opener(l111ll1ll_fi_,urllib2.HTTPCookieProcessor(l11l11l11_fi_))
            opener.addheaders = [(l11l_fi_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭২"), l111llll1_fi_)]
            opener.addheaders.append((l11l_fi_ (u"ࠪࡧࡴࡵ࡫ࡪࡧࠪ৩"),l111l1lll_fi_))
            opener.addheaders.append((l11l_fi_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ৪"),l11l_fi_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡦࡪ࡮࡬ࡷࡪࡸ࠮ࡤࡱ࠲ࠫ৫")))
            try:
                response = opener.open(query)
                response.close()
            except urllib2.HTTPError as e:
                response = e.read()
        return l11l11l11_fi_
    except:
        return None
def l11l1111l_fi_(l1ll11ll_fi_):
    l111lll11_fi_=l11l_fi_ (u"࠭ࠧ৬")
    if os.path.isfile(l1ll11ll_fi_):
        l11l11l11_fi_ = cookielib.LWPCookieJar()
        l11l11l11_fi_.load(l1ll11ll_fi_)
        for c in l11l11l11_fi_:
            l111lll11_fi_+=l11l_fi_ (u"ࠧࠦࡵࡀࠩࡸࡁࠧ৭")%(c.name, c.value)
    return l111lll11_fi_
