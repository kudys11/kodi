# -*- coding: utf-8 -*-
import sys
l1111_fi_ = sys.version_info [0] == 2
l1lll1_fi_ = 2048
l1l11_fi_ = 7
def l11l_fi_ (ll_fi_):
	global l1l11l_fi_
	l1l1l1_fi_ = ord (ll_fi_ [-1])
	l11ll_fi_ = ll_fi_ [:-1]
	l1l_fi_ = l1l1l1_fi_ % len (l11ll_fi_)
	l11_fi_ = l11ll_fi_ [:l1l_fi_] + l11ll_fi_ [l1l_fi_:]
	if l1111_fi_:
		l1llll_fi_ = unicode () .join ([unichr (ord (char) - l1lll1_fi_ - (l1l1l_fi_ + l1l1l1_fi_) % l1l11_fi_) for l1l1l_fi_, char in enumerate (l11_fi_)])
	else:
		l1llll_fi_ = str () .join ([chr (ord (char) - l1lll1_fi_ - (l1l1l_fi_ + l1l1l1_fi_) % l1l11_fi_) for l1l1l_fi_, char in enumerate (l11_fi_)])
	return eval (l1llll_fi_)
l11l_fi_ (u"ࠨࠢࠣࠏࠍࡇࡷ࡫ࡡࡵࡧࡧࠤࡴࡴࠠࡕࡪࡸࠤࡋ࡫ࡢࠡ࠳࠴ࠤ࠶࠾࠺࠵࠹࠽࠸࠸ࠦ࠲࠱࠳࠹ࠑࠏࠓࠊࡁࡣࡸࡸ࡭ࡵࡲ࠻ࠢࡵࡥࡲ࡯ࡣࠎࠌࠥࠦࠧভ")
import urllib2
import re
import l11ll111l_fi_ as l11ll111l_fi_
l11l1llll_fi_=l11l_fi_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡨࡪࡡ࠯ࡲ࡯ࠫম")
l11ll1l11_fi_ = 5
def l11ll11ll_fi_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l11l_fi_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬয"), l11l_fi_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠶࠻࠲࠵࠴࠲࠶࠸࠷࠲࠾࠽ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧর"))
    if cookies:
        req.add_header(l11l_fi_ (u"ࠥࡇࡴࡵ࡫ࡪࡧࠥ঱"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11ll1l11_fi_)
        l1ll1ll1_fi_ =  response.read()
        response.close()
    except:
        l1ll1ll1_fi_=l11l_fi_ (u"ࠫࠬল")
    return l1ll1ll1_fi_
def _11ll1l1l_fi_(content):
    src =l11l_fi_ (u"ࠬ࠭঳")
    l11l1l1l1_fi_ = re.compile(l11l_fi_ (u"ࠨࡥࡷࡣ࡯ࠬ࠳࠰࠿ࠪ࡞ࡾࡠࢂࡢࠩ࡝ࠫࠥ঴"),re.DOTALL).findall(content)
    for l11l1l11l_fi_ in l11l1l1l1_fi_:
        l11l1l11l_fi_=re.sub(l11l_fi_ (u"ࠧࠡࠢࠪ঵"),l11l_fi_ (u"ࠨࠢࠪশ"),l11l1l11l_fi_)
        l11l1l11l_fi_=re.sub(l11l_fi_ (u"ࠩ࡟ࡲࠬষ"),l11l_fi_ (u"ࠪࠫস"),l11l1l11l_fi_)
        try:
            l11l11ll1_fi_ = l11ll111l_fi_.unpack(l11l1l11l_fi_)
        except:
            l11l11ll1_fi_=l11l_fi_ (u"ࠫࠬহ")
        if l11l11ll1_fi_:
            l11l11ll1_fi_=re.sub(l11l_fi_ (u"ࡷ࠭࡜࡝ࠩ঺"),l11l_fi_ (u"ࡸࠧࠨ঻"),l11l11ll1_fi_)
            l11l1l1ll_fi_ = re.compile(l11l_fi_ (u"ࠧ࡜ࠤ࡟ࠫࡢ࠰ࡦࡪ࡮ࡨ࡟ࠧࡢࠧ࡞ࠬ࡟ࡷ࠯ࡀ࡜ࡴࠬ࡞ࠦࡡ࠭࡝ࠩ࠰࠮ࡃ࠮ࡡࠢ࡝ࠩࡠ࠰়ࠬ"),  re.DOTALL).search(content)
            l11l1lll1_fi_ = re.compile(l11l_fi_ (u"ࠨ࡝ࠥࡠࠬࡣࡦࡪ࡮ࡨ࡟ࠧࡢࠧ࡞࠼࡞ࠦࡡ࠭࡝ࠩ࠰࠭ࡃࡡ࠴࡭ࡱ࠶ࠬ࡟ࠧࡢࠧ࡞ࠩঽ"),  re.DOTALL).search(content)
            l11l1ll1l_fi_ = re.compile(l11l_fi_ (u"ࠩ࡞ࠦࡡ࠭࡝ࠫࠪ࠱࠮ࡄࡢ࠮࡮ࡲ࠷࠭ࡠࠨ࡜ࠨ࡟࠭ࠫা"),  re.DOTALL).search(content)
            if l11l1l1ll_fi_:   src = l11l1l1ll_fi_.group(1)
            elif l11l1lll1_fi_: src = l11l1lll1_fi_.group(1)
            elif l11l1ll1l_fi_: src = l11l1ll1l_fi_.group(1)
            if src:
                break
    return src
def l11ll11l1_fi_(content):
    l11l_fi_ (u"ࠥࠦࠧࠓࠊࠡࠢࠣࠤࡘࡩࡡ࡯ࡵࠣࡪࡴࡸࠠࡷ࡫ࡧࡩࡴࠦ࡬ࡪࡰ࡮ࠤ࡮ࡴࡣ࡭ࡷࡧࡩࡩࠦࡥ࡯ࡥࡲࡨࡪࡪࠠࡰࡰࡨࠑࠏࠦࠠࠡࠢࠥࠦࠧি")
    l11l1l111_fi_=l11l_fi_ (u"ࠫࠬী")
    l11l1l1ll_fi_ = re.compile(l11l_fi_ (u"ࠬࡡࠢ࡝ࠩࡠ࠮࡫࡯࡬ࡦ࡝ࠥࡠࠬࡣࠪ࡝ࡵ࠭࠾ࡡࡹࠪ࡜ࠤ࡟ࠫࡢ࠮࠮ࠬࡁࠬ࡟ࠧࡢࠧ࡞࠮ࠪু"),  re.DOTALL).search(content)
    l11l1lll1_fi_ = re.compile(l11l_fi_ (u"࡛࠭ࠣ࡞ࠪࡡ࡫࡯࡬ࡦ࡝ࠥࡠࠬࡣ࠺࡜ࠤ࡟ࠫࡢ࠮࠮ࠫࡁ࡟࠲ࡲࡶ࠴ࠪ࡝ࠥࡠࠬࡣࠧূ"),  re.DOTALL).search(content)
    l11l1ll1l_fi_ = re.compile(l11l_fi_ (u"ࠧ࡜ࠤ࡟ࠫࡢ࠰ࠨ࠯ࠬࡂࡠ࠳ࡳࡰ࠵ࠫ࡞ࠦࡡ࠭࡝ࠫࠩৃ"),  re.DOTALL).search(content)
    if l11l1l1ll_fi_:
        print l11l_fi_ (u"ࠨࡨࡲࡹࡳࡪࠠࡓࡇࠣ࡟࡫࡯࡬ࡦ࠼ࡠࠫৄ")
        l11l1l111_fi_ = l11l1l1ll_fi_.group(1)
    elif l11l1lll1_fi_:
        print l11l_fi_ (u"ࠩࡩࡳࡺࡴࡤࠡࡔࡈࠤࡠࡻࡲ࡭࠼ࡠࠫ৅")
        l11l1l111_fi_ = l11l1lll1_fi_.group(1)
    elif l11l1ll1l_fi_:
        print l11l_fi_ (u"ࠪࡪࡴࡻ࡮ࡥࠢࡕࡉࠥࡡࡵࡳ࡮࠽ࡡࠬ৆")
        l11l1l111_fi_ = l11l1ll1l_fi_.group(1)
    else:
        print l11l_fi_ (u"ࠫࡪࡴࡣࡰࡦࡨࡨࠥࡀࠠࡶࡰࡳࡥࡨࡱࡥࡳࠩে")
        l11l1l111_fi_ = _11ll1l1l_fi_(content)
    return l11l1l111_fi_
def l1ll1111_fi_(url):
    l11l_fi_ (u"ࠧࠨࠢࠎࠌࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࡹࠠࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠱ࠥࡻ࡬ࡳࠢ࡫ࡸࡹࡶ࠺࠰࠱࠱࠲࠳࠴ࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠰ࠤࡴࡸࠠ࡭࡫ࡶࡸࠥࡵࡦࠡ࡝ࠫࠫ࠼࠸࠰ࡱࠩ࠯ࠤࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡦࡨࡦ࠴ࡰ࡭࠱ࡹ࡭ࡩ࡫࡯࠰࠳࠼࠸࠻࠿࠹࠲ࡨࡂࡻࡪࡸࡳ࡫ࡣࡀ࠻࠷࠶ࡰࠨࠫ࠯࠲࠳࠴࡝ࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠒࠐࠠࠡࠢࠣࠦࠧࠨৈ")
    l11l1ll11_fi_=l11l_fi_ (u"࠭ࡼࡄࡱࡲ࡯࡮࡫࠽ࡑࡊࡓࡗࡊ࡙ࡓࡊࡆࡀ࠵ࠫࡘࡥࡧࡧࡵࡩࡷࡃࡨࡵࡶࡳ࠾࠴࠵ࡳࡵࡣࡷ࡭ࡨ࠴ࡣࡥࡣ࠱ࡴࡱ࠵ࡦ࡭ࡱࡺࡴࡱࡧࡹࡦࡴ࠲ࡪࡱࡧࡳࡩ࠱ࡩࡰࡴࡽࡰ࡭ࡣࡼࡩࡷ࠴ࡣࡰ࡯ࡰࡩࡷࡩࡩࡢ࡮࠰࠷࠳࠸࠮࠲࠺࠱ࡷࡼ࡬ࠧ৉")
    content = l11ll11ll_fi_(url)
    src=[]
    if not l11l_fi_ (u"ࠧࡀࡹࡨࡶࡸࡰࡡࠨ৊") in url:
         l11l11lll_fi_ = re.compile(l11l_fi_ (u"ࠨ࠾ࡤࠤࡩࡧࡴࡢ࠯ࡴࡹࡦࡲࡩࡵࡻࡀࠦ࠭࠴ࠪࡀࠫࠥࠤ࠭ࡅࡐ࠽ࡊࡁ࠲࠯ࡅࠩ࠿ࠪࡂࡔࡁࡗ࠾࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩো"), re.DOTALL).findall(content)
         for quality in l11l11lll_fi_:
             l1ll1ll1_fi_ = re.search(l11l_fi_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨৌ"),quality[1])
             l11l11l1l_fi_ = quality[2]
             src.insert(0,(l11l11l1l_fi_,l11l1llll_fi_+l1ll1ll1_fi_.group(1)))
    if not src:
        src = l11ll11l1_fi_(content)
        if src:
            src+=l11l1ll11_fi_
    return src
def l11ll1111_fi_(url,quality=0):
    l11l_fi_ (u"ࠥࠦࠧࠓࠊࠡࠢࠣࠤࡷ࡫ࡴࡶࡴࡱࡷࠥࡻࡲ࡭ࠢࡷࡳࠥࡼࡩࡥࡧࡲࠑࠏ্ࠦࠠࠡࠢࠥࠦࠧ")
    src = l1ll1111_fi_(url)
    if type(src)==list:
        selected=src[quality]
        print l11l_fi_ (u"ࠫࡖࡻࡡ࡭࡫ࡷࡽࠥࡀࠧৎ"),selected[0]
        src = l1ll1111_fi_(selected[1])
    return src
