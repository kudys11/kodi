# -*- coding: utf-8 -*-
import sys
l1111_fi_ = sys.version_info [0] == 2
l1lll1_fi_ = 2048
l1l11_fi_ = 7
def l11l_fi_ (ll_fi_):
	global l1l11l_fi_
	l1l1l1_fi_ = ord (ll_fi_ [-1])
	l11ll_fi_ = ll_fi_ [:-1]
	l1l_fi_ = l1l1l1_fi_ % len (l11ll_fi_)
	l11_fi_ = l11ll_fi_ [:l1l_fi_] + l11ll_fi_ [l1l_fi_:]
	if l1111_fi_:
		l1llll_fi_ = unicode () .join ([unichr (ord (char) - l1lll1_fi_ - (l1l1l_fi_ + l1l1l1_fi_) % l1l11_fi_) for l1l1l_fi_, char in enumerate (l11_fi_)])
	else:
		l1llll_fi_ = str () .join ([chr (ord (char) - l1lll1_fi_ - (l1l1l_fi_ + l1l1l1_fi_) % l1l11_fi_) for l1l1l_fi_, char in enumerate (l11_fi_)])
	return eval (l1llll_fi_)
import urllib2,urllib
import re,random,json
import cookielib
l11ll1l11_fi_=10
l111l11ll_fi_=l11l_fi_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠶࠲࠱࠴࠳࠸࠶࠷࠳࠱࠵࠵࠸ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧ૜")
def l11ll11ll_fi_(url,data=None,header={},l1ll1ll1l1_fi_=True):
    l111l1lll_fi_=l11l_fi_ (u"ࠩࠪ૝")
    l11l11l11_fi_=[]
    if l1ll1ll1l1_fi_:
        l11l11l11_fi_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l11l11l11_fi_))
        urllib2.install_opener(opener)
    if not header:
        header = {l11l_fi_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ૞"):l111l11ll_fi_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l11ll1l11_fi_)
        l1ll1ll1_fi_ =  response.read()
        response.close()
        l111l1lll_fi_ = l11l_fi_ (u"ࠫࠬ૟").join([l11l_fi_ (u"ࠬࠫࡳ࠾ࠧࡶ࠿ࠬૠ")%(c.name, c.value) for c in l11l11l11_fi_])
    except urllib2.HTTPError as e:
        l1ll1ll1_fi_ = l11l_fi_ (u"࠭ࠧૡ")
    return l1ll1ll1_fi_,l111l1lll_fi_
def l1ll1111_fi_(url):
    url = url.replace(l11l_fi_ (u"ࠧࡩࡶࡷࡴ࠿࠭ૢ"),l11l_fi_ (u"ࠨࡪࡷࡸࡵࡹ࠺ࠨૣ")).replace(l11l_fi_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠱ࠪ૤"),l11l_fi_ (u"ࠪ࠳ࡄࡼ࠽ࠨ૥"))
    content,c = l11ll11ll_fi_(url)
    match = re.findall(l11l_fi_ (u"࡛ࠫࠬ࠭ࠣࠩࡠࡃࡸࡵࡵࡳࡥࡨࡷࡠ࠭ࠢ࡞ࡁ࡟ࡷ࠯ࡀ࡜ࡴࠬࠫࡠࡠ࠴ࠪࡀ࡞ࡠ࠭ࠬ࠭ࠧ૦"), content)
    l1ll1ll1ll_fi_=l11l_fi_ (u"ࠬ࠭૧")
    if not match:
        data = {}
        data[l11l_fi_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࠮ࡺࠩ૨")] = random.randint(0, 120)
        data[l11l_fi_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭࠯ࡺࠪ૩")] = random.randint(0, 120)
        header={l11l_fi_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ૪"):l111l11ll_fi_,l11l_fi_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ૫"):url}
        l1ll1lll1l_fi_ = url + l11l_fi_ (u"ࠪࠧࠬ૬")
        content,c = l11ll11ll_fi_(l1ll1lll1l_fi_,urllib.urlencode(data),header=header)
        match = re.findall(l11l_fi_ (u"࡛ࠫࠬ࠭ࠣࠩࡠࡃࡸࡵࡵࡳࡥࡨࡷࡠ࠭ࠢ࡞ࡁ࡟ࡷ࠯ࡀ࡜ࡴࠬࠫࡠࡠ࠴ࠪࡀ࡞ࡠ࠭ࠬ࠭ࠧ૭"), content)
    if match:
        print match
        try:
            data = json.loads(match[0])
            l1ll1ll1ll_fi_=[]
            for d in data:
                if isinstance(d,dict):
                    l1ll1lll11_fi_ = d.get(l11l_fi_ (u"ࠬ࡬ࡩ࡭ࡧࠪ૮"),l11l_fi_ (u"࠭ࠧ૯"))+l11l_fi_ (u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠫࡳࠧࡔࡨࡪࡪࡸࡥࡳ࠿ࠨࡷࠬ૰")%(l111l11ll_fi_,url)
                    l1ll1ll1ll_fi_.append((d.get(l11l_fi_ (u"ࠨ࡮ࡤࡦࡪࡲࠧ૱"),l11l_fi_ (u"ࠩࠪ૲")),l1ll1lll11_fi_))
        except:
            l1ll1ll1ll_fi_ = re.findall(l11l_fi_ (u"ࠪࠫࠬࡡࠧࠣ࡟ࡂࡪ࡮ࡲࡥ࡜ࠩࠥࡡࡄࡢࡳࠫ࠼࡟ࡷ࠯ࡡࠧࠣ࡟ࡂࠬࡠࡤࠧࠣ࡟࠮࠭ࠬ࠭ࠧ૳"), match[0])
            if l1ll1ll1ll_fi_:
                l1ll1ll1ll_fi_ = l1ll1ll1ll_fi_[0].replace(l11l_fi_ (u"ࠫࡡ࠵ࠧ૴"), l11l_fi_ (u"ࠬ࠵ࠧ૵"))
                l1ll1ll1ll_fi_ += l11l_fi_ (u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠪࡹࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠧࡶࠫ૶")%(l111l11ll_fi_,url)
    return l1ll1ll1ll_fi_
