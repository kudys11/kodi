# -*- coding: utf-8 -*-
import sys
l1111_fi_ = sys.version_info [0] == 2
l1lll1_fi_ = 2048
l1l11_fi_ = 7
def l11l_fi_ (ll_fi_):
	global l1l11l_fi_
	l1l1l1_fi_ = ord (ll_fi_ [-1])
	l11ll_fi_ = ll_fi_ [:-1]
	l1l_fi_ = l1l1l1_fi_ % len (l11ll_fi_)
	l11_fi_ = l11ll_fi_ [:l1l_fi_] + l11ll_fi_ [l1l_fi_:]
	if l1111_fi_:
		l1llll_fi_ = unicode () .join ([unichr (ord (char) - l1lll1_fi_ - (l1l1l_fi_ + l1l1l1_fi_) % l1l11_fi_) for l1l1l_fi_, char in enumerate (l11_fi_)])
	else:
		l1llll_fi_ = str () .join ([chr (ord (char) - l1lll1_fi_ - (l1l1l_fi_ + l1l1l1_fi_) % l1l11_fi_) for l1l1l_fi_, char in enumerate (l11_fi_)])
	return eval (l1llll_fi_)
import sys,re,os
import urllib2,urllib
import urlparse
import cookielib
import l111ll1l1_fi_
l11l1llll_fi_=l11l_fi_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡩ࡭ࡱ࡯ࡳࡦࡴ࠱ࡧࡴ࠵ࠧ৮")
l11ll1l11_fi_ = 15
l111l11ll_fi_=l11l_fi_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠶࠻࠲࠵࠴࠲࠶࠸࠷࠲࠾࠽ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧ৯")
l1ll11ll_fi_=l11l_fi_ (u"ࡵࠫ࡫࡯࡬ࡪ࠰ࡦࡳࡴࡱࡩࡦࠩৰ")
l1ll11l1_fi_ = False
def _1lllll11l_fi_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l11l_fi_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨৱ"), l111l11ll_fi_)
    if cookies:
        req.add_header(l11l_fi_ (u"ࠧࡉ࡯ࡰ࡭࡬ࡩࠧ৲"), cookies)
        req.add_header(l11l_fi_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ৳"), l11l1llll_fi_)
    try:
        response = urllib2.urlopen(req,timeout=l11ll1l11_fi_)
        l1ll1ll1_fi_ = response.read()
        response.close()
    except:
        l1ll1ll1_fi_=l11l_fi_ (u"ࠧࠨ৴")
    return l1ll1ll1_fi_
def l11ll11ll_fi_(url,data=None):
    global l1ll11l1_fi_
    content=l11l_fi_ (u"ࠨࠩ৵")
    if l1ll11l1_fi_==True:
        if l11l_fi_ (u"ࠩࡨࡱࡧ࡫ࡤࡀࡵࡤࡰࡹ࠭৶") in url:
            content = l1lllll1l1_fi_(url)
        else:
            content = l1llll1l1l_fi_(url)
    else:
        cookies=l111ll1l1_fi_.l11l1111l_fi_(l1ll11ll_fi_)
        content=_1lllll11l_fi_(url,data,cookies)
        if not content:
            l11l11l11_fi_=l1llllll11_fi_(l11l1llll_fi_,l1ll11ll_fi_)
            cookies=l111ll1l1_fi_.l11l1111l_fi_(l1ll11ll_fi_)
            content=_1lllll11l_fi_(url,data,cookies)
    return content
def l1llllll11_fi_(l1ll1ll1_fi_,l111111l1_fi_):
    l11l11l11_fi_ = cookielib.LWPCookieJar()
    l1llllllll_fi_ = l111ll1l1_fi_.l111ll11l_fi_(l1ll1ll1_fi_,l11l11l11_fi_,l111l11ll_fi_)
    l1111lll1_fi_=os.path.dirname(l111111l1_fi_)
    if not os.path.exists(l1111lll1_fi_):
        os.makedirs(l1111lll1_fi_)
    if l11l11l11_fi_:
        l11l11l11_fi_.save(l111111l1_fi_, ignore_discard = True)
    return l11l11l11_fi_
def l11ll1l_fi_(id=l11l_fi_ (u"ࠥࡴࡷ࡫࡭ࡪࡧࡵࡩࡒࡵࡶࡪࡧࡶࠦ৷")):
    content = l11ll11ll_fi_(l11l1llll_fi_)
    ids = [(a.start(), a.end()) for a in re.finditer(l11l_fi_ (u"ࠫࡁࡹࡥࡤࡶ࡬ࡳࡳࠦࡩࡥ࠿ࠥࠫ৸"), content)]
    ids.append( (-1,-1) )
    l111l1111_fi_=[]
    l1111l1l1_fi_=[]
    for i in range(len(ids[:-1])):
        l111l11l1_fi_ = content[ ids[i][1]:ids[i+1][0] ]
        if l111l11l1_fi_.startswith(id):
            items = re.compile(l11l_fi_ (u"ࠬࡂࡳࡦࡥࡷ࡭ࡴࡴࠠࡤ࡮ࡤࡷࡸࡃࠢࡪࡶࡨࡱࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡦࡥࡷ࡭ࡴࡴ࠾ࠨ৹"),re.DOTALL).findall(l111l11l1_fi_)
            for item in items:
                href = re.compile(l11l_fi_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ৺")).findall(item)
                l1l111l_fi_ = re.compile(l11l_fi_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ৻")).findall(item)
                title = re.compile(l11l_fi_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࠩৼ")).findall(item)
                l1llll1111_fi_ = re.compile(l11l_fi_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷ࡭ࡹࡲࡥࡠࡱࡵ࡫ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࠧ৽")).findall(item)
                if not title:
                    title = re.compile(l11l_fi_ (u"ࠪࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ৾")).findall(item)
                year = re.compile(l11l_fi_ (u"ࠫࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥࡽࡪࡧࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ৿")).findall(item)
                type = re.compile(l11l_fi_ (u"ࠬࡂࡳࡱࡣࡱࠤࡨࡲࡡࡴࡵࡀࠦࡹࡿࡰࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ਀")).findall(item)
                l111l111l_fi_ = re.compile(l11l_fi_ (u"࠭࠼ࡴࡲࡤࡲࠥࡩ࡬ࡢࡵࡶࡁࠧࡴࡵ࡮ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩਁ")).findall(item)
                l1111l111_fi_ = re.compile(l11l_fi_ (u"ࠧ࠽ࡲࠣࡧࡱࡧࡳࡴ࠿ࠥࡨࡪࡹࡣࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡳࡂࠬਂ")).findall(item)
                if href and title:
                    try: l111l111l_fi_ = eval(l11l_fi_ (u"ࠨ࠳࠱࠴࠯࠭ਃ")+l111l111l_fi_[0])*10
                    except: l111l111l_fi_ = l11l_fi_ (u"ࠩࠪ਄")
                    l1111ll1l_fi_={
                        l11l_fi_ (u"ࠪ࡬ࡷ࡫ࡦࠨਅ"):urlparse.urljoin(l11l1llll_fi_,href[0]),
                        l11l_fi_ (u"ࠫ࡮ࡳࡧࠨਆ"):urlparse.urljoin(l11l1llll_fi_,l1l111l_fi_[0]) if l1l111l_fi_ else l11l_fi_ (u"ࠬ࠭ਇ"),
                        l11l_fi_ (u"࠭ࡴࡪࡶ࡯ࡩࠬਈ"): title[0],
                        l11l_fi_ (u"ࠧࡰࡴ࡬࡫࡮ࡴࡡ࡭ࡶ࡬ࡸࡱ࡫ࠧਉ"): l1llll1111_fi_[0] if l1llll1111_fi_ else l11l_fi_ (u"ࠨࠩਊ"),
                        l11l_fi_ (u"ࠩࡼࡩࡦࡸࠧ਋"): year[0].split(l11l_fi_ (u"ࠪ࠲ࠬ਌"))[-1] if year else l11l_fi_ (u"ࠫࠬ਍"),
                        l11l_fi_ (u"ࠬࡶ࡬ࡰࡶࠪ਎"):l1111l111_fi_[0].replace(l11l_fi_ (u"࠭ࠦࡩࡧ࡯ࡰ࡮ࡶ࠻ࠨਏ"),l11l_fi_ (u"ࠧ࠯࠰࠱ࠫਐ")) if l1111l111_fi_ else l11l_fi_ (u"ࠨࠩ਑"),
                        l11l_fi_ (u"ࠩࡦࡳࡩ࡫ࠧ਒") : type[0] if type else l11l_fi_ (u"ࠪࠫਓ"),
                        l11l_fi_ (u"ࠫࡷࡧࡴࡪࡰࡪࠫਔ") : l111l111l_fi_,
                        }
                    if l11l_fi_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡥࡱ࠵ࠧਕ") in href[0]:
                        l1111l1l1_fi_.append(l1111ll1l_fi_)
                    else:
                        l111l1111_fi_.append(l1111ll1l_fi_)
    return l111l1111_fi_,l1111l1l1_fi_
def search(q=l11l_fi_ (u"࠭ࡡ࡯࡫ࡤࠫਖ")):
    content = l11ll11ll_fi_(l11l_fi_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨ࡬ࡰ࡮ࡹࡥࡳ࠰ࡦࡳ࠴ࡹࡺࡶ࡭ࡤ࡮ࡄࡷ࠽ࠨਗ")+q)
    l111l1111_fi_=[]
    l1111l1l1_fi_=[]
    l1lllll1ll_fi_ = re.compile(l11l_fi_ (u"ࠨ࠾ࡸࡰࠥ࡯ࡤ࠾ࠤࡵࡩࡸࡻ࡬ࡵࡎ࡬ࡷࡹ࠴ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫਘ"),re.DOTALL).findall(content)
    for result in l1lllll1ll_fi_:
        items = re.compile(l11l_fi_ (u"ࠩ࠿ࡰ࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪਙ"),re.DOTALL).findall(result)
        for item in items:
            href = re.compile(l11l_fi_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩਚ")).findall(item)
            l1l111l_fi_ = re.compile(l11l_fi_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ਛ")).findall(item)
            title = re.compile(l11l_fi_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴࠭ਜ")).findall(item)
            l1llll1111_fi_ = re.compile(l11l_fi_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡪࡶ࡯ࡩࡤࡵࡲࡨࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࠫਝ")).findall(item)
            year = re.compile(l11l_fi_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧ࡯࡮ࡧࡱࠥࡂ࠳࠰ࠨ࡝ࡦࡾ࠸ࢂ࠯࠮ࠫ࠾࠲ࡨ࡮ࡼ࠾ࠨਞ")).findall(item)
            if href and title:
                l1111ll1l_fi_={
                    l11l_fi_ (u"ࠨࡪࡵࡩ࡫࠭ਟ"):urlparse.urljoin(l11l1llll_fi_,href[0]),
                    l11l_fi_ (u"ࠩ࡬ࡱ࡬࠭ਠ"):urlparse.urljoin(l11l1llll_fi_,l1l111l_fi_[0]) if l1l111l_fi_ else l11l_fi_ (u"ࠪࠫਡ"),
                    l11l_fi_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪਢ"): title[0],
                    l11l_fi_ (u"ࠬࡵࡲࡪࡩ࡬ࡲࡦࡲࡴࡪࡶ࡯ࡩࠬਣ"): l1llll1111_fi_[0] if l1llll1111_fi_ else l11l_fi_ (u"࠭ࠧਤ"),
                    l11l_fi_ (u"ࠧࡺࡧࡤࡶࠬਥ"): year[0] if year else l11l_fi_ (u"ࠨࠩਦ"),
                    l11l_fi_ (u"ࠩࡦࡳࡩ࡫ࠧਧ") : l11l_fi_ (u"ࠪࡗࡪࡸࡩࡢ࡮ࠪਨ") if l11l_fi_ (u"ࠫࡸ࡫ࡲࡪࡣ࡯ࠫ਩") in href[0] else l11l_fi_ (u"ࠬࡌࡩ࡭࡯ࠪਪ"),
                    }
                if l11l_fi_ (u"࠭ࡳࡦࡴ࡬ࡥࡱ࠭ਫ") in href[0]:
                    l1111l1l1_fi_.append(l1111ll1l_fi_)
                else:
                    l111l1111_fi_.append(l1111ll1l_fi_)
    return l111l1111_fi_,l1111l1l1_fi_
def l11lll_fi_(url=l11l_fi_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡨ࡬ࡰ࡮࠴ࡴࡷ࠱ࡩ࡭ࡱࡳࡹࠨਬ")):
    content = l11ll11ll_fi_(url)
    l1111ll11_fi_ = False
    l1lllll111_fi_ = False
    l1l1ll1l_fi_ = re.compile(l11l_fi_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡪࡺࡥࡃࡱࡻࠦࡃ࠮࠮ࠫࡁࠬࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡥ࡯ࡩࡦࡸࠢ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨਭ"),re.DOTALL).findall(content)
    if l1l1ll1l_fi_:
        l1111ll11_fi_ = re.compile(l11l_fi_ (u"ࠩ࠿ࡥࠥࡩ࡬ࡢࡵࡶࡁࠧࡶࡂࡵࡰࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡷࡹࡿ࡬ࡦ࠿ࠥࡴࡦࡪࡤࡪࡰࡪ࠾ࠥ࠶ࠠ࠲࠲ࡳࡼࠧࡄࡐࡰࡲࡵࡾࡪࡪ࡮ࡪࡣ࠿࠳ࡦࡄࠧਮ")).findall(l1l1ll1l_fi_[0])
        l1111ll11_fi_ = l1111ll11_fi_[0].replace(l11l_fi_ (u"ࠪࠪࡦࡳࡰ࠼ࠩਯ"),l11l_fi_ (u"ࠫࠫ࠭ਰ")) if l1111ll11_fi_ else False
        l1lllll111_fi_ = re.compile(l11l_fi_ (u"ࠬࡂࡡࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡅࡸࡳࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭਱")).findall(l1l1ll1l_fi_[0])
        l1lllll111_fi_ = l1lllll111_fi_[-1].replace(l11l_fi_ (u"࠭ࠦࡢ࡯ࡳ࠿ࠬਲ"),l11l_fi_ (u"ࠧࠧࠩਲ਼")) if l11l_fi_ (u"ࠨࡐࡤࡷࡹ࠭਴") in l1l1ll1l_fi_[0] else False
    items = re.compile(l11l_fi_ (u"ࠩ࠿ࡷࡪࡩࡴࡪࡱࡱࠤࡨࡲࡡࡴࡵࡀࠦ࡮ࡺࡥ࡮ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡪࡩࡴࡪࡱࡱࡂࠬਵ"),re.DOTALL).findall(content)
    out=[]
    for item in items:
        href = re.compile(l11l_fi_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩਸ਼")).findall(item)
        l1l111l_fi_ = re.compile(l11l_fi_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭਷")).findall(item)
        title = re.compile(l11l_fi_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴࠭ਸ")).findall(item)
        l1llll1111_fi_ = re.compile(l11l_fi_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡪࡶ࡯ࡩࡤࡵࡲࡨࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࠫਹ")).findall(item)
        year = re.compile(l11l_fi_ (u"ࠧ࠽ࡵࡳࡥࡳࠦࡣ࡭ࡣࡶࡷࡂࠨࡹࡦࡣࡵࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ਺")).findall(item)
        type = re.compile(l11l_fi_ (u"ࠨ࠾ࡶࡴࡦࡴࠠࡤ࡮ࡤࡷࡸࡃࠢࡵࡻࡳࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ਻")).findall(item)
        l111l111l_fi_ = re.compile(l11l_fi_ (u"ࠩ࠿ࡷࡵࡧ࡮ࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡰࡸࡱࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂ਼ࠬ")).findall(item)
        l1111l111_fi_ = re.compile(l11l_fi_ (u"ࠪࡀࡵࠦࡣ࡭ࡣࡶࡷࡂࠨࡤࡦࡵࡦࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡶ࠾ࠨ਽")).findall(item)
        if href and title:
            try: l111l111l_fi_ = eval(l111l111l_fi_[0])*10
            except: l111l111l_fi_ = l11l_fi_ (u"ࠫࠬਾ")
            l1111ll1l_fi_={
                l11l_fi_ (u"ࠬ࡮ࡲࡦࡨࠪਿ"):urlparse.urljoin(l11l1llll_fi_,href[0]),
                l11l_fi_ (u"࠭ࡩ࡮ࡩࠪੀ"):urlparse.urljoin(l11l1llll_fi_,l1l111l_fi_[0]) if l1l111l_fi_ else l11l_fi_ (u"ࠧࠨੁ"),
                l11l_fi_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧੂ"): title[0],
                l11l_fi_ (u"ࠩࡲࡶ࡮࡭ࡩ࡯ࡣ࡯ࡸ࡮ࡺ࡬ࡦࠩ੃"): l1llll1111_fi_[0] if l1llll1111_fi_ else l11l_fi_ (u"ࠪࠫ੄"),
                l11l_fi_ (u"ࠫࡾ࡫ࡡࡳࠩ੅"): year[0] if year else l11l_fi_ (u"ࠬ࠭੆"),
                l11l_fi_ (u"࠭ࡰ࡭ࡱࡷࠫੇ"):l1111l111_fi_[0].replace(l11l_fi_ (u"ࠧࠧࡪࡨࡰࡱ࡯ࡰ࠼ࠩੈ"),l11l_fi_ (u"ࠨ࠰࠱࠲ࠬ੉")) if l1111l111_fi_ else l11l_fi_ (u"ࠩࠪ੊"),
                l11l_fi_ (u"ࠪࡧࡴࡪࡥࠨੋ") : type[0] if type else l11l_fi_ (u"ࠫࠬੌ"),
                l11l_fi_ (u"ࠬࡸࡡࡵ࡫ࡱ࡫੍ࠬ") : l111l111l_fi_,
                }
            out.append(l1111ll1l_fi_)
    return out,(l1111ll11_fi_,l1lllll111_fi_)
def l11111l_fi_(url=l11l_fi_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧ࡫࡯࡭࠳ࡺࡶ࠰ࡵࡨࡶ࡮ࡧ࡬࠰ࡹ࡬࡯࡮ࡴࡧࡰࡹ࡬ࡩ࠴࠸࠸ࠨ੎")):
    content = l11ll11ll_fi_(url)
    out=[]
    l1l111l_fi_ = re.compile(l11l_fi_ (u"ࠧ࠽࡫ࡰ࡫ࠥ࡯ࡤ࠾ࠤࡳࡳࡸࡺࡥࡳࠤࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ੏")).findall(content)
    l1l111l_fi_ = urlparse.urljoin(l11l1llll_fi_,l1l111l_fi_[0]) if l1l111l_fi_ else l11l_fi_ (u"ࠨࠩ੐")
    l1111l111_fi_ = re.compile(l11l_fi_ (u"ࠩ࠿ࡷࡪࡩࡴࡪࡱࡱࠤ࡮ࡪ࠽ࠣࡦࡨࡷࡨࡥࡢࡰࡺࠥࡂࡁ࡮࠳ࠡ࡫ࡧࡁࠧࡹࡵࡣࡡࡷ࡭ࡹࡲࡥࠣࡀࡒࡴ࡮ࡹࠠࡴࡧࡵ࡭ࡦࡲࡵ࠻࠾࠲࡬࠸ࡄ࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡨࡲࡥࡢࡴࠥࡂࡁ࠵ࡤࡪࡸࡁࡀࡵࠦࡩࡥ࠿ࠥࡨࡪࡹࡣࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡳࡂࡁ࠵ࡳࡦࡥࡷ࡭ࡴࡴ࠾ࠨੑ")).findall(content)
    l1111l111_fi_ = l1111l111_fi_[0] if l1111l111_fi_ else l11l_fi_ (u"ࠪࠫ੒")
    l11111111_fi_=re.compile(l11l_fi_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡪࡶࡩࡴࡱࡧࡩࡓࡧ࡭ࡦࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ੓")).findall(content)
    for href,title in l11111111_fi_:
        l1llllll1l_fi_ = re.findall(l11l_fi_ (u"ࠬࡹࠨ࡝ࡦ࠮࠭ࠬ੔"),href,flags=re.I)
        l1llllll1l_fi_ = int(l1llllll1l_fi_[0]) if l1llllll1l_fi_ else l11l_fi_ (u"࠭ࠧ੕")
        l1llll1ll1_fi_ = re.findall(l11l_fi_ (u"ࠧࡦࠪ࡟ࡨ࠰࠯ࠧ੖"),href,flags=re.I)
        l1llll1ll1_fi_ = int(l1llll1ll1_fi_[0]) if l1llll1ll1_fi_ else l11l_fi_ (u"ࠨࠩ੗")
        l1111ll1l_fi_ = { l11l_fi_ (u"ࠩ࡫ࡶࡪ࡬ࠧ੘")  : urlparse.urljoin(l11l1llll_fi_,href),
                l11l_fi_ (u"ࠪࡷࡪࡧࡳࡰࡰࠪਖ਼") : l1llllll1l_fi_,
                l11l_fi_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࠬਗ਼") : l1llll1ll1_fi_,
                l11l_fi_ (u"ࠬࡳࡥࡥ࡫ࡤࡸࡾࡶࡥࠨਜ਼"): l11l_fi_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࠧੜ"),
                l11l_fi_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭੝") : l11l_fi_ (u"ࠨࠧࡧࡼࠪࡪࠠࠦࡵࠪਫ਼")%(l1llllll1l_fi_,l1llll1ll1_fi_,title),
                l11l_fi_ (u"ࠩࡳࡰࡴࡺࠧ੟"):l1111l111_fi_,
                l11l_fi_ (u"ࠪ࡭ࡲ࡭ࠧ੠"): l1l111l_fi_ }
        out.append(l1111ll1l_fi_)
    return out
def l1ll1l1_fi_(out):
    l1111l1l1_fi_={}
    l1lll1l_fi_ = [x.get(l11l_fi_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࠫ੡")) for x in out]
    for s in set(l1lll1l_fi_):
        l1111l1l1_fi_[l11l_fi_ (u"࡙ࠬࡥࡻࡱࡱࠤࠪ࠶࠲ࡥࠩ੢")%s]=[out[i] for i, j in enumerate(l1lll1l_fi_) if j == s]
    return l1111l1l1_fi_
url=l11l_fi_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧ࡫࡯࡭ࡸ࡫ࡲ࠯ࡥࡲ࠳࡫࡯࡬࡮࠱࡬ࡲࡩ࡯ࡡ࡯ࡣ࠰࡮ࡴࡴࡥࡴ࠯࡬࠱ࡴࡹࡴࡢࡶࡱ࡭ࡦ࠳࡫ࡳࡷࡦ࡮ࡦࡺࡡ࠮࠳࠼࠼࠾࠵࠱࠹࠷ࠪ੣")
def l1l1l1l1_fi_(url):
    content = l11ll11ll_fi_(url)
    l1111l1ll_fi_=[]
    l1llll1l11_fi_ = re.compile(l11l_fi_ (u"ࠧࡥࡣࡷࡥ࠲ࡺࡹࡱࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭ࡢࡷࠫࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ੤")).findall(content)
    l1llll11ll_fi_ = re.compile(l11l_fi_ (u"ࠨ࠾ࡸࡰࠥࡡࡳࡵࡻ࡯ࡩࡂࠨࡤࡪࡵࡳࡰࡦࡿ࠺࡯ࡱࡱࡩࠧࠦ࡝ࠫࡦࡤࡸࡦ࠳ࡴࡺࡲࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ੥"),re.DOTALL).findall(content)
    for l1llll1lll_fi_,l11l11_fi_ in l1llll11ll_fi_:
        l11111l1l_fi_ = re.compile(l11l_fi_ (u"ࠩ࠿ࡰ࡮࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩ੦")).findall(l11l11_fi_)
        for l11111ll1_fi_ in l11111l1l_fi_:
            data = re.compile(l11l_fi_ (u"ࠪࡨࡦࡺࡡ࠮ࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭੧")).findall(l11111ll1_fi_)
            quality = re.compile(l11l_fi_ (u"ࠫࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥࡵࡺࡧ࡬ࡪࡶࡼࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ੨")).findall(l11111ll1_fi_)
            host = re.compile(l11l_fi_ (u"ࠬࡂࡳࡱࡣࡱࠤࡨࡲࡡࡴࡵࡀࠦ࡭ࡵࡳࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ੩")).findall(l11111ll1_fi_)
            if data:
                quality = quality[0] if quality else l11l_fi_ (u"࠭࠿ࠨ੪")
                host = host[0] if host else l11l_fi_ (u"ࠧࡀࠩ੫")
                l1111ll1l_fi_ = {l11l_fi_ (u"ࠨࡷࡵࡰࠬ੬") : l11l_fi_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪ࡮ࡲࡩࡴࡧࡵ࠲ࡨࡵ࠯ࡦ࡯ࡥࡩࡩࡅࡳࡢ࡮ࡷࡁࠬ੭")+data[0],
                    l11l_fi_ (u"ࠪࡰࡦࡨࡥ࡭ࠩ੮"): l11l_fi_ (u"ࠦࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟ࠨࡷࡠ࠵ࡃࡐࡎࡒࡖࡢࠦࡼࠡࠧࡶࠤࢁ࡛ࠦࠦࡵࡠࠦ੯") %(l1llll1lll_fi_,quality,host),
                    l11l_fi_ (u"ࠬ࡮࡯ࡴࡶࠪੰ"): host,
                    l11l_fi_ (u"࠭࡬ࡢࡰࡪࠫੱ"):l1llll1lll_fi_,
                    }
                l1111l1ll_fi_.append(l1111ll1l_fi_)
    return l1111l1ll_fi_
l11111l11_fi_=l11l_fi_ (u"ࠧࠨੲ")
l11111l11_fi_=l11l_fi_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡨࡲࡢ࡯࡮ࡥ࠲ࡶࡲࡰࡺࡼ࠲ࡵࡲࠧੳ")
l1111llll_fi_=l11l_fi_ (u"ࠩࠪੴ")
def l1lllll1l1_fi_(url,header={}):
    l1ll1ll1_fi_=l11l_fi_ (u"ࠪࡿࢂ࠭ੵ")
    global l1111llll_fi_
    if not l1111llll_fi_:
        req = urllib2.Request(l11111l11_fi_,data=None,headers={l11l_fi_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ੶"): l11l_fi_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠺࠶࠮࠱࠰࠵࠺࠻࠷࠮࠲࠲࠵ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫ੷")})
        response = urllib2.urlopen(req,timeout=l11ll1l11_fi_)
        cookies=response.headers.get(l11l_fi_ (u"࠭ࡳࡦࡶ࠰ࡧࡴࡵ࡫ࡪࡧࠪ੸"),l11l_fi_ (u"ࠧࠡࠩ੹")).split(l11l_fi_ (u"ࠨࠢࠪ੺"))[0]
        response.close()
        l1111llll_fi_ = cookies
    else:
        cookies=l1111llll_fi_
    data = l11l_fi_ (u"ࠩࡸࡁࠪࡹࠦࡢ࡮࡯ࡳࡼࡉ࡯ࡰ࡭࡬ࡩࡸࡃ࡯࡯ࠩ੻")%urllib.quote_plus(url)
    l11111lll_fi_ = l11111l11_fi_+l11l_fi_ (u"ࠪ࠳࡮ࡴࡣ࡭ࡷࡧࡩࡸ࠵ࡰࡳࡱࡦࡩࡸࡹ࠮ࡱࡪࡳࡃࡦࡩࡴࡪࡱࡱࡁࡺࡶࡤࡢࡶࡨࠫ੼")
    c=l11l_fi_ (u"ࠫࠬ੽")
    headers={l11l_fi_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ੾"): l111l11ll_fi_,l11l_fi_ (u"࠭ࡕࡱࡩࡵࡥࡩ࡫࠭ࡊࡰࡶࡩࡨࡻࡲࡦ࠯ࡕࡩࡶࡻࡥࡴࡶࡶࠫ੿"):1,l11l_fi_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ઀"):cookies+c}
    headers.update(header)
    req = urllib2.Request(l11111lll_fi_,data,headers)
    response = urllib2.urlopen(req,timeout=l11ll1l11_fi_)
    l1ll1ll1_fi_=response.read()
    if l11l_fi_ (u"ࠨࡵࡶࡰࡦ࡭ࡲࡦࡧࠪઁ") in l1ll1ll1_fi_:
        l11111lll_fi_ = l11111l11_fi_+l11l_fi_ (u"ࠩ࠲࡭ࡳࡩ࡬ࡶࡦࡨࡷ࠴ࡶࡲࡰࡥࡨࡷࡸ࠴ࡰࡩࡲࡂࡥࡨࡺࡩࡰࡰࡀࡷࡸࡲࡡࡨࡴࡨࡩࠬં")
        req = urllib2.Request(l11111lll_fi_,data,headers)
        response = urllib2.urlopen(req,timeout=l11ll1l11_fi_)
        l1ll1ll1_fi_=response.read()
    response.close()
    print l11l_fi_ (u"ࠪࡋࡆ࡚ࡅࠡ࡫ࡱࠤ࡚࡙ࡅࠨઃ")
    return l1ll1ll1_fi_
def l1llll1l1l_fi_(url,head={}):
    try:
        l111111ll_fi_ =l11l_fi_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡧࡸࡡ࡮࡭ࡤ࠲ࡵࡸ࡯ࡹࡻ࠱ࡲࡪࡺ࠮ࡱ࡮࠲࡭ࡳࡪࡥࡹ࠰ࡳ࡬ࡵࡅࡱ࠾ࠧࡶࠪ࡭ࡲ࠽࠱ࠩ઄")%urllib.quote_plus(url)
        headers={l11l_fi_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩઅ"): l11l_fi_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡ࡬ࡲ࠻࠺࠻ࠡࡺ࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠺࠶࠴࠰࠯࠵࠴࠺࠸࠴࠱࠱࠲ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪઆ"),l11l_fi_ (u"ࠧࡖࡲࡪࡶࡦࡪࡥ࠮ࡋࡱࡷࡪࡩࡵࡳࡧ࠰ࡖࡪࡷࡵࡦࡵࡷࡷࠬઇ"):1,
        l11l_fi_ (u"ࠨࡃࡦࡧࡪࡶࡴࠨઈ"):l11l_fi_ (u"ࠩࡷࡩࡽࡺ࠯ࡩࡶࡰࡰ࠱ࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࡭ࡺ࡭࡭࠭ࡻࡱࡱ࠲ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽࡳ࡬࠼ࡳࡀ࠴࠳࠿ࠬࡪ࡯ࡤ࡫ࡪ࠵ࡷࡦࡤࡳ࠰࡮ࡳࡡࡨࡧ࠲ࡥࡵࡴࡧ࠭ࠬ࠲࠮ࡀࡷ࠽࠱࠰࠻ࠫઉ")}
        if head:
            headers.update(head)
        req = urllib2.Request(l111111ll_fi_,None,headers)
        response = urllib2.urlopen(req,timeout=l11ll1l11_fi_)
        l1111111l_fi_ = response.headers.dict
        l1ll1ll1_fi_=response.read()
        response.close()
    except:
        l1ll1ll1_fi_=l11l_fi_ (u"ࠪࠫઊ")
        l1111111l_fi_={}
    return l1ll1ll1_fi_
def l1l11l11_fi_(url,host):
    print(l11l_fi_ (u"ࠫ࡬࡫ࡴࡆ࡯ࡥࡩࡩ࡫ࡤࡍ࡫ࡱ࡯ࠬઋ"),url,host)
    content = l11ll11ll_fi_(url)
    l1ll1ll1_fi_ = re.search(l11l_fi_ (u"ࠬࡨ࠽ࠣࠪ࡫ࡸࡹࡶ࡛࡟ࠤ࡟ࠫࡁࡣࠫࠪࠤࠪઌ"),content)
    l1lllllll1_fi_ = re.search(l11l_fi_ (u"࠭ࡢ࠾ࠤࠫ࡟ࡣࠨ࡜ࠨ࠾ࡠ࠯࠮ࠨࠧઍ"),content)
    if l1ll1ll1_fi_:
        return l1ll1ll1_fi_.group(1).replace(l11l_fi_ (u"ࠧࠤ࡙ࡌࡈ࡙ࡎࠧ઎"),l11l_fi_ (u"ࠨ࠵࠵࠴ࠬએ")).replace(l11l_fi_ (u"ࠩࠦࡌࡊࡏࡇࡉࡖࠪઐ"),l11l_fi_ (u"ࠪ࠶࠹࠶ࠧઑ"))
    elif l1lllllll1_fi_:
        l1lllllll1_fi_ = l1lllllll1_fi_.group(1)
        if host==l11l_fi_ (u"ࠫࡨࡪࡡࠨ઒"):             l1llll111l_fi_=l11l_fi_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡧࡩࡧ࠮ࡱ࡮ࠪઓ")+l1lllllll1_fi_.replace(l11l_fi_ (u"࠭ࠣࡘࡋࡇࡘࡍࡾࠧઔ"),l11l_fi_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ક")).replace(l11l_fi_ (u"ࠨࠥࡋࡉࡎࡍࡈࡕࠩખ"),l11l_fi_ (u"ࠩࠪગ"))
        elif host==l11l_fi_ (u"ࠪࡳࡵ࡫࡮࡭ࡱࡤࡨࠬઘ"):      l1llll111l_fi_=l11l_fi_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡵࡰࡦࡰ࡯ࡳࡦࡪ࠮ࡤࡱࠪઙ")+l1lllllll1_fi_.replace(l11l_fi_ (u"ࠬࠩࡗࡊࡆࡗࡌࡽ࠭ચ"),l11l_fi_ (u"࠭ࠧછ")).replace(l11l_fi_ (u"ࠧࠤࡊࡈࡍࡌࡎࡔࠨજ"),l11l_fi_ (u"ࠨࠩઝ"))
        elif host==l11l_fi_ (u"ࠩࡶࡸࡷ࡫ࡡ࡮ࡣࡱ࡫ࡴ࠭ઞ"):    l1llll111l_fi_=l11l_fi_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡺࡲࡦࡣࡰࡥࡳ࡭࡯࠯ࡥࡲࡱࠬટ")+l1lllllll1_fi_.replace(l11l_fi_ (u"ࠫࠨ࡝ࡉࡅࡖࡋࡼࠬઠ"),l11l_fi_ (u"ࠬ࠭ડ")).replace(l11l_fi_ (u"࠭ࠣࡉࡇࡌࡋࡍ࡚ࠧઢ"),l11l_fi_ (u"ࠧࠨણ"))
        elif host==l11l_fi_ (u"ࠨࡸ࡬ࡨࡴࢀࡡࠨત"):        l1llll111l_fi_=l11l_fi_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺ࡮ࡪ࡯ࡻࡣ࠱ࡲࡪࡺࠧથ")+l1lllllll1_fi_.replace(l11l_fi_ (u"ࠪࠧ࡜ࡏࡄࡕࡊࡻࠫદ"),l11l_fi_ (u"ࠫࠬધ")).replace(l11l_fi_ (u"ࠬࠩࡈࡆࡋࡊࡌ࡙࠭ન"),l11l_fi_ (u"࠭ࠧ઩"))
        elif host==l11l_fi_ (u"ࠧࡢࡰࡼࡪ࡮ࡲࡥࡴࠩપ"):      l1llll111l_fi_=l11l_fi_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡲࡾ࡬ࡩ࡭ࡧࡶ࠲ࡵࡲࠧફ")+l1lllllll1_fi_.replace(l11l_fi_ (u"࡛ࠩࠦࡎࡊࡔࡉࠩબ"),l11l_fi_ (u"ࠪ࠺࠹࠶ࠧભ")).replace(l11l_fi_ (u"ࠫࠨࡎࡅࡊࡉࡋࡘࠬમ"),l11l_fi_ (u"ࠬ࠹࠶࠱ࠩય"))
        else:
            host +=l11l_fi_ (u"࠭࠮ࡤࡱࡰࠫર")
            l1llll111l_fi_=l11l_fi_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠨ઱")+host+l1lllllll1_fi_.replace(l11l_fi_ (u"ࠨ࡚ࠥࡍࡉ࡚ࡈࡹࠩલ"),l11l_fi_ (u"ࠩࠪળ")).replace(l11l_fi_ (u"ࠪࠧࡍࡋࡉࡈࡊࡗࠫ઴"),l11l_fi_ (u"ࠫࠬવ"))
        return l1llll111l_fi_
    else:
        l11l11_fi_ = re.findall(l11l_fi_ (u"ࠬࡡ࡜ࠨࠤࡠࠬ࡭ࡺࡴࡱ࡝ࡡࠦࡡ࠭࠼࡞࠭ࠬ࡟ࡡ࠭ࠢ࡞ࠩશ"),content)
        l1111l11l_fi_=[l11l_fi_ (u"࠭ࡧࡰࡱࡪࡰࡪࡧࡰࡪࡵࠪષ"),l11l_fi_ (u"ࠧࡧ࡫࡯࡭࠳ࡺࡶࠨસ"),l11l_fi_ (u"ࠨࡵࡳࡳࡱ࡫ࡣࡻࡰࡲࡷࡨ࡯ࠧહ")]
        for l1llll11l1_fi_ in l1111l11l_fi_:
            for l1111ll1l_fi_ in l11l11_fi_:
                if l1llll11l1_fi_ in l1111ll1l_fi_:
                    l11l11_fi_.pop(l11l11_fi_.index(l1111ll1l_fi_))
                    continue
        if l11l11_fi_:
            return l11l11_fi_[0].replace(l11l_fi_ (u"࡛ࠩࠦࡎࡊࡔࡉࠩ઺"),l11l_fi_ (u"ࠪ࠷࠷࠶ࠧ઻")).replace(l11l_fi_ (u"ࠫࠨࡎࡅࡊࡉࡋࡘ઼ࠬ"),l11l_fi_ (u"ࠬ࠸࠴࠱ࠩઽ"))
    return l11l_fi_ (u"࠭ࠧા")
