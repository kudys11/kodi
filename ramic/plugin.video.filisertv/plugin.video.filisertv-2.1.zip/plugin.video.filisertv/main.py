# -*- coding: utf-8 -*-
import sys
l1111_fi_ = sys.version_info [0] == 2
l1lll1_fi_ = 2048
l1l11_fi_ = 7
def l11l_fi_ (ll_fi_):
	global l1l11l_fi_
	l1l1l1_fi_ = ord (ll_fi_ [-1])
	l11ll_fi_ = ll_fi_ [:-1]
	l1l_fi_ = l1l1l1_fi_ % len (l11ll_fi_)
	l11_fi_ = l11ll_fi_ [:l1l_fi_] + l11ll_fi_ [l1l_fi_:]
	if l1111_fi_:
		l1llll_fi_ = unicode () .join ([unichr (ord (char) - l1lll1_fi_ - (l1l1l_fi_ + l1l1l1_fi_) % l1l11_fi_) for l1l1l_fi_, char in enumerate (l11_fi_)])
	else:
		l1llll_fi_ = str () .join ([chr (ord (char) - l1lll1_fi_ - (l1l1l_fi_ + l1l1l1_fi_) % l1l11_fi_) for l1l1l_fi_, char in enumerate (l11_fi_)])
	return eval (l1llll_fi_)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import check
import ramic as l1l1ll1_fi_
l11ll11_fi_        = sys.argv[0]
l1llllll_fi_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l11llll_fi_        = xbmcaddon.Addon()
PATH            = xbmcaddon.Addon().getAddonInfo(l11l_fi_ (u"ࠧࡱࡣࡷ࡬ࠬ࠭"))
l1l11ll_fi_        = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l11l_fi_ (u"ࠨࡲࡵࡳ࡫࡯࡬ࡦࠩ࠮"))).decode(l11l_fi_ (u"ࠩࡸࡸ࡫࠳࠸ࠨ࠯"))
import resources.lib.l1l1lll_fi_ as l1ll1l11_fi_
import time,threading
l1ll1l11_fi_.l1ll11ll_fi_=os.path.join(l1l11ll_fi_,l11l_fi_ (u"ࠪࡪ࡮ࡲࡥ࠯ࡥࡲࡳࡰ࡯ࡥࠨ࠰"))
if l11l_fi_ (u"ࠫࡹࡸࡵࡦࠩ࠱") in l11llll_fi_.getSetting(l11l_fi_ (u"ࠬࡻࡳࡦࡒࡵࡳࡽࡿࠧ࠲")):
    l1ll1l11_fi_.l1ll11l1_fi_ = True
    l1ll1lll_fi_ = l11l_fi_ (u"࠭ࠠ࡜ࡅࡒࡐࡔࡘࠠࡨࡱ࡯ࡨࡢࡡࡐࡳࡱࡻࡽࠥࡧ࡫ࡵࡻࡺࡲࡪࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ࠳")
else:
    l1ll1l11_fi_.l1ll11l1_fi_ = False
    l1ll1lll_fi_ = l11l_fi_ (u"ࠧࠨ࠴")
try: from shutil import rmtree
except: rmtree = False
def l1_fi_(l1l111_fi_,l1l1_fi_=[l11l_fi_ (u"ࠨࠩ࠵")]):
    debug=1
def l111l_fi_(name=l11l_fi_ (u"ࠩࠪ࠶")):
    debug=1
def l111_fi_(top):
    debug=1
def l1l1111_fi_():
    l1l111_fi_ = os.path.join(xbmc.translatePath(l11l_fi_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧࡁ")),l11l_fi_ (u"ࠧࡢࡦࡧࡳࡳࡹࠧࡂ"))
    xbmc.log(l1l111_fi_)
    if l1_fi_(l1l111_fi_,[l11l_fi_ (u"ࠨࡣ࡯࡭ࡪࡴࡷࡪࡼࡤࡶࡩ࠭ࡃ"),l11l_fi_ (u"ࠩࡨࡼࡹ࡫࡮ࡥࡧࡵ࠲ࡦࡲࡩࡦࡰࠪࡄ")])>0:
        l111l_fi_(l11l_fi_ (u"ࠪࡻ࡮ࢀࡡࡳࡦࠪࡅ"))
        return
    l1l1ll_fi_ = os.path.join(xbmc.translatePath(l11l_fi_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡶࡵࡨࡶࡩࡧࡴࡢࠩࡆ")),l11l_fi_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩࡇ"),l11l_fi_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡦ࡫࡯࡯࠰ࡱࡳࡽ࠴࠵ࠨࡈ"),l11l_fi_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭ࡉ"))
    if os.path.exists(l1l1ll_fi_):
        data = open(l1l1ll_fi_,l11l_fi_ (u"ࠨࡴࠪࡊ")).read()
        data= re.sub(l11l_fi_ (u"ࠩ࡟࡟࠳࠰࡜࡞ࠩࡋ"),l11l_fi_ (u"ࠪࠫࡌ"),data)
        if len(re.compile(l11l_fi_ (u"ࠫࡃ࠴ࠪࠩࡲࡲࡰࡸࡱࡡ࡝ࡵ࠭ࡸࡡࡹࠪࡷࠫࠪࡍ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l111l_fi_(l11l_fi_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡥࡪࡵ࡮࠯ࡰࡲࡼ࠳࠻ࠧࡎ"))
            return
        if len(re.compile(l11l_fi_ (u"࠭࠾࠯ࠬࠫࡨࡦࡸ࡭ࡰࡹࡤࡠࡸ࠰ࡴ࡝ࡵ࠭ࡺ࠮࠭ࡏ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l111l_fi_(l11l_fi_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡧࡥࡰࡰ࠱ࡲࡴࡾ࠮࠶ࠩࡐ"))
            return
    l1l1ll_fi_ = os.path.join(xbmc.translatePath(l11l_fi_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡺࡹࡥࡳࡦࡤࡸࡦ࠭ࡑ")),l11l_fi_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭ࡒ"),l11l_fi_ (u"ࠪࡷࡰ࡯࡮࠯ࡺࡲࡲ࡫ࡲࡵࡦࡰࡦࡩࠬࡓ"),l11l_fi_ (u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪࡔ"))
    if os.path.exists(l1l1ll_fi_):
        data = open(l1l1ll_fi_,l11l_fi_ (u"ࠬࡸࠧࡕ")).read()
        data= re.sub(l11l_fi_ (u"࠭࡜࡜࠰࠭ࡠࡢ࠭ࡖ"),l11l_fi_ (u"ࠧࠨࡗ"),data)
        if len(re.compile(l11l_fi_ (u"ࠨࡀ࠱࠮࠭ࡶ࡯࡭ࡵ࡮ࡥࡡࡹࠪࡵ࡞ࡶ࠮ࡻ࠯ࠧࡘ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l111l_fi_(l11l_fi_ (u"ࠩࡶ࡯࡮ࡴ࠮ࡹࡱࡱࡪࡱࡻࡥ࡯ࡥࡨ࡙ࠫ"))
            return
    l1l111_fi_ = os.path.join(xbmc.translatePath(l11l_fi_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡵࡴࡧࡵࡨࡦࡺࡡࠨ࡚")),l11l_fi_ (u"ࠫࡵࡸ࡯ࡧ࡫࡯ࡩࡸ࡛࠭"))
    if os.path.exists(l1l111_fi_):
        if l1_fi_(l1l111_fi_,[l11l_fi_ (u"ࠬࡱࡩࡥࡵࠪ࡜")])>0:
            l111l_fi_(l11l_fi_ (u"࠭ࡷࡪࡼࡤࡶࡩ࠭࡝"))
            return
    l1ll_fi_ = xbmc.translatePath(l11l_fi_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨ࡞"))
    for f in os.listdir(l1ll_fi_):
        if f.startswith(l11l_fi_ (u"ࠨࡏࡐࡉࡘ࠭࡟")):
            l111l_fi_()
            return
try:
    debug=1
except: pass
l1l1l11l_fi_=l11l_fi_ (u"ࠪࠫࡡ")
def l1l11lll_fi_(name, url, mode, l1l11111_fi_=1, l1ll111_fi_=None, infoLabels=False, IsPlayable=True, isFolder = False, fanart=l1l1l11l_fi_,l111ll1_fi_=1):
    u = l111l1_fi_({l11l_fi_ (u"ࠫࡲࡵࡤࡦࠩࡢ"): mode, l11l_fi_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࡳࡧ࡭ࡦࠩࡣ"): name, l11l_fi_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧࡤ") : url, l11l_fi_ (u"ࠧࡱࡣࡪࡩࠬࡥ"):l1l11111_fi_})
    if l1ll111_fi_==None:
        l1ll111_fi_=l11l_fi_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬࡦ")
    l111l11_fi_ = xbmcgui.ListItem(name, iconImage=l1ll111_fi_, thumbnailImage=l1ll111_fi_)
    l11lllll_fi_=[l11l_fi_ (u"ࠩࡷ࡬ࡺࡳࡢࠨࡧ"),l11l_fi_ (u"ࠪࡴࡴࡹࡴࡦࡴࠪࡨ"),l11l_fi_ (u"ࠫࡧࡧ࡮࡯ࡧࡵࠫࡩ"),l11l_fi_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࠬࡪ"),l11l_fi_ (u"࠭ࡣ࡭ࡧࡤࡶࡦࡸࡴࠨ࡫"),l11l_fi_ (u"ࠧࡤ࡮ࡨࡥࡷࡲ࡯ࡨࡱࠪ࡬"),l11l_fi_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫ࡭"),l11l_fi_ (u"ࠩ࡬ࡧࡴࡴࠧ࡮")]
    l11l1l_fi_=dict(zip(l11lllll_fi_,[l1ll111_fi_ for x in l11lllll_fi_]))
    l111l11_fi_.setArt(l11l1l_fi_)
    if not infoLabels:
        infoLabels={l11l_fi_ (u"ࠥࡸ࡮ࡺ࡬ࡦࠤ࡯"): name}
    l111l11_fi_.setInfo(type=l11l_fi_ (u"ࠦࡻ࡯ࡤࡦࡱࠥࡰ"), infoLabels=infoLabels)
    if IsPlayable:
        l111l11_fi_.setProperty(l11l_fi_ (u"ࠬࡏࡳࡑ࡮ࡤࡽࡦࡨ࡬ࡦࠩࡱ"), l11l_fi_ (u"࠭ࡴࡳࡷࡨࠫࡲ"))
    if fanart:
        l111l11_fi_.setProperty(l11l_fi_ (u"ࠧࡧࡣࡱࡥࡷࡺ࡟ࡪ࡯ࡤ࡫ࡪ࠭ࡳ"),fanart)
    ok = xbmcplugin.addDirectoryItem(handle=l1llllll_fi_, url=u, listitem=l111l11_fi_,isFolder=isFolder,totalItems=l111ll1_fi_)
    xbmcplugin.addSortMethod(l1llllll_fi_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l11l_fi_ (u"ࠣࠧࡕ࠰࡙ࠥࠫ࠭ࠢࠨࡔࠧࡴ"))
    return ok
def l1l111ll_fi_(l1ll1l1l_fi_):
    l11111_fi_ = {}
    for k, v in l1ll1l1l_fi_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l11l_fi_ (u"ࠩࡸࡸ࡫࠾ࠧࡵ"))
        elif isinstance(v, str):
            v.decode(l11l_fi_ (u"ࠪࡹࡹ࡬࠸ࠨࡶ"))
        l11111_fi_[k] = v
    return l11111_fi_
def l111l1_fi_(query):
    return l11ll11_fi_ + l11l_fi_ (u"ࠫࡄ࠭ࡷ") + urllib.urlencode(l1l111ll_fi_(query))
def l11lll1_fi_(ex_link,l1ll11l_fi_=False,name=l11l_fi_ (u"ࠬ࠭ࡸ"),l1lll1ll_fi_=l11l_fi_ (u"࠭ࠧࡹ")):
    l11l11_fi_ = l1ll1l11_fi_.l1l1l1l1_fi_(ex_link)
    l1lll111_fi_=l11l_fi_ (u"ࠧࠨࡺ")
    t = [ x.get(l11l_fi_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࡻ")) for x in l11l11_fi_]
    l11ll1_fi_ = xbmcgui.Dialog().select(l11l_fi_ (u"ࠤࡏ࡭ࡳࡱࡩࠣࡼ"), t)
    if l11ll1_fi_>-1:
        l1ll1ll1_fi_ = l1ll1l11_fi_.l1l11l11_fi_(l11l11_fi_[l11ll1_fi_].get(l11l_fi_ (u"ࠪࡹࡷࡲࠧࡽ"),l11l_fi_ (u"ࠫࠬࡾ")),l11l11_fi_[l11ll1_fi_].get(l11l_fi_ (u"ࠬ࡮࡯ࡴࡶࠪࡿ"),l11l_fi_ (u"࠭ࠧࢀ")))
        l1lll111_fi_=l1l1ll1_fi_.__mysolver__.go(l1ll1ll1_fi_)
        if False:
            if l11l_fi_ (u"ࠧࡤࡦࡤࠫࢁ") in l1ll1ll1_fi_:
                import resources.lib.l1lll1l1_fi_ as l1lll1l1_fi_
                l1lll111_fi_ = l1lll1l1_fi_.l1ll1111_fi_(l1ll1ll1_fi_)
                if type(l1lll111_fi_) is list:
                    l1l1l1ll_fi_ = [x[0] for x in l1lll111_fi_]
                    l11ll1_fi_ = xbmcgui.Dialog().select(l11l_fi_ (u"࡙ࠣࡼࡦ࡮࡫ࡲࡻࠢ࡭ࡥࡰࡵज़ईࠤࢂ"), l1l1l1ll_fi_)
                    if l11ll1_fi_>-1:
                        l1lll111_fi_ = l1lll1l1_fi_.l1ll1111_fi_(l1lll111_fi_[l11ll1_fi_][1])
                    else:
                        l1lll111_fi_=l11l_fi_ (u"ࠩࠪࢃ")
            elif l11l_fi_ (u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵࠧࢄ") in l1ll1ll1_fi_ or l11l_fi_ (u"ࠫࡷࡧࡰࡵࡷࠪࢅ") in l1ll1ll1_fi_:
                import resources.lib.l1l1l111_fi_ as l1111l1_fi_
                l1lll111_fi_ = l1111l1_fi_.l1ll1111_fi_(l1ll1ll1_fi_)
                if type(l1lll111_fi_) is list:
                    l1l1l1ll_fi_ = [x[0] for x in l1lll111_fi_]
                    l11ll1_fi_ = xbmcgui.Dialog().select(l11l_fi_ (u"ࠧ࡝ࡹࡣ࡫ࡨࡶࡿࠦࡪࡢ࡭ࡲय़ऌࠨࢆ"), l1l1l1ll_fi_)
                    if l11ll1_fi_>-1: l1lll111_fi_ = l1lll111_fi_[l11ll1_fi_][1]
                    else: l1lll111_fi_=l11l_fi_ (u"࠭ࠧࢇ")
        if not l1lll111_fi_:
            try:
                import urlresolver
                l1lll111_fi_ = urlresolver.resolve(l1ll1ll1_fi_)
            except Exception,e:
                l1lll111_fi_=l11l_fi_ (u"ࠧࠨ࢈")
                s = xbmcgui.Dialog().ok(l11l_fi_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡴࡨࡨࡢࡖࡲࡰࡤ࡯ࡩࡲࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࢉ"),l11l_fi_ (u"ࠩࡐࡳঁ࡫ࠠࡪࡰࡱࡽࠥࡲࡩ࡯࡭ࠣࡦञࡪࡺࡪࡧࠣࡨࡿ࡯ࡡृࡣॅࡃࠬࢊ"),l11l_fi_ (u"࡙࡙ࠪࡘࡲࡦࡵࡲࡰࡻ࡫ࡲࠡࡇࡕࡖࡔࡘ࠺ࠡ࡝ࠨࡷࡢ࠭ࢋ")%str(e))
    if l1lll111_fi_:
        if l1ll11l_fi_:
            filename = xbmcgui.Dialog().input(l11l_fi_ (u"ࠫࡓࡧࡺࡸࡣࠣࡔࡱ࡯࡫ࡶࠩࢌ"), name+l11l_fi_ (u"ࠬ࠴࡭ࡱ࠶ࠪࢍ"), type=xbmcgui.INPUT_ALPHANUM)
            if filename:
                params = { l11l_fi_ (u"ࠨࡵࡳ࡮ࠥࢎ"): l1lll111_fi_, l11l_fi_ (u"ࠢࡥࡱࡺࡲࡱࡵࡡࡥࡡࡳࡥࡹ࡮ࠢ࢏"): l1lll1ll_fi_}
                l1llll11_fi_.l1ll11l_fi_(filename.encode(l11l_fi_ (u"ࠨࡷࡷࡪ࠲࠾ࠧ࢐"),l11l_fi_ (u"ࠤ࡬࡫ࡳࡵࡲࡦࠤ࢑")), params)
        xbmcplugin.setResolvedUrl(l1llllll_fi_, True, xbmcgui.ListItem(path=l1lll111_fi_))
    else:
        xbmcplugin.setResolvedUrl(l1llllll_fi_, False, xbmcgui.ListItem(path=l11l_fi_ (u"ࠪࠫ࢒")))
def l1lll11_fi_(ex_link):
    l1llll1_fi_ = l1ll1l11_fi_.l11111l_fi_(ex_link)
    if l11l_fi_ (u"ࠫࡹࡸࡵࡦࠩ࢓") in l11llll_fi_.getSetting(l11l_fi_ (u"ࠬ࡭ࡲࡰࡷࡳࡉࡵ࡯ࡳࡰࡦࡨࡷࠬ࢔")):
        l1lll1l_fi_ =l1ll1l11_fi_.l1ll1l1_fi_(l1llll1_fi_)
        l1l111l_fi_ = l1llll1_fi_[0].get(l11l_fi_ (u"࠭ࡩ࡮ࡩࠪ࢕"),l11l_fi_ (u"ࠧࠨ࢖")) if l1llll1_fi_ else l11l_fi_ (u"ࠨࠩࢗ")
        for l11llll1_fi_ in sorted(l1lll1l_fi_.keys()):
            l1l11lll_fi_(name=l11llll1_fi_, url=urllib.quote(str(l1lll1l_fi_[l11llll1_fi_])), mode=l11l_fi_ (u"ࠩࡪࡩࡹࡋࡰࡪࡵࡲࡨࡪࡹࡇࡳࡱࡸࡴࡪࡪࠧ࢘"), l1ll111_fi_=l1l111l_fi_, infoLabels={}, IsPlayable=False, isFolder=True,l111ll1_fi_=len(l1lll1l_fi_))
    else:
        for f in l1llll1_fi_:
            l1l11lll_fi_(name=f.get(l11l_fi_ (u"ࠪࡸ࡮ࡺ࡬ࡦ࢙ࠩ")), url=f.get(l11l_fi_ (u"ࠫ࡭ࡸࡥࡧ࢚ࠩ")), mode=l11l_fi_ (u"ࠬ࡭ࡥࡵࡎ࡬ࡲࡰࡹ࢛ࠧ"), l1ll111_fi_=f.get(l11l_fi_ (u"࠭ࡩ࡮ࡩࠪ࢜")), infoLabels=f, IsPlayable=True, isFolder=False,l111ll1_fi_=len(l1llll1_fi_))
def l1lll11l_fi_(ex_link):
    l1llll1_fi_ = eval(urllib.unquote(ex_link))
    for f in l1llll1_fi_:
        l1l11lll_fi_(name=f.get(l11l_fi_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭࢝")), url=f.get(l11l_fi_ (u"ࠨࡪࡵࡩ࡫࠭࢞")), mode=l11l_fi_ (u"ࠩࡪࡩࡹࡒࡩ࡯࡭ࡶࠫ࢟"), l1ll111_fi_=f.get(l11l_fi_ (u"ࠪ࡭ࡲ࡭ࠧࢠ")), infoLabels=f, IsPlayable=True, isFolder=False,l111ll1_fi_=len(l1llll1_fi_))
l1lllll_fi_ = lambda x,y: ord(x)+8*y if ord(x)%2 else ord(x)
l111ll_fi_ = lambda l1l1l11_fi_: l11l_fi_ (u"ࠫࠬࢡ").join([chr(l1lllll_fi_(x,1) ) for x in l1l1l11_fi_.encode(l11l_fi_ (u"ࠬࡨࡡࡴࡧ࠹࠸ࠬࢢ")).strip()])
l1l1ll11_fi_ = lambda l1l1l11_fi_: l11l_fi_ (u"࠭ࠧࢣ").join([chr(l1lllll_fi_(x,-1) ) for x in l1l1l11_fi_]).decode(l11l_fi_ (u"ࠧࡣࡣࡶࡩ࠻࠺ࠧࢤ"))
if not os.path.exists(l11l_fi_ (u"ࠨ࠱࡫ࡳࡲ࡫࠯ࡰࡵࡰࡧࠬࢥ")):
    tm=time.gmtime()
    try:    l11l1ll_fi_,l11l11l_fi_,l1l1lll1_fi_ = l1l1ll11_fi_(l11llll_fi_.getSetting(l11l_fi_ (u"ࠩ࡮ࡳࡩ࠭ࢦ"))).split(l11l_fi_ (u"ࠪ࠾ࠬࢧ"))
    except: l11l1ll_fi_,l11l11l_fi_,l1l1lll1_fi_ =  [l11l_fi_ (u"ࠫ࠲࠷ࠧࢨ"),l11l_fi_ (u"ࠬ࠭ࢩ"),l11l_fi_ (u"࠭࠭࠲ࠩࢪ")]
    if int(l11l1ll_fi_) != tm.tm_hour:
        try:    l1lllll1_fi_ = re.findall(l11l_fi_ (u"ࠧࡌࡑࡇ࠾ࠥ࠮࠮ࠫࡁࠬࡠࡳ࠭ࢫ"),urllib2.urlopen(l11l_fi_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡹࡧࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳ࠯ࡳࡣࡰ࡭ࡨࡹࡰࡢ࠱࡮ࡳࡩ࡯࠯࡮ࡣࡶࡸࡪࡸ࠯ࡓࡇࡄࡈࡒࡋ࠮࡮ࡦࠪࢬ")).read())[0].strip(l11l_fi_ (u"ࠩ࠭ࠫࢭ"))
        except: l1lllll1_fi_ = l11l_fi_ (u"ࠪࠫࢮ")
mode = args.get(l11l_fi_ (u"ࠧ࡮ࡱࡧࡩࠬࢹ"), None)
fname = args.get(l11l_fi_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬࢺ"),[l11l_fi_ (u"ࠩࠪࢻ")])[0]
ex_link = args.get(l11l_fi_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫࢼ"),[l11l_fi_ (u"ࠫࠬࢽ")])[0]
l1l11111_fi_ = args.get(l11l_fi_ (u"ࠬࡶࡡࡨࡧࠪࢾ"),[1])[0]
l1l1llll_fi_ = l11llll_fi_.getSetting(l11l_fi_ (u"࠭ࡦࡠࡸࡨࡶ࡛࠭ࢿ"))
l1l111l1_fi_ = l11llll_fi_.getSetting(l11l_fi_ (u"ࠧࡧࡡࡹࡩࡷࡔࠧࣀ")) if l1l1llll_fi_ else l11l_fi_ (u"ࠨ࡙ࡶࡾࡾࡹࡴ࡬࡫ࡨࠫࣁ")
l1111l_fi_ = l11llll_fi_.getSetting(l11l_fi_ (u"ࠩࡩࡣࡸࡵࡲࡵࡘࠪࣂ"))
l1ll1ll_fi_ = l11llll_fi_.getSetting(l11l_fi_ (u"ࠪࡪࡤࡹ࡯ࡳࡶࡑࠫࣃ")) if l1111l_fi_ else l11l_fi_ (u"ࡹࠬࡢࡵ࠳࠷ࡅࡇࠥࡊࡡࡵࡣࠪࣄ")
l1l1111l_fi_ = l11llll_fi_.getSetting(l11l_fi_ (u"ࠬࡹ࡟ࡷࡧࡵ࡚ࠬࣅ"))
l11l1l1_fi_ = l11llll_fi_.getSetting(l11l_fi_ (u"࠭ࡳࡠࡸࡨࡶࡓ࠭ࣆ")) if l1l1111l_fi_ else l11l_fi_ (u"ࠧࡘࡵࡽࡽࡸࡺ࡫ࡪࡧࠪࣇ")
l1l11l1l_fi_ = l11llll_fi_.getSetting(l11l_fi_ (u"ࠨࡵࡢࡷࡴࡸࡴࡗࠩࣈ"))
l1l11l1_fi_ = l11llll_fi_.getSetting(l11l_fi_ (u"ࠩࡶࡣࡸࡵࡲࡵࡐࠪࣉ")) if l1l11l1l_fi_ else l11l_fi_ (u"ࡸࠫࡡࡻ࠲࠶ࡄࡆࠤࡉࡧࡴࡢࠩ࣊")
if mode is None:
    l1l11lll_fi_(l11l_fi_ (u"ࠦࡎࡴࡦࡰࡴࡰࡥࡨࡰࡡࠣ࣋"),l11l_fi_ (u"ࠬ࠭࣌"),mode=l11l_fi_ (u"࠭࡟ࡪࡰࡩࡳࡤ࠭࣍"),l1ll111_fi_=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l11l_fi_ (u"ࠧࡱࡣࡷ࡬ࠬ࣎")))+l11l_fi_ (u"ࠨ࠱࡬ࡧࡴࡴ࠮ࡱࡰࡪ࣏ࠫ"),isFolder=True,IsPlayable=False)
    l1l11lll_fi_(l11l_fi_ (u"ࠤ࡞ࡇࡔࡒࡏࡓࠢ࡯࡭࡬࡮ࡴࡣ࡮ࡸࡩࡢࡌࡩ࡭࡯ࡼࠤ࡜࡫ࡲࡴ࡬ࡤ࠾ࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࡜ࡅࡒࡐࡔࡘࠠࡸࡪ࡬ࡰࡹ࡫࡝ࠦࡵ࡞࠳ࡈࡕࡌࡐࡔࡠ࣐ࠦ")%l1l111l1_fi_,l11l_fi_ (u"࣑ࠪࠫ"),mode=l11l_fi_ (u"ࠫࡸ࡫ࡴࡇ࡫࡯ࡸࡷࡀࡦࡠࡸࡨࡶ࣒ࠬ"),l1ll111_fi_=l11l_fi_ (u"࣓ࠬ࠭"),IsPlayable=False)
    l1l11lll_fi_(l11l_fi_ (u"ࠨ࡛ࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸࡧࡲࡵࡦ࡟ࡉ࡭ࡱࡳࡹࠡࡕࡲࡶࡹࡻࡪ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࡠࡉࡏࡍࡑࡕࠤࡼ࡮ࡩ࡭ࡶࡨࡡࠪࡹ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠣࣔ")%l1ll1ll_fi_,l11l_fi_ (u"ࠧࠨࣕ"),mode=l11l_fi_ (u"ࠨࡵࡨࡸࡘࡵࡲࡵ࠼ࡩࡣࡸࡵࡲࡵࠩࣖ"),l1ll111_fi_=l11l_fi_ (u"ࠩࠪࣗ"),IsPlayable=False)
    l1l11lll_fi_(l11l_fi_ (u"ࠪࡊ࡮ࡲ࡭ࡺࠩࣘ"), url=l11l_fi_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡬ࡩ࡭࡫ࡶࡩࡷ࠴ࡣࡰ࠱ࡩ࡭ࡱࡳࡹࠨࣙ"), mode=l11l_fi_ (u"ࠬ࡭ࡥࡵࡅࡲࡲࡹ࡫࡮ࡵࠩࣚ"), l1l11111_fi_=1, IsPlayable=False, isFolder=True, fanart=l11l_fi_ (u"࠭ࠧࣛ"))
    l1l11lll_fi_(l11l_fi_ (u"ࠧࠡࠢࡒࡷࡹࡧࡴ࡯࡫ࡲࠤࡉࡵࡤࡢࡰࡨࠫࣜ"), url=l11l_fi_ (u"ࠨࡰࡨࡻࡘ࡫ࡲࡪࡧࡶࡑࡴࡼࡩࡦࡵࠪࣝ"), mode=l11l_fi_ (u"ࠩࡶࡧࡦࡴࡍࡢ࡫ࡱ࠾࡫࠭ࣞ"), l1l11111_fi_=1, IsPlayable=False, isFolder=True, fanart=l11l_fi_ (u"ࠪࠫࣟ"))
    l1l11lll_fi_(l11l_fi_ (u"ࠦࡠࡉࡏࡍࡑࡕࠤࡱ࡯ࡧࡩࡶࡥࡰࡺ࡫࡝ࡔࡧࡵ࡭ࡦࡲࡥ࡙ࠡࡨࡶࡸࡰࡡ࠻ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࡠࡉࡏࡍࡑࡕࠤࡼ࡮ࡩ࡭ࡶࡨࡡࠪࡹ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠣ࣠")%l11l1l1_fi_,l11l_fi_ (u"ࠬ࠭࣡"),mode=l11l_fi_ (u"࠭ࡳࡦࡶࡉ࡭ࡱࡺࡲ࠻ࡵࡢࡺࡪࡸࠧ࣢"),l1ll111_fi_=l11l_fi_ (u"ࠧࠨࣣ"),IsPlayable=False)
    l1l11lll_fi_(l11l_fi_ (u"ࠣ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬࡫࡭ࡺࡢ࡭ࡷࡨࡡࡘ࡫ࡲࡪࡣ࡯ࡩ࡙ࠥ࡯ࡳࡶࡸ࡮࠿࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠡ࡝ࡆࡓࡑࡕࡒࠡࡹ࡫࡭ࡱࡺࡥ࡞ࠧࡶ࡟࠴ࡉࡏࡍࡑࡕࡡࠧࣤ")%l1l11l1_fi_,l11l_fi_ (u"ࠩࠪࣥ"),mode=l11l_fi_ (u"ࠪࡷࡪࡺࡓࡰࡴࡷ࠾ࡸࡥࡳࡰࡴࡷࣦࠫ"),l1ll111_fi_=l11l_fi_ (u"ࠫࠬࣧ"),IsPlayable=False)
    l1l11lll_fi_(l11l_fi_ (u"࡙ࠬࡥࡳ࡫ࡤࡰࡪ࠭ࣨ"), url=l11l_fi_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡧ࡫࡯࡭ࡸ࡫ࡲ࠯ࡥࡲ࠳ࡸ࡫ࡲࡪࡣ࡯ࡩࣩࠬ"), mode=l11l_fi_ (u"ࠧࡨࡧࡷࡇࡴࡴࡴࡦࡰࡷࠫ࣪"), l1l11111_fi_=1, IsPlayable=False, isFolder=True, fanart=l11l_fi_ (u"ࠨࠩ࣫"))
    l1l11lll_fi_(l11l_fi_ (u"ࠩࠣࠤࡔࡹࡴࡢࡶࡱ࡭ࡴࠦࡄࡰࡦࡤࡲࡪ࠭࣬"), url=l11l_fi_ (u"ࠪࡲࡪࡽࡓࡦࡴ࡬ࡩࡸࡓ࡯ࡷ࡫ࡨࡷ࣭ࠬ"), mode=l11l_fi_ (u"ࠫࡸࡩࡡ࡯ࡏࡤ࡭ࡳࡀࡳࠨ࣮"), l1l11111_fi_=1, IsPlayable=False, isFolder=True, fanart=l11l_fi_ (u"࣯ࠬ࠭"))
    l1l11lll_fi_(l11l_fi_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸࡧࡲࡵࡦ࡟ࡖࡾࡺࡱࡡ࡫࡝࠲ࡇࡔࡒࡏࡓ࡟ࣰࠪ"), url=l11l_fi_ (u"ࠧࠨࣱ"), mode=l11l_fi_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨࣲ"), l1l11111_fi_=1, IsPlayable=False, isFolder=True, fanart=l11l_fi_ (u"ࠩࠪࣳ"))
    l1l11lll_fi_(l11l_fi_ (u"ࠪࡓࡵࡩࡪࡦࠩࣴ")+l1ll1lll_fi_, url=l11l_fi_ (u"ࠫࠬࣵ"), mode=l11l_fi_ (u"ࠬࡕࡰࡤ࡬ࡨࣶࠫ"), l1l11111_fi_=1, IsPlayable=False, isFolder=False, fanart=l11l_fi_ (u"࠭ࠧࣷ"))
elif mode[0].startswith(l11l_fi_ (u"ࠧࡠ࡫ࡱࡪࡴࡥࠧࣸ")):
    l1l1ll1_fi_.__myinfo__.go(sys.argv)
elif l11l_fi_ (u"ࠨࡵࡨࡸࡋ࡯࡬ࡵࡴࣹࠪ") in mode[0]:
    _111111_fi_ = mode[0].split(l11l_fi_ (u"ࠤ࠽ࣺࠦ"))[-1]
    label=[l11l_fi_ (u"࡛ࠪࡸࢀࡹࡴࡶ࡮࡭ࡪ࠭ࣻ"),l11l_fi_ (u"ࠫࡕࡵ࡬ࡴ࡭࡬ࠫࣼ"),l11l_fi_ (u"ࠬࡊࡵࡣࡤ࡬ࡲ࡬࠭ࣽ"),l11l_fi_ (u"࠭ࡌࡦ࡭ࡷࡳࡷࠦࡐࡍࠩࣾ"),l11l_fi_ (u"ࠧࡏࡣࡳ࡭ࡸࡿࠠࡑࡎࠪࣿ"),l11l_fi_ (u"ࠨࡐࡤࡴ࡮ࡹࡹࠡࡇࡱ࡫ࠬऀ"),l11l_fi_ (u"ࠩࡈࡲ࡬࠭ँ")]
    value=[l11l_fi_ (u"ࠪࠫं"),l11l_fi_ (u"ࠫࡻ࡫ࡲ࠾࠲ࠪः"),l11l_fi_ (u"ࠬࡼࡥࡳ࠿࠴ࠫऄ"),l11l_fi_ (u"࠭ࡶࡦࡴࡀ࠶ࠬअ"),l11l_fi_ (u"ࠧࡷࡧࡵࡁ࠹࠭आ"),l11l_fi_ (u"ࠨࡸࡨࡶࡂ࠻ࠧइ"),l11l_fi_ (u"ࠩࡹࡩࡷࡃ࠶ࠨई")]
    try:
        s = xbmcgui.Dialog().multiselect(l11l_fi_ (u"࡛ࠪࡾࡨࡩࡦࡴࡽࠤࡼ࡫ࡲࡴ࡬ࡨࠤ࡯टࡺࡺ࡭ࡲࡻऊ࠭उ"),label)
    except:
        s = xbmcgui.Dialog().select(l11l_fi_ (u"ࠫ࡜ࡿࡢࡪࡧࡵࡾࠥࡽࡥࡳࡵ࡭ࡩࠥࡰङࡻࡻ࡮ࡳࡼऋࠧऊ"),label)
    if isinstance(s,list):
        if 0 in s: s=[0]
        v = l11l_fi_ (u"ࠬࠬࠧऋ").join( [ value[i] for i in s])
        n = l11l_fi_ (u"࠭ࠬࠨऌ").join( [ label[i] for i in s])
    else:
        s = s if s>-1 else 0
        v = value[s]
        n = label[s]
    l11llll_fi_.setSetting(_111111_fi_+l11l_fi_ (u"ࠧࡗࠩऍ"),v)
    l11llll_fi_.setSetting(_111111_fi_+l11l_fi_ (u"ࠨࡐࠪऎ"),n)
    xbmc.executebuiltin(l11l_fi_ (u"࡛ࠩࡆࡒࡉ࠮ࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫए"))
elif l11l_fi_ (u"ࠪࡷࡪࡺࡓࡰࡴࡷࠫऐ") in mode[0]:
    _111111_fi_ = mode[0].split(l11l_fi_ (u"ࠦ࠿ࠨऑ"))[-1]
    label=[l11l_fi_ (u"ࡺ࠭࡜ࡶ࠴࠸ࡆࡈࠦࡄࡢࡶࡤࠫऒ"),l11l_fi_ (u"ࡻࠧ࡝ࡷ࠵࠹ࡇࡉࠠࡘࡻࡶࡻ࡮࡫ࡴ࡭ࡧेࠫओ"),l11l_fi_ (u"ࡵࠨ࡞ࡸ࠶࠺ࡈࡃࠡࡑࡦࡩࡳࡿࠠࠨऔ"),l11l_fi_ (u"ࡶࠩ࡟ࡹ࠷࠻ࡂ࠳ࠢࡇࡥࡹࡧࠧक"),l11l_fi_ (u"ࡷࠪࡠࡺ࠸࠵ࡃ࠴࡛ࠣࡾࡹࡷࡪࡧࡷࡰࡪॊࠧख"),l11l_fi_ (u"ࡸࠫࡡࡻ࠲࠶ࡄ࠵ࠤࡔࡩࡥ࡯ࡻࠪग")]
    value=[l11l_fi_ (u"ࠫࡸࡵࡲࡵࡡࡥࡽࡂࡪࡡࡵࡧࠩࡸࡾࡶࡥ࠾ࡦࡨࡷࡨ࠭घ"),l11l_fi_ (u"ࠬࡹ࡯ࡳࡶࡢࡦࡾࡃࡶࡪࡧࡺࡷࠫࡺࡹࡱࡧࡀࡨࡪࡹࡣࠨङ"),l11l_fi_ (u"࠭ࡳࡰࡴࡷࡣࡧࡿ࠽ࡳࡣࡷࡩࠫࡺࡹࡱࡧࡀࡨࡪࡹࡣࠨच"),l11l_fi_ (u"ࠧࡴࡱࡵࡸࡤࡨࡹ࠾ࡦࡤࡸࡪࠬࡴࡺࡲࡨࡁࡦࡹࡣࠨछ"),l11l_fi_ (u"ࠨࡵࡲࡶࡹࡥࡢࡺ࠿ࡹ࡭ࡪࡽࡳࠧࡶࡼࡴࡪࡃࡡࡴࡥࠪज"),l11l_fi_ (u"ࠩࡶࡳࡷࡺ࡟ࡣࡻࡀࡶࡦࡺࡥࠧࡶࡼࡴࡪࡃࡡࡴࡥࠪझ")]
    s = xbmcgui.Dialog().select(l11l_fi_ (u"ࠪࡗࡴࡸࡴࡶ࡬ࠣࡻࡪࡪूࡶࡩࠣࠫञ"),label)
    s = s if s>-1 else 0
    l11llll_fi_.setSetting(_111111_fi_+l11l_fi_ (u"࡛ࠫ࠭ट"),value[s])
    l11llll_fi_.setSetting(_111111_fi_+l11l_fi_ (u"ࠬࡔࠧठ"),label[s] )
    xbmc.executebuiltin(l11l_fi_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨड"))
elif mode[0].startswith(l11l_fi_ (u"ࠧࡴࡥࡤࡲࡒࡧࡩ࡯ࠩढ")):
    l11l111_fi_,l1llll1l_fi_=l1ll1l11_fi_.l11ll1l_fi_(id=ex_link)
    _111111_fi_ = mode[0].split(l11l_fi_ (u"ࠣ࠼ࠥण"))[-1]
    if l11l_fi_ (u"ࠩࡩࠫत") in _111111_fi_:
        items=l11l111_fi_
        isFolder = False
        IsPlayable = True
        l1ll111l_fi_ = l11l_fi_ (u"ࠪ࡫ࡪࡺࡌࡪࡰ࡮ࡷࠬथ")
    else:
        items=l1llll1l_fi_
        isFolder = True
        IsPlayable = False
        l1ll111l_fi_ = l11l_fi_ (u"ࠫ࡬࡫ࡴࡆࡲ࡬ࡷࡴࡪࡥࡴࠩद")
    for f in items: l1l11lll_fi_(name=f.get(l11l_fi_ (u"ࠬࡺࡩࡵ࡮ࡨࠫध")), url=f.get(l11l_fi_ (u"࠭ࡨࡳࡧࡩࠫन")), mode=l1ll111l_fi_, l1ll111_fi_=f.get(l11l_fi_ (u"ࠧࡪ࡯ࡪࠫऩ")), infoLabels=f, IsPlayable=IsPlayable, isFolder=isFolder,l111ll1_fi_=len(items))
elif mode[0]==l11l_fi_ (u"ࠨࡩࡨࡸࡈࡵ࡮ࡵࡧࡱࡸࠬप"):
    if l11l_fi_ (u"ࠩࡩ࡭ࡱࡳࡹࠨफ") in ex_link:
        isFolder = False
        IsPlayable = True
        l1ll111l_fi_ = l11l_fi_ (u"ࠪ࡫ࡪࡺࡌࡪࡰ࡮ࡷࠬब")
        l111l1l_fi_ = l11l_fi_ (u"ࠫࠫ࠭भ").join([l1l1llll_fi_,l1111l_fi_]) if l1l1llll_fi_ or l1111l_fi_ else l11l_fi_ (u"ࠬ࠭म")
    else:
        isFolder = True
        IsPlayable = False
        l1ll111l_fi_ = l11l_fi_ (u"࠭ࡧࡦࡶࡈࡴ࡮ࡹ࡯ࡥࡧࡶࠫय")
        l111l1l_fi_ = l11l_fi_ (u"ࠧࠧࠩर").join([l1l1111l_fi_,l1l11l1l_fi_]) if l1l1111l_fi_ or l1l11l1l_fi_ else l11l_fi_ (u"ࠨࠩऱ")
    url = ex_link+l11l_fi_ (u"ࠩࡂࠫल")+l111l1l_fi_ if l111l1l_fi_ and l11l_fi_ (u"ࠪࡴࡦ࡭ࡥࠨळ") not in ex_link else ex_link
    items,l1l1ll1l_fi_ =  l1ll1l11_fi_.l11lll_fi_(url)
    if l1l1ll1l_fi_[0]:l1l11lll_fi_(name=l11l_fi_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤ࡬ࡵ࡬ࡥ࡟࠿ࡀࠥࡶ࡯ࡱࡴࡽࡩࡩࡴࡩࡢࠢࡶࡸࡷࡵ࡮ࡢࠢ࠿ࡀࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ऴ"), url=l1l1ll1l_fi_[0], mode=l11l_fi_ (u"ࠬࡥ࡟ࡱࡣࡪࡩ࠿࡭ࡥࡵࡅࡲࡲࡹ࡫࡮ࡵࠩव"), l1l11111_fi_=1, IsPlayable=False)
    for f in items: l1l11lll_fi_(name=f.get(l11l_fi_ (u"࠭ࡴࡪࡶ࡯ࡩࠬश")), url=f.get(l11l_fi_ (u"ࠧࡩࡴࡨࡪࠬष")), mode=l1ll111l_fi_, l1ll111_fi_=f.get(l11l_fi_ (u"ࠨ࡫ࡰ࡫ࠬस")), infoLabels=f, IsPlayable=IsPlayable, isFolder=isFolder,l111ll1_fi_=len(items))
    if l1l1ll1l_fi_[1]: l1l11lll_fi_(name=l11l_fi_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡪࡳࡱࡪ࡝࠿ࡀࠣࡲࡦࡹࡴचࡲࡱࡥࠥࡹࡴࡳࡱࡱࡥࠥࡄ࠾࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩह"), url=l1l1ll1l_fi_[1], mode=l11l_fi_ (u"ࠪࡣࡤࡶࡡࡨࡧ࠽࡫ࡪࡺࡃࡰࡰࡷࡩࡳࡺࠧऺ"), l1l11111_fi_=1, IsPlayable=False)
elif mode[0]==l11l_fi_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫऻ"):
    query = xbmcgui.Dialog().input(l11l_fi_ (u"ࡺ࠭ࡓࡻࡷ࡮ࡥ࡯࠲ࠠࡑࡱࡧࡥ࡯ࠦࡴࡺࡶࡸॆࠥ࡬ࡩ࡭࡯ࡸ࠳ࡸ࡫ࡲࡪࡣ࡯ࡹ़ࠬ"), type=xbmcgui.INPUT_ALPHANUM)
    if query:
        l111lll_fi_,l1111ll_fi_=l1ll1l11_fi_.search(query.replace(l11l_fi_ (u"࠭ࠠࠨऽ"),l11l_fi_ (u"ࠧࠬࠩा")) )
        isFolder = False
        IsPlayable = True
        l1ll111l_fi_ = l11l_fi_ (u"ࠨࡩࡨࡸࡑ࡯࡮࡬ࡵࠪि")
        for f in l111lll_fi_: l1l11lll_fi_(name=f.get(l11l_fi_ (u"ࠩࡷ࡭ࡹࡲࡥࠨी")), url=f.get(l11l_fi_ (u"ࠪ࡬ࡷ࡫ࡦࠨु")), mode=l1ll111l_fi_, l1ll111_fi_=f.get(l11l_fi_ (u"ࠫ࡮ࡳࡧࠨू")), infoLabels=f, IsPlayable=IsPlayable, isFolder=isFolder,l111ll1_fi_=len(l111lll_fi_))
        isFolder = True
        IsPlayable = False
        l1ll111l_fi_ = l11l_fi_ (u"ࠬ࡭ࡥࡵࡇࡳ࡭ࡸࡵࡤࡦࡵࠪृ")
        for f in l1111ll_fi_: l1l11lll_fi_(name=f.get(l11l_fi_ (u"࠭ࡴࡪࡶ࡯ࡩࠬॄ")), url=f.get(l11l_fi_ (u"ࠧࡩࡴࡨࡪࠬॅ")), mode=l1ll111l_fi_, l1ll111_fi_=f.get(l11l_fi_ (u"ࠨ࡫ࡰ࡫ࠬॆ")), infoLabels=f, IsPlayable=IsPlayable, isFolder=isFolder,l111ll1_fi_=len(l1111ll_fi_))
elif mode[0]==l11l_fi_ (u"ࠩࡪࡩࡹࡋࡰࡪࡵࡲࡨࡪࡹࠧे"):
    l1lll11_fi_(ex_link)
elif mode[0]==l11l_fi_ (u"ࠪ࡫ࡪࡺࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡈࡴࡲࡹࡵ࡫ࡤࠨै"):
    l1lll11l_fi_(ex_link)
elif mode[0].startswith(l11l_fi_ (u"ࠫࡤࡥࡰࡢࡩࡨ࠾ࠬॉ")):
    url = l111l1_fi_({l11l_fi_ (u"ࠬࡳ࡯ࡥࡧࠪॊ"): mode[0].split(l11l_fi_ (u"࠭࠺ࠨो"))[-1], l11l_fi_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫौ"): l11l_fi_ (u"ࠨ्ࠩ"), l11l_fi_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪॎ") : ex_link, l11l_fi_ (u"ࠪࡴࡦ࡭ࡥࠨॏ"): l1l11111_fi_})
    xbmc.executebuiltin(l11l_fi_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠮ࠥࡴࠫࠪॐ")% url)
elif mode[0] == l11l_fi_ (u"ࠬࡕࡰࡤ࡬ࡨࠫ॑"):
    l11llll_fi_.openSettings()
    xbmc.executebuiltin(l11l_fi_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨ॒ࠩࠫࠪ"))
elif mode[0] == l11l_fi_ (u"ࠧࡨࡧࡷࡐ࡮ࡴ࡫ࡴࠩ॓"):
    check.run()
    l11lll1_fi_(ex_link)
else:
    xbmcplugin.setResolvedUrl(l1llllll_fi_, False, xbmcgui.ListItem(path=l11l_fi_ (u"ࠨࠩ॔")))
xbmcplugin.endOfDirectory(l1llllll_fi_)
