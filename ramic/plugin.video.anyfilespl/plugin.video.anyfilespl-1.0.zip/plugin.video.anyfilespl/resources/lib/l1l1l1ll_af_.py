# -*- coding: utf-8 -*-
import sys
l1ll_af_ = sys.version_info [0] == 2
l111l_af_ = 2048
l111_af_ = 7
def l1lll_af_ (ll_af_):
	global l1ll11_af_
	l1l11l_af_ = ord (ll_af_ [-1])
	l11l1_af_ = ll_af_ [:-1]
	l1l_af_ = l1l11l_af_ % len (l11l1_af_)
	l11_af_ = l11l1_af_ [:l1l_af_] + l11l1_af_ [l1l_af_:]
	if l1ll_af_:
		l1lll1_af_ = unicode () .join ([unichr (ord (char) - l111l_af_ - (l11ll_af_ + l1l11l_af_) % l111_af_) for l11ll_af_, char in enumerate (l11_af_)])
	else:
		l1lll1_af_ = str () .join ([chr (ord (char) - l111l_af_ - (l11ll_af_ + l1l11l_af_) % l111_af_) for l11ll_af_, char in enumerate (l11_af_)])
	return eval (l1lll1_af_)
l1lll_af_ (u"ࠣࠤࠥࠑࠏࡉࡲࡦࡣࡷࡩࡩࠦ࡯࡯ࠢࡗ࡬ࡺࠦࡆࡦࡤࠣ࠵࠶ࠦ࠱࠹࠼࠷࠻࠿࠺࠳ࠡ࠴࠳࠵࠻ࠓࠊࠎࠌࡃࡥࡺࡺࡨࡰࡴ࠽ࠤࡷࡧ࡭ࡪࡥࠐࠎࠧࠨࠢએ")
import urllib2
import re
import l1111111l_af_ as l1111111l_af_
l1111ll11_af_=l1lll_af_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡣࡥࡣ࠱ࡴࡱ࠭ઐ")
l11l11ll1_af_ = 5
def l111lll11_af_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l1lll_af_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧઑ"), l1lll_af_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡐ࡙࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠸࠽࠴࠰࠯࠴࠸࠺࠹࠴࠹࠸ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩ઒"))
    if cookies:
        req.add_header(l1lll_af_ (u"ࠧࡉ࡯ࡰ࡭࡬ࡩࠧઓ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11l11ll1_af_)
        l1l11111_af_ =  response.read()
        response.close()
    except:
        l1l11111_af_=l1lll_af_ (u"࠭ࠧઔ")
    return l1l11111_af_
def _111111ll_af_(content):
    src =l1lll_af_ (u"ࠧࠨક")
    l1lllll1l1_af_ = re.compile(l1lll_af_ (u"ࠣࡧࡹࡥࡱ࠮࠮ࠫࡁࠬࡠࢀࡢࡽ࡝ࠫ࡟࠭ࠧખ"),re.DOTALL).findall(content)
    for l1lllll11l_af_ in l1lllll1l1_af_:
        l1lllll11l_af_=re.sub(l1lll_af_ (u"ࠩࠣࠤࠬગ"),l1lll_af_ (u"ࠪࠤࠬઘ"),l1lllll11l_af_)
        l1lllll11l_af_=re.sub(l1lll_af_ (u"ࠫࡡࡴࠧઙ"),l1lll_af_ (u"ࠬ࠭ચ"),l1lllll11l_af_)
        try:
            l1llllllll_af_ = l1111111l_af_.unpack(l1lllll11l_af_)
        except:
            l1llllllll_af_=l1lll_af_ (u"࠭ࠧછ")
        if l1llllllll_af_:
            l1llllllll_af_=re.sub(l1lll_af_ (u"ࡲࠨ࡞࡟ࠫજ"),l1lll_af_ (u"ࡳࠩࠪઝ"),l1llllllll_af_)
            l1lllll1ll_af_ = re.compile(l1lll_af_ (u"ࠩ࡞ࠦࡡ࠭࡝ࠫࡨ࡬ࡰࡪࡡࠢ࡝ࠩࡠ࠮ࡡࡹࠪ࠻࡞ࡶ࠮ࡠࠨ࡜ࠨ࡟ࠫ࠲࠰ࡅࠩ࡜ࠤ࡟ࠫࡢ࠲ࠧઞ"),  re.DOTALL).search(content)
            l1lllllll1_af_ = re.compile(l1lll_af_ (u"ࠪ࡟ࠧࡢࠧ࡞ࡨ࡬ࡰࡪࡡࠢ࡝ࠩࡠ࠾ࡠࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅ࡜࠯࡯ࡳ࠸࠮ࡡࠢ࡝ࠩࡠࠫટ"),  re.DOTALL).search(content)
            l1llllll1l_af_ = re.compile(l1lll_af_ (u"ࠫࡠࠨ࡜ࠨ࡟࠭ࠬ࠳࠰࠿࡝࠰ࡰࡴ࠹࠯࡛ࠣ࡞ࠪࡡ࠯࠭ઠ"),  re.DOTALL).search(content)
            if l1lllll1ll_af_:   src = l1lllll1ll_af_.group(1)
            elif l1lllllll1_af_: src = l1lllllll1_af_.group(1)
            elif l1llllll1l_af_: src = l1llllll1l_af_.group(1)
            if src:
                break
    return src
def l111111l1_af_(content):
    l1lll_af_ (u"ࠧࠨࠢࠎࠌࠣࠤࠥࠦࡓࡤࡣࡱࡷࠥ࡬࡯ࡳࠢࡹ࡭ࡩ࡫࡯ࠡ࡮࡬ࡲࡰࠦࡩ࡯ࡥ࡯ࡹࡩ࡫ࡤࠡࡧࡱࡧࡴࡪࡥࡥࠢࡲࡲࡪࠓࠊࠡࠢࠣࠤࠧࠨࠢડ")
    l1lllll111_af_=l1lll_af_ (u"࠭ࠧઢ")
    l1lllll1ll_af_ = re.compile(l1lll_af_ (u"ࠧ࡜ࠤ࡟ࠫࡢ࠰ࡦࡪ࡮ࡨ࡟ࠧࡢࠧ࡞ࠬ࡟ࡷ࠯ࡀ࡜ࡴࠬ࡞ࠦࡡ࠭࡝ࠩ࠰࠮ࡃ࠮ࡡࠢ࡝ࠩࡠ࠰ࠬણ"),  re.DOTALL).search(content)
    l1lllllll1_af_ = re.compile(l1lll_af_ (u"ࠨ࡝ࠥࡠࠬࡣࡦࡪ࡮ࡨ࡟ࠧࡢࠧ࡞࠼࡞ࠦࡡ࠭࡝ࠩ࠰࠭ࡃࡡ࠴࡭ࡱ࠶ࠬ࡟ࠧࡢࠧ࡞ࠩત"),  re.DOTALL).search(content)
    l1llllll1l_af_ = re.compile(l1lll_af_ (u"ࠩ࡞ࠦࡡ࠭࡝ࠫࠪ࠱࠮ࡄࡢ࠮࡮ࡲ࠷࠭ࡠࠨ࡜ࠨ࡟࠭ࠫથ"),  re.DOTALL).search(content)
    if l1lllll1ll_af_:
        print l1lll_af_ (u"ࠪࡪࡴࡻ࡮ࡥࠢࡕࡉࠥࡡࡦࡪ࡮ࡨ࠾ࡢ࠭દ")
        l1lllll111_af_ = l1lllll1ll_af_.group(1)
    elif l1lllllll1_af_:
        print l1lll_af_ (u"ࠫ࡫ࡵࡵ࡯ࡦࠣࡖࡊ࡛ࠦࡶࡴ࡯࠾ࡢ࠭ધ")
        l1lllll111_af_ = l1lllllll1_af_.group(1)
    elif l1llllll1l_af_:
        print l1lll_af_ (u"ࠬ࡬࡯ࡶࡰࡧࠤࡗࡋࠠ࡜ࡷࡵࡰ࠿ࡣࠧન")
        l1lllll111_af_ = l1llllll1l_af_.group(1)
    else:
        print l1lll_af_ (u"࠭ࡥ࡯ࡥࡲࡨࡪࡪࠠ࠻ࠢࡸࡲࡵࡧࡣ࡬ࡧࡵࠫ઩")
        l1lllll111_af_ = _111111ll_af_(content)
    return l1lllll111_af_
def l1llll1l1l_af_(url):
    l1lll_af_ (u"ࠢࠣࠤࠐࠎࠥࠦࠠࠡࡴࡨࡸࡺࡸ࡮ࡴࠢࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥ࠳ࠠࡶ࡮ࡵࠤ࡭ࡺࡴࡱ࠼࠲࠳࠳࠴࠮࠯ࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠲ࠦ࡯ࡳࠢ࡯࡭ࡸࡺࠠࡰࡨࠣ࡟࠭࠭࠷࠳࠲ࡳࠫ࠱ࠦࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡨࡪࡡ࠯ࡲ࡯࠳ࡻ࡯ࡤࡦࡱ࠲࠵࠾࠺࠶࠺࠻࠴ࡪࡄࡽࡥࡳࡵ࡭ࡥࡂ࠽࠲࠱ࡲࠪ࠭࠱࠴࠮࠯࡟ࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠍࠋࠢࠣࠤࠥࠨࠢࠣપ")
    l1llllll11_af_=l1lll_af_ (u"ࠨࡾࡆࡳࡴࡱࡩࡦ࠿ࡓࡌࡕ࡙ࡅࡔࡕࡌࡈࡂ࠷ࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࡪࡷࡸࡵࡀ࠯࠰ࡵࡷࡥࡹ࡯ࡣ࠯ࡥࡧࡥ࠳ࡶ࡬࠰ࡨ࡯ࡳࡼࡶ࡬ࡢࡻࡨࡶ࠴࡬࡬ࡢࡵ࡫࠳࡫ࡲ࡯ࡸࡲ࡯ࡥࡾ࡫ࡲ࠯ࡥࡲࡱࡲ࡫ࡲࡤ࡫ࡤࡰ࠲࠹࠮࠳࠰࠴࠼࠳ࡹࡷࡧࠩફ")
    content = l111lll11_af_(url)
    src=[]
    if not l1lll_af_ (u"ࠩࡂࡻࡪࡸࡳ࡫ࡣࠪબ") in url:
         l1llll1lll_af_ = re.compile(l1lll_af_ (u"ࠪࡀࡦࠦࡤࡢࡶࡤ࠱ࡶࡻࡡ࡭࡫ࡷࡽࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࠨࡀࡒ࠿ࡌࡃ࠴ࠪࡀࠫࡁࠬࡄࡖ࠼ࡒࡀ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫભ"), re.DOTALL).findall(content)
         for quality in l1llll1lll_af_:
             l1l11111_af_ = re.search(l1lll_af_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪમ"),quality[1])
             l1llll1ll1_af_ = quality[2]
             src.insert(0,(l1llll1ll1_af_,l1111ll11_af_+l1l11111_af_.group(1)))
    if not src:
        src = l111111l1_af_(content)
        if src:
            src+=l1llllll11_af_
    return src
def l11111111_af_(url,quality=0):
    l1lll_af_ (u"ࠧࠨࠢࠎࠌࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࡹࠠࡶࡴ࡯ࠤࡹࡵࠠࡷ࡫ࡧࡩࡴࠓࠊࠡࠢࠣࠤࠧࠨࠢય")
    src = l1llll1l1l_af_(url)
    if type(src)==list:
        selected=src[quality]
        print l1lll_af_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࠠ࠻ࠩર"),selected[0]
        src = l1llll1l1l_af_(selected[1])
    return src
