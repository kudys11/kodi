# coding: UTF-8
import sys
l1ll_af_ = sys.version_info [0] == 2
l111l_af_ = 2048
l111_af_ = 7
def l1lll_af_ (ll_af_):
	global l1ll11_af_
	l1l11l_af_ = ord (ll_af_ [-1])
	l11l1_af_ = ll_af_ [:-1]
	l1l_af_ = l1l11l_af_ % len (l11l1_af_)
	l11_af_ = l11l1_af_ [:l1l_af_] + l11l1_af_ [l1l_af_:]
	if l1ll_af_:
		l1lll1_af_ = unicode () .join ([unichr (ord (char) - l111l_af_ - (l11ll_af_ + l1l11l_af_) % l111_af_) for l11ll_af_, char in enumerate (l11_af_)])
	else:
		l1lll1_af_ = str () .join ([chr (ord (char) - l111l_af_ - (l11ll_af_ + l1l11l_af_) % l111_af_) for l11ll_af_, char in enumerate (l11_af_)])
	return eval (l1lll1_af_)