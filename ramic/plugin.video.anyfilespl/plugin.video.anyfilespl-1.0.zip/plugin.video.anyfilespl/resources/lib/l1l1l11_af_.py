# -*- coding: utf-8 -*-
import sys
l1ll_af_ = sys.version_info [0] == 2
l111l_af_ = 2048
l111_af_ = 7
def l1lll_af_ (ll_af_):
	global l1ll11_af_
	l1l11l_af_ = ord (ll_af_ [-1])
	l11l1_af_ = ll_af_ [:-1]
	l1l_af_ = l1l11l_af_ % len (l11l1_af_)
	l11_af_ = l11l1_af_ [:l1l_af_] + l11l1_af_ [l1l_af_:]
	if l1ll_af_:
		l1lll1_af_ = unicode () .join ([unichr (ord (char) - l111l_af_ - (l11ll_af_ + l1l11l_af_) % l111_af_) for l11ll_af_, char in enumerate (l11_af_)])
	else:
		l1lll1_af_ = str () .join ([chr (ord (char) - l111l_af_ - (l11ll_af_ + l1l11l_af_) % l111_af_) for l11ll_af_, char in enumerate (l11_af_)])
	return eval (l1lll1_af_)
import sys,re,os
import urllib2
import urlparse
l1111ll11_af_=l1lll_af_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡧ࡫࡯࡭ࡸ࡫ࡲ࠯ࡶࡹ࠳ࠬ઱")
l11l11ll1_af_ = 15
l11111l1l_af_=l1lll_af_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠵࠺࠱࠴࠳࠸࠵࠷࠶࠱࠽࠼ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭લ")
def l111lll11_af_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l1lll_af_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ળ"), l11111l1l_af_)
    req.add_header(l1lll_af_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ઴"), l1111ll11_af_)
    l111l1l11_af_=l1lll_af_ (u"ࠫࠬવ")
    if cookies:
        req.add_header(l1lll_af_ (u"ࠧࡉ࡯ࡰ࡭࡬ࡩࠧશ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11l11ll1_af_)
        l1l11111_af_ = response.read()
    except:
        l1l11111_af_=l1lll_af_ (u"࠭ࠧષ")
    return l1l11111_af_
def l1lll1l1ll_af_(id=l1lll_af_ (u"ࠢࡱࡴࡨࡱ࡮࡫ࡲࡦࡏࡲࡺ࡮࡫ࡳࠣસ")):
    content = l111lll11_af_(l1111ll11_af_)
    ids = [(a.start(), a.end()) for a in re.finditer(l1lll_af_ (u"ࠨ࠾ࡶࡩࡨࡺࡩࡰࡰࠣ࡭ࡩࡃࠢࠨહ"), content)]
    ids.append( (-1,-1) )
    l1llll11l1_af_=[]
    l1lll11l1l_af_=[]
    for i in range(len(ids[:-1])):
        l11l1l1ll_af_ = content[ ids[i][1]:ids[i+1][0] ]
        if l11l1l1ll_af_.startswith(id):
            items = re.compile(l1lll_af_ (u"ࠩ࠿ࡷࡪࡩࡴࡪࡱࡱࠤࡨࡲࡡࡴࡵࡀࠦ࡮ࡺࡥ࡮ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡪࡩࡴࡪࡱࡱࡂࠬ઺"),re.DOTALL).findall(l11l1l1ll_af_)
            for item in items:
                href = re.compile(l1lll_af_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ઻")).findall(item)
                l11ll11_af_ = re.compile(l1lll_af_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ઼࠭ࠧ࠭")).findall(item)
                title = re.compile(l1lll_af_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴࠭ઽ")).findall(item)
                l1lll11lll_af_ = re.compile(l1lll_af_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡪࡶ࡯ࡩࡤࡵࡲࡨࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࠫા")).findall(item)
                if not title:
                    title = re.compile(l1lll_af_ (u"ࠧࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧિ")).findall(item)
                year = re.compile(l1lll_af_ (u"ࠨ࠾ࡶࡴࡦࡴࠠࡤ࡮ࡤࡷࡸࡃࠢࡺࡧࡤࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬી")).findall(item)
                type = re.compile(l1lll_af_ (u"ࠩ࠿ࡷࡵࡧ࡮ࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡶࡼࡴࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭ુ")).findall(item)
                l11ll11l1_af_ = re.compile(l1lll_af_ (u"ࠪࡀࡸࡶࡡ࡯ࠢࡦࡰࡦࡹࡳ࠾ࠤࡱࡹࡲࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭ૂ")).findall(item)
                l11l11l1l_af_ = re.compile(l1lll_af_ (u"ࠫࡁࡶࠠࡤ࡮ࡤࡷࡸࡃࠢࡥࡧࡶࡧࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡰ࠿ࠩૃ")).findall(item)
                if href and title:
                    try: l11ll11l1_af_ = eval(l1lll_af_ (u"ࠬ࠷࠮࠱ࠬࠪૄ")+l11ll11l1_af_[0])*10
                    except: l11ll11l1_af_ = l1lll_af_ (u"࠭ࠧૅ")
                    l1l1111_af_={
                        l1lll_af_ (u"ࠧࡩࡴࡨࡪࠬ૆"):urlparse.urljoin(l1111ll11_af_,href[0]),
                        l1lll_af_ (u"ࠨ࡫ࡰ࡫ࠬે"):urlparse.urljoin(l1111ll11_af_,l11ll11_af_[0]) if l11ll11_af_ else l1lll_af_ (u"ࠩࠪૈ"),
                        l1lll_af_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩૉ"): title[0],
                        l1lll_af_ (u"ࠫࡴࡸࡩࡨ࡫ࡱࡥࡱࡺࡩࡵ࡮ࡨࠫ૊"): l1lll11lll_af_[0] if l1lll11lll_af_ else l1lll_af_ (u"ࠬ࠭ો"),
                        l1lll_af_ (u"࠭ࡹࡦࡣࡵࠫૌ"): year[0].split(l1lll_af_ (u"ࠧ࠯્ࠩ"))[-1] if year else l1lll_af_ (u"ࠨࠩ૎"),
                        l1lll_af_ (u"ࠩࡳࡰࡴࡺࠧ૏"):l11l11l1l_af_[0].replace(l1lll_af_ (u"ࠪࠪ࡭࡫࡬࡭࡫ࡳ࠿ࠬૐ"),l1lll_af_ (u"ࠫ࠳࠴࠮ࠨ૑")) if l11l11l1l_af_ else l1lll_af_ (u"ࠬ࠭૒"),
                        l1lll_af_ (u"࠭ࡣࡰࡦࡨࠫ૓") : type[0] if type else l1lll_af_ (u"ࠧࠨ૔"),
                        l1lll_af_ (u"ࠨࡴࡤࡸ࡮ࡴࡧࠨ૕") : l11ll11l1_af_,
                        }
                    if l1lll_af_ (u"ࠩ࠲ࡷࡪࡸࡩࡢ࡮࠲ࠫ૖") in href[0]:
                        l1lll11l1l_af_.append(l1l1111_af_)
                    else:
                        l1llll11l1_af_.append(l1l1111_af_)
    return l1llll11l1_af_,l1lll11l1l_af_
def l1llll11ll_af_(url=l1lll_af_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡪ࡮ࡲࡩࡴࡧࡵ࠲ࡹࡼ࠯ࡧ࡫࡯ࡱࡾ࠭૗")):
    content = l111lll11_af_(url)
    l11l1l11l_af_ = False
    l111l11ll_af_ = False
    l1lll1l1_af_ = re.compile(l1lll_af_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡦࡶࡨࡆࡴࡾࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡨࡲࡥࡢࡴࠥࡂࡁ࠵ࡤࡪࡸࡁࠫ૘"),re.DOTALL).findall(content)
    if l1lll1l1_af_:
        l11l1l11l_af_ = re.compile(l1lll_af_ (u"ࠬࡂࡡࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡅࡸࡳࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡳࡵࡻ࡯ࡩࡂࠨࡰࡢࡦࡧ࡭ࡳ࡭࠺ࠡ࠲ࠣ࠵࠵ࡶࡸࠣࡀࡓࡳࡵࡸࡺࡦࡦࡱ࡭ࡦࡂ࠯ࡢࡀࠪ૙")).findall(l1lll1l1_af_[0])
        l11l1l11l_af_ = l11l1l11l_af_[0].replace(l1lll_af_ (u"࠭ࠦࡢ࡯ࡳ࠿ࠬ૚"),l1lll_af_ (u"ࠧࠧࠩ૛")) if l11l1l11l_af_ else False
        l111l11ll_af_ = re.compile(l1lll_af_ (u"ࠨ࠾ࡤࠤࡨࡲࡡࡴࡵࡀࠦࡵࡈࡴ࡯ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ૜")).findall(l1lll1l1_af_[0])
        l111l11ll_af_ = l111l11ll_af_[-1].replace(l1lll_af_ (u"ࠩࠩࡥࡲࡶ࠻ࠨ૝"),l1lll_af_ (u"ࠪࠪࠬ૞")) if l1lll_af_ (u"ࠫࡓࡧࡳࡵࠩ૟") in l1lll1l1_af_[0] else False
    items = re.compile(l1lll_af_ (u"ࠬࡂࡳࡦࡥࡷ࡭ࡴࡴࠠࡤ࡮ࡤࡷࡸࡃࠢࡪࡶࡨࡱࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡦࡥࡷ࡭ࡴࡴ࠾ࠨૠ"),re.DOTALL).findall(content)
    out=[]
    for item in items:
        href = re.compile(l1lll_af_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬૡ")).findall(item)
        l11ll11_af_ = re.compile(l1lll_af_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩૢ")).findall(item)
        title = re.compile(l1lll_af_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࠩૣ")).findall(item)
        l1lll11lll_af_ = re.compile(l1lll_af_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷ࡭ࡹࡲࡥࡠࡱࡵ࡫ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࠧ૤")).findall(item)
        year = re.compile(l1lll_af_ (u"ࠪࡀࡸࡶࡡ࡯ࠢࡦࡰࡦࡹࡳ࠾ࠤࡼࡩࡦࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ૥")).findall(item)
        type = re.compile(l1lll_af_ (u"ࠫࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥࡸࡾࡶࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ૦")).findall(item)
        l11ll11l1_af_ = re.compile(l1lll_af_ (u"ࠬࡂࡳࡱࡣࡱࠤࡨࡲࡡࡴࡵࡀࠦࡳࡻ࡭ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ૧")).findall(item)
        l11l11l1l_af_ = re.compile(l1lll_af_ (u"࠭࠼ࡱࠢࡦࡰࡦࡹࡳ࠾ࠤࡧࡩࡸࡩࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡲࡁࠫ૨")).findall(item)
        if href and title:
            try: l11ll11l1_af_ = eval(l11ll11l1_af_[0])*10
            except: l11ll11l1_af_ = l1lll_af_ (u"ࠧࠨ૩")
            l1l1111_af_={
                l1lll_af_ (u"ࠨࡪࡵࡩ࡫࠭૪"):urlparse.urljoin(l1111ll11_af_,href[0]),
                l1lll_af_ (u"ࠩ࡬ࡱ࡬࠭૫"):urlparse.urljoin(l1111ll11_af_,l11ll11_af_[0]) if l11ll11_af_ else l1lll_af_ (u"ࠪࠫ૬"),
                l1lll_af_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ૭"): title[0],
                l1lll_af_ (u"ࠬࡵࡲࡪࡩ࡬ࡲࡦࡲࡴࡪࡶ࡯ࡩࠬ૮"): l1lll11lll_af_[0] if l1lll11lll_af_ else l1lll_af_ (u"࠭ࠧ૯"),
                l1lll_af_ (u"ࠧࡺࡧࡤࡶࠬ૰"): year[0] if year else l1lll_af_ (u"ࠨࠩ૱"),
                l1lll_af_ (u"ࠩࡳࡰࡴࡺࠧ૲"):l11l11l1l_af_[0].replace(l1lll_af_ (u"ࠪࠪ࡭࡫࡬࡭࡫ࡳ࠿ࠬ૳"),l1lll_af_ (u"ࠫ࠳࠴࠮ࠨ૴")) if l11l11l1l_af_ else l1lll_af_ (u"ࠬ࠭૵"),
                l1lll_af_ (u"࠭ࡣࡰࡦࡨࠫ૶") : type[0] if type else l1lll_af_ (u"ࠧࠨ૷"),
                l1lll_af_ (u"ࠨࡴࡤࡸ࡮ࡴࡧࠨ૸") : l11ll11l1_af_,
                }
            out.append(l1l1111_af_)
    return out,(l11l1l11l_af_,l111l11ll_af_)
def l1lll1llll_af_(url=l1lll_af_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡩ࡭ࡱ࡯ࡳࡦࡴ࠱ࡸࡻ࠵ࡳࡦࡴ࡬ࡥࡱ࠵ࡷࡪ࡭࡬ࡲ࡬ࡵࡷࡪࡧ࠲࠶࠽࠭ૹ")):
    content = l111lll11_af_(url)
    out=[]
    l11ll11_af_ = re.compile(l1lll_af_ (u"ࠪࡀ࡮ࡳࡧࠡ࡫ࡧࡁࠧࡶ࡯ࡴࡶࡨࡶࠧࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫૺ")).findall(content)
    l11ll11_af_ = urlparse.urljoin(l1111ll11_af_,l11ll11_af_[0]) if l11ll11_af_ else l1lll_af_ (u"ࠫࠬૻ")
    l11l11l1l_af_ = re.compile(l1lll_af_ (u"ࠬࡂࡳࡦࡥࡷ࡭ࡴࡴࠠࡪࡦࡀࠦࡩ࡫ࡳࡤࡡࡥࡳࡽࠨ࠾࠽ࡪ࠶ࠤ࡮ࡪ࠽ࠣࡵࡸࡦࡤࡺࡩࡵ࡮ࡨࠦࡃࡕࡰࡪࡵࠣࡷࡪࡸࡩࡢ࡮ࡸ࠾ࡁ࠵ࡨ࠴ࡀ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡤ࡮ࡨࡥࡷࠨ࠾࠽࠱ࡧ࡭ࡻࡄ࠼ࡱࠢ࡬ࡨࡂࠨࡤࡦࡵࡦࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡶ࠾࠽࠱ࡶࡩࡨࡺࡩࡰࡰࡁࠫૼ")).findall(content)
    l11l11l1l_af_ = l11l11l1l_af_[0] if l11l11l1l_af_ else l1lll_af_ (u"࠭ࠧ૽")
    l111ll1ll_af_=re.compile(l1lll_af_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡦࡲ࡬ࡷࡴࡪࡥࡏࡣࡰࡩࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ૾")).findall(content)
    for href,title in l111ll1ll_af_:
        l1lll1ll1l_af_ = re.findall(l1lll_af_ (u"ࠨࡵࠫࡠࡩ࠱ࠩࠨ૿"),href,flags=re.I)
        l1lll1ll1l_af_ = int(l1lll1ll1l_af_[0]) if l1lll1ll1l_af_ else l1lll_af_ (u"ࠩࠪ଀")
        l1llll111l_af_ = re.findall(l1lll_af_ (u"ࠪࡩ࠭ࡢࡤࠬࠫࠪଁ"),href,flags=re.I)
        l1llll111l_af_ = int(l1llll111l_af_[0]) if l1llll111l_af_ else l1lll_af_ (u"ࠫࠬଂ")
        l1l1111_af_ = { l1lll_af_ (u"ࠬ࡮ࡲࡦࡨࠪଃ")  : urlparse.urljoin(l1111ll11_af_,href),
                l1lll_af_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭଄") : l1lll1ll1l_af_,
                l1lll_af_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࠨଅ") : l1llll111l_af_,
                l1lll_af_ (u"ࠨ࡯ࡨࡨ࡮ࡧࡴࡺࡲࡨࠫଆ"): l1lll_af_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࠪଇ"),
                l1lll_af_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩଈ") : l1lll_af_ (u"ࠫࠪࡪࡸࠦࡦࠣࠩࡸ࠭ଉ")%(l1lll1ll1l_af_,l1llll111l_af_,title),
                l1lll_af_ (u"ࠬࡶ࡬ࡰࡶࠪଊ"):l11l11l1l_af_,
                l1lll_af_ (u"࠭ࡩ࡮ࡩࠪଋ"): l11ll11_af_ }
        out.append(l1l1111_af_)
    return out
def l1lll11l11_af_(out):
    l1lll11l1l_af_={}
    l1lll1l111_af_ = [x.get(l1lll_af_ (u"ࠧࡴࡧࡤࡷࡴࡴࠧଌ")) for x in out]
    for s in set(l1lll1l111_af_):
        l1lll11l1l_af_[l1lll_af_ (u"ࠨࡕࡨࡾࡴࡴࠠࠦ࠲࠵ࡨࠬ଍")%s]=[out[i] for i, j in enumerate(l1lll1l111_af_) if j == s]
    return l1lll11l1l_af_
def l1l11l1l_af_(url):
    content = l111lll11_af_(url)
    l11l11lll_af_=[]
    l1lll1lll1_af_ = re.compile(l1lll_af_ (u"ࠩࡧࡥࡹࡧ࠭ࡵࡻࡳࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࡝ࡹ࠭࠭ࡁ࠵ࡤࡪࡸࡁࠫ଎")).findall(content)
    l1lll1l11l_af_ = re.compile(l1lll_af_ (u"ࠪࡀࡺࡲࠠ࡜ࡵࡷࡽࡱ࡫࠽ࠣࡦ࡬ࡷࡵࡲࡡࡺ࠼ࡱࡳࡳ࡫ࠢࠡ࡟࠭ࡨࡦࡺࡡ࠮ࡶࡼࡴࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫଏ"),re.DOTALL).findall(content)
    for l1llll1l11_af_,l1llll1111_af_ in l1lll1l11l_af_:
        l1lll1ll11_af_ = re.compile(l1lll_af_ (u"ࠫࡁࡲࡩࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫଐ")).findall(l1llll1111_af_)
        for l1lll1l1l1_af_ in l1lll1ll11_af_:
            data = re.compile(l1lll_af_ (u"ࠬࡪࡡࡵࡣ࠰ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ଑")).findall(l1lll1l1l1_af_)
            quality = re.compile(l1lll_af_ (u"࠭࠼ࡴࡲࡤࡲࠥࡩ࡬ࡢࡵࡶࡁࠧࡷࡵࡢ࡮࡬ࡸࡾࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭଒")).findall(l1lll1l1l1_af_)
            host = re.compile(l1lll_af_ (u"ࠧ࠽ࡵࡳࡥࡳࠦࡣ࡭ࡣࡶࡷࡂࠨࡨࡰࡵࡷࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫଓ")).findall(l1lll1l1l1_af_)
            if data:
                quality = quality[0] if quality else l1lll_af_ (u"ࠨࡁࠪଔ")
                host = host[0] if host else l1lll_af_ (u"ࠩࡂࠫକ")
                l1l1111_af_ = {l1lll_af_ (u"ࠪࡹࡷࡲࠧଖ") : l1lll_af_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡫࡯࡬ࡪࡵࡨࡶ࠳ࡺࡶ࠰ࡧࡰࡦࡪࡪ࠿ࡴࡣ࡯ࡸࡂ࠭ଗ")+data[0],
                    l1lll_af_ (u"ࠬࡲࡡࡣࡧ࡯ࠫଘ"): l1lll_af_ (u"ࠨ࡛ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࠪࡹ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠡࡾࠣࠩࡸࠦࡼࠡ࡝ࠨࡷࡢࠨଙ") %(l1llll1l11_af_,quality,host),
                    l1lll_af_ (u"ࠧࡩࡱࡶࡸࠬଚ"): host,
                    l1lll_af_ (u"ࠨ࡮ࡤࡲ࡬࠭ଛ"):l1llll1l11_af_,
                    }
                l11l11lll_af_.append(l1l1111_af_)
    return l11l11lll_af_
def l1lll11ll1_af_(url=l1lll_af_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡩ࡭ࡱ࡯ࡳࡦࡴ࠱ࡸࡻ࠵ࡥ࡮ࡤࡨࡨࡄࡹࡡ࡭ࡶࡀ࠹࠽࠻࠱࠺࠸࠷࠵࠹ࡩ࠱ࡦࡣ࠶࠶ࡪ࡬࠰࠺࠻࠻࠺࠻࠾ࠧଜ")):
    content = l111lll11_af_(url)
    l1l11111_af_ = re.search(l1lll_af_ (u"ࠪࡺࡦࡸࠠࡶࡴ࡯ࡠࡸ࠰࠽࡝ࡵ࠭࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࠬଝ"),content)
    if l1l11111_af_:
        return l1l11111_af_.group(1).replace(l1lll_af_ (u"ࠫࠨ࡝ࡉࡅࡖࡋࠫଞ"),l1lll_af_ (u"ࠬ࠹࠲࠱ࠩଟ")).replace(l1lll_af_ (u"࠭ࠣࡉࡇࡌࡋࡍ࡚ࠧଠ"),l1lll_af_ (u"ࠧ࠳࠶࠳ࠫଡ"))
    return l1lll_af_ (u"ࠨࠩଢ")
