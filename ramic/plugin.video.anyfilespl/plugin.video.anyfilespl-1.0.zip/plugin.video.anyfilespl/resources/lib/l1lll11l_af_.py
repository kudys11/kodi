# -*- coding: utf-8 -*-
import sys
l1ll_af_ = sys.version_info [0] == 2
l111l_af_ = 2048
l111_af_ = 7
def l1lll_af_ (ll_af_):
	global l1ll11_af_
	l1l11l_af_ = ord (ll_af_ [-1])
	l11l1_af_ = ll_af_ [:-1]
	l1l_af_ = l1l11l_af_ % len (l11l1_af_)
	l11_af_ = l11l1_af_ [:l1l_af_] + l11l1_af_ [l1l_af_:]
	if l1ll_af_:
		l1lll1_af_ = unicode () .join ([unichr (ord (char) - l111l_af_ - (l11ll_af_ + l1l11l_af_) % l111_af_) for l11ll_af_, char in enumerate (l11_af_)])
	else:
		l1lll1_af_ = str () .join ([chr (ord (char) - l111l_af_ - (l11ll_af_ + l1l11l_af_) % l111_af_) for l11ll_af_, char in enumerate (l11_af_)])
	return eval (l1lll1_af_)
import sys,re,os
import urllib2
import urlparse
import cookielib
import json
l1111ll11_af_=l1lll_af_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡳࡿࡦࡪ࡮ࡨࡷ࠳ࡶ࡬ࠨছ")
l11l11ll1_af_ = 15
l11111l1l_af_=l1lll_af_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡏࡘ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠷࠼࠳࠶࠮࠳࠷࠹࠸࠳࠿࠷ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨজ")
l1l11lll_af_=l1lll_af_ (u"ࠫࡨࡵ࡯࡬࡫ࡨࠫঝ")
def l111lll11_af_(url,data=None,cookies=None):
    if l1l11lll_af_ and os.path.exists(l1l11lll_af_):
        l11l1ll11_af_ = cookielib.LWPCookieJar()
        l11l1ll11_af_.load(l1l11lll_af_,True,True)
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l11l1ll11_af_))
        urllib2.install_opener(opener)
    req = urllib2.Request(url,data)
    req.add_header(l1lll_af_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩঞ"), l11111l1l_af_)
    req.add_header(l1lll_af_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧট"), l1111ll11_af_)
    l111l1l11_af_=l1lll_af_ (u"ࠧࠨঠ")
    if cookies:
        req.add_header(l1lll_af_ (u"ࠣࡅࡲࡳࡰ࡯ࡥࠣড"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11l11ll1_af_)
        l1l11111_af_ = response.read()
    except:
        l1l11111_af_=l1lll_af_ (u"ࠩࠪঢ")
    return l1l11111_af_
def l11l111ll_af_():
    global l1l11lll_af_
    try:
        l11l11l11_af_ = cookielib.LWPCookieJar()
        l11l11l11_af_.load(l1l11lll_af_,True,True)
        cookies = l1lll_af_ (u"ࠪ࠿ࠬণ").join([l1lll_af_ (u"ࠫࠪࡹ࠽ࠦࡵࠪত")%(c.name,c.value) for c in l11l11l11_af_])
    except:
        cookies =l1lll_af_ (u"ࠬ࠭থ")
    return cookies
def l111lllll_af_(url,data=None):
    l11l1ll11_af_ = cookielib.LWPCookieJar()
    if os.path.exists(l1l11lll_af_):
        l11l1ll11_af_.load(l1l11lll_af_,True,True)
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l11l1ll11_af_))
    urllib2.install_opener(opener)
    req = urllib2.Request(url,data)
    req.add_header(l1lll_af_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪদ"), l11111l1l_af_)
    req.add_header(l1lll_af_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨধ"), l1111ll11_af_)
    try:
        response = urllib2.urlopen(req,timeout=l11l11ll1_af_)
        l1ll1ll1_af_ = response.headers.get(l1lll_af_ (u"ࠨࡵࡨࡸ࠲ࡩ࡯ࡰ࡭࡬ࡩࠬন"),l1lll_af_ (u"ࠩࠪ঩"))
        l1l11111_af_ = response.read()
        response.close()
        l11l1ll11_af_.save(l1l11lll_af_,True,True)
    except:
        l1ll1ll1_af_=l1lll_af_ (u"ࠪࠫপ")
        l1l11111_af_=l1lll_af_ (u"ࠫࠬফ")
    return l1l11111_af_,l1ll1ll1_af_
data=l1lll_af_ (u"ࠬࡲ࡯ࡢࡦࡨࡶࡤ࡬࠽ࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡢࡪࡂ࠷ࠦࡴࡱࡵࡸࡤ࡬࠽࠱ࠨࡷ࡭ࡲ࡫ࡲࡢࡰࡪࡩࡤ࡬࠽࠱ࠨࡴࡹࡦࡲࡩࡵࡻࡢࡪࡂ࠶ࠦࡳࡧࡶࡸࡷ࡯ࡣࡵ࡫ࡲࡲࡤ࡬࠽࠱ࠨࡵࡩࡸ࡫ࡴࡠࡨࡀࡪࡦࡲࡳࡦࠩব")
def l1l1llll_af_(data=data):
    url=l1lll_af_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡰࡼࡪ࡮ࡲࡥࡴ࠰ࡳࡰ࠴ࡧ࡬࡭࠰࡭ࡷࡵ࠭ভ")
    content,l1ll1ll1_af_=l111lllll_af_(url,data)
    return l1ll1ll1_af_
def l1l1ll1l_af_(url=l1lll_af_ (u"ࠧ࠰ࡔࡲࡾࡷࡿࡷ࡬ࡣ࠲ࡪ࡮ࡲ࡭ࡺ࠱࠶࠳࠵࠭ম"),l11llll1_af_=1):
    if url:
        l1111l11l_af_ = l1111ll11_af_+url
        content, l1ll1ll1_af_ = l111lllll_af_(l1111l11l_af_)
        l111l11ll_af_ = 2
        l11l1l11l_af_ = False
    else:
        l11llll1_af_ = int(l11llll1_af_)*20
        l1111l11l_af_ = l1lll_af_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡲࡾ࡬ࡩ࡭ࡧࡶ࠲ࡵࡲ࠯ࡢ࡮࡯࠲࡯ࡹࡰࡀࡵࡷࡁࠪࡪࠧয")%(l11llll1_af_)
        content, l1ll1ll1_af_ = l111lllll_af_(l1111l11l_af_)
        l111l11ll_af_ = l11llll1_af_/20+1 if content.find(l1lll_af_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠴ࡧ࡬࡭࠰࡭ࡷࡵࡅࡳࡵ࠿ࠨࡨࠧࡄࠧর")%(l11llll1_af_+20))>0 else False
        l11l1l11l_af_ = l11llll1_af_/20-1 if l11llll1_af_/10>1 else False
    content=l111lll11_af_(l1lll_af_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡴࡹࡧ࡫࡯ࡩࡸ࠴ࡰ࡭࠱ࡳࡥ࡬࡫࡬ࡰࡣࡧ࡭ࡳ࡭࠯ࡢ࡮࡯࠱ࡱࡵࡡࡥࡧࡵ࠲࡯ࡹࡰࡀࡣࡧࡷࡂࡺࡲࡶࡧࠪ঱"))
    out = l1111ll1l_af_(content)
    return out,(l11l1l11l_af_,l111l11ll_af_)
def l1111l_af_(url=l1lll_af_ (u"ࠦ࠴ࡶࡡࡨࡧ࡯ࡳࡦࡪࡩ࡯ࡩ࠲ࡸࡦࡨ࠭ࡷ࡫ࡧࡩࡴࡹ࠭࡭ࡱࡤࡨࡪࡸ࠮࡫ࡵࡳࡃࡴࡶ࠽࠱ࠤল")):
    content = l111lll11_af_(l1111ll11_af_+url)
    out = l1111ll1l_af_(content)
    return out
def l1111ll1l_af_(content):
    ids = [(a.start(), a.end()) for a in re.finditer(l1lll_af_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨࠧ঳"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11l1l1ll_af_ = content[ ids[i][1]:ids[i+1][0] ]
        category = re.findall(l1lll_af_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠯࠯ࠬ࠲ࡪ࡮ࡲ࡭ࡺ࠱࡟ࡨ࠰࠵࡜ࡥ࠭ࠬࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ঴"),l11l1l1ll_af_)
        l111l11l1_af_ = re.search(l1lll_af_ (u"ࠧ࠿ࠪ࡞ࡢࡁࡣࠫࠪ࠾ࠪ঵"),category[0][1]).group(1).strip() if category else l1lll_af_ (u"ࠨࠩশ")
        l11111l11_af_ = category[0][0] if category else l1lll_af_ (u"ࠩࠪষ")
        l111ll1ll_af_ = re.findall(l1lll_af_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠳࠳࠰࠯ࡷ࡫ࡧࡩࡴ࠵࠮ࠫࠫࠥࡂࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃࡂ࠯ࡢࡀࠪস"),l11l1l1ll_af_)
        l11ll11_af_  = re.findall(l1lll_af_ (u"ࠫࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧহ"),l11l1l1ll_af_)
        l11ll11_af_ = l11ll11_af_[0] if l11ll11_af_ else l1lll_af_ (u"ࠬ࠭঺")
        user = re.findall(l1lll_af_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠲ࡺ࡮ࡪࡥࡰࡤ࡯ࡳ࡬࠵࠮ࠫࡁࠬࠦࠥ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ঻"),l11l1l1ll_af_)
        l111llll1_af_ = re.search(l1lll_af_ (u"ࠧ࠿ࠪ࡞ࡢࡁࡣࠫࠪ࠾়ࠪ"),user[0][1]).group(1).strip() if user else l1lll_af_ (u"ࠨࠩঽ")
        l111lll1l_af_ = user[0][0] if user else l1lll_af_ (u"ࠩࠪা")
        l11ll11l1_af_ = re.findall(l1lll_af_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡶࡦࡺࡩ࡯ࡩࠥࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫি"),l11l1l1ll_af_)
        l11ll11l1_af_ = l11ll11l1_af_[0] if l11ll11l1_af_ else l1lll_af_ (u"ࠫࠬী")
        l111l111l_af_ = re.findall(l1lll_af_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡭࡬ࡺࡲ࡫࡭ࡨࡵ࡮ࠡࡩ࡯ࡽࡵ࡮ࡩࡤࡱࡱ࠱ࡹ࡯࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠺ࡄࠧু"),l11l1l1ll_af_)
        l111l111l_af_ = re.search(l1lll_af_ (u"࠭࠾ࠩ࡝ࡡࡀࡢ࠱ࠩ࠽ࠩূ"),l111l111l_af_[0]).group(1).strip() if l111l111l_af_ else l1lll_af_ (u"ࠧࠨৃ")
        l11l11l1l_af_ = re.findall(l1lll_af_ (u"ࠨࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨৄ"),l11l1l1ll_af_)
        l11l11l1l_af_ = l1lll_af_ (u"ࠩࠪ৅").join([p for p in l11l11l1l_af_ if l1lll_af_ (u"ࠪࡓࡵ࡯ࡳࠨ৆") in p]).replace(l1lll_af_ (u"ࠫࡁࡨࡲ࠿ࠩে"),l1lll_af_ (u"ࠬࡢ࡮ࠨৈ"))
        if l11l11l1l_af_:
            l11l11l1l_af_ = re.sub(l1lll_af_ (u"࠭࠼࡜࠱ࡠ࠮ࡡࡽࠫ࠿ࠩ৉"),l1lll_af_ (u"ࠧࠨ৊"),l11l11l1l_af_)
        l11l1111l_af_ =l1lll_af_ (u"ࠨࠩো")
        if l111ll1ll_af_:
            href,title = l111ll1ll_af_[0]
            l11l1111l_af_ += l1lll_af_ (u"ࠩ࡞ࡆࡢࠫࡳ࡜࠱ࡅࡡࠥ࠭ৌ")%l111l11l1_af_ if l111l11l1_af_ else l1lll_af_ (u"্ࠪࠫ")
            l11l1111l_af_ += title
            l11l1111l_af_ += l1lll_af_ (u"ࠫࠥࡡࡉ࡞ࠧࡶ࡟࠴ࡏ࡝ࠡࠩৎ")%l111llll1_af_ if l111llll1_af_ else l1lll_af_ (u"ࠬ࠭৏")
            l1l1111_af_={
                l1lll_af_ (u"࠭ࡨࡳࡧࡩࠫ৐"):href,
                l1lll_af_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭৑"):l11l1111l_af_,
                l1lll_af_ (u"ࠨ࡫ࡰ࡫ࠬ৒"):urlparse.urljoin(l1111ll11_af_,l11ll11_af_) if l11ll11_af_ else l1lll_af_ (u"ࠩࠪ৓"),
                l1lll_af_ (u"ࠪࡹࡸ࡫ࡲࡠࡰࡤࡱࡪ࠭৔"):l111llll1_af_,
                l1lll_af_ (u"ࠫࡺࡹࡥࡳࡡ࡯࡭ࡳࡱࠧ৕"):l111lll1l_af_,
                l1lll_af_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿ࡟࡯ࡣࡰࡩࠬ৖"):l111l11l1_af_,
                l1lll_af_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࡠ࡮࡬ࡲࡰ࠭ৗ"):l11111l11_af_,
                l1lll_af_ (u"ࠧࡱ࡮ࡲࡸࠬ৘")  : l11l11l1l_af_,
                l1lll_af_ (u"ࠨࡥࡲࡨࡪ࠭৙")  : l111l111l_af_,
                l1lll_af_ (u"ࠩࡵࡥࡹ࡯࡮ࡨࠩ৚") : l11ll11l1_af_,
                }
            out.append(l1l1111_af_)
    return out
def l1ll1l11_af_(name=l1lll_af_ (u"ࠪࠫ৛")):
    label=[l1lll_af_ (u"ࠦ࡜ࡹࡺࡺࡵࡷ࡯࡮࡫ࠢড়"),l1lll_af_ (u"ࠧࡇ࡮ࡪ࡯ࡨࠦঢ়"),l1lll_af_ (u"ࠨࡃࡪࡧ࡮ࡥࡼࡵࡳࡵ࡭࡬ࠤ࡮ࠦࡰࡰࡦࡵࣷঁ࡫ࠢ৞"),l1lll_af_ (u"ࠢࡓࡱࡽࡶࡾࡽ࡫ࡢࠤয়"),l1lll_af_ (u"ࠣࡇࡻࡸࡷ࡫࡭ࡢ࡮ࡱࡩࠧৠ"),l1lll_af_ (u"ࠤࡊࡶࡾࠦࡩࠡ࡭ࡲࡱࡵࡻࡴࡦࡴࡼࠦৡ"),l1lll_af_ (u"ࠥࡌࡺࡳ࡯ࡳࠤৢ"),l1lll_af_ (u"ࠦࡎࡲࡵࡻ࡬ࡨࠤ࡮ࠦࡳࡻࡶࡸࡧࡿࡱࡩࠣৣ"),l1lll_af_ (u"ࠧࡑࡡࡣࡣࡵࡩࡹࡿࠠࡪࠢࡶ࡯ࡪࡩࡺࡦࠤ৤"),l1lll_af_ (u"ࠨࡋࡪࡰࡲࠤ࡮ࠦࡔࡗࠤ৥"),l1lll_af_ (u"ࠢࡌࡱࡱࡸࡷࡵࡷࡦࡴࡶ࡮ࡪࠦࡩࠡࡹࡼࡴࡦࡪ࡫ࡪࠤ০"),
            l1lll_af_ (u"ࠣࡍࡵࡩࡸࡱࣳࡸ࡭࡬ࠦ১"),l1lll_af_ (u"ࠤࡏࡹࡩࢀࡩࡦࠤ২"),l1lll_af_ (u"ࠥࡑࡴࡺ࡯ࡳࡻࡽࡥࡨࡰࡡࠣ৩"),l1lll_af_ (u"ࠦࡒࡻࡺࡺ࡭ࡤࠤ࡮ࠦࡔࡢࡰ࡬ࡩࡨࠨ৪"),l1lll_af_ (u"ࠧࡔࡡࡶ࡭ࡤࠤ࡮ࠦࡴࡦࡥ࡫ࡲࡴࡲ࡯ࡨ࡫ࡤࠦ৫"),l1lll_af_ (u"ࠨࡐࡰ࡮࡬ࡸࡾࡱࡡࠡ࡫ࠣࡻࡾࡪࡡࡳࡼࡨࡲ࡮ࡧࠢ৬"),l1lll_af_ (u"ࠢࡓࡧ࡮ࡰࡦࡳࡹࠡ࡫ࠣ࡭ࡨ࡮ࠠࡱࡣࡵࡳࡩ࡯ࡥࠣ৭"),l1lll_af_ (u"ࠣࡕࡳࡳࡷࡺࠢ৮"),l1lll_af_ (u"ࠤ࡝ࡻ࡮࡫ࡲࡻछࡷࡥࠧ৯"),l1lll_af_ (u"ࠥࡍࡳࡴࡥࠣৰ"),l1lll_af_ (u"ࠦ࡟ࡽࡩࡢࡵࡷࡹࡳ࠳ࡓࡱࡱࡷࠦৱ")]
    return label.index(name)
def l11111lll_af_(l11111ll1_af_=l1lll_af_ (u"ࠧࡩࡡࡵࡧࡪࡳࡷࡿ࡟ࡧࠤ৲")):
    if l11111ll1_af_==l1lll_af_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࡠࡨࠪ৳"):
        label=[l1lll_af_ (u"ࠢࡘࡵࡽࡽࡸࡺ࡫ࡪࡧࠥ৴"),l1lll_af_ (u"ࠣࡃࡱ࡭ࡲ࡫ࠢ৵"),l1lll_af_ (u"ࠤࡆ࡭ࡪࡱࡡࡸࡱࡶࡸࡰ࡯ࠠࡪࠢࡳࡳࡩࡸࣳॽࡧࠥ৶"),l1lll_af_ (u"ࠥࡖࡴࢀࡲࡺࡹ࡮ࡥࠧ৷"),l1lll_af_ (u"ࠦࡊࡾࡴࡳࡧࡰࡥࡱࡴࡥࠣ৸"),l1lll_af_ (u"ࠧࡍࡲࡺࠢ࡬ࠤࡰࡵ࡭ࡱࡷࡷࡩࡷࡿࠢ৹"),l1lll_af_ (u"ࠨࡈࡶ࡯ࡲࡶࠧ৺"),l1lll_af_ (u"ࠢࡊ࡮ࡸࡾ࡯࡫ࠠࡪࠢࡶࡾࡹࡻࡣࡻ࡭࡬ࠦ৻"),l1lll_af_ (u"ࠣࡍࡤࡦࡦࡸࡥࡵࡻࠣ࡭ࠥࡹ࡫ࡦࡥࡽࡩࠧৼ"),l1lll_af_ (u"ࠤࡎ࡭ࡳࡵࠠࡪࠢࡗ࡚ࠧ৽"),l1lll_af_ (u"ࠥࡏࡴࡴࡴࡳࡱࡺࡩࡷࡹࡪࡦࠢ࡬ࠤࡼࡿࡰࡢࡦ࡮࡭ࠧ৾"),
            l1lll_af_ (u"ࠦࡐࡸࡥࡴ࡭ࣶࡻࡰ࡯ࠢ৿"),l1lll_af_ (u"ࠧࡒࡵࡥࡼ࡬ࡩࠧ਀"),l1lll_af_ (u"ࠨࡍࡰࡶࡲࡶࡾࢀࡡࡤ࡬ࡤࠦਁ"),l1lll_af_ (u"ࠢࡎࡷࡽࡽࡰࡧࠠࡪࠢࡗࡥࡳ࡯ࡥࡤࠤਂ"),l1lll_af_ (u"ࠣࡐࡤࡹࡰࡧࠠࡪࠢࡷࡩࡨ࡮࡮ࡰ࡮ࡲ࡫࡮ࡧࠢਃ"),l1lll_af_ (u"ࠤࡓࡳࡱ࡯ࡴࡺ࡭ࡤࠤ࡮ࠦࡷࡺࡦࡤࡶࡿ࡫࡮ࡪࡣࠥ਄"),l1lll_af_ (u"ࠥࡖࡪࡱ࡬ࡢ࡯ࡼࠤ࡮ࠦࡩࡤࡪࠣࡴࡦࡸ࡯ࡥ࡫ࡨࠦਅ"),l1lll_af_ (u"ࠦࡘࡶ࡯ࡳࡶࠥਆ"),l1lll_af_ (u"ࠧࡠࡷࡪࡧࡵࡾञࡺࡡࠣਇ"),l1lll_af_ (u"ࠨࡉ࡯ࡰࡨࠦਈ"),l1lll_af_ (u"࡛ࠢࡹ࡬ࡥࡸࡺࡵ࡯࠯ࡖࡴࡴࡺࠢਉ")]
        value=[l1lll_af_ (u"ࠣ࠲ࠥਊ"),l1lll_af_ (u"ࠤ࠴ࠦ਋"),l1lll_af_ (u"ࠥ࠶ࠧ਌"),l1lll_af_ (u"ࠦ࠸ࠨ਍"),l1lll_af_ (u"ࠧ࠺ࠢ਎"),l1lll_af_ (u"ࠨ࠵ࠣਏ"),l1lll_af_ (u"ࠢ࠷ࠤਐ"), l1lll_af_ (u"ࠣ࠹ࠥ਑") ,l1lll_af_ (u"ࠤ࠻ࠦ਒") ,l1lll_af_ (u"ࠥ࠽ࠧਓ") ,l1lll_af_ (u"ࠦ࠶࠶ࠢਔ") ,l1lll_af_ (u"ࠧ࠷࠱ࠣਕ") ,l1lll_af_ (u"ࠨ࠱࠳ࠤਖ") ,l1lll_af_ (u"ࠢ࠲࠵ࠥਗ") ,l1lll_af_ (u"ࠣ࠳࠷ࠦਘ") ,l1lll_af_ (u"ࠤ࠴࠹ࠧਙ") ,l1lll_af_ (u"ࠥ࠵࠻ࠨਚ") ,l1lll_af_ (u"ࠦ࠶࠽ࠢਛ") ,l1lll_af_ (u"ࠧ࠷࠸ࠣਜ") ,l1lll_af_ (u"ࠨ࠱࠺ࠤਝ") ,l1lll_af_ (u"ࠢ࠳࠲ࠥਞ") ,l1lll_af_ (u"ࠣ࠴࠴ࠦਟ")]
    elif l11111ll1_af_==l1lll_af_ (u"ࠩࡶࡳࡷࡺ࡟ࡧࠩਠ"):
        label=[l1lll_af_ (u"ࠥࡈࡦࡺࡡࠡࡦࡲࡨࡦࡴࡩࡢࠢࠫࡨࡪ࡬ࡡࡶ࡮ࡷ࠭ࠧਡ"),l1lll_af_ (u"ࠦࡕࡵࡰࡶ࡮ࡤࡶࡳࡵज़ईࠤਢ"),l1lll_af_ (u"ࠧࡕࡣࡦࡰࡤࠤࡺংࡹࡵ࡭ࡲࡻࡳ࡯࡫ࣴࡹࠥਣ")]
        value=[l1lll_af_ (u"ࠨ࠰ࠣਤ"),l1lll_af_ (u"ࠢ࠲ࠤਥ"),l1lll_af_ (u"ࠣ࠴ࠥਦ")]
    return label,value
url=l1lll_af_ (u"ࠩ࠲ࡴࡦ࡭ࡥ࡭ࡱࡤࡨ࡮ࡴࡧ࠰ࡤ࡯ࡳ࡬࠳ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡴ࠯࡯ࡳࡦࡪࡥࡳ࠰࡭ࡷࡵࡅࡩࡥࡷࡽࡁ࠾࠿࠴࠱࠶ࠪਧ")
url=l1lll_af_ (u"ࠪ࠳ࡵࡧࡧࡦ࡮ࡲࡥࡩ࡯࡮ࡨ࠱ࡥࡰࡴ࡭࠭ࡷ࡫ࡧࡩࡴࡹ࠭࡭ࡱࡤࡨࡪࡸ࠮࡫ࡵࡳࡃ࡮ࡪࡵࡻ࠿࠼࠽࠹࠶࠴ࠨਨ")
url=l1lll_af_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧ࡮ࡺࡨ࡬ࡰࡪࡹ࠮ࡱ࡮࠲ࡴࡦ࡭ࡥ࡭ࡱࡤࡨ࡮ࡴࡧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶ࠱ࡸ࡮ࡡࡳࡧ࠰ࡰ࡮ࡹࡴ࠯࡬ࡶࡴࠬ਩")
data=l1lll_af_ (u"ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠽࠷࠲࠻࠼ࠬਪ")
def l11lll_af_(l111ll1l1_af_=l1lll_af_ (u"࠭࠴࠳࠹࠶࠹ࠬਫ"),l11llll1_af_=1):
    l11llll1_af_ = int(l11llll1_af_)*10
    l1111l11l_af_ = l1lll_af_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡱࡽ࡫࡯࡬ࡦࡵ࠱ࡴࡱ࠵ࡰࡢࡩࡨࡰࡴࡧࡤࡪࡰࡪ࠳ࡧࡲ࡯ࡨ࠯ࡹ࡭ࡩ࡫࡯ࡴ࠯࡯ࡳࡦࡪࡥࡳ࠰࡭ࡷࡵࡅࡩࡥࡷࡽࡁࠪࡹࠦࡴࡶࡀࠩࡩ࠭ਬ")%(l111ll1l1_af_,l11llll1_af_)
    content = l111lll11_af_(l1111l11l_af_)
    l111l11ll_af_ = l11llll1_af_/10+1 if content.find(l1lll_af_ (u"ࠨࡰࡨࡼࡹࡖࡡࡨࡧࡅࡰࡴ࡭ࡖࡪࡦࡨࡳࡸ࠮࡜ࠨࠧࡧࡠࠬ࠯࠻ࠨਭ")%(l11llll1_af_+10))>0 else False
    l11l1l11l_af_ = l11llll1_af_/10-1 if l11llll1_af_/10>1 else False
    ids = [(a.start(), a.end()) for a in re.finditer(l1lll_af_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠥࠫਮ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11l1l1ll_af_ = content[ ids[i][1]:ids[i+1][0] ]
        title = re.findall(l1lll_af_ (u"ࠪࡀࡸࡺࡲࡰࡰࡪࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡺࡲࡰࡰࡪࡂࠬਯ"),l11l1l1ll_af_)
        l111l1l1l_af_ = re.findall(l1lll_af_ (u"ࠫࡴࡴࡣ࡭࡫ࡦ࡯ࡂࠨࠨ࠯ࠬࡂ࠭ࡡ࠮࡛ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝࠭࡝ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟࡟࠭ࡀࠨࠧਰ"),l11l1l1ll_af_)
        l11ll11_af_  = re.findall(l1lll_af_ (u"ࠬࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ਱"),l11l1l1ll_af_)
        l11ll11_af_ = l11ll11_af_[0] if l11ll11_af_ else l1lll_af_ (u"࠭ࠧਲ")
        category = re.findall(l1lll_af_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠰࠰࠭࠳࡫࡯࡬࡮ࡻ࠲ࡠࡩ࠱࠯࡝ࡦ࠮࠭ࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨਲ਼"),l11l1l1ll_af_)
        l111l11l1_af_ = re.search(l1lll_af_ (u"ࠨࡀࠫ࡟ࡣࡂ࡝ࠬࠫ࠿ࠫ਴"),category[0][1]).group(1).strip() if category else l1lll_af_ (u"ࠩࠪਵ")
        l11111l11_af_ = category[0][0] if category else l1lll_af_ (u"ࠪࠫਸ਼")
        l111ll1ll_af_ = re.findall(l1lll_af_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠴࠴ࠪ࠰ࡸ࡬ࡨࡪࡵ࠯࠯ࠬࠬࠦࡃࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄ࠼࠰ࡣࡁࠫ਷"),l11l1l1ll_af_)
        l111l111l_af_ = re.findall(l1lll_af_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡭࡬ࡺࡲ࡫࡭ࡨࡵ࡮ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠷ࡁࠫਸ"),l11l1l1ll_af_)
        l111l111l_af_ = re.search(l1lll_af_ (u"࠭࠾ࠩ࡝ࡡࡀࡢ࠱ࠩ࠽ࠩਹ"),l111l111l_af_[0]).group(1).strip() if l111l111l_af_ else l1lll_af_ (u"ࠧࠨ਺")
        l11l11l1l_af_ = re.findall(l1lll_af_ (u"ࠨࡑࡳ࡭ࡸࡀ࡜ࡴࠬ࠿ࡩࡲࠦࡣ࡭ࡣࡶࡷࡂࠨࡩ࡯ࡨࡲࠦࡡࡹࠪ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡧࡰࡂࠬ਻"),l11l1l1ll_af_)
        if l111ll1ll_af_:
            href,title = l111ll1ll_af_[0]
            l1l1111_af_={
                l1lll_af_ (u"ࠩ࡫ࡶࡪ࡬਼ࠧ"):href,
                l1lll_af_ (u"ࠪ࡭ࡲ࡭ࠧ਽"):urlparse.urljoin(l1111ll11_af_,l11ll11_af_) if l11ll11_af_ else l1lll_af_ (u"ࠫࠬਾ"),
                l1lll_af_ (u"ࠬࡺࡩࡵ࡮ࡨࠫਿ"): title,
                l1lll_af_ (u"࠭ࡰ࡭ࡱࡷࠫੀ")  : l11l11l1l_af_[0] if l11l11l1l_af_ else l1lll_af_ (u"ࠧࠨੁ"),
                l1lll_af_ (u"ࠨࡥࡲࡨࡪ࠭ੂ")  : l111l111l_af_,
                }
            out.append(l1l1111_af_)
    return out,(l11l1l11l_af_,l111l11ll_af_)
def l1ll11l1_af_(l111ll1l1_af_=l1lll_af_ (u"ࠩ࠼࠽࠹࠶࠴ࠨ੃")):
    l1111l11l_af_ = l1lll_af_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡴࡹࡧ࡫࡯ࡩࡸ࠴ࡰ࡭࠱ࡳࡥ࡬࡫࡬ࡰࡣࡧ࡭ࡳ࡭࠯ࡣ࡮ࡲ࡫࠲ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳ࠮࡮ࡲࡥࡩ࡫ࡲ࠯࡬ࡶࡴࡄ࡯ࡤࡶࡼࡀࠫ੄")+l111ll1l1_af_
    content = l111lll11_af_(l1111l11l_af_)
    ids = [(a.start(), a.end()) for a in re.finditer(l1lll_af_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࠧ࠭੅"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11l1l1ll_af_ = content[ ids[i][1]:ids[i+1][0] ]
        title = re.findall(l1lll_af_ (u"ࠬࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄࠧ੆"),l11l1l1ll_af_)
        l111l1l1l_af_ = re.findall(l1lll_af_ (u"࠭࡯࡯ࡥ࡯࡭ࡨࡱ࠽ࠣࠪ࠱࠮ࡄ࠯࡜ࠩ࡝ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟࠯࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࡡ࠯࠻ࠣࠩੇ"),l11l1l1ll_af_)
        l11ll11_af_  = re.findall(l1lll_af_ (u"ࠧ࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪੈ"),l11l1l1ll_af_)
        l11ll11_af_ = l11ll11_af_[0] if l11ll11_af_ else l1lll_af_ (u"ࠨࠩ੉")
        l111l111l_af_ = re.findall(l1lll_af_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡪࡰࡾࡶࡨࡪࡥࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳࡭࠻࠾ࠨ੊"),l11l1l1ll_af_)
        l111l111l_af_ = l1lll_af_ (u"ࠪࠤ࠭࠭ੋ") + re.search(l1lll_af_ (u"ࠫࡃ࠮࡛࡟࠾ࡠ࠯࠮ࡂࠧੌ"),l111l111l_af_[0]).group(1).strip() + l1lll_af_ (u"ࠬ࠯੍ࠧ") if l111l111l_af_ else l1lll_af_ (u"࠭ࠧ੎")
        if l111l1l1l_af_:
            action,l11l1ll1l_af_,title = l111l1l1l_af_[0]
            l1llll11_af_ = l1lll_af_ (u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠿ࠪ੏")+l11l1ll1l_af_
            l1l1111_af_={
                l1lll_af_ (u"ࠨࡪࡵࡩ࡫࠭੐"):l11l1ll1l_af_,
                l1lll_af_ (u"ࠩ࡬ࡱ࡬࠭ੑ"):urlparse.urljoin(l1111ll11_af_,l11ll11_af_) if l11ll11_af_ else l1lll_af_ (u"ࠪࠫ੒"),
                l1lll_af_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ੓"): title + l111l111l_af_,
                }
            out.append(l1l1111_af_)
    return out,(False,False)
def l11l11l_af_(l1111lll1_af_=l1lll_af_ (u"ࠬ࠼࠰࠺࠶ࠪ੔")):
    url=l1lll_af_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡰࡼࡪ࡮ࡲࡥࡴ࠰ࡳࡰ࠴ࡶࡡࡨࡧ࡯ࡳࡦࡪࡩ࡯ࡩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠳ࡳࡩࡣࡵࡩ࠲ࡲࡩࡴࡶ࠱࡮ࡸࡶࠧ੕")
    content = l111lll11_af_(url,l1lll_af_ (u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠿ࠪ੖")+l1111lll1_af_)
    ids = [(a.start(), a.end()) for a in re.finditer(l1lll_af_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡰ࡭ࡣࡼࡰ࡮ࡺ࠭ࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠯ࡦࡳࡳࡺࡥ࡯ࡧࡵࠦࠬ੗"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11l1l1ll_af_ = content[ ids[i][1]:ids[i+1][0] ]
        title = re.findall(l1lll_af_ (u"ࠩࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ੘"),l11l1l1ll_af_)
        l111ll111_af_ = re.findall(l1lll_af_ (u"ࠪࡳࡳࡩ࡬ࡪࡥ࡮ࡁࠧࡹࡥࡵࡘ࡬ࡨࡪࡵࡆࡳࡱࡰࡔࡱࡧࡹ࡭࡫ࡶࡸࡡ࠮࡛ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝࠭࡝ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟࡟࠭ࡀࠨࠧਖ਼"),l11l1l1ll_af_)
        l11ll11_af_  = re.findall(l1lll_af_ (u"ࠫࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧਗ਼"),l11l1l1ll_af_)
        l11ll11_af_ = l11ll11_af_[0] if l11ll11_af_ else l1lll_af_ (u"ࠬ࠭ਜ਼")
        if l111ll111_af_ and title:
            l1l1111_af_={
                l1lll_af_ (u"࠭ࡨࡳࡧࡩࠫੜ"):l1lll_af_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡱࡽ࡫࡯࡬ࡦࡵ࠱ࡴࡱ࠵ࡶࡪࡦࡨࡳ࠴࠭੝")+l111ll111_af_[0][0],
                l1lll_af_ (u"ࠨ࡫ࡰ࡫ࠬਫ਼"):urlparse.urljoin(l1111ll11_af_,l11ll11_af_) if l11ll11_af_ else l1lll_af_ (u"ࠩࠪ੟"),
                l1lll_af_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ੠"): title[0],
                }
            out.append(l1l1111_af_)
    return out,(False,False)
def l1l11l1l_af_(url):
    id = url.split(l1lll_af_ (u"ࠫ࠴ࡼࡩࡥࡧࡲ࠳ࠬ੡"))[-1]
    l11l11lll_af_=l1lll_af_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡ࡯ࡻࡩ࡭ࡱ࡫ࡳ࠯ࡲ࡯࠳ࡻ࡯ࡤࡦࡱࡶ࠲࡯ࡹࡰࡀ࡫ࡧࡁࠬ੢")+id
    return l11l11lll_af_
l111lll1l_af_=l1lll_af_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡨ࡬ࡰࡩ࠲ࡱࡦࡰࡴࡦ࡭࠵࠳࠾࠿࠴࠱࠶ࠪ੣")
def l1l1lll1_af_(l111lll1l_af_=l1lll_af_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡢ࡭ࡱࡪ࠳ࡉࡰ࠭ࡂࡴࡷ࡭࠴࠺࠲࠸࠵࠸ࠫ੤")):
    url=l1111ll11_af_+l111lll1l_af_
    try:
        content = l111lll11_af_(url)
        name = re.findall(l1lll_af_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠦࡵࠥࡂࡁࡹࡴࡳࡱࡱ࡫ࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃ࠭੥")%l111lll1l_af_,content)
        l1111l111_af_ =  re.findall(l1lll_af_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠱ࡤࡺࡦࡺࡡࡳࡵ࠲࠲࠯ࡅࠩࠣࠩ੦"),content)
        l1111l111_af_ = l1111l111_af_[0] if l1111l111_af_ else l1lll_af_ (u"ࠪ࠳ࡨࡹࡳ࠰࡫ࡰࡥ࡬࡫ࡳ࠰ࡰࡲࡥࡻࡧࡴࡢࡴ࠱࡮ࡵ࡭ࠧ੧")
        l111l1111_af_= re.findall(l1lll_af_ (u"ࠫࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࡜ࡥ࠭ࠬࡀ࠴ࡹࡴࡳࡱࡱ࡫ࡃࡂࡢࡳࡀ࡙࡭ࡩ࡫࡯ࡴ࠾࠲ࡥࡃࡂ࠯࡭࡫ࡁࠫ੨"),content)
        l11ll111l_af_= re.findall(l1lll_af_ (u"ࠬࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࡝ࡦ࠮࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄ࠼ࡣࡴࡁࡔࡱࡧࡹ࡭࡫ࡶࡸࡁ࠵ࡡ࠿࠾࠲ࡰ࡮ࡄࠧ੩"),content)
        l111ll11l_af_= re.findall(l1lll_af_ (u"࠭࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࡞ࡧ࠯࠮ࡂ࠯ࡴࡶࡵࡳࡳ࡭࠾࠽ࡤࡵࡂࡑ࡯࡫ࡦࡵ࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠬ੪"),content)
        l1111l1ll_af_= re.findall(l1lll_af_ (u"ࠧ࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࡟ࡨ࠰࠯࠼࠰ࡵࡷࡶࡴࡴࡧ࠿࠾ࡥࡶࡃ࡙ࡵࡣࡵࡦࡶ࡮ࡨࡥ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠪ੫"),content)
        l11l1l1l1_af_ = re.findall(l1lll_af_ (u"ࠨ࠾ࡶࡴࡦࡴࠠࡤ࡮ࡤࡷࡸࡃࠢ࡯ࡣࡹࡦࡦࡸ࠭ࡳ࡫ࡪ࡬ࡹࠨࠠࡴࡶࡼࡰࡪࡃࠢ࡮ࡣࡵ࡫࡮ࡴ࠺ࠡ࠵ࡳࡼࠥ࠶ࡰࡹࠢ࠳ࡴࡽࠦ࠰ࡱࡺ࠾ࠦࡃࡂࡳ࡮ࡣ࡯ࡰࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹ࡭ࡢ࡮࡯ࡂࡁ࠵ࡳࡱࡣࡱࡂࠬ੬"),content)
        l11l1lll1_af_=re.findall(l1lll_af_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡪࡰࡾࡶࡨࡪࡥࡲࡲࠥ࡭࡬ࡺࡲ࡫࡭ࡨࡵ࡮࠮ࡵࡷࡥࡹࡹࠢ࠿࠾࠲ࡷࡵࡧ࡮࠿࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭੭"),content)
        l11l1lll1_af_=l11l1lll1_af_[0].split(l1lll_af_ (u"ࠪ࠿ࠬ੮"))[-1] if l11l1lll1_af_ else l1lll_af_ (u"ࠫࠬ੯")
        data = {
            l1lll_af_ (u"ࠬࡻࡳࡦࡴࡱࡥࡲ࡫ࠧੰ"):name[0][-1],
            l1lll_af_ (u"࠭ࡵࡴࡧࡵࡣࡱ࡯࡮࡬ࠩੱ"):l111lll1l_af_,
            l1lll_af_ (u"ࠧࡪࡦࡸࡾࠬੲ"):l111lll1l_af_.split(l1lll_af_ (u"ࠨ࠱ࠪੳ"))[-1],
            l1lll_af_ (u"ࠩ࡬ࡱ࡬࠭ੴ"):urlparse.urljoin(l1111ll11_af_,l1111l111_af_) if l1111l111_af_ else l1lll_af_ (u"ࠪࠫੵ"),
            l1lll_af_ (u"࡛ࠫ࡯ࡤࡦࡱࡶࠫ੶"):l111l1111_af_[0] if l111l1111_af_ else l1lll_af_ (u"ࠬ࠭੷"),
            l1lll_af_ (u"࠭ࡐ࡭ࡣࡼࡰ࡮ࡹࡴࠨ੸"):l11ll111l_af_[0] if l11ll111l_af_ else l1lll_af_ (u"ࠧࠨ੹"),
            l1lll_af_ (u"ࠨ࡬ࡲ࡭ࡳ࡫ࡤࠨ੺"):l11l1l1l1_af_[0] if l11l1l1l1_af_ else l1lll_af_ (u"ࠩࠪ੻"),
            l1lll_af_ (u"ࠪࡺ࡮ࡪࡥࡰࡡࡹ࡭ࡪࡽࡳࠨ੼"):l11l1lll1_af_,
            }
    except:
        data={}
    return data
def l11l111l1_af_(fname=l1lll_af_ (u"ࡶࠬࡊ࠺࡝ࡷࡶࡩࡷࡹࡲ࠯࡬ࡶࡳࡳ࠭੽")):
    l1l111ll_af_ = l1ll11l_af_(fname)
    return l1l111ll_af_
def l1lll11_af_(l1l111ll_af_):
    out=[]
    for data in l1l111ll_af_:
        out.append(l1111l1l1_af_(data))
    return out
def l1111l1l1_af_(data,l111l1ll1_af_=False):
    title = l1lll_af_ (u"ࠬࠫࡳࠡ࡝ࡹ࡭ࡩ࡫࡯ࡴ࠼࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝࡜ࡄࡠࠩࡸࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠤࡵࡲࡡࡺ࡮࡬ࡷࡹࡹ࠺࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࡡࡂ࡞ࠧࡶ࡟࠴ࡈ࡝࡜࠱ࡆࡓࡑࡕࡒ࡞࡟ࠪ੾")%(data.get(l1lll_af_ (u"࠭ࡵࡴࡧࡵࡲࡦࡳࡥࠨ੿"),l1lll_af_ (u"ࠧࡀࠩ઀")),data.get(l1lll_af_ (u"ࠨࡘ࡬ࡨࡪࡵࡳࠨઁ"),-1),data.get(l1lll_af_ (u"ࠩࡓࡰࡦࡿ࡬ࡪࡵࡷࠫં"),-1))
    l1l1111_af_ = data
    l1l1111_af_[l1lll_af_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩઃ")]=title
    if l111l1ll1_af_: l1l1111_af_[l1lll_af_ (u"ࠫࡤࡹ࡫ࡪࡲࠪ઄")]=False
    return l1l1111_af_
def l11l1llll_af_(l111ll1l1_af_,fname):
    l1l111ll_af_ = l1ll11l_af_(fname)
    l1ll1lll_af_ = False
    for l1l1111_af_ in l1l111ll_af_:
        if l111ll1l1_af_ in l1l1111_af_.get(l1lll_af_ (u"ࠬ࡯ࡤࡶࡼࠪઅ")):
            l1ll1lll_af_=True
            break
    return l1ll1lll_af_
def l1lll1ll_af_(data,fname):
    l1l111ll_af_ = l1ll11l_af_(fname)
    l111ll1l1_af_ = data.get(l1lll_af_ (u"࠭ࡩࡥࡷࡽࠫઆ"))
    l1ll1lll_af_ = False
    for l1l1111_af_ in l1l111ll_af_:
        if l111ll1l1_af_ in l1l1111_af_.get(l1lll_af_ (u"ࠧࡪࡦࡸࡾࠬઇ")):
            l1ll1lll_af_=True
            l1l1111_af_.update(data)
            l11l11111_af_(l1l111ll_af_,fname)
            break
    return l1ll1lll_af_
def l1lll111_af_(data,fname):
    l1l111ll_af_ = l1ll11l_af_(fname)
    l1l111ll_af_.append(data)
    l11l11111_af_(l1l111ll_af_,fname)
def l1ll1l1_af_(l111ll1l1_af_,fname):
    l1l111ll_af_ = l1ll11l_af_(fname)
    l11ll1111_af_=[]
    for i in xrange(len(l1l111ll_af_)):
        if l111ll1l1_af_ in l1l111ll_af_[i].get(l1lll_af_ (u"ࠨ࡫ࡧࡹࡿ࠭ઈ")):
            l11ll1111_af_.append(i)
    if l11ll1111_af_:
        for i in reversed(l11ll1111_af_):
            l1l111ll_af_.pop(i)
        l11l11111_af_(l1l111ll_af_,fname)
        return True
    else:
        return False
def l11l1l111_af_(l111lll1l_af_,fname):
    l1111llll_af_={}
    l1l111ll_af_ = l1ll11l_af_(fname)
    for data in l1l111ll_af_:
        if l111lll1l_af_ in data.get(l1lll_af_ (u"ࠩࡸࡷࡪࡸ࡟࡭࡫ࡱ࡯ࠬઉ")):
            data.update(l1l1lll1_af_(l111lll1l_af_))
            l1111llll_af_=l1111l1l1_af_(data)
            l11l11111_af_(l1l111ll_af_,fname)
            break;
    return l1111llll_af_
def l1ll11l_af_(fname):
    content = l1lll_af_ (u"ࠪ࡟ࡢ࠭ઊ")
    if fname.startswith(l1lll_af_ (u"ࠫ࡭ࡺࡴࡱࠩઋ")):
        content = l111lll11_af_(fname)
    elif os.path.exists(fname):
        with open(fname,l1lll_af_ (u"ࠬࡸࠧઌ")) as f:
            content = f.read()
            if not content:
                content =l1lll_af_ (u"࡛࠭࡞ࠩઍ")
    data=json.loads(content)
    return data
def l11l11111_af_(l1l111ll_af_,l11ll11ll_af_):
    with open(l11ll11ll_af_, l1lll_af_ (u"ࠧࡸࠩ઎")) as l111l1lll_af_:
       json.dump(l1l111ll_af_, l111l1lll_af_, indent=2, sort_keys=True)
