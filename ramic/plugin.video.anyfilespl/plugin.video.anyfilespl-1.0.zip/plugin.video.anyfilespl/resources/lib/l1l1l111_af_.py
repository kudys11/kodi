# -*- coding: utf-8 -*-
import sys
l1ll_af_ = sys.version_info [0] == 2
l111l_af_ = 2048
l111_af_ = 7
def l1lll_af_ (ll_af_):
	global l1ll11_af_
	l1l11l_af_ = ord (ll_af_ [-1])
	l11l1_af_ = ll_af_ [:-1]
	l1l_af_ = l1l11l_af_ % len (l11l1_af_)
	l11_af_ = l11l1_af_ [:l1l_af_] + l11l1_af_ [l1l_af_:]
	if l1ll_af_:
		l1lll1_af_ = unicode () .join ([unichr (ord (char) - l111l_af_ - (l11ll_af_ + l1l11l_af_) % l111_af_) for l11ll_af_, char in enumerate (l11_af_)])
	else:
		l1lll1_af_ = str () .join ([chr (ord (char) - l111l_af_ - (l11ll_af_ + l1l11l_af_) % l111_af_) for l11ll_af_, char in enumerate (l11_af_)])
	return eval (l1lll1_af_)
import urllib2,urllib
import re,random,json
import cookielib
l11l11ll1_af_=10
l11111l1l_af_=l1lll_af_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡏࡘ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠸࠴࠳࠶࠮࠳࠸࠹࠵࠳࠷࠰࠳ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩୀ")
def l111lll11_af_(url,data=None,header={},l1ll11lll1_af_=True):
    l1ll1ll1_af_=l1lll_af_ (u"ࠫࠬୁ")
    l11l1ll11_af_=[]
    if l1ll11lll1_af_:
        l11l1ll11_af_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l11l1ll11_af_))
        urllib2.install_opener(opener)
    if not header:
        header = {l1lll_af_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩୂ"):l11111l1l_af_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l11l11ll1_af_)
        l1l11111_af_ =  response.read()
        response.close()
        l1ll1ll1_af_ = l1lll_af_ (u"࠭ࠧୃ").join([l1lll_af_ (u"ࠧࠦࡵࡀࠩࡸࡁࠧୄ")%(c.name, c.value) for c in l11l1ll11_af_])
    except urllib2.HTTPError as e:
        l1l11111_af_ = l1lll_af_ (u"ࠨࠩ୅")
    return l1l11111_af_,l1ll1ll1_af_
def l1llll1l1l_af_(url):
    url = url.replace(l1lll_af_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ୆"),l1lll_af_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪେ")).replace(l1lll_af_ (u"ࠫ࠴࡫࡭ࡣࡧࡧ࠳ࠬୈ"),l1lll_af_ (u"ࠬ࠵࠿ࡷ࠿ࠪ୉"))
    content,c = l111lll11_af_(url)
    match = re.findall(l1lll_af_ (u"࠭ࠧࠨ࡝ࠥࠫࡢࡅࡳࡰࡷࡵࡧࡪࡹ࡛ࠨࠤࡠࡃࡡࡹࠪ࠻࡞ࡶ࠮࠭ࡢ࡛࠯ࠬࡂࡠࡢ࠯ࠧࠨࠩ୊"), content)
    l1ll11llll_af_=l1lll_af_ (u"ࠧࠨୋ")
    if not match:
        data = {}
        data[l1lll_af_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮࠰ࡼࠫୌ")] = random.randint(0, 120)
        data[l1lll_af_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯࠱ࡼ୍ࠬ")] = random.randint(0, 120)
        header={l1lll_af_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ୎"):l11111l1l_af_,l1lll_af_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ୏"):url}
        l1ll1l111l_af_ = url + l1lll_af_ (u"ࠬࠩࠧ୐")
        content,c = l111lll11_af_(l1ll1l111l_af_,urllib.urlencode(data),header=header)
        match = re.findall(l1lll_af_ (u"࠭ࠧࠨ࡝ࠥࠫࡢࡅࡳࡰࡷࡵࡧࡪࡹ࡛ࠨࠤࡠࡃࡡࡹࠪ࠻࡞ࡶ࠮࠭ࡢ࡛࠯ࠬࡂࡠࡢ࠯ࠧࠨࠩ୑"), content)
    if match:
        print match
        try:
            data = json.loads(match[0])
            l1ll11llll_af_=[]
            for d in data:
                if isinstance(d,dict):
                    l1ll1l1111_af_ = d.get(l1lll_af_ (u"ࠧࡧ࡫࡯ࡩࠬ୒"),l1lll_af_ (u"ࠨࠩ୓"))+l1lll_af_ (u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠦࡵࠩࡖࡪ࡬ࡥࡳࡧࡵࡁࠪࡹࠧ୔")%(l11111l1l_af_,url)
                    l1ll11llll_af_.append((d.get(l1lll_af_ (u"ࠪࡰࡦࡨࡥ࡭ࠩ୕"),l1lll_af_ (u"ࠫࠬୖ")),l1ll1l1111_af_))
        except:
            l1ll11llll_af_ = re.findall(l1lll_af_ (u"ࠬ࠭ࠧ࡜ࠩࠥࡡࡄ࡬ࡩ࡭ࡧ࡞ࠫࠧࡣ࠿࡝ࡵ࠭࠾ࡡࡹࠪ࡜ࠩࠥࡡࡄ࠮࡛࡟ࠩࠥࡡ࠰࠯ࠧࠨࠩୗ"), match[0])
            if l1ll11llll_af_:
                l1ll11llll_af_ = l1ll11llll_af_[0].replace(l1lll_af_ (u"࠭࡜࠰ࠩ୘"), l1lll_af_ (u"ࠧ࠰ࠩ୙"))
                l1ll11llll_af_ += l1lll_af_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠥࡴࠨࡕࡩ࡫࡫ࡲࡦࡴࡀࠩࡸ࠭୚")%(l11111l1l_af_,url)
    return l1ll11llll_af_
