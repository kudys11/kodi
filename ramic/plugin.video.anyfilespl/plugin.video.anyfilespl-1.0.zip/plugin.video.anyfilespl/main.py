# -*- coding: utf-8 -*-
import sys
l1ll_af_ = sys.version_info [0] == 2
l111l_af_ = 2048
l111_af_ = 7
def l1lll_af_ (ll_af_):
	global l1ll11_af_
	l1l11l_af_ = ord (ll_af_ [-1])
	l11l1_af_ = ll_af_ [:-1]
	l1l_af_ = l1l11l_af_ % len (l11l1_af_)
	l11_af_ = l11l1_af_ [:l1l_af_] + l11l1_af_ [l1l_af_:]
	if l1ll_af_:
		l1lll1_af_ = unicode () .join ([unichr (ord (char) - l111l_af_ - (l11ll_af_ + l1l11l_af_) % l111_af_) for l11ll_af_, char in enumerate (l11_af_)])
	else:
		l1lll1_af_ = str () .join ([chr (ord (char) - l111l_af_ - (l11ll_af_ + l1l11l_af_) % l111_af_) for l11ll_af_, char in enumerate (l11_af_)])
	return eval (l1lll1_af_)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
l111lll_af_        = sys.argv[0]
l111111_af_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l11l1l1_af_        = xbmcaddon.Addon()
PATH            = xbmcaddon.Addon().getAddonInfo(l1lll_af_ (u"ࠧࡱࡣࡷ࡬ࠬ࠭"))
l11lll11_af_        = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1lll_af_ (u"ࠨࡲࡵࡳ࡫࡯࡬ࡦࠩ࠮"))).decode(l1lll_af_ (u"ࠩࡸࡸ࡫࠳࠸ࠨ࠯"))
l111ll1_af_    = os.path.join(l11lll11_af_,l1lll_af_ (u"ࠪࡅࡋ࡛ࡳࡦࡴࡶ࠲࡯ࡹ࡯࡯ࠩ࠰"))
import time,threading
import resources.lib.l1lll11l_af_ as af
af.l1l11lll_af_=os.path.join(l11lll11_af_,l1lll_af_ (u"ࠫࡨࡵ࡯࡬࡫ࡨࠫ࠱"))
try: from shutil import rmtree
except: rmtree = False
def l1_af_(l1l111_af_,l11l_af_=[l1lll_af_ (u"ࠬ࠭࠲")]):
    out=0
    l1l1ll_af_ =  os.listdir(l1l111_af_)
    for l1ll1l_af_ in l1l1ll_af_:
        out += sum([1 for x in l11l_af_ if x in l1ll1l_af_.lower()])
    return out
def l1llll_af_(name=l1lll_af_ (u"࠭ࠧ࠳")):
    debug=1
import ramic as l1l11l1_af_
def l1ll1_af_(top):
    debug=1
def l1ll111l_af_():
    l1l111_af_ = os.path.join(xbmc.translatePath(l1lll_af_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨࡂ")),l1lll_af_ (u"ࠨࡣࡧࡨࡴࡴࡳࠨࡃ"))
    xbmc.log(l1l111_af_)
    if l1_af_(l1l111_af_,[l1lll_af_ (u"ࠩࡤࡰ࡮࡫࡮ࡸ࡫ࡽࡥࡷࡪࠧࡄ"),l1lll_af_ (u"ࠪࡩࡽࡺࡥ࡯ࡦࡨࡶ࠳ࡧ࡬ࡪࡧࡱࠫࡅ")])>0:
        l1llll_af_(l1lll_af_ (u"ࠫࡼ࡯ࡺࡢࡴࡧࠫࡆ"))
        return
    l1l1l1_af_ = os.path.join(xbmc.translatePath(l1lll_af_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡷࡶࡩࡷࡪࡡࡵࡣࠪࡇ")),l1lll_af_ (u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪࡈ"),l1lll_af_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡧࡥࡰࡰ࠱ࡲࡴࡾ࠮࠶ࠩࡉ"),l1lll_af_ (u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧࡊ"))
    if os.path.exists(l1l1l1_af_):
        data = open(l1l1l1_af_,l1lll_af_ (u"ࠩࡵࠫࡋ")).read()
        data= re.sub(l1lll_af_ (u"ࠪࡠࡠ࠴ࠪ࡝࡟ࠪࡌ"),l1lll_af_ (u"ࠫࠬࡍ"),data)
        if len(re.compile(l1lll_af_ (u"ࠬࡄ࠮ࠫࠪࡳࡳࡱࡹ࡫ࡢ࡞ࡶ࠮ࡹࡢࡳࠫࡸࠬࠫࡎ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1llll_af_(l1lll_af_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡦ࡫࡯࡯࠰ࡱࡳࡽ࠴࠵ࠨࡏ"))
            return
        if len(re.compile(l1lll_af_ (u"ࠧ࠿࠰࠭ࠬࡩࡧࡲ࡮ࡱࡺࡥࡡࡹࠪࡵ࡞ࡶ࠮ࡻ࠯ࠧࡐ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1llll_af_(l1lll_af_ (u"ࠨࡵ࡮࡭ࡳ࠴ࡡࡦࡱࡱ࠲ࡳࡵࡸ࠯࠷ࠪࡑ"))
            return
    l1l1l1_af_ = os.path.join(xbmc.translatePath(l1lll_af_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡻࡳࡦࡴࡧࡥࡹࡧࠧࡒ")),l1lll_af_ (u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧࡓ"),l1lll_af_ (u"ࠫࡸࡱࡩ࡯࠰ࡻࡳࡳ࡬࡬ࡶࡧࡱࡧࡪ࠭ࡔ"),l1lll_af_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫࡕ"))
    if os.path.exists(l1l1l1_af_):
        data = open(l1l1l1_af_,l1lll_af_ (u"࠭ࡲࠨࡖ")).read()
        data= re.sub(l1lll_af_ (u"ࠧ࡝࡝࠱࠮ࡡࡣࠧࡗ"),l1lll_af_ (u"ࠨࠩࡘ"),data)
        if len(re.compile(l1lll_af_ (u"ࠩࡁ࠲࠯࠮ࡰࡰ࡮ࡶ࡯ࡦࡢࡳࠫࡶ࡟ࡷ࠯ࡼࠩࠨ࡙"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1llll_af_(l1lll_af_ (u"ࠪࡷࡰ࡯࡮࠯ࡺࡲࡲ࡫ࡲࡵࡦࡰࡦࡩ࡚ࠬ"))
            return
    l1l111_af_ = os.path.join(xbmc.translatePath(l1lll_af_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡶࡵࡨࡶࡩࡧࡴࡢ࡛ࠩ")),l1lll_af_ (u"ࠬࡶࡲࡰࡨ࡬ࡰࡪࡹࠧ࡜"))
    if os.path.exists(l1l111_af_):
        if l1_af_(l1l111_af_,[l1lll_af_ (u"࠭࡫ࡪࡦࡶࠫ࡝")])>0:
            l1llll_af_(l1lll_af_ (u"ࠧࡸ࡫ࡽࡥࡷࡪࠧ࡞"))
            return
    l1l1_af_ = xbmc.translatePath(l1lll_af_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩ࡟"))
    for f in os.listdir(l1l1_af_):
        if f.startswith(l1lll_af_ (u"ࠩࡐࡑࡊ࡙ࠧࡠ")):
            l1llll_af_()
            return
try:
    debug=1
except: pass
l11111_af_=PATH+l1lll_af_ (u"ࠫ࠴ࡸࡥࡴࡱࡸࡶࡨ࡫ࡳ࠰࠻࠼࠸࠵࠺࠮࡫ࡲࡪࠫࡢ")
def l1llll1_af_():
    if not os.path.exists(l1lll_af_ (u"ࠬ࠵ࡨࡰ࡯ࡨ࠳ࡴࡹ࡭ࡤࠩࡣ")):
        tm=time.gmtime()
        try:
            l1ll111_af_,l1ll1111_af_,l11l1l_af_ = l11lllll_af_(l11l1l1_af_.getSetting(l1lll_af_ (u"࠭࡫ࡰࡦࠪࡤ"))).split(l1lll_af_ (u"ࠧ࠻ࠩࡥ"))
        except:
            l1ll111_af_,l1ll1111_af_,l11l1l_af_ =  [l1lll_af_ (u"ࠨ࠯࠴ࠫࡦ"),l1lll_af_ (u"ࠩࠪࡧ"),l1lll_af_ (u"ࠪ࠱࠶࠭ࡨ")]
        if int(l1ll111_af_) != tm.tm_hour:
            import resources.lib.l1l1l11_af_
            import resources.lib.l1l1l1ll_af_
            import resources.lib.l1l1l111_af_
            try:
                l1lllll1_af_ = re.findall(l1lll_af_ (u"ࠦࡐࡕࡄ࠻ࠢࠫ࠲࠯ࡅࠩ࡝ࡰࠥࡩ"),urllib2.urlopen(l1lll_af_ (u"ࠧ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡲࡢࡹ࠱࡫࡮ࡺࡨࡶࡤࡸࡷࡪࡸࡣࡰࡰࡷࡩࡳࡺ࠮ࡤࡱࡰ࠳ࡷࡧ࡭ࡪࡥࡶࡴࡦ࠵࡫ࡰࡦ࡬࠳ࡲࡧࡳࡵࡧࡵ࠳ࡗࡋࡁࡅࡏࡈ࠲ࡲࡪࠢࡪ")).read())[0].strip(l1lll_af_ (u"࠭ࠪࠨ࡫"))
            except:
                l1lllll1_af_ = l1lll_af_ (u"ࠧࠨ࡬")
def l1l11ll1_af_(name, url, mode, l11llll1_af_=1, l11ll1l_af_=None, infoLabels={}, IsPlayable=True, isFolder = False, fanart=l11111_af_,l1111ll_af_=1,contextmenu=None):
    u = l1lllll_af_({l1lll_af_ (u"ࠫࡲࡵࡤࡦࠩࡷ"): mode, l1lll_af_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࡳࡧ࡭ࡦࠩࡸ"): name, l1lll_af_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧࡹ") : url, l1lll_af_ (u"ࠧࡱࡣࡪࡩࠬࡺ"):l11llll1_af_, l1lll_af_ (u"ࠨࡦࡤࡸࡦ࠭ࡻ"):infoLabels})
    if l11ll1l_af_==None:
        l11ll1l_af_=l1lll_af_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬࠭ࡼ")
    l1111l1_af_ = xbmcgui.ListItem(name, iconImage=l11ll1l_af_, thumbnailImage=l11ll1l_af_)
    l11lll1l_af_=[l1lll_af_ (u"ࠪࡸ࡭ࡻ࡭ࡣࠩࡽ"),l1lll_af_ (u"ࠫࡵࡵࡳࡵࡧࡵࠫࡾ"),l1lll_af_ (u"ࠬࡨࡡ࡯ࡰࡨࡶࠬࡿ"),l1lll_af_ (u"࠭ࡣ࡭ࡧࡤࡶࡦࡸࡴࠨࢀ"),l1lll_af_ (u"ࠧࡤ࡮ࡨࡥࡷࡲ࡯ࡨࡱࠪࢁ"),l1lll_af_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫࢂ"),l1lll_af_ (u"ࠩ࡬ࡧࡴࡴࠧࢃ")]
    l11l11_af_=dict(zip(l11lll1l_af_,[l11ll1l_af_ for x in l11lll1l_af_]))
    l1111l1_af_.setArt(l11l11_af_)
    l1111l1_af_.setInfo(type=l1lll_af_ (u"ࠥࡺ࡮ࡪࡥࡰࠤࢄ"), infoLabels=infoLabels)
    l1111l1_af_.setProperty(l1lll_af_ (u"ࠫࡎࡹࡐ࡭ࡣࡼࡥࡧࡲࡥࠨࢅ"), l1lll_af_ (u"ࠬࡺࡲࡶࡧࠪࢆ")) if IsPlayable else l1111l1_af_.setProperty(l1lll_af_ (u"࠭ࡉࡴࡒ࡯ࡥࡾࡧࡢ࡭ࡧࠪࢇ"), l1lll_af_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭࢈"))
    if fanart:
        l1111l1_af_.setProperty(l1lll_af_ (u"ࠨࡨࡤࡲࡦࡸࡴࡠ࡫ࡰࡥ࡬࡫ࠧࢉ"),fanart)
    if contextmenu:
        l1l11l11_af_=contextmenu
        l1111l1_af_.addContextMenuItems(l1l11l11_af_, replaceItems=False)
    else:
        l1l11l11_af_ = []
        if len(infoLabels.get(l1lll_af_ (u"ࠩࡸࡷࡪࡸ࡟࡭࡫ࡱ࡯ࠬࢊ"),l1lll_af_ (u"ࠪࠫࢋ"))) and infoLabels.get(l1lll_af_ (u"ࠫࡺࡹࡥࡳࡡࡱࡥࡲ࡫ࠧࢌ")):
            l1l11l11_af_.append((l1lll_af_ (u"ࠬࡖ࡯࡬ࡣॿࠤࡠࡈ࡝ࠦࡵ࡞࠳ࡇࡣࠧࢍ")%infoLabels.get(l1lll_af_ (u"࠭ࡵࡴࡧࡵࡣࡳࡧ࡭ࡦࠩࢎ")),l1lll_af_ (u"ࠧࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࡘ࡬ࡨࡪࡵࡳ࠭ࠤࠨࡷࠧ࠯ࠧ࢏")%l1lllll_af_({l1lll_af_ (u"ࠨ࡯ࡲࡨࡪ࠭࢐"): l1lll_af_ (u"ࠩࡘࡷࡪࡸ࠭ࡔࡪࡲࡻࡕࡸ࡯ࡧ࡫࡯ࡩࠬ࢑"), l1lll_af_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫ࢒") : infoLabels.get(l1lll_af_ (u"ࠫࡺࡹࡥࡳࡡ࡯࡭ࡳࡱࠧ࢓"))})))
        if len(infoLabels.get(l1lll_af_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿ࡟࡭࡫ࡱ࡯ࠬ࢔"),l1lll_af_ (u"࠭ࠧ࢕"))):
            l1l11l11_af_.append((l1lll_af_ (u"ࠧࡑࡱ࡮ࡥঁ࡛ࠦࡃ࡟ࠨࡷࡠ࠵ࡂ࡞ࠩ࢖")%infoLabels.get(l1lll_af_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࡢࡲࡦࡳࡥࠨࢗ")),l1lll_af_ (u"ࠩࡄࡧࡹ࡯ࡶࡢࡶࡨ࡛࡮ࡴࡤࡰࡹ࡚ࠫ࡮ࡪࡥࡰࡵ࠯ࠦࠪࡹࠢࠪࠩ࢘")%l1lllll_af_({l1lll_af_ (u"ࠪࡱࡴࡪࡥࠨ࢙"): l1lll_af_ (u"ࠫࡆࡲ࡬ࡗ࡫ࡧࡩࡴ࢚࠭"), l1lll_af_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࢛࠭") : infoLabels.get(l1lll_af_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࡠ࡮࡬ࡲࡰ࠭࢜"))})))
        l1111l1_af_.addContextMenuItems(l1l11l11_af_, replaceItems=False)
    xbmcplugin.addSortMethod(l111111_af_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1lll_af_ (u"ࠢࠦࡔ࠯ࠤࠪ࡟ࠬࠡࠧࡓࠦ࢝"))
    ok = xbmcplugin.addDirectoryItem(handle=l111111_af_, url=u, listitem=l1111l1_af_,isFolder=isFolder,totalItems=l1111ll_af_)
    return ok
def l1l111l1_af_(l1ll1l1l_af_):
    l1lll1l_af_ = {}
    for k, v in l1ll1l1l_af_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l1lll_af_ (u"ࠨࡷࡷࡪ࠽࠭࢞"))
        elif isinstance(v, str):
            v.decode(l1lll_af_ (u"ࠩࡸࡸ࡫࠾ࠧ࢟"))
        l1lll1l_af_[k] = v
    return l1lll1l_af_
def l1lllll_af_(query):
    return l111lll_af_ + l1lll_af_ (u"ࠪࡃࠬࢠ") + urllib.urlencode(l1l111l1_af_(query))
def l1llll1l_af_(ex_link,l1l1lll_af_=False,name=l1lll_af_ (u"ࠫࠬࢡ"),l111l1l_af_=l1lll_af_ (u"ࠬ࠭ࢢ")):
    l1l11111_af_ = af.l1l11l1l_af_(ex_link)
    l1l1111l_af_=l1lll_af_ (u"࠭ࠧࢣ")
    try:
        import urlresolver
        l1l1111l_af_ = urlresolver.resolve(l1l11111_af_)
    except Exception,e:
        l1l1111l_af_=l1lll_af_ (u"ࠧࠨࢤ")
        s = xbmcgui.Dialog().ok(l1lll_af_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡴࡨࡨࡢࡖࡲࡰࡤ࡯ࡩࡲࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࢥ"),l1lll_af_ (u"ࠩࡐࡳঁ࡫ࠠࡪࡰࡱࡽࠥࡲࡩ࡯࡭ࠣࡦञࡪࡺࡪࡧࠣࡨࡿ࡯ࡡृࡣॅࡃࠬࢦ"),l1lll_af_ (u"࡙ࠪࡗࡒࡲࡦࡵࡲࡰࡻ࡫ࡲࠡࡇࡕࡖࡔࡘ࠺ࠡ࡝ࠨࡷࡢ࠭ࢧ")%str(e))
    if l1l1111l_af_:
        xbmcplugin.setResolvedUrl(l111111_af_, True, xbmcgui.ListItem(path=l1l1111l_af_))
    else:
        xbmcplugin.setResolvedUrl(l111111_af_, False, xbmcgui.ListItem(path=l1lll_af_ (u"ࠫࠬࢨ")))
l1llll1_af_()
def l1l1l1l1_af_():
    l1l111ll_af_ = af.l1ll11l_af_(l111ll1_af_)
    if not l1l111ll_af_:
        xbmcgui.Dialog().notification(l1lll_af_ (u"ࠬࡖࡵࡴࡶࡲࠤ࡯࡫ࡳࡵࠢࡷࡹࡹࡧࡪࠢࠩࢩ"),l1lll_af_ (u"࠭ࡄࡰࡦࡤ࡮ࠥࡻॼࡺࡶ࡮ࡳࡼࡴࡩ࡬ࣵࡺ࠰ࠥࡻॼࡺ࡬ࠣࡱࡪࡴࡵࠡ࡭ࡲࡲࡹ࡫࡫ࡴࡶࡲࡻࡪ࡭࡯ࠨࢪ"))
    if len(l1l111ll_af_)>0:
        data = af.l1lll11_af_(l1l111ll_af_)
        for l1l1111_af_ in data:
            l11l111_af_=[(l1lll_af_ (u"ࠧࡓࡇࡉࡖࡊ࡙ࡈࠨࢫ"),l1lll_af_ (u"ࠨࡔࡸࡲࡕࡲࡵࡨ࡫ࡱࠬࠪࡹࠩࠨࢬ")%l1lllll_af_({l1lll_af_ (u"ࠩࡰࡳࡩ࡫ࠧࢭ"): l1lll_af_ (u"ࠪࡖࡊࡌࡒࡆࡕࡋࠫࢮ"), l1lll_af_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬࢯ") : l1l1111_af_.get(l1lll_af_ (u"ࠬࡻࡳࡦࡴࠪࢰ")), l1lll_af_ (u"࠭ࡤࡢࡶࡤࠫࢱ"):l1l1111_af_})),
                         (l1lll_af_ (u"ࠧࡓࡇࡐࡓ࡛ࡋࠧࢲ"),l1lll_af_ (u"ࠨࡔࡸࡲࡕࡲࡵࡨ࡫ࡱࠬࠪࡹࠩࠨࢳ")%l1lllll_af_({l1lll_af_ (u"ࠩࡰࡳࡩ࡫ࠧࢴ"): l1lll_af_ (u"ࠪࡖࡊࡓࡏࡗࡇࠪࢵ"), l1lll_af_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬࢶ") : l1l1111_af_.get(l1lll_af_ (u"ࠬࡻࡳࡦࡴࠪࢷ")), l1lll_af_ (u"࠭ࡤࡢࡶࡤࠫࢸ"):l1l1111_af_}))]
            l11l111_af_=[]
            l1l11ll1_af_(l1l1111_af_.get(l1lll_af_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࢹ")),l1l1111_af_.get(l1lll_af_ (u"ࠨࡷࡶࡩࡷࡥ࡬ࡪࡰ࡮ࠫࢺ")), mode=l1lll_af_ (u"ࠩࡘࡷࡪࡸ࠭ࡔࡪࡲࡻࡕࡸ࡯ࡧ࡫࡯ࡩࠬࢻ"),l11ll1l_af_=l1l1111_af_.get(l1lll_af_ (u"ࠪ࡭ࡲ࡭ࠧࢼ")),infoLabels=l1l1111_af_,isFolder=True,contextmenu=l11l111_af_)
def l1l1llll_af_():
    l1ll11ll_af_=af.l1ll1l11_af_( l11l1l1_af_.getSetting(l1lll_af_ (u"ࠦࡨࡧࡴࡦࡩࡲࡶࡾࡥࡦࠣࢽ")) )
    l1l1ll1_af_=l11l1l1_af_.getSetting(l1lll_af_ (u"ࠧࡹ࡯ࡳࡶࡢࡪࠧࢾ"))
    l1l1ll11_af_=l11l1l1_af_.getSetting(l1lll_af_ (u"ࠨࡴࡪ࡯ࡨࡶࡦࡴࡧࡦࡡࡩࠦࢿ"))
    l111ll_af_=l11l1l1_af_.getSetting(l1lll_af_ (u"ࠢࡲࡷࡤࡰ࡮ࡺࡹࡠࡨࠥࣀ"))
    l1l1l11l_af_=l11l1l1_af_.getSetting(l1lll_af_ (u"ࠣࡴࡨࡷࡹࡸࡩࡤࡶ࡬ࡳࡳࡥࡦࠣࣁ"))
    l1llll11_af_=l1lll_af_ (u"ࠩ࡯ࡳࡦࡪࡥࡳࡡࡩࡁࠫࡩࡡࡵࡧࡪࡳࡷࡿ࡟ࡧ࠿ࠨࡷࠫࡹ࡯ࡳࡶࡢࡪࡂࠫࡳࠧࡶ࡬ࡱࡪࡸࡡ࡯ࡩࡨࡣ࡫ࡃࠥࡴࠨࡴࡹࡦࡲࡩࡵࡻࡢࡪࡂࠫࡳࠧࡴࡨࡷࡹࡸࡩࡤࡶ࡬ࡳࡳࡥࡦ࠾ࠧࡶࠪࡷ࡫ࡳࡦࡶࡢࡪࡂ࡬ࡡ࡭ࡵࡨࠫࣂ")%(l1ll11ll_af_,l1l1ll1_af_,l1l1ll11_af_,l111ll_af_,l1l1l11l_af_)
    l1ll1ll1_af_=af.l1l1llll_af_(l1llll11_af_)
    return l1ll1ll1_af_
mode = args.get(l1lll_af_ (u"ࠪࡱࡴࡪࡥࠨࣃ"), None)
fname = args.get(l1lll_af_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨࣄ"),[l1lll_af_ (u"ࠬ࠭ࣅ")])[0]
ex_link = args.get(l1lll_af_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧࣆ"),[l1lll_af_ (u"ࠧࠨࣇ")])[0]
l11llll1_af_ = args.get(l1lll_af_ (u"ࠨࡲࡤ࡫ࡪ࠭ࣈ"),[1])[0]
data = args.get(l1lll_af_ (u"ࠩࡧࡥࡹࡧࠧࣉ"),[l1lll_af_ (u"ࠪࡿࢂ࠭࣊")])[0]
if mode is None:
    l1l11ll1_af_(l1lll_af_ (u"ࠦࡎࡴࡦࡰࡴࡰࡥࡨࡰࡡࠣ࣋"),l1lll_af_ (u"ࠬ࠭࣌"),mode=l1lll_af_ (u"࠭࡟ࡪࡰࡩࡳࡤ࠭࣍"),l11ll1l_af_=l1lll_af_ (u"ࠧ࠰࠰࠱࠳࠳࠴࠯ࡪࡥࡲࡲ࠳ࡶ࡮ࡨࠩ࣎"),isFolder=True,IsPlayable=False)
    l1l11ll1_af_(l1lll_af_ (u"ࠣࡍࡤࡸࡪ࡭࡯ࡳ࡫ࡨࠤࡼ࡯ࡤࡦࡱ࣏ࠥ"),l1lll_af_ (u"ࠩ࠲ࡴࡦ࡭ࡥ࡭ࡱࡤࡨ࡮ࡴࡧ࠰࡫ࡱࡨࡪࡾ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡪࡧࡶ࠱ࡱࡵࡡࡥࡧࡵ࠲࡯ࡹࡰࠨ࣐"),mode=l1lll_af_ (u"ࠪ࡫ࡪࡺࡃࡰࡰࡷࡩࡳࡺ࣑ࠧ"),l11ll1l_af_=l1lll_af_ (u"࣒ࠫࠬ"),isFolder=True,IsPlayable=False)
    l1l11ll1_af_(l1lll_af_ (u"ࠧࡔ࡯ࡸࡧ࣓ࠥ"),l1lll_af_ (u"࠭࠯ࡱࡣࡪࡩࡱࡵࡡࡥ࡫ࡱ࡫࠴ࡺࡡࡣ࠯ࡹ࡭ࡩ࡫࡯ࡴ࠯࡯ࡳࡦࡪࡥࡳ࠰࡭ࡷࡵࡅ࡯ࡱ࠿࠳ࠫࣔ"),mode=l1lll_af_ (u"ࠧࡨࡧࡷࡇࡴࡴࡴࡦࡰࡷࠫࣕ"),l11ll1l_af_=l1lll_af_ (u"ࠨࠩࣖ"),isFolder=True,IsPlayable=False)
    l1l11ll1_af_(l1lll_af_ (u"ࠤࡓࡳࡵࡻ࡬ࡢࡴࡱࡩࠧࣗ"),l1lll_af_ (u"ࠪ࠳ࡵࡧࡧࡦ࡮ࡲࡥࡩ࡯࡮ࡨ࠱ࡷࡥࡧ࠳ࡶࡪࡦࡨࡳࡸ࠳࡬ࡰࡣࡧࡩࡷ࠴ࡪࡴࡲࡂࡳࡵࡃ࠱ࠨࣘ"),mode=l1lll_af_ (u"ࠫ࡬࡫ࡴࡄࡱࡱࡸࡪࡴࡴࠨࣙ"),l11ll1l_af_=l1lll_af_ (u"ࠬ࠭ࣚ"),isFolder=True,IsPlayable=False)
    l1l11ll1_af_(l1lll_af_ (u"ࠨࡏࡤࡧࡱ࡭ࡦࡴࡥࠣࣛ"),l1lll_af_ (u"ࠧ࠰ࡲࡤ࡫ࡪࡲ࡯ࡢࡦ࡬ࡲ࡬࠵ࡴࡢࡤ࠰ࡺ࡮ࡪࡥࡰࡵ࠰ࡰࡴࡧࡤࡦࡴ࠱࡮ࡸࡶ࠿ࡰࡲࡀ࠶ࠬࣜ"),mode=l1lll_af_ (u"ࠨࡩࡨࡸࡈࡵ࡮ࡵࡧࡱࡸࠬࣝ"),l11ll1l_af_=l1lll_af_ (u"ࠩࠪࣞ"),isFolder=True,IsPlayable=False)
    l1l11ll1_af_(l1lll_af_ (u"ࠥࡅࡱࡲࠠࡗ࡫ࡧࡩࡴࠨࣟ"),l1lll_af_ (u"ࠫࠬ࣠"),mode=l1lll_af_ (u"ࠬࡇ࡬࡭ࡘ࡬ࡨࡪࡵࠧ࣡"),l11ll1l_af_=l1lll_af_ (u"࠭ࠧ࣢"),isFolder=True,IsPlayable=False)
    l1l11ll1_af_(l1lll_af_ (u"ࠢ࡜ࡄࡠ࡙ࡸ࡫ࡲࡴ࡝࠲ࡆࡢࠨࣣ"),l1lll_af_ (u"ࠨࠩࣤ"),mode=l1lll_af_ (u"ࠩࡏ࡭ࡸࡺࡕࡴࡧࡵࡷࠬࣥ"),l11ll1l_af_=l1lll_af_ (u"ࣦࠪࠫ"),isFolder=True,IsPlayable=False)
elif mode[0] == l1lll_af_ (u"ࠫࡆࡲ࡬ࡗ࡫ࡧࡩࡴ࠭ࣧ"):
    l1l11ll1_af_(l1lll_af_ (u"ࠧࡡࡃࡐࡎࡒࡖࠥࡨ࡬ࡶࡧࡠࡊ࡮ࡲࡴࡳࡱࡺࡥࡳ࡯ࡥࠡ࡫ࠣࡗࡴࡸࡴࡰࡹࡤࡲ࡮࡫࡛࠰ࡅࡒࡐࡔࡘ࡝ࠣࣨ"),l1lll_af_ (u"ࣩ࠭ࠧ"),mode=l1lll_af_ (u"ࠧࡇ࡫࡯ࡸࡷࡵࡷࡢࡰ࡬ࡩࡤ࡙࡯ࡳࡶࡲࡻࡦࡴࡩࡦࠩ࣪"),l11ll1l_af_=l1lll_af_ (u"ࠨࠩ࣫"),IsPlayable=False)
    items,l1lll1l1_af_=af.l1l1ll1l_af_(ex_link,l11llll1_af_)
    if l1lll1l1_af_[0]:l1l11ll1_af_(name=l1lll_af_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝࠽࠾ࠣࡴࡴࡶࡲࡻࡧࡧࡲ࡮ࡧࠠࡴࡶࡵࡳࡳࡧࠠ࠽࠾࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࣬"), url=ex_link, mode=l1lll_af_ (u"ࠪࡣࡤࡶࡡࡨࡧ࠽ࡅࡱࡲࡖࡪࡦࡨࡳ࣭ࠬ"), l11llll1_af_=l1lll1l1_af_[0], IsPlayable=False)
    for f in items:
        l1l11ll1_af_(name=f.get(l1lll_af_ (u"ࠫࡹ࡯ࡴ࡭ࡧ࣮ࠪ")), url=f.get(l1lll_af_ (u"ࠬ࡮ࡲࡦࡨ࣯ࠪ")), mode=l1lll_af_ (u"࠭ࡧࡦࡶࡏ࡭ࡳࡱࡳࠨࣰ"), l11ll1l_af_=f.get(l1lll_af_ (u"ࠧࡪ࡯ࡪࣱࠫ")), infoLabels=f, IsPlayable=True, isFolder=False,l1111ll_af_=len(items))
    if l1lll1l1_af_[1]: l1l11ll1_af_(name=l1lll_af_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣ࠾࠿ࠢࡱࡥࡸࡺࡥࡱࡰࡤࠤࡸࡺࡲࡰࡰࡤࠤࡃࡄ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨࣲ"), url=ex_link, mode=l1lll_af_ (u"ࠩࡢࡣࡵࡧࡧࡦ࠼ࡄࡰࡱ࡜ࡩࡥࡧࡲࠫࣳ"), l11llll1_af_=l1lll1l1_af_[1], IsPlayable=False)
elif mode[0] == l1lll_af_ (u"ࠪࡊ࡮ࡲࡴࡳࡱࡺࡥࡳ࡯ࡥࡠࡕࡲࡶࡹࡵࡷࡢࡰ࡬ࡩࠬࣴ"):
    l11l1l1_af_.openSettings()
    l1l1llll_af_()
    xbmc.executebuiltin(l1lll_af_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭ࣵ"))
elif mode[0].startswith(l1lll_af_ (u"ࠬࡥࡩ࡯ࡨࡲࡣࣶࠬ")):
    l1l11l1_af_.__myinfo__.go(sys.argv)
    xbmcplugin.endOfDirectory(l111111_af_,succeeded=True,cacheToDisc=False)
elif mode[0] == l1lll_af_ (u"࠭ࡌࡪࡵࡷ࡙ࡸ࡫ࡲࡴࠩࣷ"): l1l1l1l1_af_()
elif mode[0]==l1lll_af_ (u"ࠧࡨࡧࡷࡇࡴࡴࡴࡦࡰࡷࠫࣸ"):
    items = af.l1111l_af_(ex_link)
    isFolder = False
    IsPlayable = True
    l111l11_af_ =l1lll_af_ (u"ࠨࡩࡨࡸࡑ࡯࡮࡬ࡵࣹࠪ")
    for f in items:
        l1l11ll1_af_(name=f.get(l1lll_af_ (u"ࠩࡷ࡭ࡹࡲࡥࠨࣺ")), url=f.get(l1lll_af_ (u"ࠪ࡬ࡷ࡫ࡦࠨࣻ")), mode=l111l11_af_, l11ll1l_af_=f.get(l1lll_af_ (u"ࠫ࡮ࡳࡧࠨࣼ")), infoLabels=f, IsPlayable=IsPlayable, isFolder=isFolder,l1111ll_af_=len(items))
elif mode[0] == l1lll_af_ (u"࡛ࠬࡳࡦࡴ࠰ࡗ࡭ࡵࡷࡑࡴࡲࡪ࡮ࡲࡥࠨࣽ"):
    data = af.l1l1lll1_af_(ex_link)
    if data:
        name = data.get(l1lll_af_ (u"࠭ࡵࡴࡧࡵࡲࡦࡳࡥࠨࣾ"))
        l11ll11_af_= data.get(l1lll_af_ (u"ࠧࡪ࡯ࡪࠫࣿ"))
        l11llll_af_=str(data.get(l1lll_af_ (u"ࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࠪऀ"),l1lll_af_ (u"ࠩࡂࠫँ")))
        l1l111l_af_=str(data.get(l1lll_af_ (u"࡚ࠪ࡮ࡪࡥࡰࡵࠪं"),l1lll_af_ (u"ࠫࡄ࠭ः")))
        l1ll1lll_af_ = af.l1lll1ll_af_(data,l111ll1_af_)
        if not l1ll1lll_af_:
            l1l11ll1_af_(l1lll_af_ (u"ࠬࡡࡉ࡞ࡆࡲࡨࡦࡰ࡛࠰ࡋࡠࠫऄ"),data.get(l1lll_af_ (u"࠭ࡩࡥࡷࡽࠫअ")),mode=l1lll_af_ (u"ࠧࡂࡆࡇ࡙ࡘࡋࡒࠨआ"),l11ll1l_af_=l11ll11_af_,infoLabels=data,isFolder=False,IsPlayable=False)
        else:
            l1l11ll1_af_(l1lll_af_ (u"ࠨ࡝ࡌࡡ࡚ࡹࡵॅ࡝࠲ࡍࡢ࠭इ"),data.get(l1lll_af_ (u"ࠩ࡬ࡨࡺࢀࠧई")),mode=l1lll_af_ (u"ࠪࡖࡊࡓࡏࡗࡇࠪउ"),l11ll1l_af_=l11ll11_af_,infoLabels=data,isFolder=False,IsPlayable=False)
        l1l11ll1_af_(name+l1lll_af_ (u"ࠦ࠿ࠦࡖࡪࡦࡨࡳࡸࠦࠨ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࠨऊ")+l1l111l_af_+l1lll_af_ (u"ࠧࡡ࠯ࡄࡑࡏࡓࡗࡣࠩࠣऋ"),data.get(l1lll_af_ (u"࠭ࡩࡥࡷࡽࠫऌ")),mode=l1lll_af_ (u"ࠧࡖࡵࡨࡶ࠲ࡈ࡬ࡰࡩ࠽࡚࡮ࡪࡥࡰࡵࠪऍ"),l11ll1l_af_=l11ll11_af_,isFolder=True,IsPlayable=False)
        l1l11ll1_af_(name+l1lll_af_ (u"ࠣ࠼ࠣࡔࡱࡧࡹ࡭࡫ࡶࡸࡸࠦࠨ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࠨऎ")+l11llll_af_+l1lll_af_ (u"ࠤ࡞࠳ࡈࡕࡌࡐࡔࡠ࠭ࠧए"),data.get(l1lll_af_ (u"ࠪ࡭ࡩࡻࡺࠨऐ")),mode=l1lll_af_ (u"࡚ࠫࡹࡥࡳ࠯ࡅࡰࡴ࡭࠺ࡑ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪऑ"),l11ll1l_af_=l11ll11_af_,isFolder=True,IsPlayable=False)
elif mode[0] == l1lll_af_ (u"ࠬࡇࡄࡅࡗࡖࡉࡗ࠭ऒ"):
    data = eval(data)
    if data.has_key(l1lll_af_ (u"࠭ࡩࡥࡷࡽࠫओ")):
        l1l1l1l_af_= xbmcgui.Dialog().yesno(l1lll_af_ (u"ࠧࡄࡼࡼࠤࡩࡵࡤࡢउࠣࡹঁࡿࡴ࡬ࡱࡺࡲ࡮ࡱࡡࡀࠩऔ"),
                l1lll_af_ (u"ࠨࡐࡤࡱࡪࡀࠠ࡜ࡄࡠࠩࡸࡡ࠯ࡃ࡟ࠣࠤ࠭ࠫࡳࠪࠩक")%(data.get(l1lll_af_ (u"ࠩࡸࡷࡪࡸ࡮ࡢ࡯ࡨࠫख")),data.get(l1lll_af_ (u"ࠪ࡮ࡴ࡯࡮ࡦࡦࠪग"))),
                l1lll_af_ (u"࡛ࠫ࡯ࡥࡸࡵࠣ࠾ࡠࡈ࡝ࠦࡵ࡞࠳ࡇࡣࠧघ")%data.get(l1lll_af_ (u"ࠬࡼࡩࡥࡧࡲࡣࡻ࡯ࡥࡸࡵࠪङ")),
                l1lll_af_ (u"࠭ࡖࡪࡦࡨࡳࡸ࠵ࡐ࡭ࡣࡼࡰ࡮ࡹࡴࡴࠢ࠽ࠤࡠࡈ࡝ࠦࡵ࡞࠳ࡇࡣ࠯࡜ࡄࡠࠩࡸࡡ࠯ࡃ࡟ࠪच")%(data.get(l1lll_af_ (u"ࠧࡗ࡫ࡧࡩࡴࡹࠧछ")),data.get(l1lll_af_ (u"ࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࠪज"))))
        if l1l1l1l_af_:
            af.l1lll111_af_(data,l111ll1_af_)
            xbmc.executebuiltin(l1lll_af_ (u"࡛ࠩࡆࡒࡉ࠮ࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫझ"))
    else:
        xbmcgui.Dialog().ok(l1lll_af_ (u"ࠪࡔࡷࡵࡢ࡭ࡧࡰࠤࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞࡝ࡌࡡࠪࡹ࡛࠰ࡋࡠ࡟࠴ࡉࡏࡍࡑࡕࡡࠬञ")%data.get(l1lll_af_ (u"ࠫࡺࡹࡥࡳࡰࡤࡱࡪ࠭ट")),l1lll_af_ (u"ࠬࡶࡲࡰࡨ࡬ࡰࠥࡻॼࡺࡶ࡮ࡳࡼࡴࡩ࡬ࡣࠣࡲ࡮࡫ࠠࡻࡱࡶࡸࡦैࠠࡥࡱࡧࡥࡳࡿࠡࠨठ"))
elif mode[0] == l1lll_af_ (u"࠭ࡒࡆࡏࡒ࡚ࡊ࠭ड"):
    params = eval(data)
    l1l1l1l_af_ = xbmcgui.Dialog().yesno(params.get(l1lll_af_ (u"ࠧࡶࡵࡨࡶࡳࡧ࡭ࡦࠩढ")),l1lll_af_ (u"ࠨࡅࡽࡽࠥࡻࡳࡶࡰईऋࠥࡻॼࡺࡶ࡮ࡳࡼࡴࡩ࡬ࡣ࠽ࠫण"),l1lll_af_ (u"ࠩࡸࡷࡪࡸ࡮ࡢ࡯ࡨࠤࠪࡹࠧत")%params.get(l1lll_af_ (u"ࠪࡹࡸ࡫ࡲ࡯ࡣࡰࡩࠬथ")))
    if l1l1l1l_af_: af.l1ll1l1_af_(params.get(l1lll_af_ (u"ࠫ࡮ࡪࡵࡻࠩद")),l111ll1_af_)
    xbmc.executebuiltin(l1lll_af_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧध"))
elif mode[0].startswith(l1lll_af_ (u"࠭ࡕࡴࡧࡵ࠱ࡇࡲ࡯ࡨ࠼ࠪन")):
    l1llllll_af_ = mode[0].split(l1lll_af_ (u"ࠧ࠻ࠩऩ"))[-1]
    if      l1llllll_af_ ==l1lll_af_ (u"ࠨࡘ࡬ࡨࡪࡵࡳࠨप"):
        items,l1lll1l1_af_ = af.l11lll_af_(ex_link,l11llll1_af_)
        l1l11ll_af_ = l1lll_af_ (u"ࠩࡘࡷࡪࡸ࠭ࡃ࡮ࡲ࡫࠿࡜ࡩࡥࡧࡲࡷࠬफ")
        l11ll1_af_ = l1lll_af_ (u"ࠪ࡫ࡪࡺࡌࡪࡰ࡮ࡷࠬब")
        IsPlayable , isFolder = True,False
    elif    l1llllll_af_ ==l1lll_af_ (u"ࠫࡕࡲࡡࡺ࡮࡬ࡷࡹࡹࠧभ"):
        items,l1lll1l1_af_ = af.l1ll11l1_af_(ex_link)
        l1l11ll_af_ = l1lll_af_ (u"ࠬ࠭म")
        l11ll1_af_ = l1lll_af_ (u"࠭ࡕࡴࡧࡵ࠱ࡇࡲ࡯ࡨ࠼ࡓࡰࡦࡿ࡬ࡪࡵࡷ࠱ࡈࡵ࡮ࡵࡧࡱࡸࠬय")
        IsPlayable , isFolder = False,True
    elif    l1llllll_af_ == l1lll_af_ (u"ࠧࡑ࡮ࡤࡽࡱ࡯ࡳࡵ࠯ࡆࡳࡳࡺࡥ࡯ࡶࠪर"):
        items,l1lll1l1_af_ = af.l11l11l_af_(ex_link)
        l1l11ll_af_ = l1lll_af_ (u"ࠨࠩऱ")
        l11ll1_af_ = l1lll_af_ (u"ࠩࡪࡩࡹࡒࡩ࡯࡭ࡶࠫल")
        IsPlayable , isFolder = True,False
    if l1lll1l1_af_[0]:l1l11ll1_af_(name=l1lll_af_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞࠾࠿ࠤࡵࡵࡰࡳࡼࡨࡨࡳ࡯ࡡࠡࡵࡷࡶࡴࡴࡡࠡ࠾࠿࡟࠴ࡉࡏࡍࡑࡕࡡࠬळ"), url=ex_link, mode=l1lll_af_ (u"ࠫࡤࡥࡰࡢࡩࡨ࠾ࠬऴ")+l1l11ll_af_, l11llll1_af_=l1lll1l1_af_[0], IsPlayable=False)
    for f in items:
        l1l11ll1_af_(name=f.get(l1lll_af_ (u"ࠬࡺࡩࡵ࡮ࡨࠫव")), url=f.get(l1lll_af_ (u"࠭ࡨࡳࡧࡩࠫश")), mode=l11ll1_af_, l11ll1l_af_=f.get(l1lll_af_ (u"ࠧࡪ࡯ࡪࠫष")), infoLabels=f, IsPlayable=IsPlayable, isFolder=isFolder,l1111ll_af_=len(items))
    if l1lll1l1_af_[1]: l1l11ll1_af_(name=l1lll_af_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣ࠾࠿ࠢࡱࡥࡸࡺࡥࡱࡰࡤࠤࡸࡺࡲࡰࡰࡤࠤࡃࡄ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨस"), url=ex_link, mode=l1lll_af_ (u"ࠩࡢࡣࡵࡧࡧࡦ࠼ࠪह")+l1l11ll_af_, l11llll1_af_=l1lll1l1_af_[1], IsPlayable=False)
elif mode[0].startswith(l1lll_af_ (u"ࠪࡣࡤࡶࡡࡨࡧ࠽ࠫऺ")):
    url = l1lllll_af_({l1lll_af_ (u"ࠫࡲࡵࡤࡦࠩऻ"): mode[0][7:], l1lll_af_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࡳࡧ࡭ࡦ़ࠩ"): l1lll_af_ (u"࠭ࠧऽ"), l1lll_af_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨा") : ex_link, l1lll_af_ (u"ࠨࡲࡤ࡫ࡪ࠭ि"): l11llll1_af_})
    xbmc.executebuiltin(l1lll_af_ (u"࡛ࠩࡆࡒࡉ࠮ࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠬࠪࡹࠩࠨी")% url)
elif mode[0] == l1lll_af_ (u"ࠪ࡫ࡪࡺࡌࡪࡰ࡮ࡷࠬु"):     l1llll1l_af_(ex_link)
else: xbmcplugin.setResolvedUrl(l111111_af_, False, xbmcgui.ListItem(path=l1lll_af_ (u"ࠫࠬू")))
xbmcplugin.endOfDirectory(l111111_af_)
