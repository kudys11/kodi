# -*- coding: utf-8 -*-
import sys
l1l1ll111l1_at_ = sys.version_info [0] == 2
l11l1ll111l1_at_ = 2048
l1ll11ll111l1_at_ = 7
def l111lll111l1_at_ (llll111l1_at_):
	global l111ll111l1_at_
	l1l1llll111l1_at_ = ord (llll111l1_at_ [-1])
	l1l1lll111l1_at_ = llll111l1_at_ [:-1]
	l1lll111l1_at_ = l1l1llll111l1_at_ % len (l1l1lll111l1_at_)
	l11ll111l1_at_ = l1l1lll111l1_at_ [:l1lll111l1_at_] + l1l1lll111l1_at_ [l1lll111l1_at_:]
	if l1l1ll111l1_at_:
		l1111ll111l1_at_ = unicode () .join ([unichr (ord (char) - l11l1ll111l1_at_ - (l1ll1ll111l1_at_ + l1l1llll111l1_at_) % l1ll11ll111l1_at_) for l1ll1ll111l1_at_, char in enumerate (l11ll111l1_at_)])
	else:
		l1111ll111l1_at_ = str () .join ([chr (ord (char) - l11l1ll111l1_at_ - (l1ll1ll111l1_at_ + l1l1llll111l1_at_) % l1ll11ll111l1_at_) for l1ll1ll111l1_at_, char in enumerate (l11ll111l1_at_)])
	return eval (l1111ll111l1_at_)
import sys,re,os,json
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import check,time
try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
cache = StorageServer.StorageServer(l111lll111l1_at_ (u"ࠢࡢ࡮࡯ࡸࡺࡨࡥࡵࡸࠥ࠭"))
import resources.lib.l1lll1l1ll111l1_at_ as l1lll1l1ll111l1_at_
import ramic as l11ll1lll111l1_at_
l1111lll111l1_at_        = sys.argv[0]
l11l1l1lll111l1_at_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l11l1l1ll111l1_at_        = xbmcaddon.Addon()
l1ll1lllll111l1_at_       = l11l1l1ll111l1_at_.getAddonInfo(l111lll111l1_at_ (u"ࠨࡰࡤࡱࡪ࠭࠮"))
l111lll1ll111l1_at_     = l11l1l1ll111l1_at_.getAddonInfo(l111lll111l1_at_ (u"ࠩ࡬ࡨࠬ࠯"))
PATH        = l11l1l1ll111l1_at_.getAddonInfo(l111lll111l1_at_ (u"ࠪࡴࡦࡺࡨࠨ࠰"))
l1ll1ll1ll111l1_at_    = xbmc.translatePath(l11l1l1ll111l1_at_.getAddonInfo(l111lll111l1_at_ (u"ࠫࡵࡸ࡯ࡧ࡫࡯ࡩࠬ࠱"))).decode(l111lll111l1_at_ (u"ࠬࡻࡴࡧ࠯࠻ࠫ࠲"))
l1l1ll1ll111l1_at_   = PATH+l111lll111l1_at_ (u"࠭࠯ࡳࡧࡶࡳࡺࡸࡣࡦࡵ࠲ࠫ࠳")
l1lll1l1ll111l1_at_.l1l1ll11ll111l1_at_=os.path.join(l1ll1ll1ll111l1_at_,l111lll111l1_at_ (u"ࠧࡢ࡮࡯ࡸࡺࡨࡥ࠯ࡥࡲࡳࡰ࡯ࡥࠨ࠴"))
l111llllll111l1_at_=l1l1ll1ll111l1_at_+l111lll111l1_at_ (u"ࠨࡨࡤࡲࡦࡸࡴ࠯ࡲࡱ࡫ࠬ࠵")
l1lll11lll111l1_at_ = lambda x,y: ord(x)+10*y if ord(x)%2 else ord(x)
def l1llllllll111l1_at_(name, url, mode, l1l11l1ll111l1_at_=1, l11l11lll111l1_at_=None, infoLabels=False, contextO=[l111lll111l1_at_ (u"ࠩࠪ࠶")], IsPlayable=True,fanart=l111llllll111l1_at_,l111ll1ll111l1_at_=1):
    u = l11lllll111l1_at_({l111lll111l1_at_ (u"ࠪࡱࡴࡪࡥࠨ࠷"): mode, l111lll111l1_at_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨ࠸"): name, l111lll111l1_at_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭࠹") : url, l111lll111l1_at_ (u"࠭ࡰࡢࡩࡨࠫ࠺"):l1l11l1ll111l1_at_})
    if l11l11lll111l1_at_==None:
        l11l11lll111l1_at_=l111lll111l1_at_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫ࠻")
    l11ll11lll111l1_at_ = xbmcgui.ListItem(name, iconImage=l11l11lll111l1_at_, thumbnailImage=l11l11lll111l1_at_)
    if not infoLabels:
        infoLabels={l111lll111l1_at_ (u"ࠣࡶ࡬ࡸࡱ࡫ࠢ࠼"): name}
    l11ll11lll111l1_at_.setInfo(type=l111lll111l1_at_ (u"ࠤࡹ࡭ࡩ࡫࡯ࠣ࠽"), infoLabels=infoLabels)
    if IsPlayable:
        l11ll11lll111l1_at_.setProperty(l111lll111l1_at_ (u"ࠪࡍࡸࡖ࡬ࡢࡻࡤࡦࡱ࡫ࠧ࠾"), l111lll111l1_at_ (u"ࠫࡹࡸࡵࡦࠩ࠿"))
    if fanart:
        l11ll11lll111l1_at_.setProperty(l111lll111l1_at_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࡤ࡯࡭ࡢࡩࡨࠫࡀ"),fanart)
    l11l1llll111l1_at_ = []
    l11l1llll111l1_at_.append((l111lll111l1_at_ (u"࠭ࡉ࡯ࡨࡲࡶࡲࡧࡣ࡫ࡣࠪࡁ"), l111lll111l1_at_ (u"࡙ࠧࡄࡐࡇ࠳ࡇࡣࡵ࡫ࡲࡲ࠭ࡏ࡮ࡧࡱࠬࠫࡂ")))
    content=urllib.quote_plus(json.dumps(infoLabels))
    if l111lll111l1_at_ (u"ࠨࡆࡒ࡛ࡓࡒࡏࡂࡆࠪࡃ") in contextO:
        l11l1llll111l1_at_.append((l111lll111l1_at_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝࡜ࡄࡠࡔࡴࡨࡩࡦࡴࡽ࡟࠴ࡈ࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࡄ"), l111lll111l1_at_ (u"ࠪࡖࡺࡴࡐ࡭ࡷࡪ࡭ࡳ࠮ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠧࡶࡃࡲࡵࡤࡦ࠿ࡇࡓ࡜ࡔࡌࡐࡃࡇࠪࡪࡾ࡟࡭࡫ࡱ࡯ࡂࠫࡳࠪࠩࡅ")%(l111lll1ll111l1_at_,content)))
    l11ll11lll111l1_at_.addContextMenuItems(l11l1llll111l1_at_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l11l1l1lll111l1_at_, url=u, listitem=l11ll11lll111l1_at_,isFolder=False,totalItems=l111ll1ll111l1_at_)
    xbmcplugin.addSortMethod(l11l1l1lll111l1_at_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l111lll111l1_at_ (u"ࠦࠪࡘࠬࠡࠧ࡜࠰ࠥࠫࡐࠣࡆ"))
    return ok
l11llllll111l1_at_ = lambda l1lll111ll111l1_at_: l111lll111l1_at_ (u"ࠬ࠭ࡇ").join([chr(l1lll11lll111l1_at_(x,1) ) for x in l1lll111ll111l1_at_.encode(l111lll111l1_at_ (u"࠭ࡢࡢࡵࡨ࠺࠹࠭ࡈ")).strip()])
l1l11ll1ll111l1_at_ = lambda l1lll111ll111l1_at_: l111lll111l1_at_ (u"ࠧࠨࡉ").join([chr(l1lll11lll111l1_at_(x,-1) ) for x in l1lll111ll111l1_at_]).decode(l111lll111l1_at_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨࡊ"))
def l111lllll111l1_at_(name,ex_link=None, l1l11l1ll111l1_at_=1, mode=l111lll111l1_at_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩࡋ"),iconImage=l111lll111l1_at_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧࡌ"), infoLabels=None, fanart=l111llllll111l1_at_,contextmenu=None):
    url = l11lllll111l1_at_({l111lll111l1_at_ (u"ࠫࡲࡵࡤࡦࠩࡍ"): mode, l111lll111l1_at_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࡳࡧ࡭ࡦࠩࡎ"): name, l111lll111l1_at_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧࡏ") : ex_link, l111lll111l1_at_ (u"ࠧࡱࡣࡪࡩࠬࡐ") : l1l11l1ll111l1_at_})
    l1lllllll111l1_at_ = xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconImage)
    if infoLabels:
        l1lllllll111l1_at_.setInfo(type=l111lll111l1_at_ (u"ࠣ࡯ࡲࡺ࡮࡫ࠢࡑ"), infoLabels=infoLabels)
    if fanart:
        l1lllllll111l1_at_.setProperty(l111lll111l1_at_ (u"ࠩࡩࡥࡳࡧࡲࡵࡡ࡬ࡱࡦ࡭ࡥࠨࡒ"), fanart )
    if contextmenu:
        l11l1llll111l1_at_=contextmenu
        l1lllllll111l1_at_.addContextMenuItems(l11l1llll111l1_at_, replaceItems=True)
    else:
        l11l1llll111l1_at_ = []
        l11l1llll111l1_at_.append((l111lll111l1_at_ (u"ࠪࡍࡳ࡬࡯ࡳ࡯ࡤࡧ࡯ࡧࠧࡓ"), l111lll111l1_at_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡄࡧࡹ࡯࡯࡯ࠪࡌࡲ࡫ࡵࠩࠨࡔ")),)
        l1lllllll111l1_at_.addContextMenuItems(l11l1llll111l1_at_, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=l11l1l1lll111l1_at_, url=url,listitem=l1lllllll111l1_at_, isFolder=True)
    xbmcplugin.addSortMethod(l11l1l1lll111l1_at_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l111lll111l1_at_ (u"ࠧࠫࡒ࠭ࠢࠨ࡝࠱ࠦࠥࡑࠤࡕ"))
def l11l1ll1ll111l1_at_(name, url=l111lll111l1_at_ (u"࠭ࠧࡖ"), mode=l111lll111l1_at_ (u"ࠧࠨࡗ"), l11l11lll111l1_at_=None, fanart=l111llllll111l1_at_):
    u = l11lllll111l1_at_({l111lll111l1_at_ (u"ࠨ࡯ࡲࡨࡪ࠭ࡘ"): mode, l111lll111l1_at_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࡙࠭"): name, l111lll111l1_at_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮࡚ࠫ") : url, l111lll111l1_at_ (u"ࠫࡵࡧࡧࡦ࡛ࠩ"):1})
    l11ll11lll111l1_at_ = xbmcgui.ListItem(name, iconImage=l11l11lll111l1_at_, thumbnailImage=l11l11lll111l1_at_)
    l11ll11lll111l1_at_.setProperty(l111lll111l1_at_ (u"ࠬࡏࡳࡑ࡮ࡤࡽࡦࡨ࡬ࡦࠩ࡜"), l111lll111l1_at_ (u"࠭ࡦࡢ࡮ࡶࡩࠬ࡝"))
    if fanart:
        l11ll11lll111l1_at_.setProperty(l111lll111l1_at_ (u"ࠧࡧࡣࡱࡥࡷࡺ࡟ࡪ࡯ࡤ࡫ࡪ࠭࡞"),fanart)
    ok = xbmcplugin.addDirectoryItem(handle=l11l1l1lll111l1_at_, url=u, listitem=l11ll11lll111l1_at_,isFolder=False)
    return ok
def l111llll111l1_at_(l11l11l1ll111l1_at_):
    l1l1111lll111l1_at_ = {}
    for k, v in l11l11l1ll111l1_at_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l111lll111l1_at_ (u"ࠨࡷࡷࡪ࠽࠭࡟"))
        elif isinstance(v, str):
            v.decode(l111lll111l1_at_ (u"ࠩࡸࡸ࡫࠾ࠧࡠ"))
        l1l1111lll111l1_at_[k] = v
    return l1l1111lll111l1_at_
def l11lllll111l1_at_(query):
    return l1111lll111l1_at_ + l111lll111l1_at_ (u"ࠪࡃࠬࡡ") + urllib.urlencode(l111llll111l1_at_(query))
if not os.path.exists(l111lll111l1_at_ (u"ࠫ࠴࡮࡯࡮ࡧ࠲ࡳࡸࡳࡣࠨࡢ")):
    tm=time.gmtime()
    try:    l11111ll111l1_at_,l1llll1ll111l1_at_,l111l1ll111l1_at_ = l1l11ll1ll111l1_at_(l11l1l1ll111l1_at_.getSetting(l111lll111l1_at_ (u"ࠬࡱ࡯ࡥࠩࡣ"))).split(l111lll111l1_at_ (u"࠭࠺ࠨࡤ"))
    except: l11111ll111l1_at_,l1llll1ll111l1_at_,l111l1ll111l1_at_ =  [l111lll111l1_at_ (u"ࠧ࠮࠳ࠪࡥ"),l111lll111l1_at_ (u"ࠨࠩࡦ"),l111lll111l1_at_ (u"ࠩ࠰࠵ࠬࡧ")]
    if int(l11111ll111l1_at_) != tm.tm_hour:
        try:    l1l1llllll111l1_at_ = re.findall(l111lll111l1_at_ (u"ࠪࡏࡔࡊ࠺ࠡࠪ࠱࠮ࡄ࠯࡜࡯ࠩࡨ"),urllib2.urlopen(l111lll111l1_at_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡸࡡࡸ࠰ࡪ࡭ࡹ࡮ࡵࡣࡷࡶࡩࡷࡩ࡯࡯ࡶࡨࡲࡹ࠴ࡣࡰ࡯࠲ࡶࡦࡳࡩࡤࡵࡳࡥ࠴ࡱ࡯ࡥ࡫࠲ࡱࡦࡹࡴࡦࡴ࠲ࡖࡊࡇࡄࡎࡇ࠱ࡱࡩ࠭ࡩ")).read())[0].strip(l111lll111l1_at_ (u"ࠬ࠰ࠧࡪ"))
        except: l1l1llllll111l1_at_ = l111lll111l1_at_ (u"࠭ࠧ࡫")
def l1lll1lll111l1_at_(ex_link,l1l11l1ll111l1_at_):
    url,data = ex_link.split(l111lll111l1_at_ (u"ࠪࡃࠬࡶ")) if l111lll111l1_at_ (u"ࠫࡄ࠭ࡷ") in ex_link else (ex_link,None)
    l1ll1l1lll111l1_at_,l1l1l11lll111l1_at_ = l1lll1l1ll111l1_at_.l1ll111lll111l1_at_(url,int(l1l11l1ll111l1_at_),data)
    if l1l1l11lll111l1_at_[0]:
        l1llllllll111l1_at_(name=l111lll111l1_at_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡨ࡬ࡶࡧࡠࡀࡁࠦࡰࡰࡲࡵࡾࡪࡪ࡮ࡪࡣࠣࡷࡹࡸ࡯࡯ࡣࠣࡀࡁࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࡸ"), url=ex_link, mode=l111lll111l1_at_ (u"࠭࡟ࡠࡲࡤ࡫ࡪࡥ࡟ࡎࠩࡹ"), l1l11l1ll111l1_at_=l1l1l11lll111l1_at_[0], IsPlayable=False)
    items=len(l1ll1l1lll111l1_at_)
    for f in l1ll1l1lll111l1_at_:
        l1llllllll111l1_at_(name=f.get(l111lll111l1_at_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࡺ")), url=f.get(l111lll111l1_at_ (u"ࠨࡪࡵࡩ࡫࠭ࡻ")), mode=l111lll111l1_at_ (u"ࠩࡪࡩࡹࡒࡩ࡯࡭ࡶࠫࡼ"), l11l11lll111l1_at_=f.get(l111lll111l1_at_ (u"ࠪ࡭ࡲ࡭ࠧࡽ")), infoLabels=f, contextO=[l111lll111l1_at_ (u"ࠫࡉࡕࡗࡏࡎࡒࡅࡉ࠭ࡾ")], IsPlayable=True,l111ll1ll111l1_at_=items,fanart=f.get(l111lll111l1_at_ (u"ࠬ࡯࡭ࡨࠩࡿ")))
    if l1l1l11lll111l1_at_[1]:
        l1llllllll111l1_at_(name=l111lll111l1_at_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࡃࡄࠠ࡯ࡣࡶࡸञࡶ࡮ࡢࠢࡶࡸࡷࡵ࡮ࡢࠢࡁࡂࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢀ"), url=ex_link, mode=l111lll111l1_at_ (u"ࠧࡠࡡࡳࡥ࡬࡫࡟ࡠࡏࠪࢁ"), l1l11l1ll111l1_at_=l1l1l11lll111l1_at_[1], IsPlayable=False)
    xbmcplugin.setContent(l11l1l1lll111l1_at_, l111lll111l1_at_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨࢂ"))
def l11llll1ll111l1_at_(ex_link,l1l11l1ll111l1_at_):
    url,data = ex_link.split(l111lll111l1_at_ (u"ࠩࡂࠫࢃ")) if l111lll111l1_at_ (u"ࠪࡃࠬࢄ")in ex_link else (ex_link,None)
    l1ll1l1lll111l1_at_,l1l1l11lll111l1_at_ = l1lll1l1ll111l1_at_.l11lllllll111l1_at_(url,int(l1l11l1ll111l1_at_),data)
    if l1l1l11lll111l1_at_[0]:
        l1llllllll111l1_at_(name=l111lll111l1_at_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟࠿ࡀࠥࡶ࡯ࡱࡴࡽࡩࡩࡴࡩࡢࠢࡶࡸࡷࡵ࡮ࡢࠢ࠿ࡀࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢅ"), url=ex_link, mode=l111lll111l1_at_ (u"ࠬࡥ࡟ࡱࡣࡪࡩࡤࡥࡆࠨࢆ"), l1l11l1ll111l1_at_=l1l1l11lll111l1_at_[0], IsPlayable=False)
    items=len(l1ll1l1lll111l1_at_)
    for f in l1ll1l1lll111l1_at_:
        l1llllllll111l1_at_(name=f.get(l111lll111l1_at_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࢇ")), url=f.get(l111lll111l1_at_ (u"ࠧࡩࡴࡨࡪࠬ࢈")), mode=l111lll111l1_at_ (u"ࠨࡩࡨࡸࡑ࡯࡮࡬ࡵࠪࢉ"), l11l11lll111l1_at_=f.get(l111lll111l1_at_ (u"ࠩ࡬ࡱ࡬࠭ࢊ")), infoLabels=f, IsPlayable=True,l111ll1ll111l1_at_=items,fanart=f.get(l111lll111l1_at_ (u"ࠪ࡭ࡲ࡭ࠧࢋ")))
    if l1l1l11lll111l1_at_[1]:
        l1llllllll111l1_at_(name=l111lll111l1_at_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟ࡁࡂࠥࡴࡡࡴࡶजࡴࡳࡧࠠࡴࡶࡵࡳࡳࡧࠠ࠿ࡀ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࢌ"), url=ex_link, mode=l111lll111l1_at_ (u"ࠬࡥ࡟ࡱࡣࡪࡩࡤࡥࡆࠨࢍ"), l1l11l1ll111l1_at_=l1l1l11lll111l1_at_[1], IsPlayable=False)
    xbmcplugin.setContent(l11l1l1lll111l1_at_, l111lll111l1_at_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭ࢎ"))
def l1l1111ll111l1_at_(ex_link,l1l11l1ll111l1_at_):
    l1ll1l1lll111l1_at_,l1l1l11lll111l1_at_ = l1lll1l1ll111l1_at_.l1l1l1llll111l1_at_(ex_link,int(l1l11l1ll111l1_at_))
    l1ll11l1ll111l1_at_ = l111lll111l1_at_ (u"ࠧࡨࡧࡷࡉࡵ࡯ࡳࡰࡦࡨࡷࠬ࢏")
    if l111lll111l1_at_ (u"ࠨࡶࡵࡹࡪ࠭࢐") in l11l1l1ll111l1_at_.getSetting(l111lll111l1_at_ (u"ࠩࡪࡶࡴࡻࡰࡆࡲ࡬ࡷࡴࡪࡥࡴࠩ࢑")):
        l1ll11l1ll111l1_at_ = l111lll111l1_at_ (u"ࠪ࡫ࡪࡺࡓࡦࡣࡶࡳࡳࡹࠧ࢒")
    if l1l1l11lll111l1_at_[0]:
        l1llllllll111l1_at_(name=l111lll111l1_at_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟࠿ࡀࠥࡶ࡯ࡱࡴࡽࡩࡩࡴࡩࡢࠢࡶࡸࡷࡵ࡮ࡢࠢ࠿ࡀࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࢓"), url=ex_link, mode=l111lll111l1_at_ (u"ࠬࡥ࡟ࡱࡣࡪࡩࡤࡥࡓࠨ࢔"), l1l11l1ll111l1_at_=l1l1l11lll111l1_at_[0], IsPlayable=False)
    items=len(l1ll1l1lll111l1_at_)
    for f in l1ll1l1lll111l1_at_:
        l111lllll111l1_at_(name=f.get(l111lll111l1_at_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ࢕")), ex_link=f.get(l111lll111l1_at_ (u"ࠧࡩࡴࡨࡪࠬ࢖")), mode=l1ll11l1ll111l1_at_, iconImage=f.get(l111lll111l1_at_ (u"ࠨ࡫ࡰ࡫ࠬࢗ")), infoLabels=f, fanart=f.get(l111lll111l1_at_ (u"ࠩ࡬ࡱ࡬࠭࢘")))
    if l1l1l11lll111l1_at_[1]:
        l1llllllll111l1_at_(name=l111lll111l1_at_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞ࡀࡁࠤࡳࡧࡳࡵछࡳࡲࡦࠦࡳࡵࡴࡲࡲࡦࠦ࠾࠿࡝࠲ࡇࡔࡒࡏࡓ࡟࢙ࠪ"), url=ex_link, mode=l111lll111l1_at_ (u"ࠫࡤࡥࡰࡢࡩࡨࡣࡤ࡙࢚ࠧ"), l1l11l1ll111l1_at_=l1l1l11lll111l1_at_[1], IsPlayable=False)
    xbmcplugin.setContent(l11l1l1lll111l1_at_, l111lll111l1_at_ (u"ࠬࡺࡶࡴࡪࡲࡻࡸ࢛࠭"))
def l1lllll1ll111l1_at_(ex_link):
    l11ll1ll111l1_at_ = l1lll1l1ll111l1_at_.l11ll111ll111l1_at_(ex_link)
    l11l111lll111l1_at_ =l1lll1l1ll111l1_at_.l1l1lllll111l1_at_(l11ll1ll111l1_at_)
    for l11l1lll111l1_at_ in sorted(l11l111lll111l1_at_.keys()):
        l111lllll111l1_at_(name=l11l1lll111l1_at_, ex_link=urllib.quote(str(l11l111lll111l1_at_[l11l1lll111l1_at_])), mode=l111lll111l1_at_ (u"࠭ࡧࡦࡶࡈࡴ࡮ࡹ࡯ࡥࡧࡶ࠶ࠬ࢜"))
    xbmcplugin.setContent(l11l1l1lll111l1_at_, l111lll111l1_at_ (u"ࠧࡴࡧࡤࡷࡴࡴࠧ࢝"))
def l11l111ll111l1_at_(ex_link):
    l11ll1ll111l1_at_ = l1lll1l1ll111l1_at_.l11ll111ll111l1_at_(ex_link)
    for f in l11ll1ll111l1_at_:
        l1llllllll111l1_at_(name=f.get(l111lll111l1_at_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ࢞")), url=f.get(l111lll111l1_at_ (u"ࠩ࡫ࡶࡪ࡬ࠧ࢟")), mode=l111lll111l1_at_ (u"ࠪ࡫ࡪࡺࡌࡪࡰ࡮ࡷࠬࢠ"), l11l11lll111l1_at_=f.get(l111lll111l1_at_ (u"ࠫ࡮ࡳࡧࠨࢡ")), infoLabels=f,contextO=[l111lll111l1_at_ (u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧࢢ")], IsPlayable=True,fanart=f.get(l111lll111l1_at_ (u"࠭ࡩ࡮ࡩࠪࢣ")))
    xbmcplugin.setContent(l11l1l1lll111l1_at_, l111lll111l1_at_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩࢤ"))
def l11l11ll111l1_at_(ex_link):
    l11ll1ll111l1_at_ = eval(urllib.unquote(ex_link))
    for f in l11ll1ll111l1_at_:
        l1llllllll111l1_at_(name=f.get(l111lll111l1_at_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࢥ")), url=f.get(l111lll111l1_at_ (u"ࠩ࡫ࡶࡪ࡬ࠧࢦ")), mode=l111lll111l1_at_ (u"ࠪ࡫ࡪࡺࡌࡪࡰ࡮ࡷࠬࢧ"), l11l11lll111l1_at_=f.get(l111lll111l1_at_ (u"ࠫ࡮ࡳࡧࠨࢨ")), infoLabels=f,contextO=[l111lll111l1_at_ (u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧࢩ")], IsPlayable=True,fanart=f.get(l111lll111l1_at_ (u"࠭ࡩ࡮ࡩࠪࢪ")))
    xbmcplugin.setContent(l11l1l1lll111l1_at_, l111lll111l1_at_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩࢫ"))
def l1l1lll1ll111l1_at_(ex_link,l1l111lll111l1_at_=l111lll111l1_at_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨࢬ"),l1l11l1ll111l1_at_=1):
    l1l1l11lll111l1_at_=(None,None)
    l1ll11l1ll111l1_at_ = l111lll111l1_at_ (u"ࠩࡪࡩࡹࡋࡰࡪࡵࡲࡨࡪࡹࠧࢭ")
    l11lll11ll111l1_at_=[]
    if l111lll111l1_at_ (u"ࠪࡸࡷࡻࡥࠨࢮ") in l11l1l1ll111l1_at_.getSetting(l111lll111l1_at_ (u"ࠫ࡬ࡸ࡯ࡶࡲࡈࡴ࡮ࡹ࡯ࡥࡧࡶࠫࢯ")):
        l1ll11l1ll111l1_at_ = l111lll111l1_at_ (u"ࠬ࡭ࡥࡵࡕࡨࡥࡸࡵ࡮ࡴࠩࢰ")
    if   l1l111lll111l1_at_==l111lll111l1_at_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭ࢱ"):
        l1ll1l1lll111l1_at_,l11ll1l1ll111l1_at_,l11lll11ll111l1_at_ = l1lll1l1ll111l1_at_.l1ll1111ll111l1_at_(ex_link)
    elif l1l111lll111l1_at_==l111lll111l1_at_ (u"ࠧࡱ࡮ࡤࡽࡱ࡯ࡳࡵࠩࢲ"):
        out, l1l1l11lll111l1_at_ = l1lll1l1ll111l1_at_.l111111ll111l1_at_(ex_link,l1l11l1ll111l1_at_)
        l1ll1l1lll111l1_at_,l11ll1l1ll111l1_at_ = out
    else:
        l1ll1l1lll111l1_at_ = l11ll1l1ll111l1_at_ = []
    if l1l1l11lll111l1_at_[0]:
        l1llllllll111l1_at_(name=l111lll111l1_at_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣ࠼࠽ࠢࡳࡳࡵࡸࡺࡦࡦࡱ࡭ࡦࠦࡳࡵࡴࡲࡲࡦࠦ࠼࠽࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢳ"), url=ex_link, mode=l111lll111l1_at_ (u"ࠩࡢࡣࡵࡧࡧࡦࡡࡢࡔࠬࢴ"), l1l11l1ll111l1_at_=l1l1l11lll111l1_at_[0], IsPlayable=False)
    for f in l1ll1l1lll111l1_at_:
        f[l111lll111l1_at_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩࢵ")]=l111lll111l1_at_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡴࡸࡡ࡯ࡩࡨࡡ࠭ࡌࠩ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࠪࢶ")+f.get(l111lll111l1_at_ (u"ࠬࡺࡩࡵ࡮ࡨࠫࢷ"))
        l1llllllll111l1_at_(name=f.get(l111lll111l1_at_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࢸ")), url=f.get(l111lll111l1_at_ (u"ࠧࡩࡴࡨࡪࠬࢹ")), mode=l111lll111l1_at_ (u"ࠨࡩࡨࡸࡑ࡯࡮࡬ࡵࠪࢺ"), l11l11lll111l1_at_=f.get(l111lll111l1_at_ (u"ࠩ࡬ࡱ࡬࠭ࢻ")), infoLabels=f, contextO=[l111lll111l1_at_ (u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬࢼ")],IsPlayable=True,fanart=f.get(l111lll111l1_at_ (u"ࠫ࡮ࡳࡧࠨࢽ")))
    for f in l11ll1l1ll111l1_at_:
        f[l111lll111l1_at_ (u"ࠬࡺࡩࡵ࡮ࡨࠫࢾ")]=l111lll111l1_at_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡰࡶࡴࡳࡰࡪࡣࠨࡔࠫ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࠬࢿ")+f.get(l111lll111l1_at_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࣀ"))
        l111lllll111l1_at_(name=f.get(l111lll111l1_at_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࣁ")), ex_link=f.get(l111lll111l1_at_ (u"ࠩ࡫ࡶࡪ࡬ࠧࣂ")), mode=l1ll11l1ll111l1_at_, iconImage=f.get(l111lll111l1_at_ (u"ࠪ࡭ࡲ࡭ࠧࣃ")), infoLabels=f, fanart=f.get(l111lll111l1_at_ (u"ࠫ࡮ࡳࡧࠨࣄ")))
    for f in l11lll11ll111l1_at_:
        f[l111lll111l1_at_ (u"ࠬࡺࡩࡵ࡮ࡨࠫࣅ")]=l111lll111l1_at_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡣࡺࡣࡱࡡ࠭ࡇࠩ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࠪࣆ")+f.get(l111lll111l1_at_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࣇ"))
        l111lllll111l1_at_(name=f.get(l111lll111l1_at_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࣈ")), ex_link=f.get(l111lll111l1_at_ (u"ࠩ࡫ࡶࡪ࡬ࠧࣉ")), mode=l111lll111l1_at_ (u"ࠪࡐ࡮ࡹࡴࡎࡱࡹ࡭ࡪࡹࠧ࣊"), iconImage=f.get(l111lll111l1_at_ (u"ࠫ࡮ࡳࡧࠨ࣋")), infoLabels=f, fanart=f.get(l111lll111l1_at_ (u"ࠬ࡯࡭ࡨࠩ࣌")))
    if l1l1l11lll111l1_at_[1]:
        l1llllllll111l1_at_(name=l111lll111l1_at_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࡃࡄࠠ࡯ࡣࡶࡸञࡶ࡮ࡢࠢࡶࡸࡷࡵ࡮ࡢࠢࡁࡂࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࣍"), url=ex_link, mode=l111lll111l1_at_ (u"ࠧࡠࡡࡳࡥ࡬࡫࡟ࡠࡒࠪ࣎"), l1l11l1ll111l1_at_=l1l1l11lll111l1_at_[1], IsPlayable=False)
def l1l11l1lll111l1_at_(ex_link,l11lll1ll111l1_at_=False,name=l111lll111l1_at_ (u"ࠨ࣏ࠩ"),l1llll11ll111l1_at_=l111lll111l1_at_ (u"࣐ࠩࠪ")):
    l1l111llll111l1_at_ = l1lll1l1ll111l1_at_.l1l1l11ll111l1_at_(ex_link);
    l11l11llll111l1_at_=l111lll111l1_at_ (u"࣑ࠪࠫ")
    t = [ x.get(l111lll111l1_at_ (u"ࠫࡹ࡯ࡴ࡭ࡧ࣒ࠪ")) for x in l1l111llll111l1_at_]
    u = [ x.get(l111lll111l1_at_ (u"ࠬࡻࡲ࡭࣓ࠩ")) for x in l1l111llll111l1_at_]
    h = [ x.get(l111lll111l1_at_ (u"࠭ࡨࡰࡵࡷࠫࣔ")) for x in l1l111llll111l1_at_]
    l11l1l11ll111l1_at_ = l111lll111l1_at_ (u"࡛ࠢࠢ࡭ࡥࡰ࡯ࡥࡨࡱࠣॾࡷࣹࡤ࡭ࡣࠣࡴࡴࡨࡩࡦࡴࡤࡱࡾࡅࠢࣕ") if l11lll1ll111l1_at_ else l111lll111l1_at_ (u"࡙ࠣࡨࡶࡸࡰࡡࠡࡾࠣࡓࡨ࡫࡮ࡢࠢࡿࠤࡠࡎ࡯ࡴࡶࡠࠤࠧࣖ")
    l1l111ll111l1_at_ = xbmcgui.Dialog().select(l11l1l11ll111l1_at_, t)
    if l1l111ll111l1_at_>-1:
        l1l1ll1lll111l1_at_ = u[l1l111ll111l1_at_];
        l1l1ll1lll111l1_at_ = l1lll1l1ll111l1_at_.l1ll1l1ll111l1_at_(l1l1ll1lll111l1_at_,[l1l111ll111l1_at_])
        l11l11llll111l1_at_=l11ll1lll111l1_at_.__mysolver__.go(l1l1ll1lll111l1_at_)
        if False:
            if l111lll111l1_at_ (u"ࠩࡦࡨࡦ࠭ࣗ") in h[l1l111ll111l1_at_]:
                import resources.lib.l1111l1ll111l1_at_ as l1111l1ll111l1_at_
                l11l11llll111l1_at_ = l1111l1ll111l1_at_.l1l1l1l1ll111l1_at_(l1l1ll1lll111l1_at_)
                if type(l11l11llll111l1_at_) is list:
                    l1l1l111ll111l1_at_ = [x[0] for x in l11l11llll111l1_at_]
                    l1l111ll111l1_at_ = xbmcgui.Dialog().select(l111lll111l1_at_ (u"࡛ࠥࡾࡨࡩࡦࡴࡽࠤ࡯ࡧ࡫ࡰढ़ऊࠦࣘ"), l1l1l111ll111l1_at_)
                    if l1l111ll111l1_at_>-1:
                        l11l11llll111l1_at_ = l1111l1ll111l1_at_.l1l1l1l1ll111l1_at_(l11l11llll111l1_at_[l1l111ll111l1_at_][1])
                    else:
                        l11l11llll111l1_at_=l111lll111l1_at_ (u"ࠫࠬࣙ")
            elif l111lll111l1_at_ (u"ࠬࡸࡡࡱ࡫ࡧࡺ࡮ࡪࡥࡰࠩࣚ") in h[l1l111ll111l1_at_] or l111lll111l1_at_ (u"࠭ࡲࡢࡲࡷࡹࠬࣛ") in h[l1l111ll111l1_at_]:
                print h[l1l111ll111l1_at_]
                import resources.lib.l1l111l1ll111l1_at_ as l1llll1lll111l1_at_
                l11l11llll111l1_at_ = l1llll1lll111l1_at_.l1l1l1l1ll111l1_at_(l1l1ll1lll111l1_at_)
                if type(l11l11llll111l1_at_) is list:
                    l1l1l111ll111l1_at_ = [x[0] for x in l11l11llll111l1_at_]
                    l1l111ll111l1_at_ = xbmcgui.Dialog().select(l111lll111l1_at_ (u"ࠢࡘࡻࡥ࡭ࡪࡸࡺࠡ࡬ࡤ࡯ࡴॡइࠣࣜ"), l1l1l111ll111l1_at_)
                    if l1l111ll111l1_at_>-1: l11l11llll111l1_at_ = l11l11llll111l1_at_[l1l111ll111l1_at_][1]
                    else: l11l11llll111l1_at_=l111lll111l1_at_ (u"ࠨࠩࣝ")
        if not l11l11llll111l1_at_:
            try:
                import urlresolver as l1l11lllll111l1_at_
                l11l11llll111l1_at_ = l1l11lllll111l1_at_.resolve(l1l1ll1lll111l1_at_)
            except Exception,e:
                l11l11llll111l1_at_=l111lll111l1_at_ (u"ࠩࠪࣞ")
                s = xbmcgui.Dialog().ok(l111lll111l1_at_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࡑࡴࡲࡦࡱ࡫࡭࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࣟ"),l111lll111l1_at_ (u"ࠫࡒࡵॼࡦࠢ࡬ࡲࡳࡿࠠ࡭࡫ࡱ࡯ࠥࡨङࡥࡼ࡬ࡩࠥࡪࡺࡪࡣॅࡥेࡅࠧ࣠"),l111lll111l1_at_ (u"࡛ࠬࡲ࡭ࡴࡨࡷࡴࡲࡶࡦࡴࠣࡉࡗࡘࡏࡓ࠼ࠣ࡟ࠪࡹ࡝ࠨ࣡")%str(e))
    if l11l11llll111l1_at_:
        if l11lll1ll111l1_at_:
            from resources.lib import l1111llll111l1_at_
            try: l1111llll111l1_at_.l11lll1ll111l1_at_(name, l1llll11ll111l1_at_, l11l11llll111l1_at_, l11l1l1ll111l1_at_.getSetting(l111lll111l1_at_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠯ࡲࡤࡸ࡭࠭࣢")))
            except:xbmc.executebuiltin( l111lll111l1_at_ (u"࡙ࠢࡄࡐࡇ࠳ࡔ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࠬࠪࡹࠬࠦࡵ࠯ࠩ࡮࠲ࠥࡴࣣࠫࠥ") % ( l111lll111l1_at_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡴࡨࡨࡢࠦࡂ࡭इࡧࠤࡵࡵࡢࡪࡧࡵࡥࡳ࡯ࡡࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࣤ"), name, 5000, l1llll11ll111l1_at_))
        xbmcplugin.setResolvedUrl(l11l1l1lll111l1_at_, True, xbmcgui.ListItem(path=l11l11llll111l1_at_))
    else:
        xbmcplugin.setResolvedUrl(l11l1l1lll111l1_at_, False, xbmcgui.ListItem(path=l111lll111l1_at_ (u"ࠩࠪࣥ")))
def l1ll1l11ll111l1_at_():
    return cache.get(l111lll111l1_at_ (u"ࠪ࡬࡮ࡹࡴࡰࡴࡼࣦࠫ")).split(l111lll111l1_at_ (u"ࠫࡀ࠭ࣧ"))
def l1ll111ll111l1_at_(l111ll1lll111l1_at_):
    l1l11l11ll111l1_at_ = l1ll1l11ll111l1_at_()
    if l1l11l11ll111l1_at_ == [l111lll111l1_at_ (u"ࠬ࠭ࣨ")]:
        l1l11l11ll111l1_at_ = []
    l1l11l11ll111l1_at_.insert(0, l111ll1lll111l1_at_)
    cache.set(l111lll111l1_at_ (u"࠭ࡨࡪࡵࡷࡳࡷࡿࣩࠧ"),l111lll111l1_at_ (u"ࠧ࠼ࠩ࣪").join(l1l11l11ll111l1_at_[:50]))
def l11ll11ll111l1_at_(l111ll1lll111l1_at_):
    l1l11l11ll111l1_at_ = l1ll1l11ll111l1_at_()
    if l1l11l11ll111l1_at_:
        cache.set(l111lll111l1_at_ (u"ࠨࡪ࡬ࡷࡹࡵࡲࡺࠩ࣫"),l111lll111l1_at_ (u"ࠩ࠾ࠫ࣬").join(l1l11l11ll111l1_at_[:50]))
    else:
        l111l11ll111l1_at_()
def l111l11ll111l1_at_():
    cache.delete(l111lll111l1_at_ (u"ࠪ࡬࡮ࡹࡴࡰࡴࡼ࣭ࠫ"))
xbmcplugin.setContent(l11l1l1lll111l1_at_, l111lll111l1_at_ (u"ࠫࡲࡵࡶࡪࡧࡶ࣮ࠫ"))
l11l1111ll111l1_at_ = l11l1l1ll111l1_at_.getSetting(l111lll111l1_at_ (u"ࠬ࡬࡟ࡧ࡫࡯ࡸࡷ࡜࣯ࠧ"))
l111ll11ll111l1_at_ = l11l1l1ll111l1_at_.getSetting(l111lll111l1_at_ (u"࠭ࡦࡠࡨ࡬ࡰࡹࡸࡎࠨࣰ")) if l11l1111ll111l1_at_ else l111lll111l1_at_ (u"ࠧࡏࡱࡺࡩࣱࠬ")
l111l1lll111l1_at_ = l11l1l1ll111l1_at_.getSetting(l111lll111l1_at_ (u"ࠨࡵࡢࡪ࡮ࡲࡴࡳࡘࣲࠪ"))
l11111lll111l1_at_ = l11l1l1ll111l1_at_.getSetting(l111lll111l1_at_ (u"ࠩࡶࡣ࡫࡯࡬ࡵࡴࡑࠫࣳ")) if l111l1lll111l1_at_ else l111lll111l1_at_ (u"ࠪࡒࡴࡽࡥࠨࣴ")
l1l1l1lll111l1_at_ = l11l1l1ll111l1_at_.getSetting(l111lll111l1_at_ (u"ࠫ࡫ࡥࡶࡦࡴ࡙ࠫࣵ"))
l1l11llll111l1_at_ = l11l1l1ll111l1_at_.getSetting(l111lll111l1_at_ (u"ࠬ࡬࡟ࡷࡧࡵࡒࣶࠬ")) if l1l1l1lll111l1_at_ else l111lll111l1_at_ (u"࠭ࡗࡴࡼࡼࡷࡹࡱࡩࡦࠩࣷ")
mode = args.get(l111lll111l1_at_ (u"ࠧ࡮ࡱࡧࡩࠬࣸ"), None)
fname = args.get(l111lll111l1_at_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࣹࠬ"),[l111lll111l1_at_ (u"ࣺࠩࠪ")])[0]
ex_link = args.get(l111lll111l1_at_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫࣻ"),[l111lll111l1_at_ (u"ࠫࠬࣼ")])[0]
l1l11l1ll111l1_at_ = args.get(l111lll111l1_at_ (u"ࠬࡶࡡࡨࡧࠪࣽ"),[1])[0]
if mode is None:
    l111lllll111l1_at_(name=l111lll111l1_at_ (u"࠭ࡉ࡯ࡨࡲࡶࡲࡧࡣ࡫ࡣࠪࣾ"),mode=l111lll111l1_at_ (u"ࠧࡠ࡫ࡱࡪࡴࡥࠧࣿ"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l111lll111l1_at_ (u"ࠨࡲࡤࡸ࡭࠭ऀ")))+l111lll111l1_at_ (u"ࠩ࠲࡭ࡨࡵ࡮࠯ࡲࡱ࡫ࠬँ"),infoLabels={})
    l1llllllll111l1_at_(l111lll111l1_at_ (u"ࠥ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞࡙ࡨࡶࡸࡰࡡࠡ࡬जࡾࡾࡱ࡯ࡸࡣ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࡛ࠦࡃ࡟ࠨࡷࡠ࠵ࡂ࡞ࠤं")%l1l11llll111l1_at_,l111lll111l1_at_ (u"ࠫࠬः"),mode=l111lll111l1_at_ (u"ࠬࡹࡥࡵࡘࡨࡶ࠿࡬࡟ࡷࡧࡵࠫऄ"),l11l11lll111l1_at_=l1l1ll1ll111l1_at_+l111lll111l1_at_ (u"࠭ࡦࡪ࡮ࡰࡽ࠳ࡶ࡮ࡨࠩअ"),IsPlayable=False)
    l1llllllll111l1_at_(l111lll111l1_at_ (u"ࠢ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࡌࡩ࡭࡯ࡼࠤࡋ࡯࡬ࡵࡴ࡞࠳ࡈࡕࡌࡐࡔࡠࠦआ"),l111lll111l1_at_ (u"ࠨࠩइ"),mode=l111lll111l1_at_ (u"ࠩࡶࡩࡹࡌࡩ࡭ࡶࡵ࠾࡫ࡥࡦࡪ࡮ࡷࡶࠬई"),l11l11lll111l1_at_=l1l1ll1ll111l1_at_+l111lll111l1_at_ (u"ࠪࡪ࡮ࡲ࡭ࡺ࠰ࡳࡲ࡬࠭उ"),IsPlayable=False)
    l111lllll111l1_at_(name=l111lll111l1_at_ (u"࡛ࠦࠥࠦࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸࡧࡲࡵࡦ࡟ࡉ࡭ࡱࡳࡹ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࡞ࡆࡢࠨऊ")+l111ll11ll111l1_at_+l111lll111l1_at_ (u"ࠧࡡ࠯ࡃ࡟ࠥऋ"),ex_link=l111lll111l1_at_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡ࡭࡮ࡷࡹࡧ࡫࠮ࡵࡸ࠲ࡪ࡮ࡲ࡭ࡺ࠯ࡲࡲࡱ࡯࡮ࡦ࠱ࠪऌ"),l1l11l1ll111l1_at_=1, mode=l111lll111l1_at_ (u"ࠧࡍ࡫ࡶࡸࡒࡵࡶࡪࡧࡶࠫऍ"),iconImage=l1l1ll1ll111l1_at_+l111lll111l1_at_ (u"ࠨࡨ࡬ࡰࡲࡿ࠮ࡱࡰࡪࠫऎ"))
    l111lllll111l1_at_(name=l111lll111l1_at_ (u"ࠤࠣࠤࡠࡉࡏࡍࡑࡕࠤࡱ࡯ࡧࡩࡶࡥࡰࡺ࡫࡝ࠡ࡝ࡊࡥࡹࡻ࡮ࡦ࡭ࡠ࡟࠴ࡉࡏࡍࡑࡕࡡࠧए"),ex_link=l111lll111l1_at_ (u"ࠪ࡯ࡦࡺࡥࡨࡱࡵ࡭ࡦ࠭ऐ"),l1l11l1ll111l1_at_=1, mode=l111lll111l1_at_ (u"ࠫࡌࡧࡴࡶࡰࡨ࡯ࡗࡵ࡫ࠨऑ"),iconImage=l1l1ll1ll111l1_at_+l111lll111l1_at_ (u"ࠬ࡬ࡩ࡭࡯ࡼ࠲ࡵࡴࡧࠨऒ"),fanart=l111llllll111l1_at_)
    l111lllll111l1_at_(name=l111lll111l1_at_ (u"ࠨࠠࠡ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬࡫࡭ࡺࡢ࡭ࡷࡨࡡࠥࡡࡒࡰ࡭ࡠ࡟࠴ࡉࡏࡍࡑࡕࡡࠧओ"),ex_link=l111lll111l1_at_ (u"ࠧࡳࡱ࡮ࠫऔ"),l1l11l1ll111l1_at_=1, mode=l111lll111l1_at_ (u"ࠨࡉࡤࡸࡺࡴࡥ࡬ࡔࡲ࡯ࠬक"),iconImage=l1l1ll1ll111l1_at_+l111lll111l1_at_ (u"ࠩࡩ࡭ࡱࡳࡹ࠯ࡲࡱ࡫ࠬख"),fanart=l111llllll111l1_at_)
    l1llllllll111l1_at_(l111lll111l1_at_ (u"ࠥ࡟ࡈࡕࡌࡐࡔࠣࡰ࡮࡭ࡨࡵࡩࡵࡩࡪࡴ࡝ࡔࡧࡵ࡭ࡦࡲࡥࠡࡈ࡬ࡰࡹࡸ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠣग") ,l111lll111l1_at_ (u"ࠫࠬघ"),mode=l111lll111l1_at_ (u"ࠬࡹࡥࡵࡈ࡬ࡰࡹࡸ࠺ࡴࡡࡩ࡭ࡱࡺࡲࠨङ"),l11l11lll111l1_at_=l1l1ll1ll111l1_at_+l111lll111l1_at_ (u"࠭ࡳࡦࡴ࡬ࡥࡱ࡫࠮ࡱࡰࡪࠫच"),IsPlayable=False)
    l111lllll111l1_at_(name=l111lll111l1_at_ (u"ࠢࠡࠢ࡞ࡇࡔࡒࡏࡓࠢ࡯࡭࡬࡮ࡴࡨࡴࡨࡩࡳࡣࡓࡦࡴ࡬ࡥࡱ࡫࡛࠰ࡅࡒࡐࡔࡘ࡝ࠡ࡝ࡅࡡࠧछ")+l11111lll111l1_at_+l111lll111l1_at_ (u"ࠣ࡝࠲ࡆࡢࠨज"),ex_link=None,l1l11l1ll111l1_at_=1, mode=l111lll111l1_at_ (u"ࠩࡏ࡭ࡸࡺࡓࡦࡴ࡬ࡥࡱ࡫ࠧझ"),iconImage=l1l1ll1ll111l1_at_+l111lll111l1_at_ (u"ࠪࡷࡪࡸࡩࡢ࡮ࡨ࠲ࡵࡴࡧࠨञ"))
    l111lllll111l1_at_(name=l111lll111l1_at_ (u"ࠦࡠࡉࡏࡍࡑࡕࠤࡾ࡫࡬࡭ࡱࡺࡡࡉࡡࡃࡐࡎࡒࡖࠥࡨ࡬ࡶࡧࡠࡐࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞ࡃࠣ࡟ࡈࡕࡌࡐࡔࠣࡰ࡮࡭ࡨࡵࡩࡵࡩࡪࡴ࡝ࡅ࡝ࡆࡓࡑࡕࡒࠡࡲࡸࡶࡵࡲࡥ࡞࡜࡞ࡇࡔࡒࡏࡓࠢࡪࡳࡱࡪ࡝ࡊ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣࡅ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࡈࡡࡃࡐࡎࡒࡖࠥࡲࡩࡨࡪࡷ࡫ࡷ࡫ࡥ࡯࡟ࡌ࡟࠴ࡉࡏࡍࡑࡕࡡࠧट"),ex_link=l111lll111l1_at_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧ࡬࡭ࡶࡸࡦࡪ࠴ࡴࡷ࠱ࡩ࡭ࡱࡳࡹ࠮ࡱࡱࡰ࡮ࡴࡥ࠰࡭ࡤࡸࡪ࡭࡯ࡳ࡫ࡤ࡟࠺ࡣࠫࡸࡧࡵࡷ࡯ࡧ࡛ࡍࡧ࡮ࡸࡴࡸࠬࡅࡷࡥࡦ࡮ࡴࡧ࠭ࡒࡏࡡ࠰࠭ठ"), mode=l111lll111l1_at_ (u"࠭ࡌࡪࡵࡷࡑࡴࡼࡩࡦࡵࠪड"),iconImage=l1l1ll1ll111l1_at_+l111lll111l1_at_ (u"ࠧࡥࡼ࡬ࡩࡨ࡯࠮ࡱࡰࡪࠫढ"))
    l111lllll111l1_at_(name=l111lll111l1_at_ (u"ࠣࡃࡱ࡭ࡲ࡫ࠢण"),ex_link=l111lll111l1_at_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡰࡱࡺࡵࡣࡧ࠱ࡸࡻ࠵ࡡ࡯࡫ࡰࡩ࠴࠭त"),l1l11l1ll111l1_at_=1, mode=l111lll111l1_at_ (u"ࠪࡐ࡮ࡹࡴࡂࡰ࡬ࡱࡪ࠭थ"),iconImage=l1l1ll1ll111l1_at_+l111lll111l1_at_ (u"ࠫࡦࡴࡩ࡮ࡧ࠱ࡴࡳ࡭ࠧद"),fanart=l111llllll111l1_at_)
    l111lllll111l1_at_(name=l111lll111l1_at_ (u"ࠧࡌࡵ࡯ࠤध"),ex_link=l111lll111l1_at_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡ࡭࡮ࡷࡹࡧ࡫࠮ࡵࡸ࠲ࡪࡺࡴ࠯ࠨन"), mode=l111lll111l1_at_ (u"ࠧࡍ࡫ࡶࡸࡋࡻ࡮ࠨऩ"),iconImage=l1l1ll1ll111l1_at_+l111lll111l1_at_ (u"ࠨࡨࡸࡲ࠳ࡶ࡮ࡨࠩप"))
    l111lllll111l1_at_(name=l111lll111l1_at_ (u"ࠤࡉࡹࡳ࡛ࠦࡌࡣࡷࡩ࡬ࡵࡲࡪࡧࡠࠦफ"),ex_link=l111lll111l1_at_ (u"ࠪࠫब"),l1l11l1ll111l1_at_=1, mode=l111lll111l1_at_ (u"ࠫࡋࡻ࡮ࡌࡣࡷࡩ࡬ࡵࡲࡪࡧࠪभ"),iconImage=l1l1ll1ll111l1_at_+l111lll111l1_at_ (u"ࠬ࡬ࡵ࡯࠰ࡳࡲ࡬࠭म"),fanart=l111llllll111l1_at_)
    l111lllll111l1_at_(name=l111lll111l1_at_ (u"ࠨ࡛ࡄࡑࡏࡓࡗࠦࡣࡺࡣࡱࡡࡕࡲࡡࡺ࡮࡬ࡷࡹࡿ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠣय"),ex_link=l111lll111l1_at_ (u"ࠧࠨर"), mode=l111lll111l1_at_ (u"ࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࠪऱ"),iconImage=l1l1ll1ll111l1_at_+l111lll111l1_at_ (u"ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷࡽ࠳ࡶ࡮ࡨࠩल"))
    l111lllll111l1_at_(l111lll111l1_at_ (u"ࠪࡗࡿࡻ࡫ࡢ࡬ࠪळ"),l111lll111l1_at_ (u"ࠫࠬऴ"),mode=l111lll111l1_at_ (u"࡙ࠬࡺࡶ࡭ࡤ࡮ࠬव"),iconImage=l1l1ll1ll111l1_at_+l111lll111l1_at_ (u"࠭ࡳࡻࡷ࡮ࡥ࡯࠴ࡰ࡯ࡩࠪश"))
elif mode[0].startswith(l111lll111l1_at_ (u"ࠧࡠ࡫ࡱࡪࡴࡥࠧष")):l11ll1lll111l1_at_.__myinfo__.go(sys.argv)
elif l111lll111l1_at_ (u"ࠨࡵࡨࡸࡋ࡯࡬ࡵࡴࠪस") in mode[0]:
    _11l1lllll111l1_at_ = mode[0].split(l111lll111l1_at_ (u"ࠤ࠽ࠦह"))[-1]
    label=[l111lll111l1_at_ (u"ࠪࡒࡴࡽࡥࠨऺ"),l111lll111l1_at_ (u"ࠫࡓࡵࡷࡦࠢ࡯࡭ࡳࡱࡩࠨऻ"),l111lll111l1_at_ (u"ࠬࡔࡡ࡫ࡲࡲࡴࡺࡲࡡࡳࡰ࡬ࡩ࡯ࡹࡺࡦ़ࠩ"),l111lll111l1_at_ (u"࠭ࡎࡢ࡬ࡺࡽঁ࡫ࡪࠡࡱࡦࡩࡳ࡯ࡡ࡯ࡧࠪऽ")]
    value=[l111lll111l1_at_ (u"ࠧࡀࡨ࡬ࡰࡹ࡫ࡲ࠾ࡰࡨࡻࠬा"),l111lll111l1_at_ (u"ࠨࡁࡩ࡭ࡱࡺࡥࡳ࠿ࡸࡴࡩࡧࡴࡦࡦࠪि"),l111lll111l1_at_ (u"ࠩࡂࡪ࡮ࡲࡴࡦࡴࡀࡴࡴࡶࡵ࡭ࡣࡵࠫी"),l111lll111l1_at_ (u"ࠪࡃ࡫࡯࡬ࡵࡧࡵࡁࡷࡧࡴࡦࠩु")]
    s = xbmcgui.Dialog().select(l111lll111l1_at_ (u"ࠫ࡜ࡿࡢࡪࡧࡵࡾࠥࡌࡩ࡭ࡶࡵࠫू"),label)
    s = s if s>-1 else 0
    l11l1l1ll111l1_at_.setSetting(_11l1lllll111l1_at_+l111lll111l1_at_ (u"ࠬ࡜ࠧृ"),value[s])
    l11l1l1ll111l1_at_.setSetting(_11l1lllll111l1_at_+l111lll111l1_at_ (u"࠭ࡎࠨॄ"),label[s])
    xbmc.executebuiltin(l111lll111l1_at_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩॅ"))
elif l111lll111l1_at_ (u"ࠨࡵࡨࡸ࡛࡫ࡲࠨॆ") in mode[0]:
    _11l1lllll111l1_at_ = mode[0].split(l111lll111l1_at_ (u"ࠤ࠽ࠦे"))[-1]
    label=[l111lll111l1_at_ (u"࡛ࠪࡸࢀࡹࡴࡶ࡮࡭ࡪ࠭ै"),l111lll111l1_at_ (u"ࠫࡑ࡫࡫ࡵࡱࡵࠫॉ"), l111lll111l1_at_ (u"ࠬࡊࡵࡣࡤ࡬ࡲ࡬࠭ॊ"), l111lll111l1_at_ (u"࠭ࡎࡢࡲ࡬ࡷࡾ࠭ो"), l111lll111l1_at_ (u"ࠧࡑࡎࠪौ"), l111lll111l1_at_ (u"ࠨࡇࡑࡋ्ࠬ")]
    value=[l111lll111l1_at_ (u"ࠩࠪॎ"),l111lll111l1_at_ (u"ࠪࡐࡪࡱࡴࡰࡴࠪॏ"), l111lll111l1_at_ (u"ࠫࡉࡻࡢࡣ࡫ࡱ࡫ࠬॐ"), l111lll111l1_at_ (u"ࠬࡔࡡࡱ࡫ࡶࡽࠬ॑"), l111lll111l1_at_ (u"࠭ࡐࡍ॒ࠩ"), l111lll111l1_at_ (u"ࠧࡆࡐࡊࠫ॓")]
    try:
        s = xbmcgui.Dialog().multiselect(l111lll111l1_at_ (u"ࠨ࡙ࡨࡶࡸࡰࡡࠡ࡬जࡾࡾࡱ࡯ࡸࡣࠣࠬࡲࡻ࡬ࡵ࡫ࡶࡩࡱ࡫ࡣࡵࠫࠪ॔"),label)
    except:
        s = xbmcgui.Dialog().select(l111lll111l1_at_ (u"࡚ࠩࡩࡷࡹࡪࡢࠢ࡭झࡿࡿ࡫ࡰࡹࡤࠫॕ"),label)
    if not s: s=0
    if isinstance(s,list):
        if 0 in s: s=[0]
        v = l111lll111l1_at_ (u"ࠪࡻࡪࡸࡳ࡫ࡣ࡞ࠩࡸࡣࠫࠨॖ")%(l111lll111l1_at_ (u"ࠫ࠱࠭ॗ").join( [ value[i] for i in s])) if s[0]!=0 else l111lll111l1_at_ (u"ࠬ࠭क़")
        n = l111lll111l1_at_ (u"࠭ࠬࠨख़").join( [ label[i] for i in s])
    else:
        s = s if s>-1 else 0
        v = l111lll111l1_at_ (u"ࠧࡸࡧࡵࡷ࡯ࡧ࡛ࠦࡵࡠ࠯ࠬग़")%value[s]
        n = label[s]
    l11l1l1ll111l1_at_.setSetting(_11l1lllll111l1_at_+l111lll111l1_at_ (u"ࠨࡘࠪज़"),v)
    l11l1l1ll111l1_at_.setSetting(_11l1lllll111l1_at_+l111lll111l1_at_ (u"ࠩࡑࠫड़"),n)
    xbmc.executebuiltin(l111lll111l1_at_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬढ़"))
elif mode[0] == l111lll111l1_at_ (u"ࠫࡤࡥࡰࡢࡩࡨࡣࡤࡓࠧफ़"):
    url = l11lllll111l1_at_({l111lll111l1_at_ (u"ࠬࡳ࡯ࡥࡧࠪय़"): l111lll111l1_at_ (u"࠭ࡌࡪࡵࡷࡑࡴࡼࡩࡦࡵࠪॠ"), l111lll111l1_at_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫॡ"): l111lll111l1_at_ (u"ࠨࠩॢ"), l111lll111l1_at_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪॣ") : ex_link, l111lll111l1_at_ (u"ࠪࡴࡦ࡭ࡥࠨ।"): l1l11l1ll111l1_at_})
    xbmc.executebuiltin(l111lll111l1_at_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠮ࠥࡴࠫࠪ॥")% url)
elif mode[0] == l111lll111l1_at_ (u"ࠬࡥ࡟ࡱࡣࡪࡩࡤࡥࡓࠨ०"):
    url = l11lllll111l1_at_({l111lll111l1_at_ (u"࠭࡭ࡰࡦࡨࠫ१"): l111lll111l1_at_ (u"ࠧࡍ࡫ࡶࡸࡘ࡫ࡲࡪࡣ࡯ࡩࠬ२"), l111lll111l1_at_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬ३"): l111lll111l1_at_ (u"ࠩࠪ४"), l111lll111l1_at_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫ५") : ex_link, l111lll111l1_at_ (u"ࠫࡵࡧࡧࡦࠩ६"): l1l11l1ll111l1_at_})
    xbmc.executebuiltin(l111lll111l1_at_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠨࠦࡵࠬࠫ७")% url)
elif mode[0] == l111lll111l1_at_ (u"࠭࡟ࡠࡲࡤ࡫ࡪࡥ࡟ࡑࠩ८"):
    url = l11lllll111l1_at_({l111lll111l1_at_ (u"ࠧ࡮ࡱࡧࡩࠬ९"): l111lll111l1_at_ (u"ࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࡏ࡭ࡳࡱࡳࠨ॰"), l111lll111l1_at_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭ॱ"): l111lll111l1_at_ (u"ࠪࠫॲ"), l111lll111l1_at_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬॳ") : ex_link, l111lll111l1_at_ (u"ࠬࡶࡡࡨࡧࠪॴ"): l1l11l1ll111l1_at_})
    xbmc.executebuiltin(l111lll111l1_at_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠩࠧࡶ࠭ࠬॵ")% url)
elif mode[0] == l111lll111l1_at_ (u"ࠧࡠࡡࡳࡥ࡬࡫࡟ࡠࡈࠪॶ"):
    url = l11lllll111l1_at_({l111lll111l1_at_ (u"ࠨ࡯ࡲࡨࡪ࠭ॷ"): l111lll111l1_at_ (u"ࠩࡏ࡭ࡸࡺࡆࡶࡰࠪॸ"), l111lll111l1_at_ (u"ࠪࡪࡴࡲࡤࡦࡴࡱࡥࡲ࡫ࠧॹ"): l111lll111l1_at_ (u"ࠫࠬॺ"), l111lll111l1_at_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭ॻ") : ex_link, l111lll111l1_at_ (u"࠭ࡰࡢࡩࡨࠫॼ"): l1l11l1ll111l1_at_})
    xbmc.executebuiltin(l111lll111l1_at_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠪࠨࡷ࠮࠭ॽ")% url)
elif mode[0] == l111lll111l1_at_ (u"ࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࠪॾ"):
    items = l1lll1l1ll111l1_at_.l1ll11llll111l1_at_()
    for f in items:
        l111lllll111l1_at_(name=f.get(l111lll111l1_at_ (u"ࠩࡷ࡭ࡹࡲࡥࠨॿ")), ex_link=f.get(l111lll111l1_at_ (u"ࠪ࡬ࡷ࡫ࡦࠨঀ")), mode=l111lll111l1_at_ (u"ࠫࡕࡲࡡࡺ࡮࡬ࡷࡹࡒࡩ࡯࡭ࡶࠫঁ"), iconImage=f.get(l111lll111l1_at_ (u"ࠬ࡯࡭ࡨࠩং")), infoLabels=f, fanart=f.get(l111lll111l1_at_ (u"࠭ࡩ࡮ࡩࠪঃ")))
elif mode[0] == l111lll111l1_at_ (u"ࠧࡑ࡮ࡤࡽࡱ࡯ࡳࡵࡎ࡬ࡲࡰࡹࠧ঄"):
    l1l1lll1ll111l1_at_(ex_link,l1l111lll111l1_at_=l111lll111l1_at_ (u"ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶࠪঅ"),l1l11l1ll111l1_at_=l1l11l1ll111l1_at_)
elif mode[0] == l111lll111l1_at_ (u"ࠩࡏ࡭ࡸࡺࡍࡰࡸ࡬ࡩࡸ࠭আ"):
    if l1l1l1lll111l1_at_ not in ex_link: ex_link+= l1l1l1lll111l1_at_
    if l11l1111ll111l1_at_ not in ex_link:
        ex_link += l111lll111l1_at_ (u"ࠪࠫই") if ex_link[-1]==l111lll111l1_at_ (u"ࠫ࠴࠭ঈ") else l111lll111l1_at_ (u"ࠬ࠵ࠧউ")
        ex_link += l11l1111ll111l1_at_
    l1lll1lll111l1_at_(ex_link,l1l11l1ll111l1_at_)
    xbmcplugin.setContent(l11l1l1lll111l1_at_, l111lll111l1_at_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭ঊ"))
elif mode[0] == l111lll111l1_at_ (u"ࠧࡍ࡫ࡶࡸࡆࡴࡩ࡮ࡧࠪঋ"):
    l1lll1lll111l1_at_(ex_link,l1l11l1ll111l1_at_)
    xbmcplugin.setContent(l11l1l1lll111l1_at_, l111lll111l1_at_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨঌ"))
elif mode[0] == l111lll111l1_at_ (u"ࠩࡏ࡭ࡸࡺࡆࡶࡰࠪ঍"):
    l11llll1ll111l1_at_(ex_link,l1l11l1ll111l1_at_)
    xbmcplugin.setContent(l11l1l1lll111l1_at_, l111lll111l1_at_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪ঎"))
elif mode[0] == l111lll111l1_at_ (u"ࠫ࡬࡫ࡴࡔࡧࡤࡷࡴࡴࡳࠨএ"):
    l1lllll1ll111l1_at_(ex_link)
    xbmcplugin.setContent(l11l1l1lll111l1_at_, l111lll111l1_at_ (u"ࠬࡺࡶࡴࡪࡲࡻࡸ࠭ঐ"))
elif mode[0] == l111lll111l1_at_ (u"࠭ࡧࡦࡶࡈࡴ࡮ࡹ࡯ࡥࡧࡶࠫ঑"):
    l11l111ll111l1_at_(ex_link)
    xbmcplugin.setContent(l11l1l1lll111l1_at_, l111lll111l1_at_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ঒"))
elif mode[0] == l111lll111l1_at_ (u"ࠨࡩࡨࡸࡊࡶࡩࡴࡱࡧࡩࡸ࠸ࠧও"):
    l11l11ll111l1_at_(ex_link)
    xbmcplugin.setContent(l11l1l1lll111l1_at_, l111lll111l1_at_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫঔ"))
elif mode[0] == l111lll111l1_at_ (u"ࠪࡐ࡮ࡹࡴࡔࡧࡵ࡭ࡦࡲࡥࠨক"):
    l1l1111ll111l1_at_(l111l1lll111l1_at_.strip(l111lll111l1_at_ (u"ࠫࡄ࠭খ")),l1l11l1ll111l1_at_)
    xbmcplugin.setContent(l11l1l1lll111l1_at_, l111lll111l1_at_ (u"ࠬࡺࡶࡴࡪࡲࡻࡸ࠭গ"))
elif mode[0] == l111lll111l1_at_ (u"࠭ࡧࡦࡶࡏ࡭ࡳࡱࡳࠨঘ"):
    l1l11l1lll111l1_at_(ex_link)
elif mode[0] == l111lll111l1_at_ (u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩঙ"):
    data=eval(ex_link)
    l1lll11ll111l1_at_ = l11l1l1ll111l1_at_.getSetting(l111lll111l1_at_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦ࠱ࡴࡦࡺࡨࠨচ"))
    if l1lll11ll111l1_at_:
        l1l11l1lll111l1_at_(data.get(l111lll111l1_at_ (u"ࠩ࡫ࡶࡪ࡬ࠧছ")),True,data.get(l111lll111l1_at_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩজ")),data.get(l111lll111l1_at_ (u"ࠫ࡮ࡳࡧࠨঝ")))
    else:
        xbmcgui.Dialog().ok(l111lll111l1_at_ (u"࡛ࠬࡳࡵࡣࡺࠤࡩࡵࡣࡦ࡮ࡲࡻࡾࠦࡦࡰ࡮ࡧࡩࡷ࠭ঞ"), l111lll111l1_at_ (u"࠭ࡄࡰࡹࡱࡰࡴࡧࡤࠡࡨࡤ࡭ࡱ࡫ࡤࠨট"))
elif mode[0] == l111lll111l1_at_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡉࡵࡧࡰࡷࠬঠ"):
    l1l1lll1ll111l1_at_(ex_link,l111lll111l1_at_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨড"))
elif mode[0] == l111lll111l1_at_ (u"ࠩࡉࡹࡳࡑࡡࡵࡧࡪࡳࡷ࡯ࡥࠨঢ"):
    data = l1lll1l1ll111l1_at_.l1ll1llll111l1_at_()
    for l1lll1llll111l1_at_ in data:
        title = l1lll1l1ll111l1_at_.l11ll1llll111l1_at_(l1lll1llll111l1_at_[1])
        l111lllll111l1_at_(name=title,ex_link=l1lll1llll111l1_at_[0], mode=l111lll111l1_at_ (u"ࠪࡐ࡮ࡹࡴࡇࡷࡱࠫণ"),iconImage=l1l1ll1ll111l1_at_+l111lll111l1_at_ (u"ࠫ࡫ࡻ࡮࠯ࡲࡱ࡫ࠬত"))
elif mode[0] == l111lll111l1_at_ (u"ࠬࡍࡡࡵࡷࡱࡩࡰࡘ࡯࡬ࠩথ"):
    data = l1lll1l1ll111l1_at_.filter(ex_link)
    if data:
        label=data[0]
        value=data[1]
        v=l111lll111l1_at_ (u"࠭ࠧদ")
        try:
            s = xbmcgui.Dialog().multiselect(l111lll111l1_at_ (u"ࠧࡘࡻࡥ࡭ࡪࡸࡺࠡࠩধ")+ex_link,label)
        except:
            s = xbmcgui.Dialog().select(l111lll111l1_at_ (u"ࠨ࡙ࡼࡦ࡮࡫ࡲࡻࠢࠪন")+ex_link,label)
        if not s: s=0
        if isinstance(s,list):
            v = l111lll111l1_at_ (u"ࠩࠨࡷࡠࠫࡳ࡞࠭ࠪ঩")%(ex_link,l111lll111l1_at_ (u"ࠪ࠰ࠬপ").join( [ value[i] for i in s])) if s[0]>-1 else l111lll111l1_at_ (u"ࠫࠬফ")
        else:
            s = s if s>-1 else 0
            v = l111lll111l1_at_ (u"ࠬࠫࡳ࡜ࠧࡶࡡ࠰࠭ব")%(ex_link,value[s])
        if v:
            href = l111lll111l1_at_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡ࡭࡮ࡷࡹࡧ࡫࠮ࡵࡸ࠲ࡪ࡮ࡲ࡭ࡺ࠯ࡲࡲࡱ࡯࡮ࡦ࠱ࠪভ")+v
            url = l11lllll111l1_at_({l111lll111l1_at_ (u"ࠧ࡮ࡱࡧࡩࠬম"): l111lll111l1_at_ (u"ࠨࡎ࡬ࡷࡹࡓ࡯ࡷ࡫ࡨࡷࠬয"), l111lll111l1_at_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭র"): l111lll111l1_at_ (u"ࠪࠫ঱"), l111lll111l1_at_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬল") : href, l111lll111l1_at_ (u"ࠬࡶࡡࡨࡧࠪ঳"): 1})
            xbmc.executebuiltin(l111lll111l1_at_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠩࠧࡶ࠭ࠬ঴")% url)
elif mode[0] == l111lll111l1_at_ (u"ࠧࡐࡲࡦ࡮ࡪ࠭঵"):
    l11l1l1ll111l1_at_.openSettings()
elif mode[0] ==l111lll111l1_at_ (u"ࠨࡕࡽࡹࡰࡧࡪࠨশ"):
    l111lllll111l1_at_(l111lll111l1_at_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡪࡶࡪ࡫࡮࡞ࡐࡲࡻࡪࠦࡓࡻࡷ࡮ࡥࡳ࡯ࡥ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࠩࡈ࡬ࡰࡲ࠲ࡓࡦࡴ࡬ࡥࡱ࠯࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨষ"),l111lll111l1_at_ (u"ࠪࠫস"),mode=l111lll111l1_at_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭ࡒࡴࡽࡥࠨহ"))
    l1ll11lll111l1_at_ = l1ll1l11ll111l1_at_()
    if not l1ll11lll111l1_at_ == [l111lll111l1_at_ (u"ࠬ࠭঺")]:
        for l111ll1lll111l1_at_ in l1ll11lll111l1_at_:
            contextmenu = []
            contextmenu.append((l111lll111l1_at_ (u"࠭ࡕࡴࡷेࠫ঻"), l111lll111l1_at_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠪࠨࡷ࠮়࠭")% l11lllll111l1_at_({l111lll111l1_at_ (u"ࠨ࡯ࡲࡨࡪ࠭ঽ"): l111lll111l1_at_ (u"ࠩࡖࡾࡺࡱࡡ࡫ࡗࡶࡹࡳ࠭া"), l111lll111l1_at_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫি") : l111ll1lll111l1_at_})),)
            contextmenu.append((l111lll111l1_at_ (u"࡚ࠫࡹࡵॅࠢࡦࡥेऋࠠࡩ࡫ࡶࡸࡴࡸࡩचࠩী"), l111lll111l1_at_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠥࡴࠫࠪু") % l11lllll111l1_at_({l111lll111l1_at_ (u"࠭࡭ࡰࡦࡨࠫূ"): l111lll111l1_at_ (u"ࠧࡔࡼࡸ࡯ࡦࡰࡕࡴࡷࡱࡅࡱࡲࠧৃ")})),)
            l111lllll111l1_at_(name=l111ll1lll111l1_at_, ex_link=l111ll1lll111l1_at_.replace(l111lll111l1_at_ (u"ࠨࠢࠪৄ"),l111lll111l1_at_ (u"ࠩ࠮ࠫ৅")), mode=l111lll111l1_at_ (u"ࠪࡷࡪࡧࡲࡤࡪࡌࡸࡪࡳࡳࠨ৆"), fanart=None, contextmenu=contextmenu)
elif mode[0] ==l111lll111l1_at_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭ࡒࡴࡽࡥࠨে"):
    d = xbmcgui.Dialog().input(l111lll111l1_at_ (u"࡙ࠬࡺࡶ࡭ࡤ࡮࠱ࠦࡐࡰࡦࡤ࡮ࠥࡺࡹࡵࡷ࡯ࠤ࡫࡯࡬࡮ࡷ࠲ࡷࡪࡸࡩࡢ࡮ࡸ࠳ࡧࡧࡪ࡬࡫ࠣࡍࡲ࡯ࡥࠡࡣ࡮ࡸࡴࡸࡡࠨৈ"), type=xbmcgui.INPUT_ALPHANUM)
    if d:
        l1ll111ll111l1_at_(d)
        url = l11lllll111l1_at_({l111lll111l1_at_ (u"࠭࡭ࡰࡦࡨࠫ৉"): l111lll111l1_at_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡉࡵࡧࡰࡷࠬ৊"), l111lll111l1_at_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬো"): l111lll111l1_at_ (u"ࠩࠪৌ"), l111lll111l1_at_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮্ࠫ") : d.replace(l111lll111l1_at_ (u"ࠫࠥ࠭ৎ"),l111lll111l1_at_ (u"ࠬ࠱ࠧ৏")), l111lll111l1_at_ (u"࠭ࡰࡢࡩࡨࠫ৐"): 1})
        xbmc.executebuiltin(l111lll111l1_at_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠪࠨࡷ࠮࠭৑")% url)
elif mode[0] ==l111lll111l1_at_ (u"ࠨࡕࡽࡹࡰࡧࡪࡖࡵࡸࡲࠬ৒"):
    l11ll11ll111l1_at_(ex_link)
    xbmc.executebuiltin(l111lll111l1_at_ (u"࡛ࠩࡆࡒࡉ࠮ࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠬࠪࡹࠩࠨ৓")%  l11lllll111l1_at_({l111lll111l1_at_ (u"ࠪࡱࡴࡪࡥࠨ৔"): l111lll111l1_at_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭ࠫ৕")}))
elif mode[0] == l111lll111l1_at_ (u"࡙ࠬࡺࡶ࡭ࡤ࡮࡚ࡹࡵ࡯ࡃ࡯ࡰࠬ৖"):
    l111l11ll111l1_at_()
    xbmc.executebuiltin(l111lll111l1_at_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠩࠧࡶ࠭ࠬৗ")%  l11lllll111l1_at_({l111lll111l1_at_ (u"ࠧ࡮ࡱࡧࡩࠬ৘"): l111lll111l1_at_ (u"ࠨࡕࡽࡹࡰࡧࡪࠨ৙")}))
elif mode[0] == l111lll111l1_at_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ৚"):
    pass
else:
    xbmcplugin.setResolvedUrl(l11l1l1lll111l1_at_, False, xbmcgui.ListItem(path=l111lll111l1_at_ (u"ࠪࠫ৛")))
xbmcplugin.endOfDirectory(l11l1l1lll111l1_at_)
