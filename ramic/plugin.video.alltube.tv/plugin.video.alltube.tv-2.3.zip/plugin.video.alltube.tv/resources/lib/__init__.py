# coding: UTF-8
import sys
l1l1ll111l1_at_ = sys.version_info [0] == 2
l11l1ll111l1_at_ = 2048
l1ll11ll111l1_at_ = 7
def l111lll111l1_at_ (llll111l1_at_):
	global l111ll111l1_at_
	l1l1llll111l1_at_ = ord (llll111l1_at_ [-1])
	l1l1lll111l1_at_ = llll111l1_at_ [:-1]
	l1lll111l1_at_ = l1l1llll111l1_at_ % len (l1l1lll111l1_at_)
	l11ll111l1_at_ = l1l1lll111l1_at_ [:l1lll111l1_at_] + l1l1lll111l1_at_ [l1lll111l1_at_:]
	if l1l1ll111l1_at_:
		l1111ll111l1_at_ = unicode () .join ([unichr (ord (char) - l11l1ll111l1_at_ - (l1ll1ll111l1_at_ + l1l1llll111l1_at_) % l1ll11ll111l1_at_) for l1ll1ll111l1_at_, char in enumerate (l11ll111l1_at_)])
	else:
		l1111ll111l1_at_ = str () .join ([chr (ord (char) - l11l1ll111l1_at_ - (l1ll1ll111l1_at_ + l1l1llll111l1_at_) % l1ll11ll111l1_at_) for l1ll1ll111l1_at_, char in enumerate (l11ll111l1_at_)])
	return eval (l1111ll111l1_at_)