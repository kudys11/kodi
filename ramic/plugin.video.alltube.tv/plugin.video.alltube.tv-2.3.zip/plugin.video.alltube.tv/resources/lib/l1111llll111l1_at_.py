# -*- coding: utf-8 -*-
import sys
l1l1ll111l1_at_ = sys.version_info [0] == 2
l11l1ll111l1_at_ = 2048
l1ll11ll111l1_at_ = 7
def l111lll111l1_at_ (llll111l1_at_):
	global l111ll111l1_at_
	l1l1llll111l1_at_ = ord (llll111l1_at_ [-1])
	l1l1lll111l1_at_ = llll111l1_at_ [:-1]
	l1lll111l1_at_ = l1l1llll111l1_at_ % len (l1l1lll111l1_at_)
	l11ll111l1_at_ = l1l1lll111l1_at_ [:l1lll111l1_at_] + l1l1lll111l1_at_ [l1lll111l1_at_:]
	if l1l1ll111l1_at_:
		l1111ll111l1_at_ = unicode () .join ([unichr (ord (char) - l11l1ll111l1_at_ - (l1ll1ll111l1_at_ + l1l1llll111l1_at_) % l1ll11ll111l1_at_) for l1ll1ll111l1_at_, char in enumerate (l11ll111l1_at_)])
	else:
		l1111ll111l1_at_ = str () .join ([chr (ord (char) - l11l1ll111l1_at_ - (l1ll1ll111l1_at_ + l1l1llll111l1_at_) % l1ll11ll111l1_at_) for l1ll1ll111l1_at_, char in enumerate (l11ll111l1_at_)])
	return eval (l1111ll111l1_at_)
l111lll111l1_at_ (u"ࠬ࠭ࠧࠋࠢࠣࠤ࡙ࠥࡩ࡮ࡲ࡯ࡩࠥ࡞ࡂࡎࡅࠣࡈࡴࡽ࡮࡭ࡱࡤࡨ࡙ࠥࡣࡳ࡫ࡳࡸࠏࠦࠠࠡࠢࡆࡳࡵࡿࡲࡪࡩ࡫ࡸࠥ࠮ࡃࠪࠢ࠵࠴࠶࠹ࠠࡔࡧࡤࡲࠥࡖ࡯ࡺࡵࡨࡶࠥ࠮ࡳࡦࡣࡱࡴࡴࡿࡳࡦࡴࡃ࡫ࡲࡧࡩ࡭࠰ࡦࡳࡲ࠯ࠊࠋࠢࠣࠤ࡚ࠥࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠࡧࡴࡨࡩࠥࡹ࡯ࡧࡶࡺࡥࡷ࡫࠺ࠡࡻࡲࡹࠥࡩࡡ࡯ࠢࡵࡩࡩ࡯ࡳࡵࡴ࡬ࡦࡺࡺࡥࠡ࡫ࡷࠤࡦࡴࡤ࠰ࡱࡵࠤࡲࡵࡤࡪࡨࡼࠎࠥࠦࠠࠡ࡫ࡷࠤࡺࡴࡤࡦࡴࠣࡸ࡭࡫ࠠࡵࡧࡵࡱࡸࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡇࡏࡗࠣࡋࡪࡴࡥࡳࡣ࡯ࠤࡕࡻࡢ࡭࡫ࡦࠤࡑ࡯ࡣࡦࡰࡶࡩࠥࡧࡳࠡࡲࡸࡦࡱ࡯ࡳࡩࡧࡧࠤࡧࡿࠊࠡࠢࠣࠤࡹ࡮ࡥࠡࡈࡵࡩࡪࠦࡓࡰࡨࡷࡻࡦࡸࡥࠡࡈࡲࡹࡳࡪࡡࡵ࡫ࡲࡲ࠱ࠦࡥࡪࡶ࡫ࡩࡷࠦࡶࡦࡴࡶ࡭ࡴࡴࠠ࠴ࠢࡲࡪࠥࡺࡨࡦࠢࡏ࡭ࡨ࡫࡮ࡴࡧ࠯ࠤࡴࡸࠊࠡࠢࠣࠤ࠭ࡧࡴࠡࡻࡲࡹࡷࠦ࡯ࡱࡶ࡬ࡳࡳ࠯ࠠࡢࡰࡼࠤࡱࡧࡴࡦࡴࠣࡺࡪࡸࡳࡪࡱࡱ࠲ࠏࠐࠠࠡࠢࠣࡘ࡭࡯ࡳࠡࡲࡵࡳ࡬ࡸࡡ࡮ࠢ࡬ࡷࠥࡪࡩࡴࡶࡵ࡭ࡧࡻࡴࡦࡦࠣ࡭ࡳࠦࡴࡩࡧࠣ࡬ࡴࡶࡥࠡࡶ࡫ࡥࡹࠦࡩࡵࠢࡺ࡭ࡱࡲࠠࡣࡧࠣࡹࡸ࡫ࡦࡶ࡮࠯ࠎࠥࠦࠠࠡࡤࡸࡸࠥ࡝ࡉࡕࡊࡒ࡙࡙ࠦࡁࡏ࡛࡛ࠣࡆࡘࡒࡂࡐࡗ࡝ࡀࠦࡷࡪࡶ࡫ࡳࡺࡺࠠࡦࡸࡨࡲࠥࡺࡨࡦࠢ࡬ࡱࡵࡲࡩࡦࡦࠣࡻࡦࡸࡲࡢࡰࡷࡽࠥࡵࡦࠋࠢࠣࠤࠥࡓࡅࡓࡅࡋࡅࡓ࡚ࡁࡃࡋࡏࡍ࡙࡟ࠠࡰࡴࠣࡊࡎ࡚ࡎࡆࡕࡖࠤࡋࡕࡒࠡࡃࠣࡔࡆࡘࡔࡊࡅࡘࡐࡆࡘࠠࡑࡗࡕࡔࡔ࡙ࡅ࠯ࠢࠣࡗࡪ࡫ࠠࡵࡪࡨࠎࠥࠦࠠࠡࡉࡑ࡙ࠥࡍࡥ࡯ࡧࡵࡥࡱࠦࡐࡶࡤ࡯࡭ࡨࠦࡌࡪࡥࡨࡲࡸ࡫ࠠࡧࡱࡵࠤࡲࡵࡲࡦࠢࡧࡩࡹࡧࡩ࡭ࡵ࠱ࠎࠏࠦࠠࠡࠢ࡜ࡳࡺࠦࡳࡩࡱࡸࡰࡩࠦࡨࡢࡸࡨࠤࡷ࡫ࡣࡦ࡫ࡹࡩࡩࠦࡡࠡࡥࡲࡴࡾࠦ࡯ࡧࠢࡷ࡬ࡪࠦࡇࡏࡗࠣࡋࡪࡴࡥࡳࡣ࡯ࠤࡕࡻࡢ࡭࡫ࡦࠤࡑ࡯ࡣࡦࡰࡶࡩࠏࠦࠠࠡࠢࡤࡰࡴࡴࡧࠡࡹ࡬ࡸ࡭ࠦࡴࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱ࠳ࠦࠠࡊࡨࠣࡲࡴࡺࠬࠡࡵࡨࡩࠥࡂࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱࡫ࡳࡻ࠮ࡰࡴࡪ࠳ࡱ࡯ࡣࡦࡰࡶࡩࡸ࠵࠾࠯ࠌࠪࠫࠬ஁")
import re
import json
import urllib
import urllib2
import urlparse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs
import os
import inspect
import xbmcaddon
import sys
l1ll111lllll111l1_at_ = xbmcvfs.mkdir
l1ll1l1l11ll111l1_at_ =xbmc.translatePath
l1ll1l111lll111l1_at_ = l111lll111l1_at_ (u"࠭ࠧஂ")
def l11lll1ll111l1_at_(name, l1llll11ll111l1_at_, url, l1ll1111l1ll111l1_at_):
    if url == None: return
    try: headers = dict(urlparse.parse_qsl(url.rsplit(l111lll111l1_at_ (u"ࠧࡽࠩஃ"), 1)[1]))
    except: headers = dict(l111lll111l1_at_ (u"ࠨࠩ஄"))
    url = url.split(l111lll111l1_at_ (u"ࠩࡿࠫஅ"))[0]
    content = re.compile(l111lll111l1_at_ (u"ࠪࠬ࠳࠱࠿ࠪ࡞ࡶࡗ࠭ࡢࡤࠫࠫࡈࡠࡩ࠰ࠤࠨஆ")).findall(name)
    l1ll11ll1lll111l1_at_ = name.translate(None, l111lll111l1_at_ (u"ࠫࡡ࠵࠺ࠫࡁࠥࡀࡃࢂࠧஇ")).strip(l111lll111l1_at_ (u"ࠬ࠴ࠧஈ"))
    l1ll11l111ll111l1_at_ =[l111lll111l1_at_ (u"࠭࠮࠯࠱࠱࠲࠴࠴࠮࠰࠰࠱ࠫஉ"), l111lll111l1_at_ (u"ࠧ࠯࠰࠲࠲࠳࠵࠮࠯ࠩஊ"), l111lll111l1_at_ (u"ࠨ࠰࠱࠳࠳࠴ࠧ஋"), l111lll111l1_at_ (u"ࠩ࠱࠲ࠬ஌")]
    if len(content) == 0:
        l1lll11ll111l1_at_ = l1ll1111l1ll111l1_at_
        l1lll11ll111l1_at_ = l1ll1l1l11ll111l1_at_(l1lll11ll111l1_at_)
        for level in l1ll11l111ll111l1_at_:
            try: l1ll111lllll111l1_at_(os.path.abspath(os.path.join(l1lll11ll111l1_at_, level)))
            except: pass
        l1ll111lllll111l1_at_(l1lll11ll111l1_at_)
        l1lll11ll111l1_at_ = os.path.join(l1lll11ll111l1_at_, l1ll11ll1lll111l1_at_)
        l1ll111lllll111l1_at_(l1lll11ll111l1_at_)
    else:
        l1lll11ll111l1_at_ = l1ll1111l1ll111l1_at_
        l1lll11ll111l1_at_ = l1ll1l1l11ll111l1_at_(l1lll11ll111l1_at_)
        for level in l1ll11l111ll111l1_at_:
            try: l1ll111lllll111l1_at_(os.path.abspath(os.path.join(l1lll11ll111l1_at_, level)))
            except: pass
        l1ll111lllll111l1_at_(l1lll11ll111l1_at_)
        l1ll1l1lllll111l1_at_ = content[0][0].translate(None, l111lll111l1_at_ (u"ࠪࡠ࠴ࡀࠪࡀࠤ࠿ࡂࢁ࠭஍")).strip(l111lll111l1_at_ (u"ࠫ࠳࠭எ"))
        l1lll11ll111l1_at_ = os.path.join(l1lll11ll111l1_at_, l1ll1l1lllll111l1_at_)
        l1ll111lllll111l1_at_(l1lll11ll111l1_at_)
        l1lll11ll111l1_at_ = os.path.join(l1lll11ll111l1_at_, l111lll111l1_at_ (u"࡙ࠬࡥࡢࡵࡲࡲࠥࠫ࠰࠲ࡦࠪஏ") % int(content[0][1]))
        l1ll111lllll111l1_at_(l1lll11ll111l1_at_)
    ext = os.path.splitext(urlparse.urlparse(url).path)[1][1:]
    if not ext in [l111lll111l1_at_ (u"࠭࡭ࡱ࠶ࠪஐ"), l111lll111l1_at_ (u"ࠧ࡮࡭ࡹࠫ஑"), l111lll111l1_at_ (u"ࠨࡨ࡯ࡺࠬஒ"), l111lll111l1_at_ (u"ࠩࡤࡺ࡮࠭ஓ"), l111lll111l1_at_ (u"ࠪࡱࡵ࡭ࠧஔ")]: ext = l111lll111l1_at_ (u"ࠫࡲࡶ࠴ࠨக")
    l1lll11ll111l1_at_ = os.path.join(l1lll11ll111l1_at_, l1ll11ll1lll111l1_at_ + l111lll111l1_at_ (u"ࠬ࠴ࠧ஖") + ext)
    l1ll1l11l1ll111l1_at_ = urllib.quote_plus(json.dumps(headers))
    l1ll1l1111ll111l1_at_ = urllib.quote_plus(url)
    l1ll11l1llll111l1_at_ = urllib.quote_plus(name)
    l1ll1l11llll111l1_at_ = urllib.quote_plus(l1llll11ll111l1_at_)
    l1ll11llllll111l1_at_ = urllib.quote_plus(l1lll11ll111l1_at_)
    l1ll111l1lll111l1_at_ = __file__
    cmd = l111lll111l1_at_ (u"࠭ࡒࡶࡰࡖࡧࡷ࡯ࡰࡵࠪࠨࡷ࠱ࠦࠥࡴ࠮ࠣࠩࡸ࠲ࠠࠦࡵ࠯ࠤࠪࡹࠬࠡࠧࡶ࠭ࠬ஗") % (l1ll111l1lll111l1_at_, l1ll1l1111ll111l1_at_, l1ll11llllll111l1_at_, l1ll11l1llll111l1_at_, l1ll1l11llll111l1_at_, l1ll1l11l1ll111l1_at_)
    xbmc.executebuiltin(cmd)
def l1ll11l11lll111l1_at_(url, headers, size):
    try:
        if size > 0:
            size = int(size)
            headers[l111lll111l1_at_ (u"ࠧࡓࡣࡱ࡫ࡪ࠭஘")] = l111lll111l1_at_ (u"ࠨࡤࡼࡸࡪࡹ࠽ࠦࡦ࠰ࠫங") % size
        req = urllib2.Request(url, headers=headers)
        resp = urllib2.urlopen(req, timeout=30)
        return resp
    except:
        return None
def l1ll1l1l1lll111l1_at_(title, l1lll11ll111l1_at_, l1ll11l1l1ll111l1_at_):
    l1ll11111lll111l1_at_ = xbmc.Player().isPlaying()
    text = xbmcgui.Window(10000).getProperty(l111lll111l1_at_ (u"ࠩࡊࡉࡓ࠳ࡄࡐ࡙ࡑࡐࡔࡇࡄࡆࡆࠪச"))
    if len(text) > 0:
        text += l111lll111l1_at_ (u"ࠪ࡟ࡈࡘ࡝ࠨ஛")
    if l1ll11l1l1ll111l1_at_:
        text += l111lll111l1_at_ (u"ࠫࠪࡹࠠ࠻ࠢࠨࡷࠬஜ") % (l1lll11ll111l1_at_.rsplit(os.sep)[-1], l111lll111l1_at_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࡬࡯ࡳࡧࡶࡸ࡬ࡸࡥࡦࡰࡠࡔࡴࡨࡩࡦࡴࡤࡲ࡮࡫ࠠࡱࡱࡺ࡭ࡴࡪूࡰࠢࡶ࡭ञࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ஝"))
    else:
        text += l111lll111l1_at_ (u"࠭ࠥࡴࠢ࠽ࠤࠪࡹࠧஞ") % (l1lll11ll111l1_at_.rsplit(os.sep)[-1], l111lll111l1_at_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࡕࡵࡢࡪࡧࡵࡥࡳ࡯ࡥࠡࡰ࡬ࡩࡺࡪࡡ࡯ࡧ࡞࠳ࡈࡕࡌࡐࡔࡠࠫட"))
    xbmcgui.Window(10000).setProperty(l111lll111l1_at_ (u"ࠨࡉࡈࡒ࠲ࡊࡏࡘࡐࡏࡓࡆࡊࡅࡅࠩ஠"), text)
    if (not l1ll11l1l1ll111l1_at_) or (not l1ll11111lll111l1_at_):
        xbmcgui.Dialog().ok(title, text)
        xbmcgui.Window(10000).l1ll111l11ll111l1_at_(l111lll111l1_at_ (u"ࠩࡊࡉࡓ࠳ࡄࡐ࡙ࡑࡐࡔࡇࡄࡆࡆࠪ஡"))
def l1ll1l1ll1ll111l1_at_(url, l1lll11ll111l1_at_, title, l1llll11ll111l1_at_, headers):
    headers = json.loads(urllib.unquote_plus(headers))
    url = urllib.unquote_plus(url)
    title = urllib.unquote_plus(title)
    l1llll11ll111l1_at_ = urllib.unquote_plus(l1llll11ll111l1_at_)
    l1lll11ll111l1_at_ = urllib.unquote_plus(l1lll11ll111l1_at_)
    file = l1lll11ll111l1_at_.rsplit(os.sep, 1)[-1]
    resp = l1ll11l11lll111l1_at_(url, headers, 0)
    if not resp:
        xbmcgui.Dialog().ok(title, l1lll11ll111l1_at_, l111lll111l1_at_ (u"ࠪࡔࡴࡨࡩࡦࡴࡤࡲ࡮࡫ࠠ࡯࡫ࡨࡹࡩࡧ࡮ࡦࠩ஢"), l111lll111l1_at_ (u"ࠫࡘ࡫ࡲࡸࡧࡵࠤࡳ࡯ࡥࠡࡱࡧࡴࡴࡽࡩࡢࡦࡤࠫண"))
        return
    try:    content = int(resp.headers[l111lll111l1_at_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭த")])
    except: content = 0
    try:    l1ll1111llll111l1_at_ = l111lll111l1_at_ (u"࠭ࡢࡺࡶࡨࡷࠬ஥") in resp.headers[l111lll111l1_at_ (u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡓࡣࡱ࡫ࡪࡹࠧ஦")].lower()
    except: l1ll1111llll111l1_at_ = False
    if l1ll1111llll111l1_at_:
        print l111lll111l1_at_ (u"ࠣࡆࡲࡻࡳࡲ࡯ࡢࡦࠣ࡭ࡸࠦࡲࡦࡵࡸࡱࡦࡨ࡬ࡦࠤ஧")
    if content < 1:
        xbmcgui.Dialog().ok(title, file, l111lll111l1_at_ (u"ࠩࡑ࡭ࡪࢀ࡮ࡢࡰࡼࠤࡷࡵࡺ࡮࡫ࡤࡶࠥࡶ࡬ࡪ࡭ࡸࠫந"), l111lll111l1_at_ (u"ࠪࡒ࡮࡫ࠠ࡮ࡱॿࡲࡦࠦࡴࡦࡩࡲࠤࡵࡵࡢࡳࡣऊࠫன"))
        return
    size = 1024 * 1024
    l1ll111ll1ll111l1_at_   = content / (1024 * 1024)
    if content < size:
        size = content
    total   = 0
    notify  = 0
    errors  = 0
    count   = 0
    l1ll11ll11ll111l1_at_  = 0
    sleep   = 0
    if xbmcgui.Dialog().yesno(title + l111lll111l1_at_ (u"ࠫࠥ࠳ࠠࡑࡱࡷࡻ࡮࡫ࡲࡥॼࠣࡔࡴࡨࡩࡦࡴࡤࡲ࡮࡫ࠧப"), file, l111lll111l1_at_ (u"ࠬࡘ࡯ࡻ࡯࡬ࡥࡷࠦࡰ࡭࡫࡮ࡹࠥࡺ࡯ࠡࠧࡧࡑࡇ࠭஫") % l1ll111ll1ll111l1_at_, l111lll111l1_at_ (u"࠭ࡃࡻࡻࠣ࡯ࡴࡴࡴࡺࡰࡸࡳࡼࡧइࠡࡲࡲࡦ࡮࡫ࡲࡢࡰ࡬ࡩࡄ࠭஬"), l111lll111l1_at_ (u"ࠧࡕࡣ࡮ࠫ஭"),  l111lll111l1_at_ (u"ࠨࡐ࡬ࡩࠬம")) == 1:
        return
    print l111lll111l1_at_ (u"ࠩࡇࡳࡼࡴ࡬ࡰࡣࡧࠤࡋ࡯࡬ࡦࠢࡖ࡭ࡿ࡫ࠠ࠻ࠢࠨࡨࡒࡈࠠࠦࡵࠣࠫய") % (l1ll111ll1ll111l1_at_, l1lll11ll111l1_at_)
    f = xbmcvfs.File(l1lll11ll111l1_at_, l111lll111l1_at_ (u"ࠪࡻࠬர"))
    chunk  = None
    chunks = []
    while True:
        l1ll11l1l1ll111l1_at_ = total
        for c in chunks:
            l1ll11l1l1ll111l1_at_ += len(c)
        l1ll11lll1ll111l1_at_ = min(100 * l1ll11l1l1ll111l1_at_ / content, 100)
        if l1ll11lll1ll111l1_at_ >= notify:
            xbmc.executebuiltin( l111lll111l1_at_ (u"ࠦ࡝ࡈࡍࡄ࠰ࡑࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࠩࠧࡶ࠰ࠪࡹࠬࠦ࡫࠯ࠩࡸ࠯ࠢற") % ( title + l111lll111l1_at_ (u"ࠬࠦ࠭ࠡࡒࡲࡷࡹटࡰࠡࡲࡲࡦ࡮࡫ࡲࡢࡰ࡬ࡥࠥ࠳ࠠࠨல") + str(l1ll11lll1ll111l1_at_)+l111lll111l1_at_ (u"࠭ࠥࠨள"), l1lll11ll111l1_at_, 10000, l1llll11ll111l1_at_))
            print l111lll111l1_at_ (u"ࠧࡅࡱࡺࡲࡱࡵࡡࡥࠢࡳࡩࡷࡩࡥ࡯ࡶࠣ࠾ࠥࠫࡳࠡࠧࡶࠤࠪࡪࡍࡃࠢࡧࡳࡼࡴ࡬ࡰࡣࡧࡩࡩࠦ࠺ࠡࠧࡶࡑࡇࠦࡆࡪ࡮ࡨࠤࡘ࡯ࡺࡦࠢ࠽ࠤࠪࡹࡍࡃࠩழ") % (str(l1ll11lll1ll111l1_at_)+l111lll111l1_at_ (u"ࠨࠧࠪவ"), l1lll11ll111l1_at_, l1ll111ll1ll111l1_at_, l1ll11l1l1ll111l1_at_ / 1000000, content / 1000000)
            notify += 10
        chunk = None
        error = False
        try:
            chunk  = resp.read(size)
            if not chunk:
                if l1ll11lll1ll111l1_at_ < 99:
                    error = True
                else:
                    while len(chunks) > 0:
                        c = chunks.pop(0)
                        f.write(c)
                        del c
                    f.close()
                    print l111lll111l1_at_ (u"ࠩࠨࡷࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡤࡱࡰࡴࡱ࡫ࡴࡦࠩஶ") % (l1lll11ll111l1_at_)
                    return l1ll1l1l1lll111l1_at_(title, l1lll11ll111l1_at_, True)
        except Exception, e:
            print str(e)
            error = True
            sleep = 10
            errno = 0
            if hasattr(e, l111lll111l1_at_ (u"ࠪࡩࡷࡸ࡮ࡰࠩஷ")):
                errno = e.errno
            if errno == 10035:
                pass
            if errno == 10054:
                errors = 10
                sleep  = 30
            if errno == 11001:
                errors = 10
                sleep  = 30
        if chunk:
            errors = 0
            chunks.append(chunk)
            if len(chunks) > 5:
                c = chunks.pop(0)
                f.write(c)
                total += len(c)
                del c
        if error:
            errors += 1
            count  += 1
            print l111lll111l1_at_ (u"ࠫࠪࡪࠠࡆࡴࡵࡳࡷ࠮ࡳࠪࠢࡺ࡬࡮ࡲࡳࡵࠢࡧࡳࡼࡴ࡬ࡰࡣࡧ࡭ࡳ࡭ࠠࠦࡵࠪஸ") % (count, l1lll11ll111l1_at_)
            xbmc.sleep(sleep*1000)
        if (l1ll1111llll111l1_at_ and errors > 0) or errors >= 10:
            if (not l1ll1111llll111l1_at_ and l1ll11ll11ll111l1_at_ >= 50) or l1ll11ll11ll111l1_at_ >= 500:
                print l111lll111l1_at_ (u"ࠬࠫࡳࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡧࡦࡴࡣࡦ࡮ࡨࡨࠥ࠳ࠠࡵࡱࡲࠤࡲࡧ࡮ࡺࠢࡨࡶࡷࡵࡲࠡࡹ࡫࡭ࡱࡹࡴࠡࡦࡲࡻࡳࡲ࡯ࡢࡦ࡬ࡲ࡬࠭ஹ") % (l1lll11ll111l1_at_)
                return l1ll1l1l1lll111l1_at_(title, l1lll11ll111l1_at_, False)
            l1ll11ll11ll111l1_at_ += 1
            errors  = 0
            if l1ll1111llll111l1_at_:
                chunks  = []
                print l111lll111l1_at_ (u"࠭ࡄࡰࡹࡱࡰࡴࡧࡤࠡࡴࡨࡷࡺࡳࡥࡥࠢࠫࠩࡩ࠯ࠠࠦࡵࠪ஺") % (l1ll11ll11ll111l1_at_, l1lll11ll111l1_at_)
                resp = l1ll11l11lll111l1_at_(url, headers, total)
            else:
                pass
if __name__ == l111lll111l1_at_ (u"ࠧࡠࡡࡰࡥ࡮ࡴ࡟ࡠࠩ஻"):
    l1ll1l1ll1ll111l1_at_(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
