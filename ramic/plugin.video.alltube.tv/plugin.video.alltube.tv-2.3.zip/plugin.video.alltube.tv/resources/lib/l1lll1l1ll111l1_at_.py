# -*- coding: utf-8 -*-
import sys
l1l1ll111l1_at_ = sys.version_info [0] == 2
l11l1ll111l1_at_ = 2048
l1ll11ll111l1_at_ = 7
def l111lll111l1_at_ (llll111l1_at_):
	global l111ll111l1_at_
	l1l1llll111l1_at_ = ord (llll111l1_at_ [-1])
	l1l1lll111l1_at_ = llll111l1_at_ [:-1]
	l1lll111l1_at_ = l1l1llll111l1_at_ % len (l1l1lll111l1_at_)
	l11ll111l1_at_ = l1l1lll111l1_at_ [:l1lll111l1_at_] + l1l1lll111l1_at_ [l1lll111l1_at_:]
	if l1l1ll111l1_at_:
		l1111ll111l1_at_ = unicode () .join ([unichr (ord (char) - l11l1ll111l1_at_ - (l1ll1ll111l1_at_ + l1l1llll111l1_at_) % l1ll11ll111l1_at_) for l1ll1ll111l1_at_, char in enumerate (l11ll111l1_at_)])
	else:
		l1111ll111l1_at_ = str () .join ([chr (ord (char) - l11l1ll111l1_at_ - (l1ll1ll111l1_at_ + l1l1llll111l1_at_) % l1ll11ll111l1_at_) for l1ll1ll111l1_at_, char in enumerate (l11ll111l1_at_)])
	return eval (l1111ll111l1_at_)
import urllib2,urllib
import re,os
import base64,json
import urlparse
import l111l1111ll111l1_at_
import cookielib
l1lllll1llll111l1_at_=l111lll111l1_at_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣ࡯ࡰࡹࡻࡢࡦ࠰ࡷࡺࠬ਴")
l111ll1llll111l1_at_ = 10
l1llll1l1lll111l1_at_=l111lll111l1_at_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶ࠠࠩࡏࡤࡧ࡮ࡴࡴࡰࡵ࡫࠿࡛ࠥ࠻ࠡࡋࡱࡸࡪࡲࠠࡎࡣࡦࠤࡔ࡙࡙ࠠࠢ࠴࠴ࡤ࠼࡟࠵࠽ࠣࡩࡳ࠳ࡕࡔࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠸࠳࠹ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠶࠯࠲࠱࠸࠼࠸࠮࠷࠵ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠺࠮࠴ࠩਵ")
l1l1ll11ll111l1_at_=l111lll111l1_at_ (u"ࡵࠫࠬਸ਼")
l1llllll1lll111l1_at_ = l111lll111l1_at_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡦࡤࡶࡲࡵࡷࡦ࠯ࡳࡶࡴࡾࡹ࠯ࡲ࡯࠳ࡧࡸ࡯ࡸࡵࡨ࠲ࡵ࡮ࡰࡀࡷࡀࠫ਷")
def _111111llll111l1_at_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l111lll111l1_at_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩਸ"), l1llll1l1lll111l1_at_)
    if cookies:
        req.add_header(l111lll111l1_at_ (u"ࠨࡃࡰࡱ࡮࡭ࡪࠨਹ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l111ll1llll111l1_at_)
        l1l1ll1lll111l1_at_ = response.read()
        response.close()
    except:
        l1l1ll1lll111l1_at_=l111lll111l1_at_ (u"ࠧࠨ਺")
    return l1l1ll1lll111l1_at_
l111l111lll111l1_at_=l111lll111l1_at_ (u"ࠨࠩ਻")
l111l111lll111l1_at_=l111lll111l1_at_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡳࡣࡰ࡯ࡦ࠳ࡰࡳࡱࡻࡽ࠳ࡶ࡬࠰਼ࠩ")
l11l11111ll111l1_at_=l111lll111l1_at_ (u"ࠪࠫ਽")
def l11111lllll111l1_at_(url,header={}):
    l1l1ll1lll111l1_at_=l111lll111l1_at_ (u"ࠫࠬਾ")
    global l11l11111ll111l1_at_
    if not l11l11111ll111l1_at_:
        req = urllib2.Request(l111l111lll111l1_at_,data=None,headers={l111lll111l1_at_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩਿ"): l1llll1l1lll111l1_at_,l111lll111l1_at_ (u"࠭ࡕࡱࡩࡵࡥࡩ࡫࠭ࡊࡰࡶࡩࡨࡻࡲࡦ࠯ࡕࡩࡶࡻࡥࡴࡶࡶࠫੀ"):1})
        response = urllib2.urlopen(req,timeout=l111ll1llll111l1_at_)
        cookies=response.headers.get(l111lll111l1_at_ (u"ࠧࡴࡧࡷ࠱ࡨࡵ࡯࡬࡫ࡨࠫੁ"),l111lll111l1_at_ (u"ࠨࠢࠪੂ")).split(l111lll111l1_at_ (u"ࠩࠣࠫ੃"))[0]
        response.close()
        l11l11111ll111l1_at_ = cookies
    else:
        cookies=l11l11111ll111l1_at_
    data = l111lll111l1_at_ (u"ࠪࡹࡂࠫࡳࠧࡣ࡯ࡰࡴࡽࡃࡰࡱ࡮࡭ࡪࡹ࠽ࡰࡰࠪ੄")%urllib.quote_plus(url)
    l1lllll1l1ll111l1_at_ = l111l111lll111l1_at_+l111lll111l1_at_ (u"ࠫ࠴࡯࡮ࡤ࡮ࡸࡨࡪࡹ࠯ࡱࡴࡲࡧࡪࡹࡳ࠯ࡲ࡫ࡴࡄࡧࡣࡵ࡫ࡲࡲࡂࡻࡰࡥࡣࡷࡩࠬ੅")
    headers={l111lll111l1_at_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ੆"): l1llll1l1lll111l1_at_,l111lll111l1_at_ (u"࠭ࡕࡱࡩࡵࡥࡩ࡫࠭ࡊࡰࡶࡩࡨࡻࡲࡦ࠯ࡕࡩࡶࡻࡥࡴࡶࡶࠫੇ"):1,l111lll111l1_at_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧੈ"):cookies}
    headers.update(header)
    req = urllib2.Request(l1lllll1l1ll111l1_at_,data,headers)
    response = urllib2.urlopen(req,timeout=l111ll1llll111l1_at_)
    l1l1ll1lll111l1_at_=response.read()
    if l111lll111l1_at_ (u"ࠨࡵࡶࡰࡦ࡭ࡲࡦࡧࠪ੉") in l1l1ll1lll111l1_at_:
        l1lllll1l1ll111l1_at_ = l111l111lll111l1_at_+l111lll111l1_at_ (u"ࠩ࠲࡭ࡳࡩ࡬ࡶࡦࡨࡷ࠴ࡶࡲࡰࡥࡨࡷࡸ࠴ࡰࡩࡲࡂࡥࡨࡺࡩࡰࡰࡀࡷࡸࡲࡡࡨࡴࡨࡩࠬ੊")
        req = urllib2.Request(l1lllll1l1ll111l1_at_,data,headers)
        response = urllib2.urlopen(req,timeout=l111ll1llll111l1_at_)
        l1l1ll1lll111l1_at_=response.read()
    response.close()
    print l111lll111l1_at_ (u"ࠪࡋࡆ࡚ࡅࠡ࡫ࡱࠤ࡚࡙ࡅࠨੋ")
    return l1l1ll1lll111l1_at_
def l1111lll1ll111l1_at_(url,data=None,header={}):
    cookies=l111l1111ll111l1_at_.l1llllllllll111l1_at_(l1l1ll11ll111l1_at_)
    content=_111111llll111l1_at_(url,data,cookies)
    if not content:
        l11l111llll111l1_at_=l1111l11lll111l1_at_(url,l1l1ll11ll111l1_at_)
        cookies=l111l1111ll111l1_at_.l1llllllllll111l1_at_(l1l1ll11ll111l1_at_)
        content=_111111llll111l1_at_(url,data,cookies)
        if not content and l1llllll1lll111l1_at_:
            content=l11111lllll111l1_at_(url,header)
            content = urllib.unquote(content)
    return content
def l1111l11lll111l1_at_(l1l1ll1lll111l1_at_,l1111llllll111l1_at_):
    l11l111llll111l1_at_ = cookielib.LWPCookieJar()
    l1111ll1lll111l1_at_ = l111l1111ll111l1_at_.l111ll11lll111l1_at_(l1lllll1llll111l1_at_,l11l111llll111l1_at_,l1llll1l1lll111l1_at_)
    l111lllllll111l1_at_=os.path.dirname(l1111llllll111l1_at_)
    if not os.path.exists(l111lllllll111l1_at_):
        os.makedirs(l111lllllll111l1_at_)
    if l1111ll1lll111l1_at_:
        l1111ll1lll111l1_at_.save(l1111llllll111l1_at_, ignore_discard = True)
    return l11l111llll111l1_at_
def _111lll11ll111l1_at_(href):
    url = href.replace(l111lll111l1_at_ (u"ࠫ࠴ࡨࡲࡰࡹࡶࡩ࠳ࡶࡨࡱࡁࡸࡁࠬੌ"),l111lll111l1_at_ (u"੍ࠬ࠭"))
    url = url.split(l111lll111l1_at_ (u"࠭ࠦࡢ࡯ࡳ࠿ࠬ੎"))[0]
    return urllib.unquote(url)
def l1ll111lll111l1_at_(url,l1l11l1ll111l1_at_=1,data=None):
    if l111lll111l1_at_ (u"ࠧࡴࡶࡵࡳࡳࡧࠧ੏") in url:
        url = re.sub(l111lll111l1_at_ (u"ࡳࠩࡶࡸࡷࡵ࡮ࡢ࡞࡞ࡠࡩ࠱࡜࡞ࠩ੐"),l111lll111l1_at_ (u"ࠩࡶࡸࡷࡵ࡮ࡢ࡝ࠨࡨࡢ࠭ੑ")%l1l11l1ll111l1_at_,url)
    elif l111lll111l1_at_ (u"ࠪ࠳ࡦࡱࡴࡰࡴ࠲ࠫ੒") not in url and l1l11l1ll111l1_at_>1:
        url = url[:-1] if url[-2:] == l111lll111l1_at_ (u"ࠫ࠰࠵ࠧ੓") else url
        url = url + l111lll111l1_at_ (u"ࠬࡹࡴࡳࡱࡱࡥࡠࠫࡤ࡞࠭ࠪ੔")%l1l11l1ll111l1_at_
    content = l1111lll1ll111l1_at_(url,data)
    ids = [(a.start(), a.end()) for a in re.finditer(l111lll111l1_at_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦ࡮ࡺࡥ࡮࠯ࡥࡰࡴࡩ࡫ࠡࡥ࡯ࡩࡦࡸࡦࡪࡺࠥࡂࠬ੕"), content)]
    if not ids:
        ids = [(a.start(), a.end()) for a in re.finditer(l111lll111l1_at_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡩࡡࡳࡶࡲࡳࡳࠨ࠾ࠨ੖"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11l11l11ll111l1_at_ = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile(l111lll111l1_at_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ੗"),re.DOTALL).search(l11l11l11ll111l1_at_)
        title = re.compile(l111lll111l1_at_ (u"ࠩ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠴ࡀࠪ੘"),re.DOTALL).search(l11l11l11ll111l1_at_)
        l11111ll1ll111l1_at_= re.compile(l111lll111l1_at_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡵࡨࡧࡴࡴࡤ࠮ࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ਖ਼")).search(l11l11l11ll111l1_at_)
        l111l1lllll111l1_at_ = re.compile(l111lll111l1_at_ (u"ࠫࡁࡶ࡛࡟ࡀࡠ࠮ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡶ࠾ࠨਗ਼"),re.DOTALL).search(l11l11l11ll111l1_at_)
        l111l1l1lll111l1_at_ = re.compile(l111lll111l1_at_ (u"ࠬࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨਜ਼"),re.DOTALL).search(l11l11l11ll111l1_at_)
        year = re.compile(l111lll111l1_at_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦ࡮ࡺࡥ࡮࠯ࡧࡩࡹࡧࡩ࡭ࡵࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫੜ"),re.DOTALL).search(l11l11l11ll111l1_at_)
        l11111111ll111l1_at_ = re.compile(l111lll111l1_at_ (u"ࠧࡢࡴ࡬ࡥ࠲࡮ࡩࡥࡦࡨࡲࡂࠨࡴࡳࡷࡨࠦࡃࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩ੝")).search(l11l11l11ll111l1_at_)
        if year:
            year =  re.compile(l111lll111l1_at_ (u"ࠨࠪ࡟ࡨࢀ࠺ࡽࠪࠩਫ਼"),re.DOTALL).search(year.group(1))
        l11111111ll111l1_at_ = l11111111ll111l1_at_.group(1).replace(l111lll111l1_at_ (u"ࠩࠩࡲࡧࡹࡰ࠼ࠩ੟"),l111lll111l1_at_ (u"ࠪࠫ੠")).strip() if l11111111ll111l1_at_ else l111lll111l1_at_ (u"ࠫࠬ੡")
        if href and title:
            l111l1l1lll111l1_at_ = l111l1l1lll111l1_at_.group(1).strip() if l111l1l1lll111l1_at_ else l111lll111l1_at_ (u"ࠬ࠭੢")
            l1lll1llll111l1_at_ = {l111lll111l1_at_ (u"࠭ࡨࡳࡧࡩࠫ੣")   : _111lll11ll111l1_at_(href.group(1).strip()),
                l111lll111l1_at_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭੤")  : l11ll1llll111l1_at_(title.group(1)),
                l111lll111l1_at_ (u"ࠨࡲ࡯ࡳࡹ࠭੥")   : l11ll1llll111l1_at_(l111l1lllll111l1_at_.group(1)) if l111l1lllll111l1_at_ else l111lll111l1_at_ (u"ࠩࠪ੦"),
                l111lll111l1_at_ (u"ࠪ࡭ࡲ࡭ࠧ੧")    : _111lll11ll111l1_at_(l111l1l1lll111l1_at_),
                l111lll111l1_at_ (u"ࠫࡾ࡫ࡡࡳࠩ੨")   : year.group(1) if year else l111lll111l1_at_ (u"ࠬࡅࠧ੩"),
                l111lll111l1_at_ (u"࠭ࡣࡰࡦࡨࠫ੪")   : l11111111ll111l1_at_,
                    }
            out.append(l1lll1llll111l1_at_)
    l111l11l1ll111l1_at_=False
    if content.find(l111lll111l1_at_ (u"ࠧࡴࡶࡵࡳࡳࡧ࡛ࠦࡦࡠࠫ੫")%(l1l11l1ll111l1_at_+1))>-1:
        l111l11l1ll111l1_at_ = l1l11l1ll111l1_at_+1
    l111lll1lll111l1_at_ = l1l11l1ll111l1_at_-1 if l1l11l1ll111l1_at_>1 else False
    return (out, (l111lll1lll111l1_at_,l111l11l1ll111l1_at_))
def l11lllllll111l1_at_(url,l1l11l1ll111l1_at_=1,data=None):
    l111l11llll111l1_at_ = url + l111lll111l1_at_ (u"ࠨࠧࡧࠫ੬")%l1l11l1ll111l1_at_
    content = l1111lll1ll111l1_at_(l111l11llll111l1_at_,data)
    ids = [(a.start(), a.end()) for a in re.finditer(l111lll111l1_at_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡧࡷࡱ࠱ࡧࡲ࡯ࡤ࡭ࠣࡧࡱ࡫ࡡࡳࡨ࡬ࡼࠧࡄࠧ੭"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11l11l11ll111l1_at_ = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile(l111lll111l1_at_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ੮"),re.DOTALL).search(l11l11l11ll111l1_at_)
        l111l1l1lll111l1_at_ = re.compile(l111lll111l1_at_ (u"ࠫࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ੯"),re.DOTALL).search(l11l11l11ll111l1_at_)
        l111111l1ll111l1_at_ = re.compile(l111lll111l1_at_ (u"ࠬࡂࡨ࠴࠰࠭ࡂ࠭࠴ࠪࡀࠫ࠿ࠫੰ")).search(l11l11l11ll111l1_at_)
        l1111111lll111l1_at_ = re.compile(l111lll111l1_at_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡧࡵࡴࡵࡱࡰ࠱ࡧ࡫࡬ࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪੱ")).search(l11l11l11ll111l1_at_)
        if href and l111111l1ll111l1_at_:
            title = l11ll1llll111l1_at_(l111111l1ll111l1_at_.group(1))
            l111l1lllll111l1_at_ = l11ll1llll111l1_at_(l1111111lll111l1_at_.group(1)) if l1111111lll111l1_at_ else l111lll111l1_at_ (u"ࠧࠨੲ")
            l1lll1llll111l1_at_ = {l111lll111l1_at_ (u"ࠨࡪࡵࡩ࡫࠭ੳ")   : _111lll11ll111l1_at_(href.group(1)),
                l111lll111l1_at_ (u"ࠩࡷ࡭ࡹࡲࡥࠨੴ")  : title,
                l111lll111l1_at_ (u"ࠪࡴࡱࡵࡴࠨੵ")   : l111l1lllll111l1_at_,
                l111lll111l1_at_ (u"ࠫ࡮ࡳࡧࠨ੶")    : _111lll11ll111l1_at_(l111l1l1lll111l1_at_.group(1)) if l111l1l1lll111l1_at_ else l111lll111l1_at_ (u"ࠬ࠭੷"),
                    }
            out.append(l1lll1llll111l1_at_)
    l111l11l1ll111l1_at_=False
    if content.find(l111lll111l1_at_ (u"࠭ࡨࡳࡧࡩࡁࠧࠫࡤࠣࠩ੸")%(l1l11l1ll111l1_at_+1))>-1:
        l111l11l1ll111l1_at_ = l1l11l1ll111l1_at_+1
    l111lll1lll111l1_at_ = l1l11l1ll111l1_at_-1 if l1l11l1ll111l1_at_>1 else False
    return (out, (l111lll1lll111l1_at_,l111l11l1ll111l1_at_))
def l1l1l1llll111l1_at_(data=None,l1l11l1ll111l1_at_=1):
    url=l111lll111l1_at_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡢ࡮࡯ࡸࡺࡨࡥ࠯ࡶࡹ࠳ࡸ࡫ࡲࡪࡣ࡯ࡩ࠲ࡵ࡮࡭࡫ࡱࡩ࠴࠭੹")
    l111l11llll111l1_at_ = url + l111lll111l1_at_ (u"ࠨࠧࡧࠫ੺")%l1l11l1ll111l1_at_
    content = l1111lll1ll111l1_at_(l111l11llll111l1_at_,data)
    ids = [(a.start(), a.end()) for a in re.finditer(l111lll111l1_at_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡪࡶࡨࡱ࠲ࡨ࡬ࡰࡥ࡮ࠤࡨࡲࡥࡢࡴࡩ࡭ࡽࠨ࠾ࠨ੻"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11l11l11ll111l1_at_ = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile(l111lll111l1_at_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ੼"),re.DOTALL).search(l11l11l11ll111l1_at_)
        l111l1l1lll111l1_at_ = re.compile(l111lll111l1_at_ (u"ࠫࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ੽"),re.DOTALL).search(l11l11l11ll111l1_at_)
        l111111l1ll111l1_at_ = re.compile(l111lll111l1_at_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡸࡴࡶ࠭ࡣࡧ࡯ࡸࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭੾")).search(l11l11l11ll111l1_at_)
        l1111111lll111l1_at_ = re.compile(l111lll111l1_at_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡧࡵࡴࡵࡱࡰ࠱ࡧ࡫࡬ࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ੿")).search(l11l11l11ll111l1_at_)
        if href and l111111l1ll111l1_at_:
            title = l11ll1llll111l1_at_(l111111l1ll111l1_at_.group(1))
            if l1111111lll111l1_at_:
               title = l11ll1llll111l1_at_(l1111111lll111l1_at_.group(1)) +l111lll111l1_at_ (u"ࠧ࠭ࠢࠪ઀") + title
            l1lll1llll111l1_at_ = {l111lll111l1_at_ (u"ࠨࡪࡵࡩ࡫࠭ઁ")   : _111lll11ll111l1_at_(href.group(1)),
                l111lll111l1_at_ (u"ࠩࡷ࡭ࡹࡲࡥࠨં")  : title,
                l111lll111l1_at_ (u"ࠪ࡭ࡲ࡭ࠧઃ")    : _111lll11ll111l1_at_(l111l1l1lll111l1_at_.group(1)) if l111l1l1lll111l1_at_ else l111lll111l1_at_ (u"ࠫࠬ઄"),
                    }
            out.append(l1lll1llll111l1_at_)
    l111l11l1ll111l1_at_=False
    if content.find(l111lll111l1_at_ (u"ࠬ࡮ࡲࡦࡨࡀࠦࠪࡪࠢࠨઅ")%(l1l11l1ll111l1_at_+1))>-1:
        l111l11l1ll111l1_at_ = l1l11l1ll111l1_at_+1
    l111lll1lll111l1_at_ = l1l11l1ll111l1_at_-1 if l1l11l1ll111l1_at_>1 else False
    return (out, (l111lll1lll111l1_at_,l111l11l1ll111l1_at_))
def l11ll111ll111l1_at_(url):
    content = l1111lll1ll111l1_at_(url)
    l11ll1ll111l1_at_ = re.compile(l111lll111l1_at_ (u"࠭࠼࡭࡫ࠣࡧࡱࡧࡳࡴ࠿ࠥࡩࡵ࡯ࡳࡰࡦࡨࠦࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀ࠿࠳ࡱ࡯࠾ࠨઆ")).findall(content)
    out=[]
    for e in l11ll1ll111l1_at_:
        l1111l1l1ll111l1_at_ = re.findall(l111lll111l1_at_ (u"ࠧࡴࠪ࡟ࡨ࠰࠯ࠧઇ"),e[1],flags=re.I)
        l1111l1l1ll111l1_at_ = int(l1111l1l1ll111l1_at_[0]) if l1111l1l1ll111l1_at_ else l111lll111l1_at_ (u"ࠨࠩઈ")
        l1lllllll1ll111l1_at_ = re.findall(l111lll111l1_at_ (u"ࠩࡨࠬࡡࡪࠫࠪࠩઉ"),e[1],flags=re.I)
        l1lllllll1ll111l1_at_ = int(l1lllllll1ll111l1_at_[0]) if l1lllllll1ll111l1_at_ else l111lll111l1_at_ (u"ࠪࠫઊ")
        l1lll1llll111l1_at_ = { l111lll111l1_at_ (u"ࠫ࡭ࡸࡥࡧࠩઋ")  : _111lll11ll111l1_at_(e[0]),
                l111lll111l1_at_ (u"ࠬࡹࡥࡢࡵࡲࡲࠬઌ") : l1111l1l1ll111l1_at_,
                l111lll111l1_at_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࠧઍ") : l1lllllll1ll111l1_at_,
                l111lll111l1_at_ (u"ࠧ࡮ࡧࡧ࡭ࡦࡺࡹࡱࡧࠪ઎"): l111lll111l1_at_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࠩએ"),
                l111lll111l1_at_ (u"ࠩࡷ࡭ࡹࡲࡥࠨઐ") : l11ll1llll111l1_at_(e[1].strip())}
        out.append(l1lll1llll111l1_at_)
    return out
def l1l1lllll111l1_at_(out):
    l111ll1l1ll111l1_at_={}
    l11l111lll111l1_at_ = [x.get(l111lll111l1_at_ (u"ࠪࡷࡪࡧࡳࡰࡰࠪઑ")) for x in out]
    for s in set(l11l111lll111l1_at_):
        l111ll1l1ll111l1_at_[l111lll111l1_at_ (u"ࠫࡘ࡫ࡺࡰࡰࠣࠩ࠵࠸ࡤࠨ઒")%s]=[out[i] for i, j in enumerate(l11l111lll111l1_at_) if j == s]
    return l111ll1l1ll111l1_at_
def l1ll1l1ll111l1_at_(url,host=l111lll111l1_at_ (u"ࠬ࠭ઓ")):
    if l111lll111l1_at_ (u"࠭ࡣࡥࡣࠪઔ") in host:
        return l111lll111l1_at_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡨࡪࡡ࠯ࡲ࡯࠳ࡻ࡯ࡤࡦࡱ࠲ࠩࡸ࠭ક")%(url.split(l111lll111l1_at_ (u"ࠨ࡫ࡧࡁࠬખ"))[-1])
    elif l111lll111l1_at_ (u"ࠩࡳࡳࡸ࡯ࡥࡥࡼࡨࠫગ") in host:
        return l111lll111l1_at_ (u"ࠪࠫઘ")
    elif l111lll111l1_at_ (u"ࠫࡦࡲ࡬ࡵࡷࡥࡩ࠳ࡺࡶࠨઙ") in url:
        content = l1111lll1ll111l1_at_(url)
        l11111l11ll111l1_at_=l111lll111l1_at_ (u"ࠬ࠭ચ")
        href= re.compile(l111lll111l1_at_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫછ")).findall(content)
        if href:
            href = [h for h in href if l111l111lll111l1_at_ not in h]
            l11111l11ll111l1_at_ = _111lll11ll111l1_at_(href[0])
            if l11111l11ll111l1_at_.startswith(l111lll111l1_at_ (u"ࠧ࠰࠱ࠪજ")):
                l11111l11ll111l1_at_ = l111lll111l1_at_ (u"ࠨࡪࡷࡸࡵࡀࠧઝ")+l11111l11ll111l1_at_
        return l11111l11ll111l1_at_
    elif host in url:
        if url.startswith(l111lll111l1_at_ (u"ࠩ࠲࠳ࠬઞ")):
            url = l111lll111l1_at_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩટ") + url
        return url
    else:
        return url
url=l111lll111l1_at_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡲ࡬ࡵࡷࡥࡩ࠳ࡺࡶ࠰ࡨ࡬ࡰࡲ࠵ࡡ࡯ࡶ࠰ࡱࡦࡴ࠭ࡢࡰࡷࡱࡦࡴ࠭ࡢࡰࡷ࠱ࡲࡧ࡮࠮࠴࠳࠵࠺࠵࠱࠷࠸࠹࠻ࠬઠ")
url=l111lll111l1_at_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧ࡬࡭ࡶࡸࡦࡪ࠴ࡴࡷ࠱ࡩ࡭ࡱࡳ࠯ࡵࡹࡤࡶࡩ࡫࠭࡭ࡣࡧࡳࡼࡧ࡮ࡪࡧ࠰ࡧࡷࡧࡳࡩ࠯࡯ࡥࡳࡪࡩ࡯ࡩ࠰࠶࠵࠶࠵࠰࠶࠸࠶࠾࠺ࠧડ")
def l1l1l11ll111l1_at_(url):
    content = l1111lll1ll111l1_at_(url)
    l111l1l11ll111l1_at_ = re.compile(l111lll111l1_at_ (u"࠭࠼ࡵࡤࡲࡨࡾࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡣࡱࡧࡽࡃ࠭ઢ"),re.DOTALL).findall(content)
    l111l1l11ll111l1_at_ = l111l1l11ll111l1_at_[0] if l111l1l11ll111l1_at_ else l111lll111l1_at_ (u"ࠧࠨણ")
    ids = [(a.start(), a.end()) for a in re.finditer(l111lll111l1_at_ (u"ࠨ࠾ࡷࡶࡃ࠭ત"), l111l1l11ll111l1_at_)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11l11l11ll111l1_at_ = l111l1l11ll111l1_at_[ ids[i][1]:ids[i+1][0] ]
        href = re.compile(l111lll111l1_at_ (u"ࠩࡧࡥࡹࡧ࠭ࡪࡨࡵࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨથ")).search(l11l11l11ll111l1_at_)
        l1111ll11ll111l1_at_ = re.compile(l111lll111l1_at_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸࡪࡾࡴ࠮ࡥࡨࡲࡹ࡫ࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩદ"),re.DOTALL).search(l11l11l11ll111l1_at_)
        host = re.compile(l111lll111l1_at_ (u"ࠫࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢ࠯ࠬࡂࠦࡡࡹࠪࡢ࡮ࡷࡁࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪધ")).search(l11l11l11ll111l1_at_)
        l1llll1ll1ll111l1_at_ =re.compile(l111lll111l1_at_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡸࡡࡵࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩન"),re.DOTALL).search(l11l11l11ll111l1_at_)
        if href and host:
            wersja= l1111ll11ll111l1_at_.group(1) if l1111ll11ll111l1_at_ else l111lll111l1_at_ (u"࠭ࠧ઩")
            l1111l111ll111l1_at_ = l1llll1ll1ll111l1_at_.group(1) if l1llll1ll1ll111l1_at_ else l111lll111l1_at_ (u"ࠧࠨપ")
            host  = host.groups()[-1].strip()
            l1lllll11lll111l1_at_ = base64.b64decode(href.group(1))
            if l1lllll11lll111l1_at_:
                l1lll1llll111l1_at_ = {l111lll111l1_at_ (u"ࠨࡷࡵࡰࠬફ") : l1lllll11lll111l1_at_,
                    l111lll111l1_at_ (u"ࠩࡷ࡭ࡹࡲࡥࠨબ"): l111lll111l1_at_ (u"ࠥ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞ࠧࡶ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࢂࠠࡐࡥࡨࡲࡦࠦࡌࡪࡰ࡮ࡹ࠿ࠦࠥࡴࠢࡿࠤࡠࠫࡳ࡞ࠤભ") %(wersja,l1111l111ll111l1_at_,host),
                    l111lll111l1_at_ (u"ࠫ࡭ࡵࡳࡵࠩમ"): host,
                    l111lll111l1_at_ (u"ࠬࡸࡡࡵࡧࠪય"):int(l1111l111ll111l1_at_.strip(l111lll111l1_at_ (u"࠭ࠥࠨર"))),
                    l111lll111l1_at_ (u"ࠧࡸࡧࡵࡷ࡯ࡧࠧ઱"):wersja,
                    }
                out.append(l1lll1llll111l1_at_)
            else:
                print l111lll111l1_at_ (u"ࠨࡎࡌࡒࡐࠦࡐࡓࡑࡅࡐࡊࡓ࠺ࠡࠧࡶࠫલ")%l1lllll11lll111l1_at_
    if not out:
        l1llll1lllll111l1_at_= re.compile(l111lll111l1_at_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠫ࠲࠯ࡅࠩ࠽࠱࡬ࡪࡷࡧ࡭ࡦࡀࠪળ"),re.DOTALL).findall(content)
        if l1llll1lllll111l1_at_:
            src = re.compile(l111lll111l1_at_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ઴"),re.DOTALL).findall(l1llll1lllll111l1_at_[0])
            if src:
                host = urlparse.urlparse(src[0]).netloc
                out.append( {l111lll111l1_at_ (u"ࠫࡺࡸ࡬ࠨવ") : src[0],
                    l111lll111l1_at_ (u"ࠬࡺࡩࡵ࡮ࡨࠫશ"): l111lll111l1_at_ (u"ࠨ࡛ࠦࡵࡠࠦષ") %(host),
                    l111lll111l1_at_ (u"ࠧࡩࡱࡶࡸࠬસ"): host,
                    l111lll111l1_at_ (u"ࠨࡴࡤࡸࡪ࠭હ"):0,
                    l111lll111l1_at_ (u"ࠩࡺࡩࡷࡹࡪࡢࠩ઺"):l111lll111l1_at_ (u"ࠪࠫ઻"),
                    })
    return out
l111ll111ll111l1_at_=l111lll111l1_at_ (u"ࠫࡼ࡯࡬࡭ࠢࡶࡱ࡮ࡺࡨࠨ઼")
def l1ll1111ll111l1_at_(l111ll111ll111l1_at_=l111lll111l1_at_ (u"ࠬ࡬ࡵࡵࡷࡵࡥࡲࡧࠧઽ")):
    l11l111l1ll111l1_at_=[]
    l111ll1l1ll111l1_at_=[]
    l11l1111lll111l1_at_=[]
    url=l111lll111l1_at_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡ࡭࡮ࡷࡹࡧ࡫࠮ࡵࡸ࠲࡭ࡳࡪࡥࡹ࠰ࡳ࡬ࡵࡅࡵࡳ࡮ࡀࡷࡪࡧࡲࡤࡪ࠲ࡥࡺࡺ࡯ࡤࡱࡰࡴࡱ࡫ࡴࡦ࠱ࠩࡴ࡭ࡸࡡࡴࡧࡀࠩࡸ࠭ા")%urllib.quote_plus(l111ll111ll111l1_at_)
    content= l1111lll1ll111l1_at_(url)
    if content:
        items=json.loads(content)
        for item in items.get(l111lll111l1_at_ (u"ࠧࡴࡷࡪ࡫ࡪࡹࡴࡪࡱࡱࡷࠬિ"),[]):
            href  = item.get(l111lll111l1_at_ (u"ࠨࡦࡤࡸࡦ࠭ી"),l111lll111l1_at_ (u"ࠩࠪુ"))
            title = l11ll1llll111l1_at_(item.get(l111lll111l1_at_ (u"ࠪࡺࡦࡲࡵࡦࠩૂ"),l111lll111l1_at_ (u"ࠫࠬૃ")))
            if l111lll111l1_at_ (u"ࠬࡹࡥࡳ࡫ࡤࡰࠬૄ") in href:
                l111ll1l1ll111l1_at_.append({l111lll111l1_at_ (u"࠭ࡴࡪࡶ࡯ࡩࠬૅ"):title,l111lll111l1_at_ (u"ࠧࡩࡴࡨࡪࠬ૆"):href})
            elif l111lll111l1_at_ (u"ࠨ࠱ࡤ࡯ࡹࡵࡲ࠰ࠩે") in href:
                l11l1111lll111l1_at_.append({l111lll111l1_at_ (u"ࠩࡷ࡭ࡹࡲࡥࠨૈ"):title,l111lll111l1_at_ (u"ࠪ࡬ࡷ࡫ࡦࠨૉ"):href})
            else:
                l11l111l1ll111l1_at_.append({l111lll111l1_at_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ૊"):title,l111lll111l1_at_ (u"ࠬ࡮ࡲࡦࡨࠪો"):href})
    return (l11l111l1ll111l1_at_,l111ll1l1ll111l1_at_,l11l1111lll111l1_at_)
def l1ll11llll111l1_at_():
    content=l1111lll1ll111l1_at_(l111lll111l1_at_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡ࡭࡮ࡷࡹࡧ࡫࠮ࡵࡸ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸ࠴࠭ૌ"))
    ids = [(a.start(), a.end()) for a in re.finditer(l111lll111l1_at_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠭ࡪࡶࡨࡱ્ࠬ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        offset=200
        l11l11l11ll111l1_at_ = content[ ids[i][1]-offset:ids[i+1][0] ]
        href = re.compile(l111lll111l1_at_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡲ࡬ࡵࡷࡥࡩ࠳ࡺࡶ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡤ࠲࠯ࡅࠩࠣࠩ૎")).search(l11l11l11ll111l1_at_)
        title = re.compile(l111lll111l1_at_ (u"ࠩ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠴ࡀࠪ૏")).search(l11l11l11ll111l1_at_)
        l1llllll11ll111l1_at_ = re.compile(l111lll111l1_at_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡰ࠲ࡹ࡭࠮࠸ࠣࡸࡪࡾࡴ࠮ࡴ࡬࡫࡭ࡺࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ૐ"),re.DOTALL).search(l11l11l11ll111l1_at_)
        l1llllll11ll111l1_at_ = l1llllll11ll111l1_at_.group(1).replace(l111lll111l1_at_ (u"ࠫࠫࡴࡢࡴࡲ࠾ࠫ૑"),l111lll111l1_at_ (u"ࠬ࠭૒")).strip().replace(l111lll111l1_at_ (u"࠭ࠠࠡࠩ૓"),l111lll111l1_at_ (u"ࠧࠡࠩ૔")) if l1llllll11ll111l1_at_ else l111lll111l1_at_ (u"ࠨࠩ૕")
        if href and title:
            title= l11ll1llll111l1_at_(title.group(1)) if title else l111lll111l1_at_ (u"ࠩࠪ૖")
            l1llllll11ll111l1_at_ = l11ll1llll111l1_at_(l1llllll11ll111l1_at_)
            l111llll1ll111l1_at_ = href.group(1)
            l1lll1llll111l1_at_ = {l111lll111l1_at_ (u"ࠪ࡬ࡷ࡫ࡦࠨ૗") : l111llll1ll111l1_at_,
                   l111lll111l1_at_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ૘"): l111lll111l1_at_ (u"ࠧࡡࡃࡐࡎࡒࡖࠥࡩࡹࡢࡰࡠࠩࡸࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࡜ࠧࡶࡡࠧ૙") %(title,l1llllll11ll111l1_at_),
                    }
            out.append(l1lll1llll111l1_at_)
    return out
def l111111ll111l1_at_(url,l1l11l1ll111l1_at_=1):
    l1l11l1ll111l1_at_ = int(l1l11l1ll111l1_at_)
    l11l111l1ll111l1_at_=[]
    l111ll1l1ll111l1_at_=[]
    url = re.sub(l111lll111l1_at_ (u"࠭ࡌ࠲ࡺ࡮ࡏࡾࡗ࠽ࠨ૚").decode(l111lll111l1_at_ (u"ࠧࡣࡣࡶࡩ࠻࠺ࠧ૛")),l111lll111l1_at_ (u"ࠨ࠱ࠨࡨࠬ૜")%l1l11l1ll111l1_at_,url)
    content=l1111lll1ll111l1_at_(url)
    ids = [(a.start(), a.end()) for a in re.finditer(l111lll111l1_at_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡪࡶࡨࡱ࠲ࡨ࡬ࡰࡥ࡮ࠤࡨࡲࡥࡢࡴࡩ࡭ࡽࠨ࠾ࠨ૝"), content)]
    ids.append( (-1,-1) )
    for i in range(len(ids[:-1])):
        l11l11l11ll111l1_at_ = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile(l111lll111l1_at_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ૞"),re.DOTALL).search(l11l11l11ll111l1_at_)
        title = re.compile(l111lll111l1_at_ (u"ࠫࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠶ࡂࠬ૟"),re.DOTALL).search(l11l11l11ll111l1_at_)
        l11111ll1ll111l1_at_= re.compile(l111lll111l1_at_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡷࡪࡩ࡯࡯ࡦ࠰ࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨૠ")).search(l11l11l11ll111l1_at_)
        l111l1lllll111l1_at_ = re.compile(l111lll111l1_at_ (u"࠭࠼ࡱ࡝ࡡࡂࡢ࠰࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡱࡀࠪૡ"),re.DOTALL).search(l11l11l11ll111l1_at_)
        l111l1l1lll111l1_at_ = re.compile(l111lll111l1_at_ (u"ࠧ࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪૢ"),re.DOTALL).search(l11l11l11ll111l1_at_)
        year = re.compile(l111lll111l1_at_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡩࡵࡧࡰ࠱ࡩ࡫ࡴࡢ࡫࡯ࡷࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ૣ"),re.DOTALL).search(l11l11l11ll111l1_at_)
        if year:
            year =  re.compile(l111lll111l1_at_ (u"ࠩࠫࡠࡩࢁ࠴ࡾࠫࠪ૤"),re.DOTALL).search(year.group(1))
        if href and title:
            l111l1l1lll111l1_at_ = l111l1l1lll111l1_at_.group(1) if l111l1l1lll111l1_at_ else l111lll111l1_at_ (u"ࠪࠫ૥")
            l1lll1llll111l1_at_ = {l111lll111l1_at_ (u"ࠫ࡭ࡸࡥࡧࠩ૦")   : href.group(1),
                l111lll111l1_at_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ૧")  : l11ll1llll111l1_at_(title.group(1)),
                l111lll111l1_at_ (u"࠭ࡰ࡭ࡱࡷࠫ૨")   : l11ll1llll111l1_at_(l111l1lllll111l1_at_.group(1)) if l111l1lllll111l1_at_ else l111lll111l1_at_ (u"ࠧࠨ૩"),
                l111lll111l1_at_ (u"ࠨ࡫ࡰ࡫ࠬ૪")    : l111l1l1lll111l1_at_,
                l111lll111l1_at_ (u"ࠩࡼࡩࡦࡸࠧ૫")   : year.group(1) if year else l111lll111l1_at_ (u"ࠪࡃࠬ૬"),
                    }
            if l111lll111l1_at_ (u"ࠫ࠴࡬ࡩ࡭࡯࠲ࠫ૭") in l1lll1llll111l1_at_.get(l111lll111l1_at_ (u"ࠬ࡮ࡲࡦࡨࠪ૮")):
                l11l111l1ll111l1_at_.append(l1lll1llll111l1_at_)
            else:
                l111ll1l1ll111l1_at_.append(l1lll1llll111l1_at_)
    l111l11l1ll111l1_at_=False
    if content.find(l111lll111l1_at_ (u"࠭ࡳࡵࡴࡲࡲࡦࠨࠠࡩࡴࡨࡪࡂࠨࠥࡥࠤࠪ૯")%(l1l11l1ll111l1_at_+1))>-1:
        l111l11l1ll111l1_at_ = l1l11l1ll111l1_at_+1
    l111lll1lll111l1_at_ = l1l11l1ll111l1_at_-1 if l1l11l1ll111l1_at_>1 else False
    return ((l11l111l1ll111l1_at_,l111ll1l1ll111l1_at_), (l111lll1lll111l1_at_,l111l11l1ll111l1_at_))
def filter(l111l1ll1ll111l1_at_):
    content = l1111lll1ll111l1_at_(l111lll111l1_at_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡢ࡮࡯ࡸࡺࡨࡥ࠯ࡶࡹ࠳࡫࡯࡬࡮ࡻ࠰ࡳࡳࡲࡩ࡯ࡧ࠲ࠫ૰"))
    if   l111l1ll1ll111l1_at_ == l111lll111l1_at_ (u"ࠨ࡭ࡤࡸࡪ࡭࡯ࡳ࡫ࡤࠫ૱"):
        filter = re.compile(l111lll111l1_at_ (u"ࠩ࠿ࡹࡱࠦࡣ࡭ࡣࡶࡷࡂࠨࡦࡪ࡮ࡷࡩࡷ࠳࡬ࡪࡵࡷࠤ࡫࡯࡬ࡵࡧࡵ࠱ࡨࡧࡴࡦࡩࡲࡶࡾࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ૲"),re.DOTALL).findall(content)
        pattern = l111lll111l1_at_ (u"ࠪ࡯ࡦࡺࡥࡨࡱࡵ࡭ࡦࡡࠥࡴ࡟࠮ࠫ૳")
    elif l111l1ll1ll111l1_at_ ==l111lll111l1_at_ (u"ࠫࡷࡵ࡫ࠨ૴"):
        filter = re.compile(l111lll111l1_at_ (u"ࠬࡂࡵ࡭ࠢࡦࡰࡦࡹࡳ࠾ࠤࡩ࡭ࡱࡺࡥࡳ࠯࡯࡭ࡸࡺࠢࠡ࡫ࡧࡁࠧ࡬ࡩ࡭ࡶࡨࡶ࠲ࡿࡥࡢࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ૵"),re.DOTALL).findall(content)
        pattern = l111lll111l1_at_ (u"࠭ࡲࡰ࡭࡞ࠩࡸࡣࠫࠨ૶")
    elif l111l1ll1ll111l1_at_ ==l111lll111l1_at_ (u"ࠧࡸࡧࡵࡷ࡯ࡧࠧ૷"):
        filter = re.compile(l111lll111l1_at_ (u"ࠨ࠾ࡸࡰࠥࡩ࡬ࡢࡵࡶࡁࠧ࡬ࡩ࡭ࡶࡨࡶ࠲ࡲࡩࡴࡶࠥࠤ࡮ࡪ࠽ࠣࡨ࡬ࡰࡹ࡫ࡲ࠮ࡸࡨࡶࡸ࡯࡯࡯ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ૸"),re.DOTALL).findall(content)
        pattern = l111lll111l1_at_ (u"ࠩࡺࡩࡷࡹࡪࡢ࡝ࠨࡷࡢ࠱ࠧૹ")
    else:
        filter = []
    if filter:
        items = re.compile(l111lll111l1_at_ (u"ࠪࡀࡱ࡯ࠠࡥࡣࡷࡥ࠲࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࡝ࡡࡂࡢ࠰࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫૺ"),re.DOTALL).findall(filter[0])
        l11111l1lll111l1_at_ = [x[0] for x in items]
        l1llll1l11ll111l1_at_ = [x[1] for x in items]
        return (l1llll1l11ll111l1_at_,l11111l1lll111l1_at_)
    return (None,None)
def l1ll1llll111l1_at_():
    content = l1111lll1ll111l1_at_(l111lll111l1_at_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡲ࡬ࡵࡷࡥࡩ࠳ࡺࡶ࠰ࡨࡸࡲ࠴࠭ૻ"))
    filter = re.compile(l111lll111l1_at_ (u"ࠬࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࡞ࡷࡢ࠰࠺࠰࠱ࡤࡰࡱࡺࡵࡣࡧ࠱ࡸࡻ࠵ࡦࡶࡰ࠲࡟ࡣࠨ࡝ࠬࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠬૼ"),re.DOTALL).findall(content)
    return filter
def l11ll1llll111l1_at_(l111ll111ll111l1_at_):
    if type(l111ll111ll111l1_at_) is not str:
        l111ll111ll111l1_at_=l111ll111ll111l1_at_.encode(l111lll111l1_at_ (u"࠭ࡵࡵࡨ࠰࠼ࠬ૽"))
    l111ll111ll111l1_at_ = l111ll111ll111l1_at_.replace(l111lll111l1_at_ (u"ࠧࠨࠩࠩࡲࡧࡹࡰ࠼ࠩࠪࠫ૾"),l111lll111l1_at_ (u"ࠨࠩ૿"))
    l111ll111ll111l1_at_ = l111ll111ll111l1_at_.replace(l111lll111l1_at_ (u"ࠩࠪࠫࠫࡷࡵࡰࡶ࠾ࠫࠬ࠭଀"),l111lll111l1_at_ (u"ࠪࠦࠬଁ"))
    l111ll111ll111l1_at_ = l111ll111ll111l1_at_.replace(l111lll111l1_at_ (u"ࠫࠬ࠭ࠦࡣࡦࡴࡹࡴࡁࠧࠨࠩଂ"),l111lll111l1_at_ (u"ࠬࡢࠧࠨଃ"))
    l111ll111ll111l1_at_ = l111ll111ll111l1_at_.replace(l111lll111l1_at_ (u"࠭ࠧࠨࠨࡵࡨࡶࡻ࡯࠼ࠩࠪࠫ଄"),l111lll111l1_at_ (u"ࠧ࡝ࠩࠪଅ"))
    l111ll111ll111l1_at_ = l111ll111ll111l1_at_.replace(l111lll111l1_at_ (u"ࠨࠩࠪࠪࡴࡧࡣࡶࡶࡨ࠿ࠬ࠭ࠧଆ"),l111lll111l1_at_ (u"ࣶࠩࠫଇ")).replace(l111lll111l1_at_ (u"ࠪࠫࠬࠬࡏࡢࡥࡸࡸࡪࡁࠧࠨࠩଈ"),l111lll111l1_at_ (u"ࠫࣘ࠭ଉ"))
    l1111l1llll111l1_at_=l111lll111l1_at_ (u"ࠬ࠸࠶࠳࠵࠸ࡧ࠻࠺࠲ࡣ࠵ࡥࠫଊ")
    l1lllll111ll111l1_at_=l111lll111l1_at_ (u"࠭࠲࠷࠷ࡥ࠹ࡪ࠹ࡢ࠶ࡦ࠶ࡦࠬଋ")
    l111ll111ll111l1_at_ = re.sub(l1111l1llll111l1_at_.decode(l111lll111l1_at_ (u"ࠧࡩࡧࡻࠫଌ")),l111lll111l1_at_ (u"ࠨࠩ଍"),l111ll111ll111l1_at_)
    l111ll111ll111l1_at_ = re.sub(l1lllll111ll111l1_at_.decode(l111lll111l1_at_ (u"ࠩ࡫ࡩࡽ࠭଎")),l111lll111l1_at_ (u"ࠪࠫଏ"),l111ll111ll111l1_at_)
    l111ll111ll111l1_at_ = l111ll111ll111l1_at_.replace(l111lll111l1_at_ (u"ࠫࠬ࠭ࠦࡢ࡯ࡳ࠿ࠬ࠭ࠧଐ"),l111lll111l1_at_ (u"ࠬࠬࠧ଑"))
    l111ll111ll111l1_at_ = l111ll111ll111l1_at_.replace(l111lll111l1_at_ (u"࠭࡜ࡶ࠲࠴࠴࠺࠭଒"),l111lll111l1_at_ (u"ࠧआࠩଓ")).replace(l111lll111l1_at_ (u"ࠨ࡞ࡸ࠴࠶࠶࠴ࠨଔ"),l111lll111l1_at_ (u"ࠩइࠫକ"))
    l111ll111ll111l1_at_ = l111ll111ll111l1_at_.replace(l111lll111l1_at_ (u"ࠪࡠࡺ࠶࠱࠱࠹ࠪଖ"),l111lll111l1_at_ (u"ࠫऌ࠭ଗ")).replace(l111lll111l1_at_ (u"ࠬࡢࡵ࠱࠳࠳࠺ࠬଘ"),l111lll111l1_at_ (u"࠭आࠨଙ"))
    l111ll111ll111l1_at_ = l111ll111ll111l1_at_.replace(l111lll111l1_at_ (u"ࠧ࡝ࡷ࠳࠵࠶࠿ࠧଚ"),l111lll111l1_at_ (u"ࠨछࠪଛ")).replace(l111lll111l1_at_ (u"ࠩ࡟ࡹ࠵࠷࠱࠹ࠩଜ"),l111lll111l1_at_ (u"ࠪजࠬଝ"))
    l111ll111ll111l1_at_ = l111ll111ll111l1_at_.replace(l111lll111l1_at_ (u"ࠫࡡࡻ࠰࠲࠶࠵ࠫଞ"),l111lll111l1_at_ (u"ࠬैࠧଟ")).replace(l111lll111l1_at_ (u"࠭࡜ࡶ࠲࠴࠸࠶࠭ଠ"),l111lll111l1_at_ (u"ࠧूࠩଡ"))
    l111ll111ll111l1_at_ = l111ll111ll111l1_at_.replace(l111lll111l1_at_ (u"ࠨ࡞ࡸ࠴࠶࠺࠴ࠨଢ"),l111lll111l1_at_ (u"ࠩेࠫଣ")).replace(l111lll111l1_at_ (u"ࠪࡠࡺ࠶࠱࠵࠶ࠪତ"),l111lll111l1_at_ (u"ࠫै࠭ଥ"))
    l111ll111ll111l1_at_ = l111ll111ll111l1_at_.replace(l111lll111l1_at_ (u"ࠬࡢࡵ࠱࠲ࡩ࠷ࠬଦ"),l111lll111l1_at_ (u"࠭ࣳࠨଧ")).replace(l111lll111l1_at_ (u"ࠧ࡝ࡷ࠳࠴ࡩ࠹ࠧନ"),l111lll111l1_at_ (u"ࠨࣕࠪ଩"))
    l111ll111ll111l1_at_ = l111ll111ll111l1_at_.replace(l111lll111l1_at_ (u"ࠩ࡟ࡹ࠵࠷࠵ࡣࠩପ"),l111lll111l1_at_ (u"ࠪय़ࠬଫ")).replace(l111lll111l1_at_ (u"ࠫࡡࡻ࠰࠲࠷ࡤࠫବ"),l111lll111l1_at_ (u"ࠬॠࠧଭ"))
    l111ll111ll111l1_at_ = l111ll111ll111l1_at_.replace(l111lll111l1_at_ (u"࠭࡜ࡶ࠲࠴࠻ࡦ࠭ମ"),l111lll111l1_at_ (u"ࠧॻࠩଯ")).replace(l111lll111l1_at_ (u"ࠨ࡞ࡸ࠴࠶࠽࠹ࠨର"),l111lll111l1_at_ (u"ࠩॼࠫ଱"))
    l111ll111ll111l1_at_ = l111ll111ll111l1_at_.replace(l111lll111l1_at_ (u"ࠪࡠࡺ࠶࠱࠸ࡥࠪଲ"),l111lll111l1_at_ (u"ࠫঁ࠭ଳ")).replace(l111lll111l1_at_ (u"ࠬࡢࡵ࠱࠳࠺ࡦࠬ଴"),l111lll111l1_at_ (u"࠭ॻࠨଵ"))
    return l111ll111ll111l1_at_
