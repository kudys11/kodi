# coding: UTF-8
import sys
l1l1ll111l1_at_ = sys.version_info [0] == 2
l11l1ll111l1_at_ = 2048
l1ll11ll111l1_at_ = 7
def l111lll111l1_at_ (llll111l1_at_):
	global l111ll111l1_at_
	l1l1llll111l1_at_ = ord (llll111l1_at_ [-1])
	l1l1lll111l1_at_ = llll111l1_at_ [:-1]
	l1lll111l1_at_ = l1l1llll111l1_at_ % len (l1l1lll111l1_at_)
	l11ll111l1_at_ = l1l1lll111l1_at_ [:l1lll111l1_at_] + l1l1lll111l1_at_ [l1lll111l1_at_:]
	if l1l1ll111l1_at_:
		l1111ll111l1_at_ = unicode () .join ([unichr (ord (char) - l11l1ll111l1_at_ - (l1ll1ll111l1_at_ + l1l1llll111l1_at_) % l1ll11ll111l1_at_) for l1ll1ll111l1_at_, char in enumerate (l11ll111l1_at_)])
	else:
		l1111ll111l1_at_ = str () .join ([chr (ord (char) - l11l1ll111l1_at_ - (l1ll1ll111l1_at_ + l1l1llll111l1_at_) % l1ll11ll111l1_at_) for l1ll1ll111l1_at_, char in enumerate (l11ll111l1_at_)])
	return eval (l1111ll111l1_at_)
import urlparse,cookielib,urllib2,urllib
import time,re,os
url=l111lll111l1_at_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧ࡬࡭ࡶࡸࡦࡪ࠴ࡴࡷࠩ୞")
l11l111llll111l1_at_= cookielib.LWPCookieJar()
l1llll1l1lll111l1_at_=l111lll111l1_at_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠰࠯࠲࠱࠶࠻࠼࠱࠯࠳࠳࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬୟ")
def l111ll11lll111l1_at_(url,l11l111llll111l1_at_=l11l111llll111l1_at_,l1lll11111ll111l1_at_=l1llll1l1lll111l1_at_):
    l1lll111llll111l1_at_=l111lll111l1_at_ (u"ࠧࠨୠ")
    try:
        class l1ll1lll1lll111l1_at_(urllib2.HTTPErrorProcessor):
            def http_response(self, request, response):
                return response
        def l1ll1ll1l1ll111l1_at_(s):
            try:
                offset=1 if s[0]==l111lll111l1_at_ (u"ࠨ࠭ࠪୡ") else 0
                val = int(eval(s.replace(l111lll111l1_at_ (u"ࠩࠤ࠯ࡠࡣࠧୢ"),l111lll111l1_at_ (u"ࠪ࠵ࠬୣ")).replace(l111lll111l1_at_ (u"࡛ࠫࠦࠧ࡞ࠩ୤"),l111lll111l1_at_ (u"ࠬ࠷ࠧ୥")).replace(l111lll111l1_at_ (u"࡛࠭࡞ࠩ୦"),l111lll111l1_at_ (u"ࠧ࠱ࠩ୧")).replace(l111lll111l1_at_ (u"ࠨࠪࠪ୨"),l111lll111l1_at_ (u"ࠩࡶࡸࡷ࠮ࠧ୩"))[offset:]))
                return val
            except:
                pass
        if l11l111llll111l1_at_==None:
            l11l111llll111l1_at_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(l1ll1lll1lll111l1_at_, urllib2.HTTPCookieProcessor(l11l111llll111l1_at_))
        opener.l1lll1111lll111l1_at_ = [(l111lll111l1_at_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ୪"), l1lll11111ll111l1_at_)]
        try:
            response = opener.open(url)
            result=l1lll111llll111l1_at_ = response.read()
            response.close()
        except urllib2.HTTPError as e:
            result=l1lll111llll111l1_at_ = e.read()
        l1lll11l11ll111l1_at_ = re.compile(l111lll111l1_at_ (u"ࠫࡳࡧ࡭ࡦ࠿ࠥ࡮ࡸࡩࡨ࡭ࡡࡹࡧࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯࠭ࡂ࠭ࠧ࠵࠾ࠨ୫")).findall(result)[0]
        init = re.compile(l111lll111l1_at_ (u"ࠬࡹࡥࡵࡖ࡬ࡱࡪࡵࡵࡵ࡞ࠫࡪࡺࡴࡣࡵ࡫ࡲࡲࡡ࠮࡜ࠪࡽ࡟ࡷ࠯࠴ࠪࡀ࠰࠭࠾࠭࠴ࠪࡀࠫࢀ࠿ࠬ୬")).findall(result)[0]
        l1lll11l1lll111l1_at_ = re.compile(l111lll111l1_at_ (u"ࡸࠢࡤࡪࡤࡰࡱ࡫࡮ࡨࡧ࠰ࡪࡴࡸ࡭࡝ࠩ࡟࠭ࡀࡢࡳࠫࠪ࠱࠮࠮ࡧ࠮ࡷࠤ୭")).findall(result)[0]
        l1lll111l1ll111l1_at_ = l1ll1ll1l1ll111l1_at_(init)
        lines = l1lll11l1lll111l1_at_.split(l111lll111l1_at_ (u"ࠧ࠼ࠩ୮"))
        if l1lll11l11ll111l1_at_:
            for line in lines:
                if len(line)>0 and l111lll111l1_at_ (u"ࠨ࠿ࠪ୯") in line:
                    l1ll1ll11lll111l1_at_=line.split(l111lll111l1_at_ (u"ࠩࡀࠫ୰"))
                    l1ll1ll111ll111l1_at_ = l1ll1ll1l1ll111l1_at_(l1ll1ll11lll111l1_at_[1])
                    l1lll111l1ll111l1_at_ = int(eval(str(l1lll111l1ll111l1_at_)+l1ll1ll11lll111l1_at_[0][-1]+str(l1ll1ll111ll111l1_at_)))
            l1ll1lll11ll111l1_at_ = l1lll111l1ll111l1_at_ + len(urlparse.urlparse(url).netloc)
            u=url
            query = l111lll111l1_at_ (u"ࠪࠩࡸ࠵ࡣࡥࡰ࠰ࡧ࡬࡯࠯࡭࠱ࡦ࡬ࡰࡥࡪࡴࡥ࡫ࡰࡄࡰࡳࡤࡪ࡯ࡣࡻࡩ࠽ࠦࡵࠩ࡮ࡸࡩࡨ࡭ࡡࡤࡲࡸࡽࡥࡳ࠿ࠨࡷࠬୱ") % (u, l1lll11l11ll111l1_at_, l1ll1lll11ll111l1_at_)
            if l111lll111l1_at_ (u"ࠫࡹࡿࡰࡦ࠿ࠥ࡬࡮ࡪࡤࡦࡰࠥࠤࡳࡧ࡭ࡦ࠿ࠥࡴࡦࡹࡳࠣࠩ୲") in result:
                l1ll1lllllll111l1_at_=re.compile(l111lll111l1_at_ (u"ࠬࡴࡡ࡮ࡧࡀࠦࡵࡧࡳࡴࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ୳")).findall(result)[0]
                query = l111lll111l1_at_ (u"࠭ࠥࡴ࠱ࡦࡨࡳ࠳ࡣࡨ࡫࠲ࡰ࠴ࡩࡨ࡬ࡡ࡭ࡷࡨ࡮࡬ࡀࡲࡤࡷࡸࡃࠥࡴࠨ࡭ࡷࡨ࡮࡬ࡠࡸࡦࡁࠪࡹࠦ࡫ࡵࡦ࡬ࡱࡥࡡ࡯ࡵࡺࡩࡷࡃࠥࡴࠩ୴") % (u,urllib.quote_plus(l1ll1lllllll111l1_at_), l1lll11l11ll111l1_at_, l1ll1lll11ll111l1_at_)
                time.sleep(5)
            l1ll1ll1llll111l1_at_ =l111lll111l1_at_ (u"ࠧࠨ୵").join([l111lll111l1_at_ (u"ࠨࠧࡶࡁࠪࡹ࠻ࠨ୶")%(c.name, c.value) for c in l11l111llll111l1_at_])
            opener = urllib2.build_opener(l1ll1lll1lll111l1_at_,urllib2.HTTPCookieProcessor(l11l111llll111l1_at_))
            opener.l1lll1111lll111l1_at_ = [(l111lll111l1_at_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭୷"), l1lll11111ll111l1_at_)]
            opener.l1lll1111lll111l1_at_.append((l111lll111l1_at_ (u"ࠪࡧࡴࡵ࡫ࡪࡧࠪ୸"),l1ll1ll1llll111l1_at_))
            try:
                response = opener.open(query)
                response.close()
            except urllib2.HTTPError as e:
                response = e.read()
            l1ll1ll1llll111l1_at_ =l111lll111l1_at_ (u"ࠫࠬ୹").join([l111lll111l1_at_ (u"ࠬࠫࡳ࠾ࠧࡶ࠿ࠬ୺")%(c.name, c.value) for c in l11l111llll111l1_at_])
            opener = urllib2.build_opener(l1ll1lll1lll111l1_at_,urllib2.HTTPCookieProcessor(l11l111llll111l1_at_))
            opener.l1lll1111lll111l1_at_ = [(l111lll111l1_at_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ୻"), l1lll11111ll111l1_at_)]
            opener.l1lll1111lll111l1_at_.append((l111lll111l1_at_ (u"ࠧࡤࡱࡲ࡯࡮࡫ࠧ୼"),l1ll1ll1llll111l1_at_))
            try:
                response = opener.open(url)
                response.headers[l111lll111l1_at_ (u"ࠨࡵࡨࡸ࠲ࡩ࡯ࡰ࡭࡬ࡩࠬ୽")]
                response.close()
            except:
                response = e.read()
                response.close()
        return l11l111llll111l1_at_
    except:
        return None
def l1llllllllll111l1_at_(l1l1ll11ll111l1_at_):
    l1ll1llll1ll111l1_at_=l111lll111l1_at_ (u"ࠩࠪ୾")
    if os.path.isfile(l1l1ll11ll111l1_at_):
        l11l111llll111l1_at_ = cookielib.LWPCookieJar()
        l11l111llll111l1_at_.load(l1l1ll11ll111l1_at_)
        l1ll1llll1ll111l1_at_=l111lll111l1_at_ (u"ࠪࠫ୿").join([l111lll111l1_at_ (u"ࠫࠪࡹ࠽ࠦࡵ࠾ࠫ஀")%(c.name, c.value) for c in l11l111llll111l1_at_])
    return l1ll1llll1ll111l1_at_
