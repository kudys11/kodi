# -*- coding: utf-8 -*-
import sys
l1l1ll111l1_at_ = sys.version_info [0] == 2
l11l1ll111l1_at_ = 2048
l1ll11ll111l1_at_ = 7
def l111lll111l1_at_ (llll111l1_at_):
	global l111ll111l1_at_
	l1l1llll111l1_at_ = ord (llll111l1_at_ [-1])
	l1l1lll111l1_at_ = llll111l1_at_ [:-1]
	l1lll111l1_at_ = l1l1llll111l1_at_ % len (l1l1lll111l1_at_)
	l11ll111l1_at_ = l1l1lll111l1_at_ [:l1lll111l1_at_] + l1l1lll111l1_at_ [l1lll111l1_at_:]
	if l1l1ll111l1_at_:
		l1111ll111l1_at_ = unicode () .join ([unichr (ord (char) - l11l1ll111l1_at_ - (l1ll1ll111l1_at_ + l1l1llll111l1_at_) % l1ll11ll111l1_at_) for l1ll1ll111l1_at_, char in enumerate (l11ll111l1_at_)])
	else:
		l1111ll111l1_at_ = str () .join ([chr (ord (char) - l11l1ll111l1_at_ - (l1ll1ll111l1_at_ + l1l1llll111l1_at_) % l1ll11ll111l1_at_) for l1ll1ll111l1_at_, char in enumerate (l11ll111l1_at_)])
	return eval (l1111ll111l1_at_)
import urllib2,urllib
import re,random,json
import cookielib
l111ll1llll111l1_at_=10
l1llll1l1lll111l1_at_=l111lll111l1_at_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠷࠳࠲࠵࠴࠲࠷࠸࠴࠲࠶࠶࠲ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨ௙")
def l1111lll1ll111l1_at_(url,data=None,header={},l1l1l1l1llll111l1_at_=True):
    l1ll1ll1llll111l1_at_=l111lll111l1_at_ (u"ࠪࠫ௚")
    l11l111llll111l1_at_=[]
    if l1l1l1l1llll111l1_at_:
        l11l111llll111l1_at_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l11l111llll111l1_at_))
        urllib2.install_opener(opener)
    if not header:
        header = {l111lll111l1_at_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ௛"):l1llll1l1lll111l1_at_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l111ll1llll111l1_at_)
        l1l1ll1lll111l1_at_ =  response.read()
        response.close()
        l1ll1ll1llll111l1_at_ = l111lll111l1_at_ (u"ࠬ࠭௜").join([l111lll111l1_at_ (u"࠭ࠥࡴ࠿ࠨࡷࡀ࠭௝")%(c.name, c.value) for c in l11l111llll111l1_at_])
    except urllib2.HTTPError as e:
        l1l1ll1lll111l1_at_ = l111lll111l1_at_ (u"ࠧࠨ௞")
    return l1l1ll1lll111l1_at_,l1ll1ll1llll111l1_at_
def l1l1l1l1ll111l1_at_(url):
    url = url.replace(l111lll111l1_at_ (u"ࠨࡪࡷࡸࡵࡀࠧ௟"),l111lll111l1_at_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ௠")).replace(l111lll111l1_at_ (u"ࠪ࠳ࡪࡳࡢࡦࡦ࠲ࠫ௡"),l111lll111l1_at_ (u"ࠫ࠴ࡅࡶ࠾ࠩ௢"))
    content,c = l1111lll1ll111l1_at_(url)
    match = re.findall(l111lll111l1_at_ (u"ࠬ࠭ࠧ࡜ࠤࠪࡡࡄࡹ࡯ࡶࡴࡦࡩࡸࡡࠧࠣ࡟ࡂࡠࡸ࠰࠺࡝ࡵ࠭ࠬࡡࡡ࠮ࠫࡁ࡟ࡡ࠮࠭ࠧࠨ௣"), content)
    l1l1l1ll11ll111l1_at_=l111lll111l1_at_ (u"࠭ࠧ௤")
    if not match:
        data = {}
        data[l111lll111l1_at_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭࠯ࡻࠪ௥")] = random.randint(0, 120)
        data[l111lll111l1_at_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮࠰ࡻࠫ௦")] = random.randint(0, 120)
        header={l111lll111l1_at_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭௧"):l1llll1l1lll111l1_at_,l111lll111l1_at_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ௨"):url}
        l1l1l1lll1ll111l1_at_ = url + l111lll111l1_at_ (u"ࠫࠨ࠭௩")
        content,c = l1111lll1ll111l1_at_(l1l1l1lll1ll111l1_at_,urllib.urlencode(data),header=header)
        match = re.findall(l111lll111l1_at_ (u"ࠬ࠭ࠧ࡜ࠤࠪࡡࡄࡹ࡯ࡶࡴࡦࡩࡸࡡࠧࠣ࡟ࡂࡠࡸ࠰࠺࡝ࡵ࠭ࠬࡡࡡ࠮ࠫࡁ࡟ࡡ࠮࠭ࠧࠨ௪"), content)
    if match:
        try:
            data = json.loads(match[0])
            l1l1l1ll11ll111l1_at_=[]
            for d in data:
                if isinstance(d,dict):
                    l1l1l1ll1lll111l1_at_ = d.get(l111lll111l1_at_ (u"࠭ࡦࡪ࡮ࡨࠫ௫"),l111lll111l1_at_ (u"ࠧࠨ௬"))+l111lll111l1_at_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠥࡴࠨࡕࡩ࡫࡫ࡲࡦࡴࡀࠩࡸ࠭௭")%(l1llll1l1lll111l1_at_,url)
                    l1l1l1ll11ll111l1_at_.append((d.get(l111lll111l1_at_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨ௮"),l111lll111l1_at_ (u"ࠪࠫ௯")),l1l1l1ll1lll111l1_at_))
        except:
            l1l1l1ll11ll111l1_at_ = re.findall(l111lll111l1_at_ (u"࡛ࠫࠬ࠭ࠨࠤࡠࡃ࡫࡯࡬ࡦ࡝ࠪࠦࡢࡅ࡜ࡴࠬ࠽ࡠࡸ࠰࡛ࠨࠤࡠࡃ࠭ࡡ࡞ࠨࠤࡠ࠯࠮࠭ࠧࠨ௰"), match[0])
            if l1l1l1ll11ll111l1_at_:
                l1l1l1ll11ll111l1_at_ = l1l1l1ll11ll111l1_at_[0].replace(l111lll111l1_at_ (u"ࠬࡢ࠯ࠨ௱"), l111lll111l1_at_ (u"࠭࠯ࠨ௲"))
                l1l1l1ll11ll111l1_at_ += l111lll111l1_at_ (u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠫࡳࠧࡔࡨࡪࡪࡸࡥࡳ࠿ࠨࡷࠬ௳")%(l1llll1l1lll111l1_at_,url)
    return l1l1l1ll11ll111l1_at_
