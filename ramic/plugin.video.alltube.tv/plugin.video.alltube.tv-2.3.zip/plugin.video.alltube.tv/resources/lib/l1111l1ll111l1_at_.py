# -*- coding: utf-8 -*-
import sys
l1l1ll111l1_at_ = sys.version_info [0] == 2
l11l1ll111l1_at_ = 2048
l1ll11ll111l1_at_ = 7
def l111lll111l1_at_ (llll111l1_at_):
	global l111ll111l1_at_
	l1l1llll111l1_at_ = ord (llll111l1_at_ [-1])
	l1l1lll111l1_at_ = llll111l1_at_ [:-1]
	l1lll111l1_at_ = l1l1llll111l1_at_ % len (l1l1lll111l1_at_)
	l11ll111l1_at_ = l1l1lll111l1_at_ [:l1lll111l1_at_] + l1l1lll111l1_at_ [l1lll111l1_at_:]
	if l1l1ll111l1_at_:
		l1111ll111l1_at_ = unicode () .join ([unichr (ord (char) - l11l1ll111l1_at_ - (l1ll1ll111l1_at_ + l1l1llll111l1_at_) % l1ll11ll111l1_at_) for l1ll1ll111l1_at_, char in enumerate (l11ll111l1_at_)])
	else:
		l1111ll111l1_at_ = str () .join ([chr (ord (char) - l11l1ll111l1_at_ - (l1ll1ll111l1_at_ + l1l1llll111l1_at_) % l1ll11ll111l1_at_) for l1ll1ll111l1_at_, char in enumerate (l11ll111l1_at_)])
	return eval (l1111ll111l1_at_)
l111lll111l1_at_ (u"ࠢࠣࠤࠐࠎࡈࡸࡥࡢࡶࡨࡨࠥࡵ࡮ࠡࡖ࡫ࡹࠥࡌࡥࡣࠢ࠴࠵ࠥ࠷࠸࠻࠶࠺࠾࠹࠹ࠠ࠳࠲࠴࠺ࠒࠐࠍࠋࡂࡤࡹࡹ࡮࡯ࡳ࠼ࠣࡶࡦࡳࡩࡤࠏࠍࠦࠧࠨଶ")
import urllib2
import re
import l1llll111lll111l1_at_ as l1llll111lll111l1_at_
l1lllll1llll111l1_at_=l111lll111l1_at_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡩࡤࡢ࠰ࡳࡰࠬଷ")
l111ll1llll111l1_at_ = 5
def l1111lll1ll111l1_at_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l111lll111l1_at_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ସ"), l111lll111l1_at_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡏࡘ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠷࠼࠳࠶࠮࠳࠷࠹࠸࠳࠿࠷ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨହ"))
    if cookies:
        req.add_header(l111lll111l1_at_ (u"ࠦࡈࡵ࡯࡬࡫ࡨࠦ଺"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l111ll1llll111l1_at_)
        l1l1ll1lll111l1_at_ =  response.read()
        response.close()
    except:
        l1l1ll1lll111l1_at_=l111lll111l1_at_ (u"ࠬ࠭଻")
    return l1l1ll1lll111l1_at_
def _1llll11llll111l1_at_(content):
    src =l111lll111l1_at_ (u"଼࠭ࠧ")
    l1lll1l1l1ll111l1_at_ = re.compile(l111lll111l1_at_ (u"ࠢࡦࡸࡤࡰ࠭࠴ࠪࡀࠫ࡟ࡿࡡࢃ࡜ࠪ࡞ࠬࠦଽ"),re.DOTALL).findall(content)
    for l1lll1l11lll111l1_at_ in l1lll1l1l1ll111l1_at_:
        l1lll1l11lll111l1_at_=re.sub(l111lll111l1_at_ (u"ࠨࠢࠣࠫା"),l111lll111l1_at_ (u"ࠩࠣࠫି"),l1lll1l11lll111l1_at_)
        l1lll1l11lll111l1_at_=re.sub(l111lll111l1_at_ (u"ࠪࡠࡳ࠭ୀ"),l111lll111l1_at_ (u"ࠫࠬୁ"),l1lll1l11lll111l1_at_)
        try:
            l1lll1llllll111l1_at_ = l1llll111lll111l1_at_.unpack(l1lll1l11lll111l1_at_)
        except:
            l1lll1llllll111l1_at_=l111lll111l1_at_ (u"ࠬ࠭ୂ")
        if l1lll1llllll111l1_at_:
            l1lll1llllll111l1_at_=re.sub(l111lll111l1_at_ (u"ࡸࠧ࡝࡞ࠪୃ"),l111lll111l1_at_ (u"ࡲࠨࠩୄ"),l1lll1llllll111l1_at_)
            l1lll1l1llll111l1_at_ = re.compile(l111lll111l1_at_ (u"ࠨ࡝ࠥࡠࠬࡣࠪࡧ࡫࡯ࡩࡠࠨ࡜ࠨ࡟࠭ࡠࡸ࠰࠺࡝ࡵ࠭࡟ࠧࡢࠧ࡞ࠪ࠱࠯ࡄ࠯࡛ࠣ࡞ࠪࡡ࠱࠭୅"),  re.DOTALL).search(content)
            l1lll1lll1ll111l1_at_ = re.compile(l111lll111l1_at_ (u"ࠩ࡞ࠦࡡ࠭࡝ࡧ࡫࡯ࡩࡠࠨ࡜ࠨ࡟࠽࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄࡢ࠮࡮ࡲ࠷࠭ࡠࠨ࡜ࠨ࡟ࠪ୆"),  re.DOTALL).search(content)
            l1lll1ll1lll111l1_at_ = re.compile(l111lll111l1_at_ (u"ࠪ࡟ࠧࡢࠧ࡞ࠬࠫ࠲࠯ࡅ࡜࠯࡯ࡳ࠸࠮ࡡࠢ࡝ࠩࡠ࠮ࠬେ"),  re.DOTALL).search(content)
            if l1lll1l1llll111l1_at_:   src = l1lll1l1llll111l1_at_.group(1)
            elif l1lll1lll1ll111l1_at_: src = l1lll1lll1ll111l1_at_.group(1)
            elif l1lll1ll1lll111l1_at_: src = l1lll1ll1lll111l1_at_.group(1)
            if src:
                break
    return src
def l1llll11l1ll111l1_at_(content):
    l111lll111l1_at_ (u"ࠦࠧࠨࠍࠋࠢࠣࠤ࡙ࠥࡣࡢࡰࡶࠤ࡫ࡵࡲࠡࡸ࡬ࡨࡪࡵࠠ࡭࡫ࡱ࡯ࠥ࡯࡮ࡤ࡮ࡸࡨࡪࡪࠠࡦࡰࡦࡳࡩ࡫ࡤࠡࡱࡱࡩࠒࠐࠠࠡࠢࠣࠦࠧࠨୈ")
    l1lll1l111ll111l1_at_=l111lll111l1_at_ (u"ࠬ࠭୉")
    l1lll1l1llll111l1_at_ = re.compile(l111lll111l1_at_ (u"࡛࠭ࠣ࡞ࠪࡡ࠯࡬ࡩ࡭ࡧ࡞ࠦࡡ࠭࡝ࠫ࡞ࡶ࠮࠿ࡢࡳࠫ࡝ࠥࡠࠬࡣࠨ࠯࠭ࡂ࠭ࡠࠨ࡜ࠨ࡟࠯ࠫ୊"),  re.DOTALL).search(content)
    l1lll1lll1ll111l1_at_ = re.compile(l111lll111l1_at_ (u"ࠧ࡜ࠤ࡟ࠫࡢ࡬ࡩ࡭ࡧ࡞ࠦࡡ࠭࡝࠻࡝ࠥࡠࠬࡣࠨ࠯ࠬࡂࡠ࠳ࡳࡰ࠵ࠫ࡞ࠦࡡ࠭࡝ࠨୋ"),  re.DOTALL).search(content)
    l1lll1ll1lll111l1_at_ = re.compile(l111lll111l1_at_ (u"ࠨ࡝ࠥࡠࠬࡣࠪࠩ࠰࠭ࡃࡡ࠴࡭ࡱ࠶ࠬ࡟ࠧࡢࠧ࡞ࠬࠪୌ"),  re.DOTALL).search(content)
    if l1lll1l1llll111l1_at_:
        print l111lll111l1_at_ (u"ࠩࡩࡳࡺࡴࡤࠡࡔࡈࠤࡠ࡬ࡩ࡭ࡧ࠽ࡡ୍ࠬ")
        l1lll1l111ll111l1_at_ = l1lll1l1llll111l1_at_.group(1)
    elif l1lll1lll1ll111l1_at_:
        print l111lll111l1_at_ (u"ࠪࡪࡴࡻ࡮ࡥࠢࡕࡉࠥࡡࡵࡳ࡮࠽ࡡࠬ୎")
        l1lll1l111ll111l1_at_ = l1lll1lll1ll111l1_at_.group(1)
    elif l1lll1ll1lll111l1_at_:
        print l111lll111l1_at_ (u"ࠫ࡫ࡵࡵ࡯ࡦࠣࡖࡊ࡛ࠦࡶࡴ࡯࠾ࡢ࠭୏")
        l1lll1l111ll111l1_at_ = l1lll1ll1lll111l1_at_.group(1)
    else:
        print l111lll111l1_at_ (u"ࠬ࡫࡮ࡤࡱࡧࡩࡩࠦ࠺ࠡࡷࡱࡴࡦࡩ࡫ࡦࡴࠪ୐")
        l1lll1l111ll111l1_at_ = _1llll11llll111l1_at_(content)
    l1lll1l111ll111l1_at_ = l1lll1l111ll111l1_at_.replace(l111lll111l1_at_ (u"ࠨ࡜࡝ࠤ୑"), l111lll111l1_at_ (u"ࠢࠣ୒"))
    if l1lll1l111ll111l1_at_.startswith(l111lll111l1_at_ (u"ࠨࡷࡪ࡫ࡨ࠭୓")):
        l1lll11lll111l1_at_ = lambda x: 0 if not x.isalpha() else -13 if l111lll111l1_at_ (u"ࠩࡄࠫ୔") <=x.upper()<=l111lll111l1_at_ (u"ࠪࡑࠬ୕") else 13
        l1lll1l111ll111l1_at_ = l111lll111l1_at_ (u"ࠫࠬୖ").join([chr((ord(x)-l1lll11lll111l1_at_(x)) ) for x in l1lll1l111ll111l1_at_])
        l1lll1l111ll111l1_at_=l1lll1l111ll111l1_at_[:-7] + l1lll1l111ll111l1_at_[-4:]
    return l1lll1l111ll111l1_at_
def l1l1l1l1ll111l1_at_(url):
    l111lll111l1_at_ (u"ࠧࠨࠢࠎࠌࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࡹࠠࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠱ࠥࡻ࡬ࡳࠢ࡫ࡸࡹࡶ࠺࠰࠱࠱࠲࠳࠴ࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠰ࠤࡴࡸࠠ࡭࡫ࡶࡸࠥࡵࡦࠡ࡝ࠫࠫ࠼࠸࠰ࡱࠩ࠯ࠤࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡦࡨࡦ࠴ࡰ࡭࠱ࡹ࡭ࡩ࡫࡯࠰࠳࠼࠸࠻࠿࠹࠲ࡨࡂࡻࡪࡸࡳ࡫ࡣࡀ࠻࠷࠶ࡰࠨࠫ࠯࠲࠳࠴࡝ࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠒࠐࠠࠡࠢࠣࠦࠧࠨୗ")
    l1lll1ll11ll111l1_at_=l111lll111l1_at_ (u"࠭ࡼࡄࡱࡲ࡯࡮࡫࠽ࡑࡊࡓࡗࡊ࡙ࡓࡊࡆࡀ࠵ࠫࡘࡥࡧࡧࡵࡩࡷࡃࡨࡵࡶࡳ࠾࠴࠵ࡳࡵࡣࡷ࡭ࡨ࠴ࡣࡥࡣ࠱ࡴࡱ࠵ࡦ࡭ࡱࡺࡴࡱࡧࡹࡦࡴ࠲ࡪࡱࡧࡳࡩ࠱ࡩࡰࡴࡽࡰ࡭ࡣࡼࡩࡷ࠴ࡣࡰ࡯ࡰࡩࡷࡩࡩࡢ࡮࠰࠷࠳࠸࠮࠲࠺࠱ࡷࡼ࡬ࠧ୘")
    content = l1111lll1ll111l1_at_(url)
    src=[]
    if not l111lll111l1_at_ (u"ࠧࡀࡹࡨࡶࡸࡰࡡࠨ୙") in url:
         l1lll11lllll111l1_at_ = re.compile(l111lll111l1_at_ (u"ࠨ࠾ࡤࠤࡩࡧࡴࡢ࠯ࡴࡹࡦࡲࡩࡵࡻࡀࠦ࠭࠴ࠪࡀࠫࠥࠤ࠭ࡅࡐ࠽ࡊࡁ࠲࠯ࡅࠩ࠿ࠪࡂࡔࡁࡗ࠾࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ୚"), re.DOTALL).findall(content)
         for quality in l1lll11lllll111l1_at_:
             l1l1ll1lll111l1_at_ = re.search(l111lll111l1_at_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ୛"),quality[1])
             l1lll11ll1ll111l1_at_ = quality[2]
             src.insert(0,(l1lll11ll1ll111l1_at_,l1lllll1llll111l1_at_+l1l1ll1lll111l1_at_.group(1)))
    if not src:
        src = l1llll11l1ll111l1_at_(content)
        if src:
            src+=l1lll1ll11ll111l1_at_
    return src
def l1llll1111ll111l1_at_(url,quality=0):
    l111lll111l1_at_ (u"ࠥࠦࠧࠓࠊࠡࠢࠣࠤࡷ࡫ࡴࡶࡴࡱࡷࠥࡻࡲ࡭ࠢࡷࡳࠥࡼࡩࡥࡧࡲࠑࠏࠦࠠࠡࠢࠥࠦࠧଡ଼")
    src = l1l1l1l1ll111l1_at_(url)
    if type(src)==list:
        selected=src[quality]
        print l111lll111l1_at_ (u"ࠫࡖࡻࡡ࡭࡫ࡷࡽࠥࡀࠧଢ଼"),selected[0]
        src = l1l1l1l1ll111l1_at_(selected[1])
    return src
