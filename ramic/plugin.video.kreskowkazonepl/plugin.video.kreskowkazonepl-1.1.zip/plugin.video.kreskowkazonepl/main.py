# -*- coding: utf-8 -*-
import sys
l1l1ll11l1_kz_ = sys.version_info [0] == 2
l1l1l1l11l1_kz_ = 2048
l11lll11l1_kz_ = 7
def l1ll11l1_kz_ (keyedStringLiteral):
	global l111l1l11l1_kz_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l1ll11l1_kz_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l1l1l11l1_kz_ - (charIndex + stringNr) % l11lll11l1_kz_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l1l1l11l1_kz_ - (charIndex + stringNr) % l11lll11l1_kz_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urlparse,sys,urllib
params = dict(urlparse.parse_qsl(sys.argv[2].replace(l1ll11l1_kz_ (u"ࠫࡄ࠭ࠀ"),l1ll11l1_kz_ (u"ࠬ࠭ࠁ"))))
mode = params.get(l1ll11l1_kz_ (u"࠭࡭ࡰࡦࡨࠫࠂ"))
fname = params.get(l1ll11l1_kz_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫࠃ"))
ex_link = params.get(l1ll11l1_kz_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩࠄ"))
l11111l11l1_kz_ = params.get(l1ll11l1_kz_ (u"ࠩࡳࡥ࡬࡫ࠧࠅ"))
import xbmcgui,xbmc
import time,os
l1lll1l11l1_kz_ = xbmcgui.Dialog()
import time,threading
try: from shutil import rmtree
except: rmtree = False
def lll11l1_kz_(l1llllll11l1_kz_,l1l1l11l1_kz_=[l1ll11l1_kz_ (u"ࠪࠫࠆ")]):
    debug=1
def l1111l11l1_kz_(name=l1ll11l1_kz_ (u"ࠫࠬࠇ")):
    debug=1
def l111l11l1_kz_(top):
    debug=1
def l1llll11l1_kz_():
    l1llllll11l1_kz_ = os.path.join(xbmc.translatePath(l1ll11l1_kz_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭ࠏ")),l1ll11l1_kz_ (u"࠭ࡡࡥࡦࡲࡲࡸ࠭ࠐ"))
    xbmc.log(l1llllll11l1_kz_)
    if lll11l1_kz_(l1llllll11l1_kz_,[l1ll11l1_kz_ (u"ࠧࡢ࡮࡬ࡩࡳࡽࡩࡻࡣࡵࡨࠬࠑ"),l1ll11l1_kz_ (u"ࠨࡧࡻࡸࡪࡴࡤࡦࡴ࠱ࡥࡱ࡯ࡥ࡯ࠩࠒ")])>0:
        l1111l11l1_kz_(l1ll11l1_kz_ (u"ࠩࡺ࡭ࡿࡧࡲࡥࠩࠓ"))
        return
    l11l1ll11l1_kz_ = os.path.join(xbmc.translatePath(l1ll11l1_kz_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡵࡴࡧࡵࡨࡦࡺࡡࠨࠔ")),l1ll11l1_kz_ (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨࠕ"),l1ll11l1_kz_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡥࡪࡵ࡮࠯ࡰࡲࡼ࠳࠻ࠧࠖ"),l1ll11l1_kz_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬࠗ"))
    if os.path.exists(l11l1ll11l1_kz_):
        data = open(l11l1ll11l1_kz_,l1ll11l1_kz_ (u"ࠧࡳࠩ࠘")).read()
        data= re.sub(l1ll11l1_kz_ (u"ࠨ࡞࡞࠲࠯ࡢ࡝ࠨ࠙"),l1ll11l1_kz_ (u"ࠩࠪࠚ"),data)
        if len(re.compile(l1ll11l1_kz_ (u"ࠪࡂ࠳࠰ࠨࡱࡱ࡯ࡷࡰࡧ࡜ࡴࠬࡷࡠࡸ࠰ࡶࠪࠩࠛ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1111l11l1_kz_(l1ll11l1_kz_ (u"ࠫࡸࡱࡩ࡯࠰ࡤࡩࡴࡴ࠮࡯ࡱࡻ࠲࠺࠭ࠜ"))
            return
        if len(re.compile(l1ll11l1_kz_ (u"ࠬࡄ࠮ࠫࠪࡧࡥࡷࡳ࡯ࡸࡣ࡟ࡷ࠯ࡺ࡜ࡴࠬࡹ࠭ࠬࠝ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1111l11l1_kz_(l1ll11l1_kz_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡦ࡫࡯࡯࠰ࡱࡳࡽ࠴࠵ࠨࠞ"))
            return
    l11l1ll11l1_kz_ = os.path.join(xbmc.translatePath(l1ll11l1_kz_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡹࡸ࡫ࡲࡥࡣࡷࡥࠬࠟ")),l1ll11l1_kz_ (u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬࠠ"),l1ll11l1_kz_ (u"ࠩࡶ࡯࡮ࡴ࠮ࡹࡱࡱࡪࡱࡻࡥ࡯ࡥࡨࠫࠡ"),l1ll11l1_kz_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩࠢ"))
    if os.path.exists(l11l1ll11l1_kz_):
        data = open(l11l1ll11l1_kz_,l1ll11l1_kz_ (u"ࠫࡷ࠭ࠣ")).read()
        data= re.sub(l1ll11l1_kz_ (u"ࠬࡢ࡛࠯ࠬ࡟ࡡࠬࠤ"),l1ll11l1_kz_ (u"࠭ࠧࠥ"),data)
        if len(re.compile(l1ll11l1_kz_ (u"ࠧ࠿࠰࠭ࠬࡵࡵ࡬ࡴ࡭ࡤࡠࡸ࠰ࡴ࡝ࡵ࠭ࡺ࠮࠭ࠦ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1111l11l1_kz_(l1ll11l1_kz_ (u"ࠨࡵ࡮࡭ࡳ࠴ࡸࡰࡰࡩࡰࡺ࡫࡮ࡤࡧࠪࠧ"))
            return
    l1llllll11l1_kz_ = os.path.join(xbmc.translatePath(l1ll11l1_kz_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡻࡳࡦࡴࡧࡥࡹࡧࠧࠨ")),l1ll11l1_kz_ (u"ࠪࡴࡷࡵࡦࡪ࡮ࡨࡷࠬࠩ"))
    if os.path.exists(l1llllll11l1_kz_):
        if lll11l1_kz_(l1llllll11l1_kz_,[l1ll11l1_kz_ (u"ࠫࡰ࡯ࡤࡴࠩࠪ")])>0:
            l1111l11l1_kz_(l1ll11l1_kz_ (u"ࠬࡽࡩࡻࡣࡵࡨࠬࠫ"))
            return
    l11l11l1_kz_ = xbmc.translatePath(l1ll11l1_kz_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧࠬ"))
    for f in os.listdir(l11l11l1_kz_):
        if f.startswith(l1ll11l1_kz_ (u"ࠧࡎࡏࡈࡗࠬ࠭")):
            l1111l11l1_kz_()
            return
def l1l11l11l1_kz_():
    try:
        debug=1
    except: pass

if mode is None:
    from resources.lib import l1lll11l1_kz_
    l1lll11l1_kz_.l1lll11l1_kz_().root()
elif mode.startswith(l1ll11l1_kz_ (u"ࠩࡢ࡭ࡳ࡬࡯ࡠࠩ࠯"))  :
    from resources.lib import l1lll11l1_kz_
    l1lll11l1_kz_.l1lll11l1_kz_().info()
elif mode == l1ll11l1_kz_ (u"ࠪ࡯ࡦࡺࡥࡨࡱࡵ࡭ࡪ࠭࠰"):
    from resources.lib import l1lll11l1_kz_
    l1lll11l1_kz_.l1lll11l1_kz_().l1111ll11l1_kz_()
elif mode == l1ll11l1_kz_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭࠱"):
    from resources.lib import l1lll11l1_kz_
    l1lll11l1_kz_.l1lll11l1_kz_().l1l11l1_kz_(ex_link)
elif mode.startswith(l1ll11l1_kz_ (u"ࠬࡹࡥࡵࡈ࡬ࡰࡹࡸࠧ࠲")):
    from resources.lib import l1lll11l1_kz_
    l1lll11l1_kz_.l1lll11l1_kz_().l11llll11l1_kz_(mode)
elif mode.startswith(l1ll11l1_kz_ (u"࠭࡬ࡪࡵࡷࡥࠬ࠳")):
    from resources.lib import l1lll11l1_kz_
    l1lll11l1_kz_.l1lll11l1_kz_().l1l111l11l1_kz_(mode,ex_link)
elif mode == l1ll11l1_kz_ (u"ࠧࡱࡱࡳࡹࡱࡧࡲ࡯ࡧࠪ࠴"):
    from resources.lib import l1lll11l1_kz_
    l1lll11l1_kz_.l1lll11l1_kz_().l1l11ll11l1_kz_(ex_link)
elif mode == l1ll11l1_kz_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩ࠵"):
    from resources.lib import l1lll11l1_kz_
    l1lll11l1_kz_.l1lll11l1_kz_().content(ex_link)
elif mode.startswith(l1ll11l1_kz_ (u"ࠩࡢࡣࡵࡧࡧࡦࡡࡢ࠾ࠬ࠶")):
    from resources.lib import l1lll11l1_kz_
    l1lll11l1_kz_.l1lll11l1_kz_().l11ll11l1_kz_(mode,ex_link)
elif mode.startswith(l1ll11l1_kz_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ࠷")):
    from resources.lib import l1lll11l1_kz_
    l1lll11l1_kz_.l1lll11l1_kz_().l1lllll11l1_kz_(mode,ex_link)
elif mode == l1ll11l1_kz_ (u"ࠫ࡬࡫ࡴࡍ࡫ࡱ࡯ࡸ࠭࠸"):
    from resources.lib import l1lll11l1_kz_
    l1lll11l1_kz_.l1lll11l1_kz_().l1l1lll11l1_kz_(ex_link)
elif mode == l1ll11l1_kz_ (u"ࠬࡹࡥࡳ࡫ࡤࡰࡪࡥࡳࡦࡣࡶࡳࡳࡹࠧ࠹"):
    from resources.lib import l1lll11l1_kz_
    l1lll11l1_kz_.l1lll11l1_kz_().l1ll1ll11l1_kz_(ex_link)
elif mode == l1ll11l1_kz_ (u"࠭ࡳࡦࡴ࡬ࡥࡱ࡫࡟ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ࠺"):
    from resources.lib import l1lll11l1_kz_
    l1lll11l1_kz_.l1lll11l1_kz_().l111lll11l1_kz_(ex_link)
