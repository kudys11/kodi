# -*- coding: utf-8 -*-
import sys
l1l1ll11l1_kz_ = sys.version_info [0] == 2
l1l1l1l11l1_kz_ = 2048
l11lll11l1_kz_ = 7
def l1ll11l1_kz_ (keyedStringLiteral):
	global l111l1l11l1_kz_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l1ll11l1_kz_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l1l1l11l1_kz_ - (charIndex + stringNr) % l11lll11l1_kz_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l1l1l11l1_kz_ - (charIndex + stringNr) % l11lll11l1_kz_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os,json,base64
import cookielib
from urlparse import urlparse,urljoin
l1l1l11l11l1_kz_ = 15
l1l11l11l11l1_kz_=l1ll11l1_kz_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠶࠯࠳࠾ࠤ࡜࡯࡮࠷࠶࠾ࠤࡽ࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠶࠲࠰࠳࠲࠸࠷࠶࠴࠰࠴࠴࠵ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭੠")
l1ll1l1ll11l1_kz_=l1ll11l1_kz_ (u"ࡶࠬ࠭੡")
class l1ll11l11l11l1_kz_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
def l1111l1l11l1_kz_(url,data=None):
    l1ll1l1l11l1_kz_ = cookielib.LWPCookieJar()
    if data:
        opener = urllib2.build_opener(l1ll11l11l11l1_kz_, urllib2.HTTPCookieProcessor(l1ll1l1l11l1_kz_))
    else:
        opener = urllib2.build_opener( urllib2.HTTPCookieProcessor(l1ll1l1l11l1_kz_))
    opener.addheaders = [(l1ll11l1_kz_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ੢"), l1l11l11l11l1_kz_)]
    try:
        response = opener.open(url,data,l1l1l11l11l1_kz_)
        result= response.read()
        response.close()
    except:
        result=l1ll11l1ll11l1_kz_ = e.read()
    return result
def l11l1l1l11l1_kz_(l11lll1l11l1_kz_):
    if isinstance(l11lll1l11l1_kz_, unicode):
        l11lll1l11l1_kz_ = l11lll1l11l1_kz_.encode(l1ll11l1_kz_ (u"࠭ࡵࡵࡨ࠰࠼ࠬ੣"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠧࠧ࡮ࡷ࠿ࡧࡸ࠯ࠧࡩࡷ࠿ࠬ੤"),l1ll11l1_kz_ (u"ࠨࠢࠪ੥"))
    s=l1ll11l1_kz_ (u"ࠩࡍ࡭ࡓࡩ࡚ࡄࡵ࠺ࠫ੦")
    l11lll1l11l1_kz_ = re.sub(s.decode(l1ll11l1_kz_ (u"ࠪࡦࡦࡹࡥ࠷࠶ࠪ੧")),l1ll11l1_kz_ (u"ࠫࠬ੨"),l11lll1l11l1_kz_)
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠬࡢ࡮ࠨ੩"),l1ll11l1_kz_ (u"࠭ࠧ੪")).replace(l1ll11l1_kz_ (u"ࠧ࡝ࡴࠪ੫"),l1ll11l1_kz_ (u"ࠨࠩ੬"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠩࠩࡲࡧࡹࡰ࠼ࠩ੭"),l1ll11l1_kz_ (u"ࠪࠫ੮"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠫࠫࡷࡵࡰࡶ࠾ࠫ੯"),l1ll11l1_kz_ (u"ࠬࠨࠧੰ")).replace(l1ll11l1_kz_ (u"࠭ࠦࡢ࡯ࡳ࠿ࡶࡻ࡯ࡵ࠽ࠪੱ"),l1ll11l1_kz_ (u"ࠧࠣࠩੲ"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠨࠨࡲࡥࡨࡻࡴࡦ࠽ࠪੳ"),l1ll11l1_kz_ (u"ࣶࠩࠫੴ")).replace(l1ll11l1_kz_ (u"ࠪࠪࡔࡧࡣࡶࡶࡨ࠿ࠬੵ"),l1ll11l1_kz_ (u"ࠫࣘ࠭੶"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠬࠬࡡ࡮ࡲ࠾ࡳࡦࡩࡵࡵࡧ࠾ࠫ੷"),l1ll11l1_kz_ (u"࠭ࣳࠨ੸")).replace(l1ll11l1_kz_ (u"ࠧࠧࡣࡰࡴࡀࡕࡡࡤࡷࡷࡩࡀ࠭੹"),l1ll11l1_kz_ (u"ࠨࣕࠪ੺"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠩࠩࡥࡲࡶ࠻ࠨ੻"),l1ll11l1_kz_ (u"ࠪࠪࠬ੼"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠫࡡࡻ࠰࠲࠲࠸ࠫ੽"),l1ll11l1_kz_ (u"ࠬऋࠧ੾")).replace(l1ll11l1_kz_ (u"࠭࡜ࡶ࠲࠴࠴࠹࠭੿"),l1ll11l1_kz_ (u"ࠧअࠩ઀"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠨ࡞ࡸ࠴࠶࠶࠷ࠨઁ"),l1ll11l1_kz_ (u"ࠩऊࠫં")).replace(l1ll11l1_kz_ (u"ࠪࡠࡺ࠶࠱࠱࠸ࠪઃ"),l1ll11l1_kz_ (u"ࠫऋ࠭઄"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠬࡢࡵ࠱࠳࠴࠽ࠬઅ"),l1ll11l1_kz_ (u"࠭ङࠨઆ")).replace(l1ll11l1_kz_ (u"ࠧ࡝ࡷ࠳࠵࠶࠾ࠧઇ"),l1ll11l1_kz_ (u"ࠨचࠪઈ"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠩ࡟ࡹ࠵࠷࠴࠳ࠩઉ"),l1ll11l1_kz_ (u"ࠪॆࠬઊ")).replace(l1ll11l1_kz_ (u"ࠫࡡࡻ࠰࠲࠶࠴ࠫઋ"),l1ll11l1_kz_ (u"ࠬेࠧઌ"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"࠭࡜ࡶ࠲࠴࠸࠹࠭ઍ"),l1ll11l1_kz_ (u"ࠧॅࠩ઎")).replace(l1ll11l1_kz_ (u"ࠨ࡞ࡸ࠴࠶࠺࠴ࠨએ"),l1ll11l1_kz_ (u"ࠩॆࠫઐ"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠪࡠࡺ࠶࠰ࡧ࠵ࠪઑ"),l1ll11l1_kz_ (u"ࠫࣸ࠭઒")).replace(l1ll11l1_kz_ (u"ࠬࡢࡵ࠱࠲ࡧ࠷ࠬઓ"),l1ll11l1_kz_ (u"࣓࠭ࠨઔ"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠧ࡝ࡷ࠳࠵࠺ࡨࠧક"),l1ll11l1_kz_ (u"ࠨढ़ࠪખ")).replace(l1ll11l1_kz_ (u"ࠩ࡟ࡹ࠵࠷࠵ࡢࠩગ"),l1ll11l1_kz_ (u"ࠪफ़ࠬઘ"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠫࡡࡻ࠰࠲࠹ࡤࠫઙ"),l1ll11l1_kz_ (u"ࠬঀࠧચ")).replace(l1ll11l1_kz_ (u"࠭࡜ࡶ࠲࠴࠻࠾࠭છ"),l1ll11l1_kz_ (u"ࠧॺࠩજ"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠨ࡞ࡸ࠴࠶࠽ࡣࠨઝ"),l1ll11l1_kz_ (u"ࠩॿࠫઞ")).replace(l1ll11l1_kz_ (u"ࠪࡠࡺ࠶࠱࠸ࡤࠪટ"),l1ll11l1_kz_ (u"ࠫঀ࠭ઠ"))
    return l11lll1l11l1_kz_
url=l1ll11l1_kz_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡯ࡱࡧࡱ࡯ࡦࡺࡡ࡭ࡱࡪ࠲ࡨࡵ࡭࠰ࡨ࡬ࡰࡲࡿ࠯ࠨડ")
class l1lll1l11l11l1_kz_:
    url=l1ll11l1_kz_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡰࡲࡨࡲࡰࡧࡴࡢ࡮ࡲ࡫࠳ࡩ࡯࡮࠱ࡂࡷࡂ࡯࡮ࡥ࡫ࡤࡲࡦ࠱ࡪࡰࡰࡨࡷࠬઢ")
    @staticmethod
    def l1ll1ll1l11l1_kz_(url=l1ll11l1_kz_ (u"ࠧࠨણ")):
        content = l1111l1l11l1_kz_(url)
        l1l11lll11l1_kz_=[]
        l1ll1lll11l1_kz_=[]
        l1ll1111l11l1_kz_ = re.compile(l1ll11l1_kz_ (u"ࠨ࠾ࡤࡶࡹ࡯ࡣ࡭ࡧࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡶࡹ࡯ࡣ࡭ࡧࡁࠫત"),re.DOTALL).findall(content)
        for item in l1ll1111l11l1_kz_:
            l11111ll11l1_kz_=re.findall(l1ll11l1_kz_ (u"ࠩ࠿࡬࠸ࡄ࡜ࡴࠬ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲࡶ࠾࠴࠵࡯ࡱࡧࡱ࡯ࡦࡺࡡ࡭ࡱࡪ࠲ࡨࡵ࡭࠰࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠮ࡃ࠮ࡂ࠯ࡢࡀࠪથ"),item)
            year = re.findall(l1ll11l1_kz_ (u"ࠪࡀࡸࡶࡡ࡯࡝ࡡࡂࡢ࠰࠾ࠩ࡞ࡧࡿ࠹ࢃࠩ࠽࠱ࠪદ"),item)
            l11ll1ll11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠫࡁ࡯࡭ࡨࠢࡶࡶࡨࡃ࡛ࠣ࡞ࠪࡡ࠭࠴ࠫࡀࠫ࡞ࠦࡡ࠭࡝ࠨધ"),item)
            l1lll11l11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠬࡂࡳࡱࡣࡱࠤࡨࡲࡡࡴࡵࡀࠦ࡮ࡩ࡯࡯࠯ࡶࡸࡦࡸ࠲ࠣࡀ࡟ࡷ࠯ࡂ࠯ࡴࡲࡤࡲࡃ࠮࠮ࠬࡁࠬࡀ࠴ࡪࡩࡷࡀࠪન"),item,re.DOTALL)
            l1l1111l11l1_kz_ = re.findall(l1ll11l1_kz_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡹ࡫ࡸࡵࡱࠥࡂ࠭࠴ࠫࡀࠫ࠿ࠫ઩"),item,re.DOTALL)
            if l11111ll11l1_kz_:
                href = l11111ll11l1_kz_[0][0]
                title= l11l1l1l11l1_kz_(l11111ll11l1_kz_[0][1])
                l11ll1ll11l1_kz_ = l11ll1ll11l1_kz_[0] if l11ll1ll11l1_kz_ else l1ll11l1_kz_ (u"ࠧࠨપ")
                l1lll11l11l1_kz_ = l1lll11l11l1_kz_[0].strip() if l1lll11l11l1_kz_ else l1ll11l1_kz_ (u"ࠨࠩફ")
                l1l1llll11l1_kz_={l1ll11l1_kz_ (u"ࠩ࡫ࡶࡪ࡬ࠧબ"):href,
                    l1ll11l1_kz_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩભ"):title,
                    l1ll11l1_kz_ (u"ࠫ࡮ࡳࡧࠨમ"):l11ll1ll11l1_kz_,
                    l1ll11l1_kz_ (u"ࠬࡩ࡯ࡥࡧࠪય"):l1lll11l11l1_kz_,
                    l1ll11l1_kz_ (u"࠭ࡹࡦࡣࡵࠫર"):year[0] if year else l1ll11l1_kz_ (u"ࠧࠨ઱"),
                    l1ll11l1_kz_ (u"ࠨࡲ࡯ࡳࡹ࠭લ"):l11l1l1l11l1_kz_(l1l1111l11l1_kz_[0]).strip() if l1l1111l11l1_kz_ else l1ll11l1_kz_ (u"ࠩࠪળ")
                }
                if l1ll11l1_kz_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡣ࡯ࡩ࠴࠭઴") in href:
                    l1l11lll11l1_kz_.append(l1l1llll11l1_kz_)
                else:
                    l1ll1lll11l1_kz_.append(l1l1llll11l1_kz_)
        l1l1l1ll11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࡡࠢ࡝ࠩࡠࠬ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡵࡰࡦࡰ࡮ࡥࡹࡧ࡬ࡰࡩ࠱ࡧࡴࡳ࠯࠯࠭ࡂ࠭ࡠࠨ࡜ࠨ࡟ࡁࡀࡸࡶࡡ࡯ࠢࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡧࡴࡴ࠭ࡤࡪࡨࡺࡷࡵ࡮࠮࡮ࡨࡪࡹࠨ࠾ࠨવ"),content)
        l1l1l1ll11l1_kz_ = l1l1l1ll11l1_kz_[0] if l1l1l1ll11l1_kz_ else False
        l1ll111ll11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃ࡛ࠣ࡞ࠪࡡ࠭࡮ࡴࡵࡲࡶ࠾࠴࠵࡯ࡱࡧࡱ࡯ࡦࡺࡡ࡭ࡱࡪ࠲ࡨࡵ࡭࠰࠰࠮ࡃ࠮ࡡࠢ࡝ࠩࡠࡂࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡨࡵ࡮࠮ࡥ࡫ࡩࡻࡸ࡯࡯࠯ࡵ࡭࡬࡮ࡴࠣࡀࠪશ"),content)
        l1ll111ll11l1_kz_ = l1ll111ll11l1_kz_[0] if l1ll111ll11l1_kz_ else False
        return l1ll1lll11l1_kz_,l1l11lll11l1_kz_,(l1l1l1ll11l1_kz_,l1ll111ll11l1_kz_)
    @staticmethod
    def l1ll111l11l1_kz_(url=l1ll11l1_kz_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡰࡲࡨࡲࡰࡧࡴࡢ࡮ࡲ࡫࠳ࡩ࡯࡮࠱ࡶࡩࡷ࡯ࡡ࡭ࡧ࠲ࡱ࡮ࡴࡤࡩࡷࡱࡸࡪࡸ࠯ࠨષ")):
        if not l1ll11l1_kz_ (u"ࠧࡀࡶࡤࡦࡂ࡫ࡰࡪࡵࡲࡨࡪࡹࠧસ") in url:
            url +=l1ll11l1_kz_ (u"ࠨࡁࡷࡥࡧࡃࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨહ")
        out = []
        content = l1111l1l11l1_kz_(url)
        l1ll1llll11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠩ࠿ࡹࡱࠦࡣ࡭ࡣࡶࡷࡂࠨࡥࡱ࡫ࡶࡳࡩ࡯࡯ࡴࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱ࠭઺"),content,re.DOTALL)
        for l1lllll1l11l1_kz_ in l1ll1llll11l1_kz_:
            l111llll11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠪࡀࡱ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯࡭࡫ࡁࠫ઻"),l1lllll1l11l1_kz_,re.DOTALL)
            for l11l1lll11l1_kz_ in l111llll11l1_kz_:
                l11ll1ll11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠫࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ઼ࠧ"),l11l1lll11l1_kz_)
                l111111l11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡲࡺࡳࡥࡳࡣࡱࡨࡴࠨ࠾࡝ࡵ࠭ࠬࡡࡪࠫࠪ࡞ࡶ࠮࠲ࡢࡳࠫࠪ࡟ࡨ࠰࠯࡜ࡴࠬ࠿࠳ࡩ࡯ࡶ࠿ࠩઽ"),l11l1lll11l1_kz_)
                l11111ll11l1_kz_ = re.findall(l1ll11l1_kz_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡳࡵ࡫࡮࡬ࡣࡷࡥࡱࡵࡧ࠯ࡥࡲࡱ࠴࠴ࠪࡀࠫࠥࡂ࠭ࡡ࡞࠽࡟࠮࠭ࡁ࠵ࡡ࠿ࠩા"),l11l1lll11l1_kz_)
                data = re.findall(l1ll11l1_kz_ (u"ࠧ࠽ࡵࡳࡥࡳࠦࡣ࡭ࡣࡶࡷࡂࠨࡤࡢࡶࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫિ"),l11l1lll11l1_kz_)
                if l11111ll11l1_kz_:
                    l1l1lllll11l1_kz_,l1l11l1ll11l1_kz_ = l111111l11l1_kz_[0] if l111111l11l1_kz_ else (l1ll11l1_kz_ (u"ࠨࠩી"),l1ll11l1_kz_ (u"ࠩࠪુ"))
                    l11ll1ll11l1_kz_ = l11ll1ll11l1_kz_[0] if l11ll1ll11l1_kz_ else l1ll11l1_kz_ (u"ࠪࠫૂ")
                    out.append({l1ll11l1_kz_ (u"ࠫ࡭ࡸࡥࡧࠩૃ"):l11111ll11l1_kz_[0][0],l1ll11l1_kz_ (u"ࠬࡺࡩࡵ࡮ࡨࠫૄ"):l11111ll11l1_kz_[0][1],l1ll11l1_kz_ (u"࠭ࡩ࡮ࡩࠪૅ"):l11ll1ll11l1_kz_,
                        l1ll11l1_kz_ (u"ࠧࡴࡧࡤࡷࡴࡴࠧ૆"):int(l1l1lllll11l1_kz_),l1ll11l1_kz_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࠩે"):int(l1l11l1ll11l1_kz_)})
        return out
    @staticmethod
    def l1l1lll1l11l1_kz_(out):
        l1l11lll11l1_kz_={}
        l1ll1llll11l1_kz_ = [x.get(l1ll11l1_kz_ (u"ࠩࡶࡩࡦࡹ࡯࡯ࠩૈ")) for x in out]
        for s in set(l1ll1llll11l1_kz_):
            l1l11lll11l1_kz_[l1ll11l1_kz_ (u"ࠪࡗࡪࢀ࡯࡯ࠢࠨ࠴࠷ࡪࠧૉ")%s]=[out[i] for i, j in enumerate(l1ll1llll11l1_kz_) if j == s]
        return l1l11lll11l1_kz_
    @staticmethod
    def l1l1l1l1l11l1_kz_():
        content = l1111l1l11l1_kz_(l1ll11l1_kz_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡵࡰࡦࡰ࡮ࡥࡹࡧ࡬ࡰࡩ࠱ࡧࡴࡳࠧ૊"))
        stuff = re.compile(l1ll11l1_kz_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵࡹ࠺࠰࠱ࡲࡴࡪࡴ࡫ࡢࡶࡤࡰࡴ࡭࠮ࡤࡱࡰ࠳࡬ࡧࡴࡶࡰࡨ࡯࠴࠴ࠫࡀࠫࠥࡠࡸ࠰࡛࡟ࡀࡠ࠮ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾࡜࡞ࡶࡠࡳࠦ࡝ࠫ࠾࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡮ࡄࠧો")).findall(content)
        out=[]
        for l1llll11l11l1_kz_, title, l1l11ll1l11l1_kz_ in stuff:
            out.append({l1ll11l1_kz_ (u"ࠨࡨࡳࡧࡩࠦૌ"):l1llll11l11l1_kz_,l1ll11l1_kz_ (u"ࠢࡵ࡫ࡷࡰࡪࠨ્"):l1ll11l1_kz_ (u"ࠣࡽࢀࠤ࠭ࢁࡽࠪࠤ૎").format(title,l1l11ll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠩࠩࡲࡧࡹࡰ࠼ࠩ૏"),l1ll11l1_kz_ (u"ࠪࠫૐ")))})
        return out
    @staticmethod
    def l111ll1l11l1_kz_():
        content = l1111l1l11l1_kz_(l1ll11l1_kz_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡵࡰࡦࡰ࡮ࡥࡹࡧ࡬ࡰࡩ࠱ࡧࡴࡳࠧ૑"))
        stuff = re.compile(l1ll11l1_kz_ (u"ࠬࡂ࡬ࡪࡀ࡟ࡷ࠯ࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵࡹ࠺࠰࠱ࡲࡴࡪࡴ࡫ࡢࡶࡤࡰࡴ࡭࠮ࡤࡱࡰ࠳ࡷࡵ࡫࠰࠰࠮ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀ࠿࠳ࡱ࡯࠾ࠨ૒")).findall(content)
        out=[]
        for l1llll11l11l1_kz_, title, in stuff:
            out.append({l1ll11l1_kz_ (u"ࠨࡨࡳࡧࡩࠦ૓"):l1llll11l11l1_kz_,l1ll11l1_kz_ (u"ࠢࡵ࡫ࡷࡰࡪࠨ૔"):title})
        return out
    @staticmethod
    def l1ll11ll11l1_kz_(url):
        if not l1ll11l1_kz_ (u"ࠨࡁࡷࡥࡧࡃࡶࡪࡦࡨࡳࠫࡶ࡬ࡢࡻࡨࡶࡂࡵࡰࡵ࡫ࡲࡲࠬ૕") in url:
            url+=l1ll11l1_kz_ (u"ࠩࡂࡸࡦࡨ࠽ࡷ࡫ࡧࡩࡴࠬࡰ࡭ࡣࡼࡩࡷࡃ࡯ࡱࡶ࡬ࡳࡳ࠳࠱ࠨ૖")
        content = l1111l1l11l1_kz_(url)
        l1l1l11ll11l1_kz_ = re.compile(l1ll11l1_kz_ (u"ࠪࡀࡺࡲࠠࡤ࡮ࡤࡷࡸࡃࠢࡱ࡮ࡤࡽࡪࡸ࡟ࡶ࡮ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨ૗"),re.DOTALL).findall(content)
        l1111lll11l1_kz_=l1ll11l1_kz_ (u"ࠫࠬ૘")
        l1l1l1lll11l1_kz_=[]
        for l1l1ll1l11l1_kz_ in l1l1l11ll11l1_kz_:
            l111l1ll11l1_kz_ =re.findall(l1ll11l1_kz_ (u"ࠬࡂࡡࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡣࡦࡸ࡮ࡼࡥࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠩ૙"),l1l1ll1l11l1_kz_)
            if l111l1ll11l1_kz_ and not l1111lll11l1_kz_:
                l1111lll11l1_kz_ = l111l1ll11l1_kz_[0][1]
            l1l11l1l11l1_kz_ = re.findall(l1ll11l1_kz_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠩ૚"),l1l1ll1l11l1_kz_)
            if l1l11l1l11l1_kz_:
                l1l1l1lll11l1_kz_.append({l1ll11l1_kz_ (u"ࠧࡩࡴࡨࡪࠬ૛"):l1l11l1l11l1_kz_[0][0],l1ll11l1_kz_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ૜"):l1l11l1l11l1_kz_[0][1],l1ll11l1_kz_ (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ૝"):False})
        stuff = re.compile(l1ll11l1_kz_ (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨࠬ࠳࠰࠿ࠪ࠾࠲࡭࡫ࡸࡡ࡮ࡧࡁࠫ૞"),re.I).findall(content)
        if stuff:
            src = re.findall(l1ll11l1_kz_ (u"ࠫࡸࡸࡣ࠾࡝ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟ࠪ૟"),stuff[0],re.I)
            if src:
                l1l1l1lll11l1_kz_.append({l1ll11l1_kz_ (u"ࠬ࡮ࡲࡦࡨࠪૠ"):src[0],l1ll11l1_kz_ (u"࠭ࡴࡪࡶ࡯ࡩࠬૡ"):l1111lll11l1_kz_ if l1111lll11l1_kz_ else l1ll11l1_kz_ (u"ࠧࡱ࡮ࡤࡽࡪࡸࠧૢ"),l1ll11l1_kz_ (u"ࠨࡴࡨࡷࡴࡲࡶࡦࡦࠪૣ"):True})
        return l1l1l1lll11l1_kz_
    @staticmethod
    def l1lll1lll11l1_kz_(url):
        content = l1111l1l11l1_kz_(url)
        stuff = re.compile(l1ll11l1_kz_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠫ࠲࠯ࡅࠩ࠽࠱࡬ࡪࡷࡧ࡭ࡦࡀࠪ૤"),re.I).findall(content)
        if stuff:
            src = re.findall(l1ll11l1_kz_ (u"ࠪࡷࡷࡩ࠽࡜ࠤ࡟ࠫࡢ࠮࠮ࠫࡁࠬ࡟ࠧࡢࠧ࡞ࠩ૥"),stuff[0],re.I)
            if src:
                return src[0] if src else l1ll11l1_kz_ (u"ࠫࠬ૦")
        return l1ll11l1_kz_ (u"ࠬ࠭૧")
class l1lll11ll11l1_kz_:
    def l1llll1ll11l1_kz_(self,url):
        if not url:
            url = l1ll11l1_kz_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡪࡣࡱࡩ࡭ࡱࡳ࠮ࡱ࡮࠲ࠫ૨")
        elif url.startswith(l1ll11l1_kz_ (u"ࠧ࠰࠱ࠪ૩")):
            url = l1ll11l1_kz_ (u"ࠨࡪࡷࡸࡵ࠭૪")+url
        elif url.startswith(l1ll11l1_kz_ (u"ࠩ࠲ࠫ૫")):
            url = urljoin(l1ll11l1_kz_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡮ࡧࡵࡦࡪ࡮ࡰ࠲ࡵࡲ࠯ࠨ૬"),url)
        return url
    @staticmethod
    def l1ll1ll1l11l1_kz_(url=l1ll11l1_kz_ (u"ࠫࠬ૭")):
        if not url:
            url = l1ll11l1_kz_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡰࡢࡰࡨ࡬ࡰࡲ࠴ࡰ࡭࠱ࠪ૮")
        elif url.startswith(l1ll11l1_kz_ (u"࠭࠯ࠨ૯")):
            url = urljoin(l1ll11l1_kz_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡫ࡤࡲࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࠬ૰"),url)
        content = l1111l1l11l1_kz_(url)
        out=[]
        l111l11l11l1_kz_ = re.compile(l1ll11l1_kz_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺ࠭ࡨࡴ࡬ࡨࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ૱"),re.DOTALL).findall(content)
        for show in l111l11l11l1_kz_:
            l11ll11l11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠵ࡳࡦࡴ࡬ࡥࡱ࡫࠯࠯ࠬࠬࠦࡃࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ૲"),show)
            if l11ll11l11l1_kz_:
                l11ll1ll11l1_kz_ = l11ll11l11l1_kz_[0][1]
                l11ll1ll11l1_kz_ = urljoin(l1ll11l1_kz_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡮ࡧࡵࡦࡪ࡮ࡰ࠲ࡵࡲ࠯ࠨ૳"),l11ll1ll11l1_kz_) if not l11ll1ll11l1_kz_.startswith(l1ll11l1_kz_ (u"ࠫ࡭ࡺࡴࡱࠩ૴")) else l11ll1ll11l1_kz_
                title = l11ll11l11l1_kz_[0][0].replace(l1ll11l1_kz_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡥࡱ࡫࠯ࠨ૵"),l1ll11l1_kz_ (u"࠭ࠧ૶")).replace(l1ll11l1_kz_ (u"ࠧ࠮ࠩ૷"),l1ll11l1_kz_ (u"ࠨࠢࠪ૸")).replace(l1ll11l1_kz_ (u"ࠩ࠲ࠫૹ"),l1ll11l1_kz_ (u"ࠪࠫૺ")).title()
                out.append({l1ll11l1_kz_ (u"ࠫ࡭ࡸࡥࡧࠩૻ"):l11ll11l11l1_kz_[0][0],l1ll11l1_kz_ (u"ࠬࡺࡩࡵ࡮ࡨࠫૼ"):title,l1ll11l1_kz_ (u"࠭ࡩ࡮ࡩࠪ૽"):l11ll1ll11l1_kz_})
        idx = content.find(l1ll11l1_kz_ (u"ࠧࡩ࠵ࡁࡗࡪࡸࡩࡢ࡮ࡨࡀ࠴࡮࠳࠿ࠩ૾"))
        if idx:
            l1l111l1l11l1_kz_ = re.compile(l1ll11l1_kz_ (u"ࠨ࠾ࡸࡰࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ૿"),re.DOTALL).search(content[idx:-1])
            l1l111l1l11l1_kz_ = l1l111l1l11l1_kz_.group(1) if l1l111l1l11l1_kz_ else l1ll11l1_kz_ (u"ࠩࠪ଀")
            l1l111l1l11l1_kz_ = re.sub(l1ll11l1_kz_ (u"ࡵࠦࡁࠧ࠭࠮ࠪ࠱ࢀࡡࡹࡼ࡝ࡰࠬ࠮ࡄ࠳࠭࠿ࠤଁ"), l1ll11l1_kz_ (u"ࠦࠧଂ"), l1l111l1l11l1_kz_)
            l1l1l111l11l1_kz_ = re.compile(l1ll11l1_kz_ (u"ࠬࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠵ࡳࡦࡴ࡬ࡥࡱ࡫࠯࠯ࠬࡂ࠭ࠧࡄࠨ࡜ࡠࡁࡡ࠯࠯࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠩଃ")).findall(l1l111l1l11l1_kz_)
            for href,title in l1l1l111l11l1_kz_:
                out.append({l1ll11l1_kz_ (u"࠭ࡨࡳࡧࡩࠫ଄"):href,l1ll11l1_kz_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ଅ"):title})
        return out
    @staticmethod
    def l1ll11l1l11l1_kz_(url=l1ll11l1_kz_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡬ࡥࡳ࡫࡯࡬࡮࠰ࡳࡰ࠴ࡹࡥࡳ࡫ࡤࡰࡪ࠵ࡤࡦࡶࡨ࡯ࡹࡿࡷ࠰ࠩଆ")):
        if not url:
            url = l1ll11l1_kz_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡭ࡦࡴ࡬ࡩ࡭࡯࠱ࡴࡱ࠵ࠧଇ")
        if url.startswith(l1ll11l1_kz_ (u"ࠪ࠳࠴࠭ଈ")):
            url = l1ll11l1_kz_ (u"ࠫ࡭ࡺࡴࡱࠩଉ")+url
        if url.startswith(l1ll11l1_kz_ (u"ࠬ࠵ࠧଊ")):
            url = urljoin(l1ll11l1_kz_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡪࡣࡱࡩ࡭ࡱࡳ࠮ࡱ࡮࠲ࠫଋ"),url)
        url += l1ll11l1_kz_ (u"ࠧ࠰ࠩଌ") if not url.endswith(l1ll11l1_kz_ (u"ࠨ࠱ࠪ଍")) else l1ll11l1_kz_ (u"ࠩࠪ଎")
        content = l1111l1l11l1_kz_(url)
        out=[]
        l1l11l1_kz_ = re.compile(l1ll11l1_kz_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡵ࠯ࡪࡶ࡮ࡪࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ଏ"),re.DOTALL).findall(content)
        for l1l111ll11l1_kz_ in l1l11l1_kz_:
            l1l1lllll11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠫࡸ࡫ࡺࡰࡰ࡟ࡷ࠯࠮࡜ࡥ࠭ࠬࠫଐ"),l1l111ll11l1_kz_,re.I)
            l1l1lllll11l1_kz_ = l1l1lllll11l1_kz_[0] if l1l1lllll11l1_kz_ else l1ll11l1_kz_ (u"ࠬ࠭଑")
            l1l11l1ll11l1_kz_ = re.findall(l1ll11l1_kz_ (u"࠭ࡏࡥࡥ࡬ࡲࡪࡱ࡜ࡴࠬࠫࡠࡩ࠱ࠩࠨ଒"),l1l111ll11l1_kz_,re.I)
            l1l11l1ll11l1_kz_ = l1l11l1ll11l1_kz_[0] if l1l11l1ll11l1_kz_ else l1ll11l1_kz_ (u"ࠧࠨଓ")
            href = re.compile(l1ll11l1_kz_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬࡸ࡯࡮ࡨ࡮ࡨࡴࡦ࡭ࡥ࠯ࡲ࡫ࡴࡡࡅࡩࡥ࠿࡟ࡨ࠰࠯ࠢࠨଔ")).findall(l1l111ll11l1_kz_)
            l11ll1ll11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠩ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬକ"),l1l111ll11l1_kz_)
            if href and l1l1lllll11l1_kz_ and l1l11l1ll11l1_kz_:
                l11ll1ll11l1_kz_ = urljoin(l1ll11l1_kz_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡮ࡧࡵࡦࡪ࡮ࡰ࠲ࡵࡲ࠯ࠨଖ"),l11ll1ll11l1_kz_[0]) if not l11ll1ll11l1_kz_[0].startswith(l1ll11l1_kz_ (u"ࠫ࡭ࡺࡴࡱࠩଗ")) else l1ll11l1_kz_ (u"ࠬ࠭ଘ")
                out.append({l1ll11l1_kz_ (u"࠭ࡨࡳࡧࡩࠫଙ"):url+href[0],l1ll11l1_kz_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ଚ"):l1ll11l1_kz_ (u"ࠨࡕࡨࡾࡴࡴࠠࠦࡵ࠯ࠤࡊࡶࡩࡻࡱࡧࠤࠪࡹࠧଛ")%(l1l1lllll11l1_kz_,l1l11l1ll11l1_kz_),l1ll11l1_kz_ (u"ࠩ࡬ࡱ࡬࠭ଜ"):l11ll1ll11l1_kz_,
                l1ll11l1_kz_ (u"ࠪࡷࡪࡧࡳࡰࡰࠪଝ"):int(l1l1lllll11l1_kz_),l1ll11l1_kz_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࠬଞ"):int(l1l11l1ll11l1_kz_)})
        return out
