# -*- coding: utf-8 -*-
import sys
l1l1ll11l1_kz_ = sys.version_info [0] == 2
l1l1l1l11l1_kz_ = 2048
l11lll11l1_kz_ = 7
def l1ll11l1_kz_ (keyedStringLiteral):
	global l111l1l11l1_kz_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l1ll11l1_kz_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l1l1l11l1_kz_ - (charIndex + stringNr) % l11lll11l1_kz_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l1l1l11l1_kz_ - (charIndex + stringNr) % l11lll11l1_kz_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os,json,base64
import cookielib
from urlparse import urlparse,urljoin
l1l1l11l11l1_kz_ = 15
l1l11l11l11l1_kz_=l1ll11l1_kz_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠷࠰࠴࠿ࠥ࡝ࡩ࡯࠸࠷࠿ࠥࡾ࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠷࠳࠱࠴࠳࠹࠱࠷࠵࠱࠵࠵࠶ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧࡢ")
l1ll1l1ll11l1_kz_=l1ll11l1_kz_ (u"ࡷ࠭ࡣࡰࡱ࡮࡭ࡪ࠭ࡣ")
l1l1ll11l11l1_kz_=l1ll11l1_kz_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱࡯ࡷ࡫ࡳ࡬ࡱࡺ࡯ࡦࢀ࡯࡯ࡧ࠱ࡴࡱ࠭ࡤ")
def l1lllllll11l1_kz_(l1ll1l1l11l1_kz_):
    cookies=l1ll11l1_kz_ (u"ࠧࠨࡥ")
    try:
        if l1ll1l1ll11l1_kz_ and os.path.exists(l1ll1l1ll11l1_kz_):
            l1ll1l1l11l1_kz_.load(l1ll1l1ll11l1_kz_,True,True)
            cookies = l1ll11l1_kz_ (u"ࠨ࠽ࠪࡦ").join([l1ll11l1_kz_ (u"ࠩࠨࡷࡂࠫࡳࠨࡧ")%(c.name,c.value) for c in l1ll1l1l11l1_kz_])
    except:
        cookies=l1ll11l1_kz_ (u"ࠪࠫࡨ")
    return cookies
def l1111l1l11l1_kz_(url,data=None,header={}):
    l1ll1l1l11l1_kz_ = cookielib.LWPCookieJar()
    if not l1lllllll11l1_kz_(l1ll1l1l11l1_kz_):
        content = _1ll1l11l11l1_kz_(l1ll11l1_kz_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯࡭ࡵࡩࡸࡱ࡯ࡸ࡭ࡤࡾࡴࡴࡥ࠯ࡲ࡯࠳࡮ࡳࡡࡨࡧࡶ࠳ࡸࡺࡡࡵࡻࡶࡸࡾࡱࡩ࠯ࡩ࡬ࡪࠬࡩ"))
    return _1ll1l11l11l1_kz_(url,data=data,header=header)
def _1ll1l11l11l1_kz_(url,data=None,header={}):
    l1ll1l1l11l1_kz_ = cookielib.LWPCookieJar()
    cookies=l1lllllll11l1_kz_(l1ll1l1l11l1_kz_)
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1ll1l1l11l1_kz_))
    urllib2.install_opener(opener)
    headers={l1ll11l1_kz_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩࡪ"): l1l11l11l11l1_kz_, l1ll11l1_kz_ (u"࠭ࡈࡰࡵࡷࠫ࡫"):l1ll11l1_kz_ (u"ࠧࡸࡹࡺ࠲ࡰࡸࡥࡴ࡭ࡲࡻࡰࡧࡺࡰࡰࡨ࠲ࡵࡲࠧ࡬"),l1ll11l1_kz_ (u"ࠨࡑࡵ࡭࡬࡯࡮ࠨ࡭"):l1ll11l1_kz_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴࡫ࡳࡧࡶ࡯ࡴࡽ࡫ࡢࡼࡲࡲࡪ࠴ࡰ࡭ࠩ࡮"),}
    if not cookies:
        headers[l1ll11l1_kz_ (u"࡙ࠪࡵ࡭ࡲࡢࡦࡨ࠱ࡎࡴࡳࡦࡥࡸࡶࡪ࠳ࡒࡦࡳࡸࡩࡸࡺࡳࠨ࡯")]=l1ll11l1_kz_ (u"ࠫ࠶࠭ࡰ")
    headers.update(header)
    req = urllib2.Request(url,data,headers)
    if cookies: req.add_header(l1ll11l1_kz_ (u"ࠧࡉ࡯ࡰ࡭࡬ࡩࠧࡱ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l1l1l11l11l1_kz_)
        l1lll111l11l1_kz_ = response.read()
        response.close()
        l1ll1l1l11l1_kz_.save(l1ll1l1ll11l1_kz_, ignore_discard = True)
    except:
        l1lll111l11l1_kz_=l1ll11l1_kz_ (u"࠭ࠧࡲ")
    return l1lll111l11l1_kz_
def l11l1l1l11l1_kz_(l11lll1l11l1_kz_):
    if isinstance(l11lll1l11l1_kz_, unicode):
        l11lll1l11l1_kz_ = l11lll1l11l1_kz_.encode(l1ll11l1_kz_ (u"ࠧࡶࡶࡩ࠱࠽࠭ࡳ"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠨࠨ࡯ࡸࡀࡨࡲ࠰ࠨࡪࡸࡀ࠭ࡴ"),l1ll11l1_kz_ (u"ࠩࠣࠫࡵ"))
    s=l1ll11l1_kz_ (u"ࠪࡎ࡮ࡔࡣ࡛ࡅࡶ࠻ࠬࡶ")
    l11lll1l11l1_kz_ = re.sub(s.decode(l1ll11l1_kz_ (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫࡷ")),l1ll11l1_kz_ (u"ࠬ࠭ࡸ"),l11lll1l11l1_kz_)
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"࠭࡜࡯ࠩࡹ"),l1ll11l1_kz_ (u"ࠧࠨࡺ")).replace(l1ll11l1_kz_ (u"ࠨ࡞ࡵࠫࡻ"),l1ll11l1_kz_ (u"ࠩࠪࡼ"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠪࠪࡳࡨࡳࡱ࠽ࠪࡽ"),l1ll11l1_kz_ (u"ࠫࠬࡾ"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠬࠬࡱࡶࡱࡷ࠿ࠬࡿ"),l1ll11l1_kz_ (u"࠭ࠢࠨࢀ")).replace(l1ll11l1_kz_ (u"ࠧࠧࡣࡰࡴࡀࡷࡵࡰࡶ࠾ࠫࢁ"),l1ll11l1_kz_ (u"ࠨࠤࠪࢂ"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠩࠩࡳࡦࡩࡵࡵࡧ࠾ࠫࢃ"),l1ll11l1_kz_ (u"ࠪࣷࠬࢄ")).replace(l1ll11l1_kz_ (u"ࠫࠫࡕࡡࡤࡷࡷࡩࡀ࠭ࢅ"),l1ll11l1_kz_ (u"ࠬࣙࠧࢆ"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"࠭ࠦࡢ࡯ࡳ࠿ࡴࡧࡣࡶࡶࡨ࠿ࠬࢇ"),l1ll11l1_kz_ (u"ࠧࣴࠩ࢈")).replace(l1ll11l1_kz_ (u"ࠨࠨࡤࡱࡵࡁࡏࡢࡥࡸࡸࡪࡁࠧࢉ"),l1ll11l1_kz_ (u"ࠩࣖࠫࢊ"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠪࠪࡦࡳࡰ࠼ࠩࢋ"),l1ll11l1_kz_ (u"ࠫࠫ࠭ࢌ"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠬࡢࡵ࠱࠳࠳࠹ࠬࢍ"),l1ll11l1_kz_ (u"࠭अࠨࢎ")).replace(l1ll11l1_kz_ (u"ࠧ࡝ࡷ࠳࠵࠵࠺ࠧ࢏"),l1ll11l1_kz_ (u"ࠨआࠪ࢐"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠩ࡟ࡹ࠵࠷࠰࠸ࠩ࢑"),l1ll11l1_kz_ (u"ࠪऋࠬ࢒")).replace(l1ll11l1_kz_ (u"ࠫࡡࡻ࠰࠲࠲࠹ࠫ࢓"),l1ll11l1_kz_ (u"ࠬऌࠧ࢔"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"࠭࡜ࡶ࠲࠴࠵࠾࠭࢕"),l1ll11l1_kz_ (u"ࠧचࠩ࢖")).replace(l1ll11l1_kz_ (u"ࠨ࡞ࡸ࠴࠶࠷࠸ࠨࢗ"),l1ll11l1_kz_ (u"ࠩछࠫ࢘"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠪࡠࡺ࠶࠱࠵࠴࢙ࠪ"),l1ll11l1_kz_ (u"ࠫे࢚࠭")).replace(l1ll11l1_kz_ (u"ࠬࡢࡵ࠱࠳࠷࠵࢛ࠬ"),l1ll11l1_kz_ (u"࠭ुࠨ࢜"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠧ࡝ࡷ࠳࠵࠹࠺ࠧ࢝"),l1ll11l1_kz_ (u"ࠨॆࠪ࢞")).replace(l1ll11l1_kz_ (u"ࠩ࡟ࡹ࠵࠷࠴࠵ࠩ࢟"),l1ll11l1_kz_ (u"ࠪेࠬࢠ"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠫࡡࡻ࠰࠱ࡨ࠶ࠫࢡ"),l1ll11l1_kz_ (u"ࣹࠬࠧࢢ")).replace(l1ll11l1_kz_ (u"࠭࡜ࡶ࠲࠳ࡨ࠸࠭ࢣ"),l1ll11l1_kz_ (u"ࠧࣔࠩࢤ"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠨ࡞ࡸ࠴࠶࠻ࡢࠨࢥ"),l1ll11l1_kz_ (u"ࠩफ़ࠫࢦ")).replace(l1ll11l1_kz_ (u"ࠪࡠࡺ࠶࠱࠶ࡣࠪࢧ"),l1ll11l1_kz_ (u"ࠫय़࠭ࢨ"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠬࡢࡵ࠱࠳࠺ࡥࠬࢩ"),l1ll11l1_kz_ (u"࠭ॺࠨࢪ")).replace(l1ll11l1_kz_ (u"ࠧ࡝ࡷ࠳࠵࠼࠿ࠧࢫ"),l1ll11l1_kz_ (u"ࠨॻࠪࢬ"))
    l11lll1l11l1_kz_ = l11lll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠩ࡟ࡹ࠵࠷࠷ࡤࠩࢭ"),l1ll11l1_kz_ (u"ࠪঀࠬࢮ")).replace(l1ll11l1_kz_ (u"ࠫࡡࡻ࠰࠲࠹ࡥࠫࢯ"),l1ll11l1_kz_ (u"ࠬঁࠧࢰ"))
    return l11lll1l11l1_kz_
def l1ll1ll1l11l1_kz_(url):
    content = l1111l1l11l1_kz_(url)
    out=[]
    l1ll1111l11l1_kz_ = re.compile(l1ll11l1_kz_ (u"࠭࠼࡭࡫ࡁࡠࡸ࠰࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡧࡵࡸࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭ࢱ"),re.DOTALL).findall(content)
    for item in l1ll1111l11l1_kz_:
        href  = re.findall(l1ll11l1_kz_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࢲ"),item)
        title = re.findall(l1ll11l1_kz_ (u"ࠨࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࢳ"),item)
        if href and title:
            year = re.findall(l1ll11l1_kz_ (u"ࠩࠫࠬࡄࡀ࠲࠱ࡾ࠴࠽࠮ࡢࡤࡼ࠴ࢀ࠭ࠬࢴ"),title[0])
            l11ll1ll11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠪࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࡡࠢ࡝ࠩࡠࠬ࠳࠱࠿ࠪ࡝ࠥࡠࠬࡣࠧࢵ"),item)
            l1lll11l11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠫࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡨࡵ࡮࠮ࡵࡷࡥࡷ࠸ࠢ࠿࡞ࡶ࠮ࡁ࠵ࡳࡱࡣࡱࡂ࠭࠴ࠫࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩࢶ"),item,re.DOTALL)
            l1l1111l11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠬࡂࡳࡱࡣࡱࡂ࠭࠴ࠫࡀࠫ࠿࠳ࡸࡶࡡ࡯ࠩࢷ"),item,re.DOTALL)
            l1l1llll11l1_kz_={l1ll11l1_kz_ (u"࠭ࡨࡳࡧࡩࠫࢸ"):urljoin(l1l1ll11l11l1_kz_,href[0].strip()),
                l1ll11l1_kz_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࢹ"):l11l1l1l11l1_kz_(title[0].strip().replace(l1ll11l1_kz_ (u"ࠨࡱࡱࡰ࡮ࡴࡥࠨࢺ"),l1ll11l1_kz_ (u"ࠩࠪࢻ"))),
                l1ll11l1_kz_ (u"ࠪ࡭ࡲ࡭ࠧࢼ"):urljoin(l1l1ll11l11l1_kz_,l11ll1ll11l1_kz_[0].strip()) if l11ll1ll11l1_kz_ else l1ll11l1_kz_ (u"ࠫࠬࢽ"),
                l1ll11l1_kz_ (u"ࠬࡩ࡯ࡥࡧࠪࢾ"):l1ll11l1_kz_ (u"࠭ࠧࢿ"),
                l1ll11l1_kz_ (u"ࠧࡺࡧࡤࡶࠬࣀ"):year[0] if year else l1ll11l1_kz_ (u"ࠨࠩࣁ"),
                l1ll11l1_kz_ (u"ࠩࡳࡰࡴࡺࠧࣂ"):l11l1l1l11l1_kz_(l1l1111l11l1_kz_[0]).strip() if l1l1111l11l1_kz_ else l1ll11l1_kz_ (u"ࠪࠫࣃ")
            }
            out.append(l1l1llll11l1_kz_)
    return out
def l1l1ll1ll11l1_kz_(l11lllll11l1_kz_=l1ll11l1_kz_ (u"ࠫࡋ࡯࡬࡮ࡻࠪࣄ")):
    content = l1111l1l11l1_kz_(l1l1ll11l11l1_kz_)
    out=[]
    if l11lllll11l1_kz_==l1ll11l1_kz_ (u"ࠬࡌࡩ࡭࡯ࡼࠫࣅ"):
        l1lll1l1l11l1_kz_ = re.findall(l1ll11l1_kz_ (u"࠭࠼࡭࡫ࠣࡧࡱࡧࡳࡴ࠿ࠥࡱࡪࡴࡵ࠮࡮࡬ࠦࡃࡂࡨ࠴ࡀࡓࡳࡵࡻ࡬ࡢࡴࡱࡩࠥ࡬ࡩ࡭࡯ࡼࠤࡦࡴࡩ࡮ࡱࡺࡥࡳ࡫࠼࠰ࡪ࠶ࡂࡡࡹࠪ࠽ࡷ࡯ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨࣆ"),content,re.DOTALL)
    else:
        l1lll1l1l11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠧ࠽࡮࡬ࠤࡨࡲࡡࡴࡵࡀࠦࡲ࡫࡮ࡶ࠯࡯࡭ࠧࡄ࠼ࡩ࠵ࡁࡔࡴࡶࡵ࡭ࡣࡵࡲࡪࠦ࡫ࡳࡧࡶ࡯ࣸࡽ࡫ࡪ࠾࠲࡬࠸ࡄ࡜ࡴࠬ࠿ࡹࡱࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪࣇ"),content,re.DOTALL)
    if l1lll1l1l11l1_kz_:
        l1ll1111l11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠱࠿ࠪࠤ࡟ࡷ࠯ࡺࡩࡵ࡮ࡨࡁࠧ࠴ࠫࡀࠤࡁࠬ࠳࠱࠿ࠪ࠾࠲ࡥࡃ࠭ࣈ"),l1lll1l1l11l1_kz_[0])
        for href, title in l1ll1111l11l1_kz_ :
            out.append({l1ll11l1_kz_ (u"ࠩ࡫ࡶࡪ࡬ࠧࣉ"):urljoin(l1l1ll11l11l1_kz_,href.strip()),
                l1ll11l1_kz_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ࣊"):l11l1l1l11l1_kz_(title.strip())})
    return out
def l11l111l11l1_kz_(url):
    content = l1111l1l11l1_kz_(url)
    out=[]
    l11ll1ll11l1_kz_=re.findall(l1ll11l1_kz_ (u"ࠫࡁ࡯࡭ࡨࠢࡵࡩࡱࡃࠢࡷ࠼࡬ࡱࡦ࡭ࡥࠣࠢࡶࡶࡨࡃ࡛ࠣ࡞ࠪࡡ࠭࠴ࠫࡀࠫ࡞ࠦࡡ࠭࡝ࠨ࣋"),content)
    l11ll1ll11l1_kz_ = urljoin(l1l1ll11l11l1_kz_,l11ll1ll11l1_kz_[0].strip()) if l11ll1ll11l1_kz_ else l1ll11l1_kz_ (u"ࠬ࠭࣌")
    l1l1111l11l1_kz_ = re.findall(l1ll11l1_kz_ (u"࠭࠼ࡱࠢࡦࡰࡦࡹࡳ࠾ࠤࡲࡴ࡮ࡹ࡟ࡵࡴࡨࡷࡨࠨࠠࡱࡴࡲࡴࡪࡸࡴࡺ࠿ࠥࡺ࠿ࡹࡵ࡮࡯ࡤࡶࡾࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ࣍"),content)
    l1l1111l11l1_kz_ = l11l1l1l11l1_kz_(l1l1111l11l1_kz_[0]).strip() if l1l1111l11l1_kz_ else l1ll11l1_kz_ (u"ࠧࠨ࣎")
    l1ll1111l11l1_kz_ = re.compile(l1ll11l1_kz_ (u"ࠨ࠾ࡷࡶࠥࡩ࡬ࡢࡵࡶࡁࠧࡽࡩࡦࡴࡶࡾࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡳ࣏ࠩ"),re.DOTALL).findall(content)
    for item in l1ll1111l11l1_kz_:
        data  = re.findall(l1ll11l1_kz_ (u"ࠩࡁࠬ࠳࠱࠿ࠪ࠾࠲ࡸࡩࡄ࣐ࠧ"),item)
        if len(data)>3:
            href  = re.findall(l1ll11l1_kz_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅ࣑ࠩࠣࠩ"),data[3])
            code = re.findall(l1ll11l1_kz_ (u"ࠫࡸࡶࡲࡪࡶࡨࡷࠥ࠮࡜ࡸ࠭ࠬࠤ࣒ࠬ"),data[2])
            if href:
                out.append({l1ll11l1_kz_ (u"ࠬ࡮ࡲࡦࡨ࣓ࠪ"):urljoin(l1l1ll11l11l1_kz_,href[0].strip()),
                    l1ll11l1_kz_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࣔ"):l1ll11l1_kz_ (u"ࠧࠦࡵ࠱ࠤࠪࡹࠧࣕ") % (data[0].strip(),data[1].strip()),
                    l1ll11l1_kz_ (u"ࠨࡥࡲࡨࡪ࠭ࣖ"):code[0] if code else l1ll11l1_kz_ (u"ࠩࠪࣗ"),
                    l1ll11l1_kz_ (u"ࠪ࡭ࡲ࡭ࠧࣘ"):l11ll1ll11l1_kz_,
                    l1ll11l1_kz_ (u"ࠫࡵࡲ࡯ࡵࠩࣙ"):l1l1111l11l1_kz_
                })
    return out
def l1l1lll11l1_kz_(url):
    content = l1111l1l11l1_kz_(url)
    l1ll1111l11l1_kz_ = re.compile(l1ll11l1_kz_ (u"ࠬࡂࡴࡳࠢࡦࡰࡦࡹࡳ࠾ࠤࡺ࡭ࡪࡸࡳࡻࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡷ࠭ࣚ"),re.DOTALL).findall(content)
    out=[]
    for item in l1ll1111l11l1_kz_:
        data  = re.findall(l1ll11l1_kz_ (u"࠭࠾ࠩ࡝ࡡࡠࡸࡂ࡝ࠬࡁࠬࡀ࠴ࡺࡤ࠿ࠩࣛ"),item)
        href = re.findall(l1ll11l1_kz_ (u"ࠧࠣࠢ࡟ࡻ࠰ࡃࠢࠩ࡞ࡧ࠯ࡡࡀ࠮ࠫࡁࠬࠦࠬࣜ"),item)
        if href: out.append({l1ll11l1_kz_ (u"ࠨࡪࡵࡩ࡫࠭ࣝ"):href[0].strip(),l1ll11l1_kz_ (u"ࠩࡷ࡭ࡹࡲࡥࠨࣞ"):l1ll11l1_kz_ (u"ࠪࠤࠬࣟ").join(data)})
    return out
def l1ll11lll11l1_kz_(href):
    l1l11llll11l1_kz_ = l1ll11l1_kz_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯࡭ࡵࡩࡸࡱ࡯ࡸ࡭ࡤࡾࡴࡴࡥ࠯ࡲ࡯࠳ࡴࡪࡣࡪࡰ࡮࡭ࡤ࡫࡭ࡣࠩ࣠")
    headers={l1ll11l1_kz_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭࣡"):l1ll11l1_kz_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱࡯ࡷ࡫ࡳ࡬ࡱࡺ࡯ࡦࢀ࡯࡯ࡧ࠱ࡴࡱ࠭࣢"),
            l1ll11l1_kz_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࣣࠪ"):l1ll11l1_kz_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩࣤ"),
            l1ll11l1_kz_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨࣥ"):l1ll11l1_kz_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࣦࠩ"),
            l1ll11l1_kz_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨࣧ"):l1l11l11l11l1_kz_}
    content = l1111l1l11l1_kz_(l1l11llll11l1_kz_,urllib.urlencode({l1ll11l1_kz_ (u"ࠬࡵࠧࣨ"):href}),header=headers)
    src = re.findall(l1ll11l1_kz_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࣩࠫࠥࠫ"),content)
    if src:
        return src[0]
    return l1ll11l1_kz_ (u"ࠧࠨ࣪")
class l1l111lll11l1_kz_:
    @staticmethod
    def l1ll1ll1l11l1_kz_(url=l1ll11l1_kz_ (u"ࠨࠩ࣫")):
        content = l1111l1l11l1_kz_(url)
        l1l11lll11l1_kz_=[]
        l1ll1lll11l1_kz_=[]
        l1ll1111l11l1_kz_ = re.compile(l1ll11l1_kz_ (u"ࠩ࠿ࡥࡷࡺࡩࡤ࡮ࡨࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡷࡺࡩࡤ࡮ࡨࡂࠬ࣬"),re.DOTALL).findall(content)
        for item in l1ll1111l11l1_kz_:
            l11111ll11l1_kz_=re.findall(l1ll11l1_kz_ (u"ࠪࡀ࡭࠹࠾࡝ࡵ࠭ࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳࡷ࠿࠵࠯ࡰࡲࡨࡲࡰࡧࡴࡢ࡮ࡲ࡫࠳ࡩ࡯࡮࠱࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠯ࡄ࠯࠼࠰ࡣࡁ࣭ࠫ"),item)
            year = re.findall(l1ll11l1_kz_ (u"ࠫࡁࡹࡰࡢࡰ࡞ࡢࡃࡣࠪ࠿ࠪ࡟ࡨࢀ࠺ࡽࠪ࠾࠲࣮ࠫ"),item)
            l11ll1ll11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠬࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽࡜ࠤ࡟ࠫࡢ࠮࠮ࠬࡁࠬ࡟ࠧࡢࠧ࡞࣯ࠩ"),item)
            l1lll11l11l1_kz_ = re.findall(l1ll11l1_kz_ (u"࠭࠼ࡴࡲࡤࡲࠥࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡣࡰࡰ࠰ࡷࡹࡧࡲ࠳ࠤࡁࡠࡸ࠰࠼࠰ࡵࡳࡥࡳࡄࠨ࠯࠭ࡂ࠭ࡁ࠵ࡤࡪࡸࡁࣰࠫ"),item,re.DOTALL)
            l1l1111l11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡺࡥࡹࡶࡲࠦࡃ࠮࠮ࠬࡁࠬࡀࣱࠬ"),item,re.DOTALL)
            if l11111ll11l1_kz_:
                href = l11111ll11l1_kz_[0][0]
                title= l11l1l1l11l1_kz_(l11111ll11l1_kz_[0][1])
                l11ll1ll11l1_kz_ = l11ll1ll11l1_kz_[0] if l11ll1ll11l1_kz_ else l1ll11l1_kz_ (u"ࠨࣲࠩ")
                l1lll11l11l1_kz_ = l1lll11l11l1_kz_[0].strip() if l1lll11l11l1_kz_ else l1ll11l1_kz_ (u"ࠩࠪࣳ")
                l1l1llll11l1_kz_={l1ll11l1_kz_ (u"ࠪ࡬ࡷ࡫ࡦࠨࣴ"):href,
                    l1ll11l1_kz_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪࣵ"):title,
                    l1ll11l1_kz_ (u"ࠬ࡯࡭ࡨࣶࠩ"):l11ll1ll11l1_kz_,
                    l1ll11l1_kz_ (u"࠭ࡣࡰࡦࡨࠫࣷ"):l1lll11l11l1_kz_,
                    l1ll11l1_kz_ (u"ࠧࡺࡧࡤࡶࠬࣸ"):year[0] if year else l1ll11l1_kz_ (u"ࠨࣹࠩ"),
                    l1ll11l1_kz_ (u"ࠩࡳࡰࡴࡺࣺࠧ"):l11l1l1l11l1_kz_(l1l1111l11l1_kz_[0]).strip() if l1l1111l11l1_kz_ else l1ll11l1_kz_ (u"ࠪࠫࣻ")
                }
                if l1ll11l1_kz_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡤࡰࡪ࠵ࠧࣼ") in href:
                    l1l11lll11l1_kz_.append(l1l1llll11l1_kz_)
                else:
                    l1ll1lll11l1_kz_.append(l1l1llll11l1_kz_)
        l1l1l1ll11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃ࡛ࠣ࡞ࠪࡡ࠭࡮ࡴࡵࡲࡶ࠾࠴࠵࡯ࡱࡧࡱ࡯ࡦࡺࡡ࡭ࡱࡪ࠲ࡨࡵ࡭࠰࠰࠮ࡃ࠮ࡡࠢ࡝ࠩࡠࡂࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡨࡵ࡮࠮ࡥ࡫ࡩࡻࡸ࡯࡯࠯࡯ࡩ࡫ࡺࠢ࠿ࠩࣽ"),content)
        l1l1l1ll11l1_kz_ = l1l1l1ll11l1_kz_[0] if l1l1l1ll11l1_kz_ else False
        l1ll111ll11l1_kz_ = re.findall(l1ll11l1_kz_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽࡜ࠤ࡟ࠫࡢ࠮ࡨࡵࡶࡳࡷ࠿࠵࠯ࡰࡲࡨࡲࡰࡧࡴࡢ࡮ࡲ࡫࠳ࡩ࡯࡮࠱࠱࠯ࡄ࠯࡛ࠣ࡞ࠪࡡࡃࡂࡳࡱࡣࡱࠤࡨࡲࡡࡴࡵࡀࠦ࡮ࡩ࡯࡯࠯ࡦ࡬ࡪࡼࡲࡰࡰ࠰ࡶ࡮࡭ࡨࡵࠤࡁࠫࣾ"),content)
        l1ll111ll11l1_kz_ = l1ll111ll11l1_kz_[0] if l1ll111ll11l1_kz_ else False
        return l1ll1lll11l1_kz_,l1l11lll11l1_kz_,(l1l1l1ll11l1_kz_,l1ll111ll11l1_kz_)
    @staticmethod
    def l1ll111l11l1_kz_(url=l1ll11l1_kz_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡱࡳࡩࡳࡱࡡࡵࡣ࡯ࡳ࡬࠴ࡣࡰ࡯࠲ࡷࡪࡸࡩࡢ࡮ࡨ࠳ࡲ࡯࡮ࡥࡪࡸࡲࡹ࡫ࡲ࠰ࠩࣿ")):
        if not l1ll11l1_kz_ (u"ࠨࡁࡷࡥࡧࡃࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨऀ") in url:
            url +=l1ll11l1_kz_ (u"ࠩࡂࡸࡦࡨ࠽ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩँ")
        out = []
        content = l1111l1l11l1_kz_(url)
        l1ll1llll11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠪࡀࡺࡲࠠࡤ࡮ࡤࡷࡸࡃࠢࡦࡲ࡬ࡷࡴࡪࡩࡰࡵࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲࠧं"),content,re.DOTALL)
        for l1lllll1l11l1_kz_ in l1ll1llll11l1_kz_:
            l111llll11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠫࡁࡲࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬः"),l1lllll1l11l1_kz_,re.DOTALL)
            for l11l1lll11l1_kz_ in l111llll11l1_kz_:
                l11ll1ll11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠬࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨऄ"),l11l1lll11l1_kz_)
                l111111l11l1_kz_ = re.findall(l1ll11l1_kz_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡳࡻ࡭ࡦࡴࡤࡲࡩࡵࠢ࠿࡞ࡶ࠮࠭ࡢࡤࠬࠫ࡟ࡷ࠯࠳࡜ࡴࠬࠫࡠࡩ࠱ࠩ࡝ࡵ࠭ࡀ࠴ࡪࡩࡷࡀࠪअ"),l11l1lll11l1_kz_)
                l11111ll11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡴࡶࡥ࡯࡭ࡤࡸࡦࡲ࡯ࡨ࠰ࡦࡳࡲ࠵࠮ࠫࡁࠬࠦࡃ࠮࡛࡟࠾ࡠ࠯࠮ࡂ࠯ࡢࡀࠪआ"),l11l1lll11l1_kz_)
                data = re.findall(l1ll11l1_kz_ (u"ࠨ࠾ࡶࡴࡦࡴࠠࡤ࡮ࡤࡷࡸࡃࠢࡥࡣࡷࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬइ"),l11l1lll11l1_kz_)
                if l11111ll11l1_kz_:
                    l1l1lllll11l1_kz_,l1l11l1ll11l1_kz_ = l111111l11l1_kz_[0] if l111111l11l1_kz_ else (l1ll11l1_kz_ (u"ࠩࠪई"),l1ll11l1_kz_ (u"ࠪࠫउ"))
                    l11ll1ll11l1_kz_ = l11ll1ll11l1_kz_[0] if l11ll1ll11l1_kz_ else l1ll11l1_kz_ (u"ࠫࠬऊ")
                    out.append({l1ll11l1_kz_ (u"ࠬ࡮ࡲࡦࡨࠪऋ"):l11111ll11l1_kz_[0][0],l1ll11l1_kz_ (u"࠭ࡴࡪࡶ࡯ࡩࠬऌ"):l11111ll11l1_kz_[0][1],l1ll11l1_kz_ (u"ࠧࡪ࡯ࡪࠫऍ"):l11ll1ll11l1_kz_,
                        l1ll11l1_kz_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࠨऎ"):int(l1l1lllll11l1_kz_),l1ll11l1_kz_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࠪए"):int(l1l11l1ll11l1_kz_)})
        return out
    @staticmethod
    def l1l1lll1l11l1_kz_(out):
        l1l11lll11l1_kz_={}
        l1ll1llll11l1_kz_ = [x.get(l1ll11l1_kz_ (u"ࠪࡷࡪࡧࡳࡰࡰࠪऐ")) for x in out]
        for s in set(l1ll1llll11l1_kz_):
            l1l11lll11l1_kz_[l1ll11l1_kz_ (u"ࠫࡘ࡫ࡺࡰࡰࠣࠩ࠵࠸ࡤࠨऑ")%s]=[out[i] for i, j in enumerate(l1ll1llll11l1_kz_) if j == s]
        return l1l11lll11l1_kz_
    @staticmethod
    def l1l1l1l1l11l1_kz_():
        content = l1111l1l11l1_kz_(l1ll11l1_kz_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡯ࡱࡧࡱ࡯ࡦࡺࡡ࡭ࡱࡪ࠲ࡨࡵ࡭ࠨऒ"))
        stuff = re.compile(l1ll11l1_kz_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡳࡵ࡫࡮࡬ࡣࡷࡥࡱࡵࡧ࠯ࡥࡲࡱ࠴࡭ࡡࡵࡷࡱࡩࡰ࠵࠮ࠬࡁࠬࠦࡡࡹࠪ࡜ࡠࡁࡡ࠯ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࡝࡟ࡷࡡࡴࠠ࡞ࠬ࠿࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡯࠾ࠨओ")).findall(content)
        out=[]
        for l1llll11l11l1_kz_, title, l1l11ll1l11l1_kz_ in stuff:
            out.append({l1ll11l1_kz_ (u"ࠢࡩࡴࡨࡪࠧऔ"):l1llll11l11l1_kz_,l1ll11l1_kz_ (u"ࠣࡶ࡬ࡸࡱ࡫ࠢक"):l1ll11l1_kz_ (u"ࠤࡾࢁࠥ࠮ࡻࡾࠫࠥख").format(title,l1l11ll1l11l1_kz_.replace(l1ll11l1_kz_ (u"ࠪࠪࡳࡨࡳࡱ࠽ࠪग"),l1ll11l1_kz_ (u"ࠫࠬघ")))})
        return out
    @staticmethod
    def l111ll1l11l1_kz_():
        content = l1111l1l11l1_kz_(l1ll11l1_kz_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡯ࡱࡧࡱ࡯ࡦࡺࡡ࡭ࡱࡪ࠲ࡨࡵ࡭ࠨङ"))
        stuff = re.compile(l1ll11l1_kz_ (u"࠭࠼࡭࡫ࡁࡠࡸ࠰࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡳࡵ࡫࡮࡬ࡣࡷࡥࡱࡵࡧ࠯ࡥࡲࡱ࠴ࡸ࡯࡬࠱࠱࠯ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠩच")).findall(content)
        out=[]
        for l1llll11l11l1_kz_, title, in stuff:
            out.append({l1ll11l1_kz_ (u"ࠢࡩࡴࡨࡪࠧछ"):l1llll11l11l1_kz_,l1ll11l1_kz_ (u"ࠣࡶ࡬ࡸࡱ࡫ࠢज"):title})
        return out
    @staticmethod
    def l1ll11ll11l1_kz_(url):
        if not l1ll11l1_kz_ (u"ࠩࡂࡸࡦࡨ࠽ࡷ࡫ࡧࡩࡴࠬࡰ࡭ࡣࡼࡩࡷࡃ࡯ࡱࡶ࡬ࡳࡳ࠭झ") in url:
            url+=l1ll11l1_kz_ (u"ࠪࡃࡹࡧࡢ࠾ࡸ࡬ࡨࡪࡵࠦࡱ࡮ࡤࡽࡪࡸ࠽ࡰࡲࡷ࡭ࡴࡴ࠭࠲ࠩञ")
        content = l1111l1l11l1_kz_(url)
        l1l1l11ll11l1_kz_ = re.compile(l1ll11l1_kz_ (u"ࠫࡁࡻ࡬ࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡲ࡯ࡥࡾ࡫ࡲࡠࡷ࡯ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩट"),re.DOTALL).findall(content)
        l1111lll11l1_kz_=l1ll11l1_kz_ (u"ࠬ࠭ठ")
        l1l1l1lll11l1_kz_=[]
        for l1l1ll1l11l1_kz_ in l1l1l11ll11l1_kz_:
            l111l1ll11l1_kz_ =re.findall(l1ll11l1_kz_ (u"࠭࠼ࡢࠢࡦࡰࡦࡹࡳ࠾ࠤࡤࡧࡹ࡯ࡶࡦࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠪड"),l1l1ll1l11l1_kz_)
            if l111l1ll11l1_kz_ and not l1111lll11l1_kz_:
                l1111lll11l1_kz_ = l111l1ll11l1_kz_[0][1]
            l1l11l1l11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠪढ"),l1l1ll1l11l1_kz_)
            if l1l11l1l11l1_kz_:
                l1l1l1lll11l1_kz_.append({l1ll11l1_kz_ (u"ࠨࡪࡵࡩ࡫࠭ण"):l1l11l1l11l1_kz_[0][0],l1ll11l1_kz_ (u"ࠩࡷ࡭ࡹࡲࡥࠨत"):l1l11l1l11l1_kz_[0][1],l1ll11l1_kz_ (u"ࠪࡶࡪࡹ࡯࡭ࡸࡨࡨࠬथ"):False})
        stuff = re.compile(l1ll11l1_kz_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠭࠴ࠪࡀࠫ࠿࠳࡮࡬ࡲࡢ࡯ࡨࡂࠬद"),re.I).findall(content)
        if stuff:
            src = re.findall(l1ll11l1_kz_ (u"ࠬࡹࡲࡤ࠿࡞ࠦࡡ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠࠫध"),stuff[0],re.I)
            if src:
                l1l1l1lll11l1_kz_.append({l1ll11l1_kz_ (u"࠭ࡨࡳࡧࡩࠫन"):src[0],l1ll11l1_kz_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ऩ"):l1111lll11l1_kz_ if l1111lll11l1_kz_ else l1ll11l1_kz_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲࠨप"),l1ll11l1_kz_ (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫफ"):True})
        return l1l1l1lll11l1_kz_
    @staticmethod
    def l1lll1lll11l1_kz_(url):
        content = l1111l1l11l1_kz_(url)
        stuff = re.compile(l1ll11l1_kz_ (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨࠬ࠳࠰࠿ࠪ࠾࠲࡭࡫ࡸࡡ࡮ࡧࡁࠫब"),re.I).findall(content)
        if stuff:
            src = re.findall(l1ll11l1_kz_ (u"ࠫࡸࡸࡣ࠾࡝ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟ࠪभ"),stuff[0],re.I)
            if src:
                return src[0] if src else l1ll11l1_kz_ (u"ࠬ࠭म")
        return l1ll11l1_kz_ (u"࠭ࠧय")
class l1lll11ll11l1_kz_:
    def l1llll1ll11l1_kz_(self,url):
        if not url:
            url = l1ll11l1_kz_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡫ࡤࡲࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࠬर")
        elif url.startswith(l1ll11l1_kz_ (u"ࠨ࠱࠲ࠫऱ")):
            url = l1ll11l1_kz_ (u"ࠩ࡫ࡸࡹࡶࠧल")+url
        elif url.startswith(l1ll11l1_kz_ (u"ࠪ࠳ࠬळ")):
            url = urljoin(l1ll11l1_kz_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩऴ"),url)
        return url
    @staticmethod
    def l1ll1ll1l11l1_kz_(url=l1ll11l1_kz_ (u"ࠬ࠭व")):
        if not url:
            url = l1ll11l1_kz_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡪࡣࡱࡩ࡭ࡱࡳ࠮ࡱ࡮࠲ࠫश")
        elif url.startswith(l1ll11l1_kz_ (u"ࠧ࠰ࠩष")):
            url = urljoin(l1ll11l1_kz_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡬ࡥࡳ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭स"),url)
        content = l1111l1l11l1_kz_(url)
        out=[]
        l111l11l11l1_kz_ = re.compile(l1ll11l1_kz_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡪࡴࡴ࠮ࡩࡵ࡭ࡩࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬह"),re.DOTALL).findall(content)
        for show in l111l11l11l1_kz_:
            l11ll11l11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠯ࡴࡧࡵ࡭ࡦࡲࡥ࠰࠰࠭࠭ࠧࡄ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩऺ"),show)
            if l11ll11l11l1_kz_:
                l11ll1ll11l1_kz_ = l11ll11l11l1_kz_[0][1]
                l11ll1ll11l1_kz_ = urljoin(l1ll11l1_kz_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩऻ"),l11ll1ll11l1_kz_) if not l11ll1ll11l1_kz_.startswith(l1ll11l1_kz_ (u"ࠬ࡮ࡴࡵࡲ़ࠪ")) else l11ll1ll11l1_kz_
                title = l11ll11l11l1_kz_[0][0].replace(l1ll11l1_kz_ (u"࠭࠯ࡴࡧࡵ࡭ࡦࡲࡥ࠰ࠩऽ"),l1ll11l1_kz_ (u"ࠧࠨा")).replace(l1ll11l1_kz_ (u"ࠨ࠯ࠪि"),l1ll11l1_kz_ (u"ࠩࠣࠫी")).replace(l1ll11l1_kz_ (u"ࠪ࠳ࠬु"),l1ll11l1_kz_ (u"ࠫࠬू")).title()
                out.append({l1ll11l1_kz_ (u"ࠬ࡮ࡲࡦࡨࠪृ"):l11ll11l11l1_kz_[0][0],l1ll11l1_kz_ (u"࠭ࡴࡪࡶ࡯ࡩࠬॄ"):title,l1ll11l1_kz_ (u"ࠧࡪ࡯ࡪࠫॅ"):l11ll1ll11l1_kz_})
        idx = content.find(l1ll11l1_kz_ (u"ࠨࡪ࠶ࡂࡘ࡫ࡲࡪࡣ࡯ࡩࡁ࠵ࡨ࠴ࡀࠪॆ"))
        if idx:
            l1l111l1l11l1_kz_ = re.compile(l1ll11l1_kz_ (u"ࠩ࠿ࡹࡱࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪे"),re.DOTALL).search(content[idx:-1])
            l1l111l1l11l1_kz_ = l1l111l1l11l1_kz_.group(1) if l1l111l1l11l1_kz_ else l1ll11l1_kz_ (u"ࠪࠫै")
            l1l111l1l11l1_kz_ = re.sub(l1ll11l1_kz_ (u"ࡶࠧࡂࠡ࠮࠯ࠫ࠲ࢁࡢࡳࡽ࡞ࡱ࠭࠯ࡅ࠭࠮ࡀࠥॉ"), l1ll11l1_kz_ (u"ࠧࠨॊ"), l1l111l1l11l1_kz_)
            l1l1l111l11l1_kz_ = re.compile(l1ll11l1_kz_ (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠯ࡴࡧࡵ࡭ࡦࡲࡥ࠰࠰࠭ࡃ࠮ࠨ࠾ࠩ࡝ࡡࡂࡢ࠰ࠩ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠪो")).findall(l1l111l1l11l1_kz_)
            for href,title in l1l1l111l11l1_kz_:
                out.append({l1ll11l1_kz_ (u"ࠧࡩࡴࡨࡪࠬौ"):href,l1ll11l1_kz_ (u"ࠨࡶ࡬ࡸࡱ࡫्ࠧ"):title})
        return out
    @staticmethod
    def l1ll11l1l11l1_kz_(url=l1ll11l1_kz_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡭ࡦࡴ࡬ࡩ࡭࡯࠱ࡴࡱ࠵ࡳࡦࡴ࡬ࡥࡱ࡫࠯ࡥࡧࡷࡩࡰࡺࡹࡸ࠱ࠪॎ")):
        if not url:
            url = l1ll11l1_kz_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡮ࡧࡵࡦࡪ࡮ࡰ࠲ࡵࡲ࠯ࠨॏ")
        if url.startswith(l1ll11l1_kz_ (u"ࠫ࠴࠵ࠧॐ")):
            url = l1ll11l1_kz_ (u"ࠬ࡮ࡴࡵࡲࠪ॑")+url
        if url.startswith(l1ll11l1_kz_ (u"࠭࠯ࠨ॒")):
            url = urljoin(l1ll11l1_kz_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡫ࡤࡲࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࠬ॓"),url)
        url += l1ll11l1_kz_ (u"ࠨ࠱ࠪ॔") if not url.endswith(l1ll11l1_kz_ (u"ࠩ࠲ࠫॕ")) else l1ll11l1_kz_ (u"ࠪࠫॖ")
        content = l1111l1l11l1_kz_(url)
        out=[]
        l1l11l1_kz_ = re.compile(l1ll11l1_kz_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶ࠰࡫ࡷ࡯ࡤࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧॗ"),re.DOTALL).findall(content)
        for l1l111ll11l1_kz_ in l1l11l1_kz_:
            l1l1lllll11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠬࡹࡥࡻࡱࡱࡠࡸ࠰ࠨ࡝ࡦ࠮࠭ࠬक़"),l1l111ll11l1_kz_,re.I)
            l1l1lllll11l1_kz_ = l1l1lllll11l1_kz_[0] if l1l1lllll11l1_kz_ else l1ll11l1_kz_ (u"࠭ࠧख़")
            l1l11l1ll11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠧࡐࡦࡦ࡭ࡳ࡫࡫࡝ࡵ࠭ࠬࡡࡪࠫࠪࠩग़"),l1l111ll11l1_kz_,re.I)
            l1l11l1ll11l1_kz_ = l1l11l1ll11l1_kz_[0] if l1l11l1ll11l1_kz_ else l1ll11l1_kz_ (u"ࠨࠩज़")
            href = re.compile(l1ll11l1_kz_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭ࡹࡩ࡯ࡩ࡯ࡩࡵࡧࡧࡦ࠰ࡳ࡬ࡵࡢ࠿ࡪࡦࡀࡠࡩ࠱ࠩࠣࠩड़")).findall(l1l111ll11l1_kz_)
            l11ll1ll11l1_kz_ = re.findall(l1ll11l1_kz_ (u"ࠪࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ढ़"),l1l111ll11l1_kz_)
            if href and l1l1lllll11l1_kz_ and l1l11l1ll11l1_kz_:
                l11ll1ll11l1_kz_ = urljoin(l1ll11l1_kz_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩफ़"),l11ll1ll11l1_kz_[0]) if not l11ll1ll11l1_kz_[0].startswith(l1ll11l1_kz_ (u"ࠬ࡮ࡴࡵࡲࠪय़")) else l1ll11l1_kz_ (u"࠭ࠧॠ")
                out.append({l1ll11l1_kz_ (u"ࠧࡩࡴࡨࡪࠬॡ"):url+href[0],l1ll11l1_kz_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧॢ"):l1ll11l1_kz_ (u"ࠩࡖࡩࡿࡵ࡮ࠡࠧࡶ࠰ࠥࡋࡰࡪࡼࡲࡨࠥࠫࡳࠨॣ")%(l1l1lllll11l1_kz_,l1l11l1ll11l1_kz_),l1ll11l1_kz_ (u"ࠪ࡭ࡲ࡭ࠧ।"):l11ll1ll11l1_kz_,
                l1ll11l1_kz_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࠫ॥"):int(l1l1lllll11l1_kz_),l1ll11l1_kz_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪ࠭०"):int(l1l11l1ll11l1_kz_)})
        return out
