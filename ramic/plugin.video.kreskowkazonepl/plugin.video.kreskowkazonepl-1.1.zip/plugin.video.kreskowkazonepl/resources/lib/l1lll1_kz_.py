# -*- coding: utf-8 -*-
import sys
l1l1ll1_kz_ = sys.version_info [0] == 2
l1l1l1l1_kz_ = 2048
l11lll1_kz_ = 7
def l1ll1_kz_ (keyedStringLiteral):
	global l111l1l1_kz_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l1ll1_kz_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l1l1l1_kz_ - (charIndex + stringNr) % l11lll1_kz_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l1l1l1_kz_ - (charIndex + stringNr) % l11lll1_kz_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import ramic as l11l1l1ll1_kz_
l111ll1ll1_kz_        = sys.argv[0]
l11111lll1_kz_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l1ll1l1l1l1_kz_        = xbmcaddon.Addon()
l1ll1l11ll1_kz_     = l1ll1l1l1l1_kz_.getAddonInfo(l1ll1_kz_ (u"࠭ࡩࡥࠩ१"))
l11llll1l1_kz_       = l1ll1l1l1l1_kz_.getAddonInfo(l1ll1_kz_ (u"ࠧ࡯ࡣࡰࡩࠬ२"))
PATH        = l1ll1l1l1l1_kz_.getAddonInfo(l1ll1_kz_ (u"ࠨࡲࡤࡸ࡭࠭३")).decode(l1ll1_kz_ (u"ࠩࡸࡸ࡫࠳࠸ࠨ४"))
l11ll11ll1_kz_    = xbmc.translatePath(l1ll1l1l1l1_kz_.getAddonInfo(l1ll1_kz_ (u"ࠪࡴࡷࡵࡦࡪ࡮ࡨࠫ५"))).decode(l1ll1_kz_ (u"ࠫࡺࡺࡦ࠮࠺ࠪ६"))
l1lll1llll1_kz_   = PATH+l1ll1_kz_ (u"ࠬ࠵ࡲࡦࡵࡲࡹࡷࡩࡥࡴ࠱ࠪ७")
l1lll111ll1_kz_=l1lll1llll1_kz_+l1ll1_kz_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠴ࡰ࡯ࡩࠪ८")
sys.path.append(l1lll1llll1_kz_+l1ll1_kz_ (u"ࠧ࡭࡫ࡥ࠳ࠬ९"))
l1l1111ll1_kz_ = urllib2.urlopen
l111l1l1l1_kz_ = urllib2.Request
l1lll1l1_kz_ = xbmcgui.Dialog()
import time,threading
l11l1llll1_kz_ = lambda x,y: ord(x)+20*y if ord(x)%2 else ord(x)
l1ll11ll1l1_kz_ = lambda l11l1ll1l1_kz_: l1ll1_kz_ (u"ࠨࠩ॰").join([chr(l11l1llll1_kz_(x,1) ) for x in l11l1ll1l1_kz_.encode(l1ll1_kz_ (u"ࠩࡥࡥࡸ࡫࠶࠵ࠩॱ")).strip()])
l11lll1ll1_kz_ = lambda l11l1ll1l1_kz_: l1ll11ll1l1_kz_(l11l1ll1l1_kz_).encode(l1ll1_kz_ (u"ࠪ࡬ࡪࡾࠧॲ"))
l111l11ll1_kz_ = lambda l11l1ll1l1_kz_: l1ll1_kz_ (u"ࠫࠬॳ").join([chr(l11l1llll1_kz_(x,-1) ) for x in l11l1ll1l1_kz_]).decode(l1ll1_kz_ (u"ࠬࡨࡡࡴࡧ࠹࠸ࠬॴ"))
l1ll11llll1_kz_ = lambda l11l1ll1l1_kz_: l111l11ll1_kz_(l11l1ll1l1_kz_.decode(l1ll1_kz_ (u"࠭ࡨࡦࡺࠪॵ")))
import l11l11ll1_kz_ as l11l111ll1_kz_
l11l111ll1_kz_.l1ll1l1ll1_kz_=os.path.join(l11ll11ll1_kz_,l1ll1_kz_ (u"ࠧࡤࡱࡲ࡯࡮࡫ࠧॶ"))
if not os.path.exists(l1ll1_kz_ (u"ࠨ࠱࡫ࡳࡲ࡫࠯ࡰࡵࡰࡧࠬॷ")):
    tm=time.gmtime()
    try:    l111ll11l1_kz_,l1llllll1l1_kz_,l111lll1l1_kz_ = l1ll11llll1_kz_(l1ll1l1l1l1_kz_.getSetting(l1ll1_kz_ (u"ࠩ࡮ࡳࡩ࠭ॸ"))).split(l1ll1_kz_ (u"ࠪ࠾ࠬॹ"))
    except: l111ll11l1_kz_,l1llllll1l1_kz_,l111lll1l1_kz_ =  [l1ll1_kz_ (u"ࠫ࠲࠷ࠧॺ"),l1ll1_kz_ (u"ࠬ࠭ॻ"),l1ll1_kz_ (u"࠭࠭࠲ࠩॼ")]
    if int(l111ll11l1_kz_) != tm.tm_hour:
        try:    l111111ll1_kz_ = re.findall(l1ll1_kz_ (u"ࠧࡌࡑࡇ࠾ࠥ࠮࠮ࠫࡁࠬࡠࡳ࠭ॽ"),l1l1111ll1_kz_(l1ll1_kz_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡹࡧࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳ࠯ࡳࡣࡰ࡭ࡨࡹࡰࡢ࠱࡮ࡳࡩ࡯࠯࡮ࡣࡶࡸࡪࡸ࠯ࡓࡇࡄࡈࡒࡋ࠮࡮ࡦࠪॾ")).read())[0].strip(l1ll1_kz_ (u"ࠩ࠭ࠫॿ"))
        except: l111111ll1_kz_ = l1ll1_kz_ (u"ࠪࠫঀ")
        l1111l1ll1_kz_ = l11lll1ll1_kz_(l1ll1_kz_ (u"ࠬࠫࡤ࠻ࠧࡶ࠾ࠪࡪࠧউ")%(tm.tm_hour,l111111ll1_kz_,tm.tm_min))
        l1ll1l1l1l1_kz_.setSetting(l1ll1_kz_ (u"࠭࡫ࡰࡦࠪঊ"),l1111l1ll1_kz_)
def l1llllllll1_kz_(name, url, mode, l11111l1_kz_=1, l11l11l1l1_kz_=l1ll1_kz_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫঋ"), infoLabels={}, IsPlayable=True, fanart=l1lll111ll1_kz_,l1111llll1_kz_=1):
    u = l11ll1lll1_kz_({l1ll1_kz_ (u"ࠨ࡯ࡲࡨࡪ࠭ঌ"): mode, l1ll1_kz_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭঍"): name, l1ll1_kz_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫ঎") : url, l1ll1_kz_ (u"ࠫࡵࡧࡧࡦࠩএ"):l11111l1_kz_,l1ll1_kz_ (u"ࠬࡳࡩ࡯ࡨࡲࠫঐ"):str(infoLabels)})
    isFolder = infoLabels.get(l1ll1_kz_ (u"࠭ࡩࡴࡈࡲࡰࡩ࡫ࡲࠨ঑"),False)
    if isFolder and infoLabels.get(l1ll1_kz_ (u"ࠧࡺࡧࡤࡶࠬ঒"),False):
        name += l1ll1_kz_ (u"ࠨࠢࠫࠩࡸ࠯ࠧও")%infoLabels.get(l1ll1_kz_ (u"ࠩࡼࡩࡦࡸࠧঔ"))
    l1111ll1l1_kz_ = xbmcgui.ListItem(name)
    l11lll11l1_kz_=[l1ll1_kz_ (u"ࠪࡸ࡭ࡻ࡭ࡣࠩক"),l1ll1_kz_ (u"ࠫࡵࡵࡳࡵࡧࡵࠫখ"),l1ll1_kz_ (u"ࠬࡨࡡ࡯ࡰࡨࡶࠬগ"),l1ll1_kz_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠭ঘ"),l1ll1_kz_ (u"ࠧࡤ࡮ࡨࡥࡷࡧࡲࡵࠩঙ"),l1ll1_kz_ (u"ࠨࡥ࡯ࡩࡦࡸ࡬ࡰࡩࡲࠫচ"),l1ll1_kz_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬছ"),l1ll1_kz_ (u"ࠪ࡭ࡨࡵ࡮ࠨজ")]
    l11llllll1_kz_ = dict(zip(l11lll11l1_kz_,[infoLabels.get(x,l11l11l1l1_kz_) for x in l11lll11l1_kz_]))
    l11llllll1_kz_[l1ll1_kz_ (u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫ࠧঝ")] = fanart if fanart else l11llllll1_kz_[l1ll1_kz_ (u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨঞ")]
    l1111ll1l1_kz_.setArt(l11llllll1_kz_)
    l1111ll1l1_kz_.setInfo(type=l1ll1_kz_ (u"ࠨࡶࡪࡦࡨࡳࠧট"), infoLabels=infoLabels)
    if IsPlayable and not isFolder:
        l1111ll1l1_kz_.setProperty(l1ll1_kz_ (u"ࠧࡊࡵࡓࡰࡦࡿࡡࡣ࡮ࡨࠫঠ"), l1ll1_kz_ (u"ࠨࡶࡵࡹࡪ࠭ড"))
    ok = xbmcplugin.addDirectoryItem(handle=l11111lll1_kz_, url=u, listitem=l1111ll1l1_kz_,isFolder=isFolder,totalItems=l1111llll1_kz_)
    xbmcplugin.addSortMethod(l11111lll1_kz_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1ll1_kz_ (u"ࠤࠨࡖ࠱࡚ࠦࠥ࠮ࠣࠩࡕࠨঢ"))
    return ok
def l111l1lll1_kz_(name,ex_link=None, l11111l1_kz_=1, mode=l1ll1_kz_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪণ"),iconImage=l1ll1_kz_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠨত"), infoLabels={}, fanart=l1lll111ll1_kz_,contextmenu=None):
    url = l11ll1lll1_kz_({l1ll1_kz_ (u"ࠬࡳ࡯ࡥࡧࠪথ"): mode, l1ll1_kz_ (u"࠭ࡦࡰ࡮ࡧࡩࡷࡴࡡ࡮ࡧࠪদ"): name, l1ll1_kz_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨধ") : ex_link, l1ll1_kz_ (u"ࠨࡲࡤ࡫ࡪ࠭ন") : l11111l1_kz_})
    l11l1lll1_kz_ = xbmcgui.ListItem(name)
    if infoLabels:
        l11l1lll1_kz_.setInfo(type=l1ll1_kz_ (u"ࠤࡹ࡭ࡩ࡫࡯ࠣ঩"), infoLabels=infoLabels)
    l11lll11l1_kz_=[l1ll1_kz_ (u"ࠪࡸ࡭ࡻ࡭ࡣࠩপ"),l1ll1_kz_ (u"ࠫࡵࡵࡳࡵࡧࡵࠫফ"),l1ll1_kz_ (u"ࠬࡨࡡ࡯ࡰࡨࡶࠬব"),l1ll1_kz_ (u"࠭ࡣ࡭ࡧࡤࡶࡦࡸࡴࠨভ"),l1ll1_kz_ (u"ࠧࡤ࡮ࡨࡥࡷࡲ࡯ࡨࡱࠪম"),l1ll1_kz_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫয"),l1ll1_kz_ (u"ࠩ࡬ࡧࡴࡴࠧর")]
    l11llllll1_kz_ = dict(zip(l11lll11l1_kz_,[infoLabels.get(x,iconImage) for x in l11lll11l1_kz_]))
    l11llllll1_kz_[l1ll1_kz_ (u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭঱")] = fanart if fanart else l11llllll1_kz_[l1ll1_kz_ (u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫ࠧল")]
    l11l1lll1_kz_.setArt(l11llllll1_kz_)
    if contextmenu:
        l11l1111l1_kz_=contextmenu
        l11l1lll1_kz_.addContextMenuItems(l11l1111l1_kz_, replaceItems=True)
    else:
        l11l1111l1_kz_ = []
        l11l1111l1_kz_.append((l1ll1_kz_ (u"ࠬࡏ࡮ࡧࡱࡵࡱࡦࡩࡪࡢࠩ঳"), l1ll1_kz_ (u"࠭ࡘࡃࡏࡆ࠲ࡆࡩࡴࡪࡱࡱࠬࡎࡴࡦࡰࠫࠪ঴")),)
        l11l1lll1_kz_.addContextMenuItems(l11l1111l1_kz_, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=l11111lll1_kz_, url=url,listitem=l11l1lll1_kz_, isFolder=True)
    xbmcplugin.addSortMethod(l11111lll1_kz_, sortMethod=xbmcplugin.SORT_METHOD_TITLE, label2Mask = l1ll1_kz_ (u"ࠢࠦࡔ࠯ࠤࠪ࡟ࠬࠡࠧࡓࠦ঵"))
def l1111111l1_kz_(name, url=l1ll1_kz_ (u"ࠨࠩশ"), mode=l1ll1_kz_ (u"ࠩࠪষ"), l11l11l1l1_kz_=None, fanart=l1lll111ll1_kz_):
    u = l11ll1lll1_kz_({l1ll1_kz_ (u"ࠪࡱࡴࡪࡥࠨস"): mode, l1ll1_kz_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨহ"): name, l1ll1_kz_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭঺") : url, l1ll1_kz_ (u"࠭ࡰࡢࡩࡨࠫ঻"):1})
    l1111ll1l1_kz_ = xbmcgui.ListItem(name, iconImage=l11l11l1l1_kz_, thumbnailImage=l11l11l1l1_kz_)
    l1111ll1l1_kz_.setProperty(l1ll1_kz_ (u"ࠧࡊࡵࡓࡰࡦࡿࡡࡣ࡮ࡨ়ࠫ"), l1ll1_kz_ (u"ࠨࡨࡤࡰࡸ࡫ࠧঽ"))
    if fanart:
        l1111ll1l1_kz_.setProperty(l1ll1_kz_ (u"ࠩࡩࡥࡳࡧࡲࡵࡡ࡬ࡱࡦ࡭ࡥࠨা"),fanart)
    ok = xbmcplugin.addDirectoryItem(handle=l11111lll1_kz_, url=u, listitem=l1111ll1l1_kz_,isFolder=False)
    return ok
def l111lllll1_kz_(l1ll1l1lll1_kz_):
    l1llll111l1_kz_ = {}
    for k, v in l1ll1l1lll1_kz_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l1ll1_kz_ (u"ࠪࡹࡹ࡬࠸ࠨি"))
        elif isinstance(v, str):
            v.decode(l1ll1_kz_ (u"ࠫࡺࡺࡦ࠹ࠩী"))
        l1llll111l1_kz_[k] = v
    return l1llll111l1_kz_
def l11ll1lll1_kz_(query):
    return l111ll1ll1_kz_ + l1ll1_kz_ (u"ࠬࡅࠧু") + urllib.urlencode(l111lllll1_kz_(query))
def l1llll1lll1_kz_():
    try: debug=1
    except:pass
class l1lll1_kz_():
    @staticmethod
    def root():
        l1llll1lll1_kz_()
        l111l1lll1_kz_(name=l1ll1_kz_ (u"࠭ࡉ࡯ࡨࡲࡶࡲࡧࡣ࡫ࡣࠪূ"),mode=l1ll1_kz_ (u"ࠧࡠ࡫ࡱࡪࡴࡥࠧৃ"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1ll1_kz_ (u"ࠨࡲࡤࡸ࡭࠭ৄ")))+l1ll1_kz_ (u"ࠩ࠲࡭ࡨࡵ࡮࠯ࡲࡱ࡫ࠬ৅"),infoLabels={})
        l111l1lll1_kz_(name=l1ll1_kz_ (u"ࠪࡔࡴࡶࡵ࡭ࡣࡵࡲࡪࠦࡆࡪ࡮ࡰࡽࠬ৆"),mode=l1ll1_kz_ (u"ࠫࡵࡵࡰࡶ࡮ࡤࡶࡳ࡫ࠧে"),ex_link=l1ll1_kz_ (u"ࠬࡌࡩ࡭࡯ࡼࠫৈ"))
        l111l1lll1_kz_(name=l1ll1_kz_ (u"࠭ࡐࡰࡲࡸࡰࡦࡸ࡮ࡦࠢࡎࡶࡪࡹ࡫ࣴࡹ࡮࡭ࠬ৉"),mode=l1ll1_kz_ (u"ࠧࡱࡱࡳࡹࡱࡧࡲ࡯ࡧࠪ৊"),ex_link=l1ll1_kz_ (u"ࠨࡍࡵࡩࡸࡱࣳࡸ࡭࡬ࠫো"))
        l111l1lll1_kz_(name=l1ll1_kz_ (u"ࠩࡏ࡭ࡸࡺࡡࠡࡈ࡬ࡰࡲࣹࡷࠨৌ"),mode=l1ll1_kz_ (u"ࠪࡰ࡮ࡹࡴࡢ࠼ࡩ࡭ࡱࡳ࡯ࡸ্ࠩ"),ex_link=l1ll1_kz_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯࡭ࡵࡩࡸࡱ࡯ࡸ࡭ࡤࡾࡴࡴࡥ࠯ࡲ࡯࠳ࡱ࡯ࡳࡵࡣࡢࡪ࡮ࡲ࡭ࡰࡹ࠰ࠫৎ"))
        l111l1lll1_kz_(name=l1ll1_kz_ (u"ࠬࡒࡩࡴࡶࡤࠤࡐࡸࡥࡴ࡭ࣶࡻࡪࡱࠧ৏"),mode=l1ll1_kz_ (u"࠭࡬ࡪࡵࡷࡥ࠿ࡱࡲࡦࡵ࡮ࡳࡼ࡫࡫ࠨ৐"),ex_link=l1ll1_kz_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡰࡸࡥࡴ࡭ࡲࡻࡰࡧࡺࡰࡰࡨ࠲ࡵࡲ࠯࡭࡫ࡶࡸࡦࡥࡡ࡯࡫ࡰࡩ࠲࠭৑"))
        l111l1lll1_kz_(name=l1ll1_kz_ (u"ࠨࡎ࡬ࡷࡹࡧࠠࡔࡧࡵ࡭ࡦࡲࡩࠨ৒"),mode=l1ll1_kz_ (u"ࠩ࡯࡭ࡸࡺࡡ࠻ࡵࡨࡶ࡮ࡧ࡬ࡦࠩ৓"),ex_link=l1ll1_kz_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮࡬ࡴࡨࡷࡰࡵࡷ࡬ࡣࡽࡳࡳ࡫࠮ࡱ࡮࠲ࡷࡪࡸࡩࡢ࡮ࡨ࠱ࠬ৔"))
        l111l1lll1_kz_(name=l1ll1_kz_ (u"ࠫ࡜ࡿࡣࡩࡱࡧࡾऊࡩࡥࠡ࡭ࡵࡩࡸࡱࣳࡸ࡭࡬ࠫ৕"),mode=l1ll1_kz_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭৖"),ex_link=l1ll1_kz_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱࡯ࡷ࡫ࡳ࡬ࡱࡺ࡯ࡦࢀ࡯࡯ࡧ࠱ࡴࡱ࠵ࡷࡺࡥ࡫ࡳࡩࢀࡡࡤࡧࠪৗ"))
        l111l1lll1_kz_(name=l1ll1_kz_ (u"ࠧࡘࡻࡦ࡬ࡴࡪࡺआࡥࡨࠤࡸ࡫ࡲࡪࡣ࡯ࡩࠬ৘"),mode=l1ll1_kz_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩ৙"),ex_link=l1ll1_kz_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴࡫ࡳࡧࡶ࡯ࡴࡽ࡫ࡢࡼࡲࡲࡪ࠴ࡰ࡭࠱ࡺࡽࡨ࡮࡯ࡥࡼࡤࡧࡪ࠳ࡳࡦࡴ࡬ࡥࡱ࡫ࠧ৚"))
        l111l1lll1_kz_(name=l1ll1_kz_ (u"ࠪࡗࡿࡻ࡫ࡢ࡬ࠪ৛"),mode=l1ll1_kz_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫড়"),ex_link=None)
        xbmcplugin.endOfDirectory(l11111lll1_kz_)
    @staticmethod
    def l1l111l1_kz_(mode,ex_link):
        l11l11lll1_kz_,l11lllll1_kz_ = mode.split(l1ll1_kz_ (u"ࠬࡀࠧঢ়"))
        l1lll1l1ll1_kz_ = l1ll1l1l1l1_kz_.getSetting(l11lllll1_kz_+l1ll1_kz_ (u"࠭ࡖࠨ৞"))
        l1ll1l111l1_kz_ = l1ll1l1l1l1_kz_.getSetting(l11lllll1_kz_+l1ll1_kz_ (u"ࠧࡏࠩয়")) if l1lll1l1ll1_kz_ else l1ll1_kz_ (u"ࠨ࠲ࠪৠ")
        ex_link += l1lll1l1ll1_kz_ if l1lll1l1ll1_kz_ else l1ll1_kz_ (u"ࠩ࠳ࠫৡ")
        l1ll1lll1_kz_ = l11l111ll1_kz_.l1ll1ll1l1_kz_(ex_link)
        l1llllllll1_kz_(l1ll1_kz_ (u"ࠥ࡟ࡈࡕࡌࡐࡔࠣࡰ࡮࡭ࡨࡵࡤ࡯ࡹࡪࡣࡎࡢࠢࡏ࡭ࡹ࡫ࡲच࠼࡞࠳ࡈࡕࡌࡐࡔࡠࠤࡠࡈ࡝ࠦࡵ࡞࠳ࡇࡣࠢৢ")%l1ll1l111l1_kz_,l1ll1_kz_ (u"ࠫࠬৣ"),mode=l1ll1_kz_ (u"ࠬࡹࡥࡵࡈ࡬ࡰࡹࡸ࠺ࠨ৤")+l11lllll1_kz_,l11l11l1l1_kz_=l1ll1_kz_ (u"࠭ࠧ৥"),IsPlayable=False)
        for f in l1ll1lll1_kz_:
            l111l1lll1_kz_(name=f.get(l1ll1_kz_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭০")), ex_link=f.get(l1ll1_kz_ (u"ࠨࡪࡵࡩ࡫࠭১")), mode=l1ll1_kz_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ২"), iconImage=f.get(l1ll1_kz_ (u"ࠪ࡭ࡲ࡭ࠧ৩")), infoLabels=f)
        xbmcplugin.setContent(l11111lll1_kz_, l1ll1_kz_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ৪"))
        xbmcplugin.endOfDirectory(l11111lll1_kz_)
    @staticmethod
    def l11llll1_kz_(mode):
        _1111l11l1_kz_ = mode.split(l1ll1_kz_ (u"ࠧࡀࠢ৫"))[-1]
        label=[l1ll1_kz_ (u"࠭࠰ࠨ৬"),l1ll1_kz_ (u"ࠧࡂࠩ৭"), l1ll1_kz_ (u"ࠨࡄࠪ৮"), l1ll1_kz_ (u"ࠩࡆࠫ৯"), l1ll1_kz_ (u"ࠪࡈࠬৰ"), l1ll1_kz_ (u"ࠫࡊ࠭ৱ"), l1ll1_kz_ (u"ࠬࡌࠧ৲"), l1ll1_kz_ (u"࠭ࡇࠨ৳"), l1ll1_kz_ (u"ࠧࡉࠩ৴"), l1ll1_kz_ (u"ࠨࡋࠪ৵"), l1ll1_kz_ (u"ࠩࡍࠫ৶"), l1ll1_kz_ (u"ࠪࡏࠬ৷"), l1ll1_kz_ (u"ࠫࡑ࠭৸"), l1ll1_kz_ (u"ࠬࡓࠧ৹"), l1ll1_kz_ (u"࠭ࡎࠨ৺"), l1ll1_kz_ (u"ࠧࡐࠩ৻"), l1ll1_kz_ (u"ࠨࡒࠪৼ"), l1ll1_kz_ (u"ࠩࡔࠫ৽"), l1ll1_kz_ (u"ࠪࡖࠬ৾"), l1ll1_kz_ (u"ࠫࡘ࠭৿"), l1ll1_kz_ (u"࡚ࠬࠧ਀"), l1ll1_kz_ (u"࠭ࡕࠨਁ"), l1ll1_kz_ (u"ࠧࡗࠩਂ"), l1ll1_kz_ (u"ࠨ࡙ࠪਃ"), l1ll1_kz_ (u"࡛ࠩࠫ਄"), l1ll1_kz_ (u"ࠪ࡝ࠬਅ"), l1ll1_kz_ (u"ࠫ࡟࠭ਆ")]
        value=label
        s = xbmcgui.Dialog().select(l1ll1_kz_ (u"ࠬ࡝ࡹࡣ࡫ࡨࡶࡿࠦࡌࡪࡶࡨࡶञ࠭ਇ"),label)
        s = s if s>-1 else 0
        l1ll1l1l1l1_kz_.setSetting(_1111l11l1_kz_+l1ll1_kz_ (u"࠭ࡖࠨਈ"),value[s])
        l1ll1l1l1l1_kz_.setSetting(_1111l11l1_kz_+l1ll1_kz_ (u"ࠧࡏࠩਉ"),label[s])
        xbmc.executebuiltin(l1ll1_kz_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠫ࠭ࠬਊ"))
    @staticmethod
    def info():
        l11l1l1ll1_kz_.__myinfo__.go(sys.argv)
        xbmcplugin.endOfDirectory(l11111lll1_kz_)
    @staticmethod
    def l1l11ll1_kz_(ex_link):
        l1ll1lll1_kz_ = l11l111ll1_kz_.l1l1ll1ll1_kz_(ex_link)
        for f in l1ll1lll1_kz_:
            l111l1lll1_kz_(name=f.get(l1ll1_kz_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ਋")), ex_link=f.get(l1ll1_kz_ (u"ࠪ࡬ࡷ࡫ࡦࠨ਌")), mode=l1ll1_kz_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭਍"), iconImage=f.get(l1ll1_kz_ (u"ࠬ࡯࡭ࡨࠩ਎"),l1ll1_kz_ (u"࠭ࠧਏ")), infoLabels=f)
        xbmcplugin.addSortMethod( handle=l11111lll1_kz_, sortMethod=xbmcplugin.SORT_METHOD_TITLE )
        xbmcplugin.setContent(l11111lll1_kz_, l1ll1_kz_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧਐ"))
        xbmcplugin.endOfDirectory(l11111lll1_kz_)
    @staticmethod
    def content(ex_link):
        l1ll1lll1_kz_ = l11l111ll1_kz_.l1ll1ll1l1_kz_(ex_link)
        l1llll11ll1_kz_=l1ll1_kz_ (u"ࠨࡡࡢࡴࡦ࡭ࡥࡠࡡ࠽ࡧࡴࡴࡴࡦࡰࡷࠫ਑")
        for f in l1ll1lll1_kz_:
            l111l1lll1_kz_(name=f.get(l1ll1_kz_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ਒")), ex_link=f.get(l1ll1_kz_ (u"ࠪ࡬ࡷ࡫ࡦࠨਓ")), mode=l1ll1_kz_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭ਔ"), iconImage=f.get(l1ll1_kz_ (u"ࠬ࡯࡭ࡨࠩਕ")), infoLabels=f)
        xbmcplugin.addSortMethod( handle=l11111lll1_kz_, sortMethod=xbmcplugin.SORT_METHOD_TITLE )
        xbmcplugin.setContent(l11111lll1_kz_, l1ll1_kz_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭ਖ"))
        xbmcplugin.endOfDirectory(l11111lll1_kz_)
    @staticmethod
    def l1l1_kz_(ex_link):
        l1l1_kz_ = l11l111ll1_kz_.l11l111l1_kz_(ex_link)
        for f in l1l1_kz_:
            l1llllllll1_kz_(name=f.get(l1ll1_kz_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ਗ")), url=f.get(l1ll1_kz_ (u"ࠨࡪࡵࡩ࡫࠭ਘ")), mode=l1ll1_kz_ (u"ࠩࡪࡩࡹࡒࡩ࡯࡭ࡶࠫਙ"), l11l11l1l1_kz_=f.get(l1ll1_kz_ (u"ࠪ࡭ࡲ࡭ࠧਚ"),l1ll1_kz_ (u"ࠫࠬਛ")), infoLabels=f, IsPlayable=True)
        xbmcplugin.addSortMethod( handle=l11111lll1_kz_, sortMethod=xbmcplugin.SORT_METHOD_TITLE )
        xbmcplugin.setContent(l11111lll1_kz_, l1ll1_kz_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࠧਜ"))
        xbmcplugin.endOfDirectory(l11111lll1_kz_)
    @staticmethod
    def l1l1lll1_kz_(ex_link=l1ll1_kz_ (u"࠭ࠧਝ")):
        l1lll11lll1_kz_ = l11l111ll1_kz_.l1l1lll1_kz_(ex_link)
        l1lll111l1_kz_=l1ll1_kz_ (u"ࠧࠨਞ")
        if len(l1lll11lll1_kz_)>0:
            l1l11111l1_kz_ = xbmcgui.Dialog().select(l1ll1_kz_ (u"࡙ࠣࡼࡦࣸࡸࠢਟ"), [ x.get(l1ll1_kz_ (u"ࠩࡷ࡭ࡹࡲࡥࠨਠ")) for x in l1lll11lll1_kz_])
            if l1l11111l1_kz_>-1:
                l1lll111l1_kz_ = l1lll11lll1_kz_[l1l11111l1_kz_].get(l1ll1_kz_ (u"ࠪ࡬ࡷ࡫ࡦࠨਡ"))
                l1lll111l1_kz_ = l11l111ll1_kz_.l1ll11lll1_kz_(l1lll111l1_kz_)
        if l1lll111l1_kz_:
            try:
                import urlresolver
                l1lllll1ll1_kz_ = urlresolver.resolve(l1lll111l1_kz_)
            except Exception,e:
                l1lllll1ll1_kz_=l1ll1_kz_ (u"ࠫࠬਢ")
            if l1lllll1ll1_kz_:
                xbmcplugin.setResolvedUrl(l11111lll1_kz_, True, xbmcgui.ListItem(path=l1lllll1ll1_kz_))
            else:
                xbmcplugin.setResolvedUrl(l11111lll1_kz_, False, xbmcgui.ListItem(path=l1ll1_kz_ (u"ࠬ࠭ਣ")))
        else:
            l1lll1l1_kz_.notification(l11llll1l1_kz_, l1ll1_kz_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠ࡟ࡇࡣࠠࡃࡴࡤ࡯ࠥঀࡲࣴࡦࡨॆࠥࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫਤ") , xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1ll1_kz_ (u"ࠧࡱࡣࡷ࡬ࠬਥ")))+l1ll1_kz_ (u"ࠨ࠱࡬ࡧࡴࡴ࠮ࡱࡰࡪࠫਦ"), 5000, False)
    @staticmethod
    def l11ll1_kz_(mode,ex_link):
        _1ll1ll11l1_kz_=mode.split(l1ll1_kz_ (u"ࠤ࠽ࠦਧ"))[-1]
        url = l11ll1lll1_kz_({l1ll1_kz_ (u"ࠪࡱࡴࡪࡥࠨਨ"): _1ll1ll11l1_kz_, l1ll1_kz_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨ਩"): l1ll1_kz_ (u"ࠬ࠭ਪ"), l1ll1_kz_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧਫ") : ex_link })
        xbmc.executebuiltin(l1ll1_kz_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠪࠨࡷ࠮࠭ਬ")% url)
    @staticmethod
    def l1lllll1_kz_(mode,ex_link):
        from l1llll1l1l1_kz_ import l1lll1111l1_kz_
        l1ll1ll1ll1_kz_=mode.split(l1ll1_kz_ (u"ࠣ࠼ࠥਭ"))[-1] if l1ll1_kz_ (u"ࠩ࠽ࠫਮ") in mode else l1ll1_kz_ (u"ࠪࠫਯ")
        if l1ll1ll1ll1_kz_ == l1ll1_kz_ (u"ࠫࠬਰ"):
            l111l1lll1_kz_(l1ll1_kz_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡲࡩࡨࡪࡷ࡫ࡷ࡫ࡥ࡯࡟ࡑࡳࡼ࡫ࠠࡔࡼࡸ࡯ࡦࡴࡩࡦ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ਱"),ex_link=l1ll1_kz_ (u"࠭ࠧਲ"),mode=l1ll1_kz_ (u"ࠧࡴࡧࡤࡶࡨ࡮࠺࡯ࡧࡺࠫਲ਼"))
            l1lll11l1l1_kz_ = l1lll1111l1_kz_().l111l111l1_kz_()
            if not l1lll11l1l1_kz_ == [l1ll1_kz_ (u"ࠨࠩ਴")]:
                for entry in l1lll11l1l1_kz_:
                    contextmenu = []
                    contextmenu.append((l1ll1_kz_ (u"ࡷ࡙ࠪࡸࡻ࡮ࠨਵ"), l1ll1_kz_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬࠭ࠫࡳࠪࠩਸ਼")% l11ll1lll1_kz_({l1ll1_kz_ (u"ࠫࡲࡵࡤࡦࠩ਷"): l1ll1_kz_ (u"ࠬࡹࡥࡢࡴࡦ࡬࠿ࡪࡥ࡭ࡑࡱࡩࠬਸ"), l1ll1_kz_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧਹ") : entry})),)
                    contextmenu.append((l1ll1_kz_ (u"ࡵࠨࡗࡶࡹࡳࠦࡣࡢॄࡤࠤ࡭࡯ࡳࡵࡱࡵ࡭ࡪ࠭਺"), l1ll1_kz_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࠨࡷ࠮࠭਻") % l11ll1lll1_kz_({l1ll1_kz_ (u"ࠩࡰࡳࡩ࡫਼ࠧ"): l1ll1_kz_ (u"ࠪࡷࡪࡧࡲࡤࡪ࠽ࡨࡪࡲࡁ࡭࡮ࠪ਽")})),)
                    l111l1lll1_kz_(name=entry, ex_link=entry.replace(l1ll1_kz_ (u"ࠫࠥ࠭ਾ"),l1ll1_kz_ (u"ࠬ࠱ࠧਿ")), mode=l1ll1_kz_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡀ࡮ࡦࡹࠪੀ"), fanart=None, contextmenu=contextmenu)
            xbmcplugin.endOfDirectory(l11111lll1_kz_)
        elif l1ll1ll1ll1_kz_ ==l1ll1_kz_ (u"ࠧ࡯ࡧࡺࠫੁ"):
            if not ex_link:
                l1ll1lllll1_kz_ = l1lll1l1_kz_.input(l1ll1_kz_ (u"ࡶࠩࡖࡾࡺࡱࡡ࡫࠮ࠣࡔࡴࡪࡡ࡫ࠢࡷࡽࡹࡻूࠨੂ"), type=xbmcgui.INPUT_ALPHANUM)
                if l1ll1lllll1_kz_: l1lll1111l1_kz_().l1lllll11l1_kz_(l1ll1lllll1_kz_)
            else:
                l1ll1lllll1_kz_ = ex_link
            if l1ll1lllll1_kz_:
                l1l11lll1_kz_ = l11l111ll1_kz_.l1ll1ll1l1_kz_(l1ll1_kz_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴࡫ࡳࡧࡶ࡯ࡴࡽ࡫ࡢࡼࡲࡲࡪ࠴ࡰ࡭࠱ࡶࡾࡺࡱࡡ࡫ࡁࡶࡾࡺࡱࡡ࡯ࡣࡀࠫ੃")+l1ll1lllll1_kz_.replace(l1ll1_kz_ (u"ࠪࠤࠬ੄"),l1ll1_kz_ (u"ࠫ࠰࠭੅")))
                for f in l1l11lll1_kz_: l111l1lll1_kz_(f.get(l1ll1_kz_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ੆")),f.get(l1ll1_kz_ (u"࠭ࡨࡳࡧࡩࠫੇ")), l11111l1_kz_=1, mode=l1ll1_kz_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩੈ"),iconImage=f.get(l1ll1_kz_ (u"ࠨ࡫ࡰ࡫ࠬ੉"),l1ll1_kz_ (u"ࠩࠪ੊")), infoLabels=f)
            xbmcplugin.addSortMethod( handle=l11111lll1_kz_, sortMethod=xbmcplugin.SORT_METHOD_TITLE )
            xbmcplugin.endOfDirectory(l11111lll1_kz_)
        elif l1ll1ll1ll1_kz_ ==l1ll1_kz_ (u"ࠪࡨࡪࡲࡏ࡯ࡧࠪੋ"):
            l1lll1111l1_kz_().l1lll1ll1l1_kz_(ex_link)
            xbmc.executebuiltin(l1ll1_kz_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠮ࠥࡴࠫࠪੌ")%  l11ll1lll1_kz_({l1ll1_kz_ (u"ࠬࡳ࡯ࡥࡧ੍ࠪ"): l1ll1_kz_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭੎")}))
        elif l1ll1ll1ll1_kz_ ==l1ll1_kz_ (u"ࠧࡥࡧ࡯ࡅࡱࡲࠧ੏"):
            l1lll1111l1_kz_().l11ll1l1l1_kz_()
            xbmc.executebuiltin(l1ll1_kz_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠫࠩࡸ࠯ࠧ੐")%  l11ll1lll1_kz_({l1ll1_kz_ (u"ࠩࡰࡳࡩ࡫ࠧੑ"): l1ll1_kz_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ੒")}))
        xbmcplugin.setContent(l11111lll1_kz_, l1ll1_kz_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ੓"))
    @staticmethod
    def l11111l1l1_kz_(ex_link):
        from l11l1l11l1_kz_ import l1lll1l11l1_kz_
        l1lll11lll1_kz_ = l1lll1l11l1_kz_().l1ll11ll1_kz_(ex_link)
        l1lll111l1_kz_=l1ll1_kz_ (u"ࠬ࠭੔")
        if len(l1lll11lll1_kz_)>0:
            l1l11111l1_kz_ = xbmcgui.Dialog().select(l1ll1_kz_ (u"ࠨࡗࡺࡤࣶࡶࠧ੕"), [ x.get(l1ll1_kz_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭੖")) for x in l1lll11lll1_kz_])
            if l1l11111l1_kz_>-1:
                l1lll111l1_kz_ = l1lll11lll1_kz_[l1l11111l1_kz_].get(l1ll1_kz_ (u"ࠨࡪࡵࡩ࡫࠭੗"))
                if l1lll11lll1_kz_[l1l11111l1_kz_].get(l1ll1_kz_ (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ੘")) == False:
                    l1lll111l1_kz_ = l1lll1l11l1_kz_().l1lll1lll1_kz_(l1lll111l1_kz_)
        if l1lll111l1_kz_:
            try:
                import urlresolver
                l1lllll1ll1_kz_ = urlresolver.resolve(l1lll111l1_kz_)
            except Exception,e:
                l1lllll1ll1_kz_=l1ll1_kz_ (u"ࠪࠫਖ਼")
            if l1lllll1ll1_kz_:
                xbmcplugin.setResolvedUrl(l11111lll1_kz_, True, xbmcgui.ListItem(path=l1lllll1ll1_kz_))
            else:
                xbmcplugin.setResolvedUrl(l11111lll1_kz_, False, xbmcgui.ListItem(path=l1ll1_kz_ (u"ࠫࠬਗ਼")))
        else:
            l1lll1l1_kz_.notification(l11llll1l1_kz_, l1ll1_kz_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡸࡥࡥ࡟࡞ࡆࡢࠦࡂࡳࡣ࡮ࠤॿࡸࣳࡥࡧॅࠤࡠ࠵ࡂ࡞࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪਜ਼") , xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1ll1_kz_ (u"࠭ࡰࡢࡶ࡫ࠫੜ")))+l1ll1_kz_ (u"ࠧ࠰࡫ࡦࡳࡳ࠴ࡰ࡯ࡩࠪ੝"), 5000, False)
    @staticmethod
    def l1ll1ll1_kz_(ex_link):
        from l11l1l11l1_kz_ import l1lll1l11l1_kz_
        out = l1lll1l11l1_kz_().l1ll111l1_kz_(ex_link)
        l1ll1llll1_kz_ = l1lll1l11l1_kz_().l1l1lll1l1_kz_(out)
        for l11ll111l1_kz_ in sorted(l1ll1llll1_kz_.keys()):
            l111l1lll1_kz_(name=l11ll111l1_kz_, ex_link=urllib.quote(str(l1ll1llll1_kz_[l11ll111l1_kz_])), mode=l1ll1_kz_ (u"ࠨࡵࡨࡶ࡮ࡧ࡬ࡦࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫਫ਼"))
        xbmcplugin.setContent(l11111lll1_kz_, l1ll1_kz_ (u"ࠩࡷࡺࡸ࡮࡯ࡸࡵࠪ੟"))
        xbmcplugin.endOfDirectory(l11111lll1_kz_)
