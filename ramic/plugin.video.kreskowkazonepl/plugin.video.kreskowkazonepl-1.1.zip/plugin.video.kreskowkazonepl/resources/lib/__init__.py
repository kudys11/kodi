# coding: UTF-8
import sys
l1l1ll11l1_kz_ = sys.version_info [0] == 2
l1l1l1l11l1_kz_ = 2048
l11lll11l1_kz_ = 7
def l1ll11l1_kz_ (keyedStringLiteral):
	global l111l1l11l1_kz_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l1ll11l1_kz_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l1l1l11l1_kz_ - (charIndex + stringNr) % l11lll11l1_kz_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l1l1l11l1_kz_ - (charIndex + stringNr) % l11lll11l1_kz_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)