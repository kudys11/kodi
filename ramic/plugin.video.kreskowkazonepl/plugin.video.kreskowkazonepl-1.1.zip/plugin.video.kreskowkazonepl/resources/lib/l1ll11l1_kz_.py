# coding: UTF-8
import sys
l1l1ll1_kz_ = sys.version_info [0] == 2
l1l1l1l1_kz_ = 2048
l11lll1_kz_ = 7
def l1ll1_kz_ (keyedStringLiteral):
	global l111l1l1_kz_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l1ll1_kz_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l1l1l1_kz_ - (charIndex + stringNr) % l11lll1_kz_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l1l1l1_kz_ - (charIndex + stringNr) % l11lll1_kz_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import threading
import xbmc,xbmcgui
import time,re,os
try: from shutil import rmtree
except: rmtree = False
def lll1_kz_(l1llllll1_kz_,l1l1l1_kz_=[l1ll1_kz_ (u"ࠧࠨ࠻")]):
    debug=1
def l1111l1_kz_(name=l1ll1_kz_ (u"ࠨࠩ࠼")):
    debug=1
def l111l1_kz_(top):
    debug=1
def check():
    debug=1
try:
    debug=1
except: pass
debug=1