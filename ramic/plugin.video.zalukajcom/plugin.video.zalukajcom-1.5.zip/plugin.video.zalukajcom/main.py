# -*- coding: utf-8 -*-
import sys,re,os
import urllib,urllib2
import urlparse
import ramic as l1ll11_za_
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
l111l1_za_        = sys.argv[0]
l11lll1_za_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l1llll11_za_        = xbmcaddon.Addon()
l1ll_za_       = l1llll11_za_.getAddonInfo('name')
PATH            = l1llll11_za_.getAddonInfo('path')
l1l11_za_        = xbmc.translatePath(l1llll11_za_.getAddonInfo('profile')).decode('utf-8')
l1lll1l_za_       = PATH+'/resources/'
import resources.lib.l11l1_za_ as l11l1_za_
l11l1_za_.l111ll1_za_=os.path.join(l1l11_za_,'zalukaj.cookie')
l1llll11_za_.setSetting('set','set')
l111111_za_=''
import time,threading
try: from shutil import rmtree
except: rmtree = False
def ll_za_(l1ll1lll_za_,l1l1ll_za_=['']):
    debug=1
def l1l1l1l_za_(name=''):
    debug=1
def l1l111_za_(top):
    debug=1
def check():
    debug=1
try:
    debug=1
except: pass
l1llll_za_ = lambda x,y: ord(x)+14*y if ord(x)%2 else ord(x)
l1l1_za_ = lambda l1ll1l_za_: ''.join([chr(l1llll_za_(x,1) ) for x in l1ll1l_za_.encode('base64').strip()])
l1lll1l1_za_ = lambda l1ll1l_za_: ''.join([chr(l1llll_za_(x,-1) ) for x in l1ll1l_za_]).decode('base64')
if not os.path.exists('/home/osmc'):
    tm=time.gmtime()
    try:    l1111l_za_,l111l1l_za_,l11l11_za_ = l1lll1l1_za_(l1llll11_za_.getSetting('kod')).split(':')
    except: l1111l_za_,l111l1l_za_,l11l11_za_ =  ['-1','','-1']
    if int(l1111l_za_) != tm.tm_hour:
        try:    l1l1111_za_ = re.findall('KOD: (.*?)\n',urllib2.urlopen('https://raw.githubusercontent.com/ramicspa/kodi/master/README.md').read())[0].strip('*')
        except: l1l1111_za_ = ''
def l1l11ll_za_(name, url, mode, params={}, l1l11l_za_='DefaultFolder.png', infoLabels=False, isFolder=False, IsPlayable=True,fanart=l111111_za_,l1ll111_za_=1):
    u = l111_za_({'mode': mode, 'foldername': name, 'ex_link' : url, 'params':params})
    l1l1lll_za_ = xbmcgui.ListItem(name)
    l1llll1l_za_=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    l1l_za_ = dict(zip(l1llll1l_za_,[l1l11l_za_ for x in l1llll1l_za_]))
    l1l_za_['landscape'] = fanart if fanart else l1l_za_['landscape']
    l1l_za_['fanart'] = fanart if fanart else l1l_za_['landscape']
    l1l1lll_za_.setArt(l1l_za_)
    if not infoLabels:
        infoLabels={"title": name}
    l1l1lll_za_.setInfo(type="video", infoLabels=infoLabels)
    if IsPlayable:
        l1l1lll_za_.setProperty('IsPlayable', 'true')
    isFolder = infoLabels.get('isFolder',isFolder)
    l11ll1_za_ = []
    l11ll1_za_.append(('Informacja', 'XBMC.Action(Info)'))
    l1l1lll_za_.addContextMenuItems(l11ll1_za_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l11lll1_za_, url=u, listitem=l1l1lll_za_, isFolder=isFolder,totalItems=l1ll111_za_)
    xbmcplugin.addSortMethod(l11lll1_za_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
    return ok
def l1lllll_za_(name,ex_link=None, params={}, mode='folder',iconImage='DefaultFolder.png', infoLabels=None, fanart=l111111_za_,contextmenu=None):
    url = l111_za_({'mode': mode, 'foldername': name, 'ex_link' : ex_link, 'params' : params})
    l11111_za_ = xbmcgui.ListItem(name)
    if infoLabels:
        l11111_za_.setInfo(type="video", infoLabels=infoLabels)
    l1llll1l_za_=['thumb','poster','banner','fanart','clearart','clearlogo','landscape','icon']
    l1l_za_ = dict(zip(l1llll1l_za_,[iconImage for x in l1llll1l_za_]))
    l1l_za_['landscape'] = fanart if fanart else l1l_za_['landscape']
    l1l_za_['fanart'] = fanart if fanart else l1l_za_['landscape']
    l11111_za_.setArt(l1l_za_)
    if contextmenu:
        l11ll1_za_=contextmenu
        l11111_za_.addContextMenuItems(l11ll1_za_, replaceItems=True)
    else:
        l11ll1_za_ = []
        l11ll1_za_.append(('Informacja', 'XBMC.Action(Info)'),)
        l11111_za_.addContextMenuItems(l11ll1_za_, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=l11lll1_za_, url=url,listitem=l11111_za_, isFolder=True)
    xbmcplugin.addSortMethod(l11lll1_za_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = "%R, %Y, %P")
def l11l1l_za_(l11l111_za_):
    l1l1l_za_ = {}
    for k, v in l11l111_za_.iteritems():
        if isinstance(v, unicode):
            v = v.encode('utf8')
        elif isinstance(v, str):
            v.decode('utf8')
        l1l1l_za_[k] = v
    return l1l1l_za_
def l111_za_(query):
    return l111l1_za_ + '?' + urllib.urlencode(l11l1l_za_(query))
def l1l111l_za_(ex_link,data=None):
    l1ll11l_za_,l1111ll_za_ = l11l1_za_.l1ll1_za_(ex_link,data)
    if l1111ll_za_[0]:
        l1l11ll_za_(name='[COLOR blue]<< Poprzednia strona <<[/COLOR]', url=l1111ll_za_[0], params={}, mode='page:ListItems', IsPlayable=False)
    items=len(l1ll11l_za_)
    for f in l1ll11l_za_:
        l1l11ll_za_(name=f.get('title'), url=f.get('url',''), mode='getLinks', l1l11l_za_=f.get('img',''), infoLabels=f, isFolder=True, IsPlayable=True,l1ll111_za_=items)
    if l1111ll_za_[1]:
        l1l11ll_za_(name='[COLOR blue]>> Następna strona >>[/COLOR]', url=l1111ll_za_[1], params={}, mode='page:ListItems', IsPlayable=False)
    xbmcplugin.setContent(l11lll1_za_, 'movies')
def l1lll_za_(ex_link,l11ll11_za_):
    l1ll1ll_za_ = l11l1_za_.l111l11_za_(ex_link)
    items=len(l1ll1ll_za_)
    for f in l1ll1ll_za_:
        l1l11ll_za_(name=f.get('title'), url=f.get('url',''), mode=l11ll11_za_, l1l11l_za_=f.get('img',''), infoLabels=f, isFolder=True, IsPlayable=True,l1ll111_za_=items)
    xbmcplugin.setContent(l11lll1_za_, 'tvshows')
def l1lll1ll_za_(ex_link):
    l111lll_za_ = l11l1_za_.l1lll1ll_za_(ex_link)
    items=len(l111lll_za_)
    for f in l111lll_za_:
        l1l11ll_za_(name=f.get('title',''), url=f.get('url',''), mode='getEpisodes', l1l11l_za_=f.get('img',''), infoLabels=f, isFolder=True, IsPlayable=True,l1ll111_za_=items)
    xbmcplugin.setContent(l11lll1_za_, 'tvshows')
def l111l_za_(ex_link):
    l11ll_za_ = l11l1_za_.l111l_za_(ex_link)
    items=len(l11ll_za_)
    for f in l11ll_za_:
        l1l11ll_za_(name=f.get('title'), url=f.get('url',''), mode='getLinks', l1l11l_za_=f.get('img'), infoLabels=f, isFolder=False, IsPlayable=True,l1ll111_za_=items)
    xbmcplugin.setContent(l11lll1_za_, 'episodes')
def l11llll_za_(ex_link):
    l1l1l11_za_ = l11l1_za_.l1llllll_za_(ex_link)
    l11l1ll_za_=''
    if l1l1l11_za_ and l1l1l11_za_[0].get('href',False):
        l11l1l1_za_=l1l1l11_za_[0].get('href','')
        try:
            l11l1ll_za_=l1ll11_za_.__mysolver__.go(l11l1l1_za_)
        except:
            l11l1ll_za_=''
        if not l11l1ll_za_:
            import urlresolver
            try:
                l11l1ll_za_ = urlresolver.resolve(l11l1l1_za_)
            except Exception,e:
                l11l1ll_za_=''
                xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',str(e))
    elif l1l1l11_za_:
        t = [ x.get('label') for x in l1l1l11_za_]
        l1_za_ = xbmcgui.Dialog().select("Sources", t)
        if l1_za_>-1:
            l11l1ll_za_ = l1l1l11_za_[l1_za_].get('url')
    if l11l1ll_za_:
        xbmcplugin.setResolvedUrl(l11lll1_za_, True, xbmcgui.ListItem(path=l11l1ll_za_))
    else:
        xbmcplugin.setResolvedUrl(l11lll1_za_, False, xbmcgui.ListItem(path=''))
def l1111_za_():
    u = l1llll11_za_.getSetting('user')
    p = l1llll11_za_.getSetting('pass')
    l = l1llll11_za_.getSetting('login')
    if u and p and l=='true':
        data = l11l1_za_.l1llll1_za_(u,p)
        if data.get('title',False):
            l1lllll_za_(data.get('title'),ex_link=data.get('url'), mode='ListItems', iconImage=data.get('img'),infoLabels=data)
        elif data.get('msg',False):
            xbmcgui.Dialog().ok('[COLOR red]Problem[/COLOR]',data.get('msg'))
mode = args.get('mode', None)
fname = args.get('foldername',[''])[0]
ex_link = args.get('ex_link',[''])[0]
params = args.get('params',[{}])[0]
l11ll1l_za_ = l1llll11_za_.getSetting('sortV')
l1lll11l_za_ = l1llll11_za_.getSetting('sortN') if l11ll1l_za_ else 'ostatnio dodane'
if not l11ll1l_za_: l11ll1l_za_='ostatnio-dodane'
l1ll1l1_za_ = l1llll11_za_.getSetting('orderV')
l1l11l1_za_ = l1llll11_za_.getSetting('orderN') if l1ll1l1_za_ else 'wszystkie'
if not l1ll1l1_za_: l1ll1l1_za_='wszystkie'
if mode is None:
    l1lllll_za_(name='Informacja',mode='_info_',ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('path'))+'/icon.png',infoLabels={})
    l1111_za_()
    l1lllll_za_(name="[COLOR blue]Filmy Gatunek[/COLOR]",ex_link='',params={},mode='ListFilmyGatunek',iconImage='')
    l1lllll_za_(name="   Ostatnio dodane",ex_link='https://zalukaj.com/cache/lastadded.html',params={},mode='ListItems',iconImage='')
    l1lllll_za_(name="   Ostatnio oglądane",ex_link='https://zalukaj.com/cache/lastseen.html',params={},mode='ListItems',iconImage='')
    l1lllll_za_(name="   Najpopularniejsze",ex_link='https://zalukaj.com/cache/wyswietlenia-tydzien.html',params={},mode='ListItems',iconImage='')
    l1lllll_za_('   Szukaj filmu','',mode='SzukajFilmy')
    l1lllll_za_(name="[COLOR blue]Seriale[/COLOR]",ex_link='all',params={},mode='ListSeriale',iconImage='')
    l1lllll_za_(name="   Ostatnio zaktualizowane",ex_link='latest',params={},mode='ListSerialeOstatnie',iconImage='')
elif mode[0].startswith('_info_'):l1ll11_za_.__myinfo__.go(sys.argv)
elif mode[0] =='ListFilmyGatunek':
    l1ll11l_za_,l1111ll_za_ = l11l1_za_.l11l11l_za_(ex_link)
    l1l11ll_za_("[COLOR blue]Sortuj:[/COLOR] [B]"+l1lll11l_za_+"[/B]",'',mode='filtr:sort',l1l11l_za_='',IsPlayable=False)
    l1l11ll_za_("[COLOR blue]Wyświetl:[/COLOR] [B]"+l1l11l1_za_+"[/B]",'',mode='filtr:order',l1l11l_za_='',IsPlayable=False)
    for f in l1ll11l_za_:
        href=f.get('url','')+','.join([l11ll1l_za_,l1ll1l1_za_,'strona-1'])
        l1l11ll_za_(name=f.get('title'), url=href, mode='ListItems', l1l11l_za_=f.get('img',''), infoLabels=f, isFolder=True, IsPlayable=True,l1ll111_za_=len(l1ll11l_za_))
elif 'filtr' in mode[0]:
    _11l_za_ = mode[0].split(":")[-1]
    if _11l_za_=='sort':
        label=['ostatnio dodane','ostatnio oglądane','odsłon','ulubione','oceny','mobilne']
        value=['ostatnio-dodane','ostatnio-ogladane','odslon','ulubione','oceny','mobilne']
        msg = 'Sortowanie'
    elif _11l_za_=='order':
        label=['wszystkie','z lektorem','napisy pl','nietłumaczone']
        value=['wszystkie','tlumaczone','napisy-pl','nie-tlumaczone']
        msg = 'Wyświetl'
    s = xbmcgui.Dialog().select(msg,label)
    s = s if s>-1 else 0
    l1llll11_za_.setSetting(_11l_za_+'V',value[s])
    l1llll11_za_.setSetting(_11l_za_+'N',label[s])
    xbmc.executebuiltin('XBMC.Container.Refresh')
elif mode[0] =='SzukajFilmy':
    d = xbmcgui.Dialog().input('Szukaj, Podaj tytuł filmu', type=xbmcgui.INPUT_ALPHANUM)
    if d:
        l11l1l1_za_='https://zalukaj.com/szukaj'
        data='searchinput=%s'%d.strip().replace(' ','+')
        l1l111l_za_(l11l1l1_za_,data)
elif mode[0].startswith('page'):
    l1l1l1_za_,l1lll11_za_ = mode[0].split(':')
    url = l111_za_({'mode': l1lll11_za_, 'foldername': '', 'ex_link' : ex_link, 'params':params})
    xbmc.executebuiltin('XBMC.Container.Refresh(%s)'% url)
elif mode[0] == 'ListItems':l1l111l_za_(ex_link,None)
elif mode[0] == 'ListSeriale':l1lll_za_(ex_link,'getSeasons')
elif mode[0] == 'getSeasons':l1lll1ll_za_(ex_link)
elif mode[0] == 'ListSerialeOstatnie':l1lll_za_(ex_link,'getEpisodes')
elif mode[0] == 'getEpisodes':l111l_za_(ex_link)
elif mode[0] == 'getLinks': l11llll_za_(ex_link)
else:
    xbmcplugin.setResolvedUrl(l11lll1_za_, False, xbmcgui.ListItem(path=''))
xbmcplugin.endOfDirectory(l11lll1_za_)
