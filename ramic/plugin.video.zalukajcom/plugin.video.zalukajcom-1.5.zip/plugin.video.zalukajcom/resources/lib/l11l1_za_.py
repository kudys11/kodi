# -*- coding: utf-8 -*-
import urllib2,urllib
import re,os
import json
import cookielib
from urlparse import urlparse
l11l11111_za_='https://zalukaj.com'
l11l1l1l1_za_ = 10
l11ll1l11_za_='Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36'
l111ll1_za_=r'd:\cookie'
class l11llll11_za_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
def l11l111ll_za_(url,data=None,header={},l111lllll_za_=True,l11ll1111_za_=True):
    if l111ll1_za_ and (l111lllll_za_ or l11ll1111_za_):
        l1l111ll1_za_ = cookielib.LWPCookieJar()
        if l111lllll_za_==True and os.path.exists(l111ll1_za_):
            l1l111ll1_za_.load(l111ll1_za_)
        opener = urllib2.build_opener(l11llll11_za_,urllib2.HTTPCookieProcessor(l1l111ll1_za_))
        urllib2.install_opener(opener)
    if not header:
        header = {'User-Agent':l11ll1l11_za_,'referer':'https://zalukaj.com/index.html'}
    if l111lllll_za_:
        header.update({"Cookie": l1l1111ll_za_(l111ll1_za_)})
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l11l1l1l1_za_)
        l11l1l1_za_ =  response.read()
        response.close()
        if l111ll1_za_ and l11ll1111_za_:
            l11l1lll1_za_=os.path.dirname(l111ll1_za_)
            if not os.path.exists(l11l1lll1_za_): os.makedirs(l11l1lll1_za_)
            if l1l111ll1_za_: l1l111ll1_za_.save(l111ll1_za_)
    except urllib2.HTTPError as e:
        l11l1l1_za_ = ''
    return l11l1l1_za_
def l1l1111ll_za_(l111ll1_za_):
    l11llll1l_za_=''
    if os.path.isfile(l111ll1_za_):
        l1l111ll1_za_ = cookielib.LWPCookieJar()
        l1l111ll1_za_.load(l111ll1_za_)
        l11llll1l_za_=''.join(['%s=%s;'%(c.name, c.value) for c in l1l111ll1_za_])
    return l11llll1l_za_
def l1llll1_za_(u='',p=''):
    data='login=%s&password=%s'%(u,p)
    content=l11l111ll_za_('https://zalukaj.com/account.php',data=data)
    content=l11l111ll_za_('https://zalukaj.com/libs/ajax/login.php?login=1&x=2043')
    if 'Wyloguj' in content:
        user = re.compile('<a style="text-decoration:underline;" href="#">(.*?)</a>').findall(content)
        info = re.compile('<p>(.*?)<a.*>(.*?)</a>').findall(content)
        info = '\n'.join([''.join(x) for x in info]).replace('&raquo;','').replace('&laquo;','')
        l11l11ll1_za_ = re.compile('<img src="(.*?)"').findall(content)
        l11l11ll1_za_ = 'https:'+l11l11ll1_za_[0] if l11l11ll1_za_ else ''
        href = re.compile('<a href="(.*?)">Ulubione</a>').findall(content)
        href = l11l11111_za_ + href[0] if href else ''
        return {'title':'[B]%s - Ulubione[/B]'%user[0],'plot':info,'img':l11l11ll1_za_,'url':href}
    return {'msg':'Problem z logowaniem'}
def l1ll1_za_(url='https://zalukaj.com',data=None):
    content = l11l111ll_za_(url,data,l111lllll_za_=True)
    l11l1ll11_za_ = False
    l11l111l1_za_ = False
    if 'strona-' in url:
        l11l11l1l_za_=int(re.search('strona-(\d+)',url).group(1))
        if content.find(',strona-%d'%(l11l11l1l_za_+1)):
            l11l111l1_za_=re.sub('strona-\d+','strona-%d'%(l11l11l1l_za_+1),url)
        if l11l11l1l_za_>1:
            l11l1ll11_za_=re.sub('strona-\d+','strona-%d'%(l11l11l1l_za_-1),url)
    l11ll11l1_za_ = [(a.start(), a.end()) for a in re.finditer('<div class="tivief\d">', content)]
    l11ll11l1_za_.append( (-1,-1) )
    out=[]
    for i in range(len(l11ll11l1_za_[:-1])):
        l11ll11ll_za_ = content[ l11ll11l1_za_[i][1]:l11ll11l1_za_[i+1][0] ]
        l11l11ll1_za_ = re.compile('<img.*?src="(.*?)"').search(l11ll11ll_za_)
        if not l11l11ll1_za_:
            l11l11ll1_za_ = re.compile('style="background-image:url\((.*?)\);">').search(l11ll11ll_za_)
        href = re.compile('<a.*href="(.*?)" title="(.*?)"').search(l11ll11ll_za_)
        l11l1l111_za_ = re.compile('<div style="min-height:110px;font-size:10px;"(.*?)"').findall(l11ll11ll_za_)
        if not l11l1l111_za_:
            l11l1l111_za_ = re.compile('<div style="min-height:110px"(.*?)"').findall(l11ll11ll_za_)
        l11l1l111_za_ = re.compile('>(.*?)<').findall(l11l1l111_za_[0]) if l11l1l111_za_ else ''
        if href and l11l11ll1_za_:
            h= href.group(1)
            h= 'https:'+h if h[0:2]=='//' else h
            t= href.group(2).strip()
            year = re.search('(\d{4})',t)
            t,code = t.split('|') if '|' in t else (t,'')
            p= l11l1l111_za_[0].strip() if l11l1l111_za_ else ''
            l11l1l1ll_za_ = l11l11ll1_za_.group(1)
            l11l1l1ll_za_ = 'https:'+l11l1l1ll_za_ if l11l1l1ll_za_[0:2]=='//' else l11l1l1ll_za_
            l11l1ll1l_za_ = {'url'   : h,
                'title'  : l11l11l11_za_(t.strip()),
                'plot'   : l11l11l11_za_(p),
                'img'    : l11l1l1ll_za_,
                'year'   : year.group(1) if year else '',
                'code'   : code.strip(),
                'isFolder':False,
                }
            out.append(l11l1ll1l_za_)
    return out,(l11l1ll11_za_,l11l111l1_za_)
def l111l11_za_(type=''):
    if type=='all':
        return l11l11lll_za_()
    else:
        return l11ll111l_za_()
def l11ll111l_za_(url='https://zalukaj.com/seriale'):
    content = l11l111ll_za_(url,l111lllll_za_=True)
    out=[]
    l11ll11l1_za_ = [(a.start(), a.end()) for a in re.finditer('<div class="latest tooltip">', content)]
    l11ll11l1_za_.append( (-1,-1) )
    out=[]
    for i in range(len(l11ll11l1_za_[:-1])):
        l11ll11ll_za_ = content[ l11ll11l1_za_[i][1]:l11ll11l1_za_[i+1][0] ]
        l11l1111l_za_ =re.compile('<a href="(/kategoria-serialu.*?)" title="(.*?)"><img alt=".+" src="(.*?)">').findall(l11ll11ll_za_)
        l11l1llll_za_ = re.compile('<span style="font-weight:bold;">(.*?)</span>').findall(l11ll11ll_za_)
        code = re.compile('<span class="datelts">(.*?)</span>').findall(l11ll11ll_za_)
        if l11l1111l_za_ and l11l1llll_za_:
            h=l11l11111_za_+l11l1111l_za_[0][0]
            l11l11ll1_za_ = l11l1111l_za_[0][-1]
            t = '%s (%s)'%(l11l1111l_za_[0][1],l11l1llll_za_[0])
            out.append(
                {'url':h,
                 'title'  : l11l11l11_za_(t.strip()),
                 'img'  : l11l11ll1_za_,
                 'code'   : l11l11l11_za_(code[0].strip()) if code else '',
                 'plot'   : l11l11l11_za_(code[0].strip()) if code else '',
                })
    return out
def l11l11lll_za_():
    content = l11l111ll_za_(l11l11111_za_,l111lllll_za_=True)
    out=[]
    l1ll1ll_za_ = re.compile('<a href="(/sezon-serialu/.*?)" title="(.*?)">(.*?)</a>').findall(content)
    for s in l1ll1ll_za_:
        out.append({
            'url': l11l11111_za_+s[0],
            'title': l11l11l11_za_(s[1].strip()).decode('utf-8')
            }
            )
    return out
def l1lll1ll_za_(url='https://zalukaj.com/kategoria-serialu/2727,1/the_walking_dead_the_walking_dead_sezon_7/'):
    content = l11l111ll_za_(url,l111lllll_za_=True)
    out=[]
    l11l11ll1_za_ = re.compile('<div id="sezony" align="center"><img src="(.*?)"',re.DOTALL).findall(content)
    l11l11ll1_za_ = l11l11ll1_za_[0] if l11l11ll1_za_ else ''
    l11l11ll1_za_ = 'https:'+l11l11ll1_za_ if l11l11ll1_za_[0:2]=='//' else l11l11ll1_za_
    l111lll_za_ = re.compile('<a class="sezon" href="(.*?)" >(.*?)</a>').findall(content)
    for s in l111lll_za_:
        out.append({
            'url': l11l11111_za_+s[0],
            'title': l11l11l11_za_(s[1].strip()).decode('utf-8'),
            'img':l11l11ll1_za_,
            })
    return out
def l111l_za_(url):
    content = l11l111ll_za_(url,l111lllll_za_=True)
    out=[]
    l11l11ll1_za_ = re.compile('<div align="center"><img src="(.*?)"',re.DOTALL).findall(content)
    l11l11ll1_za_ = l11l11ll1_za_[0] if l11l11ll1_za_ else ''
    l11l11ll1_za_ = 'https:'+l11l11ll1_za_ if l11l11ll1_za_[0:2]=='//' else l11l11ll1_za_
    l11ll_za_ = re.compile('<div align="left" id="sezony"[^>]*>(.*?)<a href="(.*?)" title="(.*?)">(.*?)</a></div>').findall(content)
    for s in l11ll_za_:
        h= s[1]
        h= 'https:'+h if h[0:2]=='//' else h
        t= '%s %s'%(s[0].strip(),s[2].strip())
        out.append({
            'url': h,
            'title': l11l11l11_za_(t).decode('utf-8'),
            'img':l11l11ll1_za_,
            })
    return out
def l1llllll_za_(url):
    l111lll11_za_=[{}]
    href=''
    content = l11l111ll_za_(url,l111lllll_za_=True,l11ll1111_za_=False)
    l111lll1l_za_ = re.compile('<iframe(.*?)</iframe>',re.DOTALL).findall(content)
    if l111lll1l_za_:
        src = re.compile('src="(.*?)"').findall(l111lll1l_za_[0])
        if src:
            src = src[0]
            l111llll1_za_ = src.split('&')[0]+'&x=1&'+'&'.join(src.split('&')[1:])
            l111llll1_za_ = l11l11111_za_ + l111llll1_za_ if l111llll1_za_[0]=='/' else l111llll1_za_
            data = l11l111ll_za_(l111llll1_za_,l111lllll_za_=True)
            href =re.compile('<iframe src="(.*?)" .+?></iframe>').findall(data)
            if href:
                href='https:'+href[0] if href[0][0:2]=='//' else href[0]
                l111lll11_za_=[{'href':href,'label':'you should not see this'}]
    else:
        if 'Duze obciazenie!' in content:
            l111lll11_za_=[{'url':'','label':'[COLOR red]Duze obciazenie! [/COLOR]'}]
    if len(l111lll11_za_)==1 and l111lll11_za_[0]=={} and href:
        l111lll11_za_=[{'href':href,'label':'link'}]
    return l111lll11_za_
def l11l11l_za_(url=''):
    out=[
        {'url':"https://zalukaj.com/gatunek,22/",'title':"Akcja",},
        {'url':"https://zalukaj.com/gatunek,2/",'title':"Animowane",},
        {'url':"https://zalukaj.com/gatunek,21/",'title':"Biografie",},
        {'url':"https://zalukaj.com/gatunek,3/",'title':"Dokumentalne",},
        {'url':"https://zalukaj.com/gatunek,4/",'title':"Dramat",},
        {'url':"https://zalukaj.com/gatunek,25/",'title':"Familijne",},
        {'url':"https://zalukaj.com/gatunek,30/",'title':"Fantasty",},
        {'url':"https://zalukaj.com/gatunek,27/",'title':"Historyczne",},
        {'url':"https://zalukaj.com/gatunek,7/",'title':"Horror",},
        {'url':"https://zalukaj.com/gatunek,29/",'title':"Katastroficzne",},
        {'url':"https://zalukaj.com/gatunek,8/",'title':"Komedia",},
        {'url':"https://zalukaj.com/gatunek,23/",'title':"Kostiumowe",},
        {'url':"https://zalukaj.com/gatunek,28/",'title':"Musical",},
        {'url':"https://zalukaj.com/gatunek,20/",'title':"Obyczajowy",},
        {'url':"https://zalukaj.com/gatunek,24/",'title':"Polskie",},
        {'url':"https://zalukaj.com/gatunek,10/",'title':"Przygodowe",},
        {'url':"https://zalukaj.com/gatunek,12/",'title':"Sci-Fi",},
        {'url':"https://zalukaj.com/gatunek,13/",'title':"Sensacyjne",},
        {'url':"https://zalukaj.com/gatunek,26/",'title':"Sport",},
        {'url':"https://zalukaj.com/gatunek,14/",'title':"Thriller",},
        {'url':"https://zalukaj.com/gatunek,15/",'title':"Wojenne",},
        ]
    return out,(False, False)
def l11l11l11_za_(l11l1l11l_za_):
    if type(l11l1l11l_za_) is not str:
        l11l1l11l_za_=l11l1l11l_za_.encode('utf-8')
    l11l1l11l_za_ = l11l1l11l_za_.replace('&nbsp;','')
    l11l1l11l_za_ = l11l1l11l_za_.replace('&lt;br/&gt;',' ')
    l11l1l11l_za_ = l11l1l11l_za_.replace('&oacute;','ó').replace('&Oacute;','Ó')
    l11l1l11l_za_ = l11l1l11l_za_.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    l11l1l11l_za_ = l11l1l11l_za_.replace('&amp;','&')
    l11l1l11l_za_ = l11l1l11l_za_.replace('\u0105','ą').replace('\u0104','Ą')
    l11l1l11l_za_ = l11l1l11l_za_.replace('\u0107','ć').replace('\u0106','Ć')
    l11l1l11l_za_ = l11l1l11l_za_.replace('\u0119','ę').replace('\u0118','Ę')
    l11l1l11l_za_ = l11l1l11l_za_.replace('\u0142','ł').replace('\u0141','Ł')
    l11l1l11l_za_ = l11l1l11l_za_.replace('\u0144','ń').replace('\u0144','Ń')
    l11l1l11l_za_ = l11l1l11l_za_.replace('\u00f3','ó').replace('\u00d3','Ó')
    l11l1l11l_za_ = l11l1l11l_za_.replace('\u015b','ś').replace('\u015a','Ś')
    l11l1l11l_za_ = l11l1l11l_za_.replace('\u017a','ź').replace('\u0179','Ź')
    l11l1l11l_za_ = l11l1l11l_za_.replace('\u017c','ż').replace('\u017b','Ż')
    return l11l1l11l_za_
