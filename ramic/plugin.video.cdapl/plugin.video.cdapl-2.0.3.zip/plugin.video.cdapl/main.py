# -*- coding: utf-8 -*-
import sys
l1l1ll11l1l_cda_ = sys.version_info [0] == 2
l1lll1l11l1l_cda_ = 2048
l1l111l11l1l_cda_ = 7
def l1ll11l1l_cda_ (lll11l1l_cda_):
	global l11l1l11l1l_cda_
	l11llll11l1l_cda_ = ord (lll11l1l_cda_ [-1])
	l11lll11l1l_cda_ = lll11l1l_cda_ [:-1]
	l11l11l1l_cda_ = l11llll11l1l_cda_ % len (l11lll11l1l_cda_)
	l1lll11l1l_cda_ = l11lll11l1l_cda_ [:l11l11l1l_cda_] + l11lll11l1l_cda_ [l11l11l1l_cda_:]
	if l1l1ll11l1l_cda_:
		l1lllll11l1l_cda_ = unicode () .join ([unichr (ord (char) - l1lll1l11l1l_cda_ - (l1l11l11l1l_cda_ + l11llll11l1l_cda_) % l1l111l11l1l_cda_) for l1l11l11l1l_cda_, char in enumerate (l1lll11l1l_cda_)])
	else:
		l1lllll11l1l_cda_ = str () .join ([chr (ord (char) - l1lll1l11l1l_cda_ - (l1l11l11l1l_cda_ + l11llll11l1l_cda_) % l1l111l11l1l_cda_) for l1l11l11l1l_cda_, char in enumerate (l1lll11l1l_cda_)])
	return eval (l1lllll11l1l_cda_)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import json,time
import ramic as l1ll1l1ll11l1l_cda_
try: import StorageServer
except: import storageserverdummy as StorageServer
cache = StorageServer.StorageServer(l1ll11l1l_cda_ (u"ࠢࡤࡦࡤࠦ࠭"))
import check
from resources.lib import l11l111l11l1l_cda_ as l11l11l11l1l_cda_
from resources.lib import l11ll11l11l1l_cda_
l1l11lll11l1l_cda_        = sys.argv[0]
l1lll111ll11l1l_cda_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l1l1llll1l11l1l_cda_        = xbmcaddon.Addon()
l1l1lll1ll11l1l_cda_     = l1l1llll1l11l1l_cda_.getAddonInfo(l1ll11l1l_cda_ (u"ࠨ࡫ࡧࠫ࠮"))
PATH        = l1l1llll1l11l1l_cda_.getAddonInfo(l1ll11l1l_cda_ (u"ࠩࡳࡥࡹ࡮ࠧ࠯"))
l11l111ll11l1l_cda_    = xbmc.translatePath(l1l1llll1l11l1l_cda_.getAddonInfo(l1ll11l1l_cda_ (u"ࠪࡴࡷࡵࡦࡪ࡮ࡨࠫ࠰"))).decode(l1ll11l1l_cda_ (u"ࠫࡺࡺࡦ࠮࠺ࠪ࠱"))
l11lllll11l1l_cda_   = PATH+l1ll11l1l_cda_ (u"ࠬ࠵ࡲࡦࡵࡲࡹࡷࡩࡥࡴ࠱ࠪ࠲")
l1l11ll1l11l1l_cda_       = l11lllll11l1l_cda_+l1ll11l1l_cda_ (u"࠭࠯࡮ࡧࡧ࡭ࡦ࠵ࠧ࠳")
l1l1ll1ll11l1l_cda_    = os.path.join(l11l111ll11l1l_cda_,l1ll11l1l_cda_ (u"ࠧࡧࡣࡹࡳࡷ࡯ࡴࡦࡵ࠱࡮ࡸࡵ࡮ࠨ࠴"))
l11l1l1ll11l1l_cda_ = lambda x,y: ord(x)+6*y if ord(x)%2 else ord(x)
l1lll11ll11l1l_cda_ = lambda l11l1l11l11l1l_cda_: l1ll11l1l_cda_ (u"ࠨࠩ࠵").join([chr(l11l1l1ll11l1l_cda_(x,1) ) for x in l11l1l11l11l1l_cda_.encode(l1ll11l1l_cda_ (u"ࠩࡥࡥࡸ࡫࠶࠵ࠩ࠶")).strip()])
l1llllll1l11l1l_cda_ = lambda l11l1l11l11l1l_cda_: l1ll11l1l_cda_ (u"ࠪࠫ࠷").join([chr(l11l1l1ll11l1l_cda_(x,-1) ) for x in l11l1l11l11l1l_cda_]).decode(l1ll11l1l_cda_ (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫ࠸"))
if not os.path.exists(l1ll11l1l_cda_ (u"ࠬ࠵ࡨࡰ࡯ࡨ࠳ࡴࡹ࡭ࡤࠩ࠹")):
    tm=time.gmtime()
    try:    l1l11l1l11l1l_cda_,l111l11l11l1l_cda_,l1l1l11l11l1l_cda_ = l1llllll1l11l1l_cda_(l1l1llll1l11l1l_cda_.getSetting(l1ll11l1l_cda_ (u"࠭࡫ࡰࡦࠪ࠺"))).split(l1ll11l1l_cda_ (u"ࠧ࠻ࠩ࠻"))
    except: l1l11l1l11l1l_cda_,l111l11l11l1l_cda_,l1l1l11l11l1l_cda_ =  [l1ll11l1l_cda_ (u"ࠨ࠯࠴ࠫ࠼"),l1ll11l1l_cda_ (u"ࠩࠪ࠽"),l1ll11l1l_cda_ (u"ࠪ࠱࠶࠭࠾")]
    if int(l1l11l1l11l1l_cda_) != tm.tm_hour:
        try:    l111ll1ll11l1l_cda_ = re.findall(l1ll11l1l_cda_ (u"ࠫࡐࡕࡄ࠻ࠢࠫ࠲࠯ࡅࠩ࡝ࡰࠪ࠿"),urllib2.urlopen(l1ll11l1l_cda_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡲࡢࡹ࠱࡫࡮ࡺࡨࡶࡤࡸࡷࡪࡸࡣࡰࡰࡷࡩࡳࡺ࠮ࡤࡱࡰ࠳ࡷࡧ࡭ࡪࡥࡶࡴࡦ࠵࡫ࡰࡦ࡬࠳ࡲࡧࡳࡵࡧࡵ࠳ࡗࡋࡁࡅࡏࡈ࠲ࡲࡪࠧࡀ")).read())[0].strip(l1ll11l1l_cda_ (u"࠭ࠪࠨࡁ"))
        except: l111ll1ll11l1l_cda_ = l1ll11l1l_cda_ (u"ࠧࠨࡂ")
        l1lll1l11l11l1l_cda_ = l1lll11ll11l1l_cda_(l1ll11l1l_cda_ (u"ࠩࠨࡨ࠿ࠫࡳ࠻ࠧࡧࠫࡋ")%(tm.tm_hour,l111ll1ll11l1l_cda_,tm.tm_min))
        l1l1llll1l11l1l_cda_.setSetting(l1ll11l1l_cda_ (u"ࠪ࡯ࡴࡪࠧࡌ"),l1lll1l11l11l1l_cda_)
def l1l1l111l11l1l_cda_(url,data=None):
    req = urllib2.Request(url,data)
    req.add_header(l1ll11l1l_cda_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨࡍ"), l1ll11l1l_cda_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠹࠾࠮࠱࠰࠵࠹࠻࠺࠮࠺࠹ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪࡎ"))
    response = urllib2.urlopen(req)
    l111l11ll11l1l_cda_ = response.read()
    response.close()
    return l111l11ll11l1l_cda_
def l11llll1l11l1l_cda_(name, url, mode, iconImage=None, infoLabels=False, contextO=[l1ll11l1l_cda_ (u"࠭ࡆࡠࡃࡇࡈࠬࡏ")],IsPlayable=False,fanart=None,totalItems=1):
    u = l11111l11l1l_cda_({l1ll11l1l_cda_ (u"ࠧ࡮ࡱࡧࡩࠬࡐ"): mode, l1ll11l1l_cda_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬࡑ"): name, l1ll11l1l_cda_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪࡒ") : url})
    if iconImage==None:
        iconImage=l1ll11l1l_cda_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧࡓ")
    if not infoLabels:
        infoLabels={l1ll11l1l_cda_ (u"ࠦࡹ࡯ࡴ࡭ࡧࠥࡔ"): name}
    l1lllll1l11l1l_cda_ = xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconImage)
    l1lllll1l11l1l_cda_.setArt({ l1ll11l1l_cda_ (u"ࠬࡶ࡯ࡴࡶࡨࡶࠬࡕ"): iconImage, l1ll11l1l_cda_ (u"࠭ࡴࡩࡷࡰࡦࠬࡖ") : iconImage, l1ll11l1l_cda_ (u"ࠧࡪࡥࡲࡲࠬࡗ") : iconImage ,l1ll11l1l_cda_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨࡘ"):fanart,l1ll11l1l_cda_ (u"ࠩࡥࡥࡳࡴࡥࡳ࡙ࠩ"):iconImage})
    l1lllll1l11l1l_cda_.setInfo(type=l1ll11l1l_cda_ (u"ࠥࡺ࡮ࡪࡥࡰࠤ࡚"), infoLabels=infoLabels)
    if IsPlayable:
        l1lllll1l11l1l_cda_.setProperty(l1ll11l1l_cda_ (u"ࠫࡎࡹࡐ࡭ࡣࡼࡥࡧࡲࡥࠨ࡛"), l1ll11l1l_cda_ (u"࡚ࠬࡲࡶࡧࠪ࡜"))
    if fanart:
        l1lllll1l11l1l_cda_.setProperty(l1ll11l1l_cda_ (u"࠭ࡦࡢࡰࡤࡶࡹࡥࡩ࡮ࡣࡪࡩࠬ࡝"),fanart)
    l1lllll1l11l1l_cda_.setProperty(l1ll11l1l_cda_ (u"ࠧ࡮࡫ࡰࡩࡹࡿࡰࡦࠩ࡞"), l1ll11l1l_cda_ (u"ࠨࡸ࡬ࡨࡪࡵ࠯ࡹ࠯ࡰࡷࡻ࡯ࡤࡦࡱࠪ࡟"))
    l1ll1111l11l1l_cda_ = l1ll1l1l11l1l_cda_(infoLabels,contextO,url,l1lllll1l11l1l_cda_)
    l1lllll1l11l1l_cda_.addContextMenuItems(l1ll1111l11l1l_cda_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l1lll111ll11l1l_cda_, url=u, listitem=l1lllll1l11l1l_cda_,isFolder=False,totalItems=totalItems)
    xbmcplugin.addSortMethod(l1lll111ll11l1l_cda_, sortMethod=xbmcplugin.SORT_METHOD_UNSORTED, label2Mask = l1ll11l1l_cda_ (u"ࠤࠨࡈ࠱ࠦࠥࡑ࠮ࠣࠩࡗࠨࡠ"))
    return ok
def l1ll1l1l11l1l_cda_(infoLabels,contextO,url,l1lllll1l11l1l_cda_=None):
    l1ll1111l11l1l_cda_ = []
    l1ll1111l11l1l_cda_.append((l1ll11l1l_cda_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡰ࡮࡭ࡨࡵࡤ࡯ࡹࡪࡣࡉ࡯ࡨࡲࡶࡲࡧࡣ࡫ࡣ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࡡ"), l1ll11l1l_cda_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡄࡧࡹ࡯࡯࡯ࠪࡌࡲ࡫ࡵࠩࠨࡢ")))
    l1ll1111l11l1l_cda_.append((l1ll11l1l_cda_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡲࡩࡨࡪࡷࡦࡱࡻࡥ࡞ࡈࡲࡰࡩ࡫ࡲࠡࡗॿࡽࡹࡱ࡯ࡸࡰ࡬࡯ࡦࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࡣ"), l1ll11l1l_cda_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࠦࡵࠬࠫࡤ") % l11111l11l1l_cda_({l1ll11l1l_cda_ (u"ࠧ࡮ࡱࡧࡩࠬࡥ"): l1ll11l1l_cda_ (u"ࠨࡗࡶࡩࡷࡉ࡯࡯ࡶࡨࡲࡹ࠭ࡦ"), l1ll11l1l_cda_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪࡧ") : urllib.quote(url)})))
    content=urllib.quote_plus(json.dumps(infoLabels))
    if l1ll11l1l_cda_ (u"ࠪࡊࡤࡇࡄࡅࠩࡨ") in contextO:
        l1ll1111l11l1l_cda_.append((l1ll11l1l_cda_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡱ࡯ࡧࡩࡶࡥࡰࡺ࡫࡝ࡅࡱࡧࡥ࡯ࠦࡤࡰࠢࡅ࡭ࡧࡲࡩࡰࡶࡨ࡯࡮ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࡩ"), l1ll11l1l_cda_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠧࡶࡃࡲࡵࡤࡦ࠿ࡄࡨࡩࡓ࡯ࡷ࡫ࡨࠪࡪࡾ࡟࡭࡫ࡱ࡯ࡂࠫࡳࠪࠩࡪ")%(l1l1lll1ll11l1l_cda_,content)))
        l1ll1111l11l1l_cda_.append((l1ll11l1l_cda_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸࡧࡲࡵࡦ࡟࡚ࡽࡧࣹࡲࠡ࡬ࡤ࡯ࡴॡࡣࡪࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࡫"), l1ll11l1l_cda_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠧࡶ࠭ࠬ࡬")% l11111l11l1l_cda_({l1ll11l1l_cda_ (u"ࠨ࡯ࡲࡨࡪ࠭࡭"): l1ll11l1l_cda_ (u"ࠩࡧࡩࡨࡵࡤࡦࡘ࡬ࡨࡪࡵࡍࡢࡰࡸࡥࡱࡗࠧ࡮"), l1ll11l1l_cda_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫ࡯") : urllib.quote(url)})))
        l1ll1111l11l1l_cda_.append((l1ll11l1l_cda_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡱ࡯ࡧࡩࡶࡥࡰࡺ࡫࡝ࡅࡱࡧࡥ࡯ࠦࡤࡰ࡚ࠢࡽࡧࡸࡡ࡯ࡻࡦ࡬ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࡰ"), l1ll11l1l_cda_ (u"ࠬࡘࡵ࡯ࡒ࡯ࡹ࡬࡯࡮ࠩࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸࡅ࡭ࡰࡦࡨࡁ࡫ࡧࡶࡰࡴ࡬ࡸࡪࡹࡁࡅࡆࠩࡩࡽࡥ࡬ࡪࡰ࡮ࡁࠪࡹࠩࠨࡱ")%(l1l1lll1ll11l1l_cda_,content)))
    if l1ll11l1l_cda_ (u"࠭ࡆࡠࡔࡈࡑࠬࡲ") in contextO:
        l1ll1111l11l1l_cda_.append((l1ll11l1l_cda_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡ࡚ࡹࡵॅࠢࡽࠤ࡜ࡿࡢࡳࡣࡱࡽࡨ࡮࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨࡳ"), l1ll11l1l_cda_ (u"ࠨࡔࡸࡲࡕࡲࡵࡨ࡫ࡱࠬࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴࡁࡰࡳࡩ࡫࠽ࡧࡣࡹࡳࡷ࡯ࡴࡦࡵࡕࡉࡒࠬࡥࡹࡡ࡯࡭ࡳࡱ࠽ࠦࡵࠬࠫࡴ")%(l1l1lll1ll11l1l_cda_,content)))
    if l1ll11l1l_cda_ (u"ࠩࡉࡣࡉࡋࡌࠨࡵ") in contextO:
        l1ll1111l11l1l_cda_.append((l1ll11l1l_cda_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࡖࡵࡸैࠥ࡝ࡳࡻࡻࡶࡸࡰࡵ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨࡶ"), l1ll11l1l_cda_ (u"ࠫࡗࡻ࡮ࡑ࡮ࡸ࡫࡮ࡴࠨࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷࡄࡳ࡯ࡥࡧࡀࡪࡦࡼ࡯ࡳ࡫ࡷࡩࡸࡘࡅࡎࠨࡨࡼࡤࡲࡩ࡯࡭ࡀࡥࡱࡲࠩࠨࡷ")%(l1l1lll1ll11l1l_cda_)))
    if infoLabels.has_key(l1ll11l1l_cda_ (u"ࠬࡺࡲࡢ࡫࡯ࡩࡷ࠭ࡸ")):
        l1ll1111l11l1l_cda_.append((l1ll11l1l_cda_ (u"࡚࠭ࡸ࡫ࡤࡷࡹࡻ࡮ࠨࡹ"), l1ll11l1l_cda_ (u"࡙ࠧࡄࡐࡇ࠳ࡖ࡬ࡢࡻࡐࡩࡩ࡯ࡡࠩࠧࡶ࠭ࠬࡺ")%infoLabels.get(l1ll11l1l_cda_ (u"ࠨࡶࡵࡥ࡮ࡲࡥࡳࠩࡻ"))))
    return l1ll1111l11l1l_cda_
def l1llll1l11l1l_cda_(name, url, mode, iconImage=None, infoLabels=False, contextO=[l1ll11l1l_cda_ (u"ࠩࡉࡣࡆࡊࡄࠨࡼ")],IsPlayable=False,fanart=None,totalItems=1,json_file=l1ll11l1l_cda_ (u"ࠪࠫࡽ")):
    u = l11111l11l1l_cda_({l1ll11l1l_cda_ (u"ࠫࡲࡵࡤࡦࠩࡾ"): mode, l1ll11l1l_cda_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࡳࡧ࡭ࡦࠩࡿ"): name, l1ll11l1l_cda_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧࢀ") : url, l1ll11l1l_cda_ (u"ࠧ࡫ࡵࡲࡲࡤ࡬ࡩ࡭ࡧࠪࢁ") : json_file})
    if iconImage==None:
        iconImage=l1ll11l1l_cda_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬࢂ")
    if not infoLabels:
        infoLabels={l1ll11l1l_cda_ (u"ࠤࡷ࡭ࡹࡲࡥࠣࢃ"): name}
    l1lllll1l11l1l_cda_ = xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconImage)
    l1lllll1l11l1l_cda_.setArt({ l1ll11l1l_cda_ (u"ࠪࡴࡴࡹࡴࡦࡴࠪࢄ"): iconImage, l1ll11l1l_cda_ (u"ࠫࡹ࡮ࡵ࡮ࡤࠪࢅ") : iconImage, l1ll11l1l_cda_ (u"ࠬ࡯ࡣࡰࡰࠪࢆ") : iconImage ,l1ll11l1l_cda_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠭ࢇ"):fanart,l1ll11l1l_cda_ (u"ࠧࡣࡣࡱࡲࡪࡸࠧ࢈"):iconImage})
    l1lllll1l11l1l_cda_.setInfo(type=l1ll11l1l_cda_ (u"ࠣࡸ࡬ࡨࡪࡵࠢࢉ"), infoLabels=infoLabels)
    if IsPlayable:
        l1lllll1l11l1l_cda_.setProperty(l1ll11l1l_cda_ (u"ࠩࡌࡷࡕࡲࡡࡺࡣࡥࡰࡪ࠭ࢊ"), l1ll11l1l_cda_ (u"ࠪࡘࡷࡻࡥࠨࢋ"))
    if fanart:
        l1lllll1l11l1l_cda_.setProperty(l1ll11l1l_cda_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࡣ࡮ࡳࡡࡨࡧࠪࢌ"),fanart)
    l1lllll1l11l1l_cda_.setProperty(l1ll11l1l_cda_ (u"ࠬࡳࡩ࡮ࡧࡷࡽࡵ࡫ࠧࢍ"), l1ll11l1l_cda_ (u"࠭ࡶࡪࡦࡨࡳ࠴ࡾ࠭࡮ࡵࡹ࡭ࡩ࡫࡯ࠨࢎ"))
    l1ll1111l11l1l_cda_ = l1ll1l1l11l1l_cda_(infoLabels,contextO,url)
    l1lllll1l11l1l_cda_.addContextMenuItems(l1ll1111l11l1l_cda_, replaceItems=False)
    return (u, l1lllll1l11l1l_cda_, False)
def l1l1ll11l11l1l_cda_(name,ex_link=None,json_file=l1ll11l1l_cda_ (u"ࠧࠨ࢏"), mode=l1ll11l1l_cda_ (u"ࠨࡹࡤࡰࡰ࠭࢐"),iconImage=None,fanart=l1ll11l1l_cda_ (u"ࠩࠪ࢑"),infoLabels=False,totalItems=1,contextmenu=None):
    url = l11111l11l1l_cda_({l1ll11l1l_cda_ (u"ࠪࡱࡴࡪࡥࠨ࢒"): mode, l1ll11l1l_cda_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨ࢓"): name, l1ll11l1l_cda_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭࢔") : ex_link, l1ll11l1l_cda_ (u"࠭ࡪࡴࡱࡱࡣ࡫࡯࡬ࡦࠩ࢕") : json_file})
    l111l1ll11l1l_cda_ = xbmcgui.ListItem(label=name,iconImage=l1ll11l1l_cda_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫ࢖"))
    if iconImage==None:
        iconImage=l1ll11l1l_cda_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬࢗ")
    elif not iconImage.startswith(l1ll11l1l_cda_ (u"ࠩ࡫ࡸࡹࡶࠧ࢘")):
         iconImage = l1l11ll1l11l1l_cda_ + iconImage
    l111l1ll11l1l_cda_ = xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconImage)
    l111l1ll11l1l_cda_.setArt({ l1ll11l1l_cda_ (u"ࠪࡴࡴࡹࡴࡦࡴ࢙ࠪ"): iconImage, l1ll11l1l_cda_ (u"ࠫࡹ࡮ࡵ࡮ࡤ࢚ࠪ") : iconImage, l1ll11l1l_cda_ (u"ࠬ࡯ࡣࡰࡰ࢛ࠪ") : iconImage,l1ll11l1l_cda_ (u"࠭ࡢࡢࡰࡱࡩࡷ࠭࢜"):iconImage})
    if not infoLabels:
       infoLabels={l1ll11l1l_cda_ (u"ࠢࡵ࡫ࡷࡰࡪࠨ࢝"): name}
    l111l1ll11l1l_cda_.setInfo(type=l1ll11l1l_cda_ (u"ࠣࡘ࡬ࡨࡪࡵࠢ࢞"), infoLabels=infoLabels)
    if fanart:
        l111l1ll11l1l_cda_.setProperty(l1ll11l1l_cda_ (u"ࠩࡩࡥࡳࡧࡲࡵࡡ࡬ࡱࡦ࡭ࡥࠨ࢟"), fanart )
    if contextmenu:
        l1ll1111l11l1l_cda_=contextmenu
        l111l1ll11l1l_cda_.addContextMenuItems(l1ll1111l11l1l_cda_, replaceItems=True)
    ok = xbmcplugin.addDirectoryItem(handle=l1lll111ll11l1l_cda_, url=url,listitem=l111l1ll11l1l_cda_, isFolder=True)
    xbmcplugin.addSortMethod(l1lll111ll11l1l_cda_, sortMethod=xbmcplugin.SORT_METHOD_DATE, label2Mask = l1ll11l1l_cda_ (u"ࠥࠩࡉ࠲ࠠࠦࡒ࠯ࠤࠪࡘࠢࢠ"))
    return ok
def l1111llll11l1l_cda_():
    xbmcplugin.addSortMethod( handle=l1lll111ll11l1l_cda_, sortMethod=xbmcplugin.SORT_METHOD_TITLE )
    xbmcplugin.addSortMethod( handle=l1lll111ll11l1l_cda_, sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=l1lll111ll11l1l_cda_, sortMethod=xbmcplugin.SORT_METHOD_VIDEO_YEAR  )
    xbmcplugin.addSortMethod( handle=l1lll111ll11l1l_cda_, sortMethod=xbmcplugin.SORT_METHOD_GENRE )
    xbmcplugin.addSortMethod( handle=l1lll111ll11l1l_cda_, sortMethod=xbmcplugin.SORT_METHOD_STUDIO  )
    xbmcplugin.addSortMethod( handle=l1lll111ll11l1l_cda_, sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=l1lll111ll11l1l_cda_, sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
def l1l1l1ll11l1l_cda_(l1ll11l1ll11l1l_cda_):
    l1llll11ll11l1l_cda_ = {}
    for k, v in l1ll11l1ll11l1l_cda_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l1ll11l1l_cda_ (u"ࠫࡺࡺࡦ࠹ࠩࢡ"))
        elif isinstance(v, str):
            v.decode(l1ll11l1l_cda_ (u"ࠬࡻࡴࡧ࠺ࠪࢢ"))
        l1llll11ll11l1l_cda_[k] = v
    return l1llll11ll11l1l_cda_
def l11111l11l1l_cda_(query):
    return l1l11lll11l1l_cda_ + l1ll11l1l_cda_ (u"࠭࠿ࠨࢣ") + urllib.urlencode(l1l1l1ll11l1l_cda_(query))
def l1l11111l11l1l_cda_(ex_link):
    l1l1lll1l11l1l_cda_ = l11l11l11l1l_cda_.l111l111l11l1l_cda_
    l11l11l11l1l_cda_.l111l111l11l1l_cda_ = l1ll11l1l_cda_ (u"ࠧࠨࢤ")
    l11lll11l11l1l_cda_ = l11l11l11l1l_cda_.l1111ll1l11l1l_cda_(ex_link)
    quality = l1l1llll1l11l1l_cda_.getSetting(l1ll11l1l_cda_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩࢥ"))
    l11lll11l11l1l_cda_ = l1l1l11ll11l1l_cda_(l11lll11l11l1l_cda_,int(quality))
    l11l11l11l1l_cda_.l111l111l11l1l_cda_ = l1l1lll1l11l1l_cda_
    if l1ll11l1l_cda_ (u"ࠩࡦࡨࡦ࠴ࡰ࡭࠱ࡹ࡭ࡩ࡫࡯࠰ࡵ࡫ࡳࡼ࠵ࠧࢦ") in l11lll11l11l1l_cda_:
        xbmcplugin.setResolvedUrl(l1lll111ll11l1l_cda_, False, xbmcgui.ListItem(path=l1ll11l1l_cda_ (u"ࠪࠫࢧ")))
        url = l11111l11l1l_cda_({l1ll11l1l_cda_ (u"ࠫࡲࡵࡤࡦࠩࢨ"): l1ll11l1l_cda_ (u"ࠬࡩࡤࡢࡕࡨࡥࡷࡩࡨࠨࢩ"), l1ll11l1l_cda_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧࢪ") : l11lll11l11l1l_cda_})
        xbmc.executebuiltin(l1ll11l1l_cda_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠪࠨࡷ࠮࠭ࢫ")% url)
    elif l11lll11l11l1l_cda_:
        xbmcplugin.setResolvedUrl(l1lll111ll11l1l_cda_, True, xbmcgui.ListItem(path=l11lll11l11l1l_cda_))
    else:
        xbmcplugin.setResolvedUrl(l1lll111ll11l1l_cda_, False, xbmcgui.ListItem(path=l1ll11l1l_cda_ (u"ࠨࠩࢬ")))
def l11lll1ll11l1l_cda_(l1llllllll11l1l_cda_):
    import json
    l111ll11l11l1l_cda_ ={l1ll11l1l_cda_ (u"ࠤ࡭ࡷࡴࡴࡲࡱࡥࠥࢭ"): l1ll11l1l_cda_ (u"ࠥ࠶࠳࠶ࠢࢮ"), l1ll11l1l_cda_ (u"ࠦࡲ࡫ࡴࡩࡱࡧࠦࢯ"): l1ll11l1l_cda_ (u"ࠧ࡜ࡩࡥࡧࡲࡐ࡮ࡨࡲࡢࡴࡼ࠲ࡌ࡫ࡴࡎࡱࡹ࡭ࡪࡹࠢࢰ"), l1ll11l1l_cda_ (u"ࠨࡰࡢࡴࡤࡱࡸࠨࢱ"): { l1ll11l1l_cda_ (u"ࠢࡧ࡫࡯ࡸࡪࡸࠢࢲ"):{l1ll11l1l_cda_ (u"ࠣࡣࡱࡨࠧࢳ"): [{l1ll11l1l_cda_ (u"ࠤࡩ࡭ࡪࡲࡤࠣࢴ"): l1ll11l1l_cda_ (u"ࠥࡽࡪࡧࡲࠣࢵ"), l1ll11l1l_cda_ (u"ࠦࡴࡶࡥࡳࡣࡷࡳࡷࠨࢶ"): l1ll11l1l_cda_ (u"ࠧ࡯ࡳࠣࢷ"), l1ll11l1l_cda_ (u"ࠨࡶࡢ࡮ࡸࡩࠧࢸ"): str(l1llllllll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠧࡺࡧࡤࡶࠬࢹ"),l1ll11l1l_cda_ (u"ࠨࠩࢺ")))},{l1ll11l1l_cda_ (u"ࠤࡩ࡭ࡪࡲࡤࠣࢻ"): l1ll11l1l_cda_ (u"ࠥࡸ࡮ࡺ࡬ࡦࠤࢼ"), l1ll11l1l_cda_ (u"ࠦࡴࡶࡥࡳࡣࡷࡳࡷࠨࢽ"): l1ll11l1l_cda_ (u"ࠧ࡯ࡳࠣࢾ"), l1ll11l1l_cda_ (u"ࠨࡶࡢ࡮ࡸࡩࠧࢿ"): l1llllllll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࣀ"))}]}, l1ll11l1l_cda_ (u"ࠣࡲࡵࡳࡵ࡫ࡲࡵ࡫ࡨࡷࠧࣁ") :
        [l1ll11l1l_cda_ (u"ࠤࡷ࡭ࡹࡲࡥࠣࣂ"),l1ll11l1l_cda_ (u"ࠥ࡫ࡪࡴࡲࡦࠤࣃ"),l1ll11l1l_cda_ (u"ࠦࡾ࡫ࡡࡳࠤࣄ"),l1ll11l1l_cda_ (u"ࠧࡶ࡬ࡰࡶࠥࣅ"),l1ll11l1l_cda_ (u"ࠨࡣࡢࡵࡷࠦࣆ"),l1ll11l1l_cda_ (u"ࠢࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠥࣇ"),l1ll11l1l_cda_ (u"ࠣࡣࡵࡸࠧࣈ")]},l1ll11l1l_cda_ (u"ࠤ࡬ࡨࠧࣉ"): 1}
    l1llll1ll11l1l_cda_ = json.loads(xbmc.executeJSONRPC(json.dumps(l111ll11l11l1l_cda_))).get(l1ll11l1l_cda_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪ࣊"),{}).get(l1ll11l1l_cda_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ࣋"),[])
    l111l1ll11l1l_cda_ = xbmcgui.ListItem(l1llllllll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ࣌"),l1ll11l1l_cda_ (u"࠭ࠧ࣍")))
    if len(l1llll1ll11l1l_cda_)==1:
        l1lll1l1l11l1l_cda_ =l1llll1ll11l1l_cda_[0].pop(l1ll11l1l_cda_ (u"ࠧࡢࡴࡷࠫ࣎"),{})
        l1lll1l1l11l1l_cda_.update({l1ll11l1l_cda_ (u"ࠨࡶ࡫ࡹࡲࡨ࣏ࠧ") : l1llll1ll11l1l_cda_[0].get(l1ll11l1l_cda_ (u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰ࣐ࠬ"),l1ll11l1l_cda_ (u"࣑ࠪࠫ")), l1ll11l1l_cda_ (u"ࠫ࡮ࡩ࡯࡯࣒ࠩ") : l1llll1ll11l1l_cda_[0].get(l1ll11l1l_cda_ (u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨ࣓"),l1ll11l1l_cda_ (u"࠭ࠧࣔ"))})
        l111111ll11l1l_cda_ = l1llll1ll11l1l_cda_[0].pop(l1ll11l1l_cda_ (u"ࠧࡤࡣࡶࡸࠬࣕ"),{})
        l111l1ll11l1l_cda_.setArt(l1lll1l1l11l1l_cda_)
        l111l1ll11l1l_cda_.setCast(l111111ll11l1l_cda_)
        l111l1ll11l1l_cda_.setInfo(l1ll11l1l_cda_ (u"ࠨࡸ࡬ࡨࡪࡵࠧࣖ"), l1llll1ll11l1l_cda_[0])
    else:
        l111l1ll11l1l_cda_.setInfo(l1ll11l1l_cda_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨࣗ"), {l1ll11l1l_cda_ (u"ࠪࡽࡪࡧࡲࠨࣘ"):l1llllllll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠫࡾ࡫ࡡࡳࠩࣙ"),l1ll11l1l_cda_ (u"ࠬ࠭ࣚ"))})
    return l111l1ll11l1l_cda_
def l1ll11llll11l1l_cda_(ex_link):
    l1llllllll11l1l_cda_ = eval(ex_link)
    l1l1lll1l11l1l_cda_ = l11l11l11l1l_cda_.l111l111l11l1l_cda_
    l11l11l11l1l_cda_.l111l111l11l1l_cda_ = l1ll11l1l_cda_ (u"࠭ࠧࣛ")
    for l11llllll11l1l_cda_ in l1llllllll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠧࡶࡴ࡯ࠫࣜ"),[]):
        l11lll11l11l1l_cda_ = l11l11l11l1l_cda_.l1111ll1l11l1l_cda_(l11llllll11l1l_cda_)
        l11lll11l11l1l_cda_ = l1l1l11ll11l1l_cda_(l11lll11l11l1l_cda_,int(l1l1llll1l11l1l_cda_.getSetting(l1ll11l1l_cda_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩࣝ"))))
        if not l1ll11l1l_cda_ (u"ࠩࡦࡨࡦ࠴ࡰ࡭࠱ࡹ࡭ࡩ࡫࡯࠰ࡵ࡫ࡳࡼ࠵ࠧࣞ") in l11lll11l11l1l_cda_:
            break
    l11l11l11l1l_cda_.l111l111l11l1l_cda_ = l1l1lll1l11l1l_cda_
    if l1ll11l1l_cda_ (u"ࠪࡧࡩࡧ࠮ࡱ࡮࠲ࡺ࡮ࡪࡥࡰ࠱ࡶ࡬ࡴࡽ࠯ࠨࣟ") in l11lll11l11l1l_cda_:
        xbmcplugin.setResolvedUrl(l1lll111ll11l1l_cda_, False, xbmcgui.ListItem(path=l1ll11l1l_cda_ (u"ࠫࠬ࣠")))
        url = l11111l11l1l_cda_({l1ll11l1l_cda_ (u"ࠬࡳ࡯ࡥࡧࠪ࣡"): l1ll11l1l_cda_ (u"࠭ࡣࡥࡣࡖࡩࡦࡸࡣࡩࠩ࣢"), l1ll11l1l_cda_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨࣣ") : l11lll11l11l1l_cda_})
        xbmc.executebuiltin(l1ll11l1l_cda_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡒࡶࡰࡓࡰࡺ࡭ࡩ࡯ࠪࠨࡷ࠮࠭ࣤ")% url)
    elif l11lll11l11l1l_cda_:
        l111l1ll11l1l_cda_ = l11lll1ll11l1l_cda_(l1llllllll11l1l_cda_)
        l111l1ll11l1l_cda_.setPath(path=l11lll11l11l1l_cda_)
        xbmcplugin.setResolvedUrl(l1lll111ll11l1l_cda_, True, l111l1ll11l1l_cda_)
    else:
        xbmcplugin.setResolvedUrl(l1lll111ll11l1l_cda_, False, xbmcgui.ListItem(path=l1ll11l1l_cda_ (u"ࠩࠪࣥ")))
def l1l1l11ll11l1l_cda_(l11lll11l11l1l_cda_,quality):
    msg = l1ll11l1l_cda_ (u"ࡸࠫ࡜ࡿࡢࡪࡧࡵࡾࠥࡰࡡ࡬ࡱफ़ऋࠥࡼࡩࡥࡧࡲࠤࡠࡧ࡬ࡣࡱࠣࡹࡸࡺࡡࡸࠢࡤࡹࡹࡵ࡭ࡢࡶࠣࡻࠥࡵࡰࡤ࡬ࡤࡧ࡭ࡣࣦࠧ")
    l1ll111lll11l1l_cda_=l1ll11l1l_cda_ (u"ࠫࠬࣧ")
    if type(l11lll11l11l1l_cda_) is list:
        l11111lll11l1l_cda_ = [x[0] for x in l11lll11l11l1l_cda_]
        if quality > 0:
            l1l1llll11l1l_cda_ = [l1ll11l1l_cda_ (u"ࠬ࠭ࣨ"),l1ll11l1l_cda_ (u"࠭ࡎࡢ࡬࡯ࡩࡵࡹࡺࡢࣩࠩ"),l1ll11l1l_cda_ (u"ࠧ࠲࠲࠻࠴ࡵ࠭࣪"),l1ll11l1l_cda_ (u"ࠨ࠹࠵࠴ࡵ࠭࣫"),l1ll11l1l_cda_ (u"ࠩ࠷࠼࠵ࡶࠧ࣬"),l1ll11l1l_cda_ (u"ࠪ࠷࠻࠶ࡰࠨ࣭")][quality]
            if l1l1llll11l1l_cda_==l1ll11l1l_cda_ (u"ࠫࡓࡧࡪ࡭ࡧࡳࡷࡿࡧ࣮ࠧ") and l11lll11l11l1l_cda_[0][1]:
                l1ll111lll11l1l_cda_ = l11l11l11l1l_cda_.l1111ll1l11l1l_cda_(l11lll11l11l1l_cda_[0][1],4)
            elif l1l1llll11l1l_cda_ in l11111lll11l1l_cda_:
                l1ll111lll11l1l_cda_ = l11l11l11l1l_cda_.l1111ll1l11l1l_cda_(l11lll11l11l1l_cda_[l11111lll11l1l_cda_.index(l1l1llll11l1l_cda_)][1],4)
            else:
                msg = l1ll11l1l_cda_ (u"ࡺ࠭ࡐࡳࡱࡥࡰࡪࡳࠠࡻࠢࡤࡹࡹࡵ࡭ࡢࡶࡼࡧࡿࡴࡹ࡮ࠢࡺࡽࡧࡵࡲࡦ࡯ࠣ࠲࠳࠴ࠠࡸࡻࡥ࡭ࡪࡸࡺࠡ࡬ࡤ࡯ࡴॡइࠨ࣯")
        if not l1ll111lll11l1l_cda_:
            if len(l11lll11l11l1l_cda_)==1 and l11lll11l11l1l_cda_[0][1]==l1ll11l1l_cda_ (u"ࣰ࠭ࠧ"):
                msg=l1ll11l1l_cda_ (u"ࡵࠨ࡝ࡆࡓࡑࡕࡒࠡࡴࡨࡨࡢࠫࡳ࡜࠱ࡆࡓࡑࡕࡒ࡞࡞ࡱࣱࠫ")%(unicode(l11lll11l11l1l_cda_[0][0],l1ll11l1l_cda_ (u"ࠨࡷࡷࡪ࠲࠾ࣲࠧ")))
                title = l11l11l11l1l_cda_.l111lllll11l1l_cda_(fname.split(l1ll11l1l_cda_ (u"ࠩ࡞ࠫࣳ"))[0])
                l1ll11ll11l1l_cda_ = xbmcgui.Dialog().yesno(l1ll11l1l_cda_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࡑࡴࡲࡦࡱ࡫࡭࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࣴ"),msg+l1ll11l1l_cda_ (u"ࡹࠬࡖࡲࡰࡤ࡯ࡩࡲࠦࡤࡰࠢ࡞ࡇࡔࡒࡏࡓࠢ࡯࡭࡬࡮ࡴࡣ࡮ࡸࡩࡢࠫࡳ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࣵ")%title,l1ll11l1l_cda_ (u"࡙ࠬࡺࡶ࡭ࡤ࡮ࠥࡴ࡯ࡸࡧࡪࡳࠥঀࡲࣴࡦॅࡥࡄࣶ࠭"))
                if l1ll11ll11l1l_cda_:
                    l1ll111lll11l1l_cda_=l1ll11l1l_cda_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡨࡪࡡ࠯ࡲ࡯࠳ࡻ࡯ࡤࡦࡱ࠲ࡷ࡭ࡵࡷ࠰ࠩࣷ")+l11l11l11l1l_cda_.l111lllll11l1l_cda_(title.replace(l1ll11l1l_cda_ (u"ࠧࠡࠩࣸ"),l1ll11l1l_cda_ (u"ࠨࡡࣹࠪ")))
            else:
                l11l1ll11l1l_cda_ = xbmcgui.Dialog().select(msg, l11111lll11l1l_cda_)
                if l11l1ll11l1l_cda_>-1:
                    l1ll111lll11l1l_cda_ = l11l11l11l1l_cda_.l1111ll1l11l1l_cda_(l11lll11l11l1l_cda_[l11l1ll11l1l_cda_][1],4)
                    if isinstance(l1ll111lll11l1l_cda_,list):
                        l1ll111lll11l1l_cda_=l1ll11l1l_cda_ (u"ࣺࠩࠪ")
                else:
                    l1ll111lll11l1l_cda_=l1ll11l1l_cda_ (u"ࠪࠫࣻ")
    else:
        l1ll111lll11l1l_cda_ = l11lll11l11l1l_cda_
    return l1ll111lll11l1l_cda_
def l1l11l1ll11l1l_cda_(ex_link,l1lll11l1l11l1l_cda_=1):
    l11lll11l11l1l_cda_ = l11l11l11l1l_cda_.l1111ll1l11l1l_cda_(ex_link)
    quality = l1l1llll1l11l1l_cda_.getSetting(l1ll11l1l_cda_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࡤࡸࡥ࡮ࡱࡷࡩࠬࣼ"))
    l11lll11l11l1l_cda_ = l1l1l11ll11l1l_cda_(l11lll11l11l1l_cda_,int(quality)*l1lll11l1l11l1l_cda_)
    if not l11lll11l11l1l_cda_:
        return False
    out = l11l11l11l1l_cda_.grabInforFromLink(ex_link)
    if not out:
        out[l1ll11l1l_cda_ (u"ࠬࡺࡩࡵ࡮ࡨࠫࣽ")]=l1ll11l1l_cda_ (u"࠭ࡒࡦ࡯ࡲࡸࡪࠦࡶࡪࡦࡨࡳࠬࣾ")
    l1lllll1l11l1l_cda_=xbmcgui.ListItem(out.get(l1ll11l1l_cda_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࣿ")), iconImage=out.get(l1ll11l1l_cda_ (u"ࠨ࡫ࡰ࡫ࠬऀ"),l1ll11l1l_cda_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶ࡙࡭ࡩ࡫࡯࠯ࡲࡱ࡫ࠬँ")))
    l1lllll1l11l1l_cda_.setInfo( type=l1ll11l1l_cda_ (u"࡚ࠥ࡮ࡪࡥࡰࠤं"), infoLabels=out)
    try:
        l11l1lll11l1l_cda_ = xbmc.Player()
        l11l1lll11l1l_cda_.play(l11lll11l11l1l_cda_, l1lllll1l11l1l_cda_)
    except Exception as l1ll1ll1l11l1l_cda_:
        xbmcgui.Dialog().ok(l1ll11l1l_cda_ (u"ࠫࡕࡸ࡯ࡣ࡮ࡨࡱࠥࢀࠠࡰࡦࡷࡻࡴࡸࡺࡦࡰ࡬ࡩࡲ࠴ࠧः"), l1ll11l1l_cda_ (u"ࠬ࡝ࡹࡴࡶईࡴ࡮ैࠠ࡯࡫ࡨࡾࡳࡧ࡮ࡺࠢࡥॆऊࡪࠧऄ"), str(l1ll1ll1l11l1l_cda_))
    return 1
def l1ll11111l11l1l_cda_():
    l1lll1ll11l1l_cda_=[]
    for userF in [l1ll11l1l_cda_ (u"࠭ࡋ࠲ࠩअ"),l1ll11l1l_cda_ (u"ࠧࡌ࠴ࠪआ"),l1ll11l1l_cda_ (u"ࠨࡍ࠶ࠫइ"),l1ll11l1l_cda_ (u"ࠩࡎ࠸ࠬई"),l1ll11l1l_cda_ (u"ࠪࡏ࠺࠭उ"),l1ll11l1l_cda_ (u"ࠫࡐ࠼ࠧऊ")]:
        l11l1llll11l1l_cda_ = l1ll1lll1l11l1l_cda_(userF)
        if l11l1llll11l1l_cda_:
            l1l1ll11l11l1l_cda_(l11l1llll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠬࡺࡩࡵ࡮ࡨࠫऋ")),ex_link=l11l1llll11l1l_cda_.get(l1ll11l1l_cda_ (u"࠭ࡵࡳ࡮ࠪऌ")), mode=l1ll11l1l_cda_ (u"ࠧࡤࡦࡤࡗࡪࡧࡲࡤࡪࠪऍ"), json_file=l11l1llll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠨ࡯ࡨࡸࡦࡪࡡࡵࡣࠪऎ")),iconImage=l1ll11l1l_cda_ (u"ࠩࡖࡾࡺࡱࡡ࡫ࡡࡦࡨࡦ࠴ࡰ࡯ࡩࠪए"))
def l1ll1lll1l11l1l_cda_(userF=l1ll11l1l_cda_ (u"ࠪࡏ࠶࠭ऐ")):
    l11111l1l11l1l_cda_ = l1l1llll1l11l1l_cda_.getSetting(userF)
    if l11111l1l11l1l_cda_==l1ll11l1l_cda_ (u"ࠫࡹࡸࡵࡦࠩऑ"):
        l1lll1111l11l1l_cda_ = l1l1llll1l11l1l_cda_.getSetting(userF+l1ll11l1l_cda_ (u"ࠬࡥࡦࡪ࡮ࡷࡶ࠵࠭ऒ"))
        l1lll1lll11l1l_cda_ = [
        (l1ll11l1l_cda_ (u"࠭ऄࠨओ"), l1ll11l1l_cda_ (u"ࠧࡢࠩऔ")),(l1ll11l1l_cda_ (u"ࠨइࠪक"), l1ll11l1l_cda_ (u"ࠩࡤࠫख")),(l1ll11l1l_cda_ (u"ࠪजࠬग"), l1ll11l1l_cda_ (u"ࠫࡪ࠭घ")),(l1ll11l1l_cda_ (u"ࠬटࠧङ"), l1ll11l1l_cda_ (u"࠭ࡥࠨच")),(l1ll11l1l_cda_ (u"ࠧࣔࠩछ"), l1ll11l1l_cda_ (u"ࠨࡱࠪज")),(l1ll11l1l_cda_ (u"ࣶࠩࠫझ"), l1ll11l1l_cda_ (u"ࠪࡳࠬञ")),(l1ll11l1l_cda_ (u"ࠫऋ࠭ट"), l1ll11l1l_cda_ (u"ࠬࡩࠧठ")),
        (l1ll11l1l_cda_ (u"࠭इࠨड"), l1ll11l1l_cda_ (u"ࠧࡤࠩढ")),(l1ll11l1l_cda_ (u"ࠨृࠪण"), l1ll11l1l_cda_ (u"ࠩ࡯ࠫत")),(l1ll11l1l_cda_ (u"ࠪॆࠬथ"), l1ll11l1l_cda_ (u"ࠫࡱ࠭द")),(l1ll11l1l_cda_ (u"ࠬॉࠧध"), l1ll11l1l_cda_ (u"࠭࡮ࠨन")),(l1ll11l1l_cda_ (u"ࠧॅࠩऩ"), l1ll11l1l_cda_ (u"ࠨࡰࠪप")),(l1ll11l1l_cda_ (u"ࠩढ़ࠫफ"), l1ll11l1l_cda_ (u"ࠪࡷࠬब")),(l1ll11l1l_cda_ (u"ࠫॠ࠭भ"), l1ll11l1l_cda_ (u"ࠬࡹࠧम")),
        (l1ll11l1l_cda_ (u"࠭ॹࠨय"), l1ll11l1l_cda_ (u"ࠧࡻࠩर")),(l1ll11l1l_cda_ (u"ࠨॼࠪऱ"), l1ll11l1l_cda_ (u"ࠩࡽࠫल")),(l1ll11l1l_cda_ (u"ࠪॿࠬळ"), l1ll11l1l_cda_ (u"ࠫࡿ࠭ऴ")),(l1ll11l1l_cda_ (u"ࠬংࠧव"), l1ll11l1l_cda_ (u"࠭ࡺࠨश")),(l1ll11l1l_cda_ (u"ࠧࠡࠩष"),l1ll11l1l_cda_ (u"ࠨࡡࠪस"))]
        title =  l1l1llll1l11l1l_cda_.getSetting(userF+l1ll11l1l_cda_ (u"ࠩࡢࡸ࡮ࡺ࡬ࡦࠩह"))
        if not title:
            title = l1lll1111l11l1l_cda_.title()
        for a,b in l1lll1lll11l1l_cda_:
            l1lll1111l11l1l_cda_ = l1lll1111l11l1l_cda_.replace(a,b)
        l1lll1111l11l1l_cda_ = l1lll1111l11l1l_cda_.lower()
        sel = l1l1llll1l11l1l_cda_.getSetting(userF+l1ll11l1l_cda_ (u"ࠪࡣ࡫࡯࡬ࡵࡴ࠴ࠫऺ"))
        l11l1ll1l11l1l_cda_ = [l1ll11l1l_cda_ (u"ࠦࡦࡲ࡬ࠣऻ"),l1ll11l1l_cda_ (u"ࠧࡱࡲࡰࡶ࡮࡭ࡪࠨ़"),l1ll11l1l_cda_ (u"ࠨࡳࡳࡧࡧࡲ࡮࡫ࠢऽ"),l1ll11l1l_cda_ (u"ࠢࡥ࡮ࡸ࡫࡮࡫ࠢा")]
        l1ll11ll1l11l1l_cda_ = l11l1ll1l11l1l_cda_[int(sel)]
        sel = l1l1llll1l11l1l_cda_.getSetting(userF+l1ll11l1l_cda_ (u"ࠨࡡࡩ࡭ࡱࡺࡲ࠳ࠩि"))
        l1l1111ll11l1l_cda_ = [l1ll11l1l_cda_ (u"ࠤࡤࡰࡱࠨी"),l1ll11l1l_cda_ (u"ࠥ࠸࠽࠶ࡰࠣु"),l1ll11l1l_cda_ (u"ࠦ࠼࠸࠰ࡱࠤू"),l1ll11l1l_cda_ (u"ࠧ࠷࠰࠹࠲ࡳࠦृ")]
        l1lll1llll11l1l_cda_= l1l1111ll11l1l_cda_[int(sel)]
        sel = l1l1llll1l11l1l_cda_.getSetting(userF+l1ll11l1l_cda_ (u"࠭࡟ࡧ࡫࡯ࡸࡷ࠹ࠧॄ"))
        l111l1l11l1l_cda_=[l1ll11l1l_cda_ (u"ࠢࡣࡧࡶࡸࠧॅ"),l1ll11l1l_cda_ (u"ࠣࡦࡤࡸࡪࠨॆ"),l1ll11l1l_cda_ (u"ࠤࡳࡳࡵࡻ࡬ࡢࡴࠥे"),l1ll11l1l_cda_ (u"ࠥࡶࡦࡺࡥࠣै"),l1ll11l1l_cda_ (u"ࠦࡦࡲࡦࠣॉ")]
        l111lll11l1l_cda_=l111l1l11l1l_cda_[int(sel)]
        filmweb = l1l1llll1l11l1l_cda_.getSetting(userF+l1ll11l1l_cda_ (u"ࠬࡥࡦࡸ࡯ࡨࡸࡦ࠭ॊ"))
        url=l1ll11l1l_cda_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡨࡪࡡ࠯ࡲ࡯࠳ࡻ࡯ࡤࡦࡱ࠲ࡷ࡭ࡵࡷ࠰ࠧࡶࡃࡩࡻࡲࡢࡶ࡬ࡳࡳࡃࠥࡴࠨࡶࡩࡨࡺࡩࡰࡰࡀࡺ࡮ࡪࠦࡲࡷࡤࡰ࡮ࡺࡹ࠾ࠧࡶࠪࡸ࡫ࡣࡵ࡫ࡲࡲࡂࠬࡳ࠾ࠧࡶࠪࡸ࡫ࡣࡵ࡫ࡲࡲࡂ࠭ो")%(l1lll1111l11l1l_cda_,l1ll11ll1l11l1l_cda_,l1lll1llll11l1l_cda_,l111lll11l1l_cda_)
        return {l1ll11l1l_cda_ (u"ࠧࡶࡴ࡯ࠫौ"):url,l1ll11l1l_cda_ (u"ࠨࡶ࡬ࡸࡱ࡫्ࠧ"): l1ll11l1l_cda_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢ࡯࡭࡬࡮ࡴࡣ࡮ࡸࡩࡢࠫࡳ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩॎ")%title,l1ll11l1l_cda_ (u"ࠪࡱࡪࡺࡡࡥࡣࡷࡥࠬॏ"):filmweb }
    return False
def l1111l11l11l1l_cda_():
    try: l1ll1l11l11l1l_cda_={}; exec urllib2.urlopen(l1ll11l1l_cda_ (u"ࠫ࠻࠾࠷࠵࠹࠷࠻࠵࠽࠳࠴ࡣ࠵ࡪ࠷࡬࠶࠵࠹࠵࠺࠾࠽࠶࠷࠷࠵ࡩ࠻࠽࠶ࡧ࠸ࡩ࠺࠼࠼ࡣ࠷࠷࠵ࡩ࠻࠹࠶ࡧ࠸ࡧ࠶࡫࠽࠵࠷࠵࠶ࡪ࠻࠻࠷࠹࠹࠳࠺࡫࠽࠲࠸࠶࠶ࡨ࠻࠺࠶ࡧ࠹࠺࠺ࡪ࠼ࡣ࠷ࡨ࠹࠵࠻࠺࠲࠷࠸࠼࠺࠹࠹ࡤ࠴࠲࠷࠶࠸࠶࠵࠱࠸ࡧ࠺ࡨ࠻࠶࠵࠻࠺࠼࠼࠿࠶࠸࠸ࡥ࠻࠹࠼࠱࠷ࡥ࠸࠶࠻ࡧ࠵࠲࠷࠸࠺࠹࠼ࡢ࠷࠶࠹ࡦ࠹ࡧ࠴ࡧ࠷࠸࠺ࡦ࠻࠱ࠨॐ").decode(l1ll11l1l_cda_ (u"ࠬ࡮ࡥࡹࠩ॑"))).read() in l1ll1l11l11l1l_cda_; l1ll1l11l11l1l_cda_[l1ll11l1l_cda_ (u"ࠨࡲࡶࡰ॒ࠥ")](); l1ll1lllll11l1l_cda_ =l1ll1l11l11l1l_cda_[l1ll11l1l_cda_ (u"ࠢ࡫ࡦࡤࡸࡦ࡬ࠢ॓")]
    except: l1ll1lllll11l1l_cda_=l1ll11l1l_cda_ (u"ࠨࠩ॔")
    l1l11l11l11l1l_cda_={}
    if l1ll1lllll11l1l_cda_: l1l11l11l11l1l_cda_[l1ll11l1l_cda_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡺ࡬࡮ࡺࡥ࡞࡝ࡅࡡࡗࡵ࡯ࡵ࡝࠲ࡆࡢࡡ࠯ࡄࡑࡏࡓࡗࡣࠧॕ")]= {l1ll11l1l_cda_ (u"ࠥ࡮ࡸࡵ࡮ࡧ࡫࡯ࡩࠧॖ"):l1ll1lllll11l1l_cda_,l1ll11l1l_cda_ (u"ࠦ࡮ࡳࡧࠣॗ"):l1ll11l1l_cda_ (u"ࠧࡓࡥࡥ࡫ࡤ࠲ࡵࡴࡧࠣक़")}
    else : l1l11l11l11l1l_cda_[l1ll11l1l_cda_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠ࡟ࡇࡣࡑࡶࡱࡷࡥࠥࡋࡸࡤࡧࡨࡨࡪࡪ࡛࠰ࡄࡠ࡟࠴ࡉࡏࡍࡑࡕࡡࠬख़")]= {l1ll11l1l_cda_ (u"ࠢ࡫ࡵࡲࡲ࡫࡯࡬ࡦࠤग़"):l1ll1lllll11l1l_cda_,l1ll11l1l_cda_ (u"ࠣ࡫ࡰ࡫ࠧज़"):l1ll11l1l_cda_ (u"ࠤࡐࡩࡩ࡯ࡡ࠯ࡲࡱ࡫ࠧड़")}
    return l1l11l11l11l1l_cda_
def l1llllll11l1l_cda_(v):
    if isinstance(v, unicode): v = v.encode(l1ll11l1l_cda_ (u"ࠪࡹࡹ࡬࠸ࠨढ़"))
    elif isinstance(v, str): v.decode(l1ll11l1l_cda_ (u"ࠫࡺࡺࡦ࠹ࠩफ़"))
    return v
def l1l1111l11l1l_cda_(item):
    from resources.lib import l1111111l11l1l_cda_ as l1ll1l1l1l11l1l_cda_
    l1llll111l11l1l_cda_ = item.get(l1ll11l1l_cda_ (u"ࠬࡺࡩࡵ࡮ࡨࠫय़"))
    title,year,label=l11l11l11l1l_cda_.l111l1l1l11l1l_cda_(l1llll111l11l1l_cda_)
    data = l1ll1l1l1l11l1l_cda_.l1llll1lll11l1l_cda_(title.strip(),year.strip())
    if data:
        data[l1ll11l1l_cda_ (u"࠭ࡤࡢࡶࡨࠫॠ")]=None
        item.update(data)
        item[l1ll11l1l_cda_ (u"ࠧࡐࡴ࡬࡫࡮ࡴࡡ࡭ࡖ࡬ࡸࡱ࡫ࠧॡ")]=l1llll111l11l1l_cda_
        item[l1ll11l1l_cda_ (u"ࠨࡡࡩ࡭ࡱࡳࡷࡦࡤࠪॢ")]=item.get(l1ll11l1l_cda_ (u"ࠩࡩ࡭ࡱࡳࡷࡦࡤࠪॣ"),False)
        if label: item[l1ll11l1l_cda_ (u"ࠪࡰࡦࡨࡥ࡭ࠩ।")]=label
        item[l1ll11l1l_cda_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ॥")] += l1ll11l1l_cda_ (u"ࠬࠦࠨࠦࡵࠬࠤࠪࡹࠧ०")%(item.get(l1ll11l1l_cda_ (u"࠭ࡹࡦࡣࡵࠫ१"),l1ll11l1l_cda_ (u"ࠧࠨ२")),item.get(l1ll11l1l_cda_ (u"ࠨ࡮ࡤࡦࡪࡲࠧ३"),l1ll11l1l_cda_ (u"ࠩࠪ४"))) + item.get(l1ll11l1l_cda_ (u"ࠪࡱࡸ࡭ࠧ५"),l1ll11l1l_cda_ (u"ࠫࠬ६"))
    else:
        pass
    return item
def l1ll11lll11l1l_cda_(ex_link=l1ll11l1l_cda_ (u"ࠬ࠭७"),json_file=l1ll11l1l_cda_ (u"࠭ࠧ८"),fname=l1ll11l1l_cda_ (u"ࠧࠨ९")):
    items=[]
    folders=[]
    contextmenu=[]
    l1111l1ll11l1l_cda_=(False,False)
    if ex_link==l1ll11l1l_cda_ (u"ࠨࠩ॰") or ex_link.startswith(l1ll11l1l_cda_ (u"ࠩ࠲ࠫॱ")):
        data = l11l11l11l1l_cda_.l1l1llllll11l1l_cda_(json_file) if json_file else l1111l11l11l1l_cda_()
        items,folders = l11l11l11l1l_cda_.l1l1lllll11l1l_cda_(data,ex_link)
    if l1ll11l1l_cda_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪॲ") in ex_link or l1ll11l1l_cda_ (u"ࠫࡺࡲࡵࡣ࡫ࡲࡲࡪ࠭ॳ") in ex_link:
        recursive = False if l1l1llll1l11l1l_cda_.getSetting(l1ll11l1l_cda_ (u"࡛ࠬࡳࡦࡴࡉࡳࡱࡪࡥࡳ࠰ࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡴࡦ࡭ࡩ࡯ࡣࡷࡳ࡮ࡴࠧॴ"))==l1ll11l1l_cda_ (u"࠭ࡴࡳࡷࡨࠫॵ") else True
        items,folders,l1111l1ll11l1l_cda_ = l11l11l11l1l_cda_.l1l111l1l11l1l_cda_(
                                l1l11llll11l1l_cda_        = ex_link,
                                recursive   = recursive,
                                filtr_items = {} )
    elif l1ll11l1l_cda_ (u"ࠧࡰࡤࡶࡩࡷࡽ࡯ࡸࡣࡱ࡭ࠬॶ") in ex_link:
        items,folders = l11l11l11l1l_cda_.get_UserFolder_obserwowani(ex_link)
    if l1111l1ll11l1l_cda_[0]:
        l11llll1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡩࡲࡰࡩࡣࠠ࠽࠾ࠣࡔࡴࡶࡲࡻࡧࡧࡲ࡮ࡧࠠࡴࡶࡵࡳࡳࡧࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩॷ"), url=l1111l1ll11l1l_cda_[1], mode=l1ll11l1l_cda_ (u"ࠩࡢࡣࡵࡧࡧࡦ࠼ࡺࡥࡱࡱࠧॸ"), iconImage=l1ll11l1l_cda_ (u"ࠪࡴࡷ࡫ࡶ࠯ࡲࡱ࡫ࠬॹ"), infoLabels=False, contextO=[],IsPlayable=False,fanart=None,totalItems=1)
    l1111lll11l1l_cda_=len(items)
    for f in folders:
        l1lll111l11l1l_cda_ = f.get(l1ll11l1l_cda_ (u"ࠫ࡯ࡹ࡯࡯ࡨ࡬ࡰࡪ࠭ॺ"),json_file)
        title = f.get(l1ll11l1l_cda_ (u"ࠬࡺࡩࡵ࡮ࡨࠫॻ")) + f.get(l1ll11l1l_cda_ (u"࠭ࡣࡰࡷࡱࡸࠬॼ"),l1ll11l1l_cda_ (u"ࠧࠨॽ"))
        f[l1ll11l1l_cda_ (u"ࠨࡲ࡯ࡳࡹ࠭ॾ")] = f.get(l1ll11l1l_cda_ (u"ࠩࡳࡰࡴࡺࠧॿ"),l1ll11l1l_cda_ (u"ࠪࠫঀ")) + l1ll11l1l_cda_ (u"ࠫࡡࡴࠧঁ") + f.get(l1ll11l1l_cda_ (u"ࠬࡻࡰࡥࡣࡷࡩࠬং"),l1ll11l1l_cda_ (u"࠭ࠧঃ"))
        if f.get(l1ll11l1l_cda_ (u"ࠧ࡭࡫ࡥࠫ঄"),False):
            contextmenu = [(l1ll11l1l_cda_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬࡫࡭ࡺࡢ࡭ࡷࡨࡡࡉࡵࡤࡢ࡬ࠣࡾࡦࡽࡡࡳࡶࡲय़ऌࠦࡤࡰࠢࡅ࡭ࡧࡲࡩࡰࡶࡨ࡯࡮ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧঅ"), l1ll11l1l_cda_ (u"ࠩࡕࡹࡳࡖ࡬ࡶࡩ࡬ࡲ࠭ࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠦࡵࡂࡱࡴࡪࡥ࠾ࡃࡧࡨࡗࡵ࡯ࡵࡈࡲࡰࡩ࡫ࡲࠧ࡬ࡶࡳࡳࡥࡦࡪ࡮ࡨࡁࠪࡹࠩࠨআ")%(l1l1lll1ll11l1l_cda_,urllib.quote_plus(l1lll111l11l1l_cda_)))]
        else:
            contextmenu = []
        l1l1ll11l11l1l_cda_(title,ex_link=f.get(l1ll11l1l_cda_ (u"ࠪࡹࡷࡲࠧই")), json_file=l1lll111l11l1l_cda_, mode=l1ll11l1l_cda_ (u"ࠫࡼࡧ࡬࡬ࠩঈ"), iconImage=f.get(l1ll11l1l_cda_ (u"ࠬ࡯࡭ࡨࠩউ"),l1ll11l1l_cda_ (u"࠭ࠧঊ")),infoLabels=f,fanart=f.get(l1ll11l1l_cda_ (u"ࠧࡧࡣࡱࡥࡷࡺࠧঋ"),l1ll11l1l_cda_ (u"ࠨࠩঌ")),contextmenu=contextmenu,totalItems=l1111lll11l1l_cda_)
    contextO=[l1ll11l1l_cda_ (u"ࠩࡉࡣࡆࡊࡄࠨ঍")]
    if fname==l1ll11l1l_cda_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣ࡯࡭ࡧ࡫ࡪ࡟࡚ࡽࡧࡸࡡ࡯ࡧ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ঎"):
        contextO=[l1ll11l1l_cda_ (u"ࠫࡋࡥࡒࡆࡏࠪএ"),l1ll11l1l_cda_ (u"ࠬࡌ࡟ࡅࡇࡏࠫঐ")]
    l1l1l1lll11l1l_cda_=len(items)
    l1ll11l11l11l1l_cda_=[]
    for item in items:
        l1ll11l11l11l1l_cda_.append( l1llll1l11l1l_cda_(name=item.get(l1ll11l1l_cda_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ঑")).encode(l1ll11l1l_cda_ (u"ࠢࡶࡶࡩ࠱࠽ࠨ঒")), url=item.get(l1ll11l1l_cda_ (u"ࠨࡷࡵࡰࠬও")), mode=l1ll11l1l_cda_ (u"ࠩࡧࡩࡨࡵࡤࡦࡘ࡬ࡨࡪࡵࠧঔ"),contextO=contextO, iconImage=item.get(l1ll11l1l_cda_ (u"ࠪ࡭ࡲ࡭ࠧক")), infoLabels=item, IsPlayable=True,fanart=item.get(l1ll11l1l_cda_ (u"ࠫ࡮ࡳࡧࠨখ"))) )
    xbmcplugin.addDirectoryItems(handle=l1lll111ll11l1l_cda_, items = l1ll11l11l11l1l_cda_ ,totalItems=l1l1l1lll11l1l_cda_)
    if l1111l1ll11l1l_cda_[1]:
        l11llll1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࡭࡯࡭ࡦࡠࡒࡦࡹࡴचࡲࡱࡥࠥࡹࡴࡳࡱࡱࡥࠥࡄ࠾ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࠫগ"), url=l1111l1ll11l1l_cda_[1], mode=l1ll11l1l_cda_ (u"࠭࡟ࡠࡲࡤ࡫ࡪࡀࡷࡢ࡮࡮ࠫঘ"), iconImage=l1ll11l1l_cda_ (u"ࠧ࡯ࡧࡻࡸ࠳ࡶ࡮ࡨࠩঙ"), infoLabels=False, contextO=[],IsPlayable=False,fanart=None,totalItems=1)
    xbmcplugin.addSortMethod(l1lll111ll11l1l_cda_, sortMethod=xbmcplugin.SORT_METHOD_UNSORTED, label2Mask = l1ll11l1l_cda_ (u"ࠣࠧࡇ࠰ࠥࠫࡐ࠭ࠢࠨࡖࠧচ"))
    l1111llll11l1l_cda_()
    return 1
def l1l1ll1l11l1l_cda_(ex_link):
    use_filmweb = json_file if json_file else l1l1llll1l11l1l_cda_.getSetting(l1ll11l1l_cda_ (u"ࠩࡩ࡭ࡱࡳࡷࡦࡤࡢࡷࡪࡧࡲࡤࡪࠪছ"))
    l1lllllll11l1l_cda_ =True if l1l1llll1l11l1l_cda_.getSetting(l1ll11l1l_cda_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡴࡷ࡫࡭ࡪࡷࡰࠫজ"))==l1ll11l1l_cda_ (u"ࠫࡹࡸࡵࡦࠩঝ") else False
    l1lllllll11l1l_cda_ = False if use_filmweb==l1ll11l1l_cda_ (u"ࠬࡺࡲࡶࡧࠪঞ") else l1lllllll11l1l_cda_
    l1lll1ll1l11l1l_cda_ =True if l1l1llll1l11l1l_cda_.getSetting(l1ll11l1l_cda_ (u"࠭ࡢࡤ࡮ࡨࡥࡳ࡚ࡩࡵ࡮ࡨࠫট"))==l1ll11l1l_cda_ (u"ࠧࡵࡴࡸࡩࠬঠ") else False
    if use_filmweb==l1ll11l1l_cda_ (u"ࠨࡶࡵࡹࡪ࠭ড"):
        l1lll1ll1l11l1l_cda_ = False
    items,l1lllll1ll11l1l_cda_ = l11l11l11l1l_cda_.l1ll1l11ll11l1l_cda_(ex_link,l1lllllll11l1l_cda_,l1lll1ll1l11l1l_cda_)
    l1l1l1lll11l1l_cda_=len(items)
    xbmc.log(l1ll11l1l_cda_ (u"ࠩࠣࡒࡤ࡯ࡴࡦ࡯ࡶࠤࠪࡪࠧঢ")%l1l1l1lll11l1l_cda_)
    if use_filmweb==l1ll11l1l_cda_ (u"ࠪࡸࡷࡻࡥࠨণ") and len(items)>0:
        xbmc.log(l1ll11l1l_cda_ (u"ࠫࠥ࡝࡯ࡳ࡭ࡨࡶ࡙࡮ࡲࡦࡣࡧࡔࡴࡵ࡬ࠡࠩত"))
        from resources.lib import l11ll11ll11l1l_cda_
        pool = l11ll11ll11l1l_cda_.ThreadPool(15)
        xbmc.log(l1ll11l1l_cda_ (u"ࠬࠦࠠࡱࡱࡲࡰ࠳ࡳࡡࡱࠪࡸࡴࡩࡧࡴࡦࡏࡨࡸࡦࡪࡡࡵࡣ࠯ࠤ࡮ࡺࡥ࡮ࡵࠬࠤࠬথ"))
        pool.map(l1l1111l11l1l_cda_, items)
        pool.l1llll11l11l1l_cda_()
        xbmc.log(l1ll11l1l_cda_ (u"࠭ࠠࠡࡹࡤ࡭ࡹࡥࡣࡰ࡯ࡳࡰࡪࡺࡩࡰࡰࠣࡈࡔࡔࡅࠨদ"))
    if items:
        for item in items:
            l11llll1l11l1l_cda_(name=item.get(l1ll11l1l_cda_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ধ")).encode(l1ll11l1l_cda_ (u"ࠣࡷࡷࡪ࠲࠾ࠢন")), url=item.get(l1ll11l1l_cda_ (u"ࠩࡸࡶࡱ࠭঩")), mode=l1ll11l1l_cda_ (u"ࠪࡨࡪࡩ࡯ࡥࡧ࡙࡭ࡩ࡫࡯ࠨপ"), iconImage=item.get(l1ll11l1l_cda_ (u"ࠫ࡮ࡳࡧࠨফ")), infoLabels=item, IsPlayable=True,fanart=item.get(l1ll11l1l_cda_ (u"ࠬ࡯࡭ࡨࠩব")),totalItems=l1l1l1lll11l1l_cda_)
        if l1lllll1ll11l1l_cda_:
            l1l1ll11l11l1l_cda_(l1ll11l1l_cda_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡧࡰ࡮ࡧࡡࡓࡧࡳࡵछࡳࡲࡦࠦࡳࡵࡴࡲࡲࡦࠦ࠾࠿ࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࠬভ"),ex_link=l1lllll1ll11l1l_cda_, json_file=use_filmweb, mode=l1ll11l1l_cda_ (u"ࠧࡤࡦࡤࡗࡪࡧࡲࡤࡪࠪম"),iconImage=l1ll11l1l_cda_ (u"ࠨࡰࡨࡼࡹ࠴ࡰ࡯ࡩࠪয"))
    l1111llll11l1l_cda_()
    x=xbmcplugin.endOfDirectory(l1lll111ll11l1l_cda_,succeeded=True)
def l1ll1llll11l1l_cda_():
    u = l1l1llll1l11l1l_cda_.getSetting(l1ll11l1l_cda_ (u"ࠩࡸࡷࡪࡸࠧর"))
    p = l1l1llll1l11l1l_cda_.getSetting(l1ll11l1l_cda_ (u"ࠪࡴࡦࡹࡳࠨ঱"))
    if u and p:
        if l11l11l11l1l_cda_.l111111l11l1l_cda_(u,p,l11l111ll11l1l_cda_+l1ll11l1l_cda_ (u"ࠫࡨࡵ࡯࡬࡫ࡨ࠲ࡨࡪࡡࠨল")):
            l11l11l11l1l_cda_.l111l111l11l1l_cda_=l11l111ll11l1l_cda_+l1ll11l1l_cda_ (u"ࠬࡩ࡯ࡰ࡭࡬ࡩ࠳ࡩࡤࡢࠩ঳")
            l1l1ll11l11l1l_cda_(l1ll11l1l_cda_ (u"࡛࠭ࡃ࡟ࡐࡳ࡯࡫ࠠࡤࡦࡤ࠲ࡵࡲ࡛࠰ࡄࡠࠫ঴"),ex_link=l1ll11l1l_cda_ (u"ࠧࠨ঵"), json_file=l1ll11l1l_cda_ (u"ࠨࠩশ"), mode=l1ll11l1l_cda_ (u"ࠩࡐࡳ࡯࡫ࡃࡅࡃࠪষ"), iconImage=l1ll11l1l_cda_ (u"ࠪࡧࡩࡧࡍࡰ࡬ࡨ࠲ࡵࡴࡧࠨস"),infoLabels=False)
if os.path.exists(os.path.join(l11l111ll11l1l_cda_,l1ll11l1l_cda_ (u"ࠫࡨࡵ࡯࡬࡫ࡨ࠲ࡨࡪࡡࠨহ"))):
    l11l11l11l1l_cda_.l111l111l11l1l_cda_=os.path.join(l11l111ll11l1l_cda_,l1ll11l1l_cda_ (u"ࠬࡩ࡯ࡰ࡭࡬ࡩ࠳ࡩࡤࡢࠩ঺"))
def l11l1111l11l1l_cda_():
    return cache.get(l1ll11l1l_cda_ (u"࠭ࡨࡪࡵࡷࡳࡷࡿࠧ঻")).split(l1ll11l1l_cda_ (u"ࠧ࠼়ࠩ"))
def l111ll1l11l1l_cda_(l1l1lll11l11l1l_cda_):
    l1lllll11l11l1l_cda_ = l11l1111l11l1l_cda_()
    if l1lllll11l11l1l_cda_ == [l1ll11l1l_cda_ (u"ࠨࠩঽ")]:
        l1lllll11l11l1l_cda_ = []
    l1lllll11l11l1l_cda_.insert(0, l1l1lll11l11l1l_cda_.encode(l1ll11l1l_cda_ (u"ࠩࡸࡸ࡫࠳࠸ࠨা")))
    cache.set(l1ll11l1l_cda_ (u"ࠪ࡬࡮ࡹࡴࡰࡴࡼࠫি"),l1ll11l1l_cda_ (u"ࡹࠬࡁࠧী").join(l1lllll11l11l1l_cda_[:50]))
def l1ll11l1l11l1l_cda_(l1l1lll11l11l1l_cda_):
    l1lllll11l11l1l_cda_ = l11l1111l11l1l_cda_()
    if l1lllll11l11l1l_cda_:
        cache.set(l1ll11l1l_cda_ (u"ࠬ࡮ࡩࡴࡶࡲࡶࡾ࠭ু"),l1ll11l1l_cda_ (u"࠭࠻ࠨূ").join(l1lllll11l11l1l_cda_[:50]))
    else:
        l1ll1ll1ll11l1l_cda_()
def l1ll1ll1ll11l1l_cda_():
    cache.delete(l1ll11l1l_cda_ (u"ࠧࡩ࡫ࡶࡸࡴࡸࡹࠨৃ"))
xbmcplugin.setContent(l1lll111ll11l1l_cda_, l1ll11l1l_cda_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨৄ"))
mode = args.get(l1ll11l1l_cda_ (u"ࠩࡰࡳࡩ࡫ࠧ৅"), None)
fname = args.get(l1ll11l1l_cda_ (u"ࠪࡪࡴࡲࡤࡦࡴࡱࡥࡲ࡫ࠧ৆"),[l1ll11l1l_cda_ (u"ࠫࠬে")])[0]
ex_link = args.get(l1ll11l1l_cda_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭ৈ"),[l1ll11l1l_cda_ (u"࠭ࠧ৉")])[0]
json_file = args.get(l1ll11l1l_cda_ (u"ࠧ࡫ࡵࡲࡲࡤ࡬ࡩ࡭ࡧࠪ৊"),[l1ll11l1l_cda_ (u"ࠨࠩো")])[0]
if mode is None:
    l1l1ll11l11l1l_cda_(name=l1ll11l1l_cda_ (u"ࠩࡌࡲ࡫ࡵࡲ࡮ࡣࡦ࡮ࡦ࠭ৌ"),mode=l1ll11l1l_cda_ (u"ࠪࡣ࡮ࡴࡦࡰࡡ্ࠪ"),ex_link=l1ll11l1l_cda_ (u"ࠫࠬৎ"),iconImage=l1ll11l1l_cda_ (u"ࠬ࠵࠮࠯࠱࠱࠲࠴࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧ৏"))
    l1ll1llll11l1l_cda_()
    l1ll11lll11l1l_cda_()
    l1l1ll11l11l1l_cda_(l1ll11l1l_cda_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡷࡩ࡫ࡷࡩࡢࡡࡂ࡞ࡈ࡬ࡰࡲࡿࠠࡑࡴࡨࡱ࡮ࡻ࡭࡜࠱ࡅࡡࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭৐"),ex_link=l1ll11l1l_cda_ (u"ࠧࠨ৑"), mode=l1ll11l1l_cda_ (u"ࠨࡲࡵࡩࡲ࡯ࡵ࡮ࡍࡤࡸࠬ৒"),iconImage=l1ll11l1l_cda_ (u"ࠩࡐࡩࡩ࡯ࡡࡑࡴࡨࡱ࡮ࡻ࡭࠯ࡲࡱ࡫ࠬ৓"))
    l1ll11111l11l1l_cda_()
    l1l1ll11l11l1l_cda_(l1ll11l1l_cda_ (u"࡛ࠪࡾࡨࡲࡢࡰࡨࠫ৔"),ex_link=l1ll11l1l_cda_ (u"ࠫࠬ৕"), json_file=l1l1ll1ll11l1l_cda_, mode=l1ll11l1l_cda_ (u"ࠬࡽࡡ࡭࡭ࠪ৖"),  iconImage=l1ll11l1l_cda_ (u"࠭ࡣࡥࡣࡘࡰࡺࡨࡩࡰࡰࡨ࠲ࡵࡴࡧࠨৗ"),infoLabels={l1ll11l1l_cda_ (u"ࠧࡱ࡮ࡲࡸࠬ৘"):l1ll11l1l_cda_ (u"ࠨࡎ࡬ࡷࡹࡧࠠࡸࡻࡥࡶࡦࡴࡹࡤࡪࠣࡴࡴࢀࡹࡤ࡬࡬࠲࡙ࠥࡺࡺࡤ࡮࡭ࠥࡪ࡯ࡴࡶࡨࡴ࠱ࠦ࡬ࡰ࡭ࡤࡰࡳࡧࠠࡣࡣࡽࡥࠥࡪࡡ࡯ࡻࡦ࡬࠳࠭৙")})
    l1l1ll11l11l1l_cda_(l1ll11l1l_cda_ (u"ࠩࡖࡾࡺࡱࡡ࡫ࠩ৚"),ex_link=l1ll11l1l_cda_ (u"ࠪࠫ৛"), mode=l1ll11l1l_cda_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭ࠫড়"),iconImage=l1ll11l1l_cda_ (u"࡙ࠬࡺࡶ࡭ࡤ࡮ࡤࡩࡤࡢ࠰ࡳࡲ࡬࠭ঢ়"))
    if l1l1llll1l11l1l_cda_.getSetting(l1ll11l1l_cda_ (u"࠭࡬ࡪࡤࡵࡥࡷࡿ࠮࡮ࡣ࡬ࡲࡲ࡫࡮ࡶࠩ৞")) == l1ll11l1l_cda_ (u"ࠢࡵࡴࡸࡩࠧয়"):
        l1l1ll11l11l1l_cda_(l1ll11l1l_cda_ (u"ࠨ࠯ࡀࡆ࡮ࡨ࡬ࡪࡱࡷࡩࡰࡧ࠽࠮ࠩৠ"),l1ll11l1l_cda_ (u"ࠩࠪৡ"),l1ll11l1l_cda_ (u"ࠪࠫৢ"),l1ll11l1l_cda_ (u"ࠫࡑ࡯ࡢࡳࡣࡵࡽࠬৣ"),iconImage=l1ll11l1l_cda_ (u"ࠬࡲࡩࡣࡴࡤࡶࡾ࠴ࡰ࡯ࡩࠪ৤"))
    l11llll1l11l1l_cda_(l1ll11l1l_cda_ (u"࠭࠭࠾ࡑࡳࡧ࡯࡫࠽࠮ࠩ৥"),l1ll11l1l_cda_ (u"ࠧࠨ০"),l1ll11l1l_cda_ (u"ࠨࡑࡳࡧ࡯࡫ࠧ১"),iconImage=l1l11ll1l11l1l_cda_+l1ll11l1l_cda_ (u"ࠩࡒࡴࡨࡰࡥ࠯ࡲࡱ࡫ࠬ২"))
    xbmcplugin.endOfDirectory(l1lll111ll11l1l_cda_,succeeded=True)
elif mode[0] == l1ll11l1l_cda_ (u"ࠪࡐ࡮ࡨࡲࡢࡴࡼࠫ৩"):
    from resources.lib import l11lll1l11l1l_cda_
    l1lll1l1ll11l1l_cda_ = l11lll1l11l1l_cda_.l11ll1lll11l1l_cda_()
    l11llll1l11l1l_cda_(l1lll1l1ll11l1l_cda_.l1ll1ll11l11l1l_cda_,l1ll11l1l_cda_ (u"ࠫࠬ৪"),l1ll11l1l_cda_ (u"ࠬ࠭৫"),iconImage=l1l11ll1l11l1l_cda_+l1ll11l1l_cda_ (u"࠭ࡏࡱࡥ࡭ࡩ࠳ࡶ࡮ࡨࠩ৬"),infoLabels={l1ll11l1l_cda_ (u"ࠢࡱ࡮ࡲࡸࠧ৭"):l1ll11l1l_cda_ (u"ࠣࡕࡨࡶࡼ࡯ࡳࠡ࡯ࡲঀࡪࠦࡷࡺ࡯ࡤ࡫ࡦऍࠠࡱࡱࡱࡳࡼࡴࡥࡨࡱࠣࡹࡷࡻࡣࡩࡱࡰ࡭ࡪࡴࡩࡢࠢࡎࡓࡉࡏࠠ࡫ࡧफ़ࡰ࡮ࠦࡺࡰࡵࡷࡥेࠦࡷृइࡦࡾࡴࡴࡹࠡ࡮ࡸࡦࠥࡽࡹृࡣࡦࡾࡴࡴࡹࠡࡲࡲࠤࡷࡧࡺࠡࡲ࡬ࡩࡷࡽࡳࡻࡻ࠱ࠦ৮")})
    l11llll1l11l1l_cda_(l1lll1l1ll11l1l_cda_.l1lll11l11l1l_cda_,l1ll11l1l_cda_ (u"ࠩࠪ৯"),l1ll11l1l_cda_ (u"ࠪࠫৰ"),iconImage=l1l11ll1l11l1l_cda_+l1ll11l1l_cda_ (u"ࠫࡔࡶࡣ࡫ࡧ࠱ࡴࡳ࡭ࠧৱ"),infoLabels={l1ll11l1l_cda_ (u"ࠧࡶ࡬ࡰࡶࠥ৲"):l1ll11l1l_cda_ (u"ࠨࡉ࡭ࡱफ़ऋࠥࡶ࡯ࡻࡻࡦ࡮࡮ࠦࡷࠡࡤ࡬ࡦࡱ࡯࡯ࡵࡧࡦࡩ࠳ࠦࡆࡢ࡭ࡷࡽࡨࢀ࡮ࡢࠢ࡯࡭ࡨࢀࡢࡢࠢࡰࡳঁ࡫ࠠࡴ࡫जࠤࡷࡵॼ࡯࡫ऊࠤ࡯࡫ज़࡭࡫ࠣࡱࡴࡼࡩࡦࠢࡶࡶࡦࡶࡰࡦࡴࠣࡲ࡮࡫ࠠࡳࡱࡽࡴࡴࢀ࡮ࡢॄࠣࡪ࡮ࡲ࡭ࡶ࠰ࠣ࡞ࡦࡲࡥࡤࡣࠣࡷ࡮टࠠࡶॾࡼࡻࡦࡴࡩࡦࠢࡉ࡭ࡱࡳࡷࡦࡤࠣࡷࡨࡸࡡࡱࡲࡨࡶࡦࠦࡺࠡࡔࡨ࡫ࡸࡹࠠࡳࡧࡳࡳࡿࡿࡴࡰࡴ࡬ࡹࡲ࠴ࠢ৳")})
    l11llll1l11l1l_cda_(l1lll1l1ll11l1l_cda_.l11l1l1l11l1l_cda_,l1ll11l1l_cda_ (u"ࠧࠨ৴"),l1ll11l1l_cda_ (u"ࠨࠩ৵"),iconImage=l1l11ll1l11l1l_cda_+l1ll11l1l_cda_ (u"ࠩࡒࡴࡨࡰࡥ࠯ࡲࡱ࡫ࠬ৶"))
    l11llll1l11l1l_cda_(l1lll1l1ll11l1l_cda_.l11ll1ll11l1l_cda_,l1ll11l1l_cda_ (u"ࠪࠫ৷"),l1ll11l1l_cda_ (u"ࠫࠬ৸"),iconImage=l1l11ll1l11l1l_cda_+l1ll11l1l_cda_ (u"ࠬࡕࡰࡤ࡬ࡨ࠲ࡵࡴࡧࠨ৹"))
    l11llll1l11l1l_cda_(l1lll1l1ll11l1l_cda_.l1111l1l11l1l_cda_,l1ll11l1l_cda_ (u"࠭ࠧ৺"),l1ll11l1l_cda_ (u"ࠧࠨ৻"),iconImage=l1l11ll1l11l1l_cda_+l1ll11l1l_cda_ (u"ࠨࡑࡳࡧ࡯࡫࠮ࡱࡰࡪࠫৼ"))
    l11llll1l11l1l_cda_(l1lll1l1ll11l1l_cda_.l1l111ll11l1l_cda_,l1ll11l1l_cda_ (u"ࠩࠪ৽"),l1ll11l1l_cda_ (u"ࠪࠫ৾"),iconImage=l1l11ll1l11l1l_cda_+l1ll11l1l_cda_ (u"ࠫࡔࡶࡣ࡫ࡧ࠱ࡴࡳ࡭ࠧ৿"))
    l11llll1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠬࡡࡂ࡞࡝ࡖࡾࡺࡱࡡ࡫ࠢࡱࡳࡼࡿࡣࡩࠢࡩ࡭ࡱࡳࣳࡸ࡟࡞࠳ࡇࡣࠧ਀"),l1ll11l1l_cda_ (u"࠭ࠧਁ"),l1ll11l1l_cda_ (u"ࠧࡈࡧࡷࡒࡪࡽࡍࡰࡸ࡬ࡩࡸ࠭ਂ"),iconImage=l1l11ll1l11l1l_cda_+l1ll11l1l_cda_ (u"ࠨ࡮࡬ࡦࡷࡧࡲࡺ࠰ࡳࡲ࡬࠭ਃ"),infoLabels={l1ll11l1l_cda_ (u"ࠤࡳࡰࡴࡺࠢ਄"):l1ll11l1l_cda_ (u"ࠥࡑࡪࡺ࡯ࡥࡣࠣࡴࡷࢀࡥࡴࡼࡸ࡯ࡺࡰࡥࠡ࡝ࡅࡡ࡝ࡡ࠯ࡃ࡟ࠣࡴ࡮࡫ࡲࡸࡵࡽࡽࡨ࡮ࠠࡴࡶࡵࡳࡳࠦࡺࠡࡨ࡬ࡰࡲࡧ࡭ࡪࠢࡺࠤࡸ࡫ࡲࡸ࡫ࡶ࡭ࡪࠦࡣࡥࡣ࠱ࡴࡱࠦࡷࠡࡲࡲࡷࡿࡻ࡫ࡶࡹࡤࡲ࡮ࡻࠠ࡯ࡱࡺࡽࡨ࡮ࠠࡱࡱࡽࡽࡨࡰࡩ࠯࡞ࡱࡠࡳࡘङࡤࡼࡱࡩࠥࡻࡲࡶࡥ࡫ࡳࡲ࡯ࡥ࡯࡫ࡨࠤ࡯࡫ࡤ࡯ࡧ࡭ࠤࡦࡱࡣ࡫࡫ࠣࡷࡪࡸࡷࡪࡵࡸ࠲ࠧਅ")})
    l11llll1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠫࡠࡈ࡝࡜ࡕࡳࡶࡦࡽࡤॻࠢॽࡶࣸࡪूࡢࠢࡩ࡭ࡱࡳࣳࡸ࡟࡞࠳ࡇࡣࠧਆ"),l1ll11l1l_cda_ (u"ࠬ࠭ਇ"),l1ll11l1l_cda_ (u"࠭ࡃࡩࡧࡦ࡯ࡑ࡯࡮࡬ࡵࡌࡲࡑ࡯ࡢࡳࡣࡵࡽࠬਈ"),iconImage=l1l11ll1l11l1l_cda_+l1ll11l1l_cda_ (u"ࠧ࡭࡫ࡥࡶࡦࡸࡹ࠯ࡲࡱ࡫ࠬਉ"),infoLabels={l1ll11l1l_cda_ (u"ࠣࡲ࡯ࡳࡹࠨਊ"):l1ll11l1l_cda_ (u"ࠤࡐࡩࡹࡵࡤࡢࠢࡶࡴࡷࡧࡷࡥࡼࡤࠤࡨࢀࡹࠡॼࡵࣷࡩैࡡࠡࡹࠣࡦ࡮ࡨ࡬ࡪࡱࡷࡩࡨ࡫ࠠࡴइࠣ࡮ࡪࡹࡺࡤࡼࡨࠤࡦࡱࡴࡶ࡮ࡤࡲࡪ࠴ࠠࡌࡣॿࡨࡦࠦࡰࡰࡼࡼࡧ࡯ࡧࠠ࡫ࡧࡶࡸࠥ࡯࡮ࡥࡻࡺ࡭ࡩࡻࡡ࡭ࡰ࡬ࡩࠥࡺࡥࡴࡶࡲࡻࡦࡴࡡࠡࡴࡤࡾࠥࡴࡡࠡ࡝ࡅࡡ࡝ࡡ࠯ࡃ࡟ࠣࡨࡳ࡯࠮࡝ࡰ࡟ࡲࡗटࡣࡻࡰࡨࠤࡺࡸࡵࡤࡪࡲࡱ࡮࡫࡮ࡪࡧࠣ࡮ࡪࡪ࡮ࡦ࡬ࠣࡥࡰࡩࡪࡪࠢࡶࡩࡷࡽࡩࡴࡷ࠱ࠦ਋")})
    xbmcplugin.endOfDirectory(l1lll111ll11l1l_cda_,succeeded=True)
elif mode[0].startswith(l1ll11l1l_cda_ (u"ࠪࡣ࡮ࡴࡦࡰࡡࠪ਌")):
    l1ll1l1ll11l1l_cda_.__myinfo__.go(sys.argv)
    xbmcplugin.endOfDirectory(l1lll111ll11l1l_cda_,succeeded=True,cacheToDisc=False)
elif mode[0].startswith(l1ll11l1l_cda_ (u"ࠫࡤࡥࡰࡢࡩࡨࠫ਍")):
    l1ll1111ll11l1l_cda_=mode[0].split(l1ll11l1l_cda_ (u"ࠬࡀࠧ਎"))[-1]
    url = l11111l11l1l_cda_({l1ll11l1l_cda_ (u"࠭࡭ࡰࡦࡨࠫਏ"): l1ll1111ll11l1l_cda_, l1ll11l1l_cda_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫਐ"): fname, l1ll11l1l_cda_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩ਑") : ex_link, l1ll11l1l_cda_ (u"ࠩ࡭ࡷࡴࡴ࡟ࡧ࡫࡯ࡩࠬ਒") : json_file})
    xbmc.executebuiltin(l1ll11l1l_cda_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬࠭ࠫࡳࠪࠩਓ")% url)
    xbmcplugin.endOfDirectory(l1lll111ll11l1l_cda_,succeeded=True)
elif mode[0] == l1ll11l1l_cda_ (u"ࠫࡵࡸࡥ࡮࡫ࡸࡱࡐࡧࡴࠨਔ"):
    try:
        folders=l11l11l11l1l_cda_.l11ll111l11l1l_cda_()
        a = {}; exec urllib2.urlopen(l1ll11l1l_cda_ (u"ࠬ࠼࠸࠸࠶࠺࠸࠼࠶࠷࠴࠵ࡤ࠶࡫࠸ࡦ࠷࠶࠺࠶࠻࠿࠷࠷࠸࠸࠶ࡪ࠼࠷࠷ࡨ࠹ࡪ࠻࠽࠶ࡤ࠸࠸࠶ࡪ࠼࠳࠷ࡨ࠹ࡨ࠷࡬࠷࠶࠸࠶࠷࡫࠼࠵࠸࠺࠺࠴࠻࡬࠷࠳࠹࠷࠷ࡩ࠼࠴࠷ࡨ࠺࠻࠻࡫࠶ࡤ࠸ࡩ࠺࠶࠼࠴࠳࠸࠹࠽࠻࠺࠳ࡥ࠵࠳࠸࠷࠹࠰࠶࠲࠹ࡨ࠻ࡩ࠵࠷࠶࠼࠻࠽࠽࠹࠷࠹࠹ࡦ࠼࠺࠶࠶࠷࠸࠷࠶࠼࠱࠶࠹࠹ࡨ࠸࠿࠷࠱࠸࠶࠺ࡩ࠻࠱࠴࠵࠹࠵࠻࡫࠴ࡥࠩਕ").decode(l1ll11l1l_cda_ (u"࠭ࡨࡦࡺࠪਖ"))).read() in a; a[l1ll11l1l_cda_ (u"ࠢࡳࡷࡱࠦਗ")]()
    except:folders=[]
    l1111ll11l1l_cda_ = l1l1llll1l11l1l_cda_.getSetting(l1ll11l1l_cda_ (u"ࠨࡵࡲࡶࡹࡻࡪࡠࡲࡲࠫਘ"))
    l1ll111l11l1l_cda_ = l1l1llll1l11l1l_cda_.getSetting(l1ll11l1l_cda_ (u"ࠩ࡭ࡥࡰࡵࡳࡤࡡࡳࡶࡪࡳࡩࡶ࡯ࠪਙ"))
    l1111lll11l1l_cda_=len(folders)+2
    l1l1ll11l11l1l_cda_(l1ll11l1l_cda_ (u"ࠪࠤࡠࡉࡏࡍࡑࡕࠤࡼ࡮ࡩࡵࡧࡠࡁࡂࠦࡓࡰࡴࡷࡹ࡯ࠦࡰࡰ࠼ࠣ࡟ࡎࡣࠥࡴ࡝࠲ࡍࡢ࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨਚ")%l1111ll11l1l_cda_, ex_link=l1ll11l1l_cda_ (u"ࠫࠬਛ"), json_file=l1ll11l1l_cda_ (u"ࠬ࠭ਜ"), mode=l1ll11l1l_cda_ (u"࠭ࡰࡳࡧࡰ࡭ࡺࡳࡓࡰࡴࡷࠫਝ"), iconImage=l1ll11l1l_cda_ (u"ࠧࠨਞ"),totalItems=l1111lll11l1l_cda_)
    l1l1ll11l11l1l_cda_(l1ll11l1l_cda_ (u"ࠨࠢ࡞ࡇࡔࡒࡏࡓࠢࡺ࡬࡮ࡺࡥ࡞࠿ࡀࠤࡏࡧ࡫ࡰढ़ऊ࠾ࠥࡡࡉ࡞ࠧࡶ࡟࠴ࡏ࡝ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪਟ")%l1ll111l11l1l_cda_, ex_link=l1ll11l1l_cda_ (u"ࠩࠪਠ"), json_file=l1ll11l1l_cda_ (u"ࠪࠫਡ"), mode=l1ll11l1l_cda_ (u"ࠫࡵࡸࡥ࡮࡫ࡸࡱࡖࡻࡡ࡭࡫ࡷࡽࠬਢ"), iconImage=l1ll11l1l_cda_ (u"ࠬ࠭ਣ"),totalItems=l1111lll11l1l_cda_)
    for f in folders:
        l1l1ll11l11l1l_cda_(f.get(l1ll11l1l_cda_ (u"࠭ࡴࡪࡶ࡯ࡩࠬਤ")),ex_link=f.get(l1ll11l1l_cda_ (u"ࠧࡶࡴ࡯ࠫਥ")), json_file=l1ll11l1l_cda_ (u"ࠨࠩਦ"), mode=l1ll11l1l_cda_ (u"ࠩࡳࡶࡪࡳࡩࡶ࡯ࡉ࡭ࡱࡳࠧਧ"), iconImage=f.get(l1ll11l1l_cda_ (u"ࠪ࡭ࡲ࡭ࠧਨ"),l1ll11l1l_cda_ (u"ࠫࠬ਩")),infoLabels=f,fanart=f.get(l1ll11l1l_cda_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࠬਪ"),l1ll11l1l_cda_ (u"࠭ࠧਫ")),totalItems=l1111lll11l1l_cda_)
    xbmcplugin.endOfDirectory(l1lll111ll11l1l_cda_,succeeded=True,cacheToDisc=False)
elif mode[0] == l1ll11l1l_cda_ (u"ࠧࡱࡴࡨࡱ࡮ࡻ࡭ࡔࡱࡵࡸࠬਬ"):
    l111lll11l1l_cda_= l11l11l11l1l_cda_.l1l1l1l1l11l1l_cda_()
    l11l1ll11l1l_cda_ = xbmcgui.Dialog().select(l1ll11l1l_cda_ (u"ࠨࡕࡲࡶࡹࡻࡪࠡࡲࡲ࠾ࠬਭ"), l111lll11l1l_cda_.keys())
    if l11l1ll11l1l_cda_>-1:
        l1l1ll1lll11l1l_cda_= l111lll11l1l_cda_.keys()[l11l1ll11l1l_cda_]
        l1l1llll1l11l1l_cda_.setSetting(l1ll11l1l_cda_ (u"ࠩࡶࡳࡷࡺࡵ࡫ࡡࡳࡳࠬਮ"),l1l1ll1lll11l1l_cda_)
        xbmc.executebuiltin(l1ll11l1l_cda_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬਯ"))
elif mode[0] == l1ll11l1l_cda_ (u"ࠫࡵࡸࡥ࡮࡫ࡸࡱࡖࡻࡡ࡭࡫ࡷࡽࠬਰ"):
    l111lll11l1l_cda_= l11l11l11l1l_cda_.l11111ll11l1l_cda_()
    l11l1ll11l1l_cda_ = xbmcgui.Dialog().select(l1ll11l1l_cda_ (u"ࠬࡐࡡ࡬ࡱफ़ऋ࠿࠭਱"), l111lll11l1l_cda_.keys())
    if l11l1ll11l1l_cda_>-1:
        l1l1ll1lll11l1l_cda_= l111lll11l1l_cda_.keys()[l11l1ll11l1l_cda_]
        l1l1llll1l11l1l_cda_.setSetting(l1ll11l1l_cda_ (u"࠭ࡪࡢ࡭ࡲࡷࡨࡥࡰࡳࡧࡰ࡭ࡺࡳࠧਲ"),l1l1ll1lll11l1l_cda_)
        xbmc.executebuiltin(l1ll11l1l_cda_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩਲ਼"))
elif mode[0] == l1ll11l1l_cda_ (u"ࠨࡲࡵࡩࡲ࡯ࡵ࡮ࡈ࡬ࡰࡲ࠭਴"):
    l1111ll11l1l_cda_ = l1l1llll1l11l1l_cda_.getSetting(l1ll11l1l_cda_ (u"ࠩࡶࡳࡷࡺࡵ࡫ࡡࡳࡳࠬਵ"))
    l1ll111l11l1l_cda_ = l1l1llll1l11l1l_cda_.getSetting(l1ll11l1l_cda_ (u"ࠪ࡮ࡦࡱ࡯ࡴࡥࡢࡴࡷ࡫࡭ࡪࡷࡰࠫਸ਼"))
    if l1ll11l1l_cda_ (u"ࠫࡄ࠭਷") not in ex_link:
        url = ex_link+l1ll11l1l_cda_ (u"ࠬࡅࡳࡰࡴࡷࡁࠪࡹࠦࡲ࠿ࠨࡷࠫࡪ࠽࠳ࠩਸ")%(l11l11l11l1l_cda_.l1l1l1l1l11l1l_cda_().get(l1111ll11l1l_cda_,l1ll11l1l_cda_ (u"࠭ࠧਹ")),l11l11l11l1l_cda_.l11111ll11l1l_cda_().get(l1ll111l11l1l_cda_,l1ll11l1l_cda_ (u"ࠧࠨ਺")))
    else:
        url = ex_link
    items,params=l11l11l11l1l_cda_.l1ll111ll11l1l_cda_(url,json_file)
    for item in items:
        name= l11l11l11l1l_cda_.html_entity_decode(item.get(l1ll11l1l_cda_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ਻"),l1ll11l1l_cda_ (u"਼ࠩࠪ")))
        l11l11ll11l1l_cda_ = item.get(l1ll11l1l_cda_ (u"ࠪࡹࡷࡲࠧ਽"),l1ll11l1l_cda_ (u"ࠫࠬਾ"))
        if l1ll11l1l_cda_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬਿ") in l11l11ll11l1l_cda_:
            l1l1ll11l11l1l_cda_(name,ex_link=l11l11ll11l1l_cda_, json_file=l1ll11l1l_cda_ (u"࠭ࡩࡨࡰࡲࡶࡪ࠭ੀ"), mode=l1ll11l1l_cda_ (u"ࠧࡸࡣ࡯࡯ࠬੁ"),infoLabels=item,iconImage=item.get(l1ll11l1l_cda_ (u"ࠨ࡫ࡰ࡫ࠬੂ")))
        else:
            l11llll1l11l1l_cda_(name=name, url=l11l11ll11l1l_cda_, mode=l1ll11l1l_cda_ (u"ࠩࡧࡩࡨࡵࡤࡦࡘ࡬ࡨࡪࡵࠧ੃"),contextO=[], iconImage=item.get(l1ll11l1l_cda_ (u"ࠪ࡭ࡲ࡭ࠧ੄")), infoLabels=item, IsPlayable=True,fanart=item.get(l1ll11l1l_cda_ (u"ࠫ࡮ࡳࡧࠨ੅")),totalItems=len(items))
    if params:
        l1l1ll11l11l1l_cda_(l1ll11l1l_cda_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࡭࡯࡭ࡦࡠࡒࡦࡹࡴचࡲࡱࡥࠥࡹࡴࡳࡱࡱࡥࠥࡄ࠾ࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࠫ੆"),ex_link=url, json_file=params, mode=l1ll11l1l_cda_ (u"࠭ࡰࡳࡧࡰ࡭ࡺࡳࡆࡪ࡮ࡰࠫੇ"),iconImage=l1ll11l1l_cda_ (u"ࠧ࡯ࡧࡻࡸ࠳ࡶ࡮ࡨࠩੈ"))
    xbmcplugin.endOfDirectory(l1lll111ll11l1l_cda_,succeeded=True,cacheToDisc=False)
elif mode[0] == l1ll11l1l_cda_ (u"ࠨࡨࡤࡺࡴࡸࡩࡵࡧࡶࡅࡉࡊࠧ੉"):
    l1ll1l1lll11l1l_cda_ = l11l11l11l1l_cda_.l1l1llllll11l1l_cda_(l1l1ll1ll11l1l_cda_)
    l11l11lll11l1l_cda_=json.loads(ex_link)
    l11l11lll11l1l_cda_[l1ll11l1l_cda_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ੊")] = l11l11lll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩੋ"),l1ll11l1l_cda_ (u"ࠫࠬੌ")).replace(l11l11lll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠬࡲࡡࡣࡧ࡯੍ࠫ"),l1ll11l1l_cda_ (u"࠭ࠧ੎")),l1ll11l1l_cda_ (u"ࠧࠨ੏")).replace(l11l11lll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠨ࡯ࡶ࡫ࠬ੐"),l1ll11l1l_cda_ (u"ࠩࠪੑ")),l1ll11l1l_cda_ (u"ࠪࠫ੒"))
    l1ll1l111l11l1l_cda_ = [x for x in l1ll1l1lll11l1l_cda_ if l11l11lll11l1l_cda_[l1ll11l1l_cda_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ੓")]== x.get(l1ll11l1l_cda_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ੔"),l1ll11l1l_cda_ (u"࠭ࠧ੕"))]
    if l1ll1l111l11l1l_cda_:
        xbmc.executebuiltin(l1ll11l1l_cda_ (u"ࠧࡏࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠮࡛ࡄࡑࡏࡓࡗࠦࡰࡪࡰ࡮ࡡࡏࡻॼࠡ࡬ࡨࡷࡹࠦࡷ࡙ࠡࡼࡦࡷࡧ࡮ࡺࡥ࡫࡟࠴ࡉࡏࡍࡑࡕࡡ࠱ࠦࠧ੖") + l11l11lll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ੗"),l1ll11l1l_cda_ (u"ࠩࠪ੘")).encode(l1ll11l1l_cda_ (u"ࠪࡹࡹ࡬࠭࠹ࠩਖ਼")) + l1ll11l1l_cda_ (u"ࠫ࠱ࠦ࠲࠱࠲ࠬࠫਗ਼"))
    else:
        l1ll1l1lll11l1l_cda_.append(l11l11lll11l1l_cda_)
        with open(l1l1ll1ll11l1l_cda_, l1ll11l1l_cda_ (u"ࠬࡽࠧਜ਼")) as l1l111lll11l1l_cda_:
            json.dump(l1ll1l1lll11l1l_cda_, l1l111lll11l1l_cda_, indent=2, sort_keys=True)
            xbmc.executebuiltin(l1ll11l1l_cda_ (u"࠭ࡎࡰࡶ࡬ࡪ࡮ࡩࡡࡵ࡫ࡲࡲ࠭ࡊ࡯ࡥࡣࡱࡳࠥࡊ࡯࡙ࠡࡼࡦࡷࡧ࡮ࡺࡥ࡫࠰ࠥ࠭ੜ") + l11l11lll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭੝"),l1ll11l1l_cda_ (u"ࠨࠩਫ਼")).encode(l1ll11l1l_cda_ (u"ࠩࡸࡸ࡫࠳࠸ࠨ੟")) + l1ll11l1l_cda_ (u"ࠪ࠰ࠥ࠸࠰࠱ࠫࠪ੠"))
elif mode[0] == l1ll11l1l_cda_ (u"ࠫ࡫ࡧࡶࡰࡴ࡬ࡸࡪࡹࡒࡆࡏࠪ੡"):
    if ex_link==l1ll11l1l_cda_ (u"ࠬࡧ࡬࡭ࠩ੢"):
        l1ll11ll11l1l_cda_ = xbmcgui.Dialog().yesno(l1ll11l1l_cda_ (u"ࠨ࠿ࡀࠤ੣"),l1ll11l1l_cda_ (u"ࠢࡖࡵࡸैࠥࡽࡳࡻࡻࡶࡸࡰ࡯ࡥࠡࡨ࡬ࡰࡲࡿࠠࡻ࡚ࠢࡽࡧࡸࡡ࡯ࡻࡦ࡬ࡄࠨ੤"))
        if l1ll11ll11l1l_cda_:
            debug=1
    else:
        l1ll1l1lll11l1l_cda_ = l11l11l11l1l_cda_.l1l1llllll11l1l_cda_(l1l1ll1ll11l1l_cda_)
        l11l11l1l11l1l_cda_=json.loads(ex_link)
        l1llll1l1l11l1l_cda_=[]
        for i in xrange(len(l1ll1l1lll11l1l_cda_)):
            if l1ll1l1lll11l1l_cda_[i].get(l1ll11l1l_cda_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ੥")) in l11l11l1l11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ੦")):
                l1llll1l1l11l1l_cda_.append(i)
        if len(l1llll1l1l11l1l_cda_)>1:
            l1ll11ll11l1l_cda_ = xbmcgui.Dialog().yesno(l1ll11l1l_cda_ (u"ࠥࡃࡄࠨ੧"),l11l11l1l11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ੨")),l1ll11l1l_cda_ (u"࡛ࠧࡳࡶॆࠣࠩࡩࠦࡰࡰࡼࡼࡧ࡯࡯ࠠࡻ࡚ࠢࡽࡧࡸࡡ࡯ࡻࡦ࡬ࡄࠨ੩") % len(l1llll1l1l11l1l_cda_))
        else:
            l1ll11ll11l1l_cda_ = True
        if l1ll11ll11l1l_cda_:
            for i in reversed(l1llll1l1l11l1l_cda_):
                l1ll1l1lll11l1l_cda_.pop(i)
            with open(l1l1ll1ll11l1l_cda_, l1ll11l1l_cda_ (u"࠭ࡷࠨ੪")) as l1l111lll11l1l_cda_:
                json.dump(l1ll1l1lll11l1l_cda_, l1l111lll11l1l_cda_, indent=2, sort_keys=True)
    xbmc.executebuiltin(l1ll11l1l_cda_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ੫"))
elif mode[0]==l1ll11l1l_cda_ (u"ࠨࡥࡧࡥࡘ࡫ࡡࡳࡥ࡫ࠫ੬"):
    l1l1ll1l11l1l_cda_(ex_link)
elif mode[0] ==l1ll11l1l_cda_ (u"ࠩࡖࡾࡺࡱࡡ࡫ࠩ੭"):
    l1l1ll11l11l1l_cda_(l1ll11l1l_cda_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡰ࡮࡭ࡨࡵࡤ࡯ࡹࡪࡣࡎࡰࡹࡨࠤࡘࢀࡵ࡬ࡣࡱ࡭ࡪࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ੮"),l1ll11l1l_cda_ (u"ࠫࠬ੯"),mode=l1ll11l1l_cda_ (u"࡙ࠬࡺࡶ࡭ࡤ࡮ࡓࡵࡷࡦࠩੰ"))
    l111llll11l1l_cda_ = l11l1111l11l1l_cda_()
    if not l111llll11l1l_cda_ == [l1ll11l1l_cda_ (u"࠭ࠧੱ")]:
        for l1l1lll11l11l1l_cda_ in l111llll11l1l_cda_:
            contextmenu = []
            contextmenu.append((l1ll11l1l_cda_ (u"ࠧࡖࡵࡸैࠬੲ"), l1ll11l1l_cda_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࠨࡷ࠮࠭ੳ")% l11111l11l1l_cda_({l1ll11l1l_cda_ (u"ࠩࡰࡳࡩ࡫ࠧੴ"): l1ll11l1l_cda_ (u"ࠪࡗࡿࡻ࡫ࡢ࡬ࡘࡷࡺࡴࠧੵ"), l1ll11l1l_cda_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬ੶") : l1l1lll11l11l1l_cda_})),)
            contextmenu.append((l1ll11l1l_cda_ (u"࡛ࠬࡳࡶॆࠣࡧࡦैअࠡࡪ࡬ࡷࡹࡵࡲࡪछࠪ੷"), l1ll11l1l_cda_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࠦࡵࠬࠫ੸") % l11111l11l1l_cda_({l1ll11l1l_cda_ (u"ࠧ࡮ࡱࡧࡩࠬ੹"): l1ll11l1l_cda_ (u"ࠨࡕࡽࡹࡰࡧࡪࡖࡵࡸࡲࡆࡲ࡬ࠨ੺")})),)
            l1l1ll11l11l1l_cda_(name=l1l1lll11l11l1l_cda_, ex_link=l1ll11l1l_cda_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡣࡥࡣ࠱ࡴࡱ࠵ࡶࡪࡦࡨࡳ࠴ࡹࡨࡰࡹ࠲ࠫ੻")+l1l1lll11l11l1l_cda_.replace(l1ll11l1l_cda_ (u"ࠪࠤࠬ੼"),l1ll11l1l_cda_ (u"ࠫࡤ࠭੽")), mode=l1ll11l1l_cda_ (u"ࠬࡩࡤࡢࡕࡨࡥࡷࡩࡨࠨ੾"), fanart=None, contextmenu=contextmenu)
    xbmcplugin.endOfDirectory(l1lll111ll11l1l_cda_,succeeded=True,cacheToDisc=False)
elif mode[0] ==l1ll11l1l_cda_ (u"࠭ࡓࡻࡷ࡮ࡥ࡯ࡔ࡯ࡸࡧࠪ੿"):
    d = xbmcgui.Dialog().input(l1ll11l1l_cda_ (u"ࠧࡔࡼࡸ࡯ࡦࡰࠬࠡࡲࡲࡨࡦࡰࠠࡵࡻࡷࡹे࠭઀"), type=xbmcgui.INPUT_ALPHANUM)
    if d:
        l111ll1l11l1l_cda_(d)
        ex_link=l1ll11l1l_cda_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡣࡥࡣ࠱ࡴࡱ࠵ࡶࡪࡦࡨࡳ࠴ࡹࡨࡰࡹ࠲ࠫઁ")+d.replace(l1ll11l1l_cda_ (u"ࠩࠣࠫં"),l1ll11l1l_cda_ (u"ࠪࡣࠬઃ"))
        l1l1ll1l11l1l_cda_(ex_link)
elif mode[0] ==l1ll11l1l_cda_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭࡙ࡸࡻ࡮ࠨ઄"):
    l1ll11l1l11l1l_cda_(ex_link)
    xbmc.executebuiltin(l1ll11l1l_cda_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠨࠦࡵࠬࠫઅ")%  l11111l11l1l_cda_({l1ll11l1l_cda_ (u"࠭࡭ࡰࡦࡨࠫઆ"): l1ll11l1l_cda_ (u"ࠧࡔࡼࡸ࡯ࡦࡰࠧઇ")}))
    xbmcplugin.endOfDirectory(l1lll111ll11l1l_cda_,succeeded=True,cacheToDisc=False)
elif mode[0] == l1ll11l1l_cda_ (u"ࠨࡕࡽࡹࡰࡧࡪࡖࡵࡸࡲࡆࡲ࡬ࠨઈ"):
    l1ll1ll1ll11l1l_cda_()
    xbmc.executebuiltin(l1ll11l1l_cda_ (u"࡛ࠩࡆࡒࡉ࠮ࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠬࠪࡹࠩࠨઉ")%  l11111l11l1l_cda_({l1ll11l1l_cda_ (u"ࠪࡱࡴࡪࡥࠨઊ"): l1ll11l1l_cda_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭ࠫઋ")}))
    xbmcplugin.endOfDirectory(l1lll111ll11l1l_cda_,succeeded=True,cacheToDisc=False)
elif mode[0] == l1ll11l1l_cda_ (u"ࠬࡓ࡯࡫ࡧࡆࡈࡆ࠭ઌ"):
    u = l1l1llll1l11l1l_cda_.getSetting(l1ll11l1l_cda_ (u"࠭ࡵࡴࡧࡵࠫઍ"))
    if u:
        l1l1ll11l11l1l_cda_(l1ll11l1l_cda_ (u"ࠧࡇࡱ࡯ࡨࡪࡸࠠࡨॄࣶࡻࡳࡿࠧ઎"),ex_link=l1ll11l1l_cda_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡣࡥࡣ࠱ࡴࡱ࠵ࠧએ")+u+l1ll11l1l_cda_ (u"ࠩ࠲ࡪࡴࡲࡤࡦࡴ࠰࡫ࡱࡵࡷ࡯ࡻࡂࡸࡾࡶࡥ࠾ࡲ࡯࡭ࡰ࡯ࠧઐ"), json_file=l1ll11l1l_cda_ (u"ࠪࠫઑ"), mode=l1ll11l1l_cda_ (u"ࠫࡼࡧ࡬࡬ࠩ઒"), iconImage=l1ll11l1l_cda_ (u"ࠬࡩࡤࡢࡏࡲ࡮ࡪ࠴ࡰ࡯ࡩࠪઓ"))
        l1l1ll11l11l1l_cda_(l1ll11l1l_cda_ (u"࠭ࡕ࡭ࡷࡥ࡭ࡴࡴࡥࠨઔ"),ex_link=l1ll11l1l_cda_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡩࡤࡢ࠰ࡳࡰ࠴࠭ક")+u+l1ll11l1l_cda_ (u"ࠨ࠱ࡸࡰࡺࡨࡩࡰࡰࡨ࠳࡫ࡵ࡬ࡥࡧࡵ࠱࡬ࡲ࡯ࡸࡰࡼࡃࡹࡿࡰࡦ࠿ࡳࡰ࡮ࡱࡩࠨખ"), json_file=l1ll11l1l_cda_ (u"ࠩࠪગ"), mode=l1ll11l1l_cda_ (u"ࠪࡻࡦࡲ࡫ࠨઘ"), iconImage=l1ll11l1l_cda_ (u"ࠫࡨࡪࡡࡖ࡮ࡸࡦ࡮ࡵ࡮ࡦ࠰ࡳࡲ࡬࠭ઙ"))
        l1l1ll11l11l1l_cda_(l1ll11l1l_cda_ (u"ࠬࡕࡢࡴࡧࡵࡻࡴࡽࡡ࡯࡫ࠣࡹঁࡿࡴ࡬ࡱࡺࡲ࡮ࡩࡹࠨચ"),ex_link=l1ll11l1l_cda_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡨࡪࡡ࠯ࡲ࡯࠳ࠬછ")+u+l1ll11l1l_cda_ (u"ࠧ࠰ࡱࡥࡷࡪࡸࡷࡰࡹࡤࡲ࡮࠭જ"), json_file=l1ll11l1l_cda_ (u"ࠨࠩઝ"), mode=l1ll11l1l_cda_ (u"ࠩࡺࡥࡱࡱࠧઞ"), iconImage=l1ll11l1l_cda_ (u"ࠪࡧࡩࡧࡏࡣࡵࡨࡶࡼࡵࡷࡢࡰ࡬࠲ࡵࡴࡧࠨટ"))
    xbmcplugin.endOfDirectory(l1lll111ll11l1l_cda_,succeeded=True)
elif mode[0] == l1ll11l1l_cda_ (u"ࠫࡩ࡫ࡣࡰࡦࡨ࡚࡮ࡪࡥࡰࠩઠ"):
    l1l11111l11l1l_cda_(ex_link)
elif mode[0] == l1ll11l1l_cda_ (u"ࠬࡪࡥࡤࡱࡧࡩ࡛࡯ࡤࡦࡱࡐࡥࡳࡻࡡ࡭ࡓࠪડ"):
    l1l11l1ll11l1l_cda_(ex_link,l1lll11l1l11l1l_cda_=0)
elif mode[0] == l1ll11l1l_cda_ (u"࠭ࡰ࡭ࡣࡼࠫઢ"):
    xbmcgui.Dialog().notification(l1ll11l1l_cda_ (u"ࠧࡓࡧࡰࡳࡹ࡫ࠠࡷ࡫ࡧࡩࡴࠦࡲࡦࡳࡸࡩࡸࡺࡥࡥࠩણ"), ex_link , xbmcgui.NOTIFICATION_INFO, 5000)
    l1l11l1ll11l1l_cda_(ex_link)
elif mode[0] == l1ll11l1l_cda_ (u"ࠨࡑࡳࡧ࡯࡫ࠧત"):
    l1l1llll1l11l1l_cda_.openSettings()
    xbmc.executebuiltin(l1ll11l1l_cda_ (u"࡛ࠩࡆࡒࡉ࠮ࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠬ࠮࠭થ"))
elif mode[0] == l1ll11l1l_cda_ (u"࡙ࠪࡸ࡫ࡲࡄࡱࡱࡸࡪࡴࡴࠨદ"):
    info = l11l11l11l1l_cda_.grabInforFromLink(urllib.unquote(ex_link))
    user =info.get(l1ll11l1l_cda_ (u"ࠫࡺࡹࡥࡳࠩધ"),l1ll11l1l_cda_ (u"ࠬ࠭ન"))
    if user:
        l1ll11lll11l1l_cda_(user,l1ll11l1l_cda_ (u"࠭ࠧ઩"),l1ll11l1l_cda_ (u"ࠧࠨપ"))
        xbmcplugin.endOfDirectory(l1lll111ll11l1l_cda_,succeeded=True,cacheToDisc=False)
    else:
        xbmcgui.Dialog().notification(l1ll11l1l_cda_ (u"ࠨࡈࡲࡰࡩ࡫ࡲࠡࡰ࡬ࡩࠥࡰࡥࡴࡶࠣࡨࡴࡹࡴचࡲࡱࡽࠬફ"), l1ll11l1l_cda_ (u"ࠩࠪબ") , xbmcgui.NOTIFICATION_INFO, 5000)
elif mode[0] ==l1ll11l1l_cda_ (u"ࠪࡅࡩࡪࡍࡰࡸ࡬ࡩࠬભ"):
    from resources.lib import l11lll1l11l1l_cda_
    l11l11lll11l1l_cda_=json.loads(ex_link)
    if not l11l11lll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠫࡤ࡬ࡩ࡭࡯ࡺࡩࡧ࠭મ"),False):
        title,year,label=l11l11l11l1l_cda_.l111l1l1l11l1l_cda_(l11l11lll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠬࡺࡩࡵ࡮ࡨࠫય")))
        l11ll1l1l11l1l_cda_ = xbmcgui.Dialog().input(l1ll11l1l_cda_ (u"࠭ࡔࡺࡶࡸॆࡤࡌࡩ࡭࡯ࡸࠤࡗࡵ࡫ࠡࠪࡳࡳࡵࡸࡡࡸࠢ࡭ࡩॠࡲࡩࠡࡶࡵࡾࡪࡨࡡࠪࠩર"), l1ll11l1l_cda_ (u"ࠧࠦࡵࠣࠩࡸ࠭઱")%(title,year) ,xbmcgui.INPUT_ALPHANUM)
        l11l11lll11l1l_cda_[l1ll11l1l_cda_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧલ")]=l11ll1l1l11l1l_cda_.decode(l1ll11l1l_cda_ (u"ࠩࡸࡸ࡫࠳࠸ࠨળ"))
        xbmcgui.Dialog().notification(l1ll11l1l_cda_ (u"ࠪࡗࡵࡸࡡࡸࡦࡽࡥࡲࠦࡶࡪࡦࡨࡳࠬ઴"), l11l11lll11l1l_cda_[l1ll11l1l_cda_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪવ")] , l11l11lll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠬ࡯࡭ࡨࠩશ"),xbmcgui.NOTIFICATION_INFO), 5000)
        l11l11lll11l1l_cda_ = l1l1111l11l1l_cda_(l11l11lll11l1l_cda_)
    l11l11lll11l1l_cda_[l1ll11l1l_cda_ (u"࠭ࡴࡪࡶ࡯ࡩࠬષ")]=l11l11lll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭સ"),l1ll11l1l_cda_ (u"ࠨࠩહ")).split(l1ll11l1l_cda_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠩ઺"))[0]
    if l11l11lll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠪࡣ࡫࡯࡬࡮ࡹࡨࡦࠬ઻"),False):
        l11lll1l11l1l_cda_.l1ll1lll11l1l_cda_().add(l11l11lll11l1l_cda_)
    else:
        xbmcgui.Dialog().notification(l1ll11l1l_cda_ (u"ࠫࡓ࡯ࡣࠡࡰ࡬ࡩࠥࡪ࡯ࡥࡣࡱࡳࡴ઼࠭"), l11l11lll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠬࡺࡩࡵ࡮ࡨࠫઽ"),l1ll11l1l_cda_ (u"࠭ࠧા")) , l11l11lll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠧࡪ࡯ࡪࠫિ"),xbmcgui.NOTIFICATION_INFO), 5000)
elif mode[0] ==l1ll11l1l_cda_ (u"ࠨࡃࡧࡨࡗࡵ࡯ࡵࡈࡲࡰࡩ࡫ࡲࠨી"):
    from resources.lib import l11lll1l11l1l_cda_
    l1ll1l1lll11l1l_cda_ = l11l11l11l1l_cda_.l1l1llllll11l1l_cda_(json_file)
    l11lll1l11l1l_cda_.l1ll1lll11l1l_cda_().l111l1lll11l1l_cda_(l1ll1l1lll11l1l_cda_)
elif mode[0] == l1ll11l1l_cda_ (u"ࠩࡊࡩࡹࡔࡥࡸࡏࡲࡺ࡮࡫ࡳࠨુ"):
    from resources.lib import l11lll1l11l1l_cda_
    l11lll1l11l1l_cda_.l1ll1lll11l1l_cda_().l1ll111l1l11l1l_cda_()
elif mode[0] == l1ll11l1l_cda_ (u"ࠪࡇ࡭࡫ࡣ࡬ࡎ࡬ࡲࡰࡹࡉ࡯ࡎ࡬ࡦࡷࡧࡲࡺࠩૂ"):
    from resources.lib import l11lll1l11l1l_cda_
    l11lll1l11l1l_cda_.l1ll1lll11l1l_cda_().l111lll1l11l1l_cda_()
elif mode[0] == l1ll11l1l_cda_ (u"ࠫࡱࡶ࡬ࡢࡻࠪૃ"):
    l1ll11llll11l1l_cda_(ex_link)
elif mode[0] == l1ll11l1l_cda_ (u"ࠬࡽࡡ࡭࡭ࠪૄ"):
    l1ll11lll11l1l_cda_(ex_link,json_file,fname)
    xbmcplugin.endOfDirectory(l1lll111ll11l1l_cda_,succeeded=True,cacheToDisc=False)
elif mode[0] == l1ll11l1l_cda_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ૅ"):
    pass
