# -*- coding: utf-8 -*-
import sys
l1l1ll11l1l_cda_ = sys.version_info [0] == 2
l1lll1l11l1l_cda_ = 2048
l1l111l11l1l_cda_ = 7
def l1ll11l1l_cda_ (lll11l1l_cda_):
	global l11l1l11l1l_cda_
	l11llll11l1l_cda_ = ord (lll11l1l_cda_ [-1])
	l11lll11l1l_cda_ = lll11l1l_cda_ [:-1]
	l11l11l1l_cda_ = l11llll11l1l_cda_ % len (l11lll11l1l_cda_)
	l1lll11l1l_cda_ = l11lll11l1l_cda_ [:l11l11l1l_cda_] + l11lll11l1l_cda_ [l11l11l1l_cda_:]
	if l1l1ll11l1l_cda_:
		l1lllll11l1l_cda_ = unicode () .join ([unichr (ord (char) - l1lll1l11l1l_cda_ - (l1l11l11l1l_cda_ + l11llll11l1l_cda_) % l1l111l11l1l_cda_) for l1l11l11l1l_cda_, char in enumerate (l1lll11l1l_cda_)])
	else:
		l1lllll11l1l_cda_ = str () .join ([chr (ord (char) - l1lll1l11l1l_cda_ - (l1l11l11l1l_cda_ + l11llll11l1l_cda_) % l1l111l11l1l_cda_) for l1l11l11l1l_cda_, char in enumerate (l1lll11l1l_cda_)])
	return eval (l1lllll11l1l_cda_)
import urllib
import urllib2
import hashlib
import json
import re
l111ll111ll11l1l_cda_ = l1ll11l1l_cda_ (u"ࠦ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡳ࡭࠰ࡩ࡭ࡱࡳࡷࡦࡤ࠱ࡴࡱ࠵ࡡࡱ࡫ࡂࠦ໏");
l111ll1111l11l1l_cda_ = l1ll11l1l_cda_ (u"ࠧࡷࡪࡤࡉ࡫࡛࠷ࡐ࡮ࡷࡉࡗ࠽ࡩ࡬ࡃࡵ࠵ࡸࡘࡤࡰ࡯ࡻࡔ࠶ࡷࠧ໐");
l111ll11l1l11l1l_cda_ = l1ll11l1l_cda_ (u"ࠨࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡪ࡮ࡲ࡭ࡸࡧࡥ࠲ࡵࡲࠢ໑");
VERSION = l1ll11l1l_cda_ (u"ࠢ࠳࠰࠵ࠦ໒");
l111ll1ll1l11l1l_cda_ = l1ll11l1l_cda_ (u"ࠣࡣࡱࡨࡷࡵࡩࡥࠤ໓");
l111lll111l11l1l_cda_ = l1ll11l1l_cda_ (u"ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡦࡪ࡮ࡰࡻࡪࡨ࠮ࡱ࡮࠲ࡷࡪࡧࡲࡤࡪ࠲ࡰ࡮ࡼࡥࡀࡳࡀࠦ໔");
l111lll11ll11l1l_cda_ = l1ll11l1l_cda_ (u"ࠥࡠࡡࡩࠢ໕");
l111l1ll11l11l1l_cda_ = l1ll11l1l_cda_ (u"ࠦࡡࡢࡡࠣ໖");
l11l11l1lll11l1l_cda_ = l1ll11l1l_cda_ (u"ࠧ࡮ࡴࡵࡲ࠽࠳࠴࠷࠮ࡧࡹࡦࡨࡳ࠴ࡰ࡭࠱ࡳࡳࠧ໗")
l1ll11ll11l11l1l_cda_=10
def _111ll1l11l11l1l_cda_(url):
    l1ll11l1l_cda_ (u"ࠨࠢࠣࠏࠍࠤࠥࠦࠠࡈࡧࡷࠤ࡚ࡸ࡬ࠡࡥࡲࡲࡹࡴࡥࡵࡰࡷࠑࠏࠦࠠࠡࠢࡵࡩࡹࡻࡲ࡯࠼ࠣࡷࡹࡸࡩ࡯ࡩࠐࠎࠥࠦࠠࠡࠤࠥࠦ໘")
    headers = {l1ll11l1l_cda_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ໙"): l1ll11l1l_cda_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡍ࡫ࡱࡹࡽࡁࠠࡂࡰࡧࡶࡴ࡯ࡤࠡ࠶࠱࠵࠳࠷࠻ࠡࡉࡤࡰࡦࡾࡹࠡࡐࡨࡼࡺࡹࠠࡃࡷ࡬ࡰࡩ࠵ࡊࡓࡑ࠳࠷ࡈ࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠶࠰࠴࠽ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠶࠾࠮࠱࠰࠴࠴࠷࠻࠮࠲࠸࠹ࠤࡒࡵࡢࡪ࡮ࡨࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠵࠯࠳࠼ࠫ໚"),
            }
    req = urllib2.Request(url, None, headers)
    response = urllib2.urlopen(req,timeout=l1ll11ll11l11l1l_cda_)
    l111l11ll11l1l_cda_ = response.read()
    response.close()
    return l111l11ll11l1l_cda_
def _11l11lll1l11l1l_cda_(method):
    l111l1lllll11l1l_cda_ = method + l1ll11l1l_cda_ (u"ࠤ࡟ࡲࠧ໛") + l111ll1ll1l11l1l_cda_ + l111ll1111l11l1l_cda_;
    l111l1lllll11l1l_cda_ = VERSION + l1ll11l1l_cda_ (u"ࠥ࠰ࠧໜ") + hashlib.md5(l111l1lllll11l1l_cda_).hexdigest();
    return l111l1lllll11l1l_cda_;
def _11l111ll1l11l1l_cda_(method):
    l111l1lllll11l1l_cda_ = _11l11lll1l11l1l_cda_(method);
    method += l1ll11l1l_cda_ (u"ࠦࡡࡴࠢໝ");
    qs={    l1ll11l1l_cda_ (u"ࠬࡳࡥࡵࡪࡲࡨࡸ࠭ໞ"):method,
            l1ll11l1l_cda_ (u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦࠩໟ"):l111l1lllll11l1l_cda_,
            l1ll11l1l_cda_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ໠"):VERSION,
            l1ll11l1l_cda_ (u"ࠨࡣࡳࡴࡎࡪࠧ໡"):l111ll1ll1l11l1l_cda_}
    return urllib.urlencode(qs)
def _11l111l1ll11l1l_cda_(response,_11l11ll11l11l1l_cda_):
    _111llll1ll11l1l_cda_ = response.split(l1ll11l1l_cda_ (u"ࠩࠣࡸ࠿࠭໢"))[0].split(l1ll11l1l_cda_ (u"ࠪࡠࡳ࠭໣"))
    status = _111llll1ll11l1l_cda_[0]
    data = _111llll1ll11l1l_cda_[1]
    out={}
    if data==l1ll11l1l_cda_ (u"ࠫࡳࡻ࡬࡭ࠩ໤"):
        pass
    else:
        l111ll11lll11l1l_cda_=json.loads(data)
        N=len(l111ll11lll11l1l_cda_)
        for k,v in _11l11ll11l11l1l_cda_.iteritems():
            if l111ll11lll11l1l_cda_[k]==None:
                l111ll11lll11l1l_cda_[k]=l1ll11l1l_cda_ (u"ࠬ࠭໥")
            if N>= k: out[v]=l111ll11lll11l1l_cda_[k]
    return out
def getFilmInfoFull(filmID=l1ll11l1l_cda_ (u"࠭࠱࠹࠷࠹࠷࠷࠭໦")):
    method = l1ll11l1l_cda_ (u"ࠧࡨࡧࡷࡊ࡮ࡲ࡭ࡊࡰࡩࡳࡋࡻ࡬࡭ࠢ࡞ࠫ໧") + filmID + l1ll11l1l_cda_ (u"ࠨ࡟ࠪ໨")
    _11l11ll11l11l1l_cda_ ={
        0 :  l1ll11l1l_cda_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ໩"),
        1 :  l1ll11l1l_cda_ (u"ࠪࡳࡷ࡯ࡧࡪࡰࡤࡰࡹ࡯ࡴ࡭ࡧࠪ໪"),
        2 :  l1ll11l1l_cda_ (u"ࠫࡷࡧࡴࡪࡰࡪࠫ໫"),
        3 :  l1ll11l1l_cda_ (u"ࠬࡼ࡯ࡵࡧࡶࠫ໬"),
        4 :  l1ll11l1l_cda_ (u"࠭ࡧࡦࡰࡵࡩࠬ໭"),
        5 :  l1ll11l1l_cda_ (u"ࠧࡺࡧࡤࡶࠬ໮"),
        6 :  l1ll11l1l_cda_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪ໯"),
        7 :  l1ll11l1l_cda_ (u"ࠩࡦࡳࡲࡳࡥ࡯ࡶࡶࡇࡴࡻ࡮ࡵࠩ໰"),
        8 :  l1ll11l1l_cda_ (u"ࠪࡪࡴࡸࡵ࡮ࡗࡵࡰࠬ໱"),
        9 :  l1ll11l1l_cda_ (u"ࠫ࡭ࡧࡳࡓࡧࡹ࡭ࡪࡽࠧ໲"),
        10 :  l1ll11l1l_cda_ (u"ࠬ࡮ࡡࡴࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭໳"),
        11 :  l1ll11l1l_cda_ (u"࠭ࡩ࡮ࡩࠪ໴"),
        12 :  l1ll11l1l_cda_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭໵"),
        13 :  l1ll11l1l_cda_ (u"ࠨࡲࡵࡩࡲ࡯ࡥࡳࡧ࡚ࡳࡷࡲࡤࠨ໶"),
        14 :  l1ll11l1l_cda_ (u"ࠩࡧࡥࡹ࡫ࠧ໷"),
        15 :  l1ll11l1l_cda_ (u"ࠪࡪ࡮ࡲ࡭ࡕࡻࡳࡩࠬ໸"),
        16 :  l1ll11l1l_cda_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࡷࡈࡵࡵ࡯ࡶࠪ໹"),
        17 :  l1ll11l1l_cda_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࡃࡰࡷࡱࡸࠬ໺"),
        18 :  l1ll11l1l_cda_ (u"࠭ࡳࡵࡷࡧ࡭ࡴ࠭໻"),
        19 :  l1ll11l1l_cda_ (u"ࠧࡱ࡮ࡲࡸࠬ໼")
    }
    response = _111ll1l11l11l1l_cda_( l111ll111ll11l1l_cda_ + _11l111ll1l11l1l_cda_(method))
    out = {}
    if response[:2]==l1ll11l1l_cda_ (u"ࠨࡱ࡮ࠫ໽"):
        out =_11l111l1ll11l1l_cda_(response,_11l11ll11l11l1l_cda_)
        out[l1ll11l1l_cda_ (u"ࠩࡩ࡭ࡱࡳࡷࡦࡤࠪ໾")]=filmID
        if out.get(l1ll11l1l_cda_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ໿")):
            l111ll1llll11l1l_cda_ = [ x for x in out.get(l1ll11l1l_cda_ (u"ࠫࡻ࡯ࡤࡦࡱࠪༀ")) if l1ll11l1l_cda_ (u"ࠬࡳࡰ࠵ࠩ༁") in str(x) ]
            pattern = [l1ll11l1l_cda_ (u"࠭࠮࠴࠸࠳ࡴ࠳࠭༂"), l1ll11l1l_cda_ (u"ࠧ࠯࠶࠻࠴ࡵ࠴ࠧ༃"), l1ll11l1l_cda_ (u"ࠨ࠰࠺࠶࠵ࡶ࠮ࠨ༄")]
            l111l1l1lll11l1l_cda_ = l111ll1llll11l1l_cda_[0]
            for p in pattern:
                for t in l111ll1llll11l1l_cda_:
                    if p in t:
                        l111l1l1lll11l1l_cda_ = t
            out[l1ll11l1l_cda_ (u"ࠩࡷࡶࡦ࡯࡬ࡦࡴࠪ༅")]=l111l1l1lll11l1l_cda_
        if out.get(l1ll11l1l_cda_ (u"ࠪ࡭ࡲ࡭ࠧ༆")):
            out[l1ll11l1l_cda_ (u"ࠫ࡮ࡳࡧࠨ༇")]=l11l11l1lll11l1l_cda_ + out.get(l1ll11l1l_cda_ (u"ࠬ࡯࡭ࡨࠩ༈")).replace(l1ll11l1l_cda_ (u"࠭࠮࠳࠰ࠪ༉"),l1ll11l1l_cda_ (u"ࠧ࠯࠵࠱ࠫ༊"))
        if out.get(l1ll11l1l_cda_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪ་")):
            out[l1ll11l1l_cda_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ༌")] = float(out.get(l1ll11l1l_cda_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ།")))*60
    return out
def l11l11l1l1l11l1l_cda_(filmID=l1ll11l1l_cda_ (u"ࠫ࠺࠿࠴࠴࠷࠺ࠫ༎")):
    method = l1ll11l1l_cda_ (u"ࠬ࡭ࡥࡵࡈ࡬ࡰࡲࡹࡉ࡯ࡨࡲࡗ࡭ࡵࡲࡵࠢ࡞࡟ࠬ༏") + filmID + l1ll11l1l_cda_ (u"࠭࡝࡞ࠩ༐")
    _11l11ll11l11l1l_cda_ = {
        0 :  l1ll11l1l_cda_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭༑"),
        1 :  l1ll11l1l_cda_ (u"ࠨࡻࡨࡥࡷ࠭༒"),
        2 :  l1ll11l1l_cda_ (u"ࠩࡵࡥࡹ࡯࡮ࡨࠩ༓"),
        3 :  l1ll11l1l_cda_ (u"ࠪࡣࠬ༔"),
        4 :  l1ll11l1l_cda_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭༕"),
        5 :  l1ll11l1l_cda_ (u"ࠬ࡯࡭ࡨࠩ༖"),
        6 :  l1ll11l1l_cda_ (u"࠭ࡩࡥࠩ༗")}
    response = _111ll1l11l11l1l_cda_( l111ll111ll11l1l_cda_ + _11l111ll1l11l1l_cda_(method))
    out = {}
    if response[:2]==l1ll11l1l_cda_ (u"ࠧࡰ࡭༘ࠪ"):
        out =_11l111l1ll11l1l_cda_(response.replace(l1ll11l1l_cda_ (u"ࠨ࡝࡞༙ࠫ"),l1ll11l1l_cda_ (u"ࠩ࡞ࠫ༚")).replace(l1ll11l1l_cda_ (u"ࠪࡡࡢ࠭༛"),l1ll11l1l_cda_ (u"ࠫࡢ࠭༜")),_11l11ll11l11l1l_cda_)
    return out
def l11l11111ll11l1l_cda_(filmID=l1ll11l1l_cda_ (u"ࠬ࠻࠹࠵࠵࠸࠻ࠬ༝"), t=l1ll11l1l_cda_ (u"࠭ࡡࡤࡶࡲࡶࡸ࠭༞")):
    l111ll1l1ll11l1l_cda_ = { l1ll11l1l_cda_ (u"ࠧࡥ࡫ࡵࡩࡨࡺ࡯ࡳࡵࠪ༟"): l1ll11l1l_cda_ (u"ࠨ࠳ࠪ༠"), l1ll11l1l_cda_ (u"ࠩࡶࡧࡪࡴࡡࡳ࡫ࡶࡸࡸ࠭༡"): l1ll11l1l_cda_ (u"ࠪ࠶ࠬ༢"), l1ll11l1l_cda_ (u"ࠫࡲࡻࡳࡪࡥࡶࠫ༣"): l1ll11l1l_cda_ (u"ࠬ࠹ࠧ༤"), l1ll11l1l_cda_ (u"࠭ࡰࡩࡱࡷࡳࡸ࠭༥"): l1ll11l1l_cda_ (u"ࠧ࠵ࠩ༦"), l1ll11l1l_cda_ (u"ࠨࡣࡦࡸࡴࡸࡳࠨ༧"): l1ll11l1l_cda_ (u"ࠩ࠹ࠫ༨"), l1ll11l1l_cda_ (u"ࠪࡴࡷࡵࡤࡶࡥࡨࡶࡸ࠭༩"): l1ll11l1l_cda_ (u"ࠫ࠾࠭༪") }
    l111lllllll11l1l_cda_ = [l1ll11l1l_cda_ (u"ࠬ࡯ࡤࠨ༫"), l1ll11l1l_cda_ (u"࠭ࡲࡰ࡮ࡨࠫ༬"), l1ll11l1l_cda_ (u"ࠧࡳࡱ࡯ࡩࡤࡺࡹࡱࡧࠪ༭"), l1ll11l1l_cda_ (u"ࠨࡰࡤࡱࡪ࠭༮"), l1ll11l1l_cda_ (u"ࠩ࡬ࡱ࡬࠭༯")]
    l11l111l11l11l1l_cda_ = {}
    if t in l111ll1l1ll11l1l_cda_.keys():
        method = l1ll11l1l_cda_ (u"ࠪ࡫ࡪࡺࡆࡪ࡮ࡰࡔࡪࡸࡳࡰࡰࡶࠤࡠ࠭༰") + str(filmID) + l1ll11l1l_cda_ (u"ࠫ࠱ࠦࠧ༱") + l111ll1l1ll11l1l_cda_[t] + l1ll11l1l_cda_ (u"ࠬ࠲ࠠ࠱࠮ࠣ࠹࠵ࡣࠧ༲")
        response = _111ll1l11l11l1l_cda_( l111ll111ll11l1l_cda_ + _11l111ll1l11l1l_cda_(method))
        l111lll1l1l11l1l_cda_ = re.search(l1ll11l1l_cda_ (u"࠭ࠨ࡝࡝࠱࠮ࡡࡣࠩࠨ༳"), response)
        l11l111111l11l1l_cda_ = json.loads(l111lll1l1l11l1l_cda_.group(1))
        for data in l11l111111l11l1l_cda_:
            l11l111l11l11l1l_cda_[data[0]] = {}
            for i in range(0, len(l111lllllll11l1l_cda_)):
                if l111lllllll11l1l_cda_[i] == l1ll11l1l_cda_ (u"ࠧࡪ࡯ࡪࠫ༴"):
                    l11l111l11l11l1l_cda_[data[0]][l111lllllll11l1l_cda_[i]] = l1ll11l1l_cda_ (u"ࠨ༵ࠩ") if data[i] == None else l1ll11l1l_cda_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠲࡫ࡽࡣࡥࡰ࠱ࡴࡱ࠵ࡰࠨ༶") + data[i].encode(l1ll11l1l_cda_ (u"ࠪࡹࡹ࡬࠭࠹༷ࠩ")).replace(l1ll11l1l_cda_ (u"ࠫ࠳࠷࠮࡫ࡲࡪࠫ༸"), l1ll11l1l_cda_ (u"ࠬ࠴࠳࠯࡬ࡳ࡫༹ࠬ"))
                else:
                    l11l111l11l11l1l_cda_[data[0]][l111lllllll11l1l_cda_[i]] = data[i].encode(l1ll11l1l_cda_ (u"࠭ࡵࡵࡨ࠰࠼ࠬ༺")) if type(data[i]) == unicode else data[i]
    return l11l111l11l11l1l_cda_
def l11l1111lll11l1l_cda_(filmID=l1ll11l1l_cda_ (u"ࠧ࠲ࠩ༻")):
    method = l1ll11l1l_cda_ (u"ࠨࡩࡨࡸࡋ࡯࡬࡮ࡆࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࡛ࠦࠨ༼") + filmID + l1ll11l1l_cda_ (u"ࠩࡠࠫ༽")
    _11l11ll11l11l1l_cda_ = {0 :  l1ll11l1l_cda_ (u"ࠪࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠨ༾")}
    response = _111ll1l11l11l1l_cda_( l111ll111ll11l1l_cda_ + _11l111ll1l11l1l_cda_(method))
    out = {}
    if response[:2]==l1ll11l1l_cda_ (u"ࠫࡴࡱࠧ༿"):
        out =_11l111l1ll11l1l_cda_(response,_11l11ll11l11l1l_cda_)
    return out
def _11l1111l1l11l1l_cda_(result):
    l111l1ll1ll11l1l_cda_ = result.split(l111l1ll11l11l1l_cda_);
    print l1ll11l1l_cda_ (u"ࠬࡢࡴࡇࡱࡸࡲࡩࠦࠥࡥࠢࡨࡲࡹࡸࡩࡦࡵࠪཀ") %len(l111l1ll1ll11l1l_cda_)
    element=l111l1ll1ll11l1l_cda_[0]
    l11l11ll1ll11l1l_cda_=[]
    for element in l111l1ll1ll11l1l_cda_:
        l11l1llll11l1l_cda_=_11l111llll11l1l_cda_(element)
        if l11l1llll11l1l_cda_: l11l11ll1ll11l1l_cda_.append(l11l1llll11l1l_cda_)
    return l11l11ll1ll11l1l_cda_
def _11l111llll11l1l_cda_(element):
    l111llll11l11l1l_cda_ = element.split(l111lll11ll11l1l_cda_);
    type = l111llll11l11l1l_cda_[0]
    if type == l1ll11l1l_cda_ (u"࠭ࡦࠨཁ") or type == l1ll11l1l_cda_ (u"ࠧࡴࠩག"):
        result = _111lll1lll11l1l_cda_(l111llll11l11l1l_cda_);
    elif type == l1ll11l1l_cda_ (u"ࠨࡲࠪགྷ"):
        result=None
    else :
        result=None
    return result
def _111lll1lll11l1l_cda_(l111llll11l11l1l_cda_):
    item={}
    if len(l111llll11l11l1l_cda_):
        item[l1ll11l1l_cda_ (u"ࠩࡷࡽࡵ࡫ࠧང")] = l111llll11l11l1l_cda_[0]
        item[l1ll11l1l_cda_ (u"ࠪ࡭ࡩ࠭ཅ")] = l111llll11l11l1l_cda_[1]
        item[l1ll11l1l_cda_ (u"ࠫ࡮ࡳࡧࠨཆ")] = l11l11l1lll11l1l_cda_ + l111llll11l11l1l_cda_[2]
        item[l1ll11l1l_cda_ (u"ࠬࡺࡩࡵ࡮ࡨࡣ࡫࠭ཇ")] = l111llll11l11l1l_cda_[3]
        item[l1ll11l1l_cda_ (u"࠭ࡴࡪࡶ࡯ࡩࡤࡶࠧ཈")] = l111llll11l11l1l_cda_[4]
        item[l1ll11l1l_cda_ (u"ࠧࡵ࡫ࡷࡰࡪࡥࡥࠨཉ")] = l111llll11l11l1l_cda_[5]
        item[l1ll11l1l_cda_ (u"ࠨࡻࡨࡥࡷ࠭ཊ")] = l111llll11l11l1l_cda_[6]
        item[l1ll11l1l_cda_ (u"ࠩࡦࡥࡸࡺࠧཋ")] = l111llll11l11l1l_cda_[7]
    return item
def l111lllll1l11l1l_cda_(param=l1ll11l1l_cda_ (u"ࠪࡶࡴࡪࡺࡪࡰࡼࠤࡸ࡯ङࠡࡰ࡬ࡩࠥࡽࡹࡣ࡫ࡨࡶࡦ࠭ཌ")):
    result = _111ll1l11l11l1l_cda_( l111lll111l11l1l_cda_ + urllib.quote_plus(param) )
    out = _11l1111l1l11l1l_cda_(result)
    return out
def l11l11l111l11l1l_cda_(title=l1ll11l1l_cda_ (u"ࠫࠬཌྷ"),year=l1ll11l1l_cda_ (u"ࠬ࠭ཎ"),itemType=l1ll11l1l_cda_ (u"࠭ࡦࠨཏ")):
    l1ll11l1l_cda_ (u"ࠢࠣࠤࠐࠎࠥࠦࠠࠡࡕࡽࡹࡰࡧࠠࡪࡰࡩࡳࡷࡳࡡࡤ࡬࡬ࠤࡴࠦࡦࡪ࡮ࡰ࡭ࡪࠓࠊࠡࠢࠣࠤ࡮ࡺࡥ࡮ࡖࡼࡴࡪࠦ࠽ࠡࠩࡩࠫࠥ࠳ࠠࡇ࡫࡯ࡱࠒࠐࠠࠡࠢࠣ࡭ࡹ࡫࡭ࡕࡻࡳࡩࠥࡃࠠࠨࡵࠪࠤ࠲ࠦࡓࡦࡴ࡬ࡥࡱࠓࠊࠡࠢࠣࠤࠧࠨࠢཐ")
    l111l1lll1l11l1l_cda_={}
    search = l1ll11l1l_cda_ (u"ࡶࠩࠨࡷࠬད") % title.strip()
    search += l1ll11l1l_cda_ (u"ࡷࠪࠤࠪࡹࠧདྷ") % year if year else l1ll11l1l_cda_ (u"ࠪࠫན")
    out= l111lllll1l11l1l_cda_(search)
    if out:
        if len(out)==1:
            l111l1lll1l11l1l_cda_ = out[0]
        else:
            for l11l1llll11l1l_cda_ in sorted(out, key=lambda k: k[l1ll11l1l_cda_ (u"ࠫࡾ࡫ࡡࡳࠩཔ")],reverse=True):
                if l11l1llll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠬࡿࡥࡢࡴࠪཕ"),l1ll11l1l_cda_ (u"࠭ࠧབ")) in [l1ll11l1l_cda_ (u"ࠧ࠳࠲࠴࠻ࠬབྷ"),l1ll11l1l_cda_ (u"ࠨ࠴࠳࠵࠽࠭མ"),l1ll11l1l_cda_ (u"ࠩ࠵࠴࠶࠿ࠧཙ"),l1ll11l1l_cda_ (u"ࠪ࠶࠵࠸࠰ࠨཚ")]:
                    continue
                if l11l1llll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠫࡹࡿࡰࡦࠩཛ")) == itemType:
                    l111l1lll1l11l1l_cda_ = l11l1llll11l1l_cda_
                    break
        return getFilmInfoFull(l111l1lll1l11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠬ࡯ࡤࠨཛྷ"),l1ll11l1l_cda_ (u"࠭ࠧཝ")))
    else:
        return l111l1lll1l11l1l_cda_
def l1llll1lll11l1l_cda_(title=l1ll11l1l_cda_ (u"ࠧࡻ࡫ࡰࡳࡼࡧࠠࡰࡲࡲࡻ࡮࡫ज़ईࠩཞ"),year=l1ll11l1l_cda_ (u"ࠨ࠴࠳࠵࠹࠭ཟ"),itemType=l1ll11l1l_cda_ (u"ࠩࡩࠫའ")):
    l1llllllll11l1l_cda_={}
    try: title = title.encode(l1ll11l1l_cda_ (u"ࠪࡹࡹ࡬࠭࠹ࠩཡ")).decode(l1ll11l1l_cda_ (u"ࠫࡺࡺࡦ࠮࠺ࠪར")) if isinstance(title,unicode) else title
    except: title=title
    result = _111ll1l11l11l1l_cda_(l1ll11l1l_cda_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡩ࡭ࡱࡳࡷࡦࡤ࠱ࡴࡱ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡦࡪ࡮ࡰࡃࡶࡃࠧལ")+urllib.quote_plus(title))
    data = re.compile(l1ll11l1l_cda_ (u"࠭࠼࡭࡫ࠣ࡭ࡩࡃࠢࠩࡁ࠽ࡪ࡮ࡲ࡭ࡽࡪ࡬ࡸ࠮ࡥࠨ࡜ࡠࠥࡡ࠯࠯࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨཤ"),re.DOTALL).findall(result)
    for id,l1ll1ll1lll11l1l_cda_ in data:
        l11l11lllll11l1l_cda_ = re.search(l1ll11l1l_cda_ (u"ࠧࠩࠪࡂ࠾࠶࠿ࡼ࠳࠲ࠬࡠࡩࢁ࠲ࡾࠫࠪཥ"),l1ll1ll1lll11l1l_cda_)
        l11l11lllll11l1l_cda_ = l11l11lllll11l1l_cda_.group(1) if l11l11lllll11l1l_cda_ else l1ll11l1l_cda_ (u"ࠨࠩས")
        if l11l11lllll11l1l_cda_ == year:
            l1llllllll11l1l_cda_ = getFilmInfoFull(id)
            break
    return l1llllllll11l1l_cda_
def l11l11l11ll11l1l_cda_(title=l1ll11l1l_cda_ (u"ࠩࡽ࡭ࡲࡵࡷࡢࠢࡲࡴࡴࡽࡩࡦढ़ऊࠫཧ"),year=l1ll11l1l_cda_ (u"ࠪ࠶࠵࠷࠴ࠨཨ"),itemType=l1ll11l1l_cda_ (u"ࠫ࡫࠭ཀྵ")):
    l1llllllll11l1l_cda_={}
    try: title = title.encode(l1ll11l1l_cda_ (u"ࠬࡻࡴࡧ࠯࠻ࠫཪ")).decode(l1ll11l1l_cda_ (u"࠭ࡵࡵࡨ࠰࠼ࠬཫ")) if isinstance(title,unicode) else title
    except: title=title
    result = _111ll1l11l11l1l_cda_(l1ll11l1l_cda_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲࡫࡯࡬࡮ࡹࡨࡦ࠳ࡶ࡬࠰ࡵࡨࡥࡷࡩࡨ࠰ࡨ࡬ࡰࡲࡅࡱ࠾ࠩཬ")+urllib.quote_plus(title))
    data = re.compile(l1ll11l1l_cda_ (u"ࠨ࠾࡯࡭ࠥ࡯ࡤ࠾ࠤࠫࡃ࠿࡬ࡩ࡭࡯ࡿ࡬࡮ࡺࠩࡠࠪ࡞ࡢࠧࡣࠪࠪ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪ཭"),re.DOTALL).findall(result)
    for id,l1ll1ll1lll11l1l_cda_ in data:
        l11l11lllll11l1l_cda_ = re.search(l1ll11l1l_cda_ (u"ࠩࠫࠬࡄࡀ࠱࠺ࡾ࠵࠴࠮ࡢࡤࡼ࠴ࢀ࠭ࠬ཮"),l1ll1ll1lll11l1l_cda_)
        l11l11lllll11l1l_cda_ = l11l11lllll11l1l_cda_.group(1) if l11l11lllll11l1l_cda_ else l1ll11l1l_cda_ (u"ࠪࠫ཯")
        if l11l11lllll11l1l_cda_ == year:
            l1llllllll11l1l_cda_ = l11l11l1l1l11l1l_cda_(id)
            break
    return l1llllllll11l1l_cda_
if __name__==l1ll11l1l_cda_ (u"ࠦࡤࡥ࡭ࡢ࡫ࡱࡣࡤࠨ཰"):
    pass
