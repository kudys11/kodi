# -*- coding: utf-8 -*-
import sys
l1l1ll11l1l_cda_ = sys.version_info [0] == 2
l1lll1l11l1l_cda_ = 2048
l1l111l11l1l_cda_ = 7
def l1ll11l1l_cda_ (lll11l1l_cda_):
	global l11l1l11l1l_cda_
	l11llll11l1l_cda_ = ord (lll11l1l_cda_ [-1])
	l11lll11l1l_cda_ = lll11l1l_cda_ [:-1]
	l11l11l1l_cda_ = l11llll11l1l_cda_ % len (l11lll11l1l_cda_)
	l1lll11l1l_cda_ = l11lll11l1l_cda_ [:l11l11l1l_cda_] + l11lll11l1l_cda_ [l11l11l1l_cda_:]
	if l1l1ll11l1l_cda_:
		l1lllll11l1l_cda_ = unicode () .join ([unichr (ord (char) - l1lll1l11l1l_cda_ - (l1l11l11l1l_cda_ + l11llll11l1l_cda_) % l1l111l11l1l_cda_) for l1l11l11l1l_cda_, char in enumerate (l1lll11l1l_cda_)])
	else:
		l1lllll11l1l_cda_ = str () .join ([chr (ord (char) - l1lll1l11l1l_cda_ - (l1l11l11l1l_cda_ + l11llll11l1l_cda_) % l1l111l11l1l_cda_) for l1l11l11l1l_cda_, char in enumerate (l1lll11l1l_cda_)])
	return eval (l1lllll11l1l_cda_)
l1ll11l1l_cda_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࡄࡱࡹࡩࡳࡧ࡮ࡵࠢࡄࡨࡩ࠳࡯࡯ࠌࠍࠤࠥࠦࠠࡕࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡩࡴࠢࡩࡶࡪ࡫ࠠࡴࡱࡩࡸࡼࡧࡲࡦ࠼ࠣࡽࡴࡻࠠࡤࡣࡱࠤࡷ࡫ࡤࡪࡵࡷࡶ࡮ࡨࡵࡵࡧࠣ࡭ࡹࠦࡡ࡯ࡦ࠲ࡳࡷࠦ࡭ࡰࡦ࡬ࡪࡾࠐࠠࠡࠢࠣ࡭ࡹࠦࡵ࡯ࡦࡨࡶࠥࡺࡨࡦࠢࡷࡩࡷࡳࡳࠡࡱࡩࠤࡹ࡮ࡥࠡࡉࡑ࡙ࠥࡍࡥ࡯ࡧࡵࡥࡱࠦࡐࡶࡤ࡯࡭ࡨࠦࡌࡪࡥࡨࡲࡸ࡫ࠠࡢࡵࠣࡴࡺࡨ࡬ࡪࡵ࡫ࡩࡩࠦࡢࡺࠌࠣࠤࠥࠦࡴࡩࡧࠣࡊࡷ࡫ࡥࠡࡕࡲࡪࡹࡽࡡࡳࡧࠣࡊࡴࡻ࡮ࡥࡣࡷ࡭ࡴࡴࠬࠡࡧ࡬ࡸ࡭࡫ࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࠢ࠶ࠤࡴ࡬ࠠࡵࡪࡨࠤࡑ࡯ࡣࡦࡰࡶࡩ࠱ࠦ࡯ࡳࠌࠣࠤࠥࠦࠨࡢࡶࠣࡽࡴࡻࡲࠡࡱࡳࡸ࡮ࡵ࡮ࠪࠢࡤࡲࡾࠦ࡬ࡢࡶࡨࡶࠥࡼࡥࡳࡵ࡬ࡳࡳ࠴ࠊࠋࠢࠣࠤ࡚ࠥࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠࡥ࡫ࡶࡸࡷ࡯ࡢࡶࡶࡨࡨࠥ࡯࡮ࠡࡶ࡫ࡩࠥ࡮࡯ࡱࡧࠣࡸ࡭ࡧࡴࠡ࡫ࡷࠤࡼ࡯࡬࡭ࠢࡥࡩࠥࡻࡳࡦࡨࡸࡰ࠱ࠐࠠࠡࠢࠣࡦࡺࡺࠠࡘࡋࡗࡌࡔ࡛ࡔࠡࡃࡑ࡝ࠥ࡝ࡁࡓࡔࡄࡒ࡙࡟࠻ࠡࡹ࡬ࡸ࡭ࡵࡵࡵࠢࡨࡺࡪࡴࠠࡵࡪࡨࠤ࡮ࡳࡰ࡭࡫ࡨࡨࠥࡽࡡࡳࡴࡤࡲࡹࡿࠠࡰࡨࠍࠤࠥࠦࠠࡎࡇࡕࡇࡍࡇࡎࡕࡃࡅࡍࡑࡏࡔ࡚ࠢࡲࡶࠥࡌࡉࡕࡐࡈࡗࡘࠦࡆࡐࡔࠣࡅࠥࡖࡁࡓࡖࡌࡇ࡚ࡒࡁࡓࠢࡓ࡙ࡗࡖࡏࡔࡇ࠱ࠤ࡙ࠥࡥࡦࠢࡷ࡬ࡪࠐࠠࠡࠢࠣࡋࡓ࡛ࠠࡈࡧࡱࡩࡷࡧ࡬ࠡࡒࡸࡦࡱ࡯ࡣࠡࡎ࡬ࡧࡪࡴࡳࡦࠢࡩࡳࡷࠦ࡭ࡰࡴࡨࠤࡩ࡫ࡴࡢ࡫࡯ࡷ࠳ࠐࠊࠡࠢࠣࠤ࡞ࡵࡵࠡࡵ࡫ࡳࡺࡲࡤࠡࡪࡤࡺࡪࠦࡲࡦࡥࡨ࡭ࡻ࡫ࡤࠡࡣࠣࡧࡴࡶࡹࠡࡱࡩࠤࡹ࡮ࡥࠡࡉࡑ࡙ࠥࡍࡥ࡯ࡧࡵࡥࡱࠦࡐࡶࡤ࡯࡭ࡨࠦࡌࡪࡥࡨࡲࡸ࡫ࠊࠡࠢࠣࠤࡦࡲ࡯࡯ࡩࠣࡻ࡮ࡺࡨࠡࡶ࡫࡭ࡸࠦࡰࡳࡱࡪࡶࡦࡳ࠮ࠡࠢࡌࡪࠥࡴ࡯ࡵ࠮ࠣࡷࡪ࡫ࠠ࠽ࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡭࡮ࡶ࠰ࡲࡶ࡬࠵࡬ࡪࡥࡨࡲࡸ࡫ࡳ࠰ࡀ࠱ࠎࠧࠨ഼ࠢ")
import os
import sys
import urllib
import urlparse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
l11ll11llll11l1l_cda_ = 1000
l1l11lll1ll11l1l_cda_ = xbmcaddon.Addon().getLocalizedString
l1l111ll1ll11l1l_cda_ = xbmc.getLocalizedString
l11llll1l1l11l1l_cda_ = xbmcaddon.Addon().getSetting
setSetting = xbmcaddon.Addon().setSetting
l1ll11l11l1l_cda_ = xbmcaddon.Addon
l11lll11l1l11l1l_cda_ = xbmcplugin.addDirectoryItem
item = xbmcgui.ListItem
l1llll1l11l11l1l_cda_ = xbmcplugin.endOfDirectory
content = xbmcplugin.setContent
property = xbmcplugin.setProperty
l11ll1l1lll11l1l_cda_ = xbmcaddon.Addon().getAddonInfo
l11l1l1l11l11l1l_cda_ = xbmc.getInfoLabel
l11l1l11l1l11l1l_cda_ = xbmc.getCondVisibility
l11ll11111l11l1l_cda_ = xbmc.executeJSONRPC
l11llllllll11l1l_cda_ = xbmcgui.Window(10000)
l11l1l1l1ll11l1l_cda_ = xbmcgui.Dialog()
l11ll11ll1l11l1l_cda_ = xbmcgui.DialogProgress()
l11ll111lll11l1l_cda_ = xbmcgui.DialogProgressBG()
l11l1lll1ll11l1l_cda_ = xbmcgui.ControlButton
l1lll1l11ll11l1l_cda_ = xbmcgui.ControlImage
l1l11ll1l1l11l1l_cda_ = xbmc.Keyboard
sleep = xbmc.sleep
l11ll111l1l11l1l_cda_ = xbmc.executebuiltin
l1l11l111ll11l1l_cda_ = xbmc.getSkinDir()
l1l11l1l11l11l1l_cda_ = xbmc.Player()
l1l111l1l1l11l1l_cda_ = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
l11ll1111ll11l1l_cda_ = xbmcplugin.setResolvedUrl
l1l11llll1l11l1l_cda_ = xbmcvfs.File
l11lll11lll11l1l_cda_ = xbmcvfs.mkdir
l1l111ll11l11l1l_cda_ = xbmcvfs.delete
l1l1111llll11l1l_cda_ = xbmcvfs.rmdir
l11lll1111l11l1l_cda_ = xbmcvfs.listdir
l1l111lll1l11l1l_cda_ = xbmc.translatePath
l1l11l1llll11l1l_cda_ = xbmc.translatePath(l1ll11l1l_cda_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡸࡱࡩ࡯࠱ࠪഽ"))
l11l1ll1l1l11l1l_cda_ = xbmc.translatePath(l11ll1l1lll11l1l_cda_(l1ll11l1l_cda_ (u"ࠩࡳࡥࡹ࡮ࠧാ")))
l1l11ll111l11l1l_cda_ = xbmc.translatePath(l11ll1l1lll11l1l_cda_(l1ll11l1l_cda_ (u"ࠪࡴࡷࡵࡦࡪ࡮ࡨࠫി"))).decode(l1ll11l1l_cda_ (u"ࠫࡺࡺࡦ࠮࠺ࠪീ"))
l11l1l111ll11l1l_cda_ = os.path.join(l1l11ll111l11l1l_cda_, l1ll11l1l_cda_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫു"))
l11l1llll1l11l1l_cda_ = os.path.join(l1l11ll111l11l1l_cda_, l1ll11l1l_cda_ (u"࠭ࡶࡪࡧࡺࡷ࠳ࡪࡢࠨൂ"))
l1l11l1111l11l1l_cda_ = os.path.join(l1l11ll111l11l1l_cda_, l1ll11l1l_cda_ (u"ࠧࡣࡱࡲ࡯ࡲࡧࡲ࡬ࡵ࠱ࡨࡧ࠭ൃ"))
l11ll1l111l11l1l_cda_ = os.path.join(l1l11ll111l11l1l_cda_, l1ll11l1l_cda_ (u"ࠨࡲࡵࡳࡻ࡯ࡤࡦࡴࡶ࠲࠶࠹࠮ࡥࡤࠪൄ"))
l11lll111ll11l1l_cda_ = os.path.join(l1l11ll111l11l1l_cda_, l1ll11l1l_cda_ (u"ࠩࡰࡩࡹࡧ࠮࠶࠰ࡧࡦࠬ൅"))
l1l11l11lll11l1l_cda_ = os.path.join(l1l11ll111l11l1l_cda_, l1ll11l1l_cda_ (u"ࠪࡰ࡮ࡨࡲࡢࡴࡼ࠲ࡩࡨࠧെ"))
l11ll1lll1l11l1l_cda_ = os.path.join(l1l11ll111l11l1l_cda_, l1ll11l1l_cda_ (u"ࠫࡨࡧࡣࡩࡧ࠱ࡨࡧ࠭േ"))
l1l11111lll11l1l_cda_ = xbmc.abortRequested
l11ll11l1ll11l1l_cda_ = xbmc.log
key = l1ll11l1l_cda_ (u"ࠧࡘࡧࡖ࡭࡛ࡴ࠷ࡹ࠵ࡷ࠺ࡻ࠳ࡆࡅࡄࠩࡉ࠮ࡏࡧࡖࡥࡔࡪ࡙ࡱ࡞ࡷ࠳ࡵ࠸ࠥൈ")
l1l11l1ll1l11l1l_cda_ = l1ll11l1l_cda_ (u"ࠨࡰ࠳ࡵ࠸ࡺ࠽ࡿ࠯ࡃࡁࡈࠬࡍ࠱ࡍࡣࠤ൉")
def l1l11llllll11l1l_cda_():
    l1l1111111l11l1l_cda_ = l11l1lll11l11l1l_cda_() ; l1lll1l1l11l1l_cda_ = l1l11l11l1l11l1l_cda_()
    if not (l1lll1l1l11l1l_cda_ == None and l1l1111111l11l1l_cda_ in [l1ll11l1l_cda_ (u"ࠧ࠮ࠩൊ"), l1ll11l1l_cda_ (u"ࠨࠩോ")]): return os.path.join(l1lll1l1l11l1l_cda_, l1ll11l1l_cda_ (u"ࠩ࡬ࡧࡴࡴ࠮ࡱࡰࡪࠫൌ"))
    return l11ll1l1lll11l1l_cda_(l1ll11l1l_cda_ (u"ࠪ࡭ࡨࡵ࡮ࠨ്"))
def l1l1l11111l11l1l_cda_():
    l1l1111111l11l1l_cda_ = l11l1lll11l11l1l_cda_() ; l1lll1l1l11l1l_cda_ = l1l11l11l1l11l1l_cda_()
    if not (l1lll1l1l11l1l_cda_ == None and l1l1111111l11l1l_cda_ in [l1ll11l1l_cda_ (u"ࠫ࠲࠭ൎ"), l1ll11l1l_cda_ (u"ࠬ࠭൏")]): return os.path.join(l1lll1l1l11l1l_cda_, l1ll11l1l_cda_ (u"࠭ࡰࡰࡵࡷࡩࡷ࠴ࡰ࡯ࡩࠪ൐"))
    elif l1l1111111l11l1l_cda_ == l1ll11l1l_cda_ (u"ࠧ࠮ࠩ൑"): return l1ll11l1l_cda_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬ൒")
    return l11ll1l1lll11l1l_cda_(l1ll11l1l_cda_ (u"ࠩ࡬ࡧࡴࡴࠧ൓"))
def l11l1llllll11l1l_cda_():
    l1l1111111l11l1l_cda_ = l11l1lll11l11l1l_cda_() ; l1lll1l1l11l1l_cda_ = l1l11l11l1l11l1l_cda_()
    if not (l1lll1l1l11l1l_cda_ == None and l1l1111111l11l1l_cda_ in [l1ll11l1l_cda_ (u"ࠪ࠱ࠬൔ"), l1ll11l1l_cda_ (u"ࠫࠬൕ")]): return os.path.join(l1lll1l1l11l1l_cda_, l1ll11l1l_cda_ (u"ࠬࡶ࡯ࡴࡶࡨࡶ࠳ࡶ࡮ࡨࠩൖ"))
    return l1ll11l1l_cda_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡖࡪࡦࡨࡳ࠳ࡶ࡮ࡨࠩൗ")
def l11llll111l11l1l_cda_():
    l1l1111111l11l1l_cda_ = l11l1lll11l11l1l_cda_() ; l1lll1l1l11l1l_cda_ = l1l11l11l1l11l1l_cda_()
    if not (l1lll1l1l11l1l_cda_ == None and l1l1111111l11l1l_cda_ in [l1ll11l1l_cda_ (u"ࠧ࠮ࠩ൘"), l1ll11l1l_cda_ (u"ࠨࠩ൙")]): return os.path.join(l1lll1l1l11l1l_cda_, l1ll11l1l_cda_ (u"ࠩࡥࡥࡳࡴࡥࡳ࠰ࡳࡲ࡬࠭൚"))
    return l1ll11l1l_cda_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷ࡚࡮ࡪࡥࡰ࠰ࡳࡲ࡬࠭൛")
def l11llll1lll11l1l_cda_():
    l1l1111111l11l1l_cda_ = l11l1lll11l11l1l_cda_() ; l1lll1l1l11l1l_cda_ = l1l11l11l1l11l1l_cda_()
    if not (l1lll1l1l11l1l_cda_ == None and l1l1111111l11l1l_cda_ in [l1ll11l1l_cda_ (u"ࠫ࠲࠭൜"), l1ll11l1l_cda_ (u"ࠬ࠭൝")]): return os.path.join(l1lll1l1l11l1l_cda_, l1ll11l1l_cda_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠴ࡪࡱࡩࠪ൞"))
    return l11ll1l1lll11l1l_cda_(l1ll11l1l_cda_ (u"ࠧࡧࡣࡱࡥࡷࡺࠧൟ"))
def l11lllll11l11l1l_cda_():
    l1l1111111l11l1l_cda_ = l11l1lll11l11l1l_cda_() ; l1lll1l1l11l1l_cda_ = l1l11l11l1l11l1l_cda_()
    if not (l1lll1l1l11l1l_cda_ == None and l1l1111111l11l1l_cda_ in [l1ll11l1l_cda_ (u"ࠨ࠯ࠪൠ"), l1ll11l1l_cda_ (u"ࠩࠪൡ")]): return os.path.join(l1lll1l1l11l1l_cda_, l1ll11l1l_cda_ (u"ࠪࡲࡪࡾࡴ࠯ࡲࡱ࡫ࠬൢ"))
    return l1ll11l1l_cda_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸ࡛࡯ࡤࡦࡱ࠱ࡴࡳ࡭ࠧൣ")
def l11lll1l1ll11l1l_cda_():
    return l11ll1l1lll11l1l_cda_(l1ll11l1l_cda_ (u"ࠬ࡯ࡤࠨ൤"))
def l1l111l111l11l1l_cda_():
    return l11ll1l1lll11l1l_cda_(l1ll11l1l_cda_ (u"࠭࡮ࡢ࡯ࡨࠫ൥"))
def l11l1ll111l11l1l_cda_(l1l1111ll1l11l1l_cda_):
    try:
        query = urllib.urlencode(l1l1111ll1l11l1l_cda_)
    except UnicodeEncodeError:
        for k in l1l1111ll1l11l1l_cda_:
            if isinstance(l1l1111ll1l11l1l_cda_[k], unicode):
                l1l1111ll1l11l1l_cda_[k] = l1l1111ll1l11l1l_cda_[k].encode(l1ll11l1l_cda_ (u"ࠧࡶࡶࡩ࠱࠽࠭൦"))
        query = urllib.urlencode(l1l1111ll1l11l1l_cda_)
    l1l111l1lll11l1l_cda_ = sys.argv[0]
    if not l1l111l1lll11l1l_cda_: l1l111l1lll11l1l_cda_ = l11lll1l1ll11l1l_cda_()
    return l1l111l1lll11l1l_cda_ + l1ll11l1l_cda_ (u"ࠨࡁࠪ൧") + query
def l1l11l11l1l11l1l_cda_():
    l1l1111111l11l1l_cda_ = l11l1lll11l11l1l_cda_()
    if l1l1111111l11l1l_cda_ in [l1ll11l1l_cda_ (u"ࠩ࠰ࠫ൨"), l1ll11l1l_cda_ (u"ࠪࠫ൩")]: return
    elif l11l1l11l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡍࡧࡳࡂࡦࡧࡳࡳ࠮ࡳࡤࡴ࡬ࡴࡹ࠴ࡣࡰࡸࡨࡲࡦࡴࡴ࠯ࡣࡵࡸࡼࡵࡲ࡬ࠫࠪ൪")):
        return os.path.join(xbmcaddon.Addon(l1ll11l1l_cda_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡩ࡯ࡷࡧࡱࡥࡳࡺ࠮ࡢࡴࡷࡻࡴࡸ࡫ࠨ൫")).getAddonInfo(l1ll11l1l_cda_ (u"࠭ࡰࡢࡶ࡫ࠫ൬")), l1ll11l1l_cda_ (u"ࠧࡳࡧࡶࡳࡺࡸࡣࡦࡵࠪ൭"), l1ll11l1l_cda_ (u"ࠨ࡯ࡨࡨ࡮ࡧࠧ൮"), l1l1111111l11l1l_cda_)
def l11l1lll11l11l1l_cda_():
    l11l1lll11l11l1l_cda_ = l11llll1l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠩࡤࡴࡵ࡫ࡡࡳࡣࡱࡧࡪ࠴࠱ࠨ൯")).lower() if l11l1l11l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡌࡦࡹࡁࡥࡦࡲࡲ࠭ࡹࡣࡳ࡫ࡳࡸ࠳ࡩ࡯ࡷࡧࡱࡥࡳࡺ࠮ࡢࡴࡷࡻࡴࡸ࡫ࠪࠩ൰")) else l11llll1l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠫࡦࡶࡰࡦࡣࡵࡥࡳࡩࡥ࠯ࡣ࡯ࡸࠬ൱")).lower()
    return l11l1lll11l11l1l_cda_
def l11ll1l11ll11l1l_cda_():
    l11ll111l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠬࡘࡵ࡯ࡒ࡯ࡹ࡬࡯࡮ࠩࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡷࡨࡸࡩࡱࡶ࠱ࡧࡴࡼࡥ࡯ࡣࡱࡸ࠳ࡧࡲࡵࡹࡲࡶࡰ࠯ࠧ൲"))
def l11ll1lllll11l1l_cda_(message, l11l1ll11ll11l1l_cda_=l11ll1l1lll11l1l_cda_(l1ll11l1l_cda_ (u"࠭࡮ࡢ࡯ࡨࠫ൳")), l11ll11l11l11l1l_cda_=l1ll11l1l_cda_ (u"ࠧࠨ൴"), time=3000, l11lll1llll11l1l_cda_=False):
    if l11ll11l11l11l1l_cda_ == l1ll11l1l_cda_ (u"ࠨࠩ൵"): l11ll11l11l11l1l_cda_ = l1l11llllll11l1l_cda_()
    elif l11ll11l11l11l1l_cda_ == l1ll11l1l_cda_ (u"ࠩࡌࡒࡋࡕࠧ൶"): l11ll11l11l11l1l_cda_ = xbmcgui.NOTIFICATION_INFO
    elif l11ll11l11l11l1l_cda_ == l1ll11l1l_cda_ (u"࡛ࠪࡆࡘࡎࡊࡐࡊࠫ൷"): l11ll11l11l11l1l_cda_ = xbmcgui.NOTIFICATION_WARNING
    elif l11ll11l11l11l1l_cda_ == l1ll11l1l_cda_ (u"ࠫࡊࡘࡒࡐࡔࠪ൸"): l11ll11l11l11l1l_cda_ = xbmcgui.NOTIFICATION_ERROR
    l11l1l1l1ll11l1l_cda_.notification(l11l1ll11ll11l1l_cda_, message, l11ll11l11l11l1l_cda_, time, l11lll1llll11l1l_cda_)
def l1l11lll11l11l1l_cda_(l1l11111l1l11l1l_cda_, l1l111lllll11l1l_cda_, l1l1111l11l11l1l_cda_, l11l1ll11ll11l1l_cda_=l11ll1l1lll11l1l_cda_(l1ll11l1l_cda_ (u"ࠬࡴࡡ࡮ࡧࠪ൹")), l11l1l1111l11l1l_cda_=l1ll11l1l_cda_ (u"࠭ࠧൺ"), l11lll1ll1l11l1l_cda_=l1ll11l1l_cda_ (u"ࠧࠨൻ")):
    return l11l1l1l1ll11l1l_cda_.yesno(l11l1ll11ll11l1l_cda_, l1l11111l1l11l1l_cda_, l1l111lllll11l1l_cda_, l1l1111l11l11l1l_cda_, l11l1l1111l11l1l_cda_, l11lll1ll1l11l1l_cda_)
def l11ll1l1l1l11l1l_cda_(list, l11l1ll11ll11l1l_cda_=l11ll1l1lll11l1l_cda_(l1ll11l1l_cda_ (u"ࠨࡰࡤࡱࡪ࠭ർ"))):
    return l11l1l1l1ll11l1l_cda_.select(l11l1ll11ll11l1l_cda_, list)
def l1l11l1l1ll11l1l_cda_():
    netloc = [urlparse.urlparse(sys.argv[0]).netloc, l1ll11l1l_cda_ (u"ࠩࠪൽ"), l1ll11l1l_cda_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡯࡭ࡻ࡫࠮ࡴࡶࡵࡩࡦࡳࡳࡱࡴࡲࠫൾ"), l1ll11l1l_cda_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡴ࡭ࡹࡴࡳࡧࡤࡱࡸ࠭ൿ"), l1ll11l1l_cda_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡨࡶࡳࡵࡴࡨࡥࡲࡹࠧ඀"), l1ll11l1l_cda_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡺࡩ࡯࡭࡯ࡩࡵࡧࡤࠨඁ"), l1ll11l1l_cda_ (u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮ࡵࡸࡪࡹ࡮ࡪࡥ࠯ࡨࡸࡰࡱࡹࡣࡳࡧࡨࡲࠬං"), l1ll11l1l_cda_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯ࡶࡹ࡫ࡺ࡯ࡤࡦ࠰ࡤࡷࡸࡧࡳࡴ࡫ࡱࡷࠬඃ")]
    if not l11l1l1l11l11l1l_cda_(l1ll11l1l_cda_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡖ࡬ࡶࡩ࡬ࡲࡓࡧ࡭ࡦࠩ඄")) in netloc: sys.exit()
def l1l11ll1lll11l1l_cda_():
    if l11l1l11l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡌࡦࡹࡁࡥࡦࡲࡲ࠭ࡹࡣࡳ࡫ࡳࡸ࠳ࡩ࡯ࡷࡧࡱࡥࡳࡺ࠮࡮ࡧࡷࡥࡩࡧࡴࡢࠫࠪඅ")):
        return os.path.join(xbmcaddon.Addon(l1ll11l1l_cda_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡨࡵࡶࡦࡰࡤࡲࡹ࠴࡭ࡦࡶࡤࡨࡦࡺࡡࠨආ")).getAddonInfo(l1ll11l1l_cda_ (u"ࠬࡶࡡࡵࡪࠪඇ")), l1ll11l1l_cda_ (u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩඈ"), l1ll11l1l_cda_ (u"ࠧࡥࡣࡷࡥࠬඉ"), l1ll11l1l_cda_ (u"ࠨ࡯ࡨࡸࡦ࠴ࡤࡣࠩඊ"))
def l11llllll1l11l1l_cda_(l11ll1ll1ll11l1l_cda_=None):
    l1l11ll11ll11l1l_cda_ = {l1ll11l1l_cda_ (u"ࠩࡅࡹࡱ࡭ࡡࡳ࡫ࡤࡲࠬඋ"): l1ll11l1l_cda_ (u"ࠪࡦ࡬࠭ඌ"), l1ll11l1l_cda_ (u"ࠫࡈ࡮ࡩ࡯ࡧࡶࡩࠬඍ"): l1ll11l1l_cda_ (u"ࠬࢀࡨࠨඎ"), l1ll11l1l_cda_ (u"࠭ࡃࡳࡱࡤࡸ࡮ࡧ࡮ࠨඏ"): l1ll11l1l_cda_ (u"ࠧࡩࡴࠪඐ"), l1ll11l1l_cda_ (u"ࠨࡅࡽࡩࡨ࡮ࠧඑ"): l1ll11l1l_cda_ (u"ࠩࡦࡷࠬඒ"), l1ll11l1l_cda_ (u"ࠪࡈࡦࡴࡩࡴࡪࠪඓ"): l1ll11l1l_cda_ (u"ࠫࡩࡧࠧඔ"), l1ll11l1l_cda_ (u"ࠬࡊࡵࡵࡥ࡫ࠫඕ"): l1ll11l1l_cda_ (u"࠭࡮࡭ࠩඖ"), l1ll11l1l_cda_ (u"ࠧࡆࡰࡪࡰ࡮ࡹࡨࠨ඗"): l1ll11l1l_cda_ (u"ࠨࡧࡱࠫ඘"), l1ll11l1l_cda_ (u"ࠩࡉ࡭ࡳࡴࡩࡴࡪࠪ඙"): l1ll11l1l_cda_ (u"ࠪࡪ࡮࠭ක"), l1ll11l1l_cda_ (u"ࠫࡋࡸࡥ࡯ࡥ࡫ࠫඛ"): l1ll11l1l_cda_ (u"ࠬ࡬ࡲࠨග"), l1ll11l1l_cda_ (u"࠭ࡇࡦࡴࡰࡥࡳ࠭ඝ"): l1ll11l1l_cda_ (u"ࠧࡥࡧࠪඞ"), l1ll11l1l_cda_ (u"ࠨࡉࡵࡩࡪࡱࠧඟ"): l1ll11l1l_cda_ (u"ࠩࡨࡰࠬච"), l1ll11l1l_cda_ (u"ࠪࡌࡪࡨࡲࡦࡹࠪඡ"): l1ll11l1l_cda_ (u"ࠫ࡭࡫ࠧජ"), l1ll11l1l_cda_ (u"ࠬࡎࡵ࡯ࡩࡤࡶ࡮ࡧ࡮ࠨඣ"): l1ll11l1l_cda_ (u"࠭ࡨࡶࠩඤ"), l1ll11l1l_cda_ (u"ࠧࡊࡶࡤࡰ࡮ࡧ࡮ࠨඥ"): l1ll11l1l_cda_ (u"ࠨ࡫ࡷࠫඦ"), l1ll11l1l_cda_ (u"ࠩࡍࡥࡵࡧ࡮ࡦࡵࡨࠫට"): l1ll11l1l_cda_ (u"ࠪ࡮ࡦ࠭ඨ"), l1ll11l1l_cda_ (u"ࠫࡐࡵࡲࡦࡣࡱࠫඩ"): l1ll11l1l_cda_ (u"ࠬࡱ࡯ࠨඪ"), l1ll11l1l_cda_ (u"࠭ࡎࡰࡴࡺࡩ࡬࡯ࡡ࡯ࠩණ"): l1ll11l1l_cda_ (u"ࠧ࡯ࡱࠪඬ"), l1ll11l1l_cda_ (u"ࠨࡒࡲࡰ࡮ࡹࡨࠨත"): l1ll11l1l_cda_ (u"ࠩࡳࡰࠬථ"), l1ll11l1l_cda_ (u"ࠪࡔࡴࡸࡴࡶࡩࡸࡩࡸ࡫ࠧද"): l1ll11l1l_cda_ (u"ࠫࡵࡺࠧධ"), l1ll11l1l_cda_ (u"ࠬࡘ࡯࡮ࡣࡱ࡭ࡦࡴࠧන"): l1ll11l1l_cda_ (u"࠭ࡲࡰࠩ඲"), l1ll11l1l_cda_ (u"ࠧࡓࡷࡶࡷ࡮ࡧ࡮ࠨඳ"): l1ll11l1l_cda_ (u"ࠨࡴࡸࠫප"), l1ll11l1l_cda_ (u"ࠩࡖࡩࡷࡨࡩࡢࡰࠪඵ"): l1ll11l1l_cda_ (u"ࠪࡷࡷ࠭බ"), l1ll11l1l_cda_ (u"ࠫࡘࡲ࡯ࡷࡣ࡮ࠫභ"): l1ll11l1l_cda_ (u"ࠬࡹ࡫ࠨම"), l1ll11l1l_cda_ (u"࠭ࡓ࡭ࡱࡹࡩࡳ࡯ࡡ࡯ࠩඹ"): l1ll11l1l_cda_ (u"ࠧࡴ࡮ࠪය"), l1ll11l1l_cda_ (u"ࠨࡕࡳࡥࡳ࡯ࡳࡩࠩර"): l1ll11l1l_cda_ (u"ࠩࡨࡷࠬ඼"), l1ll11l1l_cda_ (u"ࠪࡗࡼ࡫ࡤࡪࡵ࡫ࠫල"): l1ll11l1l_cda_ (u"ࠫࡸࡼࠧ඾"), l1ll11l1l_cda_ (u"࡚ࠬࡨࡢ࡫ࠪ඿"): l1ll11l1l_cda_ (u"࠭ࡴࡩࠩව"), l1ll11l1l_cda_ (u"ࠧࡕࡷࡵ࡯࡮ࡹࡨࠨශ"): l1ll11l1l_cda_ (u"ࠨࡶࡵࠫෂ"), l1ll11l1l_cda_ (u"ࠩࡘ࡯ࡷࡧࡩ࡯࡫ࡤࡲࠬස"): l1ll11l1l_cda_ (u"ࠪࡹࡰ࠭හ")}
    l11lll1l11l11l1l_cda_ = [l1ll11l1l_cda_ (u"ࠫࡧ࡭ࠧළ"),l1ll11l1l_cda_ (u"ࠬࡩࡳࠨෆ"),l1ll11l1l_cda_ (u"࠭ࡤࡢࠩ෇"),l1ll11l1l_cda_ (u"ࠧࡥࡧࠪ෈"),l1ll11l1l_cda_ (u"ࠨࡧ࡯ࠫ෉"),l1ll11l1l_cda_ (u"ࠩࡨࡲ්ࠬ"),l1ll11l1l_cda_ (u"ࠪࡩࡸ࠭෋"),l1ll11l1l_cda_ (u"ࠫ࡫࡯ࠧ෌"),l1ll11l1l_cda_ (u"ࠬ࡬ࡲࠨ෍"),l1ll11l1l_cda_ (u"࠭ࡨࡦࠩ෎"),l1ll11l1l_cda_ (u"ࠧࡩࡴࠪා"),l1ll11l1l_cda_ (u"ࠨࡪࡸࠫැ"),l1ll11l1l_cda_ (u"ࠩ࡬ࡸࠬෑ"),l1ll11l1l_cda_ (u"ࠪ࡮ࡦ࠭ි"),l1ll11l1l_cda_ (u"ࠫࡰࡵࠧී"),l1ll11l1l_cda_ (u"ࠬࡴ࡬ࠨු"),l1ll11l1l_cda_ (u"࠭࡮ࡰࠩ෕"),l1ll11l1l_cda_ (u"ࠧࡱ࡮ࠪූ"),l1ll11l1l_cda_ (u"ࠨࡲࡷࠫ෗"),l1ll11l1l_cda_ (u"ࠩࡵࡳࠬෘ"),l1ll11l1l_cda_ (u"ࠪࡶࡺ࠭ෙ"),l1ll11l1l_cda_ (u"ࠫࡸࡱࠧේ"),l1ll11l1l_cda_ (u"ࠬࡹ࡬ࠨෛ"),l1ll11l1l_cda_ (u"࠭ࡳࡳࠩො"),l1ll11l1l_cda_ (u"ࠧࡴࡸࠪෝ"),l1ll11l1l_cda_ (u"ࠨࡶ࡫ࠫෞ"),l1ll11l1l_cda_ (u"ࠩࡷࡶࠬෟ"),l1ll11l1l_cda_ (u"ࠪࡹࡰ࠭෠"),l1ll11l1l_cda_ (u"ࠫࡿ࡮ࠧ෡")]
    l1l1111l1ll11l1l_cda_ = [l1ll11l1l_cda_ (u"ࠬ࡫࡮ࠨ෢"),l1ll11l1l_cda_ (u"࠭ࡳࡷࠩ෣"),l1ll11l1l_cda_ (u"ࠧ࡯ࡱࠪ෤"),l1ll11l1l_cda_ (u"ࠨࡦࡤࠫ෥"),l1ll11l1l_cda_ (u"ࠩࡩ࡭ࠬ෦"),l1ll11l1l_cda_ (u"ࠪࡲࡱ࠭෧"),l1ll11l1l_cda_ (u"ࠫࡩ࡫ࠧ෨"),l1ll11l1l_cda_ (u"ࠬ࡯ࡴࠨ෩"),l1ll11l1l_cda_ (u"࠭ࡥࡴࠩ෪"),l1ll11l1l_cda_ (u"ࠧࡧࡴࠪ෫"),l1ll11l1l_cda_ (u"ࠨࡲ࡯ࠫ෬"),l1ll11l1l_cda_ (u"ࠩ࡫ࡹࠬ෭"),l1ll11l1l_cda_ (u"ࠪࡩࡱ࠭෮"),l1ll11l1l_cda_ (u"ࠫࡹࡸࠧ෯"),l1ll11l1l_cda_ (u"ࠬࡸࡵࠨ෰"),l1ll11l1l_cda_ (u"࠭ࡨࡦࠩ෱"),l1ll11l1l_cda_ (u"ࠧ࡫ࡣࠪෲ"),l1ll11l1l_cda_ (u"ࠨࡲࡷࠫෳ"),l1ll11l1l_cda_ (u"ࠩࡽ࡬ࠬ෴"),l1ll11l1l_cda_ (u"ࠪࡧࡸ࠭෵"),l1ll11l1l_cda_ (u"ࠫࡸࡲࠧ෶"),l1ll11l1l_cda_ (u"ࠬ࡮ࡲࠨ෷"),l1ll11l1l_cda_ (u"࠭࡫ࡰࠩ෸")]
    l11l1ll1lll11l1l_cda_ = [l1ll11l1l_cda_ (u"ࠧࡨࡸࠪ෹"), l1ll11l1l_cda_ (u"ࠨࡩࡸࠫ෺"), l1ll11l1l_cda_ (u"ࠩࡪࡨࠬ෻"), l1ll11l1l_cda_ (u"ࠪ࡫ࡦ࠭෼"), l1ll11l1l_cda_ (u"ࠫ࡬ࡴࠧ෽"), l1ll11l1l_cda_ (u"ࠬ࡭࡬ࠨ෾"), l1ll11l1l_cda_ (u"࠭ࡴࡺࠩ෿"), l1ll11l1l_cda_ (u"ࠧࡵࡹࠪ฀"), l1ll11l1l_cda_ (u"ࠨࡶࡷࠫก"), l1ll11l1l_cda_ (u"ࠩࡷࡶࠬข"), l1ll11l1l_cda_ (u"ࠪࡸࡸ࠭ฃ"), l1ll11l1l_cda_ (u"ࠫࡹࡴࠧค"), l1ll11l1l_cda_ (u"ࠬࡺ࡯ࠨฅ"), l1ll11l1l_cda_ (u"࠭ࡴ࡭ࠩฆ"), l1ll11l1l_cda_ (u"ࠧࡵ࡭ࠪง"), l1ll11l1l_cda_ (u"ࠨࡶ࡫ࠫจ"), l1ll11l1l_cda_ (u"ࠩࡷ࡭ࠬฉ"), l1ll11l1l_cda_ (u"ࠪࡸ࡬࠭ช"), l1ll11l1l_cda_ (u"ࠫࡹ࡫ࠧซ"), l1ll11l1l_cda_ (u"ࠬࡺࡡࠨฌ"), l1ll11l1l_cda_ (u"࠭ࡤࡦࠩญ"), l1ll11l1l_cda_ (u"ࠧࡥࡣࠪฎ"), l1ll11l1l_cda_ (u"ࠨࡦࡽࠫฏ"), l1ll11l1l_cda_ (u"ࠩࡧࡺࠬฐ"), l1ll11l1l_cda_ (u"ࠪࡵࡺ࠭ฑ"), l1ll11l1l_cda_ (u"ࠫࡿ࡮ࠧฒ"), l1ll11l1l_cda_ (u"ࠬࢀࡡࠨณ"), l1ll11l1l_cda_ (u"࠭ࡺࡶࠩด"), l1ll11l1l_cda_ (u"ࠧࡸࡣࠪต"), l1ll11l1l_cda_ (u"ࠨࡹࡲࠫถ"), l1ll11l1l_cda_ (u"ࠩ࡭ࡺࠬท"), l1ll11l1l_cda_ (u"ࠪ࡮ࡦ࠭ธ"), l1ll11l1l_cda_ (u"ࠫࡨ࡮ࠧน"), l1ll11l1l_cda_ (u"ࠬࡩ࡯ࠨบ"), l1ll11l1l_cda_ (u"࠭ࡣࡢࠩป"), l1ll11l1l_cda_ (u"ࠧࡤࡧࠪผ"), l1ll11l1l_cda_ (u"ࠨࡥࡼࠫฝ"), l1ll11l1l_cda_ (u"ࠩࡦࡷࠬพ"), l1ll11l1l_cda_ (u"ࠪࡧࡷ࠭ฟ"), l1ll11l1l_cda_ (u"ࠫࡨࡼࠧภ"), l1ll11l1l_cda_ (u"ࠬࡩࡵࠨม"), l1ll11l1l_cda_ (u"࠭ࡰࡴࠩย"), l1ll11l1l_cda_ (u"ࠧࡱࡶࠪร"), l1ll11l1l_cda_ (u"ࠨࡲࡤࠫฤ"), l1ll11l1l_cda_ (u"ࠩࡳ࡭ࠬล"), l1ll11l1l_cda_ (u"ࠪࡴࡱ࠭ฦ"), l1ll11l1l_cda_ (u"ࠫࡲ࡭ࠧว"), l1ll11l1l_cda_ (u"ࠬࡳ࡬ࠨศ"), l1ll11l1l_cda_ (u"࠭࡭࡯ࠩษ"), l1ll11l1l_cda_ (u"ࠧ࡮࡫ࠪส"), l1ll11l1l_cda_ (u"ࠨ࡯࡫ࠫห"), l1ll11l1l_cda_ (u"ࠩࡰ࡯ࠬฬ"), l1ll11l1l_cda_ (u"ࠪࡱࡹ࠭อ"), l1ll11l1l_cda_ (u"ࠫࡲࡹࠧฮ"), l1ll11l1l_cda_ (u"ࠬࡳࡲࠨฯ"), l1ll11l1l_cda_ (u"࠭࡭ࡺࠩะ"), l1ll11l1l_cda_ (u"ࠧࡷࡧࠪั"), l1ll11l1l_cda_ (u"ࠨࡸ࡬ࠫา"), l1ll11l1l_cda_ (u"ࠩ࡬ࡷࠬำ"), l1ll11l1l_cda_ (u"ࠪ࡭ࡺ࠭ิ"), l1ll11l1l_cda_ (u"ࠫ࡮ࡺࠧี"), l1ll11l1l_cda_ (u"ࠬࡼ࡯ࠨึ"), l1ll11l1l_cda_ (u"࠭ࡩࡪࠩื"), l1ll11l1l_cda_ (u"ࠧࡪ࡭ุࠪ"), l1ll11l1l_cda_ (u"ࠨ࡫ࡲูࠫ"), l1ll11l1l_cda_ (u"ࠩ࡬ࡥฺࠬ"), l1ll11l1l_cda_ (u"ࠪ࡭ࡪ࠭฻"), l1ll11l1l_cda_ (u"ࠫ࡮ࡪࠧ฼"), l1ll11l1l_cda_ (u"ࠬ࡯ࡧࠨ฽"), l1ll11l1l_cda_ (u"࠭ࡦࡳࠩ฾"), l1ll11l1l_cda_ (u"ࠧࡧࡻࠪ฿"), l1ll11l1l_cda_ (u"ࠨࡨࡤࠫเ"), l1ll11l1l_cda_ (u"ࠩࡩࡪࠬแ"), l1ll11l1l_cda_ (u"ࠪࡪ࡮࠭โ"), l1ll11l1l_cda_ (u"ࠫ࡫ࡰࠧใ"), l1ll11l1l_cda_ (u"ࠬ࡬࡯ࠨไ"), l1ll11l1l_cda_ (u"࠭ࡳࡴࠩๅ"), l1ll11l1l_cda_ (u"ࠧࡴࡴࠪๆ"), l1ll11l1l_cda_ (u"ࠨࡵࡴࠫ็"), l1ll11l1l_cda_ (u"ࠩࡶࡻ่ࠬ"), l1ll11l1l_cda_ (u"ࠪࡷࡻ้࠭"), l1ll11l1l_cda_ (u"ࠫࡸࡻ๊ࠧ"), l1ll11l1l_cda_ (u"ࠬࡹࡴࠨ๋"), l1ll11l1l_cda_ (u"࠭ࡳ࡬ࠩ์"), l1ll11l1l_cda_ (u"ࠧࡴ࡫ࠪํ"), l1ll11l1l_cda_ (u"ࠨࡵࡲࠫ๎"), l1ll11l1l_cda_ (u"ࠩࡶࡲࠬ๏"), l1ll11l1l_cda_ (u"ࠪࡷࡲ࠭๐"), l1ll11l1l_cda_ (u"ࠫࡸࡲࠧ๑"), l1ll11l1l_cda_ (u"ࠬࡹࡣࠨ๒"), l1ll11l1l_cda_ (u"࠭ࡳࡢࠩ๓"), l1ll11l1l_cda_ (u"ࠧࡴࡩࠪ๔"), l1ll11l1l_cda_ (u"ࠨࡵࡨࠫ๕"), l1ll11l1l_cda_ (u"ࠩࡶࡨࠬ๖"), l1ll11l1l_cda_ (u"ࠪࡰ࡬࠭๗"), l1ll11l1l_cda_ (u"ࠫࡱࡨࠧ๘"), l1ll11l1l_cda_ (u"ࠬࡲࡡࠨ๙"), l1ll11l1l_cda_ (u"࠭࡬࡯ࠩ๚"), l1ll11l1l_cda_ (u"ࠧ࡭ࡱࠪ๛"), l1ll11l1l_cda_ (u"ࠨ࡮࡬ࠫ๜"), l1ll11l1l_cda_ (u"ࠩ࡯ࡺࠬ๝"), l1ll11l1l_cda_ (u"ࠪࡰࡹ࠭๞"), l1ll11l1l_cda_ (u"ࠫࡱࡻࠧ๟"), l1ll11l1l_cda_ (u"ࠬࡿࡩࠨ๠"), l1ll11l1l_cda_ (u"࠭ࡹࡰࠩ๡"), l1ll11l1l_cda_ (u"ࠧࡦ࡮ࠪ๢"), l1ll11l1l_cda_ (u"ࠨࡧࡲࠫ๣"), l1ll11l1l_cda_ (u"ࠩࡨࡲࠬ๤"), l1ll11l1l_cda_ (u"ࠪࡩࡪ࠭๥"), l1ll11l1l_cda_ (u"ࠫࡪࡻࠧ๦"), l1ll11l1l_cda_ (u"ࠬ࡫ࡴࠨ๧"), l1ll11l1l_cda_ (u"࠭ࡥࡴࠩ๨"), l1ll11l1l_cda_ (u"ࠧࡳࡷࠪ๩"), l1ll11l1l_cda_ (u"ࠨࡴࡺࠫ๪"), l1ll11l1l_cda_ (u"ࠩࡵࡱࠬ๫"), l1ll11l1l_cda_ (u"ࠪࡶࡳ࠭๬"), l1ll11l1l_cda_ (u"ࠫࡷࡵࠧ๭"), l1ll11l1l_cda_ (u"ࠬࡨࡥࠨ๮"), l1ll11l1l_cda_ (u"࠭ࡢࡨࠩ๯"), l1ll11l1l_cda_ (u"ࠧࡣࡣࠪ๰"), l1ll11l1l_cda_ (u"ࠨࡤࡰࠫ๱"), l1ll11l1l_cda_ (u"ࠩࡥࡲࠬ๲"), l1ll11l1l_cda_ (u"ࠪࡦࡴ࠭๳"), l1ll11l1l_cda_ (u"ࠫࡧ࡮ࠧ๴"), l1ll11l1l_cda_ (u"ࠬࡨࡩࠨ๵"), l1ll11l1l_cda_ (u"࠭ࡢࡳࠩ๶"), l1ll11l1l_cda_ (u"ࠧࡣࡵࠪ๷"), l1ll11l1l_cda_ (u"ࠨࡱࡰࠫ๸"), l1ll11l1l_cda_ (u"ࠩࡲ࡮ࠬ๹"), l1ll11l1l_cda_ (u"ࠪࡳࡨ࠭๺"), l1ll11l1l_cda_ (u"ࠫࡴࡹࠧ๻"), l1ll11l1l_cda_ (u"ࠬࡵࡲࠨ๼"), l1ll11l1l_cda_ (u"࠭ࡸࡩࠩ๽"), l1ll11l1l_cda_ (u"ࠧࡩࡼࠪ๾"), l1ll11l1l_cda_ (u"ࠨࡪࡼࠫ๿"), l1ll11l1l_cda_ (u"ࠩ࡫ࡶࠬ຀"), l1ll11l1l_cda_ (u"ࠪ࡬ࡹ࠭ກ"), l1ll11l1l_cda_ (u"ࠫ࡭ࡻࠧຂ"), l1ll11l1l_cda_ (u"ࠬ࡮ࡩࠨ຃"), l1ll11l1l_cda_ (u"࠭ࡨࡰࠩຄ"), l1ll11l1l_cda_ (u"ࠧࡩࡣࠪ຅"), l1ll11l1l_cda_ (u"ࠨࡪࡨࠫຆ"), l1ll11l1l_cda_ (u"ࠩࡸࡾࠬງ"), l1ll11l1l_cda_ (u"ࠪࡹࡷ࠭ຈ"), l1ll11l1l_cda_ (u"ࠫࡺࡱࠧຉ"), l1ll11l1l_cda_ (u"ࠬࡻࡧࠨຊ"), l1ll11l1l_cda_ (u"࠭ࡡࡢࠩ຋"), l1ll11l1l_cda_ (u"ࠧࡢࡤࠪຌ"), l1ll11l1l_cda_ (u"ࠨࡣࡨࠫຍ"), l1ll11l1l_cda_ (u"ࠩࡤࡪࠬຎ"), l1ll11l1l_cda_ (u"ࠪࡥࡰ࠭ຏ"), l1ll11l1l_cda_ (u"ࠫࡦࡳࠧຐ"), l1ll11l1l_cda_ (u"ࠬࡧ࡮ࠨຑ"), l1ll11l1l_cda_ (u"࠭ࡡࡴࠩຒ"), l1ll11l1l_cda_ (u"ࠧࡢࡴࠪຓ"), l1ll11l1l_cda_ (u"ࠨࡣࡹࠫດ"), l1ll11l1l_cda_ (u"ࠩࡤࡽࠬຕ"), l1ll11l1l_cda_ (u"ࠪࡥࡿ࠭ຖ"), l1ll11l1l_cda_ (u"ࠫࡳࡲࠧທ"), l1ll11l1l_cda_ (u"ࠬࡴ࡮ࠨຘ"), l1ll11l1l_cda_ (u"࠭࡮ࡰࠩນ"), l1ll11l1l_cda_ (u"ࠧ࡯ࡣࠪບ"), l1ll11l1l_cda_ (u"ࠨࡰࡥࠫປ"), l1ll11l1l_cda_ (u"ࠩࡱࡨࠬຜ"), l1ll11l1l_cda_ (u"ࠪࡲࡪ࠭ຝ"), l1ll11l1l_cda_ (u"ࠫࡳ࡭ࠧພ"), l1ll11l1l_cda_ (u"ࠬࡴࡹࠨຟ"), l1ll11l1l_cda_ (u"࠭࡮ࡳࠩຠ"), l1ll11l1l_cda_ (u"ࠧ࡯ࡸࠪມ"), l1ll11l1l_cda_ (u"ࠨ࡭ࡤࠫຢ"), l1ll11l1l_cda_ (u"ࠩ࡮࡫ࠬຣ"), l1ll11l1l_cda_ (u"ࠪ࡯ࡰ࠭຤"), l1ll11l1l_cda_ (u"ࠫࡰࡰࠧລ"), l1ll11l1l_cda_ (u"ࠬࡱࡩࠨ຦"), l1ll11l1l_cda_ (u"࠭࡫ࡰࠩວ"), l1ll11l1l_cda_ (u"ࠧ࡬ࡰࠪຨ"), l1ll11l1l_cda_ (u"ࠨ࡭ࡰࠫຩ"), l1ll11l1l_cda_ (u"ࠩ࡮ࡰࠬສ"), l1ll11l1l_cda_ (u"ࠪ࡯ࡸ࠭ຫ"), l1ll11l1l_cda_ (u"ࠫࡰࡸࠧຬ"), l1ll11l1l_cda_ (u"ࠬࡱࡷࠨອ"), l1ll11l1l_cda_ (u"࠭࡫ࡷࠩຮ"), l1ll11l1l_cda_ (u"ࠧ࡬ࡷࠪຯ"), l1ll11l1l_cda_ (u"ࠨ࡭ࡼࠫະ")]
    name = None
    name = l11llll1l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠩࡤࡴ࡮࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨັ"))
    if not name: name = l1ll11l1l_cda_ (u"ࠪࡅ࡚࡚ࡏࠨາ")
    if name[-1].isupper():
        try: name = xbmc.l11l1l11lll11l1l_cda_(xbmc.l11lllll1ll11l1l_cda_).split(l1ll11l1l_cda_ (u"ࠫࠥ࠭ຳ"))[0]
        except: pass
    try: name = l1l11ll11ll11l1l_cda_[name]
    except: name = l1ll11l1l_cda_ (u"ࠬ࡫࡮ࠨິ")
    l1l11lll1ll11l1l_cda_ = {l1ll11l1l_cda_ (u"࠭ࡴࡳࡣ࡮ࡸࠬີ"): name} if name in l11lll1l11l11l1l_cda_ else {l1ll11l1l_cda_ (u"ࠧࡵࡴࡤ࡯ࡹ࠭ຶ"): l1ll11l1l_cda_ (u"ࠨࡧࡱࠫື")}
    l1l11lll1ll11l1l_cda_[l1ll11l1l_cda_ (u"ࠩࡷࡺࡩࡨຸࠧ")] = name if name in l1l1111l1ll11l1l_cda_ else l1ll11l1l_cda_ (u"ࠪࡩࡳູ࠭")
    l1l11lll1ll11l1l_cda_[l1ll11l1l_cda_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩ຺ࠬ")] = name if name in l11l1ll1lll11l1l_cda_ else l1ll11l1l_cda_ (u"ࠬ࡫࡮ࠨົ")
    if l11ll1ll1ll11l1l_cda_:
        l1l11lll1ll11l1l_cda_[l1ll11l1l_cda_ (u"࠭ࡴࡳࡣ࡮ࡸࠬຼ")] = [i[0] for i in l1l11ll11ll11l1l_cda_.iteritems() if i[1] == l1l11lll1ll11l1l_cda_[l1ll11l1l_cda_ (u"ࠧࡵࡴࡤ࡯ࡹ࠭ຽ")]][0]
        l1l11lll1ll11l1l_cda_[l1ll11l1l_cda_ (u"ࠨࡶࡹࡨࡧ࠭຾")] = [i[0] for i in l1l11ll11ll11l1l_cda_.iteritems() if i[1] == l1l11lll1ll11l1l_cda_[l1ll11l1l_cda_ (u"ࠩࡷࡺࡩࡨࠧ຿")]][0]
        l1l11lll1ll11l1l_cda_[l1ll11l1l_cda_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫເ")] = [i[0] for i in l1l11ll11ll11l1l_cda_.iteritems() if i[1] == l1l11lll1ll11l1l_cda_[l1ll11l1l_cda_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬແ")]][0]
    return l1l11lll1ll11l1l_cda_
def version():
    l11l1l1llll11l1l_cda_ = l1ll11l1l_cda_ (u"ࠬ࠭ໂ")
    try: version = l1ll11l11l1l_cda_(l1ll11l1l_cda_ (u"࠭ࡸࡣ࡯ࡦ࠲ࡦࡪࡤࡰࡰࠪໃ")).getAddonInfo(l1ll11l1l_cda_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨໄ"))
    except: version = l1ll11l1l_cda_ (u"ࠨ࠻࠼࠽ࠬ໅")
    for i in version:
        if i.isdigit(): l11l1l1llll11l1l_cda_ += i
        else: break
    return int(l11l1l1llll11l1l_cda_)
def openSettings(query=None, id=l11ll1l1lll11l1l_cda_(l1ll11l1l_cda_ (u"ࠩ࡬ࡨࠬໆ"))):
    try:
        l11llll11ll11l1l_cda_()
        l11ll111l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠪࡅࡩࡪ࡯࡯࠰ࡒࡴࡪࡴࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠩࠧࡶ࠭ࠬ໇") % id)
        if query == None: raise Exception()
        c, f = query.split(l1ll11l1l_cda_ (u"ࠫ࠳່࠭"))
        l11ll111l1l11l1l_cda_(l1ll11l1l_cda_ (u"࡙ࠬࡥࡵࡈࡲࡧࡺࡹࠨࠦ࡫້ࠬࠫ") % (int(c) + 100))
        l11ll111l1l11l1l_cda_(l1ll11l1l_cda_ (u"࠭ࡓࡦࡶࡉࡳࡨࡻࡳࠩࠧ࡬໊࠭ࠬ") % (int(f) + 200))
    except:
        return
def l11l1l1ll1l11l1l_cda_():
    return l11ll111l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫໋ࠫ"))
def l1l111l11ll11l1l_cda_():
    return l11ll111l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠨࡃࡦࡸ࡮ࡼࡡࡵࡧ࡚࡭ࡳࡪ࡯ࡸࠪࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬࠯ࠧ໌"))
def l11llll11ll11l1l_cda_():
    return l11ll111l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨ࠰ࡆࡰࡴࡹࡥࠩࡤࡸࡷࡾࡪࡩࡢ࡮ࡲ࡫࠮࠭ໍ"))
def l1l111111ll11l1l_cda_():
    return l11ll111l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠪࡅࡨࡺࡩࡰࡰࠫࡕࡺ࡫ࡵࡦࠫࠪ໎"))
