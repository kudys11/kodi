# coding: UTF-8
import sys
l1l1ll11l1l_cda_ = sys.version_info [0] == 2
l1lll1l11l1l_cda_ = 2048
l1l111l11l1l_cda_ = 7
def l1ll11l1l_cda_ (lll11l1l_cda_):
	global l11l1l11l1l_cda_
	l11llll11l1l_cda_ = ord (lll11l1l_cda_ [-1])
	l11lll11l1l_cda_ = lll11l1l_cda_ [:-1]
	l11l11l1l_cda_ = l11llll11l1l_cda_ % len (l11lll11l1l_cda_)
	l1lll11l1l_cda_ = l11lll11l1l_cda_ [:l11l11l1l_cda_] + l11lll11l1l_cda_ [l11l11l1l_cda_:]
	if l1l1ll11l1l_cda_:
		l1lllll11l1l_cda_ = unicode () .join ([unichr (ord (char) - l1lll1l11l1l_cda_ - (l1l11l11l1l_cda_ + l11llll11l1l_cda_) % l1l111l11l1l_cda_) for l1l11l11l1l_cda_, char in enumerate (l1lll11l1l_cda_)])
	else:
		l1lllll11l1l_cda_ = str () .join ([chr (ord (char) - l1lll1l11l1l_cda_ - (l1l11l11l1l_cda_ + l11llll11l1l_cda_) % l1l111l11l1l_cda_) for l1l11l11l1l_cda_, char in enumerate (l1lll11l1l_cda_)])
	return eval (l1lllll11l1l_cda_)
import threading
import xbmc,xbmcgui
import time,re,os
try: from shutil import rmtree
except: rmtree = False
def l1l11l1l_cda_(l11ll1l11l1l_cda_,l11ll11l1l_cda_=[l1ll11l1l_cda_ (u"ࠫࠬଞ")]):
    debug=1
def l1111l11l1l_cda_(name=l1ll11l1l_cda_ (u"ࠬ࠭ଟ")):
    debug=1
def l111l11l1l_cda_(top):
    debug=1
def check():
    debug=1
try:
    debug=1
except: pass
