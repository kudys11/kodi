# -*- coding: utf-8 -*-
import sys
l1l1ll11l1l_cda_ = sys.version_info [0] == 2
l1lll1l11l1l_cda_ = 2048
l1l111l11l1l_cda_ = 7
def l1ll11l1l_cda_ (lll11l1l_cda_):
	global l11l1l11l1l_cda_
	l11llll11l1l_cda_ = ord (lll11l1l_cda_ [-1])
	l11lll11l1l_cda_ = lll11l1l_cda_ [:-1]
	l11l11l1l_cda_ = l11llll11l1l_cda_ % len (l11lll11l1l_cda_)
	l1lll11l1l_cda_ = l11lll11l1l_cda_ [:l11l11l1l_cda_] + l11lll11l1l_cda_ [l11l11l1l_cda_:]
	if l1l1ll11l1l_cda_:
		l1lllll11l1l_cda_ = unicode () .join ([unichr (ord (char) - l1lll1l11l1l_cda_ - (l1l11l11l1l_cda_ + l11llll11l1l_cda_) % l1l111l11l1l_cda_) for l1l11l11l1l_cda_, char in enumerate (l1lll11l1l_cda_)])
	else:
		l1lllll11l1l_cda_ = str () .join ([chr (ord (char) - l1lll1l11l1l_cda_ - (l1l11l11l1l_cda_ + l11llll11l1l_cda_) % l1l111l11l1l_cda_) for l1l11l11l1l_cda_, char in enumerate (l1lll11l1l_cda_)])
	return eval (l1lllll11l1l_cda_)
l1ll11l1l_cda_ (u"ࠢࠣࠤࠐࠎࡈࡸࡥࡢࡶࡨࡨࠥࡵ࡮ࠡࡖ࡫ࡹࠥࡌࡥࡣࠢ࠴࠵ࠥ࠷࠸࠻࠶࠺࠾࠹࠹ࠠ࠳࠲࠴࠺ࠒࠐࠍࠋࡂࡤࡹࡹ࡮࡯ࡳ࠼ࠣࡶࡦࡳࡩࡤࠏࠍࠦࠧࠨୄ")
import cookielib
import urllib2,urllib
import re,os
import json as json
import l1ll1111l1l11l1l_cda_ as l1ll1111l1l11l1l_cda_
l1l1l1l11ll11l1l_cda_=l1ll11l1l_cda_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡣࡥࡣ࠱ࡴࡱ࠭୅")
l1ll11ll11l11l1l_cda_ = 10
l111l111l11l1l_cda_ = l1ll11l1l_cda_ (u"ࡴࠪࡇ࠿ࡢࡵࡴࡧࡵࡷࡡࡩࡤࡢ࠰ࡦࡳࡴࡱࡩࡦࠩ୆")
def l1l1l111l11l1l_cda_(url,data=None,cookies=None,Refer=False):
    if l111l111l11l1l_cda_ and os.path.exists(l111l111l11l1l_cda_):
        l1lll1ll11l11l1l_cda_ = cookielib.LWPCookieJar()
        l1lll1ll11l11l1l_cda_.load(l111l111l11l1l_cda_)
        cookies = l1ll11l1l_cda_ (u"ࠪ࠿ࠬେ").join([l1ll11l1l_cda_ (u"ࠫࠪࡹ࠽ࠦࡵࠪୈ")%(c.name,c.value) for c in l1lll1ll11l11l1l_cda_])
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1lll1ll11l11l1l_cda_))
        urllib2.install_opener(opener)
    req = urllib2.Request(url,data)
    req.add_header(l1ll11l1l_cda_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ୉"), l1ll11l1l_cda_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠺࠸࠯࠲࠱࠶࠺࠼࠴࠯࠻࠺ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫ୊"))
    if Refer:
        req.add_header(l1ll11l1l_cda_ (u"ࠢࡓࡧࡩࡩࡷ࡫ࡲࠣୋ"), url)
        req.add_header(l1ll11l1l_cda_ (u"࡚ࠣ࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠦୌ"), l1ll11l1l_cda_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶ୍ࠪ"))
        req.add_header(l1ll11l1l_cda_ (u"ࠥࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠤ୎"),l1ll11l1l_cda_ (u"ࠦࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱࡭ࡷࡴࡴࠢ୏"))
    if cookies:
        req.add_header(l1ll11l1l_cda_ (u"ࠧࡉ࡯ࡰ࡭࡬ࡩࠧ୐"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l1ll11ll11l11l1l_cda_)
        l111l11ll11l1l_cda_ =  response.read()
        response.close()
    except:
        l111l11ll11l1l_cda_=l1ll11l1l_cda_ (u"࠭ࠧ୑")
    return l111l11ll11l1l_cda_
def l111111l11l1l_cda_(l1lll11111l11l1l_cda_,l1l1lll111l11l1l_cda_,l111l111l11l1l_cda_):
    l1ll11lllll11l1l_cda_ = { l1ll11l1l_cda_ (u"ࠧࡶࡵࡨࡶࡳࡧ࡭ࡦࠩ୒"): l1lll11111l11l1l_cda_, l1ll11l1l_cda_ (u"ࠨࡲࡤࡷࡸࡽ࡯ࡳࡦࠪ୓"): l1l1lll111l11l1l_cda_, l1ll11l1l_cda_ (u"ࠤࡶࡹࡧࡳࡩࡵࡡ࡯ࡳ࡬࡯࡮ࠣ୔"): l1ll11l1l_cda_ (u"ࠥࠦ୕") }
    url=l1ll11l1l_cda_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡦࡨࡦ࠴ࡰ࡭࠱࡯ࡳ࡬࡯࡮ࠨୖ")
    l1lll1ll11l11l1l_cda_ = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1lll1ll11l11l1l_cda_))
    urllib2.install_opener(opener)
    params=urllib.urlencode(l1ll11lllll11l1l_cda_)
    status=False
    try:
        req = urllib2.Request(url, params)
        req.add_header(l1ll11l1l_cda_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩୗ"), l1ll11l1l_cda_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠹࠲࠶ࡁࠠࡳࡸ࠽࠶࠷࠴࠰ࠪࠢࡊࡩࡨࡱ࡯࠰࠴࠳࠵࠵࠶࠱࠱࠳ࠣࡊ࡮ࡸࡥࡧࡱࡻ࠳࠷࠸࠮࠱ࠩ୘"))
        response = urllib2.urlopen(req)
        l1ll11l1l1l11l1l_cda_ = response.read()
        response.close()
        if l1lll11111l11l1l_cda_ in l1ll11l1l1l11l1l_cda_:
            l1lll1ll11l11l1l_cda_.save(l111l111l11l1l_cda_, ignore_discard = True)
            status=True
    except:
        pass
    return status
def _1l1ll1111l11l1l_cda_(content):
    src =l1ll11l1l_cda_ (u"ࠧࠨ୙")
    l1l1l11l11l11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"ࠣࡧࡹࡥࡱ࠮࠮ࠫࡁࠬࡠࢀࡢࡽ࡝ࠫ࡟࠭ࠧ୚"),re.DOTALL).findall(content)
    for l1ll1ll11ll11l1l_cda_ in l1l1l11l11l11l1l_cda_:
        l1ll1ll11ll11l1l_cda_=re.sub(l1ll11l1l_cda_ (u"ࠩࠣࠤࠬ୛"),l1ll11l1l_cda_ (u"ࠪࠤࠬଡ଼"),l1ll1ll11ll11l1l_cda_)
        l1ll1ll11ll11l1l_cda_=re.sub(l1ll11l1l_cda_ (u"ࠫࡡࡴࠧଢ଼"),l1ll11l1l_cda_ (u"ࠬ࠭୞"),l1ll1ll11ll11l1l_cda_)
        try:
            l1ll111l11l11l1l_cda_ = l1ll1111l1l11l1l_cda_.unpack(l1ll1ll11ll11l1l_cda_)
        except:
            l1ll111l11l11l1l_cda_=l1ll11l1l_cda_ (u"࠭ࠧୟ")
        if l1ll111l11l11l1l_cda_:
            l1ll111l11l11l1l_cda_=re.sub(l1ll11l1l_cda_ (u"ࡲࠨ࡞࡟ࠫୠ"),l1ll11l1l_cda_ (u"ࡳࠩࠪୡ"),l1ll111l11l11l1l_cda_)
            l1lll1111ll11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"ࠩ࡞ࡠࠬࠨ࡝ࠫࡨ࡬ࡰࡪࡡ࡜ࠨࠤࡠ࠮࠿ࡢࡳࠫ࡝࡟ࠫࠧࡣࠨ࠯࠭ࡂ࠭ࡠࡢࠧࠣ࡟࠯ࠫୢ"),  re.DOTALL).search(l1ll111l11l11l1l_cda_)
            l1lll11l11l11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"ࠪ࡟ࡡ࠭ࠢ࡞ࡨ࡬ࡰࡪࡡ࡜ࠨࠤࡠ࡟࠿ࡢࡳ࡞ࠬ࡞ࡠࠬࠨ࡝ࠩ࠰࠮ࡃ࠮ࡡ࡜ࠨࠤࡠࠫୣ"),  re.DOTALL).search(l1ll111l11l11l1l_cda_)
            l1lll111lll11l1l_cda_ = re.search(l1ll11l1l_cda_ (u"ࠦࡠ࠭࡜ࠣ࡟ࡩ࡭ࡱ࡫࡛ࠨ࡞ࠥࡡ࠿ࡡࠧ࡝ࠤࡠࠬ࠳࠰࠿࡝࠰ࡰࡴ࠹࠯࡛ࠨ࡞ࠥࡡࠧ୤"),l1ll111l11l11l1l_cda_)
            if l1lll1111ll11l1l_cda_:
                src = l1lll1111ll11l1l_cda_.group(1)
            elif l1lll11l11l11l1l_cda_:
                src = l1lll11l11l11l1l_cda_.group(1)
            elif l1lll111lll11l1l_cda_:
                src = l1lll111lll11l1l_cda_.group(1)+l1ll11l1l_cda_ (u"ࠬ࠴࡭ࡱ࠶ࠪ୥")
            if src:
                break
    return src
def _1ll11ll1ll11l1l_cda_(content):
    src=l1ll11l1l_cda_ (u"࠭ࠧ୦")
    l1l1lll1lll11l1l_cda_ = content.find(l1ll11l1l_cda_ (u"ࠧࡽࡾࡿ࡬ࡹࡺࡰࠨ୧"))
    if l1l1lll1lll11l1l_cda_>0:
        l1l1ll1ll1l11l1l_cda_ = content.find(l1ll11l1l_cda_ (u"ࠨ࠰ࡶࡴࡱ࡯ࡴࠨ୨"),l1l1lll1lll11l1l_cda_)
        encoded =content[l1l1lll1lll11l1l_cda_:l1l1ll1ll1l11l1l_cda_]
        if encoded:
            l1ll1l11l11l1l_cda_ = encoded.split(l1ll11l1l_cda_ (u"ࠩࡳࡰࡦࡿࡥࡳࠩ୩"))[0]
            l1ll1l11l11l1l_cda_=re.sub(l1ll11l1l_cda_ (u"ࡵࠫࡠࢂ࡝ࠬ࡞ࡺࡿ࠷࠲࠳ࡾ࡝ࡿࡡ࠰࠭୪"),l1ll11l1l_cda_ (u"ࠫࢁ࠭୫"),l1ll1l11l11l1l_cda_,re.DOTALL)
            l1ll1l11l11l1l_cda_=re.sub(l1ll11l1l_cda_ (u"ࡷ࡛࠭ࡽ࡟࠮ࡠࡼࢁ࠲࠭࠵ࢀ࡟ࢁࡣࠫࠨ୬"),l1ll11l1l_cda_ (u"࠭ࡼࠨ୭"),l1ll1l11l11l1l_cda_,re.DOTALL)
            l1ll1ll111l11l1l_cda_=[l1ll11l1l_cda_ (u"ࠧࡩࡶࡷࡴࠬ୮"),l1ll11l1l_cda_ (u"ࠨࡥࡧࡥࠬ୯"),l1ll11l1l_cda_ (u"ࠩࡳࡰࠬ୰"),l1ll11l1l_cda_ (u"ࠪࡰࡴ࡭࡯ࠨୱ"),l1ll11l1l_cda_ (u"ࠫࡼ࡯ࡤࡵࡪࠪ୲"),l1ll11l1l_cda_ (u"ࠬ࡮ࡥࡪࡩ࡫ࡸࠬ୳"),l1ll11l1l_cda_ (u"࠭ࡴࡳࡷࡨࠫ୴"),l1ll11l1l_cda_ (u"ࠧࡴࡶࡤࡸ࡮ࡩࠧ୵"),l1ll11l1l_cda_ (u"ࠨࡵࡷࠫ୶"),l1ll11l1l_cda_ (u"ࠩࡰࡴ࠹࠭୷"),l1ll11l1l_cda_ (u"ࠪࡪࡦࡲࡳࡦࠩ୸"),l1ll11l1l_cda_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ୹"),l1ll11l1l_cda_ (u"ࠬࡹࡴࡢࡶ࡬ࡧࠬ୺"),
                    l1ll11l1l_cda_ (u"࠭ࡴࡺࡲࡨࠫ୻"),l1ll11l1l_cda_ (u"ࠧࡴࡹࡩࠫ୼"),l1ll11l1l_cda_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲࠨ୽"),l1ll11l1l_cda_ (u"ࠩࡩ࡭ࡱ࡫ࠧ୾"),l1ll11l1l_cda_ (u"ࠪࡧࡴࡴࡴࡳࡱ࡯ࡦࡦࡸࠧ୿"),l1ll11l1l_cda_ (u"ࠫࡦࡪࡳࠨ஀"),l1ll11l1l_cda_ (u"ࠬࡩࡺࡢࡵࠪ஁"),l1ll11l1l_cda_ (u"࠭ࡰࡰࡵ࡬ࡸ࡮ࡵ࡮ࠨஂ"),l1ll11l1l_cda_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩஃ"),l1ll11l1l_cda_ (u"ࠨࡤࡲࡸࡹࡵ࡭ࠨ஄"),l1ll11l1l_cda_ (u"ࠩࡸࡷࡪࡸࡁࡨࡧࡱࡸࠬஅ"),
                    l1ll11l1l_cda_ (u"ࠪࡱࡦࡺࡣࡩࠩஆ"),l1ll11l1l_cda_ (u"ࠫࡵࡴࡧࠨஇ"),l1ll11l1l_cda_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹࡵࡲࠨஈ"),l1ll11l1l_cda_ (u"࠭ࡩࡥࠩஉ"), l1ll11l1l_cda_ (u"ࠧ࠴࠹ࠪஊ"), l1ll11l1l_cda_ (u"ࠨࡴࡨ࡫࡮ࡵ࡮ࡴࠩ஋"), l1ll11l1l_cda_ (u"ࠩ࠳࠽ࠬ஌"), l1ll11l1l_cda_ (u"ࠪࡩࡳࡧࡢ࡭ࡧࡧࠫ஍"), l1ll11l1l_cda_ (u"ࠫࡸࡸࡣࠨஎ"), l1ll11l1l_cda_ (u"ࠬࡳࡥࡥ࡫ࡤࠫஏ")]
            l1ll1ll111l11l1l_cda_=[l1ll11l1l_cda_ (u"࠭ࡨࡵࡶࡳࠫஐ"), l1ll11l1l_cda_ (u"ࠧ࡭ࡱࡪࡳࠬ஑"), l1ll11l1l_cda_ (u"ࠨࡹ࡬ࡨࡹ࡮ࠧஒ"), l1ll11l1l_cda_ (u"ࠩ࡫ࡩ࡮࡭ࡨࡵࠩஓ"), l1ll11l1l_cda_ (u"ࠪࡸࡷࡻࡥࠨஔ"), l1ll11l1l_cda_ (u"ࠫࡸࡺࡡࡵ࡫ࡦࠫக"), l1ll11l1l_cda_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫ஖"), l1ll11l1l_cda_ (u"࠭ࡶࡪࡦࡨࡳࠬ஗"), l1ll11l1l_cda_ (u"ࠧࡱ࡮ࡤࡽࡪࡸࠧ஘"),
                l1ll11l1l_cda_ (u"ࠨࡨ࡬ࡰࡪ࠭ங"), l1ll11l1l_cda_ (u"ࠩࡷࡽࡵ࡫ࠧச"), l1ll11l1l_cda_ (u"ࠪࡶࡪ࡭ࡩࡰࡰࡶࠫ஛"), l1ll11l1l_cda_ (u"ࠫࡳࡵ࡮ࡦࠩஜ"), l1ll11l1l_cda_ (u"ࠬࡩࡺࡢࡵࠪ஝"), l1ll11l1l_cda_ (u"࠭ࡥ࡯ࡣࡥࡰࡪࡪࠧஞ"), l1ll11l1l_cda_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩட"), l1ll11l1l_cda_ (u"ࠨࡥࡲࡲࡹࡸ࡯࡭ࡤࡤࡶࠬ஠"), l1ll11l1l_cda_ (u"ࠩࡰࡥࡹࡩࡨࠨ஡"), l1ll11l1l_cda_ (u"ࠪࡦࡴࡺࡴࡰ࡯ࠪ஢"),
                l1ll11l1l_cda_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫண"), l1ll11l1l_cda_ (u"ࠬࡶ࡯ࡴ࡫ࡷ࡭ࡴࡴࠧத"), l1ll11l1l_cda_ (u"࠭ࡵࡴࡧࡵࡅ࡬࡫࡮ࡵࠩ஥"), l1ll11l1l_cda_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡰࡴࠪ஦"), l1ll11l1l_cda_ (u"ࠨࡥࡲࡲ࡫࡯ࡧࠨ஧"), l1ll11l1l_cda_ (u"ࠩ࡫ࡸࡲࡲࠧந"), l1ll11l1l_cda_ (u"ࠪ࡬ࡹࡳ࡬࠶ࠩன"), l1ll11l1l_cda_ (u"ࠫࡵࡸ࡯ࡷ࡫ࡧࡩࡷ࠭ப"), l1ll11l1l_cda_ (u"ࠬࡨ࡬ࡢࡥ࡮ࠫ஫"),
                l1ll11l1l_cda_ (u"࠭ࡨࡰࡴ࡬ࡾࡴࡴࡴࡢ࡮ࡄࡰ࡮࡭࡮ࠨ஬"), l1ll11l1l_cda_ (u"ࠧࡤࡣࡱࡊ࡮ࡸࡥࡆࡸࡨࡲࡹࡇࡐࡊࡅࡤࡰࡱࡹࠧ஭"), l1ll11l1l_cda_ (u"ࠨࡷࡶࡩ࡛࠸ࡁࡑࡋࡆࡥࡱࡲࡳࠨம"), l1ll11l1l_cda_ (u"ࠩࡹࡩࡷࡺࡩࡤࡣ࡯ࡅࡱ࡯ࡧ࡯ࠩய"), l1ll11l1l_cda_ (u"ࠪࡸ࡮ࡳࡥࡴ࡮࡬ࡨࡪࡸࡴࡰࡱ࡯ࡸ࡮ࡶࡰ࡭ࡷࡪ࡭ࡳ࠭ர"),
                l1ll11l1l_cda_ (u"ࠫࡴࡼࡥࡳ࡮ࡤࡽࡸ࠭ற"), l1ll11l1l_cda_ (u"ࠬࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥࡅࡲࡰࡴࡸࠧல"), l1ll11l1l_cda_ (u"࠭࡭ࡢࡴࡪ࡭ࡳࡨ࡯ࡵࡶࡲࡱࠬள"), l1ll11l1l_cda_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴࡳࠨழ"), l1ll11l1l_cda_ (u"ࠨ࡮࡬ࡲࡰ࠭வ"), l1ll11l1l_cda_ (u"ࠩࡶࡸࡷ࡫ࡴࡤࡪ࡬ࡲ࡬࠭ஶ"), l1ll11l1l_cda_ (u"ࠪࡹࡳ࡯ࡦࡰࡴࡰࠫஷ"), l1ll11l1l_cda_ (u"ࠫࡸࡺࡡࡵ࡫ࡦ࠵ࠬஸ"),
                l1ll11l1l_cda_ (u"ࠬࡹࡥࡵࡷࡳࠫஹ"), l1ll11l1l_cda_ (u"࠭ࡪࡸࡲ࡯ࡥࡾ࡫ࡲࠨ஺"), l1ll11l1l_cda_ (u"ࠧࡤࡪࡨࡧࡰࡌ࡬ࡢࡵ࡫ࠫ஻"), l1ll11l1l_cda_ (u"ࠨࡕࡰࡥࡷࡺࡔࡗࠩ஼"), l1ll11l1l_cda_ (u"ࠩࡹ࠴࠵࠷ࠧ஽"), l1ll11l1l_cda_ (u"ࠪࡧࡷ࡫࡭ࡦࠩா"), l1ll11l1l_cda_ (u"ࠫࡩࡵࡣ࡬ࠩி"), l1ll11l1l_cda_ (u"ࠬࡧࡵࡵࡱࡶࡸࡦࡸࡴࠨீ"), l1ll11l1l_cda_ (u"࠭ࡩࡥ࡮ࡨ࡬࡮ࡪࡥࠨு"), l1ll11l1l_cda_ (u"ࠧ࡮ࡱࡧࡩࡸ࠭ூ"),
               l1ll11l1l_cda_ (u"ࠨࡨ࡯ࡥࡸ࡮ࠧ௃"), l1ll11l1l_cda_ (u"ࠩࡲࡺࡪࡸࠧ௄"), l1ll11l1l_cda_ (u"ࠪࡰࡪ࡬ࡴࠨ௅"), l1ll11l1l_cda_ (u"ࠫ࡭࡯ࡤࡦࠩெ"), l1ll11l1l_cda_ (u"ࠬࡶ࡬ࡢࡻࡨࡶ࠺࠭ே"), l1ll11l1l_cda_ (u"࠭ࡩ࡮ࡣࡪࡩࠬை"), l1ll11l1l_cda_ (u"ࠧࡌࡎࡌࡏࡓࡏࡊࠨ௉"), l1ll11l1l_cda_ (u"ࠨࡥࡲࡱࡵࡧ࡮ࡪࡱࡱࡷࠬொ"), l1ll11l1l_cda_ (u"ࠩࡵࡩࡸࡺ࡯ࡳࡧࠪோ"), l1ll11l1l_cda_ (u"ࠪࡧࡱ࡯ࡣ࡬ࡕ࡬࡫ࡳ࠭ௌ"),
                l1ll11l1l_cda_ (u"ࠫࡸࡩࡨࡦࡦࡸࡰࡪ்࠭"), l1ll11l1l_cda_ (u"ࠬࡥࡣࡰࡷࡱࡸࡩࡵࡷ࡯ࡡࠪ௎"), l1ll11l1l_cda_ (u"࠭ࡣࡰࡷࡱࡸࡩࡵࡷ࡯ࠩ௏"), l1ll11l1l_cda_ (u"ࠧࡳࡧࡪ࡭ࡴࡴࠧௐ"), l1ll11l1l_cda_ (u"ࠨࡧ࡯ࡷࡪ࠭௑"), l1ll11l1l_cda_ (u"ࠩࡦࡳࡳࡺࡲࡰ࡮ࡶࠫ௒"), l1ll11l1l_cda_ (u"ࠪࡴࡷ࡫࡬ࡰࡣࡧࠫ௓"), l1ll11l1l_cda_ (u"ࠫࡴࡸࡹࡨ࡫ࡱࡥࡱࡴࡥࠨ௔"), l1ll11l1l_cda_ (u"ࠬࡹࡴࡺ࡮ࡨࠫ௕"),
                l1ll11l1l_cda_ (u"࠭࠶࠳࠲ࡳࡼࠬ௖"), l1ll11l1l_cda_ (u"ࠧ࠴࠺࠺ࡴࡽ࠭ௗ"), l1ll11l1l_cda_ (u"ࠨࡲࡲࡷࡹ࡫ࡲࠨ௘"), l1ll11l1l_cda_ (u"ࠩࡽࡲ࡮ࡱ࡮ࡪࡧࠪ௙"), l1ll11l1l_cda_ (u"ࠪࡷࡪࡱࡵ࡯ࡦࠪ௚"), l1ll11l1l_cda_ (u"ࠫࡸ࡮࡯ࡸࡃࡩࡸࡪࡸࡓࡦࡥࡲࡲࡩࡹࠧ௛"), l1ll11l1l_cda_ (u"ࠬ࡯࡭ࡢࡩࡨࡷࠬ௜"), l1ll11l1l_cda_ (u"࠭ࡒࡦ࡭࡯ࡥࡲࡧࠧ௝"), l1ll11l1l_cda_ (u"ࠧࡴ࡭࡬ࡴࡆࡪࠧ௞"),
                 l1ll11l1l_cda_ (u"ࠨ࡮ࡨࡺࡪࡲࡳࠨ௟"), l1ll11l1l_cda_ (u"ࠩࡳࡥࡩࡪࡩ࡯ࡩࠪ௠"), l1ll11l1l_cda_ (u"ࠪࡳࡵࡧࡣࡪࡶࡼࠫ௡"), l1ll11l1l_cda_ (u"ࠫࡩ࡫ࡢࡶࡩࠪ௢"), l1ll11l1l_cda_ (u"ࠬࡼࡩࡥࡧࡲ࠷ࠬ௣"), l1ll11l1l_cda_ (u"࠭ࡣ࡭ࡱࡶࡩࠬ௤"), l1ll11l1l_cda_ (u"ࠧࡴ࡯ࡤࡰࡱࡺࡥࡹࡶࠪ௥"), l1ll11l1l_cda_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩ௦"), l1ll11l1l_cda_ (u"ࠩࡦࡰࡦࡹࡳࠨ௧"), l1ll11l1l_cda_ (u"ࠪࡥࡱ࡯ࡧ࡯ࠩ௨"),
                  l1ll11l1l_cda_ (u"ࠫࡳࡵࡴࡪࡥࡨࠫ௩"), l1ll11l1l_cda_ (u"ࠬࡳࡥࡥ࡫ࡤࠫ௪")]
            for l11l1llll11l1l_cda_ in l1ll1ll111l11l1l_cda_:
                l1ll1l11l11l1l_cda_=l1ll1l11l11l1l_cda_.replace(l11l1llll11l1l_cda_,l1ll11l1l_cda_ (u"࠭ࠧ௫"))
            cleanup=l1ll1l11l11l1l_cda_.replace(l1ll11l1l_cda_ (u"ࠧࡽࠩ௬"),l1ll11l1l_cda_ (u"ࠨࠢࠪ௭")).split()
            out={l1ll11l1l_cda_ (u"ࠩࡶࡩࡷࡼࡥࡳࠩ௮"): l1ll11l1l_cda_ (u"ࠪࠫ௯"), l1ll11l1l_cda_ (u"ࠫࡪ࠭௰"): l1ll11l1l_cda_ (u"ࠬ࠭௱"), l1ll11l1l_cda_ (u"࠭ࡦࡪ࡮ࡨࠫ௲"): l1ll11l1l_cda_ (u"ࠧࠨ௳"), l1ll11l1l_cda_ (u"ࠨࡵࡷࠫ௴"): l1ll11l1l_cda_ (u"ࠩࠪ௵")}
            if len(cleanup)==4:
                for l11l1llll11l1l_cda_ in cleanup:
                    if l11l1llll11l1l_cda_.isdigit():
                        out[l1ll11l1l_cda_ (u"ࠪࡩࠬ௶")]=l11l1llll11l1l_cda_
                    elif re.match(l1ll11l1l_cda_ (u"ࠫࡠࡧ࠭ࡻ࡟ࡾ࠶࠱ࢃ࡜ࡥࡽ࠶ࢁࠬ௷"),l11l1llll11l1l_cda_) and len(l11l1llll11l1l_cda_)<10:
                        out[l1ll11l1l_cda_ (u"ࠬࡹࡥࡳࡸࡨࡶࠬ௸")] = l11l1llll11l1l_cda_
                    elif len(l11l1llll11l1l_cda_)==22:
                        out[l1ll11l1l_cda_ (u"࠭ࡳࡵࠩ௹")] = l11l1llll11l1l_cda_
                    else:
                        out[l1ll11l1l_cda_ (u"ࠧࡧ࡫࡯ࡩࠬ௺")] = l11l1llll11l1l_cda_
                src=l1ll11l1l_cda_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࠨࡷ࠳ࡩࡤࡢ࠰ࡳࡰ࠴ࠫࡳ࠯࡯ࡳ࠸ࡄࡹࡴ࠾ࠧࡶࠪࡪࡃࠥࡴࠩ௻")%(out.get(l1ll11l1l_cda_ (u"ࠩࡶࡩࡷࡼࡥࡳࠩ௼")),out.get(l1ll11l1l_cda_ (u"ࠪࡪ࡮ࡲࡥࠨ௽")),out.get(l1ll11l1l_cda_ (u"ࠫࡸࡺࠧ௾")),out.get(l1ll11l1l_cda_ (u"ࠬ࡫ࠧ௿")))
    return src
url=l1ll11l1l_cda_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡨࡪࡡ࠯ࡲ࡯࠳ࡻ࡯ࡤࡦࡱ࠲࠵࠹࠶࠳࠺࠲࠸࠹ࡦ࠭ఀ")
url=l1ll11l1l_cda_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡩࡤࡢ࠰ࡳࡰ࠴ࡼࡩࡥࡧࡲ࠳࠶࠻࠱࠷࠸࠳࠽࠻࠼࠿ࡸࡧࡵࡷ࡯ࡧ࠽࠸࠴࠳ࡴࠬఁ")
def l1ll11l111l11l1l_cda_(content):
    l1ll11l1l_cda_ (u"ࠣࠤࠥࠑࠏࠦࠠࠡࠢࡖࡧࡦࡴࡳࠡࡨࡲࡶࠥࡼࡩࡥࡧࡲࠤࡱ࡯࡮࡬ࠢ࡬ࡲࡨࡲࡵࡥࡧࡧࠤࡪࡴࡣࡰࡦࡨࡨࠥࡵ࡮ࡦࠏࠍࠤࠥࠦࠠࠣࠤࠥం")
    l1ll11l11ll11l1l_cda_=l1ll11l1l_cda_ (u"ࠩࠪః")
    l1lll1111ll11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"ࠪ࡟ࡡ࠭ࠢ࡞ࡨ࡬ࡰࡪࡡ࡜ࠨࠤࡠ࡟࠿ࡢࡳ࡞ࠬ࡞ࡠࠬࠨ࡝ࠩ࠰࠮ࡃ࠮ࡡ࡜ࠨࠤࡠࠫఄ"),re.DOTALL).search(content)
    l1l1lll1l1l11l1l_cda_ = re.findall(l1ll11l1l_cda_ (u"ࠫࡵࡲࡡࡺࡧࡵࡣࡩࡧࡴࡢ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪఅ"),content,re.DOTALL)
    l1l1lll1l1l11l1l_cda_=l1l1lll1l1l11l1l_cda_[0] if l1l1lll1l1l11l1l_cda_ else l1ll11l1l_cda_ (u"ࠬ࠭ఆ")
    l1ll111l11l11l1l_cda_ = l1l1lll1l1l11l1l_cda_.replace(l1ll11l1l_cda_ (u"࠭ࠦࡲࡷࡲࡸࡀ࠭ఇ"),l1ll11l1l_cda_ (u"ࠧࠣࠩఈ"))
    l1ll1llllll11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"ࠨ࡝࡟ࠫࠧࡣࠪࡧ࡫࡯ࡩࡠࡢࠧࠣ࡟࠭࠾ࡡࡹࠪ࡜࡞ࠪࠦࡢ࠮࠮ࠬࡁࠬ࡟ࡡ࠭ࠢ࡞࠮ࠪఉ"),  re.DOTALL).search(l1ll111l11l11l1l_cda_)
    if l1lll1111ll11l1l_cda_:
        l1ll11l11ll11l1l_cda_ = l1lll1111ll11l1l_cda_.group(1)
    elif l1ll1llllll11l1l_cda_:
        l1ll11l11ll11l1l_cda_ = l1ll1llllll11l1l_cda_.group(1)
    else:
        l1ll11l11ll11l1l_cda_ = _1l1ll1111l11l1l_cda_(content)
        if not l1ll11l11ll11l1l_cda_:
            l1ll11l11ll11l1l_cda_ = _1ll11ll1ll11l1l_cda_(content)
    l1ll11l11ll11l1l_cda_ = l1ll11l11ll11l1l_cda_.replace(l1ll11l1l_cda_ (u"ࠤ࡟ࡠࠧఊ"), l1ll11l1l_cda_ (u"ࠥࠦఋ"))
    if l1ll11l11ll11l1l_cda_.startswith(l1ll11l1l_cda_ (u"ࠫࡺ࡭ࡧࡤࠩఌ")):
        l11l1l1ll11l1l_cda_ = lambda x: 0 if not x.isalpha() else -13 if l1ll11l1l_cda_ (u"ࠬࡇࠧ఍") <=x.upper()<=l1ll11l1l_cda_ (u"࠭ࡍࠨఎ") else 13
        l1ll11l11ll11l1l_cda_ = l1ll11l1l_cda_ (u"ࠧࠨఏ").join([chr((ord(x)-l11l1l1ll11l1l_cda_(x)) ) for x in l1ll11l11ll11l1l_cda_])
        l1ll11l11ll11l1l_cda_=l1ll11l11ll11l1l_cda_[:-7] + l1ll11l11ll11l1l_cda_[-4:]
    return l1ll11l11ll11l1l_cda_
def l1111ll1l11l1l_cda_(url,tryIT=4):
    l1ll11l1l_cda_ (u"ࠣࠤࠥࠑࠏࠦࠠࠡࠢࡵࡩࡹࡻࡲ࡯ࡵࠣࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠭ࠡࡷ࡯ࡶࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵࠮࠯࠰࠱ࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠭ࠡࡱࡵࠤࡱ࡯ࡳࡵࠢࡲࡪࠥࡡࠨࠨ࠹࠵࠴ࡵ࠭ࠬࠡࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡤࡦࡤ࠲ࡵࡲ࠯ࡷ࡫ࡧࡩࡴ࠵࠱࠺࠶࠹࠽࠾࠷ࡦࡀࡹࡨࡶࡸࡰࡡ࠾࠹࠵࠴ࡵ࠭ࠩ࠭࠰࠱࠲ࡢࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠐࠎࠥࠦࠠࠡࠤࠥࠦఐ")
    url = url.replace(l1ll11l1l_cda_ (u"ࠩ࠲ࡺ࡫࡯࡬࡮ࠩ఑"),l1ll11l1l_cda_ (u"ࠪࠫఒ"))
    if not l1ll11l1l_cda_ (u"ࠫࡪࡨࡤ࠯ࡥࡧࡥ࠳ࡶ࡬ࠨఓ") in url:
       url=l1ll11l1l_cda_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡣࡦ࠱ࡧࡩࡧ࠮ࡱ࡮࠲࠵࠵࠶ࡸ࠲࠲࠳࠳ࠬఔ")+url.split(l1ll11l1l_cda_ (u"࠭࠯ࠨక"))[-1]
    l1ll1lll11l11l1l_cda_=l1ll11l1l_cda_ (u"ࠧࡽࡅࡲࡳࡰ࡯ࡥ࠾ࡒࡋࡔࡘࡋࡓࡔࡋࡇࡁ࠶ࠬࡒࡦࡨࡨࡶࡪࡸ࠽ࡩࡶࡷࡴ࠿࠵࠯ࡴࡶࡤࡸ࡮ࡩ࠮ࡤࡦࡤ࠲ࡵࡲ࠯ࡧ࡮ࡲࡻࡵࡲࡡࡺࡧࡵ࠳࡫ࡲࡡࡴࡪ࠲ࡪࡱࡵࡷࡱ࡮ࡤࡽࡪࡸ࠮ࡤࡱࡰࡱࡪࡸࡣࡪࡣ࡯࠱࠸࠴࠲࠯࠳࠻࠲ࡸࡽࡦࠨఖ")
    content = l1l1l111l11l1l_cda_(url)
    src=[]
    if content==l1ll11l1l_cda_ (u"ࠨࠩగ"):
        src.append((l1ll11l1l_cda_ (u"ࠩࡐࡥࡹ࡫ࡲࡪࡣॅࠤࡿࡵࡳࡵࡣॅࠤࡺࡹࡵ࡯࡫जࡸࡾ࠭ఘ"),l1ll11l1l_cda_ (u"ࠪࠫఙ")))
    l1ll1llll1l11l1l_cda_ = content.find(l1ll11l1l_cda_ (u"࡙ࠫࡵࠠࡸ࡫ࡧࡩࡴࠦࡪࡦࡵࡷࠤࡳ࡯ࡥࡥࡱࡶࡸञࡶ࡮ࡦࠢࠪచ"))
    if l1ll1llll1l11l1l_cda_>0:
        src.append((l1ll11l1l_cda_ (u"࡚ࠬ࡯ࠡࡹ࡬ࡨࡪࡵࠠ࡫ࡧࡶࡸࠥࡴࡩࡦࡦࡲࡷࡹटࡰ࡯ࡧࠣࡻ࡚ࠥࡷࡰ࡫ࡰࠤࡰࡸࡡ࡫ࡷࠪఛ"),l1ll11l1l_cda_ (u"࠭ࠧజ")))
    elif not l1ll11l1l_cda_ (u"ࠧࡀࡹࡨࡶࡸࡰࡡࠨఝ") in url:
        l1l1l11l1ll11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"ࠨ࠾ࡤࠤࡩࡧࡴࡢ࠯ࡴࡹࡦࡲࡩࡵࡻࡀࠦ࠭࠴ࠪࡀࠫࠥࠤ࠭ࡅࡐ࠽ࡊࡁ࠲࠯ࡅࠩ࠿ࠪࡂࡔࡁࡗ࠾࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩఞ"), re.DOTALL).findall(content)
        for quality in l1l1l11l1ll11l1l_cda_:
             l111l11ll11l1l_cda_ = re.search(l1ll11l1l_cda_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨట"),quality[1])
             l1l1ll111ll11l1l_cda_ = quality[2]
             if l111l11ll11l1l_cda_:
                src.insert(0,(l1l1ll111ll11l1l_cda_,l111l11ll11l1l_cda_.group(1)))
    if not src:
        src = l1ll11l111l11l1l_cda_(content)
        if src:
            src+=l1ll1lll11l11l1l_cda_
        else:
            for i in range(tryIT):
                content = l1l1l111l11l1l_cda_(url)
                src = l1ll11l111l11l1l_cda_(content)
                if src:
                    src+=l1ll1lll11l11l1l_cda_
                    break
    if not src:
        if content.find(l1ll11l1l_cda_ (u"ࠪࡘࡪࡴࠠࡧ࡫࡯ࡱࠥࡰࡥࡴࡶࠣࡨࡴࡹࡴࠨఠ")):
            src=[(l1ll11l1l_cda_ (u"࡙ࠫ࡫࡮ࠡࡨ࡬ࡰࡲࠦࡪࡦࡵࡷࠤࡩࡵࡳࡵछࡳࡲࡾࠦࡤ࡭ࡣࠣࡹঁࡿࡴ࡬ࡱࡺࡲ࡮ࡱࣳࡸࠢࡳࡶࡪࡳࡩࡶ࡯࠱ࠤ࡜ࡺࡹࡤࡼ࡮ࡥࠥࡳ࡯ॽࡧࠣࡲ࡮࡫ࠠࡰࡤࡶॆࡺ࡭ࡩࡸࡣऊࠤࡵࡵࡰࡳࡣࡺࡲ࡮࡫ࠠࡻࡣࡶࡳࡧࣹࡷࠡࡲࡵࡩࡲ࡯ࡵ࡮ࠩడ"),l1ll11l1l_cda_ (u"ࠬ࠭ఢ"))]
    return src
def l1l1llll1ll11l1l_cda_(url,quality=0):
    l1ll11l1l_cda_ (u"ࠨࠢࠣࠏࠍࠤࠥࠦࠠࡳࡧࡷࡹࡷࡴࡳࠡࡷࡵࡰࠥࡺ࡯ࠡࡸ࡬ࡨࡪࡵࠍࠋࠢࠣࠤࠥࠨࠢࠣణ")
    src = l1111ll1l11l1l_cda_(url)
    if type(src)==list:
        selected=src[quality]
        src = l1111ll1l11l1l_cda_(selected[1])
    return src
def l1l1l1ll11l11l1l_cda_(l1ll1l11lll11l1l_cda_):
    if l1ll1l11lll11l1l_cda_.startswith(l1ll11l1l_cda_ (u"ࠧ࠰࠱ࠪత")):
        return l1ll11l1l_cda_ (u"ࠨࡪࡷࡸࡵࡹ࠺ࠨథ")+l1ll1l11lll11l1l_cda_
    else:
        return l1ll1l11lll11l1l_cda_
url=l1ll11l1l_cda_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡤࡦࡤ࠲ࡵࡲ࠯ࡳࡣࡷࡳࡼࡴࡩ࡬࠻࠼࠳࡫ࡵ࡬ࡥࡧࡵ࠱࡬ࡲ࡯ࡸࡰࡼ࠳࠷࠭ద")
def _1ll111111l11l1l_cda_(url,recursive=True,items=[],folders=[]):
    content = l1l1l111l11l1l_cda_(url)
    items = items
    folders = folders
    l1lll1lll1l11l1l_cda_ = [(a.start(), a.end()) for a in re.finditer(l1ll11l1l_cda_ (u"ࠪࡨࡦࡺࡡ࠮ࡨ࡬ࡰࡪࡥࡩࡥ࠿ࠥࠫధ"), content)]
    l1lll1lll1l11l1l_cda_.append( (-1,-1) )
    for i in range(len(l1lll1lll1l11l1l_cda_[:-1])):
        l1l1ll1l1ll11l1l_cda_  = content[ l1lll1lll1l11l1l_cda_[i][1]:l1lll1lll1l11l1l_cda_[i+1][0] ]
        match   = re.compile(l1ll11l1l_cda_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡱ࡯࡮࡬࠯ࡷ࡭ࡹࡲࡥ࠮ࡸ࡬ࡷ࡮ࡺࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪన")).findall(l1l1ll1l1ll11l1l_cda_)
        l1ll1l1l11l11l1l_cda_  = re.compile(l1ll11l1l_cda_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡺࡩ࡮ࡧ࠰ࡸ࡭ࡻ࡭ࡣ࠯ࡩࡳࡱࡪࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ఩")).findall(l1l1ll1l1ll11l1l_cda_)
        l1l1l11llll11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡩࡷࡰࡦࡳࡧࡩ࡭࠯࡫ࡨ࠲࡯ࡣࡰࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩప")).findall(l1l1ll1l1ll11l1l_cda_)
        l1l1l11llll11l1l_cda_ = [a.replace(l1ll11l1l_cda_ (u"ࠧ࠽ࡵࡳࡥࡳࠦࡣ࡭ࡣࡶࡷࡂࠨࡨࡥ࠯࡬ࡧࡴ࠳ࡥ࡭ࡧࡰࠦࡃ࠭ఫ"),l1ll11l1l_cda_ (u"ࠨࠩబ")) for a in l1l1l11llll11l1l_cda_]
        l1l1l1lllll11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"ࠩ࠿࡭ࡲ࡭࡛ࠡ࡞ࡷࡠࡳࡣࠫࡤ࡮ࡤࡷࡸࡃࠢࡵࡪࡸࡱࡧࠦࡴࡩࡷࡰࡦ࠲ࡨࡧࠡࡶ࡫ࡹࡲࡨ࠭ࡴ࡫ࡽࡩࠧࡡࠠ࡝ࡶ࡟ࡲࡢ࠱ࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࡟ࠥࡢࡴ࡝ࡰࡠ࠯ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠪభ"),re.DOTALL).findall(l1l1ll1l1ll11l1l_cda_)
        if match:
            url = l1l1l1l11ll11l1l_cda_+ match[0][0]
            title = l1ll11lll1l11l1l_cda_(match[0][1])
            l1ll1lll1ll11l1l_cda_ =  l1ll1l11l1l11l1l_cda_(l1ll1l1l11l11l1l_cda_[0]) if l1ll1l1l11l11l1l_cda_ else l1ll11l1l_cda_ (u"ࠪࠫమ")
            code = l1l1l11llll11l1l_cda_[0] if l1l1l11llll11l1l_cda_ else l1ll11l1l_cda_ (u"ࠫࠬయ")
            l1ll1l1ll1l11l1l_cda_ = l1ll11lll1l11l1l_cda_(l1l1l1lllll11l1l_cda_[0][0]) if l1l1l1lllll11l1l_cda_ else l1ll11l1l_cda_ (u"ࠬ࠭ర")
            l1ll1l11lll11l1l_cda_ = l1l1l1ll11l11l1l_cda_(l1l1l1lllll11l1l_cda_[0][1]) if l1l1l1lllll11l1l_cda_ else l1ll11l1l_cda_ (u"࠭ࠧఱ")
            items.append({l1ll11l1l_cda_ (u"ࠧࡶࡴ࡯ࠫల"):url,l1ll11l1l_cda_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧళ"):unicode(title,l1ll11l1l_cda_ (u"ࠩࡸࡸ࡫࠳࠸ࠨఴ")),l1ll11l1l_cda_ (u"ࠪࡧࡴࡪࡥࠨవ"):code.encode(l1ll11l1l_cda_ (u"ࠫࡺࡺࡦ࠮࠺ࠪశ")),l1ll11l1l_cda_ (u"ࠬࡶ࡬ࡰࡶࠪష"):unicode(l1ll1l1ll1l11l1l_cda_,l1ll11l1l_cda_ (u"࠭ࡵࡵࡨ࠰࠼ࠬస")),l1ll11l1l_cda_ (u"ࠧࡪ࡯ࡪࠫహ"):l1ll1l11lll11l1l_cda_,l1ll11l1l_cda_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪ఺"):l1ll1lll1ll11l1l_cda_})
    l1lll1l1lll11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡩࡳࡱࡪࡥࡳ࠯ࡤࡶࡪࡧࠢ࠿࡝ࠣࡠࡹࡢ࡮࡞࠭࠿ࡥࡠࠦ࡜ࡵ࡞ࡱࡡ࠰࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ఻"),re.DOTALL).findall(content)
    l1l1l1lll1l11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"ࠪࡀࡸࡶࡡ࡯࡝ࠣࡠࡹࡢ࡮࡞࠭ࡦࡰࡦࡹࡳ࠾ࠤࡱࡥࡲ࡫࠭ࡧࡱ࡯ࡨࡪࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄ఼ࠧ"),re.DOTALL).findall(content)
    if l1lll1l1lll11l1l_cda_:
        if len(l1l1l1lll1l11l1l_cda_) > len(l1lll1l1lll11l1l_cda_): l1l1l1lll1l11l1l_cda_ = l1l1l1lll1l11l1l_cda_[1:]
        for i in range(len(l1lll1l1lll11l1l_cda_)):
            folders.append( {l1ll11l1l_cda_ (u"ࠫࡺࡸ࡬ࠨఽ"):l1lll1l1lll11l1l_cda_[i],l1ll11l1l_cda_ (u"ࠬࡺࡩࡵ࡮ࡨࠫా"): html_entity_decode(l1l1l1lll1l11l1l_cda_[i]) })
    l1lllll1ll11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࡄࡱࡱࡸࡷࡵ࡬ࠣࡀ࡞ࠤࡡࡺ࡜࡯࡟࠮ࡀࡦࠦࡣ࡭ࡣࡶࡷࡂࠨࡢࡵࡰࠣࡦࡹࡴ࠭ࡱࡴ࡬ࡱࡦࡸࡹࠡࡤ࡯ࡳࡨࡱࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧి"),re.DOTALL).findall(content)
    l1lllll1ll11l1l_cda_ = l1lllll1ll11l1l_cda_[0] if l1lllll1ll11l1l_cda_ else False
    l1l1l11ll1l11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡦࡰࡦࡹࡳ࠾ࠤࡳࡶࡪࡼࡩࡰࡷࡶࠦࡃ࠭ీ")).findall(content)
    l1l1l11ll1l11l1l_cda_ = l1l1l11ll1l11l1l_cda_[0] if l1l1l11ll1l11l1l_cda_ else False
    l1111l1ll11l1l_cda_ = (l1l1l11ll1l11l1l_cda_,l1lllll1ll11l1l_cda_)
    if recursive and l1lllll1ll11l1l_cda_:
        _1ll111111l11l1l_cda_(l1lllll1ll11l1l_cda_,recursive,items,folders)
    return items,folders,l1111l1ll11l1l_cda_
def get_UserFolder_obserwowani(url):
    content = l1l1l111l11l1l_cda_(url)
    items = []
    folders = []
    match=re.compile(l1ll11l1l_cda_ (u"ࠨࡂࡸঀࡾࡺ࡫ࡰࡹࡱ࡭ࡨࡿࠨ࠯ࠬࡂ࠭ࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡳࡥࡳ࡫࡬࠮ࡨࡲࡳࡹ࡫ࡲࠣࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩు"), re.DOTALL).findall(content)
    if len(match) > 0:
        data = re.compile(l1ll11l1l_cda_ (u"ࠩࡧࡥࡹࡧ࠭ࡶࡵࡨࡶࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠭࠴ࠪࡀࠫࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧూ"), re.DOTALL).findall(match[0])
        for l11l1llll11l1l_cda_ in data:
            folders.append( {l1ll11l1l_cda_ (u"ࠪࡹࡷࡲࠧృ"):l11l1llll11l1l_cda_[1]+l1ll11l1l_cda_ (u"ࠫ࠴࡬࡯࡭ࡦࡨࡶ࠲࡭࡬ࡰࡹࡱࡽࠬౄ"),l1ll11l1l_cda_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ౅"): html_entity_decode(l11l1llll11l1l_cda_[0]),l1ll11l1l_cda_ (u"࠭ࡩ࡮ࡩࠪె"):l1l1l1ll11l11l1l_cda_(l11l1llll11l1l_cda_[3]) })
    return items,folders
def l1l111l1l11l1l_cda_( l1l11llll11l1l_cda_,recursive=True,filtr_items={}):
    items=[]
    folders=[]
    items,folders,l1111l1ll11l1l_cda_ =_1ll111111l11l1l_cda_(l1l11llll11l1l_cda_,recursive,items,folders)
    if recursive:
        l1111l1ll11l1l_cda_ = (False,False)
    _1l1ll1l11l11l1l_cda_=[]
    if filtr_items:
        l1ll1l1l1ll11l1l_cda_=0
        key = filtr_items.keys()[0]
        value = filtr_items[key].encode(l1ll11l1l_cda_ (u"ࠢࡶࡶࡩ࠱࠽ࠨే"))
        for item in items:
            if value in item.get(key):
                l1ll1l1l1ll11l1l_cda_ +=1
                _1l1ll1l11l11l1l_cda_.append(item)
        items = _1l1ll1l11l11l1l_cda_
        print l1ll11l1l_cda_ (u"ࠨࡈ࡬ࡰࡹ࡫ࡤࠡࠧࡧࠤ࡮ࡺࡥ࡮ࡵࠣࡦࡾ࡛ࠦࠦࡵࠣ࡭ࡳࠦࠥࡴ࡟ࠪై") %(l1ll1l1l1ll11l1l_cda_, value, key)
    return items,folders,l1111l1ll11l1l_cda_
def l1lll1ll1ll11l1l_cda_(l):
    l1ll11l1l_cda_ (u"ࠤࠥࠦࠒࠐࠠࠡࠢࠣࡧࡴࡴࡶࡦࡴࡷࡷࠥࡲࡩࡴࡶࠣࡸࡴࠦࡤࡪࡥࡷ࡭ࡴࡴࡡࡳࡻࠣࡪࡴࡸࠠࡴࡣࡩࡩࠥࡪࡡࡵࡣࠣࡴ࡮ࡩࡵࡱࠏࠍࠤࠥࠦࠠࠣࠤࠥ౉")
    return dict(zip(range(len(l)),l))
def l111lllll11l1l_cda_(l1ll1ll1lll11l1l_cda_):
    l1lll1lll11l1l_cda_ = [
    (l1ll11l1l_cda_ (u"ࠪईࠬొ"), l1ll11l1l_cda_ (u"ࠫࡦ࠭ో")),(l1ll11l1l_cda_ (u"ࠬऋࠧౌ"), l1ll11l1l_cda_ (u"࠭ࡡࠨ్")),(l1ll11l1l_cda_ (u"ࠧङࠩ౎"), l1ll11l1l_cda_ (u"ࠨࡧࠪ౏")),(l1ll11l1l_cda_ (u"ࠩजࠫ౐"), l1ll11l1l_cda_ (u"ࠪࡩࠬ౑")),(l1ll11l1l_cda_ (u"ࠫࣘ࠭౒"), l1ll11l1l_cda_ (u"ࠬࡵࠧ౓")),(l1ll11l1l_cda_ (u"࠭ࣳࠨ౔"), l1ll11l1l_cda_ (u"ࠧࡰౕࠩ")),(l1ll11l1l_cda_ (u"ࠨईౖࠪ"), l1ll11l1l_cda_ (u"ࠩࡦࠫ౗")),
    (l1ll11l1l_cda_ (u"ࠪऋࠬౘ"), l1ll11l1l_cda_ (u"ࠫࡨ࠭ౙ")),(l1ll11l1l_cda_ (u"ࠬेࠧౚ"), l1ll11l1l_cda_ (u"࠭࡬ࠨ౛")),(l1ll11l1l_cda_ (u"ࠧृࠩ౜"), l1ll11l1l_cda_ (u"ࠨ࡮ࠪౝ")),(l1ll11l1l_cda_ (u"ࠩॆࠫ౞"), l1ll11l1l_cda_ (u"ࠪࡲࠬ౟")),(l1ll11l1l_cda_ (u"ࠫॉ࠭ౠ"), l1ll11l1l_cda_ (u"ࠬࡴࠧౡ")),(l1ll11l1l_cda_ (u"࠭ग़ࠨౢ"), l1ll11l1l_cda_ (u"ࠧࡴࠩౣ")),(l1ll11l1l_cda_ (u"ࠨढ़ࠪ౤"), l1ll11l1l_cda_ (u"ࠩࡶࠫ౥")),
    (l1ll11l1l_cda_ (u"ࠪॽࠬ౦"), l1ll11l1l_cda_ (u"ࠫࡿ࠭౧")),(l1ll11l1l_cda_ (u"ࠬঀࠧ౨"), l1ll11l1l_cda_ (u"࠭ࡺࠨ౩")),(l1ll11l1l_cda_ (u"ࠧॼࠩ౪"), l1ll11l1l_cda_ (u"ࠨࡼࠪ౫")),(l1ll11l1l_cda_ (u"ࠩॿࠫ౬"), l1ll11l1l_cda_ (u"ࠪࡾࠬ౭")),(l1ll11l1l_cda_ (u"ࠫࠥ࠭౮"),l1ll11l1l_cda_ (u"ࠬࡥࠧ౯"))]
    for a,b in l1lll1lll11l1l_cda_:
        l1ll1ll1lll11l1l_cda_ = l1ll1ll1lll11l1l_cda_.replace(a,b)
    return l1ll1ll1lll11l1l_cda_
l1ll1l11l1l11l1l_cda_ = lambda l1ll1lll1ll11l1l_cda_: sum([a*b for a,b in zip([1,60,3600], map(int,l1ll1lll1ll11l1l_cda_.split(l1ll11l1l_cda_ (u"࠭࠺ࠨ౰"))[::-1]))])
url=l1ll11l1l_cda_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡩࡤࡢ࠰ࡳࡰ࠴ࡼࡩࡥࡧࡲ࠳ࡸ࡮࡯ࡸ࠱ࡱࡥࡿࡴࡡࡤࡼࡲࡲࡾࡥ࠲࠱࠳࠳ࠫ౱")
url=l1ll11l1l_cda_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡣࡥࡣ࠱ࡴࡱ࠵ࡶࡪࡦࡨࡳ࠴ࡹࡨࡰࡹ࠲ࡲࡦࢀ࡮ࡢࡥࡽࡳࡳࡿ࡟࠳࠲࠴࠴ࡄࡪࡵࡳࡣࡷ࡭ࡴࡴ࠽࡬ࡴࡲࡸࡰ࡯ࡥࠧࡵࡨࡧࡹ࡯࡯࡯࠿ࠩࡵࡺࡧ࡬ࡪࡶࡼࡁࡦࡲ࡬ࠧࡵࡨࡧࡹ࡯࡯࡯࠿ࠩࡷࡂࡨࡥࡴࡶࠩࡷࡪࡩࡴࡪࡱࡱࡁࠬ౲")
url = l1ll11l1l_cda_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡤࡦࡤ࠲ࡵࡲ࠯ࡪࡰࡩࡳ࠴࡬ࡩ࡭࡯ࡢࡴࡱࡥ࠲࠱࠳࠹ࠫ౳")
def l1ll1l11ll11l1l_cda_(url,l1lll11l1ll11l1l_cda_=False,l1l1ll11l1l11l1l_cda_=1):
    url=l111lllll11l1l_cda_(url)
    content = l1l1l111l11l1l_cda_(url)
    l1lll1l111l11l1l_cda_=re.compile(l1ll11l1l_cda_ (u"ࠪࡀࡱࡧࡢࡦ࡮ࠫ࠲࠯ࡅࠩ࠽࠱࡯ࡥࡧ࡫࡬࠿ࠩ౴"), re.DOTALL).findall(content)
    l1lllll1ll11l1l_cda_ =re.compile(l1ll11l1l_cda_ (u"ࠫࡁࡧࠠࡤ࡮ࡤࡷࡸࡃࠢࡴࡤࡰࡆ࡮࡭ࡎࡦࡺࡷࠤࡧࡺ࡮࠮࡯ࡼࠤࡧࡺ࡮࠮࡮ࡤࡶ࡬࡫ࠠࡧ࡫ࡻ࡭ࡲ࡭ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ౵")).findall(content)
    items=[]
    for label in l1lll1l111l11l1l_cda_:
        label = html_entity_decode(label)
        l1ll11111ll11l1l_cda_=l1ll11l1l_cda_ (u"ࠬ࠭౶")
        if label.find(l1ll11l1l_cda_ (u"࠭ࡰࡳࡧࡰ࡭ࡺࡳࠧ౷"))>0:
            if l1lll11l1ll11l1l_cda_:
                l1ll11111ll11l1l_cda_ =l1ll11l1l_cda_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡱࡷࡵࡴࡱ࡫࡝ࠩࡒࠬ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ౸")
            else: continue
        l1ll1l1ll1l11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"ࠨࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮࠮ࠨࠧ౹")).findall(label)
        l1lll1l11ll11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭࠭ࠧࠦࠧ౺")).findall(label)
        l1l1ll111ll11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"ࠪࡀࡸࡶࡡ࡯ࠢࡦࡰࡦࡹࡳ࠾ࠤ࡫ࡨ࠲࡯ࡣࡰ࠯ࡨࡰࡪࡳࠠࡩࡦ࠰ࡩࡱ࡫࡭࠮ࡲࡲࡷࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ౻")).findall(label)
        l1ll1lll1ll11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"ࠫࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡳࡥࡆ࡮ࡨࡱࠧࡄ࡜ࡴࠬࠫ࠲࠯ࡅࠩ࡝ࡵ࠭ࡀ࠴ࡹࡰࡢࡰࡁࠫ౼")).findall(label)
        title=re.compile(l1ll11l1l_cda_ (u"ࠬࡂࡡࠡࡥ࡯ࡥࡸࡹ࠽ࠣ࠰࠭ࡃࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫ࠱ࡹ࡭ࡩ࡫࡯࠰࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ౽")).findall(label)
        l1l1l111lll11l1l_cda_ = l1ll11l1l_cda_ (u"࠭ࡎࡰࡹࡲय़ऌ࠭౾") if label.find(l1ll11l1l_cda_ (u"ࠧࡏࡱࡺࡳॠऍࠧ౿"))>0 else l1ll11l1l_cda_ (u"ࠨࠩಀ")
        l1lll11ll1l11l1l_cda_ = l1ll11l1l_cda_ (u"ࠩࠪಁ")
        if title:
            if len(title[0])==2:
                url = l1l1l1l11ll11l1l_cda_+ title[0][0] if not title[0][0].startswith(l1ll11l1l_cda_ (u"ࠪ࡬ࡹࡺࡰࠨಂ")) else title[0][0]
                title = l1ll11lll1l11l1l_cda_(title[0][1].split(l1ll11l1l_cda_ (u"ࠫࡁ࠭ಃ"))[0].strip())
                l1ll1lll1ll11l1l_cda_ = l1ll1l11l1l11l1l_cda_(l1ll1lll1ll11l1l_cda_[0]) if l1ll1lll1ll11l1l_cda_ else l1ll11l1l_cda_ (u"ࠬ࠭಄")
                code = l1ll11111ll11l1l_cda_
                code += l1l1ll111ll11l1l_cda_[0] if l1l1ll111ll11l1l_cda_ else l1ll11l1l_cda_ (u"࠭ࠧಅ")
                l1ll1l1ll1l11l1l_cda_ = l1ll11lll1l11l1l_cda_(l1ll1l1ll1l11l1l_cda_[0]) if l1ll1l1ll1l11l1l_cda_ else l1ll11l1l_cda_ (u"ࠧࠨಆ")
                l1ll1l11lll11l1l_cda_ = l1l1l1ll11l11l1l_cda_(l1lll1l11ll11l1l_cda_[0]) if l1lll1l11ll11l1l_cda_ else l1ll11l1l_cda_ (u"ࠨࠩಇ")
                if l1l1ll11l1l11l1l_cda_:
                    l1ll1l1ll1l11l1l_cda_ =l1ll11l1l_cda_ (u"ࠩ࡞ࡆࡢࠫࡳ࡜࠱ࡅࡡࡡࡴࠥࡴࠩಈ")%(title,l1ll1l1ll1l11l1l_cda_)
                    title,l1lll11ll1l11l1l_cda_,l1l1ll11lll11l1l_cda_ = l111l1l1l11l1l_cda_(title)
                items.append({l1ll11l1l_cda_ (u"ࠪࡹࡷࡲࠧಉ"):url,l1ll11l1l_cda_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪಊ"):unicode(title,l1ll11l1l_cda_ (u"ࠬࡻࡴࡧ࠯࠻ࠫಋ")),l1ll11l1l_cda_ (u"࠭ࡹࡦࡣࡵࠫಌ"):l1lll11ll1l11l1l_cda_,l1ll11l1l_cda_ (u"ࠧࡤࡱࡧࡩࠬ಍"):code,l1ll11l1l_cda_ (u"ࠨࡲ࡯ࡳࡹ࠭ಎ"):unicode(l1ll1l1ll1l11l1l_cda_,l1ll11l1l_cda_ (u"ࠩࡸࡸ࡫࠳࠸ࠨಏ")),l1ll11l1l_cda_ (u"ࠪ࡭ࡲ࡭ࠧಐ"):l1ll1l11lll11l1l_cda_,l1ll11l1l_cda_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭಑"):l1ll1lll1ll11l1l_cda_,l1ll11l1l_cda_ (u"ࠬࡴࡥࡸࠩಒ"):l1l1l111lll11l1l_cda_,})
    if items and l1lllll1ll11l1l_cda_:
        l1lllll1ll11l1l_cda_ = [p for p in l1lllll1ll11l1l_cda_ if l1ll11l1l_cda_ (u"࠭࠯ࡷ࡫ࡧࡩࡴ࠭ಓ") in p]
        l1lllll1ll11l1l_cda_ = l1l1l1l11ll11l1l_cda_+ l1lllll1ll11l1l_cda_[-1] if l1lllll1ll11l1l_cda_ else False
    return items,l1lllll1ll11l1l_cda_
def l1lll1l1l1l11l1l_cda_(items):
    for i in items:
        print i.get(l1ll11l1l_cda_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ಔ"))
        print l1ll11l1l_cda_ (u"ࠨࡽࠥࡸ࡮ࡺ࡬ࡦࠤ࠽ࠦࠪࡹࠢ࠭ࠤࡸࡶࡱࠨ࠺ࠣࠧࡶࠦ࠱ࠨࡣࡰࡦࡨࠦ࠿ࠨࠥࡴࠤࢀࠫಕ") % (i.get(l1ll11l1l_cda_ (u"ࠩࡷ࡭ࡹࡲࡥࠨಖ")),i.get(l1ll11l1l_cda_ (u"ࠪࡹࡷࡲࠧಗ")),i.get(l1ll11l1l_cda_ (u"ࠫࡨࡵࡤࡦࠩಘ")))
def l111l1l1l11l1l_cda_(title):
    pattern = re.compile(l1ll11l1l_cda_ (u"ࡷࠨ࡛ࠩ࡞࡞ࡿࡀ࠲࠯࠭࡞࡟ࡡࠧಙ"))
    year=l1ll11l1l_cda_ (u"࠭ࠧಚ")
    label=l1ll11l1l_cda_ (u"ࠧࠨಛ")
    l1l1l1l1l1l11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"ࠨࠪࡂ࠾ࡱ࡫࡫ࡵࡱࡵࢀࡵࡲࡼࡥࡷࡥࡦ࡮ࡴࡧࡽࡰࡤࡴ࡮ࡹ࡛ࡺ࡟࠭࠭ࠬಜ"), flags=re.I | re.X).findall(title.lower())
    if l1l1l1l1l1l11l1l_cda_:
        label = l1ll11l1l_cda_ (u"ࠩࠣ࡟ࡈࡕࡌࡐࡔࠣࡰ࡮࡭ࡨࡵࡩࡵࡩࡪࡴ࡝ࠡࠧࡶࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ಝ") % l1ll11l1l_cda_ (u"ࠪࠤࠬಞ").join(l1l1l1l1l1l11l1l_cda_)
    l1l1lllll1l11l1l_cda_=[l1ll11l1l_cda_ (u"ࠫࡱ࡫࡫ࡵࡱࡵࠫಟ"),l1ll11l1l_cda_ (u"ࠬࡪࡵࡣࡤ࡬ࡲ࡬࠭ಠ"),l1ll11l1l_cda_ (u"࠭ࠠࡱ࡮ࠣࠫಡ"),l1ll11l1l_cda_ (u"ࠧࡧࡷ࡯ࡰࠬಢ"),l1ll11l1l_cda_ (u"ࠨࡪࡧࠫಣ"),l1ll11l1l_cda_ (u"ࠩ࡟࠮ࠬತ"),l1ll11l1l_cda_ (u"ࠪ࠻࠷࠶ࡰࠨಥ"),l1ll11l1l_cda_ (u"ࠫ࠶࠶࠸࠱ࡲࠪದ"),l1ll11l1l_cda_ (u"ࠬ࠺࠸࠱ࡲࠪಧ"),l1ll11l1l_cda_ (u"࠭ࠢࠨನ")]
    for l1ll111ll1l11l1l_cda_ in l1l1lllll1l11l1l_cda_:
        title = re.sub(l1ll111ll1l11l1l_cda_,l1ll11l1l_cda_ (u"ࠧࠨ಩"),title,flags=re.I | re.X)
    l1l1l111l1l11l1l_cda_ = re.findall(l1ll11l1l_cda_ (u"ࠨ࡞ࡧࡿ࠹ࢃࠧಪ"),title)
    if l1l1l111l1l11l1l_cda_:
        year = l1l1l111l1l11l1l_cda_[-1]
        title = re.sub(l1l1l111l1l11l1l_cda_[-1],l1ll11l1l_cda_ (u"ࠩࠪಫ"),title)
    title = pattern.split(title)[0]
    return title.strip(), year, label.strip()
url=l1ll11l1l_cda_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡥࡧࡥ࠳ࡶ࡬࠰ࡸ࡬ࡨࡪࡵ࠯࠹࠷࠴࠶࠶࠶࠶ࠨಬ")
url=l1ll11l1l_cda_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡦࡨࡦ࠴ࡰ࡭࠱ࡹ࡭ࡩ࡫࡯࠰࠳࠷࠹࠹࠽࠵࠸࠵࠳ࠫಭ")
def l1l1llll11l11l1l_cda_(l111l11ll11l1l_cda_):
    if l111l11ll11l1l_cda_.startswith(l1ll11l1l_cda_ (u"ࠬ࠵࠯ࠨಮ")):
        l111l11ll11l1l_cda_ = l1ll11l1l_cda_ (u"࠭ࡨࡵࡶࡳࡷࠬಯ")+l111l11ll11l1l_cda_
    elif l111l11ll11l1l_cda_.startswith(l1ll11l1l_cda_ (u"ࠧ࠰ࠩರ")):
        l111l11ll11l1l_cda_ = l1ll11l1l_cda_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡣࡥࡣ࠱ࡴࡱ࠭ಱ")+l111l11ll11l1l_cda_
    elif not l111l11ll11l1l_cda_.startswith(l1ll11l1l_cda_ (u"ࠩ࡫ࡸࡹࡶࠧಲ")):
        l111l11ll11l1l_cda_=l1ll11l1l_cda_ (u"ࠪࠫಳ")
    return l111l11ll11l1l_cda_
def grabInforFromLink(url):
    out={}
    if not l1ll11l1l_cda_ (u"ࠫࡼࡽࡷ࠯ࡥࡧࡥ࠳ࡶ࡬࠰ࡸ࡬ࡨࡪࡵ࠯ࠨ಴") in url:
        return out
    content = l1l1l111l11l1l_cda_(url)
    l1ll1l1ll1l11l1l_cda_=re.compile(l1ll11l1l_cda_ (u"ࠬࡂ࡭ࡦࡶࡤࠤࡵࡸ࡯ࡱࡧࡵࡸࡾࡃࠢࡰࡩ࠽ࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠣࠢࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫವ"),re.DOTALL).findall(content)
    title=re.compile(l1ll11l1l_cda_ (u"࠭࠼࡮ࡧࡷࡥࠥࡶࡲࡰࡲࡨࡶࡹࡿ࠽ࠣࡱࡪ࠾ࡹ࡯ࡴ࡭ࡧࠥࠤࡨࡵ࡮ࡵࡧࡱࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ಶ")).findall(content)
    l1lll1l11ll11l1l_cda_=re.compile(l1ll11l1l_cda_ (u"ࠧ࠽࡯ࡨࡸࡦࠦࡰࡳࡱࡳࡩࡷࡺࡹ࠾ࠤࡲ࡫࠿࡯࡭ࡢࡩࡨࠦࠥࡩ࡯࡯ࡶࡨࡲࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧಷ")).findall(content)
    user = re.compile(l1ll11l1l_cda_ (u"ࠨ࠾ࡤࠤࡨࡲࡡࡴࡵࡀࠦࡱ࡯࡮࡬࠯ࡳࡶ࡮ࡳࡡࡳࡻࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡧࡱࡧࡳࡴ࠿ࠥࡥࡺࡺ࡯ࡳࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠦࡃ࠭ಸ")).findall(content)
    quality=re.compile(l1ll11l1l_cda_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣ࠰࠮ࡃࡼ࡫ࡲࡴ࡬ࡤࡁ࠭࠴ࠫࡀࠫࠥࠫಹ")).findall(content)
    l1ll1lll1ll11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"ࠪࡀࡲ࡫ࡴࡢࠢ࡬ࡸࡪࡳࡰࡳࡱࡳࡁࡠࡢࠧࠣ࡟ࡧࡹࡷࡧࡴࡪࡱࡱ࡟ࡡ࠭ࠢ࡞ࠢࡦࡳࡳࡺࡥ࡯ࡶࡀ࡟ࡡ࠭ࠢ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠩࠥࡡࠬ಺")).findall(content)
    if title:
        title = l1ll11lll1l11l1l_cda_(title[0])
        l1ll1lll1ll11l1l_cda_ =l1ll11l1l_cda_ (u"ࠫ࠿࠭಻").join(re.compile(l1ll11l1l_cda_ (u"ࠬ࠮࡜ࡥ಼࠭ࠬࠫ")).findall(l1ll1lll1ll11l1l_cda_[0])) if l1ll1lll1ll11l1l_cda_ else l1ll11l1l_cda_ (u"࠭ࠧಽ")
        l1ll1lll1ll11l1l_cda_ = l1ll1l11l1l11l1l_cda_(l1ll1lll1ll11l1l_cda_) if l1ll1lll1ll11l1l_cda_ else l1ll11l1l_cda_ (u"ࠧࠨಾ")
        user = l1l1llll11l11l1l_cda_(user[0])+l1ll11l1l_cda_ (u"ࠨ࠱ࡩࡳࡱࡪࡥࡳ࠯ࡪࡰࡴࡽ࡮ࡺࠩಿ") if user else l1ll11l1l_cda_ (u"ࠩࠪೀ")
        code = quality[-1] if quality else l1ll11l1l_cda_ (u"ࠪࠫು")
        l1ll1l1ll1l11l1l_cda_ = l1ll11lll1l11l1l_cda_(l1ll1l1ll1l11l1l_cda_[0]) if l1ll1l1ll1l11l1l_cda_ else l1ll11l1l_cda_ (u"ࠫࠬೂ")
        l1ll1l11lll11l1l_cda_ = l1l1l1ll11l11l1l_cda_(l1lll1l11ll11l1l_cda_[0]) if l1lll1l11ll11l1l_cda_ else l1ll11l1l_cda_ (u"ࠬ࠭ೃ")
        out={l1ll11l1l_cda_ (u"࠭ࡵࡳ࡮ࠪೄ"):url,l1ll11l1l_cda_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭೅"):unicode(title,l1ll11l1l_cda_ (u"ࠨࡷࡷࡪ࠲࠾ࠧೆ")),l1ll11l1l_cda_ (u"ࠩࡦࡳࡩ࡫ࠧೇ"):code,l1ll11l1l_cda_ (u"ࠪࡴࡱࡵࡴࠨೈ"):unicode(l1ll1l1ll1l11l1l_cda_,l1ll11l1l_cda_ (u"ࠫࡺࡺࡦ࠮࠺ࠪ೉")),l1ll11l1l_cda_ (u"ࠬ࡯࡭ࡨࠩೊ"):l1ll1l11lll11l1l_cda_,l1ll11l1l_cda_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨೋ"):l1ll1lll1ll11l1l_cda_,l1ll11l1l_cda_ (u"ࠧࡶࡵࡨࡶࠬೌ"):user}
    return out
import htmlentitydefs
def l1l1l1l111l11l1l_cda_(m):
    l1ll11l1lll11l1l_cda_ = m.group(1)
    if l1ll11l1lll11l1l_cda_.startswith(l1ll11l1l_cda_ (u"ࠨࡺ್ࠪ")):
        return unichr(int(l1ll11l1lll11l1l_cda_[1:],16))
    try:
        return unichr(int(l1ll11l1lll11l1l_cda_))
    except Exception, l111ll11ll11l1l_cda_:
        if l1ll11l1lll11l1l_cda_ in htmlentitydefs.name2codepoint:
            return unichr(htmlentitydefs.name2codepoint[l1ll11l1lll11l1l_cda_])
        else:
            return l1ll11l1lll11l1l_cda_
def html_entity_decode(string):
    string = string.decode(l1ll11l1l_cda_ (u"ࠩࡘࡘࡋ࠳࠸ࠨ೎"))
    pattern = l1ll11l1l_cda_ (u"ࠪࡎ࡮ࡓ࠯ࡌࡈࡻ࠷ࡐࢀ࠸ࡱࡑࡺࡁࡂ࠭೏")
    s = re.compile(pattern.decode(l1ll11l1l_cda_ (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫ೐"))).sub(l1l1l1l111l11l1l_cda_, string)
    return s.encode(l1ll11l1l_cda_ (u"࡛ࠬࡔࡇ࠯࠻ࠫ೑"))
def l1l1llllll11l1l_cda_(l1llll111ll11l1l_cda_):
    content = l1ll11l1l_cda_ (u"࡛࠭࡞ࠩ೒")
    if l1llll111ll11l1l_cda_.startswith(l1ll11l1l_cda_ (u"ࠧࡩࡶࡷࡴࠬ೓")):
        content = l1l1l111l11l1l_cda_(l1llll111ll11l1l_cda_)
    elif os.path.exists(l1llll111ll11l1l_cda_):
        with open(l1llll111ll11l1l_cda_,l1ll11l1l_cda_ (u"ࠨࡴࠪ೔")) as f:
            content = f.read()
            if not content:
                content =l1ll11l1l_cda_ (u"ࠩ࡞ࡡࠬೕ")
    data=json.loads(html_entity_decode(content))
    return data
def l1ll1111lll11l1l_cda_(l1ll1l111ll11l1l_cda_, path=l1ll11l1l_cda_ (u"ࠪࠫೖ")):
    elem = l1ll1l111ll11l1l_cda_
    if path:
        try:
            for x in path.strip(l1ll11l1l_cda_ (u"ࠦ࠴ࠨ೗")).split(l1ll11l1l_cda_ (u"ࠧ࠵ࠢ೘")):
                elem = elem.get( x.decode(l1ll11l1l_cda_ (u"࠭ࡵࡵࡨ࠰࠼ࠬ೙")) )
        except:
            pass
    return elem
def l1l1lllll11l1l_cda_(data,path):
    l1l1lll11ll11l1l_cda_ = []
    l1l1l1111ll11l1l_cda_=[]
    l1lll11llll11l1l_cda_ = l1ll1111lll11l1l_cda_(data,path)
    if type(l1lll11llll11l1l_cda_) is dict:
        for e in l1lll11llll11l1l_cda_.keys():
            l11l1llll11l1l_cda_=l1lll11llll11l1l_cda_.get(e)
            if type(l11l1llll11l1l_cda_) is str or type(l11l1llll11l1l_cda_) is unicode:
                l1l1lll11ll11l1l_cda_.append( {l1ll11l1l_cda_ (u"ࠧࡪ࡯ࡪࠫ೚"):l1ll11l1l_cda_ (u"ࠨࠩ೛"),l1ll11l1l_cda_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ೜"):e,l1ll11l1l_cda_ (u"ࠪࡹࡷࡲࠧೝ"):l1ll11l1l_cda_ (u"ࠦࠧೞ"), l1ll11l1l_cda_ (u"ࠧࡰࡳࡰࡰࡩ࡭ࡱ࡫ࠢ೟") :l11l1llll11l1l_cda_} )
            elif type(l11l1llll11l1l_cda_) is dict and l11l1llll11l1l_cda_.has_key(l1ll11l1l_cda_ (u"࠭ࡪࡴࡱࡱࡪ࡮ࡲࡥࠨೠ")):
                l11l1llll11l1l_cda_[l1ll11l1l_cda_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ೡ")]=e
                l11l1llll11l1l_cda_[l1ll11l1l_cda_ (u"ࠨࡷࡵࡰࠬೢ")]=l1ll11l1l_cda_ (u"ࠩࠪೣ")
                l1l1lll11ll11l1l_cda_.append( l11l1llll11l1l_cda_ )
            else:
                if isinstance(e, unicode):
                    e = e.encode(l1ll11l1l_cda_ (u"ࠪࡹࡹ࡬࠸ࠨ೤"))
                elif isinstance(e, str):
                    e.decode(l1ll11l1l_cda_ (u"ࠫࡺࡺࡦ࠹ࠩ೥"))
                l1l1lll11ll11l1l_cda_.append( {l1ll11l1l_cda_ (u"ࠬ࡯࡭ࡨࠩ೦"):l1ll11l1l_cda_ (u"࠭ࠧ೧"),l1ll11l1l_cda_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭೨"):e,l1ll11l1l_cda_ (u"ࠨࡷࡵࡰࠬ೩"):path+l1ll11l1l_cda_ (u"ࠩ࠲ࠫ೪")+e,l1ll11l1l_cda_ (u"ࠪࡪࡦࡴࡡࡳࡶࠪ೫"):l1ll11l1l_cda_ (u"ࠫࠬ೬")} )
        if l1l1lll11ll11l1l_cda_:
             l1l1lll11ll11l1l_cda_= sorted(l1l1lll11ll11l1l_cda_, key=lambda k: (k.get(l1ll11l1l_cda_ (u"ࠬ࡯ࡤࡹࠩ೭"),l1ll11l1l_cda_ (u"࠭ࠧ೮")),k.get(l1ll11l1l_cda_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭೯"),l1ll11l1l_cda_ (u"ࠨࠩ೰"))))
    if type(l1lll11llll11l1l_cda_) is list:
        for l11l1llll11l1l_cda_ in l1lll11llll11l1l_cda_:
            if l11l1llll11l1l_cda_.has_key(l1ll11l1l_cda_ (u"ࠩࡸࡶࡱ࠭ೱ")):
                l1l1l1111ll11l1l_cda_.append( l11l1llll11l1l_cda_ )
            elif l11l1llll11l1l_cda_.has_key(l1ll11l1l_cda_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪೲ")):
                filtr_items = l11l1llll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠫ࡫ࡲࡴࡦࡴࡢ࡭ࡹ࡫࡭ࠨೳ"),{})
                l1ll111llll11l1l_cda_ = l11l1llll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠬࡹࡵࡣࡨࡲࡨࡪࡸࡳࠨ೴"),True)
                l1ll111l1ll11l1l_cda_ = l11l1llll11l1l_cda_.get(l1ll11l1l_cda_ (u"࠭ࡩࡵࡧࡰࡷࠬ೵"),True)
                l1l1lllllll11l1l_cda_ = l11l1llll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠧࡳࡧࡦࡹࡷࡹࡩࡷࡧࠪ೶"),True)
                items,folders,l1111l1ll11l1l_cda_ = l1l111l1l11l1l_cda_(
                                        l1l11llll11l1l_cda_        = l11l1llll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ೷"),l1ll11l1l_cda_ (u"ࠩࠪ೸")),
                                        recursive   = l1l1lllllll11l1l_cda_,
                                        filtr_items = filtr_items )
                if l1ll111llll11l1l_cda_:
                    l1l1lll11ll11l1l_cda_.extend(folders)
                if l1ll111l1ll11l1l_cda_:
                    l1l1l1111ll11l1l_cda_.extend(items)
    return (l1l1l1111ll11l1l_cda_,l1l1lll11ll11l1l_cda_)
from ramic import go as l1l1l1ll1ll11l1l_cda_
l1ll11lll1l11l1l_cda_ = l1l1l1ll1ll11l1l_cda_[l1ll11l1l_cda_ (u"ࠪࡨࡪࡩ࡯ࡥࡧࡋࡘࡒࡒࡥ࡯ࡶࡵ࡭ࡪࡹࠧ೹")]
def l11ll111l11l1l_cda_():
    url=l1ll11l1l_cda_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡦࡨࡦ࠴ࡰ࡭࠱ࡳࡶࡪࡳࡩࡶ࡯ࠪ೺")
    content = l1l1l111l11l1l_cda_(url)
    l1l1ll1llll11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"ࠬࡂ࡬ࡪࡀ࠿ࡥࡡࡹࠫࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡩࡤࡢ࠰ࡳࡰ࠴ࡶࡲࡦ࡯࡬ࡹࡲ࠵࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾࠯ࠬࡂࡀ࠴ࡲࡩ࠿ࠩ೻"), re.DOTALL).findall(content)
    out=[]
    for l11l1llll11l1l_cda_ in l1l1ll1llll11l1l_cda_:
        out.append({l1ll11l1l_cda_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ೼"):l1ll11lll1l11l1l_cda_(l11l1llll11l1l_cda_[1]),l1ll11l1l_cda_ (u"ࠧࡶࡴ࡯ࠫ೽"):l11l1llll11l1l_cda_[0]})
    if out:
        out.insert(0,{l1ll11l1l_cda_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ೾"):l1ll11l1l_cda_ (u"ࠩ࡞ࡆࡢ࡝ࡳࡻࡻࡶࡸࡰ࡯ࡥࠡࡨ࡬ࡰࡲࡿ࡛࠰ࡄࡠࠫ೿"),l1ll11l1l_cda_ (u"ࠪࡹࡷࡲࠧഀ"):l1ll11l1l_cda_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡦࡨࡦ࠴ࡰ࡭࠱ࡳࡶࡪࡳࡩࡶ࡯ࠪഁ")})
    return out
url=l1ll11l1l_cda_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡧࡩࡧ࠮ࡱ࡮࠲ࡴࡷ࡫࡭ࡪࡷࡰ࠳ࡸ࡫ࡲࡪࡣ࡯ࡩ࠲࡯࠭࡮࡫ࡱ࡭ࡸ࡫ࡲࡪࡧࠪം")
def l1lll1lllll11l1l_cda_(content):
    l1lll1lll1l11l1l_cda_ = [(a.start(), a.end()) for a in re.finditer(l1ll11l1l_cda_ (u"࠭࠼ࡴࡲࡤࡲࠥࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯ࡷࡧࡵ࠱ࡦࡸࡥࡢࠤࡁࠫഃ"), content)]
    l1lll1lll1l11l1l_cda_.append( (-1,-1) )
    out=[]
    for i in range(len(l1lll1lll1l11l1l_cda_[:-1])):
        item = content[ l1lll1lll1l11l1l_cda_[i][1]:l1lll1lll1l11l1l_cda_[i+1][0] ]
        href = re.compile(l1ll11l1l_cda_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩഄ")).findall(item)
        title= re.compile(l1ll11l1l_cda_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡭࡬ࡲࡴ࠳ࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭അ")).findall(item)
        l1ll1l11lll11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧആ")).findall(item)
        quality = re.compile(l1ll11l1l_cda_ (u"ࠪࠦࡨࡲ࡯ࡶࡦ࠰࡫ࡷࡧࡹࠣࡀࠫ࠲࠯ࡅࡰࠪ࠾ࠪഇ")).findall(item)
        l1lll111l1l11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"ࠫࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥࡱࡦࡸ࡫ࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫഈ")).findall(item)
        l1ll1l1ll1l11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"ࠬࡂࡳࡱࡣࡱࠤࡨࡲࡡࡴࡵࡀࠦࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠯ࡦࡳࡻ࡫ࡲ࠮ࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࡃ࠮࠮ࠫࡁࠬࡀࡠ࠵࡝ࠫࡵࡳࡥࡳ࠭ഉ"),re.DOTALL).findall(item)
        if title and href:
            try:
                l1llll1111l11l1l_cda_ = float(l1lll111l1l11l1l_cda_[0]) if l1lll111l1l11l1l_cda_ else l1ll11l1l_cda_ (u"࠭ࠧഊ")
            except:
                l1llll1111l11l1l_cda_ = l1ll11l1l_cda_ (u"ࠧࠨഋ")
            out.append({
                l1ll11l1l_cda_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧഌ"):l1ll11lll1l11l1l_cda_(title[0]),
                l1ll11l1l_cda_ (u"ࠩࡸࡶࡱ࠭഍"):l1l1l1l11ll11l1l_cda_+href[0] if not href[0].startswith(l1ll11l1l_cda_ (u"ࠪ࡬ࡹࡺࡰࠨഎ")) else href[0],
                l1ll11l1l_cda_ (u"ࠫ࡮ࡳࡧࠨഏ"):l1l1l1ll11l11l1l_cda_(l1ll1l11lll11l1l_cda_[0]) if l1ll1l11lll11l1l_cda_ else l1ll11l1l_cda_ (u"ࠬ࠭ഐ"),
                l1ll11l1l_cda_ (u"࠭ࡣࡰࡦࡨࠫ഑"):quality[-1] if quality else l1ll11l1l_cda_ (u"ࠧࠨഒ"),
                l1ll11l1l_cda_ (u"ࠨࡴࡤࡸ࡮ࡴࡧࠨഓ"):l1llll1111l11l1l_cda_,
                l1ll11l1l_cda_ (u"ࠩࡳࡰࡴࡺࠧഔ"):l1ll11lll1l11l1l_cda_(l1ll1l1ll1l11l1l_cda_[0]) if l1ll1l1ll1l11l1l_cda_ else l1ll11l1l_cda_ (u"ࠪࠫക")
                })
    return out
def l1l1l1l1l11l1l_cda_():
    return {l1ll11l1l_cda_ (u"ࠫࡳࡵࡷࡰࠢࡧࡳࡩࡧ࡮ࡦࠩഖ"):l1ll11l1l_cda_ (u"ࠬࡴࡥࡸࠩഗ"),
    l1ll11l1l_cda_ (u"࠭ࡡ࡭ࡨࡤࡦࡪࡺࡹࡤࡼࡱ࡭ࡪ࠭ഘ"):l1ll11l1l_cda_ (u"ࠧࡢ࡮ࡳ࡬ࡦ࠭ങ"),
    l1ll11l1l_cda_ (u"ࠨࡰࡤ࡮ࡱ࡫ࡰࡪࡧ࡭ࠤࡴࡩࡥ࡯࡫ࡤࡲࡪࠦ࡮ࡢࠢࡉ࡭ࡱࡳࡷࡦࡤࠪച"):l1ll11l1l_cda_ (u"ࠩࡥࡩࡸࡺࠧഛ"),
    l1ll11l1l_cda_ (u"ࠪࡲࡦࡰࡣࡻछफ़ࡧ࡮࡫ࡪࠡࡱࡦࡩࡳ࡯ࡡ࡯ࡧࠣࡲࡦࠦࡆࡪ࡮ࡰࡻࡪࡨࠧജ"):l1ll11l1l_cda_ (u"ࠫࡵࡵࡰࡶ࡮ࡤࡶࠬഝ"),
    l1ll11l1l_cda_ (u"ࠬࡪࡡࡵࡣࠣࡴࡷ࡫࡭ࡪࡧࡵࡽࠥࡱࡩ࡯ࡱࡺࡩ࡯࠭ഞ"):l1ll11l1l_cda_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫ࠧട"),
    l1ll11l1l_cda_ (u"ࠧࡱࡱࡳࡹࡱࡧࡲ࡯ࡧࠣࡻࠥࡩࡩआࡩࡸࠤࡴࡹࡴࡢࡶࡱ࡭ࡨ࡮ࠠ࠷࠲ࠣࡨࡳ࡯ࠧഠ"):l1ll11l1l_cda_ (u"ࠨࡸ࡬ࡩࡼࡹࠧഡ"),
    l1ll11l1l_cda_ (u"ࠩࡳࡳࡵࡻ࡬ࡢࡴࡱࡩࠥࡽࠠࡤ࡫ई࡫ࡺࠦ࡯ࡴࡶࡤࡸࡳ࡯ࡣࡩࠢ࠶࠴ࠥࡪ࡮ࡪࠩഢ"):l1ll11l1l_cda_ (u"ࠪࡺ࡮࡫ࡷࡴ࠵࠳ࠫണ")}
def l11111ll11l1l_cda_():
    return {l1ll11l1l_cda_ (u"ࠫ࡜ࡹࡺࡺࡵࡷ࡯࡮࡫ࠧത"):l1ll11l1l_cda_ (u"ࠬ࠷ࠬ࠳࠮࠶ࠫഥ"),
    l1ll11l1l_cda_ (u"࠭ࡗࡺࡵࡲ࡯ࡦࠦࡪࡢ࡭ࡲय़ऌࠦࠨ࠸࠴࠳ࡴ࠱ࠦ࠱࠱࠺࠳ࡴ࠮࠭ദ"):l1ll11l1l_cda_ (u"ࠧ࠲ࠩധ"),
    l1ll11l1l_cda_ (u"ࠨड़ࡵࡩࡩࡴࡩࡢࠢ࡭ࡥࡰࡵज़ईࠢࠫ࠸࠽࠶ࡰࠪࠩന"):l1ll11l1l_cda_ (u"ࠩ࠵ࠫഩ"),
    l1ll11l1l_cda_ (u"ࠪࡒ࡮ࡹ࡫ࡢࠢ࡭ࡥࡰࡵज़ईࠢࠫ࠷࠻࠶ࡰࠪࠩപ"):l1ll11l1l_cda_ (u"ࠫ࠸࠭ഫ"),
    }
def l1ll111ll11l1l_cda_(url,params=l1ll11l1l_cda_ (u"ࠬ࠭ബ")):
    if len(params)==0:
        content = l1l1l111l11l1l_cda_(url)
        out = l1lll1lllll11l1l_cda_(content)
        match = re.compile(l1ll11l1l_cda_ (u"࠭࡫ࡢࡶࡤࡰࡴ࡭ࡌࡰࡣࡧࡑࡴࡸࡥ࡝ࠪࡳࡥ࡬࡫ࠬࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࠫ࠲࠯ࡅࠩࠣ࠮ࠪഭ")).findall(content)
        if match:
            params = l1ll11l1l_cda_ (u"ࠧࠦࡦࡢࠩࡸࡥࠥࡴࠩമ") %(2,match[0][0],match[0][1])
    else:
        l1l1l1l1lll11l1l_cda_ = params.split(l1ll11l1l_cda_ (u"ࠨࡡࠪയ"))
        l1ll1l1llll11l1l_cda_ = str([int(l1l1l1l1lll11l1l_cda_[0]),l1l1l1l1lll11l1l_cda_[1],l1l1l1l1lll11l1l_cda_[2],{}])
        l1ll1ll1l1l11l1l_cda_ = l1ll11l1l_cda_ (u"ࠩࡾࠦ࡯ࡹ࡯࡯ࡴࡳࡧࠧࡀࠢ࠳࠰࠳ࠦ࠱ࠨ࡭ࡦࡶ࡫ࡳࡩࠨ࠺ࠣ࡭ࡤࡸࡦࡲ࡯ࡨࡎࡲࡥࡩࡓ࡯ࡳࡧࠥ࠰ࠧࡶࡡࡳࡣࡰࡷࠧࡀࠥࡴ࠮ࠥ࡭ࡩࠨ࠺࠳ࡿࠪര")%l1ll1l1llll11l1l_cda_
        content = l1l1l111l11l1l_cda_(url.split(l1ll11l1l_cda_ (u"ࠪࡃࠬറ"))[0]+l1ll11l1l_cda_ (u"ࠫࡄࡪ࠽࠳ࠩല"),data=l1ll1ll1l1l11l1l_cda_.replace(l1ll11l1l_cda_ (u"ࠬࡢࠧࠨള"),l1ll11l1l_cda_ (u"࠭ࠢࠨഴ")),Refer=True)
        l1ll1l1111l11l1l_cda_=json.loads(content).get(l1ll11l1l_cda_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧവ")) if content else {}
        if l1ll1l1111l11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠨࡵࡷࡥࡹࡻࡳࠨശ")) ==l1ll11l1l_cda_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡨࠫഷ"):
            params = l1ll11l1l_cda_ (u"ࠪࠩࡩࡥࠥࡴࡡࠨࡷࠬസ") % (int(l1l1l1l1lll11l1l_cda_[0])+1,l1l1l1l1lll11l1l_cda_[1],l1l1l1l1lll11l1l_cda_[2])
        else:
            params = l1ll11l1l_cda_ (u"ࠫࠬഹ")
        out = l1lll1lllll11l1l_cda_(l1ll1l1111l11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠬ࡮ࡴ࡮࡮ࠪഺ"),l1ll11l1l_cda_ (u"഻࠭ࠧ")))
    return out,params
