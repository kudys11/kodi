# -*- coding: utf-8 -*-
import sys
l1l1ll11l1l_cda_ = sys.version_info [0] == 2
l1lll1l11l1l_cda_ = 2048
l1l111l11l1l_cda_ = 7
def l1ll11l1l_cda_ (lll11l1l_cda_):
	global l11l1l11l1l_cda_
	l11llll11l1l_cda_ = ord (lll11l1l_cda_ [-1])
	l11lll11l1l_cda_ = lll11l1l_cda_ [:-1]
	l11l11l1l_cda_ = l11llll11l1l_cda_ % len (l11lll11l1l_cda_)
	l1lll11l1l_cda_ = l11lll11l1l_cda_ [:l11l11l1l_cda_] + l11lll11l1l_cda_ [l11l11l1l_cda_:]
	if l1l1ll11l1l_cda_:
		l1lllll11l1l_cda_ = unicode () .join ([unichr (ord (char) - l1lll1l11l1l_cda_ - (l1l11l11l1l_cda_ + l11llll11l1l_cda_) % l1l111l11l1l_cda_) for l1l11l11l1l_cda_, char in enumerate (l1lll11l1l_cda_)])
	else:
		l1lllll11l1l_cda_ = str () .join ([chr (ord (char) - l1lll1l11l1l_cda_ - (l1l11l11l1l_cda_ + l11llll11l1l_cda_) % l1l111l11l1l_cda_) for l1l11l11l1l_cda_, char in enumerate (l1lll11l1l_cda_)])
	return eval (l1lllll11l1l_cda_)
import xbmc
import xbmcgui
import xbmcaddon
import datetime
def l1ll1ll11l1l_cda_():
    if xbmcaddon.Addon().getSetting(l1ll11l1l_cda_ (u"ࠩ࡯࡭ࡧࡸࡡࡳࡻ࠱ࡷࡪࡸࡶࡪࡥࡨ࠲ࡦࡩࡴࡪࡸࡨࠫႛ")) == l1ll11l1l_cda_ (u"ࠪࡸࡷࡻࡥࠨႜ"):
        from resources.lib import l11lll1l11l1l_cda_
        l1lll1ll111l11l1l_cda_=l11lll1l11l1l_cda_.l1ll1lll11l1l_cda_()
        while not xbmc.abortRequested:
            if(xbmcgui.Window(10000).getProperty(l1ll11l1l_cda_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡧࡩࡧࡰ࡭ࡡࡵࡹࡳࡴࡩ࡯ࡩࠪႝ")) != l1ll11l1l_cda_ (u"࡚ࠬࡲࡶࡧࠪ႞")):
                try:
                    l1lll1l1llll11l1l_cda_ = xbmcaddon.Addon().getSetting(l1ll11l1l_cda_ (u"࠭࡬ࡪࡤࡵࡥࡷࡿ࠮ࡴࡧࡵࡺ࡮ࡩࡥ࠯ࡣࡦࡸ࡮ࡼࡥࠨ႟"))
                    if not l1lll1l1llll11l1l_cda_ == l1ll11l1l_cda_ (u"ࠧࡵࡴࡸࡩࠬႠ"):
                        xbmc.log(l1ll11l1l_cda_ (u"ࠨ࡝ࡆࡈࡆ࠴ࡐࡍࠢࡖࡩࡷࡼࡩࡤࡧࡘࡴࡩࡧࡴࡦ࡟࠽ࠤࡸ࡫ࡲࡷ࡫ࡦࡩࡆࡩࡴࡪࡸࡨࠤࡂࠫࡳ࠭ࠢࡕࡩࡸࡺࡡࡳࡶࠣࡏࡴࡪࡩࠡࡶࡲࠤࡨࡵ࡭ࡱ࡮ࡨࡸࡱࡿࠠࡴࡶࡲࡴࠥࡹࡥࡳࡸ࡬ࡧࡪ࠭Ⴁ")%l1lll1l1llll11l1l_cda_)
                        raise Exception()
                    try:
                        l1llll11l1ll11l1l_cda_ = xbmcaddon.Addon().getSetting(l1ll11l1l_cda_ (u"ࠩ࡯࡭ࡧࡸࡡࡳࡻ࠱ࡷࡪࡸࡶࡪࡥࡨ࠲ࡱࡧࡳࡵ࠰ࡵࡹࡳ࠭Ⴂ"))
                        l1llll11l1ll11l1l_cda_ = datetime.datetime.strptime(l1llll11l1ll11l1l_cda_, l1ll11l1l_cda_ (u"ࠪࠩ࡞࠳ࠥ࡮࠯ࠨࡨࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠧႣ"))
                    except:
                        l1llll11l1ll11l1l_cda_= datetime.datetime.now()
                        xbmcaddon.Addon().setSetting(l1ll11l1l_cda_ (u"ࠫࡱ࡯ࡢࡳࡣࡵࡽ࠳ࡹࡥࡳࡸ࡬ࡧࡪ࠴࡬ࡢࡵࡷ࠲ࡷࡻ࡮ࠨႤ"), l1llll11l1ll11l1l_cda_.strftime(l1ll11l1l_cda_ (u"࡙ࠬࠫ࠮ࠧࡰ࠱ࠪࡪࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠩႥ")))
                    l1lll1ll11ll11l1l_cda_ = int( xbmcaddon.Addon().getSetting(l1ll11l1l_cda_ (u"࠭࡬ࡪࡤࡵࡥࡷࡿ࠮ࡴࡧࡵࡺ࡮ࡩࡥ࠯ࡹࡤ࡭ࡹ࠴ࡴࡪ࡯ࡨࠫႦ")) or 1)
                    t1 = datetime.timedelta(hours=l1lll1ll11ll11l1l_cda_)
                    l1lll1l1ll1l11l1l_cda_ = datetime.datetime.now()
                    l1111l11lll11l1l_cda_ = abs(l1lll1l1ll1l11l1l_cda_ - l1llll11l1ll11l1l_cda_) > t1
                    if l1111l11lll11l1l_cda_ == False: raise Exception()
                    xbmcgui.Window(10000).setProperty(l1ll11l1l_cda_ (u"ࠧࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡣࡥࡣࡳࡰࡤࡸࡵ࡯ࡰ࡬ࡲ࡬࠭Ⴇ"), l1ll11l1l_cda_ (u"ࠨࡖࡵࡹࡪ࠭Ⴈ"))
                    xbmc.log(l1ll11l1l_cda_ (u"ࠩ࡞ࡇࡉࡇ࠮ࡑࡎࠣࡗࡪࡸࡶࡪࡥࡨ࡙ࡵࡪࡡࡵࡧࡠ࠾࡚ࠥࡡࡴ࡭ࠣࡷࡹࡧࡲࡵࡧࡧࠫႩ"))
                    l1lll1ll111l11l1l_cda_.l111lll1l11l1l_cda_()
                    l1lll1ll111l11l1l_cda_.l1ll111l1l11l1l_cda_()
                    xbmcgui.Window(10000).clearProperty(l1ll11l1l_cda_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡦࡨࡦࡶ࡬ࡠࡴࡸࡲࡳ࡯࡮ࡨࠩႪ"))
                    xbmc.log(l1ll11l1l_cda_ (u"ࠫࡠࡉࡄࡂ࠰ࡓࡐ࡙ࠥࡥࡳࡸ࡬ࡧࡪ࡛ࡰࡥࡣࡷࡩࡢࡀࠠࡕࡣࡶ࡯ࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡫ࡤࠨႫ"))
                except:
                    pass
            else:
                pass
            xbmc.sleep(30000)
    else:
        xbmc.log(l1ll11l1l_cda_ (u"ࠬࡡࡃࡅࡃ࠱ࡔࡑࠦࡓࡦࡴࡹ࡭ࡨ࡫࡝࠻ࠢࡌࡷࠥࡴ࡯ࡵࠢࡵࡹࡳࡴࡩ࡯ࡩࠪႬ"))
