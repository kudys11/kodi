# -*- coding: utf-8 -*-
import sys
l1l1ll11l1l_cda_ = sys.version_info [0] == 2
l1lll1l11l1l_cda_ = 2048
l1l111l11l1l_cda_ = 7
def l1ll11l1l_cda_ (lll11l1l_cda_):
	global l11l1l11l1l_cda_
	l11llll11l1l_cda_ = ord (lll11l1l_cda_ [-1])
	l11lll11l1l_cda_ = lll11l1l_cda_ [:-1]
	l11l11l1l_cda_ = l11llll11l1l_cda_ % len (l11lll11l1l_cda_)
	l1lll11l1l_cda_ = l11lll11l1l_cda_ [:l11l11l1l_cda_] + l11lll11l1l_cda_ [l11l11l1l_cda_:]
	if l1l1ll11l1l_cda_:
		l1lllll11l1l_cda_ = unicode () .join ([unichr (ord (char) - l1lll1l11l1l_cda_ - (l1l11l11l1l_cda_ + l11llll11l1l_cda_) % l1l111l11l1l_cda_) for l1l11l11l1l_cda_, char in enumerate (l1lll11l1l_cda_)])
	else:
		l1lllll11l1l_cda_ = str () .join ([chr (ord (char) - l1lll1l11l1l_cda_ - (l1l11l11l1l_cda_ + l11llll11l1l_cda_) % l1l111l11l1l_cda_) for l1l11l11l1l_cda_, char in enumerate (l1lll11l1l_cda_)])
	return eval (l1lllll11l1l_cda_)
import sys
from Queue import Queue
from threading import Thread
class l1lll1l11lll11l1l_cda_(Thread):
    l1ll11l1l_cda_ (u"ࠨࠢࠣࠢࡗ࡬ࡷ࡫ࡡࡥࠢࡨࡼࡪࡩࡵࡵ࡫ࡱ࡫ࠥࡺࡡࡴ࡭ࡶࠤ࡫ࡸ࡯࡮ࠢࡤࠤ࡬࡯ࡶࡦࡰࠣࡸࡦࡹ࡫ࡴࠢࡴࡹࡪࡻࡥࠡࠤࠥࠦႭ")
    def __init__(self, l1lll1l1l11l11l1l_cda_):
        Thread.__init__(self)
        self.l1lll1l1l11l11l1l_cda_ = l1lll1l1l11l11l1l_cda_
        self.daemon = True
        self.start()
    def run(self):
        while True:
            func, args, l1lll1l11l1l11l1l_cda_ = self.l1lll1l1l11l11l1l_cda_.get()
            try:
                func(*args, **l1lll1l11l1l11l1l_cda_)
            except Exception as e:
                print(e)
            finally:
                self.l1lll1l1l11l11l1l_cda_.task_done()
class ThreadPool:
    l1ll11l1l_cda_ (u"ࠢࠣࠤࠣࡔࡴࡵ࡬ࠡࡱࡩࠤࡹ࡮ࡲࡦࡣࡧࡷࠥࡩ࡯࡯ࡵࡸࡱ࡮ࡴࡧࠡࡶࡤࡷࡰࡹࠠࡧࡴࡲࡱࠥࡧࠠࡲࡷࡨࡹࡪࠦࠢࠣࠤႮ")
    def __init__(self, l1lll1l1l1ll11l1l_cda_):
        self.l1lll1l1l11l11l1l_cda_ = Queue(l1lll1l1l1ll11l1l_cda_)
        for _ in range(l1lll1l1l1ll11l1l_cda_):
            l1lll1l11lll11l1l_cda_(self.l1lll1l1l11l11l1l_cda_)
    def l1llll1l1lll11l1l_cda_(self, func, *args, **l1lll1l11l1l11l1l_cda_):
        l1ll11l1l_cda_ (u"ࠣࠤࠥࠤࡆࡪࡤࠡࡣࠣࡸࡦࡹ࡫ࠡࡶࡲࠤࡹ࡮ࡥࠡࡳࡸࡩࡺ࡫ࠠࠣࠤࠥႯ")
        self.l1lll1l1l11l11l1l_cda_.put((func, args, l1lll1l11l1l11l1l_cda_))
    def map(self, func, l1lll1l111ll11l1l_cda_):
        l1ll11l1l_cda_ (u"ࠤࠥࠦࠥࡇࡤࡥࠢࡤࠤࡱ࡯ࡳࡵࠢࡲࡪࠥࡺࡡࡴ࡭ࡶࠤࡹࡵࠠࡵࡪࡨࠤࡶࡻࡥࡶࡧࠣࠦࠧࠨႰ")
        for args in l1lll1l111ll11l1l_cda_:
            self.l1llll1l1lll11l1l_cda_(func, args)
    def l1llll11l11l1l_cda_(self):
        l1ll11l1l_cda_ (u"ࠥࠦࠧࠦࡗࡢ࡫ࡷࠤ࡫ࡵࡲࠡࡥࡲࡱࡵࡲࡥࡵ࡫ࡲࡲࠥࡵࡦࠡࡣ࡯ࡰࠥࡺࡨࡦࠢࡷࡥࡸࡱࡳࠡ࡫ࡱࠤࡹ࡮ࡥࠡࡳࡸࡩࡺ࡫ࠠࠣࠤࠥႱ")
        self.l1lll1l1l11l11l1l_cda_.join()
