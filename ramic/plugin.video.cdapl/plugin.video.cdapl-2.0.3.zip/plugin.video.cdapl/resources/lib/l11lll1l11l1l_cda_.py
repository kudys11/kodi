# -*- coding: utf-8 -*-
import sys
l1l1ll11l1l_cda_ = sys.version_info [0] == 2
l1lll1l11l1l_cda_ = 2048
l1l111l11l1l_cda_ = 7
def l1ll11l1l_cda_ (lll11l1l_cda_):
	global l11l1l11l1l_cda_
	l11llll11l1l_cda_ = ord (lll11l1l_cda_ [-1])
	l11lll11l1l_cda_ = lll11l1l_cda_ [:-1]
	l11l11l1l_cda_ = l11llll11l1l_cda_ % len (l11lll11l1l_cda_)
	l1lll11l1l_cda_ = l11lll11l1l_cda_ [:l11l11l1l_cda_] + l11lll11l1l_cda_ [l11l11l1l_cda_:]
	if l1l1ll11l1l_cda_:
		l1lllll11l1l_cda_ = unicode () .join ([unichr (ord (char) - l1lll1l11l1l_cda_ - (l1l11l11l1l_cda_ + l11llll11l1l_cda_) % l1l111l11l1l_cda_) for l1l11l11l1l_cda_, char in enumerate (l1lll11l1l_cda_)])
	else:
		l1lllll11l1l_cda_ = str () .join ([chr (ord (char) - l1lll1l11l1l_cda_ - (l1l11l11l1l_cda_ + l11llll11l1l_cda_) % l1l111l11l1l_cda_) for l1l11l11l1l_cda_, char in enumerate (l1lll11l1l_cda_)])
	return eval (l1lllll11l1l_cda_)
l1ll11l1l_cda_ (u"ࠨࠢࠣࠌࠣࠤࠥࠦࡃࡰࡸࡨࡲࡦࡴࡴࠡࡃࡧࡨ࠲ࡵ࡮ࠋࠌࠣࠤࠥࠦࡔࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥ࡯ࡳࠡࡨࡵࡩࡪࠦࡳࡰࡨࡷࡻࡦࡸࡥ࠻ࠢࡼࡳࡺࠦࡣࡢࡰࠣࡶࡪࡪࡩࡴࡶࡵ࡭ࡧࡻࡴࡦࠢ࡬ࡸࠥࡧ࡮ࡥ࠱ࡲࡶࠥࡳ࡯ࡥ࡫ࡩࡽࠏࠦࠠࠡࠢ࡬ࡸࠥࡻ࡮ࡥࡧࡵࠤࡹ࡮ࡥࠡࡶࡨࡶࡲࡹࠠࡰࡨࠣࡸ࡭࡫ࠠࡈࡐࡘࠤࡌ࡫࡮ࡦࡴࡤࡰࠥࡖࡵࡣ࡮࡬ࡧࠥࡒࡩࡤࡧࡱࡷࡪࠦࡡࡴࠢࡳࡹࡧࡲࡩࡴࡪࡨࡨࠥࡨࡹࠋࠢࠣࠤࠥࡺࡨࡦࠢࡉࡶࡪ࡫ࠠࡔࡱࡩࡸࡼࡧࡲࡦࠢࡉࡳࡺࡴࡤࡢࡶ࡬ࡳࡳ࠲ࠠࡦ࡫ࡷ࡬ࡪࡸࠠࡷࡧࡵࡷ࡮ࡵ࡮ࠡ࠵ࠣࡳ࡫ࠦࡴࡩࡧࠣࡐ࡮ࡩࡥ࡯ࡵࡨ࠰ࠥࡵࡲࠋࠢࠣࠤࠥ࠮ࡡࡵࠢࡼࡳࡺࡸࠠࡰࡲࡷ࡭ࡴࡴࠩࠡࡣࡱࡽࠥࡲࡡࡵࡧࡵࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠐࠊࠡࠢࠣࠤ࡙࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯ࠣ࡭ࡸࠦࡤࡪࡵࡷࡶ࡮ࡨࡵࡵࡧࡧࠤ࡮ࡴࠠࡵࡪࡨࠤ࡭ࡵࡰࡦࠢࡷ࡬ࡦࡺࠠࡪࡶࠣࡻ࡮ࡲ࡬ࠡࡤࡨࠤࡺࡹࡥࡧࡷ࡯࠰ࠏࠦࠠࠡࠢࡥࡹࡹࠦࡗࡊࡖࡋࡓ࡚࡚ࠠࡂࡐ࡜ࠤ࡜ࡇࡒࡓࡃࡑࡘ࡞ࡁࠠࡸ࡫ࡷ࡬ࡴࡻࡴࠡࡧࡹࡩࡳࠦࡴࡩࡧࠣ࡭ࡲࡶ࡬ࡪࡧࡧࠤࡼࡧࡲࡳࡣࡱࡸࡾࠦ࡯ࡧࠌࠣࠤࠥࠦࡍࡆࡔࡆࡌࡆࡔࡔࡂࡄࡌࡐࡎ࡚࡙ࠡࡱࡵࠤࡋࡏࡔࡏࡇࡖࡗࠥࡌࡏࡓࠢࡄࠤࡕࡇࡒࡕࡋࡆ࡙ࡑࡇࡒࠡࡒࡘࡖࡕࡕࡓࡆ࠰ࠣࠤࡘ࡫ࡥࠡࡶ࡫ࡩࠏࠦࠠࠡࠢࡊࡒ࡚ࠦࡇࡦࡰࡨࡶࡦࡲࠠࡑࡷࡥࡰ࡮ࡩࠠࡍ࡫ࡦࡩࡳࡹࡥࠡࡨࡲࡶࠥࡳ࡯ࡳࡧࠣࡨࡪࡺࡡࡪ࡮ࡶ࠲ࠏࠐࠠࠡࠢࠣ࡝ࡴࡻࠠࡴࡪࡲࡹࡱࡪࠠࡩࡣࡹࡩࠥࡸࡥࡤࡧ࡬ࡺࡪࡪࠠࡢࠢࡦࡳࡵࡿࠠࡰࡨࠣࡸ࡭࡫ࠠࡈࡐࡘࠤࡌ࡫࡮ࡦࡴࡤࡰࠥࡖࡵࡣ࡮࡬ࡧࠥࡒࡩࡤࡧࡱࡷࡪࠐࠠࠡࠢࠣࡥࡱࡵ࡮ࡨࠢࡺ࡭ࡹ࡮ࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲ࠴ࠠࠡࡋࡩࠤࡳࡵࡴ࠭ࠢࡶࡩࡪࠦ࠼ࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡴࡵ࠯ࡱࡵ࡫࠴ࡲࡩࡤࡧࡱࡷࡪࡹ࠯࠿࠰ࠍࠦࠧࠨྎ")
import datetime
import json
import os
import re
import sys
import urllib
import urllib2
import urlparse
import xbmc
import l11ll1ll11l11l1l_cda_
import re
import unicodedata
def l111111l11l11l1l_cda_(title):
    try:
        title = l111lllll11l1l_cda_(title)
        try: return title.decode(l1ll11l1l_cda_ (u"ࠧࡢࡵࡦ࡭࡮࠭ྏ")).encode(l1ll11l1l_cda_ (u"ࠣࡷࡷࡪ࠲࠾ࠢྐ"))
        except: pass
        return str(l1ll11l1l_cda_ (u"ࠩࠪྑ").join(c for c in unicodedata.normalize(l1ll11l1l_cda_ (u"ࠪࡒࡋࡑࡄࠨྒ"), unicode(title.decode(l1ll11l1l_cda_ (u"ࠫࡺࡺࡦ࠮࠺ࠪྒྷ")))) if unicodedata.category(c) != l1ll11l1l_cda_ (u"ࠬࡓ࡮ࠨྔ")))
    except:
        return title
def l111lllll11l1l_cda_(l1ll1ll1lll11l1l_cda_):
    l1lll1lll11l1l_cda_ = [
    (l1ll11l1l_cda_ (u"࠭ऄࠨྕ"), l1ll11l1l_cda_ (u"ࠧࡢࠩྖ")),(l1ll11l1l_cda_ (u"ࠨइࠪྗ"), l1ll11l1l_cda_ (u"ࠩࡤࠫ྘")),(l1ll11l1l_cda_ (u"ࠪजࠬྙ"), l1ll11l1l_cda_ (u"ࠫࡪ࠭ྚ")),(l1ll11l1l_cda_ (u"ࠬटࠧྛ"), l1ll11l1l_cda_ (u"࠭ࡥࠨྜ")),(l1ll11l1l_cda_ (u"ࠧࣔࠩྜྷ"), l1ll11l1l_cda_ (u"ࠨࡱࠪྞ")),(l1ll11l1l_cda_ (u"ࣶࠩࠫྟ"), l1ll11l1l_cda_ (u"ࠪࡳࠬྠ")),(l1ll11l1l_cda_ (u"ࠫऋ࠭ྡ"), l1ll11l1l_cda_ (u"ࠬࡩࠧྡྷ")),
    (l1ll11l1l_cda_ (u"࠭इࠨྣ"), l1ll11l1l_cda_ (u"ࠧࡤࠩྤ")),(l1ll11l1l_cda_ (u"ࠨृࠪྥ"), l1ll11l1l_cda_ (u"ࠩ࡯ࠫྦ")),(l1ll11l1l_cda_ (u"ࠪॆࠬྦྷ"), l1ll11l1l_cda_ (u"ࠫࡱ࠭ྨ")),(l1ll11l1l_cda_ (u"ࠬॉࠧྩ"), l1ll11l1l_cda_ (u"࠭࡮ࠨྪ")),(l1ll11l1l_cda_ (u"ࠧॅࠩྫ"), l1ll11l1l_cda_ (u"ࠨࡰࠪྫྷ")),(l1ll11l1l_cda_ (u"ࠩढ़ࠫྭ"), l1ll11l1l_cda_ (u"ࠪࡷࠬྮ")),(l1ll11l1l_cda_ (u"ࠫॠ࠭ྯ"), l1ll11l1l_cda_ (u"ࠬࡹࠧྰ")),
    (l1ll11l1l_cda_ (u"࠭ॹࠨྱ"), l1ll11l1l_cda_ (u"ࠧࡻࠩྲ")),(l1ll11l1l_cda_ (u"ࠨॼࠪླ"), l1ll11l1l_cda_ (u"ࠩࡽࠫྴ")),(l1ll11l1l_cda_ (u"ࠪॿࠬྵ"), l1ll11l1l_cda_ (u"ࠫࡿ࠭ྶ")),(l1ll11l1l_cda_ (u"ࠬংࠧྷ"), l1ll11l1l_cda_ (u"࠭ࡺࠨྸ"))]
    for a,b in l1lll1lll11l1l_cda_:
        l1ll1ll1lll11l1l_cda_ = l1ll1ll1lll11l1l_cda_.replace(a,b)
    return l1ll1ll1lll11l1l_cda_
def l1lll1lll1ll11l1l_cda_(l1ll1ll1lll11l1l_cda_=l1ll11l1l_cda_ (u"ࠧࠨྐྵ")):
    print l1ll11l1l_cda_ (u"ࠨ࡝ࡆࡈࡆ࠴ࡐࡍࠢࡏ࡭ࡧࡸࡡࡳࡻࡠ࠾ࠥࠫࡳࠨྺ")%l1ll1ll1lll11l1l_cda_
class l1llllll111l11l1l_cda_:
    @staticmethod
    def l1llll1l11ll11l1l_cda_(l11111111ll11l1l_cda_):
        try:
            l11111111ll11l1l_cda_ = xbmc.makeLegalFilename(l11111111ll11l1l_cda_)
            l11ll1ll11l11l1l_cda_.l11lll11lll11l1l_cda_(l11111111ll11l1l_cda_)
            try:
                if not l1ll11l1l_cda_ (u"ࠩࡩࡸࡵࡀ࠯࠰ࠩྻ") in l11111111ll11l1l_cda_: raise Exception()
                from ftplib import FTP
                l1lllll11l1l11l1l_cda_ = re.compile(l1ll11l1l_cda_ (u"ࠪࡪࡹࡶ࠺࠰࠱ࠫ࠲࠰ࡅࠩ࠻ࠪ࠱࠯ࡄ࠯ࡀࠩ࠰࠮ࡃ࠮ࡀ࠿ࠩ࡞ࡧ࠯࠮ࡅ࠯ࠩ࠰࠮࠳ࡄ࠯ࠧྼ")).findall(l11111111ll11l1l_cda_)
                l11111ll11l11l1l_cda_ = FTP(l1lllll11l1l11l1l_cda_[0][2], l1lllll11l1l11l1l_cda_[0][0], l1lllll11l1l11l1l_cda_[0][1])
                try:
                    l11111ll11l11l1l_cda_.cwd(l1lllll11l1l11l1l_cda_[0][4])
                except:
                    l11111ll11l11l1l_cda_.mkd(l1lllll11l1l11l1l_cda_[0][4])
                l11111ll11l11l1l_cda_.quit()
            except:
                pass
        except:
            pass
    @staticmethod
    def l1111l1111l11l1l_cda_(path, content):
        try:
            path = xbmc.makeLegalFilename(path)
            if not isinstance(content, basestring):
                content = str(content)
            file = l11ll1ll11l11l1l_cda_.l1l11llll1l11l1l_cda_(path, l1ll11l1l_cda_ (u"ࠫࡼ࠭྽"))
            file.write(str(content))
            file.close()
        except Exception as e:
            pass
    @staticmethod
    def l1111l11l1l11l1l_cda_(path):
        content = None
        try:
            path = xbmc.makeLegalFilename(path)
            file = l11ll1ll11l11l1l_cda_.l1l11llll1l11l1l_cda_(path, l1ll11l1l_cda_ (u"ࠬࡸࠧ྾"))
            content = file.read()
            file.close()
        except Exception as e:
            pass
        return content
    @staticmethod
    def l1lllll1111l11l1l_cda_(l1llll11ll1l11l1l_cda_, l1lll1lll1l11l1l_cda_):
        l1llllllll1l11l1l_cda_ = l1ll11l1l_cda_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡴࡩࡧࡷࡺࡩࡨ࠮ࡤࡱࡰ࠳ࡄࡺࡡࡣ࠿ࡶࡩࡷ࡯ࡥࡴࠨ࡬ࡨࡂࠫࡳࠨ྿")
        l111111ll1l11l1l_cda_ = l1ll11l1l_cda_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡺࡨࡦ࡯ࡲࡺ࡮࡫ࡤࡣ࠰ࡲࡶ࡬࠵ࠥࡴ࠱ࠨࡷࠬ࿀")
        l11111l1l1l11l1l_cda_ = l1ll11l1l_cda_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡯࡭ࡥࡤ࠱ࡧࡴࡳ࠯ࡵ࡫ࡷࡰࡪ࠵ࠥࡴ࠱ࠪ࿁")
        l1llll11llll11l1l_cda_= l1ll11l1l_cda_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡦࡪ࡮ࡰࡻࡪࡨ࠮ࡱ࡮ࠨࡷࠬ࿂")
        l1llll1ll11l11l1l_cda_ =l1ll11l1l_cda_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡧ࡫࡯ࡱࡼ࡫ࡢ࠯ࡲ࡯࠳ࡋ࡯࡬࡮ࡁ࡬ࡨࡂࠫࡳࠨ࿃")
        if l1ll11l1l_cda_ (u"ࠫࡹࡼࡤࡣࠩ࿄") in l1lll1lll1l11l1l_cda_:
            return l1llllllll1l11l1l_cda_ % (str(l1lll1lll1l11l1l_cda_[l1ll11l1l_cda_ (u"ࠬࡺࡶࡥࡤࠪ࿅")]))
        elif l1ll11l1l_cda_ (u"࠭ࡴ࡮ࡦࡥ࿆ࠫ") in l1lll1lll1l11l1l_cda_:
            return l111111ll1l11l1l_cda_ % (l1llll11ll1l11l1l_cda_, str(l1lll1lll1l11l1l_cda_[l1ll11l1l_cda_ (u"ࠧࡵ࡯ࡧࡦࠬ࿇")]))
        elif l1ll11l1l_cda_ (u"ࠨ࡫ࡰࡨࡧ࠭࿈") in l1lll1lll1l11l1l_cda_:
            return l11111l1l1l11l1l_cda_ % (str(l1lll1lll1l11l1l_cda_[l1ll11l1l_cda_ (u"ࠩ࡬ࡱࡩࡨࠧ࿉")]))
        elif l1ll11l1l_cda_ (u"ࠪࡨࡦࡺࡡࡠࡨ࡬ࡰࡲ࠭࿊") in l1lll1lll1l11l1l_cda_:
            return l1llll1ll11l11l1l_cda_ % (str(l1lll1lll1l11l1l_cda_[l1ll11l1l_cda_ (u"ࠫࡩࡧࡴࡢࡡࡩ࡭ࡱࡳࠧ࿋")]))
        elif l1ll11l1l_cda_ (u"ࠬ࡬ࡩ࡭࡯ࡺࡩࡧ࡮ࡲࡦࡨࠪ࿌") in l1lll1lll1l11l1l_cda_:
            return l1llll11llll11l1l_cda_ % (str(l1lll1lll1l11l1l_cda_[l1ll11l1l_cda_ (u"࠭ࡦࡪ࡮ࡰࡻࡪࡨࡨࡳࡧࡩࠫ࿍")]))
        else:
            return l1ll11l1l_cda_ (u"ࠧࠨ࿎")
    @staticmethod
    def l1111l1ll1l11l1l_cda_(title, year, l1lll1lll11l11l1l_cda_, l1l1111l1ll11l1l_cda_=None, l1llllll1l1l11l1l_cda_=None, l1llll1l1l1l11l1l_cda_=None, l1llllllllll11l1l_cda_=None, l1llll111lll11l1l_cda_=None):
        return True
    @staticmethod
    def l1lllll11lll11l1l_cda_(filename):
        try:
            filename = filename.strip()
            filename = re.sub(l1ll11l1l_cda_ (u"ࡳࠩࠫࡃࠦࠫࡳࠪ࡝ࡡࡠࡼࡢ࠭ࡠ࡞࠱ࡡࠬ࿏"), l1ll11l1l_cda_ (u"ࠩ࠱ࠫ࿐"), filename)
            filename = re.sub(l1ll11l1l_cda_ (u"ࠪࡠ࠳࠱ࠧ࿑"), l1ll11l1l_cda_ (u"ࠫ࠳࠭࿒"), filename)
            filename = re.sub(re.compile(l1ll11l1l_cda_ (u"ࠬ࠮ࡃࡐࡐࡿࡔࡗࡔࡼࡂࡗ࡛ࢀࡓ࡛ࡌࡽࡅࡒࡑࡡࡪࡼࡍࡒࡗࡠࡩ࠯࡜࠯ࠩ࿓"), re.I), l1ll11l1l_cda_ (u"࠭࡜࡝࠳ࡢࠫ࿔"), filename)
            xbmc.makeLegalFilename(filename)
            return filename
        except:
            return filename
    @staticmethod
    def l1lllll1l11l11l1l_cda_(l1lllll1l1ll11l1l_cda_, title, year=l1ll11l1l_cda_ (u"ࠧࠨ࿕"), l1llllll1l1l11l1l_cda_=l1ll11l1l_cda_ (u"ࠨࠩ࿖")):
        l1111111lll11l1l_cda_ = re.sub(l1ll11l1l_cda_ (u"ࡴࠪ࡟ࡣࡢࡷ࡝࠯ࡢࡠ࠳ࠦ࡝ࠨ࿗"), l1ll11l1l_cda_ (u"ࠪࡣࠬ࿘"), title)
        l1111111lll11l1l_cda_ = l1ll11l1l_cda_ (u"ࠫࠪࡹࠠࠩࠧࡶ࠭ࠬ࿙") % (l1111111lll11l1l_cda_, year) if year else l1111111lll11l1l_cda_
        path = os.path.join(l1lllll1l1ll11l1l_cda_, l1111111lll11l1l_cda_)
        if l1llllll1l1l11l1l_cda_:
            path = os.path.join(path, l1ll11l1l_cda_ (u"࡙ࠬࡥࡢࡵࡲࡲࠥࠫࡳࠨ࿚") % l1llllll1l1l11l1l_cda_)
        return path
    @staticmethod
    def l1lll1llllll11l1l_cda_(url):
        req = urllib2.Request(url)
        req.add_header(l1ll11l1l_cda_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ࿛"), l1ll11l1l_cda_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠴࠹࠰࠳࠲࠷࠻࠶࠵࠰࠼࠻࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬ࿜"))
        response = l1ll11l1l_cda_ (u"ࠨࡐࡲࡸࡈ࡮ࡥࡤ࡭ࡨࡨࠬ࿝")
        try:
            resp = urllib2.urlopen(req)
            response=l1ll11l1l_cda_ (u"ࠩࡒࡏࠬ࿞")
        except urllib2.HTTPError, e:
            response = l1ll11l1l_cda_ (u"ࠪࡌ࡙࡚ࡐࡆࡴࡵࡳࡷࠦ࠽ࠡࠩ࿟") + str(e.code)
        except urllib2.URLError, e:
            response =  l1ll11l1l_cda_ (u"࡚ࠫࡘࡌࡆࡴࡵࡳࡷࠦ࠽ࠡࠩ࿠") + str(e.reason)
        except httplib.HTTPException, e:
            response = l1ll11l1l_cda_ (u"ࠬࡎࡔࡕࡒࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠬ࿡")
        return response
    @staticmethod
    def l1111ll11ll11l1l_cda_(v):
        if isinstance(v, unicode): v = v.encode(l1ll11l1l_cda_ (u"࠭ࡵࡵࡨ࠻ࠫ࿢"))
        elif isinstance(v, str): v.decode(l1ll11l1l_cda_ (u"ࠧࡶࡶࡩ࠼ࠬ࿣"))
        return v
    @staticmethod
    def l11111l11l1l_cda_(query):
        def l1l1l1ll11l1l_cda_(l1ll11l1ll11l1l_cda_):
            l1llll11ll11l1l_cda_ = {}
            for k, v in l1ll11l1ll11l1l_cda_.iteritems():
                if isinstance(v, unicode): v = v.encode(l1ll11l1l_cda_ (u"ࠨࡷࡷࡪ࠽࠭࿤"))
                elif isinstance(v, str): v.decode(l1ll11l1l_cda_ (u"ࠩࡸࡸ࡫࠾ࠧ࿥"))
                l1llll11ll11l1l_cda_[k] = v
            return l1llll11ll11l1l_cda_
        l111111l1ll11l1l_cda_ = l1ll11l1l_cda_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡨࡪࡡࡱ࡮࠲ࠫ࿦")
        return l111111l1ll11l1l_cda_ + l1ll11l1l_cda_ (u"ࠫࡄ࠭࿧") + urllib.urlencode(l1l1l1ll11l1l_cda_(query))
class l11ll1lll11l1l_cda_:
    def __init__(self):
        self.l1lllllll1ll11l1l_cda_ = os.path.join(l11ll1ll11l11l1l_cda_.l1l111lll1l11l1l_cda_(l11ll1ll11l11l1l_cda_.l11llll1l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠬࡲࡩࡣࡴࡤࡶࡾ࠴࡭ࡰࡸ࡬ࡩࠬ࿨"))), l1ll11l1l_cda_ (u"࠭ࠧ࿩"))
        try:
            l1llll11l1ll11l1l_cda_ = l11ll1ll11l11l1l_cda_.l11llll1l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠧ࡭࡫ࡥࡶࡦࡸࡹ࠯ࡵࡨࡶࡻ࡯ࡣࡦ࠰࡯ࡥࡸࡺ࠮ࡳࡷࡱࠫ࿪"))
            l1llll11l1ll11l1l_cda_ = datetime.datetime.strptime(l1llll11l1ll11l1l_cda_, l1ll11l1l_cda_ (u"ࠨࠧ࡜࠱ࠪࡳ࠭ࠦࡦࠣࠩࡍࡀࠥࡎ࠼ࠨࡗࠬ࿫"))
            t1 = datetime.timedelta(hours=int(l11ll1ll11l11l1l_cda_.l11llll1l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠩ࡯࡭ࡧࡸࡡࡳࡻ࠱ࡷࡪࡸࡶࡪࡥࡨ࠲ࡼࡧࡩࡵ࠰ࡷ࡭ࡲ࡫ࠧ࿬"))))
            l1111l11lll11l1l_cda_ = t1-abs(datetime.datetime.now() - l1llll11l1ll11l1l_cda_)
        except:
            l1111l11lll11l1l_cda_= False
        l111111llll11l1l_cda_,l111111111l11l1l_cda_ = l11ll1ll11l11l1l_cda_.l11lll1111l11l1l_cda_(self.l1lllllll1ll11l1l_cda_) if self.l1lllllll1ll11l1l_cda_ else ([],[])
        self.l1lll11l11l1l_cda_ = l1ll11l1l_cda_ (u"ࠪࡍࡱࡵज़ईࠢࡩ࡭ࡱࡳࣳࡸࠢࡺࠤࡧ࡯ࡢ࡭࡫ࡲࡸࡪࡩࡥ࠻ࠢ࡞ࡆࡢࠫࡤ࡜࠱ࡅࡡࠬ࿭")%len(l111111llll11l1l_cda_)
        self.l11ll1ll11l1l_cda_ = l1ll11l1l_cda_ (u"ࠫࡆࡱࡴࡶ࡮࡬ࡾࡦࡩࡪࡢࠢࡦࡳ࠿࡛ࠦࡃ࡟ࠨࡷࠥ࡮࡛࠰ࡄࡠࠫ࿮")%l11ll1ll11l11l1l_cda_.l11llll1l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠬࡲࡩࡣࡴࡤࡶࡾ࠴ࡳࡦࡴࡹ࡭ࡨ࡫࠮ࡸࡣ࡬ࡸ࠳ࡺࡩ࡮ࡧࠪ࿯"))
        l11111l111l11l1l_cda_ = l11ll1ll11l11l1l_cda_.l11llll1l1l11l1l_cda_(l1ll11l1l_cda_ (u"࠭࡬ࡪࡤࡵࡥࡷࡿ࠮ࡴࡧࡵࡺ࡮ࡩࡥ࠯ࡶࡨࡷࡹࡲࡩ࡯࡭࠱ࡨࡪࡲࡡࡺࠩ࿰"))
        self.l1111l1l11l1l_cda_ = l1ll11l1l_cda_ (u"ࠧॺࡴࣶࡨेࡧࠠࡣ࡫ࡥࡰ࡮ࡵࡴࡦ࡭࡬ࠤࡳ࡯ࡥࠡࡵईࠤࡸࡶࡲࡢࡹࡧࡾࡦࡴࡥࠡࡱ࡮ࡶࡪࡹ࡯ࡸࡱࠣ࡟ࡇࡣࠨ࠱ࠢࡧࡲ࡮࠯࡛࠰ࡄࡠࠫ࿱") if l11111l111l11l1l_cda_==l1ll11l1l_cda_ (u"ࠨ࠲ࠪ࿲") else l1ll11l1l_cda_ (u"ࠩࡖࡴࡷࡧࡷࡥࡼࡤࡲ࡮࡫ࠠॻࡴࣶࡨࡪैࠠࡤࡱ࠽ࠤࡠࡈ࡝ࠦࡵࠣࡨࡳ࡯࡛࠰ࡄࡠࠫ࿳")%l11111l111l11l1l_cda_
        self.l1ll1ll11l11l1l_cda_ = l1ll11l1l_cda_ (u"ࠪࡗࡪࡸࡶࡪࡥࡨ࠾ࠥࡡࡃࡐࡎࡒࡖࠥࡲࡩࡨࡪࡷ࡫ࡷ࡫ࡥ࡯࡟ࡲࡲࡱ࡯࡮ࡦ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ࿴") if l11ll1ll11l11l1l_cda_.l11llll1l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠫࡱ࡯ࡢࡳࡣࡵࡽ࠳ࡹࡥࡳࡸ࡬ࡧࡪ࠴ࡡࡤࡶ࡬ࡺࡪ࠭࿵")) == l1ll11l1l_cda_ (u"ࠬࡺࡲࡶࡧࠪ࿶") else l1ll11l1l_cda_ (u"࠭ࡓࡦࡴࡹ࡭ࡨ࡫࠺ࠡ࡝ࡆࡓࡑࡕࡒࠡࡴࡨࡨࡢࡵࡦࡧ࡮࡬ࡲࡪࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࿷")
        if l11ll1ll11l11l1l_cda_.l11llll1l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠧ࡭࡫ࡥࡶࡦࡸࡹ࠯ࡵࡨࡶࡻ࡯ࡣࡦ࠰ࡤࡧࡹ࡯ࡶࡦࠩ࿸")) == l1ll11l1l_cda_ (u"ࠨࡶࡵࡹࡪ࠭࿹") and l1111l11lll11l1l_cda_:
            l11111lllll11l1l_cda_ = l1ll11l1l_cda_ (u"ࠩࡦ࡬ࡼ࡯࡬࡬छࠪ࿺") if l1111l11lll11l1l_cda_.days<0 else str(l1111l11lll11l1l_cda_).split(l1ll11l1l_cda_ (u"ࠪ࠲ࠬ࿻"))[0]+l1ll11l1l_cda_ (u"ࠫࠥ࡮ࠧ࿼")
            self.l1l111ll11l1l_cda_ = l1ll11l1l_cda_ (u"ࠬࡔࡡࡴࡶजࡴࡳ࡫ࠠࡴࡼࡸ࡯ࡦࡴࡩࡦࠢࡽࡥࠥࡵ࡫࠻ࠢ࡞ࡆࡢࠦࠥࡴࠢ࡞࠳ࡇࡣࠠࠨ࿽")%l11111lllll11l1l_cda_
        else:
            self.l1l111ll11l1l_cda_ = l1ll11l1l_cda_ (u"࠭ࡎࡢࡵࡷझࡵࡴࡥࠡࡵࡽࡹࡰࡧ࡮ࡪࡧࠣࡲ࡮࡫ࠠࡸ࡫ࡤࡨࡴࡳ࡯ࠡ࡭࡬ࡩࡩࡿࠧ࿾")
        self.l11l1l1l11l1l_cda_ = l1ll11l1l_cda_ (u"ࠧࡐࡵࡷࡥࡹࡴࡩࡢࠢࡄ࡯ࡹࡻࡡ࡭࡫ࡽࡥࡨࡰࡡ࠻ࠢ࡞ࡆࡢࠫࡳ࡜࠱ࡅࡡࠬ࿿")%l11ll1ll11l11l1l_cda_.l11llll1l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠨ࡮࡬ࡦࡷࡧࡲࡺ࠰ࡶࡩࡷࡼࡩࡤࡧ࠱ࡰࡦࡹࡴ࠯ࡴࡸࡲࠬက"))
class l1ll1lll11l1l_cda_:
    def __init__(self):
        self.l1111l1llll11l1l_cda_ = os.path.join(l11ll1ll11l11l1l_cda_.l1l111lll1l11l1l_cda_(l11ll1ll11l11l1l_cda_.l11llll1l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠩ࡯࡭ࡧࡸࡡࡳࡻ࠱ࡱࡴࡼࡩࡦࠩခ"))), l1ll11l1l_cda_ (u"ࠪࠫဂ"))
        self.l1lll1ll1l1l11l1l_cda_ = l11ll1ll11l11l1l_cda_.l11llll1l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠫࡱ࡯ࡢࡳࡣࡵࡽ࠳ࡩࡨࡦࡥ࡮ࡣࡲࡵࡶࡪࡧࠪဃ")) or l1ll11l1l_cda_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫင")
        self.l1111l111ll11l1l_cda_ = l11ll1ll11l11l1l_cda_.l11llll1l1l11l1l_cda_(l1ll11l1l_cda_ (u"࠭࡬ࡪࡤࡵࡥࡷࡿ࠮ࡶࡲࡧࡥࡹ࡫ࠧစ")) or l1ll11l1l_cda_ (u"ࠧࡵࡴࡸࡩࠬဆ")
        self.l11111l1lll11l1l_cda_ = l11ll1ll11l11l1l_cda_.l11llll1l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠨ࡮࡬ࡦࡷࡧࡲࡺ࠰ࡦ࡬ࡪࡩ࡫ࠨဇ")) or l1ll11l1l_cda_ (u"ࠩࡷࡶࡺ࡫ࠧဈ")
        self.l1lllll1ll1l11l1l_cda_ = 10
        self.l11ll1lllll11l1l_cda_ = False
        self.l11ll11ll1l11l1l_cda_ = False
        self.l1llllll11ll11l1l_cda_ = True
    def add(self, l1llllllll11l1l_cda_):
        _1lllllll11l11l1l_cda_ = l1llllllll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠪࡣ࡫࡯࡬࡮ࡹࡨࡦࠬဉ"),False)
        title = l1llllllll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪည"),l1ll11l1l_cda_ (u"ࠬ࠭ဋ"))
        title = re.sub(l1ll11l1l_cda_ (u"࠭࡜ࠩ࡞ࡧࡿ࠹ࢃ࡜ࠪࠩဌ"),l1ll11l1l_cda_ (u"ࠧࠨဍ"),title).strip()
        year  = l1llllllll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠨࡻࡨࡥࡷ࠭ဎ"),l1ll11l1l_cda_ (u"ࠩࠪဏ"))
        url   = l1llllllll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠪࡹࡷࡲࠧတ"),l1ll11l1l_cda_ (u"ࠫࠬထ"))
        if not ( _1lllllll11l11l1l_cda_ and url):
            return False
        if self.l1lll1ll1l1l11l1l_cda_ == l1ll11l1l_cda_ (u"ࠬࡺࡲࡶࡧࠪဒ"):
            if l1llllll111l11l1l_cda_.l1lll1llllll11l1l_cda_(url) != l1ll11l1l_cda_ (u"࠭ࡏࡌࠩဓ"):
                return False
        if not l11ll1ll11l11l1l_cda_.l11l1l11l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠧࡘ࡫ࡱࡨࡴࡽ࠮ࡊࡵ࡙࡭ࡸ࡯ࡢ࡭ࡧࠫ࡭ࡳ࡬࡯ࡥ࡫ࡤࡰࡴ࡭ࠩࠨန")) and not l11ll1ll11l11l1l_cda_.l11l1l11l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠨࡒ࡯ࡥࡾ࡫ࡲ࠯ࡊࡤࡷ࡛࡯ࡤࡦࡱࠪပ")):
            l11ll1ll11l11l1l_cda_.l11ll1lllll11l1l_cda_(l1ll11l1l_cda_ (u"ࠩࡇࡳࡩࡧࡷࡢࡰ࡬ࡩࠥࡪ࡯ࠡࡄ࡬ࡦࡱ࡯࡯ࡵࡧ࡮࡭ࠥ࠴࠮࠯ࠩဖ"), time=3)
            self.l11ll1lllll11l1l_cda_ = True
        l1lll1ll1lll11l1l_cda_ = 0
        if self.l1llll1lll1l11l1l_cda_(_1lllllll11l11l1l_cda_,title,year,url):
            l1lll1ll1lll11l1l_cda_ += 1
        if self.l11ll1lllll11l1l_cda_ == True:
            l11ll1ll11l11l1l_cda_.l11ll1lllll11l1l_cda_(l1ll11l1l_cda_ (u"ࠪ࡞ࡦࡱ࡯ॅࡥࡽࡳࡳࡵࠧဗ"), time=2)
        if self.l1111l111ll11l1l_cda_ == l1ll11l1l_cda_ (u"ࠫࡹࡸࡵࡦࠩဘ") and not l11ll1ll11l11l1l_cda_.l11l1l11l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠬࡒࡩࡣࡴࡤࡶࡾ࠴ࡉࡴࡕࡦࡥࡳࡴࡩ࡯ࡩ࡙࡭ࡩ࡫࡯ࠨမ")) and l1lll1ll1lll11l1l_cda_ > 0:
            l11ll1ll11l11l1l_cda_.l11ll111l1l11l1l_cda_(l1ll11l1l_cda_ (u"࠭ࡕࡱࡦࡤࡸࡪࡒࡩࡣࡴࡤࡶࡾ࠮ࡶࡪࡦࡨࡳ࠮࠭ယ"))
    def l111l1lll11l1l_cda_(self, l1ll1l1lll11l1l_cda_):
        if not l11ll1ll11l11l1l_cda_.l11l1l11l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠧࡘ࡫ࡱࡨࡴࡽ࠮ࡊࡵ࡙࡭ࡸ࡯ࡢ࡭ࡧࠫ࡭ࡳ࡬࡯ࡥ࡫ࡤࡰࡴ࡭ࠩࠨရ")) and not l11ll1ll11l11l1l_cda_.l11l1l11l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠨࡒ࡯ࡥࡾ࡫ࡲ࠯ࡊࡤࡷ࡛࡯ࡤࡦࡱࠪလ")):
            try:
                l11ll1ll11l11l1l_cda_.l11ll1lllll11l1l_cda_(l1ll11l1l_cda_ (u"ࠩࡇࡳࡩࡧࡷࡢࡰ࡬ࡩࠥࡌ࡯࡭ࡦࡨࡶࡺࠦࡤࡰࠢࡅ࡭ࡧࡲࡩࡰࡶࡨ࡯࡮ࠦ࠮࠯࠰ࠪဝ"), time=3)
                self.l11ll1lllll11l1l_cda_ = True
            except:
                self.l11ll1lllll11l1l_cda_ = False
        l1lll1ll1lll11l1l_cda_ = 0
        l11ll111lll11l1l_cda_ = l11ll1ll11l11l1l_cda_.l11ll111lll11l1l_cda_
        l11ll111lll11l1l_cda_.create(l1ll11l1l_cda_ (u"ࠪࡧࡩࡧ࠮ࡱ࡮ࠪသ"),l1ll11l1l_cda_ (u"ࠫࡉࡵࡤࡢࡹࡤࡲ࡮࡫ࠠࡇࡱ࡯ࡨࡪࡸࡵࠡࡦࡲࠤࡇ࡯ࡢ࡭࡫ࡲࡸࡪࡱࡩࠨဟ"))
        for index, l1llllllll11l1l_cda_ in enumerate(l1ll1l1lll11l1l_cda_):
            l1llll1lllll11l1l_cda_ = int((index+1)*100.0/(len(l1ll1l1lll11l1l_cda_)))
            _1lllllll11l11l1l_cda_ = l1llllllll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠬࡥࡦࡪ࡮ࡰࡻࡪࡨࠧဠ"),False)
            title = l1llllllll11l1l_cda_.get(l1ll11l1l_cda_ (u"࠭ࡴࡪࡶ࡯ࡩࠬအ"),l1ll11l1l_cda_ (u"ࠧࠨဢ"))
            title = re.sub(l1ll11l1l_cda_ (u"ࠨ࡞ࠫࡠࡩࢁ࠴ࡾ࡞ࠬࠫဣ"),l1ll11l1l_cda_ (u"ࠩࠪဤ"),title).strip()
            year  = l1llllllll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠪࡽࡪࡧࡲࠨဥ"),l1ll11l1l_cda_ (u"ࠫࠬဦ"))
            url   = l1llllllll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠬࡻࡲ࡭ࠩဧ"),l1ll11l1l_cda_ (u"࠭ࠧဨ"))
            if not ( _1lllllll11l11l1l_cda_ and url): continue
            if self.l1lll1ll1l1l11l1l_cda_ == l1ll11l1l_cda_ (u"ࠧࡵࡴࡸࡩࠬဩ"):
                if l1llllll111l11l1l_cda_.l1lll1llllll11l1l_cda_(url) != l1ll11l1l_cda_ (u"ࠨࡑࡎࠫဪ"):
                    l11ll111lll11l1l_cda_.update(l1llll1lllll11l1l_cda_,message=l1ll11l1l_cda_ (u"ࠩࡰࡥࡷࡺࡷࡺࠢ࡯࡭ࡳࡱࠠ࡜ࠧࡶࡡࠥ࠭ါ")%(title))
                    l1lll1lll1ll11l1l_cda_(l1ll11l1l_cda_ (u"ࠪ࡟ࡈ࡮ࡥࡤ࡭ࡏ࡭ࡳࡱ࡝࠻ࠢࡅࡅࡉࠦࡓࡰࡷࡵࡧࡪࡀࠠࠦࡵࠪာ")%title)
                    continue
                else:
                    l1lll1lll1ll11l1l_cda_(l1ll11l1l_cda_ (u"ࠫࡠࡉࡨࡦࡥ࡮ࡐ࡮ࡴ࡫࡞࠼ࠣࡓࡐࠦࡓࡰࡷࡵࡧࡪࡀࠠࠦࡵࠪိ")%title)
            if self.l1llll1lll1l11l1l_cda_(_1lllllll11l11l1l_cda_,title,year,url):
                l1lll1ll1lll11l1l_cda_ += 1
                l11ll111lll11l1l_cda_.update(l1llll1lllll11l1l_cda_,message=l1ll11l1l_cda_ (u"ࠬࡊ࡯ࡥࡣࡱࡳࠥࡡࠥࡴ࡟ࠣࠫီ")%(title))
        l11ll111lll11l1l_cda_.close()
        if self.l11ll1lllll11l1l_cda_ == True:
            l11ll1ll11l11l1l_cda_.l11ll1lllll11l1l_cda_(l1ll11l1l_cda_ (u"࠭ࡄࡰࡦࡤࡲࡴࠦࠥࡥࠢࡩ࡭ࡱࡳࣳࡸࠩု")%l1lll1ll1lll11l1l_cda_, time=2)
        if self.l1111l111ll11l1l_cda_ == l1ll11l1l_cda_ (u"ࠧࡵࡴࡸࡩࠬူ") and not l11ll1ll11l11l1l_cda_.l11l1l11l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠨࡎ࡬ࡦࡷࡧࡲࡺ࠰ࡌࡷࡘࡩࡡ࡯ࡰ࡬ࡲ࡬࡜ࡩࡥࡧࡲࠫေ")) and l1lll1ll1lll11l1l_cda_ > 0:
            l11ll1ll11l11l1l_cda_.l11ll111l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠩࡘࡴࡩࡧࡴࡦࡎ࡬ࡦࡷࡧࡲࡺࠪࡹ࡭ࡩ࡫࡯ࠪࠩဲ"))
    def l1llll1lll1l11l1l_cda_(self, _1lllllll11l11l1l_cda_, title, year, url):
        if isinstance(title,unicode): title = title.encode(l1ll11l1l_cda_ (u"ࠪࡹࡹ࡬࠭࠹ࠩဳ"))
        l1lll1llll1l11l1l_cda_ = l111111l11l11l1l_cda_(title.translate(None, l1ll11l1l_cda_ (u"ࠫࡡ࠵࠺ࠫࡁࠥࡀࡃࢂࠧဴ")) )
        content = l1llllll111l11l1l_cda_.l11111l11l1l_cda_({l1ll11l1l_cda_ (u"ࠬࡳ࡯ࡥࡧࠪဵ"): l1ll11l1l_cda_ (u"࠭࡬ࡱ࡮ࡤࡽࠬံ"), l1ll11l1l_cda_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨ့"):str({l1ll11l1l_cda_ (u"ࠨࡡࡩ࡭ࡱࡳࡷࡦࡤࠪး"):_1lllllll11l11l1l_cda_,l1ll11l1l_cda_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ္"):title,l1ll11l1l_cda_ (u"ࠪࡽࡪࡧࡲࠨ်"):year,l1ll11l1l_cda_ (u"ࠫࡺࡸ࡬ࠨျ"):[url],l1ll11l1l_cda_ (u"ࠬࡲࡩ࡯࡭ࡦ࡬ࡪࡩ࡫ࡦࡦࠪြ"): datetime.datetime.now().strftime(l1ll11l1l_cda_ (u"࡚࠭ࠥ࠯ࠨࡱ࠲ࠫࡤࠡࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠪွ")) })})
        l11111111ll11l1l_cda_ = l1llllll111l11l1l_cda_.l1lllll1l11l11l1l_cda_(self.l1111l1llll11l1l_cda_, l1lll1llll1l11l1l_cda_, year)
        l1llllll111l11l1l_cda_.l1llll1l11ll11l1l_cda_(l11111111ll11l1l_cda_)
        l1lllll111ll11l1l_cda_ = os.path.join(l11111111ll11l1l_cda_, l1llllll111l11l1l_cda_.l1lllll11lll11l1l_cda_(l1lll1llll1l11l1l_cda_) + l1ll11l1l_cda_ (u"ࠧ࠯ࡵࡷࡶࡲ࠭ှ"))
        if self.l1llllll11ll11l1l_cda_ == True and os.path.exists(l1lllll111ll11l1l_cda_):
            content = l1llllll111l11l1l_cda_.l1111l11l1l11l1l_cda_(l1lllll111ll11l1l_cda_)
            l1llll1l111l11l1l_cda_ = eval(urlparse.parse_qs(content.split(l1ll11l1l_cda_ (u"ࠨࡁࠪဿ"))[-1]).get(l1ll11l1l_cda_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪ၀"),{})[0]).get(l1ll11l1l_cda_ (u"ࠪࡹࡷࡲࠧ၁"),[])
            l1llll1l111l11l1l_cda_.append(url)
            l1llll1l111l11l1l_cda_ = list(set(l1llll1l111l11l1l_cda_))
            content = l1llllll111l11l1l_cda_.l11111l11l1l_cda_({l1ll11l1l_cda_ (u"ࠫࡲࡵࡤࡦࠩ၂"): l1ll11l1l_cda_ (u"ࠬࡲࡰ࡭ࡣࡼࠫ၃"), l1ll11l1l_cda_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧ၄"):str({l1ll11l1l_cda_ (u"ࠧࡠࡨ࡬ࡰࡲࡽࡥࡣࠩ၅"):_1lllllll11l11l1l_cda_,l1ll11l1l_cda_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ၆"):title,l1ll11l1l_cda_ (u"ࠩࡼࡩࡦࡸࠧ၇"):year,l1ll11l1l_cda_ (u"ࠪࡹࡷࡲࠧ၈"):l1llll1l111l11l1l_cda_,l1ll11l1l_cda_ (u"ࠫࡱ࡯࡮࡬ࡥ࡫ࡩࡨࡱࡥࡥࠩ၉"): datetime.datetime.now().strftime(l1ll11l1l_cda_ (u"࡙ࠬࠫ࠮ࠧࡰ࠱ࠪࡪࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠩ၊")) })})
        l1llllll111l11l1l_cda_.l1111l1111l11l1l_cda_(l1lllll111ll11l1l_cda_, content)
        l1llllll111l11l1l_cda_.l1111l1111l11l1l_cda_(os.path.join(l11111111ll11l1l_cda_, l1ll11l1l_cda_ (u"࠭࡭ࡰࡸ࡬ࡩ࠳ࡴࡦࡰࠩ။")), l1llllll111l11l1l_cda_.l1lllll1111l11l1l_cda_(l1ll11l1l_cda_ (u"ࠧ࡮ࡱࡹ࡭ࡪ࠭၌"), {l1ll11l1l_cda_ (u"ࠨࡦࡤࡸࡦࡥࡦࡪ࡮ࡰࠫ၍"):_1lllllll11l11l1l_cda_}))
        l111l111l1l11l1l_cda_ = True
        return l111l111l1l11l1l_cda_
    def l1llll1ll1ll11l1l_cda_(self,l11l1llll11l1l_cda_,idx,N):
        from l11l111l11l1l_cda_ import l111l1l1l11l1l_cda_
        from l1111111l11l1l_cda_ import l11l11l11ll11l1l_cda_
        title, year, label = l111l1l1l11l1l_cda_(l11l1llll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ၎")))
        title = title.split(l1ll11l1l_cda_ (u"ࠪ࠱ࠬ၏"))[0]
        title = l1llllll111l11l1l_cda_.l1111ll11ll11l1l_cda_(title)
        l1111ll111l11l1l_cda_ = year or l11l1llll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠫࡾ࡫ࡡࡳࠩၐ"))
        l1llll1lllll11l1l_cda_ = int((idx+1)*100.0/(N))
        l111l1lll1l11l1l_cda_ = l11l11l11ll11l1l_cda_(title,l1111ll111l11l1l_cda_)
        if l111l1lll1l11l1l_cda_:
            l1lll1lll1ll11l1l_cda_(l1ll11l1l_cda_ (u"ࠬࡡࡁࡥࡦࡐࡳࡻ࡯ࡥ࡞࠼ࠣࡑࡴࡼࡩࡦࠢ࠰ࡂࠥࠫࡳࠡࠪࠨࡷ࠮ࠦࠧၑ")%(l111l1lll1l11l1l_cda_.get(l1ll11l1l_cda_ (u"࠭ࡴࡪࡶ࡯ࡩࠬၒ")),l111l1lll1l11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠧࡺࡧࡤࡶࠬၓ"))))
            l111l1lll1l11l1l_cda_[l1ll11l1l_cda_ (u"ࠨࡡࡩ࡭ࡱࡳࡷࡦࡤࠪၔ")]=l111l1lll1l11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠩ࡬ࡨࠬၕ"),l1ll11l1l_cda_ (u"ࠪࠫၖ"))
            l111l1lll1l11l1l_cda_[l1ll11l1l_cda_ (u"ࠫࡺࡸ࡬ࠨၗ")]= l11l1llll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠬࡻࡲ࡭ࠩၘ"))
            self.l11111lll1l11l1l_cda_.append(l111l1lll1l11l1l_cda_)
            self.l11ll111lll11l1l_cda_.update(l1llll1lllll11l1l_cda_,message=l1ll11l1l_cda_ (u"࠭ࠥࡴࠢࠫࠩࡸ࠯ࠧၙ")%(l111l1lll1l11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ၚ")),l111l1lll1l11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠨࡻࡨࡥࡷ࠭ၛ"))))
    def l1ll111l1l11l1l_cda_(self):
        from l11l111l11l1l_cda_ import l1ll1l11ll11l1l_cda_
        import l11ll11ll11l1l_cda_
        import time
        self.l1lll1ll1l1l11l1l_cda_ = l1ll11l1l_cda_ (u"ࠩࡩࡥࡱࡹࡥࠨၜ")
        url = l1ll11l1l_cda_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡥࡧࡥ࠳ࡶ࡬࠰ࡸ࡬ࡨࡪࡵ࠯ࡴࡪࡲࡻ࠴ࡩࡡ࡭ࡧࡢࡪ࡮ࡲ࡭ࡺࡡࡲࡶࡤࡩࡡ࡭ࡻࡢࡪ࡮ࡲ࡭ࡠࡱࡵࡣࡱ࡫࡫ࡵࡱࡵࡣࡴࡸ࡟ࡱ࡮ࡢࡳࡷࡥࡤࡶࡤࡥ࡭ࡳ࡭࡟ࡰࡴࡢࡲࡦࡶࡩࡴࡻࡢࡳࡷࡥࡦࡱࡵࡢࡳࡷࡥ࡯ࡥࡥ࠲ࡴࠪࡪ࠿ࡥࡷࡵࡥࡹ࡯࡯࡯࠿ࡧࡰࡺ࡭ࡩࡦࠨࡶࡩࡨࡺࡩࡰࡰࡀࠪࡶࡻࡡ࡭࡫ࡷࡽࡂ࠽࠲࠱ࡲࠩࡷࡪࡩࡴࡪࡱࡱࡁࠫࡹ࠽ࡥࡣࡷࡩࠫࡹࡥࡤࡶ࡬ࡳࡳࡃࠧၝ")
        if not l11ll1ll11l11l1l_cda_.l11l1l11l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠫ࡜࡯࡮ࡥࡱࡺ࠲ࡎࡹࡖࡪࡵ࡬ࡦࡱ࡫ࠨࡪࡰࡩࡳࡩ࡯ࡡ࡭ࡱࡪ࠭ࠬၞ")) and not l11ll1ll11l11l1l_cda_.l11l1l11l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠬࡖ࡬ࡢࡻࡨࡶ࠳ࡎࡡࡴࡘ࡬ࡨࡪࡵࠧၟ")):
            try:
                l11ll1ll11l11l1l_cda_.l11ll1lllll11l1l_cda_(l1ll11l1l_cda_ (u"࠭ࡓࡻࡷ࡮ࡥࡲࠦ࡮ࡰࡹࡼࡧ࡭ࠦࡦࡪ࡮ࡰࣷࡼࠦ࠮࠯࠰ࠪၠ"), time=3)
                self.l11ll1lllll11l1l_cda_ = True
            except:
                self.l11ll1lllll11l1l_cda_ = False
        self.l11ll111lll11l1l_cda_ = l11ll1ll11l11l1l_cda_.l11ll111lll11l1l_cda_
        self.l11ll111lll11l1l_cda_.create(l1ll11l1l_cda_ (u"ࠧࡤࡦࡤ࠲ࡵࡲࠧၡ"),l1ll11l1l_cda_ (u"ࠨࡕࡽࡹࡰࡧ࡭ࠡࡰࡲࡻࡾࡩࡨࠡࡨ࡬ࡰࡲࣹࡷࠡ࠰࠱࠲ࠬၢ"))
        items=[]
        l11ll1ll11l11l1l_cda_.setSetting(l1ll11l1l_cda_ (u"ࠩ࡯࡭ࡧࡸࡡࡳࡻ࠱ࡷࡪࡸࡶࡪࡥࡨ࠲ࡱࡧࡳࡵ࠰ࡵࡹࡳ࠭ၣ"), datetime.datetime.now().strftime(l1ll11l1l_cda_ (u"ࠪࠩ࡞࠳ࠥ࡮࠯ࠨࡨࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠧၤ")))
        for l1llll111l1l11l1l_cda_ in range(int(l11ll1ll11l11l1l_cda_.l11llll1l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠫࡱ࡯ࡢࡳࡣࡵࡽ࠳ࡹࡥࡳࡸ࡬ࡧࡪ࠴ࡰࡢࡩࡨࡷࠬၥ")) or 1)):
            l1llll111l1l11l1l_cda_ +=1
            l1lll1lll1ll11l1l_cda_(l1ll11l1l_cda_ (u"ࠬࡡࡁࡥࡦࡐࡳࡻ࡯ࡥ࡞࠼ࠣࡗࡪࡧࡲࡤࡪ࡬ࡲ࡬ࠦࡣࡥࡣ࠱ࡴࡱ࠲ࠠࡱࡣࡪࡩࠥࡡࠥࡥ࡟ࠪၦ")%l1llll111l1l11l1l_cda_)
            l1llll11111l11l1l_cda_,next=l1ll1l11ll11l1l_cda_(url%(l1llll111l1l11l1l_cda_),False,False)
            items.extend(l1llll11111l11l1l_cda_)
            self.l11ll111lll11l1l_cda_.update(0,message=l1ll11l1l_cda_ (u"࡚࠭࡯ࡣ࡯ࡥࡿैࡥ࡮ࠢࡳࡳࡿࡿࡣ࡫࡫ࠣ࡟ࠪࡪ࡝ࠡࠩၧ")%(len(items)))
        self.l11ll111lll11l1l_cda_.update(0,message=l1ll11l1l_cda_ (u"ࠧࡊࡰࡧࡩࡳࡺࡹࡧ࡫࡮ࡹ࡯࡫ࠠࠦࡦࠣࡪ࡮ࡲ࡭ࣴࡹࠣࡻࠥࠫࡤࠡࡹईࡸࡰࡧࡣࡩࠢ࠱࠲࠳࠭ၨ")%(len(items),self.l1lllll1ll1l11l1l_cda_))
        items = [x for x in items if x.get(l1ll11l1l_cda_ (u"ࠨࡥࡲࡨࡪ࠭ၩ"),l1ll11l1l_cda_ (u"ࠩࠪၪ"))!= l1ll11l1l_cda_ (u"ࠪࠫၫ")]
        l1lll1lll1ll11l1l_cda_(l1ll11l1l_cda_ (u"ࠫࡠࡇࡤࡥࡏࡲࡺ࡮࡫࡝࠻ࠢࡉࡳࡺࡴࡤࠡࡖࡲࡸࡦࡲࠠࠦࡦࠣࡺ࡮ࡪࡥࡰࡵࠣ࠲࠳࠴ࠠࠨၬ")%(len(items)))
        pool = l11ll11ll11l1l_cda_.ThreadPool(self.l1lllll1ll1l11l1l_cda_)
        self.l11111lll1l11l1l_cda_=[]
        N=len(items)
        for idx,l11l1llll11l1l_cda_ in enumerate(items):
            pool.l1llll1l1lll11l1l_cda_(self.l1llll1ll1ll11l1l_cda_, *(l11l1llll11l1l_cda_,idx,N))
            time.sleep(0.1)
        pool.l1llll11l11l1l_cda_()
        l1lll1lll1ll11l1l_cda_(l1ll11l1l_cda_ (u"ࠬࡡࡁࡥࡦࡐࡳࡻ࡯ࡥ࡞࠼ࠣࠬࡆ࡬ࡴࡦࡴࠣࡘ࡭ࡸࡥࡢࡦ࡬ࡲ࡬࠯ࠠࡇࡱࡸࡲࡩࠦࡔࡰࡶࡤࡰࠥࠫࡤࠡࡏࡲࡺ࡮࡫ࡳࠡ࠰࠱࠲ࠥ࠭ၭ")%(len(self.l11111lll1l11l1l_cda_)))
        self.l11111lll1l11l1l_cda_.reverse()
        self.l11ll111lll11l1l_cda_.close()
        self.l111l1lll11l1l_cda_( self.l11111lll1l11l1l_cda_ )
        l11ll1ll11l11l1l_cda_.setSetting(l1ll11l1l_cda_ (u"࠭࡬ࡪࡤࡵࡥࡷࡿ࠮ࡴࡧࡵࡺ࡮ࡩࡥ࠯࡮ࡤࡷࡹ࠴ࡲࡶࡰࠪၮ"), datetime.datetime.now().strftime(l1ll11l1l_cda_ (u"࡛ࠧࠦ࠰ࠩࡲ࠳ࠥࡥࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠫၯ")))
    def l1111111l1l11l1l_cda_(self,l11111l11ll11l1l_cda_,idx,N):
        from shutil import rmtree
        l1llll1111ll11l1l_cda_ = os.path.join(self.l1111l1llll11l1l_cda_,l11111l11ll11l1l_cda_)
        content = l11ll1ll11l11l1l_cda_.l11lll1111l11l1l_cda_(l1llll1111ll11l1l_cda_)
        l1llll1lll1l11l1l_cda_ = [os.path.join(self.l1111l1llll11l1l_cda_,l11111l11ll11l1l_cda_,x) for x in content[1] if x.endswith(l1ll11l1l_cda_ (u"ࠨ࠰ࡶࡸࡷࡳࠧၰ"))]
        l1llll1lllll11l1l_cda_ = int((idx+1)*100.0/(N))
        self.l11ll111lll11l1l_cda_.update(l1llll1lllll11l1l_cda_,message=l1ll11l1l_cda_ (u"ࠩࠨࡷࠬၱ")%(l11111l11ll11l1l_cda_))
        if l1llll1lll1l11l1l_cda_:
            l1llll1lll1l11l1l_cda_ = l1llll1lll1l11l1l_cda_[0]
            content = l1llllll111l11l1l_cda_.l1111l11l1l11l1l_cda_(l1llll1lll1l11l1l_cda_)
            l11111ll1ll11l1l_cda_ = eval(urlparse.parse_qs(content.split(l1ll11l1l_cda_ (u"ࠪࡃࠬၲ"))[-1]).get(l1ll11l1l_cda_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬၳ"),{})[0])
            l1llll1l111l11l1l_cda_ = l11111ll1ll11l1l_cda_.get(l1ll11l1l_cda_ (u"ࠬࡻࡲ࡭ࠩၴ"),[])
            l1111l1l1ll11l1l_cda_ = l11111ll1ll11l1l_cda_.get(l1ll11l1l_cda_ (u"࠭࡬ࡪࡰ࡮ࡧ࡭࡫ࡣ࡬ࡧࡧࠫၵ"),l1ll11l1l_cda_ (u"ࠢ࠳࠲࠳࠴࠲࠶࠱࠮࠲࠴ࠤ࠶࠸࠺࠱࠲࠽࠴࠵ࠨၶ"))
            l1111l1l1ll11l1l_cda_ = datetime.datetime.strptime(l1111l1l1ll11l1l_cda_, l1ll11l1l_cda_ (u"ࠨࠧ࡜࠱ࠪࡳ࠭ࠦࡦࠣࠩࡍࡀࠥࡎ࠼ࠨࡗࠬၷ"))
            l1lllll1llll11l1l_cda_ = datetime.datetime.now() - l1111l1l1ll11l1l_cda_
            if l1lllll1llll11l1l_cda_.days >= self.l1111l1l11l11l1l_cda_:
                self.res[l1ll11l1l_cda_ (u"ࠩࡦ࡬ࡪࡩ࡫ࡦࡦࠪၸ")]+=1
                l1llllll1lll11l1l_cda_=[l1llll11l11l11l1l_cda_ for l1llll11l11l11l1l_cda_ in set(l1llll1l111l11l1l_cda_) if l1ll11l1l_cda_ (u"ࠪࡓࡐ࠭ၹ") in l1llllll111l11l1l_cda_.l1lll1llllll11l1l_cda_(l1llll11l11l11l1l_cda_)]
                l1lll1lll1ll11l1l_cda_(l1ll11l1l_cda_ (u"ࠫࡠࡉࡨࡦࡥ࡮ࡐ࡮ࡴ࡫࡞࠼ࠣࡇ࡭࡫ࡣ࡬࡫ࡱ࡫ࠥࠫࡳࠡ࡮࡬ࡲࡰࡹࠠࡤࡱࡸࡲࡹࠦࡢࡦࡨࡲࡶࡪ࠵ࡡࡧࡶࡨࡶ࠿ࠦࠥࡥ࠱ࠨࡨࠬၺ")%(l11111l11ll11l1l_cda_,len(l1llll1l111l11l1l_cda_),len(l1llllll1lll11l1l_cda_)))
                if len(l1llllll1lll11l1l_cda_)==0:
                    rmtree(l1llll1111ll11l1l_cda_)
                    self.res[l1ll11l1l_cda_ (u"ࠬࡸࡥ࡮ࡱࡹࡩࡩ࠭ၻ")]+=1
                    l1lll1lll1ll11l1l_cda_(l1ll11l1l_cda_ (u"࡛࠭ࡄࡪࡨࡧࡰࡒࡩ࡯࡭ࡠ࠾ࠥࡘࡥ࡮ࡱࡹ࡭ࡳ࡭ࠠࡇࡱ࡯ࡨࡪࡸࠠࠦࡵࠪၼ")%(l11111l11ll11l1l_cda_))
                else:
                    l11111ll1ll11l1l_cda_.update( {l1ll11l1l_cda_ (u"ࠧࡶࡴ࡯ࠫၽ"):l1llllll1lll11l1l_cda_, l1ll11l1l_cda_ (u"ࠨ࡮࡬ࡲࡰࡩࡨࡦࡥ࡮ࡩࡩ࠭ၾ"): datetime.datetime.now().strftime(l1ll11l1l_cda_ (u"ࠩࠨ࡝࠲ࠫ࡭࠮ࠧࡧࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘ࠭ၿ")) } )
                    content = l1llllll111l11l1l_cda_.l11111l11l1l_cda_({l1ll11l1l_cda_ (u"ࠪࡱࡴࡪࡥࠨႀ"): l1ll11l1l_cda_ (u"ࠫࡱࡶ࡬ࡢࡻࠪႁ"), l1ll11l1l_cda_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭ႂ"):str(l11111ll1ll11l1l_cda_)})
                    l1llllll111l11l1l_cda_.l1111l1111l11l1l_cda_(l1llll1lll1l11l1l_cda_, content)
                    self.res[l1ll11l1l_cda_ (u"࠭ࡵࡱࡦࡤࡸࡪࡪࠧႃ")]+=1
                    l1lll1lll1ll11l1l_cda_(l1ll11l1l_cda_ (u"ࠧ࡜ࡅ࡫ࡩࡨࡱࡌࡪࡰ࡮ࡡ࠿ࠦࡕࡱࡦࡤࡸࡪ࡯࡮ࡨࠢࡶࡸࡷࡳࡆࡪ࡮ࡨࡁࠥࠫࡳࠨႄ")%(l1llll1lll1l11l1l_cda_))
            else:
                self.res[l1ll11l1l_cda_ (u"ࠨࡵ࡮࡭ࡵࡶࡥࡥࠩႅ")]+=1
                l1lll1lll1ll11l1l_cda_(l1ll11l1l_cda_ (u"ࠩ࡞ࡇ࡭࡫ࡣ࡬ࡎ࡬ࡲࡰࡣ࠺ࠡࡕ࡮࡭ࡵࡶࡩ࡯ࡩࠣࠩࡸࠦࡡ࡭ࡴࡨࡥࡩࡿࠠࡤࡪࡨࡧࡰ࡫ࡤࠡࡱࡱࠤࠪࡹࠧႆ")%(l11111l11ll11l1l_cda_,str(l1111l1l1ll11l1l_cda_)) )
    def l111lll1l11l1l_cda_(self):
        import l11ll11ll11l1l_cda_
        import time
        self.l1111l1l11l11l1l_cda_ =  int(l11ll1ll11l11l1l_cda_.l11llll1l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠪࡰ࡮ࡨࡲࡢࡴࡼ࠲ࡸ࡫ࡲࡷ࡫ࡦࡩ࠳ࡺࡥࡴࡶ࡯࡭ࡳࡱ࠮ࡥࡧ࡯ࡥࡾ࠭ႇ")) or 0)
        if self.l1111l1l11l11l1l_cda_ == 0:
            l1lll1lll1ll11l1l_cda_(l1ll11l1l_cda_ (u"ࠫࡠࡉࡨࡦࡥ࡮ࡐ࡮ࡴ࡫࡞࠼ࠣࡗ࡙ࡇࡒࡕࠢࡤࡲࡩࠦࡓࡕࡑࡓࠤ࠲ࠦࡄࡰࠢࡱࡳࡹࠦࡣࡩࡧࡦ࡯ࠥࡲࡩࡣࡴࡤࡶࡾࠦࡳࡰࡷࡵࡧࡪࡹࠧႈ"))
            return
        l111111llll11l1l_cda_,l111111111l11l1l_cda_ = l11ll1ll11l11l1l_cda_.l11lll1111l11l1l_cda_(self.l1111l1llll11l1l_cda_)
        self.l11ll111lll11l1l_cda_ = l11ll1ll11l11l1l_cda_.l11ll111lll11l1l_cda_
        self.l11ll111lll11l1l_cda_.create(l1ll11l1l_cda_ (u"࡙ࠬࡰࡳࡣࡺࡨࡿࡧ࡭ࠡॼࡵࣷࡩैࡡࠡࡤ࡬ࡦࡱ࡯࡯ࡵࡧ࡮࡭ࠥࡩࡤࡢ࠰ࡳࡰࠬႉ"),l1ll11l1l_cda_ (u"࠭ࡉ࡭ࡱफ़ऋࠥࡶ࡯ࡻࡻࡦ࡮࡮ࡀࠠࠦࡦࠪႊ")%len(l111111llll11l1l_cda_))
        l1lll1lll1ll11l1l_cda_(l1ll11l1l_cda_ (u"ࠧ࡜ࡅ࡫ࡩࡨࡱࡌࡪࡰ࡮ࡡ࠿ࠦࡓࡕࡃࡕࡘࠥࡒࡩࡣࡴࡤࡶࡾࠦࡆࡰ࡮ࡧࡩࡷࡹࠠ࠾ࠢࠨࡨࠬႋ")%len(l111111llll11l1l_cda_))
        if not l11ll1ll11l11l1l_cda_.l11l1l11l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠨ࡙࡬ࡲࡩࡵࡷ࠯ࡋࡶ࡚࡮ࡹࡩࡣ࡮ࡨࠬ࡮ࡴࡦࡰࡦ࡬ࡥࡱࡵࡧࠪࠩႌ")) and not l11ll1ll11l11l1l_cda_.l11l1l11l1l11l1l_cda_(l1ll11l1l_cda_ (u"ࠩࡓࡰࡦࡿࡥࡳ࠰ࡋࡥࡸ࡜ࡩࡥࡧࡲႍࠫ")):
            try:
                l11ll1ll11l11l1l_cda_.l11ll1lllll11l1l_cda_(l1ll11l1l_cda_ (u"ࠪࡗࡵࡸࡡࡸࡦࡽࡥࡲࠦॺࡳࣵࡧࡰࡦࠦࡢࡪࡤ࡯࡭ࡴࡺࡥ࡬࡫ࠣࡧࡩࡧ࠮ࡱ࡮ࠪႎ"), time=3)
                self.l11ll1lllll11l1l_cda_ = True
            except:
                self.l11ll1lllll11l1l_cda_ = False
        pool = l11ll11ll11l1l_cda_.ThreadPool(self.l1lllll1ll1l11l1l_cda_)
        self.res={l1ll11l1l_cda_ (u"ࠫࡨ࡮ࡥࡤ࡭ࡨࡨࠬႏ"):0,l1ll11l1l_cda_ (u"ࠬࡹ࡫ࡪࡲࡳࡩࡩ࠭႐"):0,l1ll11l1l_cda_ (u"࠭ࡲࡦ࡯ࡲࡺࡪࡪࠧ႑"):0,l1ll11l1l_cda_ (u"ࠧࡶࡲࡧࡥࡹ࡫ࡤࠨ႒"):0}
        N = len(l111111llll11l1l_cda_)
        for idx,l11111l11ll11l1l_cda_ in enumerate(l111111llll11l1l_cda_):
            pool.l1llll1l1lll11l1l_cda_(self.l1111111l1l11l1l_cda_, *(l11111l11ll11l1l_cda_,idx,N))
            time.sleep(0.1)
        pool.l1llll11l11l1l_cda_()
        l1lll1lll1ll11l1l_cda_(l1ll11l1l_cda_ (u"ࠨ࡝ࡆ࡬ࡪࡩ࡫ࡍ࡫ࡱ࡯ࡢࡀࠠࡆࡐࡇࠤࡘࡺࡡࡵࡷࡶࠤࡨ࡮ࡥࡤ࡭ࡨࡨ࠿ࠫࡤ࠭ࠢࡶ࡯࡮ࡶࡰࡦࡦ࠽ࠩࡩ࠲ࠠࡳࡧࡰࡳࡻ࡫ࡤ࠻ࠧࡧ࠰ࠥࡻࡰࡥࡣࡷࡩࡩࡀࠥࡥࠩ႓")%(self.res[l1ll11l1l_cda_ (u"ࠩࡦ࡬ࡪࡩ࡫ࡦࡦࠪ႔")],self.res[l1ll11l1l_cda_ (u"ࠪࡷࡰ࡯ࡰࡱࡧࡧࠫ႕")],self.res[l1ll11l1l_cda_ (u"ࠫࡷ࡫࡭ࡰࡸࡨࡨࠬ႖")],self.res[l1ll11l1l_cda_ (u"ࠬࡻࡰࡥࡣࡷࡩࡩ࠭႗")]))
        self.l11ll111lll11l1l_cda_.close()
        if self.l11ll1lllll11l1l_cda_ == True:
            l11ll1ll11l11l1l_cda_.l11ll1lllll11l1l_cda_(l1ll11l1l_cda_ (u"࠭ࡕࡴࡷࡱ࡭ञࡺ࡯ࠡ࠼ࠨࡨ࠱࡚ࠦࡢ࡭ࡷࡹࡦࡲࡩࡻࡱࡺࡥࡳࡵࠠ࠻ࠧࡧࠤࠬ႘")%(self.res[l1ll11l1l_cda_ (u"ࠧࡳࡧࡰࡳࡻ࡫ࡤࠨ႙")],self.res[l1ll11l1l_cda_ (u"ࠨࡷࡳࡨࡦࡺࡥࡥࠩႚ")]), time=30)
