# coding: UTF-8
import sys
l1_sy_ = sys.version_info [0] == 2
l1lll1_sy_ = 2048
l11ll_sy_ = 7
def l1l11_sy_ (ll_sy_):
	global l1llll_sy_
	l1l111_sy_ = ord (ll_sy_ [-1])
	l11l1_sy_ = ll_sy_ [:-1]
	l11_sy_ = l1l111_sy_ % len (l11l1_sy_)
	l1ll_sy_ = l11l1_sy_ [:l11_sy_] + l11l1_sy_ [l11_sy_:]
	if l1_sy_:
		l1ll1l_sy_ = unicode () .join ([unichr (ord (char) - l1lll1_sy_ - (l1l1l_sy_ + l1l111_sy_) % l11ll_sy_) for l1l1l_sy_, char in enumerate (l1ll_sy_)])
	else:
		l1ll1l_sy_ = str () .join ([chr (ord (char) - l1lll1_sy_ - (l1l1l_sy_ + l1l111_sy_) % l11ll_sy_) for l1l1l_sy_, char in enumerate (l1ll_sy_)])
	return eval (l1ll1l_sy_)