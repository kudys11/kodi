# -*- coding: utf-8 -*-
import sys
l1_sy_ = sys.version_info [0] == 2
l1lll1_sy_ = 2048
l11ll_sy_ = 7
def l1l11_sy_ (ll_sy_):
	global l1llll_sy_
	l1l111_sy_ = ord (ll_sy_ [-1])
	l11l1_sy_ = ll_sy_ [:-1]
	l11_sy_ = l1l111_sy_ % len (l11l1_sy_)
	l1ll_sy_ = l11l1_sy_ [:l11_sy_] + l11l1_sy_ [l11_sy_:]
	if l1_sy_:
		l1ll1l_sy_ = unicode () .join ([unichr (ord (char) - l1lll1_sy_ - (l1l1l_sy_ + l1l111_sy_) % l11ll_sy_) for l1l1l_sy_, char in enumerate (l1ll_sy_)])
	else:
		l1ll1l_sy_ = str () .join ([chr (ord (char) - l1lll1_sy_ - (l1l1l_sy_ + l1l111_sy_) % l11ll_sy_) for l1l1l_sy_, char in enumerate (l1ll_sy_)])
	return eval (l1ll1l_sy_)
import urllib2,urllib
import re,os
import l11llllll_sy_,cookielib
from urlparse import urlparse,urljoin
l11ll1l11_sy_=l1l11_sy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡹࡥࡳ࡫ࡤࡰࡴࡹࡹ࠯ࡲ࡯ࠫॾ")
l11ll11l1_sy_ = 10
l11lll111_sy_=l1l11_sy_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠶࠻࠲࠵࠴࠲࠶࠸࠷࠲࠾࠽ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧॿ")
l111111_sy_=l1l11_sy_ (u"ࡵࠫࠬঀ")
l11l11l11_sy_ = l1l11_sy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡵࡥࡲࡱࡡ࠯ࡲࡵࡳࡽࡿ࠮࡯ࡧࡷ࠲ࡵࡲ࠯ࡪࡰࡧࡩࡽ࠴ࡰࡩࡲࡂࡵࡂ࠭ঁ")
def _11l11ll1_sy_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l1l11_sy_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩং"), l11lll111_sy_)
    if cookies:
        req.add_header(l1l11_sy_ (u"ࠨࡃࡰࡱ࡮࡭ࡪࠨঃ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11ll11l1_sy_)
        l1111l1_sy_ = response.read()
        response.close()
    except:
        l1111l1_sy_=l1l11_sy_ (u"ࠧࠨ঄")
    return l1111l1_sy_
def l11l1l1l1_sy_(url,data=None):
    cookies=l11llllll_sy_.l1l111ll1_sy_(l111111_sy_)
    content=_11l11ll1_sy_(url,data,cookies)
    if not content:
        l1l11l11l_sy_=l11l1l111_sy_(l11ll1l11_sy_,l111111_sy_)
        cookies=l11llllll_sy_.l1l111ll1_sy_(l111111_sy_)
        content=_11l11ll1_sy_(url,data,cookies)
    return content
def l11l1l111_sy_(l1111l1_sy_,l11l1l1ll_sy_):
    l1l11l11l_sy_ = cookielib.LWPCookieJar()
    l11l1l11l_sy_ = l11llllll_sy_.l11lllll1_sy_(l1111l1_sy_,l1l11l11l_sy_,l11lll111_sy_)
    l11ll1l1l_sy_=os.path.dirname(l11l1l1ll_sy_)
    if not os.path.exists(l11ll1l1l_sy_):
        os.makedirs(l11ll1l1l_sy_)
    if l1l11l11l_sy_:
        l1l11l11l_sy_.save(l11l1l1ll_sy_, ignore_discard = True)
    return l1l11l11l_sy_
def l1llll1l_sy_(url=l1l11_sy_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡹࡥࡳ࡫ࡤࡰࡴࡹࡹ࠯ࡲ࡯ࠫঅ"),l11l1ll1l_sy_=l1l11_sy_ (u"ࠩࠪআ")):
    out=[]
    content = l11l1l1l1_sy_(url)
    l11l11lll_sy_ = re.compile(l1l11_sy_ (u"ࠪࡀࡱ࡯ࠠࡤ࡮ࡤࡷࡸࡃࠢࡴࡷࡥࡰࡳࡱࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅࠢ࠿࠾ࡥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡧࡄ࠼࠰ࡣࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄ࡜ࡴࠬ࠿࠳ࡱ࡯࠾ࠨই"),re.DOTALL).findall(content)
    for type,items in l11l11lll_sy_:
        if l11l1ll1l_sy_ in type:
            l11lll1_sy_ = re.compile(l1l11_sy_ (u"ࠫࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡀࡧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡢ࠿࠾࠲ࡥࡃࡂ࠯࡭࡫ࡁࠫঈ")).findall(items)
            for s in l11lll1_sy_:
                out.append({l1l11_sy_ (u"ࠬࡺࡩࡵ࡮ࡨࠫউ"):l11l1ll11_sy_(s[1].strip()),l1l11_sy_ (u"࠭ࡵࡳ࡮ࠪঊ"):s[0]})
            return out
    return out
def l11ll1l_sy_(url=l1l11_sy_ (u"ࠧ࠰ࡼࡤ࡫ࡷࡧ࡮ࡪࡥࡽࡲࡪ࠳ࡳࡦࡴ࡬ࡥࡱ࡫࠯ࡸࡱ࡭ࡲࡦ࠳ࡩ࠮ࡲࡲ࡯ࡴࡰ࠯ࠨঋ"),data=l1l11_sy_ (u"ࠨࡦ࡯ࡩࡳ࡫ࡷࡴࡵࡲࡶࡹࡨࡹ࠾ࡦࡤࡸࡪࠬࡤ࡭ࡧࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࡂࡪࡥࡴࡥࠩࡷࡪࡺ࡟࡯ࡧࡺࡣࡸࡵࡲࡵ࠿ࡧࡰࡪࡥࡳࡰࡴࡷࡣࡲࡧࡩ࡯ࠨࡶࡩࡹࡥࡤࡪࡴࡨࡧࡹ࡯࡯࡯ࡡࡶࡳࡷࡺ࠽ࡥ࡮ࡨࡣࡩ࡯ࡲࡦࡥࡷ࡭ࡴࡴ࡟࡮ࡣ࡬ࡲࠬঌ")):
    if not url.startswith(l1l11_sy_ (u"ࠩ࡫ࡸࡹࡶࠧ঍")):
        if url[0]==l1l11_sy_ (u"ࠪ࠳ࠬ঎"): url = l11ll1l11_sy_+urllib2.quote(url)
        else: url = urljoin(l11ll1l11_sy_,url)
    out=[]
    content = l11l1l1l1_sy_(url,data)
    l11l111l1_sy_ = [(a.start(), a.end()) for a in re.finditer(l1l11_sy_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡥࡥࡸ࡫ࠠࡴࡪࡲࡶࡹࡹࡴࡰࡴࡼࠦࡃ࠭এ"), content)]
    l11l111l1_sy_.append( (-1,-1) )
    out=[]
    for i in range(len(l11l111l1_sy_[:-1])):
        l11ll1lll_sy_ = content[ l11l111l1_sy_[i][1]:l11l111l1_sy_[i+1][0] ]
        href = re.compile(l1l11_sy_ (u"ࠬࡂࡨ࠴ࠢࡦࡰࡦࡹࡳ࠾ࠤࡥࡸࡱࠨ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࡁ࠵ࡨ࠴ࡀࠪঐ"),re.DOTALL).findall(l11ll1lll_sy_)
        info = re.compile(l1l11_sy_ (u"࠭࠼ࡱࠢࡦࡰࡦࡹࡳ࠾ࠤࡥ࡭ࡳ࡬࡯ࠡࡵࡰࡥࡱࡲࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣ࠰࠭ࡃࠧࡢࡳࠫࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡵࡄࠧ঑")).findall(l11ll1lll_sy_)
        info = l1l11_sy_ (u"ࠧࠨ঒").join(info[0])+l1l11_sy_ (u"ࠨ࡞ࡱࠫও") if info else l1l11_sy_ (u"ࠩࠪঔ")
        l11l1lll1_sy_ = re.compile(l1l11_sy_ (u"ࠪࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ক")).findall(l11ll1lll_sy_)
        l11ll1111_sy_ = re.compile(l1l11_sy_ (u"ࠫࡁࡲࡥࡧࡶࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰࡪ࡬ࡴ࠿ࠩখ")).findall(l11ll1lll_sy_)
        l11ll1111_sy_ = info+ l11ll1111_sy_[0] if l11ll1111_sy_ else l1l11_sy_ (u"ࠬ࠭গ")
        if href and info and l11l1lll1_sy_:
            h = href[0][0]
            t = href[0][1]
            i = l11l1lll1_sy_[0]
            out.append({l1l11_sy_ (u"࠭ࡴࡪࡶ࡯ࡩࠬঘ"):l11l1ll11_sy_(t),l1l11_sy_ (u"ࠧࡶࡴ࡯ࠫঙ"):h,l1l11_sy_ (u"ࠨ࡫ࡰ࡫ࠬচ"):i,l1l11_sy_ (u"ࠩࡳࡰࡴࡺࠧছ"):l11ll1111_sy_})
    l11ll11ll_sy_ = re.compile(l1l11_sy_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃࡂࡳࡱࡣࡱࠤࡨࡲࡡࡴࡵࡀࠦࡹ࡮ࡩࡥࡧࠣࡴࡵࡸࡥࡷࠤࡁ࡛ࡸࡺࡥࡤࡼ࠿࠳ࡸࡶࡡ࡯ࡀ࠿࠳ࡦࡄࠧজ")).search(content)
    l11ll11ll_sy_ = l11ll11ll_sy_.group(1) if l11ll11ll_sy_ else False
    l11l11l1l_sy_ = re.compile(l1l11_sy_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄ࠼ࡴࡲࡤࡲࠥࡩ࡬ࡢࡵࡶࡁࠧࡺࡨࡪࡦࡨࠤࡵࡴࡥࡹࡶࠥࡂࡉࡧ࡬ࡦ࡬࠿࠳ࡸࡶࡡ࡯ࡀ࠿࠳ࡦࡄࠧঝ")).search(content)
    l11l11l1l_sy_ = l11l11l1l_sy_.group(1) if l11l11l1l_sy_ else False
    if not out:
        out.append({l1l11_sy_ (u"ࠬࡺࡩࡵ࡮ࡨࠫঞ"):l1l11_sy_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠࡆࡷࡧ࡫ࠡࡣࡵࡸࡾࡱࡵृࣵࡺࠤࡱࡻࡢࠡࡰ࡬ࡩࠥࡳࡡࡴࡼࠣࡨࡴࡹࡴचࡲࡸࠤࡩࡵࠠࡪࡥ࡫ࠤࡴ࡭࡬आࡦࡤࡲ࡮ࡧ࠮࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩট"),l1l11_sy_ (u"ࠧࡶࡴ࡯ࠫঠ"):l1l11_sy_ (u"ࠨࠩড"),l1l11_sy_ (u"ࠩ࡬ࡱ࡬࠭ঢ"):l1l11_sy_ (u"ࠪࠫণ"),l1l11_sy_ (u"ࠫࡵࡲ࡯ࡵࠩত"):l1l11_sy_ (u"ࠬ࠭থ")})
        l11ll11ll_sy_ = False
        l11l11l1l_sy_ = False
    return out,(l11ll11ll_sy_,l11l11l1l_sy_)
def l1lll1l1_sy_(url=l1l11_sy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡷࡪࡸࡩࡢ࡮ࡲࡷࡾ࠴ࡰ࡭࠱ࡽࡥ࡬ࡸࡡ࡯࡫ࡦࡾࡳ࡫࠭ࡴࡧࡵ࡭ࡦࡲࡥ࠺࠱ࡲࡷࡹࡧࡴ࡯࡫࠰ࡳࡰࡸࡥࡵ࠯ࡷ࡬ࡪ࠳࡬ࡢࡵࡷ࠱ࡸ࡮ࡩࡱ࠱࠴࠷࠷࠶࠹࠮ࡱࡶࡸࡦࡺ࡮ࡪ࠯ࡲ࡯ࡷ࡫ࡴ࠮ࡶ࡫ࡩ࠲ࡲࡡࡴࡶ࠰ࡷ࡭࡯ࡰ࠮ࡵ࠳࠸ࡪ࠶࠶࠮ࡧࡱ࡫࠳࡮ࡴ࡮࡮ࠪদ")):
    content = l11l1l1l1_sy_(url)
    l11ll1ll1_sy_=[]
    l11l1llll_sy_ = re.compile(l1l11_sy_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠩ࠰࠭ࡃ࠮ࡂ࠯ࡪࡨࡵࡥࡲ࡫࠾ࠨধ"),re.DOTALL|re.IGNORECASE).findall(content)
    for l11l111ll_sy_ in l11l1llll_sy_:
        src = re.compile(l1l11_sy_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ন"),re.DOTALL|re.IGNORECASE).findall(l11l111ll_sy_)
        if src:
            host = urlparse(src[0]).netloc
            l11ll1ll1_sy_.append({l1l11_sy_ (u"ࠩࡸࡶࡱ࠭঩"):src[0],l1l11_sy_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩপ"):host})
    return l11ll1ll1_sy_
def l11l1ll11_sy_(l11ll111l_sy_):
    l11ll111l_sy_ = l11ll111l_sy_.replace(l1l11_sy_ (u"ࠫࠫࡲࡴ࠼ࡤࡵ࠳ࠫ࡭ࡴ࠼ࠩফ"),l1l11_sy_ (u"ࠬࠦࠧব"))
    l11ll111l_sy_ = l11ll111l_sy_.replace(l1l11_sy_ (u"࠭ࠦࡲࡷࡲࡸࡀ࠭ভ"),l1l11_sy_ (u"ࠧࠣࠩম")).replace(l1l11_sy_ (u"ࠨࠨࡤࡱࡵࡁࡱࡶࡱࡷ࠿ࠬয"),l1l11_sy_ (u"ࠩࠥࠫর"))
    l11ll111l_sy_ = l11ll111l_sy_.replace(l1l11_sy_ (u"ࠪࠪࡴࡧࡣࡶࡶࡨ࠿ࠬ঱"),l1l11_sy_ (u"ࠫࣸ࠭ল")).replace(l1l11_sy_ (u"ࠬࠬࡏࡢࡥࡸࡸࡪࡁࠧ঳"),l1l11_sy_ (u"࣓࠭ࠨ঴"))
    l11ll111l_sy_ = l11ll111l_sy_.replace(l1l11_sy_ (u"ࠧࠧࡣࡰࡴࡀࡵࡡࡤࡷࡷࡩࡀ࠭঵"),l1l11_sy_ (u"ࠨࣵࠪশ")).replace(l1l11_sy_ (u"ࠩࠩࡥࡲࡶ࠻ࡐࡣࡦࡹࡹ࡫࠻ࠨষ"),l1l11_sy_ (u"ࠪࣗࠬস"))
    l11ll111l_sy_ = l11ll111l_sy_.replace(l1l11_sy_ (u"ࠫࠫࡧ࡭ࡱ࠽ࠪহ"),l1l11_sy_ (u"ࠬࠬࠧ঺"))
    l11ll111l_sy_ = l11ll111l_sy_.replace(l1l11_sy_ (u"࠭࡜ࡶ࠲࠴࠴࠺࠭঻"),l1l11_sy_ (u"ࠧआ়ࠩ")).replace(l1l11_sy_ (u"ࠨ࡞ࡸ࠴࠶࠶࠴ࠨঽ"),l1l11_sy_ (u"ࠩइࠫা"))
    l11ll111l_sy_ = l11ll111l_sy_.replace(l1l11_sy_ (u"ࠪࡠࡺ࠶࠱࠱࠹ࠪি"),l1l11_sy_ (u"ࠫऌ࠭ী")).replace(l1l11_sy_ (u"ࠬࡢࡵ࠱࠳࠳࠺ࠬু"),l1l11_sy_ (u"࠭आࠨূ"))
    l11ll111l_sy_ = l11ll111l_sy_.replace(l1l11_sy_ (u"ࠧ࡝ࡷ࠳࠵࠶࠿ࠧৃ"),l1l11_sy_ (u"ࠨछࠪৄ")).replace(l1l11_sy_ (u"ࠩ࡟ࡹ࠵࠷࠱࠹ࠩ৅"),l1l11_sy_ (u"ࠪजࠬ৆"))
    l11ll111l_sy_ = l11ll111l_sy_.replace(l1l11_sy_ (u"ࠫࡡࡻ࠰࠲࠶࠵ࠫে"),l1l11_sy_ (u"ࠬैࠧৈ")).replace(l1l11_sy_ (u"࠭࡜ࡶ࠲࠴࠸࠶࠭৉"),l1l11_sy_ (u"ࠧूࠩ৊"))
    l11ll111l_sy_ = l11ll111l_sy_.replace(l1l11_sy_ (u"ࠨ࡞ࡸ࠴࠶࠺࠴ࠨো"),l1l11_sy_ (u"ࠩेࠫৌ")).replace(l1l11_sy_ (u"ࠪࡠࡺ࠶࠱࠵࠶্ࠪ"),l1l11_sy_ (u"ࠫै࠭ৎ"))
    l11ll111l_sy_ = l11ll111l_sy_.replace(l1l11_sy_ (u"ࠬࡢࡵ࠱࠲ࡩ࠷ࠬ৏"),l1l11_sy_ (u"࠭ࣳࠨ৐")).replace(l1l11_sy_ (u"ࠧ࡝ࡷ࠳࠴ࡩ࠹ࠧ৑"),l1l11_sy_ (u"ࠨࣕࠪ৒"))
    l11ll111l_sy_ = l11ll111l_sy_.replace(l1l11_sy_ (u"ࠩ࡟ࡹ࠵࠷࠵ࡣࠩ৓"),l1l11_sy_ (u"ࠪय़ࠬ৔")).replace(l1l11_sy_ (u"ࠫࡡࡻ࠰࠲࠷ࡤࠫ৕"),l1l11_sy_ (u"ࠬॠࠧ৖"))
    l11ll111l_sy_ = l11ll111l_sy_.replace(l1l11_sy_ (u"࠭࡜ࡶ࠲࠴࠻ࡦ࠭ৗ"),l1l11_sy_ (u"ࠧॻࠩ৘")).replace(l1l11_sy_ (u"ࠨ࡞ࡸ࠴࠶࠽࠹ࠨ৙"),l1l11_sy_ (u"ࠩॼࠫ৚"))
    l11ll111l_sy_ = l11ll111l_sy_.replace(l1l11_sy_ (u"ࠪࡠࡺ࠶࠱࠸ࡥࠪ৛"),l1l11_sy_ (u"ࠫঁ࠭ড়")).replace(l1l11_sy_ (u"ࠬࡢࡵ࠱࠳࠺ࡦࠬঢ়"),l1l11_sy_ (u"࠭ॻࠨ৞"))
    return l11ll111l_sy_
