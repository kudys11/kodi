# coding: UTF-8
import sys
l1_sy_ = sys.version_info [0] == 2
l1lll1_sy_ = 2048
l11ll_sy_ = 7
def l1l11_sy_ (ll_sy_):
	global l1llll_sy_
	l1l111_sy_ = ord (ll_sy_ [-1])
	l11l1_sy_ = ll_sy_ [:-1]
	l11_sy_ = l1l111_sy_ % len (l11l1_sy_)
	l1ll_sy_ = l11l1_sy_ [:l11_sy_] + l11l1_sy_ [l11_sy_:]
	if l1_sy_:
		l1ll1l_sy_ = unicode () .join ([unichr (ord (char) - l1lll1_sy_ - (l1l1l_sy_ + l1l111_sy_) % l11ll_sy_) for l1l1l_sy_, char in enumerate (l1ll_sy_)])
	else:
		l1ll1l_sy_ = str () .join ([chr (ord (char) - l1lll1_sy_ - (l1l1l_sy_ + l1l111_sy_) % l11ll_sy_) for l1l1l_sy_, char in enumerate (l1ll_sy_)])
	return eval (l1ll1l_sy_)
import urlparse,cookielib,urllib2,urllib
import time,re,os
url=l1l11_sy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡷࡪࡸࡩࡢ࡮ࡲࡷࡾ࠴ࡰ࡭࠱ࠪॠ")
l1l11l11l_sy_= cookielib.LWPCookieJar()
l11lll111_sy_=l1l11_sy_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ॡ")
def l11lllll1_sy_(url,l1l11l11l_sy_=l1l11l11l_sy_,l1l1111ll_sy_=l11lll111_sy_):
    l11lll1l1_sy_=l1l11_sy_ (u"ࠨࠩॢ")
    try:
        class l1l111111_sy_(urllib2.HTTPErrorProcessor):
            def http_response(self, request, response):
                return response
        def l11lll1ll_sy_(s):
            try:
                offset=1 if s[0]==l1l11_sy_ (u"ࠩ࠮ࠫॣ") else 0
                val = int(eval(s.replace(l1l11_sy_ (u"ࠪࠥ࠰ࡡ࡝ࠨ।"),l1l11_sy_ (u"ࠫ࠶࠭॥")).replace(l1l11_sy_ (u"ࠬࠧࠡ࡜࡟ࠪ०"),l1l11_sy_ (u"࠭࠱ࠨ१")).replace(l1l11_sy_ (u"ࠧ࡜࡟ࠪ२"),l1l11_sy_ (u"ࠨ࠲ࠪ३")).replace(l1l11_sy_ (u"ࠩࠫࠫ४"),l1l11_sy_ (u"ࠪࡷࡹࡸࠨࠨ५"))[offset:]))
                return val
            except:
                pass
        if l1l11l11l_sy_==None:
            l1l11l11l_sy_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(l1l111111_sy_, urllib2.HTTPCookieProcessor(l1l11l11l_sy_))
        opener.addheaders = [(l1l11_sy_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ६"), l1l1111ll_sy_)]
        try:
            response = opener.open(url)
            result=l11lll1l1_sy_ = response.read()
            response.close()
        except urllib2.HTTPError as e:
            result=l11lll1l1_sy_ = e.read()
        l1l11l111_sy_ = re.compile(l1l11_sy_ (u"ࠬࡴࡡ࡮ࡧࡀࠦ࡯ࡹࡣࡩ࡮ࡢࡺࡨࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠮ࡃ࠮ࠨ࠯࠿ࠩ७")).findall(result)[0]
        init = re.compile(l1l11_sy_ (u"࠭ࡳࡦࡶࡗ࡭ࡲ࡫࡯ࡶࡶ࡟ࠬ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࡢࠨ࡝ࠫࡾࡠࡸ࠰࠮ࠫࡁ࠱࠮࠿࠮࠮ࠫࡁࠬࢁࡀ࠭८")).findall(result)[0]
        l1l111lll_sy_ = re.compile(l1l11_sy_ (u"ࡲࠣࡥ࡫ࡥࡱࡲࡥ࡯ࡩࡨ࠱࡫ࡵࡲ࡮࡞ࠪࡠ࠮ࡁ࡜ࡴࠬࠫ࠲࠯࠯ࡡ࠯ࡸࠥ९")).findall(result)[0]
        l1l111l11_sy_ = l11lll1ll_sy_(init)
        lines = l1l111lll_sy_.split(l1l11_sy_ (u"ࠨ࠽ࠪ॰"))
        if l1l11l111_sy_:
            for line in lines:
                if len(line)>0 and l1l11_sy_ (u"ࠩࡀࠫॱ") in line:
                    l1l111l1l_sy_=line.split(l1l11_sy_ (u"ࠪࡁࠬॲ"))
                    l11lll11l_sy_ = l11lll1ll_sy_(l1l111l1l_sy_[1])
                    l1l111l11_sy_ = int(eval(str(l1l111l11_sy_)+l1l111l1l_sy_[0][-1]+str(l11lll11l_sy_)))
            l11llll1l_sy_ = l1l111l11_sy_ + len(urlparse.urlparse(url).netloc)
            u=l1l11_sy_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡵࡨࡶ࡮ࡧ࡬ࡰࡵࡼ࠲ࡵࡲࠧॳ")
            query = l1l11_sy_ (u"ࠬࠫࡳ࠰ࡥࡧࡲ࠲ࡩࡧࡪ࠱࡯࠳ࡨ࡮࡫ࡠ࡬ࡶࡧ࡭ࡲ࠿࡫ࡵࡦ࡬ࡱࡥࡶࡤ࠿ࠨࡷࠫࡰࡳࡤࡪ࡯ࡣࡦࡴࡳࡸࡧࡵࡁࠪࡹࠧॴ") % (u, l1l11l111_sy_, l11llll1l_sy_)
            if l1l11_sy_ (u"࠭ࡴࡺࡲࡨࡁࠧ࡮ࡩࡥࡦࡨࡲࠧࠦ࡮ࡢ࡯ࡨࡁࠧࡶࡡࡴࡵࠥࠫॵ") in result:
                l1l1111l1_sy_=re.compile(l1l11_sy_ (u"ࠧ࡯ࡣࡰࡩࡂࠨࡰࡢࡵࡶࠦࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬॶ")).findall(result)[0]
                query = l1l11_sy_ (u"ࠨࠧࡶ࠳ࡨࡪ࡮࠮ࡥࡪ࡭࠴ࡲ࠯ࡤࡪ࡮ࡣ࡯ࡹࡣࡩ࡮ࡂࡴࡦࡹࡳ࠾ࠧࡶࠪ࡯ࡹࡣࡩ࡮ࡢࡺࡨࡃࠥࡴࠨ࡭ࡷࡨ࡮࡬ࡠࡣࡱࡷࡼ࡫ࡲ࠾ࠧࡶࠫॷ") % (u,urllib.quote_plus(l1l1111l1_sy_), l1l11l111_sy_, l11llll1l_sy_)
                time.sleep(5)
            l11llll11_sy_ =l1l11_sy_ (u"ࠩࠪॸ").join([l1l11_sy_ (u"ࠪࠩࡸࡃࠥࡴ࠽ࠪॹ")%(c.name, c.value) for c in l1l11l11l_sy_])
            opener = urllib2.build_opener(l1l111111_sy_,urllib2.HTTPCookieProcessor(l1l11l11l_sy_))
            opener.addheaders = [(l1l11_sy_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨॺ"), l1l1111ll_sy_)]
            opener.addheaders.append((l1l11_sy_ (u"ࠬࡩ࡯ࡰ࡭࡬ࡩࠬॻ"),l11llll11_sy_))
            try:
                response = opener.open(query)
                response.close()
            except urllib2.HTTPError as e:
                response = e.read()
        return l1l11l11l_sy_
    except:
        return None
def l1l111ll1_sy_(l111111_sy_):
    l1l11111l_sy_=l1l11_sy_ (u"࠭ࠧॼ")
    if os.path.isfile(l111111_sy_):
        l1l11l11l_sy_ = cookielib.LWPCookieJar()
        l1l11l11l_sy_.load(l111111_sy_)
        for c in l1l11l11l_sy_:
            l1l11111l_sy_+=l1l11_sy_ (u"ࠧࠦࡵࡀࠩࡸࡁࠧॽ")%(c.name, c.value)
    return l1l11111l_sy_
