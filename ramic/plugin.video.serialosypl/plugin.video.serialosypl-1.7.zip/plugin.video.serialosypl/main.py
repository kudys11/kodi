# -*- coding: utf-8 -*-
import sys
l1_sy_ = sys.version_info [0] == 2
l1lll1_sy_ = 2048
l11ll_sy_ = 7
def l1l11_sy_ (ll_sy_):
	global l1llll_sy_
	l1l111_sy_ = ord (ll_sy_ [-1])
	l11l1_sy_ = ll_sy_ [:-1]
	l11_sy_ = l1l111_sy_ % len (l11l1_sy_)
	l1ll_sy_ = l11l1_sy_ [:l11_sy_] + l11l1_sy_ [l11_sy_:]
	if l1_sy_:
		l1ll1l_sy_ = unicode () .join ([unichr (ord (char) - l1lll1_sy_ - (l1l1l_sy_ + l1l111_sy_) % l11ll_sy_) for l1l1l_sy_, char in enumerate (l1ll_sy_)])
	else:
		l1ll1l_sy_ = str () .join ([chr (ord (char) - l1lll1_sy_ - (l1l1l_sy_ + l1l111_sy_) % l11ll_sy_) for l1l1l_sy_, char in enumerate (l1ll_sy_)])
	return eval (l1ll1l_sy_)
import sys,re,os,time
import urllib,urllib2
import urlparse
import check
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
l1lllll_sy_        = sys.argv[0]
l111l11_sy_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l1ll1lll_sy_        = xbmcaddon.Addon()
l111ll_sy_       = l1ll1lll_sy_.getAddonInfo(l1l11_sy_ (u"ࠫࡳࡧ࡭ࡦࠩࠪ"))
PATH            = l1ll1lll_sy_.getAddonInfo(l1l11_sy_ (u"ࠬࡶࡡࡵࡪࠪࠫ"))
l1l1l11_sy_        = xbmc.translatePath(l1ll1lll_sy_.getAddonInfo(l1l11_sy_ (u"࠭ࡰࡳࡱࡩ࡭ࡱ࡫ࠧࠬ"))).decode(l1l11_sy_ (u"ࠧࡶࡶࡩ࠱࠽࠭࠭"))
l1lllll1_sy_       = PATH+l1l11_sy_ (u"ࠨ࠱ࡵࡩࡸࡵࡵࡳࡥࡨࡷ࠴࠭࠮")
l1lll1ll_sy_=l1l11_sy_ (u"ࠩࠪ࠯")
import resources.lib.l11l1l1_sy_ as l11l1l1_sy_
l11l1l1_sy_.l111111_sy_=os.path.join(l1l1l11_sy_,l1l11_sy_ (u"ࠪࡱࡾ࠴ࡣࡰࡱ࡮࡭ࡪ࠭࠰"))
import ramic as l1lll11_sy_
try: from shutil import rmtree
except: rmtree = False
def l1l_sy_(l11lll_sy_,l11l_sy_=[l1l11_sy_ (u"ࠫࠬ࠱")]):
    debug=1
def l1111_sy_(name=l1l11_sy_ (u"ࠬ࠭࠲")):
    debug=1
def l111_sy_(top):
    debug=1
def l1l1lll_sy_():
    l11lll_sy_ = os.path.join(xbmc.translatePath(l1l11_sy_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴࡮࡯࡮ࡧࠪ࠽")),l1l11_sy_ (u"ࠪࡥࡩࡪ࡯࡯ࡵࠪ࠾"))
    debug=1
    l1l11l_sy_ = os.path.join(xbmc.translatePath(l1l11_sy_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡹࡸ࡫ࡲࡥࡣࡷࡥࠬࡂ")),l1l11_sy_ (u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬࡃ"),l1l11_sy_ (u"ࠩࡶ࡯࡮ࡴ࠮ࡢࡧࡲࡲ࠳ࡴ࡯ࡹ࠰࠸ࠫࡄ"),l1l11_sy_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩࡅ"))
    debug=1
    l1l11l_sy_ = os.path.join(xbmc.translatePath(l1l11_sy_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡶࡵࡨࡶࡩࡧࡴࡢࠩࡍ")),l1l11_sy_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩࡎ"),l1l11_sy_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡽࡵ࡮ࡧ࡮ࡸࡩࡳࡩࡥࠨࡏ"),l1l11_sy_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭ࡐ"))
    debug=1
    l11lll_sy_ = os.path.join(xbmc.translatePath(l1l11_sy_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡸࡷࡪࡸࡤࡢࡶࡤࠫࡖ")),l1l11_sy_ (u"ࠧࡱࡴࡲࡪ࡮ࡲࡥࡴࠩࡗ"))
    l1l1_sy_ = xbmc.translatePath(l1l11_sy_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩࡘ"))
    debug=1
try:
    debug=1
except: pass
def l111lll_sy_(name, url, mode, params={}, l1ll111_sy_=l1l11_sy_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠨ࡛"), infoLabels=False, isFolder=False, IsPlayable=True,fanart=l1lll1ll_sy_,l11ll11_sy_=1):
    u = l1111l_sy_({l1l11_sy_ (u"ࠬࡳ࡯ࡥࡧࠪ࡜"): mode, l1l11_sy_ (u"࠭ࡦࡰ࡮ࡧࡩࡷࡴࡡ࡮ࡧࠪ࡝"): name, l1l11_sy_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨ࡞") : url, l1l11_sy_ (u"ࠨࡲࡤࡶࡦࡳࡳࠨ࡟"):params})
    l11l1ll_sy_ = xbmcgui.ListItem(name)
    l1ll11ll_sy_=[l1l11_sy_ (u"ࠩࡷ࡬ࡺࡳࡢࠨࡠ"),l1l11_sy_ (u"ࠪࡴࡴࡹࡴࡦࡴࠪࡡ"),l1l11_sy_ (u"ࠫࡧࡧ࡮࡯ࡧࡵࠫࡢ"),l1l11_sy_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࠬࡣ"),l1l11_sy_ (u"࠭ࡣ࡭ࡧࡤࡶࡦࡸࡴࠨࡤ"),l1l11_sy_ (u"ࠧࡤ࡮ࡨࡥࡷࡲ࡯ࡨࡱࠪࡥ"),l1l11_sy_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫࡦ"),l1l11_sy_ (u"ࠩ࡬ࡧࡴࡴࠧࡧ")]
    l11l11_sy_ = dict(zip(l1ll11ll_sy_,[l1ll111_sy_ for x in l1ll11ll_sy_]))
    l11l11_sy_[l1l11_sy_ (u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭ࡨ")] = fanart if fanart else l11l11_sy_[l1l11_sy_ (u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫ࠧࡩ")]
    l11l11_sy_[l1l11_sy_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࠬࡪ")] = fanart if fanart else l11l11_sy_[l1l11_sy_ (u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦࠩ࡫")]
    l11l1ll_sy_.setArt(l11l11_sy_)
    if not infoLabels:
        infoLabels={l1l11_sy_ (u"ࠢࡵ࡫ࡷࡰࡪࠨ࡬"): name}
    l11l1ll_sy_.setInfo(type=l1l11_sy_ (u"ࠣࡸ࡬ࡨࡪࡵࠢ࡭"), infoLabels=infoLabels)
    if IsPlayable:
        l11l1ll_sy_.setProperty(l1l11_sy_ (u"ࠩࡌࡷࡕࡲࡡࡺࡣࡥࡰࡪ࠭࡮"), l1l11_sy_ (u"ࠪࡸࡷࡻࡥࠨ࡯"))
    l11ll1_sy_ = []
    l11ll1_sy_.append((l1l11_sy_ (u"ࠫࡎࡴࡦࡰࡴࡰࡥࡨࡰࡡࠨࡰ"), l1l11_sy_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡅࡨࡺࡩࡰࡰࠫࡍࡳ࡬࡯ࠪࠩࡱ")))
    l11l1ll_sy_.addContextMenuItems(l11ll1_sy_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l111l11_sy_, url=u, listitem=l11l1ll_sy_, isFolder=isFolder,totalItems=l11ll11_sy_)
    xbmcplugin.addSortMethod(l111l11_sy_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1l11_sy_ (u"ࠨࠥࡓ࠮ࠣࠩ࡞࠲ࠠࠦࡒࠥࡲ"))
    return ok
def l1l111l_sy_(name,ex_link=None, params={}, mode=l1l11_sy_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧࡳ"),iconImage=l1l11_sy_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬࡴ"), infoLabels=None, fanart=l1lll1ll_sy_,contextmenu=None):
    url = l1111l_sy_({l1l11_sy_ (u"ࠩࡰࡳࡩ࡫ࠧࡵ"): mode, l1l11_sy_ (u"ࠪࡪࡴࡲࡤࡦࡴࡱࡥࡲ࡫ࠧࡶ"): name, l1l11_sy_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬࡷ") : ex_link, l1l11_sy_ (u"ࠬࡶࡡࡳࡣࡰࡷࠬࡸ") : params})
    l1l11l1_sy_ = xbmcgui.ListItem(name)
    if infoLabels:
        l1l11l1_sy_.setInfo(type=l1l11_sy_ (u"ࠨࡶࡪࡦࡨࡳࠧࡹ"), infoLabels=infoLabels)
    l1ll11ll_sy_=[l1l11_sy_ (u"ࠧࡵࡪࡸࡱࡧ࠭ࡺ"),l1l11_sy_ (u"ࠨࡲࡲࡷࡹ࡫ࡲࠨࡻ"),l1l11_sy_ (u"ࠩࡥࡥࡳࡴࡥࡳࠩࡼ"),l1l11_sy_ (u"ࠪࡪࡦࡴࡡࡳࡶࠪࡽ"),l1l11_sy_ (u"ࠫࡨࡲࡥࡢࡴࡤࡶࡹ࠭ࡾ"),l1l11_sy_ (u"ࠬࡩ࡬ࡦࡣࡵࡰࡴ࡭࡯ࠨࡿ"),l1l11_sy_ (u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦࠩࢀ"),l1l11_sy_ (u"ࠧࡪࡥࡲࡲࠬࢁ")]
    l11l11_sy_ = dict(zip(l1ll11ll_sy_,[iconImage for x in l1ll11ll_sy_]))
    l11l11_sy_[l1l11_sy_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫࢂ")] = fanart if fanart else l11l11_sy_[l1l11_sy_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬࢃ")]
    l11l11_sy_[l1l11_sy_ (u"ࠪࡪࡦࡴࡡࡳࡶࠪࢄ")] = fanart if fanart else l11l11_sy_[l1l11_sy_ (u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫ࠧࢅ")]
    l1l11l1_sy_.setArt(l11l11_sy_)
    if contextmenu:
        l11ll1_sy_=contextmenu
        l1l11l1_sy_.addContextMenuItems(l11ll1_sy_, replaceItems=True)
    else:
        l11ll1_sy_ = []
        l11ll1_sy_.append((l1l11_sy_ (u"ࠬࡏ࡮ࡧࡱࡵࡱࡦࡩࡪࡢࠩࢆ"), l1l11_sy_ (u"࠭ࡘࡃࡏࡆ࠲ࡆࡩࡴࡪࡱࡱࠬࡎࡴࡦࡰࠫࠪࢇ")),)
        l1l11l1_sy_.addContextMenuItems(l11ll1_sy_, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=l111l11_sy_, url=url,listitem=l1l11l1_sy_, isFolder=True)
    xbmcplugin.addSortMethod(l111l11_sy_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1l11_sy_ (u"ࠢࠦࡔ࠯ࠤࠪ࡟ࠬࠡࠧࡓࠦ࢈"))
def l1l1ll1_sy_(l11111l_sy_):
    l1llllll_sy_ = {}
    for k, v in l11111l_sy_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l1l11_sy_ (u"ࠨࡷࡷࡪ࠽࠭ࢉ"))
        elif isinstance(v, str):
            v.decode(l1l11_sy_ (u"ࠩࡸࡸ࡫࠾ࠧࢊ"))
        l1llllll_sy_[k] = v
    return l1llllll_sy_
def l1111l_sy_(query):
    return l1lllll_sy_ + l1l11_sy_ (u"ࠪࡃࠬࢋ") + urllib.urlencode(l1l1ll1_sy_(query))
def l1lll111_sy_(ex_link,data):
    l1l1111_sy_,l1llll11_sy_ = l11l1l1_sy_.l11ll1l_sy_(ex_link,data)
    if l1llll11_sy_[0]:
        l111lll_sy_(name=l1l11_sy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟࠿ࡀࠥࡖ࡯ࡱࡴࡽࡩࡩࡴࡩࡢࠢࡶࡸࡷࡵ࡮ࡢࠢ࠿ࡀࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢌ"), url=l1llll11_sy_[0], params={}, mode=l1l11_sy_ (u"ࠬࡶࡡࡨࡧ࠽࡫ࡪࡺࡃࡰࡰࡷࡩࡳࡺࠧࢍ"), IsPlayable=False)
    items=len(l1l1111_sy_)
    for f in l1l1111_sy_:
        l111lll_sy_(name=f.get(l1l11_sy_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࢎ")), url=f.get(l1l11_sy_ (u"ࠧࡶࡴ࡯ࠫ࢏"),l1l11_sy_ (u"ࠨࠩ࢐")), mode=l1l11_sy_ (u"ࠩࡪࡩࡹࡒࡩ࡯࡭ࡶࠫ࢑"), l1ll111_sy_=f.get(l1l11_sy_ (u"ࠪ࡭ࡲ࡭ࠧ࢒")), infoLabels=f, isFolder=False, IsPlayable=True,l11ll11_sy_=items)
    if l1llll11_sy_[1]:
        l111lll_sy_(name=l1l11_sy_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟ࡁࡂࠥࡔࡡࡴࡶजࡴࡳࡧࠠࡴࡶࡵࡳࡳࡧࠠ࠿ࡀ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࢓"), url=l1llll11_sy_[1], params={}, mode=l1l11_sy_ (u"ࠬࡶࡡࡨࡧ࠽࡫ࡪࡺࡃࡰࡰࡷࡩࡳࡺࠧ࢔"), IsPlayable=False)
    xbmcplugin.setContent(l111l11_sy_, l1l11_sy_ (u"࠭ࡴࡷࡵ࡫ࡳࡼࡹࠧ࢕"))
def l1ll11l_sy_(l1111l1_sy_):
    l1ll1ll1_sy_=l1l11_sy_ (u"ࠧࠨ࢖")
    l1ll1ll1_sy_=l1lll11_sy_.__mysolver__.go(l1111l1_sy_)
    if not l1ll1ll1_sy_:
        try:
            import urlresolver
            l1ll1ll1_sy_ = urlresolver.resolve(l1111l1_sy_)
        except Exception,e:
            l1ll1ll1_sy_=l1l11_sy_ (u"ࠨࠩࢗ")
    return l1ll1ll1_sy_
l1llll1_sy_ = lambda x,y: ord(x)+4*y if ord(x)%2 else ord(x)
l111l1_sy_ = lambda l1lll1l_sy_: l1l11_sy_ (u"ࠩࠪ࢘").join([chr(l1llll1_sy_(x,1) ) for x in l1lll1l_sy_.encode(l1l11_sy_ (u"ࠪࡦࡦࡹࡥ࠷࠶࢙ࠪ")).strip()])
l1ll1l1l_sy_ = lambda l1lll1l_sy_: l1l11_sy_ (u"࢚ࠫࠬ").join([chr(l1llll1_sy_(x,-1) ) for x in l1lll1l_sy_]).decode(l1l11_sy_ (u"ࠬࡨࡡࡴࡧ࠹࠸࢛ࠬ"))
if not os.path.exists(l1l11_sy_ (u"࠭࠯ࡩࡱࡰࡩ࠴ࡵࡳ࡮ࡥࠪ࢜")):
    tm=time.gmtime()
    try:    l1l11ll_sy_,l1111ll_sy_,l1l1l1l_sy_ = l1ll1l1l_sy_(l1ll1lll_sy_.getSetting(l1l11_sy_ (u"ࠧ࡬ࡱࡧࠫ࢝"))).split(l1l11_sy_ (u"ࠨ࠼ࠪ࢞"))
    except: l1l11ll_sy_,l1111ll_sy_,l1l1l1l_sy_ =  [l1l11_sy_ (u"ࠩ࠰࠵ࠬ࢟"),l1l11_sy_ (u"ࠪࠫࢠ"),l1l11_sy_ (u"ࠫ࠲࠷ࠧࢡ")]
    if int(l1l11ll_sy_) != tm.tm_hour:
        try:    l111ll1_sy_ = re.findall(l1l11_sy_ (u"ࠬࡑࡏࡅ࠼ࠣࠬ࠳࠰࠿ࠪ࡞ࡱࠫࢢ"),urllib2.urlopen(l1l11_sy_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡳࡣࡺ࠲࡬࡯ࡴࡩࡷࡥࡹࡸ࡫ࡲࡤࡱࡱࡸࡪࡴࡴ࠯ࡥࡲࡱ࠴ࡸࡡ࡮࡫ࡦࡷࡵࡧ࠯࡬ࡱࡧ࡭࠴ࡳࡡࡴࡶࡨࡶ࠴ࡘࡅࡂࡆࡐࡉ࠳ࡳࡤࠨࢣ")).read())[0].strip(l1l11_sy_ (u"ࠧࠫࠩࢤ"))
        except: l111ll1_sy_ = l1l11_sy_ (u"ࠨࠩࢥ")
        l11l11l_sy_ = l111l1_sy_(l1l11_sy_ (u"ࠪࠩࡩࡀࠥࡴ࠼ࠨࡨࠬࢮ")%(tm.tm_hour,l111ll1_sy_,tm.tm_min))
        l1ll1lll_sy_.setSetting(l1l11_sy_ (u"ࠫࡰࡵࡤࠨࢯ"),l11l11l_sy_)
def l111l1l_sy_(ex_link):
    l11l111_sy_ = l11l1l1_sy_.l1lll1l1_sy_(ex_link)
    l1ll1ll1_sy_=l1l11_sy_ (u"ࠬ࠭ࢰ")
    t = [ x.get(l1l11_sy_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࢱ")) for x in l11l111_sy_]
    u = [ x.get(l1l11_sy_ (u"ࠧࡶࡴ࡯ࠫࢲ")) for x in l11l111_sy_]
    l11l1l_sy_ = xbmcgui.Dialog().select(l1l11_sy_ (u"ࠣࡕࡲࡹࡷࡩࡥࡴࠤࢳ"), t)
    if l11l1l_sy_>-1:
        l1111l1_sy_ = l11l111_sy_[l11l1l_sy_].get(l1l11_sy_ (u"ࠩࡸࡶࡱ࠭ࢴ"))
        l1ll1ll1_sy_=l1ll11l_sy_(l1111l1_sy_) if l1111l1_sy_ else l1l11_sy_ (u"ࠪࠫࢵ")
    if l1ll1ll1_sy_:
        xbmcplugin.setResolvedUrl(l111l11_sy_, True, xbmcgui.ListItem(path=l1ll1ll1_sy_))
    else:
        xbmcplugin.setResolvedUrl(l111l11_sy_, False, xbmcgui.ListItem(path=l1l11_sy_ (u"ࠫࠬࢶ")))
mode = args.get(l1l11_sy_ (u"ࠬࡳ࡯ࡥࡧࠪࢷ"), None)
fname = args.get(l1l11_sy_ (u"࠭ࡦࡰ࡮ࡧࡩࡷࡴࡡ࡮ࡧࠪࢸ"),[l1l11_sy_ (u"ࠧࠨࢹ")])[0]
ex_link = args.get(l1l11_sy_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩࢺ"),[l1l11_sy_ (u"ࠩࠪࢻ")])[0]
params = args.get(l1l11_sy_ (u"ࠪࡴࡦࡸࡡ࡮ࡵࠪࢼ"),[{}])[0]
l1ll1ll_sy_ = l1ll1lll_sy_.getSetting(l1l11_sy_ (u"ࠫࡸࡵࡲࡵࡘࠪࢽ"))
l1ll1l11_sy_ = l1ll1lll_sy_.getSetting(l1l11_sy_ (u"ࠬࡹ࡯ࡳࡶࡑࠫࢾ")) if l1ll1ll_sy_ else l1l11_sy_ (u"࠭ࡂࡳࡣ࡮ࠫࢿ")
if mode is None:
    l1l111l_sy_(name=l1l11_sy_ (u"ࠧࡊࡰࡩࡳࡷࡳࡡࡤ࡬ࡤࠫࣀ"),mode=l1l11_sy_ (u"ࠨࡡ࡬ࡲ࡫ࡵ࡟ࠨࣁ"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1l11_sy_ (u"ࠩࡳࡥࡹ࡮ࠧࣂ")))+l1l11_sy_ (u"ࠪ࠳࡮ࡩ࡯࡯࠰ࡳࡲ࡬࠭ࣃ"),infoLabels={})
    l111lll_sy_(l1l11_sy_ (u"ࠦࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟ࡖࡳࡷࡺ࡯ࡸࡣࡱ࡭ࡪࡀ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠡ࡝ࡅࡡࠧࣄ")+l1ll1l11_sy_+l1l11_sy_ (u"ࠧࡡ࠯ࡃ࡟ࠥࣅ"),l1l11_sy_ (u"࠭ࠧࣆ"),mode=l1l11_sy_ (u"ࠧࡧ࡫࡯ࡸࡷࡀࡳࡰࡴࡷࠫࣇ"),l1ll111_sy_=l1l11_sy_ (u"ࠨࠩࣈ"),IsPlayable=False)
    l1l111l_sy_(name=l1l11_sy_ (u"ࠤࡖࡸࡷࡵ࡮ࡢࠢࡪॆࣸࡽ࡮ࡢࠤࣉ"),ex_link=l1l11_sy_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡴࡧࡵ࡭ࡦࡲ࡯ࡴࡻ࠱ࡴࡱ࠵ࠧ࣊"),params={}, mode=l1l11_sy_ (u"ࠫ࡬࡫ࡴࡄࡱࡱࡸࡪࡴࡴࠨ࣋"),iconImage=l1l11_sy_ (u"ࠬ࠭࣌"))
    l1l111l_sy_(name=l1l11_sy_ (u"ࠨ࡚ࡢࡩࡵࡥࡳ࡯ࡣࡻࡰࡨࠤࡸ࡫ࡲࡪࡣ࡯ࡩࠧ࣍"),ex_link=l1l11_sy_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡸ࡫ࡲࡪࡣ࡯ࡳࡸࡿ࠮ࡱ࡮ࠪ࣎"),params={l1l11_sy_ (u"ࠨ࡯ࡨࡲࡺ࣏࠭"):l1l11_sy_ (u"ࠩ࡝ࡥ࡬ࡸࡡ࡯࡫ࡦࡾࡳ࡫࣐ࠧ")}, mode=l1l11_sy_ (u"ࠪ࡫ࡪࡺࡓࡦࡴ࡬ࡥࡱ࡫࣑ࠧ"),iconImage=l1l11_sy_ (u"࣒ࠫࠬ"))
    l1l111l_sy_(name=l1l11_sy_ (u"ࠧࡖ࡯࡭ࡵ࡮࡭ࡪࠦࡳࡦࡴ࡬ࡥࡱ࡫࣓ࠢ"),ex_link=l1l11_sy_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡷࡪࡸࡩࡢ࡮ࡲࡷࡾ࠴ࡰ࡭ࠩࣔ"),params={l1l11_sy_ (u"ࠧ࡮ࡧࡱࡹࠬࣕ"):l1l11_sy_ (u"ࠨࡒࡲࡰࡸࡱࡩࡦࠩࣖ")}, mode=l1l11_sy_ (u"ࠩࡪࡩࡹ࡙ࡥࡳ࡫ࡤࡰࡪ࠭ࣗ"),iconImage=l1l11_sy_ (u"ࠪࠫࣘ"))
    l1l111l_sy_(name=l1l11_sy_ (u"ࠦࡉࡵ࡫ࡶ࡯ࡨࡲࡹࡧ࡬࡯ࡧࠥࣙ"),ex_link=l1l11_sy_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡶࡩࡷ࡯ࡡ࡭ࡱࡶࡽ࠳ࡶ࡬ࠨࣚ"),params={l1l11_sy_ (u"࠭࡭ࡦࡰࡸࠫࣛ"):l1l11_sy_ (u"ࠧࡅࡱ࡮ࡹࡲ࡫࡮ࡵࡣ࡯ࡲࡪ࠭ࣜ")}, mode=l1l11_sy_ (u"ࠨࡩࡨࡸࡘ࡫ࡲࡪࡣ࡯ࡩࠬࣝ"),iconImage=l1l11_sy_ (u"ࠩࠪࣞ"))
elif mode[0].startswith(l1l11_sy_ (u"ࠪࡣ࡮ࡴࡦࡰࡡࠪࣟ")):l1lll11_sy_.__myinfo__.go(sys.argv)
elif l1l11_sy_ (u"ࠫ࡫࡯࡬ࡵࡴࠪ࣠") in mode[0]:
    _11111_sy_ = mode[0].split(l1l11_sy_ (u"ࠧࡀࠢ࣡"))[-1]
    if _11111_sy_==l1l11_sy_ (u"࠭ࡳࡰࡴࡷࠫ࣢"):
        label=[l1l11_sy_ (u"ࠧࡃࡴࡤ࡯ࣣࠬ"),l1l11_sy_ (u"ࠨࡆࡤࡸࡦࠦࡤࡰࡦࡤࡲ࡮ࡧࠧࣤ"),l1l11_sy_ (u"ࠩࡒࡧࡪࡴࡡࠨࣥ"),l1l11_sy_ (u"࡛ࠪࡾॡࡷࡪࡧࡷࡰࡪࡴࡩࡢࣦࠩ"),l1l11_sy_ (u"ࠫࡐࡵ࡭ࡦࡰࡷࡥࡷࢀࡥࠨࣧ"),l1l11_sy_ (u"ࠬࡇ࡬ࡧࡣࡥࡩࡹࡿࡣࡻࡰ࡬ࡩࠥࡇ࡛࠭ࠩࣨ"),l1l11_sy_ (u"࠭ࡁ࡭ࡨࡤࡦࡪࡺࡹࡤࡼࡱ࡭ࡪ࡚ࠦ࠮ࡃࣩࠪ")]
        value=[l1l11_sy_ (u"ࠧࠨ࣪"),l1l11_sy_ (u"ࠨࡦ࡯ࡩࡳ࡫ࡷࡴࡵࡲࡶࡹࡨࡹ࠾ࡦࡤࡸࡪࠬࡤ࡭ࡧࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࡂࡪࡥࡴࡥࠩࡷࡪࡺ࡟࡯ࡧࡺࡣࡸࡵࡲࡵ࠿ࡧࡰࡪࡥࡳࡰࡴࡷࡣࡲࡧࡩ࡯ࠨࡶࡩࡹࡥࡤࡪࡴࡨࡧࡹ࡯࡯࡯ࡡࡶࡳࡷࡺ࠽ࡥ࡮ࡨࡣࡩ࡯ࡲࡦࡥࡷ࡭ࡴࡴ࡟࡮ࡣ࡬ࡲࠬ࣫"),l1l11_sy_ (u"ࠩࡧࡰࡪࡴࡥࡸࡵࡶࡳࡷࡺࡢࡺ࠿ࡵࡥࡹ࡯࡮ࡨࠨࡧࡰࡪࡪࡩࡳࡧࡦࡸ࡮ࡵ࡮࠾ࡦࡨࡷࡨࠬࡳࡦࡶࡢࡲࡪࡽ࡟ࡴࡱࡵࡸࡂࡪ࡬ࡦࡡࡶࡳࡷࡺ࡟࡮ࡣ࡬ࡲࠫࡹࡥࡵࡡࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࡤࡹ࡯ࡳࡶࡀࡨࡱ࡫࡟ࡥ࡫ࡵࡩࡨࡺࡩࡰࡰࡢࡱࡦ࡯࡮ࠨ࣬"),l1l11_sy_ (u"ࠪࡨࡱ࡫࡮ࡦࡹࡶࡷࡴࡸࡴࡣࡻࡀࡲࡪࡽࡳࡠࡴࡨࡥࡩࠬࡤ࡭ࡧࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࡂࡪࡥࡴࡥࠩࡷࡪࡺ࡟࡯ࡧࡺࡣࡸࡵࡲࡵ࠿ࡧࡰࡪࡥࡳࡰࡴࡷࡣࡲࡧࡩ࡯ࠨࡶࡩࡹࡥࡤࡪࡴࡨࡧࡹ࡯࡯࡯ࡡࡶࡳࡷࡺ࠽ࡥ࡮ࡨࡣࡩ࡯ࡲࡦࡥࡷ࡭ࡴࡴ࡟࡮ࡣ࡬ࡲ࣭ࠬ"),l1l11_sy_ (u"ࠫࡩࡲࡥ࡯ࡧࡺࡷࡸࡵࡲࡵࡤࡼࡁࡨࡵ࡭࡮ࡡࡱࡹࡲࠬࡤ࡭ࡧࡧ࡭ࡷ࡫ࡣࡵ࡫ࡲࡲࡂࡪࡥࡴࡥࠩࡷࡪࡺ࡟࡯ࡧࡺࡣࡸࡵࡲࡵ࠿ࡧࡰࡪࡥࡳࡰࡴࡷࡣࡲࡧࡩ࡯ࠨࡶࡩࡹࡥࡤࡪࡴࡨࡧࡹ࡯࡯࡯ࡡࡶࡳࡷࡺ࠽ࡥ࡮ࡨࡣࡩ࡯ࡲࡦࡥࡷ࡭ࡴࡴ࡟࡮ࡣ࡬ࡲ࣮ࠬ"),l1l11_sy_ (u"ࠬࡪ࡬ࡦࡰࡨࡻࡸࡹ࡯ࡳࡶࡥࡽࡂࡺࡩࡵ࡮ࡨࠪࡩࡲࡥࡥ࡫ࡵࡩࡨࡺࡩࡰࡰࡀࡥࡸࡩࠦࡴࡧࡷࡣࡳ࡫ࡷࡠࡵࡲࡶࡹࡃࡤ࡭ࡧࡢࡷࡴࡸࡴࡠ࡯ࡤ࡭ࡳࠬࡳࡦࡶࡢࡨ࡮ࡸࡥࡤࡶ࡬ࡳࡳࡥࡳࡰࡴࡷࡁࡩࡲࡥࡠࡦ࡬ࡶࡪࡩࡴࡪࡱࡱࡣࡲࡧࡩ࡯࣯ࠩ"),l1l11_sy_ (u"࠭ࡤ࡭ࡧࡱࡩࡼࡹࡳࡰࡴࡷࡦࡾࡃࡴࡪࡶ࡯ࡩࠫࡪ࡬ࡦࡦ࡬ࡶࡪࡩࡴࡪࡱࡱࡁࡩ࡫ࡳࡤࠨࡶࡩࡹࡥ࡮ࡦࡹࡢࡷࡴࡸࡴ࠾ࡦ࡯ࡩࡤࡹ࡯ࡳࡶࡢࡱࡦ࡯࡮ࠧࡵࡨࡸࡤࡪࡩࡳࡧࡦࡸ࡮ࡵ࡮ࡠࡵࡲࡶࡹࡃࡤ࡭ࡧࡢࡨ࡮ࡸࡥࡤࡶ࡬ࡳࡳࡥ࡭ࡢ࡫ࡱࣰࠫ")]
        msg = l1l11_sy_ (u"ࠧࡔࡱࡵࡸࡴࡽࡡ࡯࡫ࡨࣱࠫ")
    s = xbmcgui.Dialog().select(msg,label)
    s = s if s>-1 else 0
    l1ll1lll_sy_.setSetting(_11111_sy_+l1l11_sy_ (u"ࠨࡘࣲࠪ"),value[s])
    l1ll1lll_sy_.setSetting(_11111_sy_+l1l11_sy_ (u"ࠩࡑࠫࣳ"),label[s])
    xbmc.executebuiltin(l1l11_sy_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬࣴ"))
elif mode[0]==l1l11_sy_ (u"ࠫ࡬࡫ࡴࡔࡧࡵ࡭ࡦࡲࡥࠨࣵ"):
    params=eval(params)
    l11lll1_sy_ = l11l1l1_sy_.l1llll1l_sy_(ex_link,params.get(l1l11_sy_ (u"ࠬࡳࡥ࡯ࡷࣶࠪ"),l1l11_sy_ (u"࡚࠭ࡢࡩࡵࡥࡳ࡯ࡣࡻࡰࡨࠫࣷ")))
    items=len(l11lll1_sy_)
    for f in l11lll1_sy_:
        l111lll_sy_(name=f.get(l1l11_sy_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࣸ")), url=f.get(l1l11_sy_ (u"ࠨࡷࡵࡰࣹࠬ"),l1l11_sy_ (u"ࣺࠩࠪ")), mode=l1l11_sy_ (u"ࠪ࡫ࡪࡺࡃࡰࡰࡷࡩࡳࡺࠧࣻ"), l1ll111_sy_=f.get(l1l11_sy_ (u"ࠫ࡮ࡳࡧࠨࣼ")), infoLabels=f, isFolder=True, IsPlayable=False,l11ll11_sy_=items)
    xbmcplugin.setContent(l111l11_sy_, l1l11_sy_ (u"ࠬࡺࡶࡴࡪࡲࡻࡸ࠭ࣽ"))
elif mode[0]==l1l11_sy_ (u"࠭ࡧࡦࡶࡆࡳࡳࡺࡥ࡯ࡶࠪࣾ"):
     l1lll111_sy_(ex_link,l1ll1ll_sy_)
elif mode[0]==l1l11_sy_ (u"ࠧࡨࡧࡷࡐ࡮ࡴ࡫ࡴࠩࣿ"):
    l111l1l_sy_(ex_link)
elif mode[0].startswith(l1l11_sy_ (u"ࠨࡲࡤ࡫ࡪ࠭ऀ")):
    l1ll1l1_sy_,l11llll_sy_ = mode[0].split(l1l11_sy_ (u"ࠩ࠽ࠫँ"))
    url = l1111l_sy_({l1l11_sy_ (u"ࠪࡱࡴࡪࡥࠨं"): l11llll_sy_, l1l11_sy_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨः"): l1l11_sy_ (u"ࠬ࠭ऄ"), l1l11_sy_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧअ") : ex_link, l1l11_sy_ (u"ࠧࡱࡣࡵࡥࡲࡹࠧआ"):params})
    xbmc.executebuiltin(l1l11_sy_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠫࠩࡸ࠯ࠧइ")% url)
else:
    xbmcplugin.setResolvedUrl(l111l11_sy_, False, xbmcgui.ListItem(path=l1l11_sy_ (u"ࠩࠪई")))
xbmcplugin.endOfDirectory(l111l11_sy_)
