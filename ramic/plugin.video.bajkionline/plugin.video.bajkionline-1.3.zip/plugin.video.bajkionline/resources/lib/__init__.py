# coding: UTF-8
import sys
l1llll1_ba_ = sys.version_info [0] == 2
l1lll1_ba_ = 2048
l1111_ba_ = 7
def l11l11_ba_ (ll_ba_):
	global l1lll1l_ba_
	l11l11l_ba_ = ord (ll_ba_ [-1])
	l1lllll_ba_ = ll_ba_ [:-1]
	l1l11l1_ba_ = l11l11l_ba_ % len (l1lllll_ba_)
	l1lll_ba_ = l1lllll_ba_ [:l1l11l1_ba_] + l1lllll_ba_ [l1l11l1_ba_:]
	if l1llll1_ba_:
		l1l1ll1_ba_ = unicode () .join ([unichr (ord (char) - l1lll1_ba_ - (l11ll1_ba_ + l11l11l_ba_) % l1111_ba_) for l11ll1_ba_, char in enumerate (l1lll_ba_)])
	else:
		l1l1ll1_ba_ = str () .join ([chr (ord (char) - l1lll1_ba_ - (l11ll1_ba_ + l11l11l_ba_) % l1111_ba_) for l11ll1_ba_, char in enumerate (l1lll_ba_)])
	return eval (l1l1ll1_ba_)