# -*- coding: utf-8 -*-
import sys
l1llll1_ba_ = sys.version_info [0] == 2
l1lll1_ba_ = 2048
l1111_ba_ = 7
def l11l11_ba_ (ll_ba_):
	global l1lll1l_ba_
	l11l11l_ba_ = ord (ll_ba_ [-1])
	l1lllll_ba_ = ll_ba_ [:-1]
	l1l11l1_ba_ = l11l11l_ba_ % len (l1lllll_ba_)
	l1lll_ba_ = l1lllll_ba_ [:l1l11l1_ba_] + l1lllll_ba_ [l1l11l1_ba_:]
	if l1llll1_ba_:
		l1l1ll1_ba_ = unicode () .join ([unichr (ord (char) - l1lll1_ba_ - (l11ll1_ba_ + l11l11l_ba_) % l1111_ba_) for l11ll1_ba_, char in enumerate (l1lll_ba_)])
	else:
		l1l1ll1_ba_ = str () .join ([chr (ord (char) - l1lll1_ba_ - (l11ll1_ba_ + l11l11l_ba_) % l1111_ba_) for l11ll1_ba_, char in enumerate (l1lll_ba_)])
	return eval (l1l1ll1_ba_)
import urllib2,urllib
import re,os
import base64,json
import urlparse
import cookielib
l1l11111l_ba_=l11l11_ba_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡥࡥ࡯ࡱࡩࡰࡰ࡯࡭ࡳ࡫࠮ࡤࡱࡰ࠳ࠬझ")
l11llll11_ba_ = 15
l11ll1lll_ba_=l11l11_ba_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰ࠡࠪࡐࡥࡨ࡯࡮ࡵࡱࡶ࡬ࡀࠦࡕ࠼ࠢࡌࡲࡹ࡫࡬ࠡࡏࡤࡧࠥࡕࡓ࡚ࠡࠣ࠵࠵ࡥ࠶ࡠ࠶࠾ࠤࡪࡴ࠭ࡖࡕࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠹࠴࠳ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠷࠰࠳࠲࠹࠽࠲࠯࠸࠶ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠴࠯࠵ࠪञ")
l1l11ll_ba_=l11l11_ba_ (u"ࡶࠬࡊ࠺࡝ࡥࡲࡳࡰ࡯ࡥࠨट")
def l1l11l11l_ba_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l11l11_ba_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩठ"), l11ll1lll_ba_)
    if cookies:
        req.add_header(l11l11_ba_ (u"ࠨࡃࡰࡱ࡮࡭ࡪࠨड"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11llll11_ba_)
        l1l1l1l_ba_ = response.read()
        response.close()
    except:
        l1l1l1l_ba_=l11l11_ba_ (u"ࠧࠨढ")
    return l1l1l1l_ba_
def l1l11l111_ba_(url,data=None,header={},l11llll1l_ba_=True,l1l111l1l_ba_=False):
    if l1l11ll_ba_ and os.path.isfile(l1l11ll_ba_) and l11llll1l_ba_:
        l1l1111l1_ba_ = cookielib.LWPCookieJar()
        try:
            l1l1111l1_ba_.load(l1l11ll_ba_)
        except:
            l1l1111l1_ba_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1l1111l1_ba_))
        urllib2.install_opener(opener)
    req = urllib2.Request(url,data)
    if not header:
        header = {l11l11_ba_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬण"):l11ll1lll_ba_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l11llll11_ba_)
        l1l1l1l_ba_ =  response.read()
        response.close()
        if l1l11ll_ba_ and os.path.isfile(l1l11ll_ba_) and l1l111l1l_ba_ and l11llll1l_ba_:
             l1l1111l1_ba_.save(l1l11ll_ba_, ignore_discard = True)
    except urllib2.HTTPError as e:
        l1l1l1l_ba_ = l11l11_ba_ (u"ࠩࠪत")
    return l1l1l1l_ba_
def l11111_ba_(url):
    content = l1l11l111_ba_(url)
    l1l1111ll_ba_ = re.compile(l11l11_ba_ (u"ࠪࡀࡱ࡯ࠠࡤ࡮ࡤࡷࡸࡃࠢࡤࡣࡷ࠱࡮ࡺࡥ࡮ࠢࡦࡥࡹ࠳ࡩࡵࡧࡰ࠱ࡡࡪࠫࠣࡀ࡞ࡠࡳࡢࡳ࡞ࠬࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭थ"),re.DOTALL).findall(content)
    out=[]
    for l11lll11l_ba_ in l1l1111ll_ba_:
        href = re.compile(l11l11_ba_ (u"ࠫࡠࡂࡡ࡞ࠬ࡟ࡷ࠯࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫद"),re.DOTALL).findall(l11lll11l_ba_)
        l11lll1ll_ba_ = re.compile(l11l11_ba_ (u"ࠬࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬध"),re.DOTALL).findall(l11lll11l_ba_)
        title = re.compile(l11l11_ba_ (u"࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧन"),re.DOTALL).findall(l11lll11l_ba_)
        if href and title:
            l1l11lll1_ba_ = {l11l11_ba_ (u"ࠧࡩࡴࡨࡪࠬऩ")   : href[0],
                l11l11_ba_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧप")  : l11llllll_ba_(title[0]),
                l11l11_ba_ (u"ࠩࡳࡰࡴࡺࠧफ")   : l11llllll_ba_(l11lll1ll_ba_[0]) if l11lll1ll_ba_ else l11l11_ba_ (u"ࠪࠫब"),
                }
            out.append(l1l11lll1_ba_)
    return out
def l111l1_ba_(url,l1111ll_ba_=l11l11_ba_ (u"ࠫ࠶࠭भ")):
    content = l1l11l111_ba_(url)
    l11ll1ll1_ba_=False
    l11lllll1_ba_=False
    l1l111111_ba_ = [(a.start(), a.end()) for a in re.finditer(l11l11_ba_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡲ࠭࡮ࡦ࠰࠷ࠥࡩ࡯࡭࠯ࡶࡱ࠲࠼ࠠࡤࡱ࡯࠱ࡽࡹ࠭࠷ࠢࠥࡂࠬम"), content)]
    if not l1l111111_ba_:
        l1l111111_ba_ = [(a.start(), a.end()) for a in re.finditer(l11l11_ba_ (u"࠭࠼ࡢࠢࡦࡰࡦࡹࡳ࠾ࠤࡨࡰࡪࡳࡥ࡯ࡶࠣ࡫ࡦࡲ࡬ࡦࡴࡼ࠱ࡸ࡯ࡺࡦࡴࠥࠫय"), content)]
    l1l111111_ba_.append( (-1,-1) )
    out=[]
    for i in range(len(l1l111111_ba_[:-1])):
        l11lll11l_ba_ = content[ l1l111111_ba_[i][1]:l1l111111_ba_[i+1][0] ]
        href = re.compile(l11l11_ba_ (u"ࠧ࡜࠾ࡤࡡ࠯ࡢࡳࠫࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧर"),re.DOTALL).findall(l11lll11l_ba_)
        title = re.compile(l11l11_ba_ (u"ࠨࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨऱ"),re.DOTALL).findall(l11lll11l_ba_)
        l11lll1ll_ba_ = re.compile(l11l11_ba_ (u"ࠩ࠿ࡴࡠࡤ࠾࡞ࠬࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡴࡃ࠭ल"),re.DOTALL).findall(l11lll11l_ba_)
        l1l111ll1_ba_ = re.compile(l11l11_ba_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨळ"),re.DOTALL).findall(l11lll11l_ba_)
        if href and title:
            year =  re.compile(l11l11_ba_ (u"ࠫ࠭ࡢࡤࡼ࠶ࢀ࠭ࠬऴ"),re.DOTALL).search(title[0])
            l1l11lll1_ba_ = {l11l11_ba_ (u"ࠬ࡮ࡲࡦࡨࠪव")   : href[0],
                l11l11_ba_ (u"࠭ࡴࡪࡶ࡯ࡩࠬश")  : l11llllll_ba_(title[0]),
                l11l11_ba_ (u"ࠧࡱ࡮ࡲࡸࠬष")   : l11llllll_ba_(l11lll1ll_ba_[0]) if l11lll1ll_ba_ else l11l11_ba_ (u"ࠨࠩस"),
                l11l11_ba_ (u"ࠩ࡬ࡱ࡬࠭ह")    : l1l111ll1_ba_[0] if l1l111ll1_ba_ else l11l11_ba_ (u"ࠪࠫऺ"),
                l11l11_ba_ (u"ࠫࡾ࡫ࡡࡳࠩऻ")   : year.group(1) if year else l11l11_ba_ (u"़ࠬ࠭"),
                    }
            out.append(l1l11lll1_ba_)
    l11lll1_ba_=re.compile(l11l11_ba_ (u"࠭ࡶࡢࡴࠣࡴࡧࡪ࡟ࡢ࡮ࡳࡠࡸ࠰࠽࡝ࡵ࠭ࠬࢀ࠴ࠪࡀࡿࠬࠫऽ")).findall(content)
    if l11lll1_ba_:
        l11lll1_ba_ = json.loads(l11lll1_ba_[0])
        l11ll1ll1_ba_ = l11lll1_ba_.get(l11l11_ba_ (u"ࠧ࡯ࡧࡻࡸࡑ࡯࡮࡬ࠩा"))
    l11lllll1_ba_ =  False
    return out,(l11lllll1_ba_,l11ll1ll1_ba_)
url=l11l11_ba_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡤࡤ࡮ࡰ࡯࡯࡯࡮࡬ࡲࡪ࠴ࡣࡰ࡯࠲ࡱࡦࡲࡹ࠮࡯࡬ࡷ࠲࡬ࡩ࡭࡫ࡳ࠱࡮࠳ࡳ࡮ࡱ࡮࠳ࠬि")
url=l11l11_ba_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡥࡥ࡯ࡱࡩࡱࡱࡳࡳࡱࡹ࡫ࡶ࠰ࡦࡳࡲ࠵࠱࠸࠯ࡳࡥࡳࡪࡡ࠮ࡼࡤ࠱ࡰࡸࡡࡵ࡭ࡤࡱ࡮࠭ी")
url=l11l11_ba_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡦࡦࡰ࡫ࡪࡱࡱࡰ࡮ࡴࡥ࠯ࡥࡲࡱ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ࡤࡣ࡯࡭ࡲ࡫ࡲࡰࠩु")
def l1l11_ba_(url):
    content = l1l11l111_ba_(url)
    l11lll1l1_ba_=l11l11_ba_ (u"ࠫࠬू")
    try:exec(l11l11_ba_ (u"ࠬࡢࡸ࠱ࡣ࡟ࡼ࠻࠷࡜ࡹ࠴࠳ࡠࡽ࠹ࡤ࡝ࡺ࠵࠴ࡡࡾ࠷ࡣ࡞ࡻ࠻ࡩࡢࡸ࠳࠲࡟ࡼ࠵ࡧ࡜ࡹ࠹࠷ࡠࡽ࠽࠲࡝ࡺ࠺࠽ࡡࡾ࠳ࡢ࡞ࡻ࠴ࡦࡢࡸ࠳࠲࡟ࡼ࠷࠶࡜ࡹ࠴࠳ࡠࡽ࠸࠰࡝ࡺ࠹࠹ࡡࡾ࠷࠹࡞ࡻ࠺࠺ࡢࡸ࠷࠵࡟ࡼ࠷࠶࡜ࡹ࠹࠸ࡠࡽ࠽࠲࡝ࡺ࠹ࡧࡡࡾ࠶ࡤ࡞ࡻ࠺࠾ࡢࡸ࠷࠴࡟ࡼ࠸࠸࡜ࡹ࠴ࡨࡠࡽ࠽࠵࡝ࡺ࠺࠶ࡡࡾ࠶ࡤ࡞ࡻ࠺࡫ࡢࡸ࠸࠲࡟ࡼ࠻࠻࡜ࡹ࠸ࡨࡠࡽ࠸࠸࡝ࡺ࠵࠻ࡡࡾ࠶࠹࡞ࡻ࠻࠹ࡢࡸ࠸࠶࡟ࡼ࠼࠶࡜ࡹ࠹࠶ࡠࡽ࠹ࡡ࡝ࡺ࠵ࡪࡡࡾ࠲ࡧ࡞ࡻ࠺࠹ࡢࡸ࠸࠴࡟ࡼ࠻࠿࡜ࡹ࠹࠹ࡠࡽ࠼࠵࡝ࡺ࠵ࡩࡡࡾ࠶࠸࡞ࡻ࠺࡫ࡢࡸ࠷ࡨ࡟ࡼ࠻࠽࡜ࡹ࠸ࡦࡠࡽ࠼࠵࡝ࡺ࠵ࡩࡡࡾ࠶࠴࡞ࡻ࠺࡫ࡢࡸ࠷ࡦ࡟ࡼ࠷࡬࡜ࡹ࠹࠸ࡠࡽ࠼࠳࡝ࡺ࠶ࡪࡡࡾ࠶࠶࡞ࡻ࠻࠽ࡢࡸ࠸࠲࡟ࡼ࠻࡬࡜ࡹ࠹࠵ࡠࡽ࠽࠴࡝ࡺ࠶ࡨࡡࡾ࠶࠵࡞ࡻ࠺࡫ࡢࡸ࠸࠹࡟ࡼ࠻࡫࡜ࡹ࠸ࡦࡠࡽ࠼ࡦ࡝ࡺ࠹࠵ࡡࡾ࠶࠵࡞ࡻ࠶࠻ࡢࡸ࠷࠻࡟ࡼ࠻࠺࡜ࡹ࠵ࡧࡠࡽ࠹࠰࡝ࡺ࠷࠶ࡡࡾ࠳࠱࡞ࡻ࠹࠵ࡢࡸ࠷ࡦ࡟ࡼ࠻ࡩ࡜ࡹ࠷࠹ࡠࡽ࠺࠹࡝ࡺ࠺࠼ࡡࡾ࠷࠺࡞ࡻ࠺࠼ࡢࡸ࠷ࡤ࡟ࡼ࠼࠺࡜ࡹ࠷࠹ࡠࡽ࠹࠳࡝ࡺ࠸࠺ࡡࡾ࠳࠳࡞ࡻ࠹࠸ࡢࡸ࠴࠴࡟ࡼ࠸࠿࡜ࡹ࠷ࡤࡠࡽ࠻࠴࡝ࡺ࠸࠺ࡡࡾ࠴ࡦ࡞ࡻ࠺ࡧࡢࡸ࠶࠹࡟ࡼ࠺࠺࡜ࡹ࠶࠴ࡠࡽ࠸࠷࡝ࡺ࠵࠽ࡡࡾ࠲ࡦ࡞ࡻ࠻࠷ࡢࡸ࠷࠷࡟ࡼ࠻࠷࡜ࡹ࠸࠷ࡠࡽ࠸࠸࡝ࡺ࠵࠽ࡡࡾ࠲࠱࡞ࡻ࠺࠾ࡢࡸ࠷ࡧ࡟ࡼ࠷࠶࡜ࡹ࠸࠴ࡠࡽ࠶ࡡ࡝ࡺ࠵࠴ࡡࡾ࠲࠱࡞ࡻ࠶࠵ࡢࡸ࠳࠲࡟ࡼ࠻࠷࡜ࡹ࠷ࡥࡠࡽ࠸࠲࡝ࡺ࠺࠶ࡡࡾ࠷࠶࡞ࡻ࠺ࡪࡢࡸ࠳࠴࡟ࡼ࠺ࡪ࡜ࡹ࠴࠻ࡠࡽ࠸࠹࡝ࡺ࠵࠴ࡡࡾ࠲࠱࡞ࡻ࠶࠵ࡢࡸ࠳࠲࡟ࡼ࠷࠶࡜ࡹ࠲ࡤࡠࡽ࠼࠵࡝ࡺ࠺࠼ࡡࡾ࠶࠴࡞ࡻ࠺࠺ࡢࡸ࠸࠲࡟ࡼ࠼࠺࡜ࡹ࠵ࡤࡠࡽ࠽࠰࡝ࡺ࠹࠵ࡡࡾ࠷࠴࡞ࡻ࠻࠸ࡢࡸ࠱ࡣࠪृ"))
    except:pass
    l1l111lll_ba_ = re.compile(l11l11_ba_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡩࡧࡴࡤࡱࡪ࠭ॄ"),re.DOTALL).findall(content)
    for l1l111l11_ba_ in l1l111lll_ba_:
        src = re.compile(l11l11_ba_ (u"ࠧࡴࡴࡦࡁࡠࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜࡞ࠪࠦࡢ࠭ॅ")).findall(l1l111l11_ba_)
        if src:
            l11lll1l1_ba_ = src[0]
            if l11l11_ba_ (u"ࠨࡨࡤࡧࡪࡨ࡯ࡰ࡭ࠪॆ") in l11lll1l1_ba_:
                continue
            if l11lll1l1_ba_.startswith(l11l11_ba_ (u"ࠩ࠲࠳ࠬे")):
                l11lll1l1_ba_ = l11l11_ba_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩै")+l11lll1l1_ba_
            break
    return l11lll1l1_ba_
def l11llllll_ba_(l11lll111_ba_):
    if type(l11lll111_ba_) is not str:
        l11lll111_ba_=l11lll111_ba_.encode(l11l11_ba_ (u"ࠫࡺࡺࡦ࠮࠺ࠪॉ"))
    s=l11l11_ba_ (u"ࠬࡐࡩࡏࡥ࡝ࡇࡸ࠽ࠧॊ")
    l11lll111_ba_ = re.sub(s.decode(l11l11_ba_ (u"࠭ࡢࡢࡵࡨ࠺࠹࠭ो")),l11l11_ba_ (u"ࠧࠨौ"),l11lll111_ba_)
    l11lll111_ba_ = l11lll111_ba_.replace(l11l11_ba_ (u"ࠨࠨ࡯ࡸࡀ࡮࠵ࠧࡩࡷ࠿्ࠬ"),l11l11_ba_ (u"ࠩࠪॎ"))
    l11lll111_ba_ = l11lll111_ba_.replace(l11l11_ba_ (u"ࠪࠪࡱࡺ࠻࠰ࡪ࠸ࠪ࡬ࡺ࠻ࠨॏ"),l11l11_ba_ (u"ࠫࠬॐ"))
    l11lll111_ba_ = l11lll111_ba_.replace(l11l11_ba_ (u"ࠬࠬ࡮ࡣࡵࡳ࠿ࠬ॑"),l11l11_ba_ (u"॒࠭ࠧ"))
    l11lll111_ba_ = l11lll111_ba_.replace(l11l11_ba_ (u"ࠧࠧ࡮ࡷ࠿ࡧࡸ࠯ࠧࡩࡷ࠿ࠬ॓"),l11l11_ba_ (u"ࠨࠢࠪ॔"))
    l11lll111_ba_ = l11lll111_ba_.replace(l11l11_ba_ (u"ࠩࠩࡵࡺࡵࡴ࠼ࠩॕ"),l11l11_ba_ (u"ࠪࠦࠬॖ")).replace(l11l11_ba_ (u"ࠫࠫࡧ࡭ࡱ࠽ࡴࡹࡴࡺ࠻ࠨॗ"),l11l11_ba_ (u"ࠬࠨࠧक़"))
    l11lll111_ba_ = l11lll111_ba_.replace(l11l11_ba_ (u"࠭ࠦࡰࡣࡦࡹࡹ࡫࠻ࠨख़"),l11l11_ba_ (u"ࠧࣴࠩग़")).replace(l11l11_ba_ (u"ࠨࠨࡒࡥࡨࡻࡴࡦ࠽ࠪज़"),l11l11_ba_ (u"ࠩࣖࠫड़"))
    l11lll111_ba_ = l11lll111_ba_.replace(l11l11_ba_ (u"ࠪࠪࡦࡳࡰ࠼ࡱࡤࡧࡺࡺࡥ࠼ࠩढ़"),l11l11_ba_ (u"ࠫࣸ࠭फ़")).replace(l11l11_ba_ (u"ࠬࠬࡡ࡮ࡲ࠾ࡓࡦࡩࡵࡵࡧ࠾ࠫय़"),l11l11_ba_ (u"࣓࠭ࠨॠ"))
    l11lll111_ba_ = l11lll111_ba_.replace(l11l11_ba_ (u"ࠧ࡝ࡷ࠳࠵࠵࠻ࠧॡ"),l11l11_ba_ (u"ࠨइࠪॢ")).replace(l11l11_ba_ (u"ࠩ࡟ࡹ࠵࠷࠰࠵ࠩॣ"),l11l11_ba_ (u"ࠪईࠬ।"))
    l11lll111_ba_ = l11lll111_ba_.replace(l11l11_ba_ (u"ࠫࡡࡻ࠰࠲࠲࠺ࠫ॥"),l11l11_ba_ (u"ࠬऍࠧ०")).replace(l11l11_ba_ (u"࠭࡜ࡶ࠲࠴࠴࠻࠭१"),l11l11_ba_ (u"ࠧइࠩ२"))
    l11lll111_ba_ = l11lll111_ba_.replace(l11l11_ba_ (u"ࠨ࡞ࡸ࠴࠶࠷࠹ࠨ३"),l11l11_ba_ (u"ࠩजࠫ४")).replace(l11l11_ba_ (u"ࠪࡠࡺ࠶࠱࠲࠺ࠪ५"),l11l11_ba_ (u"ࠫझ࠭६"))
    l11lll111_ba_ = l11lll111_ba_.replace(l11l11_ba_ (u"ࠬࡢࡵ࠱࠳࠷࠶ࠬ७"),l11l11_ba_ (u"࠭ूࠨ८")).replace(l11l11_ba_ (u"ࠧ࡝ࡷ࠳࠵࠹࠷ࠧ९"),l11l11_ba_ (u"ࠨृࠪ॰"))
    l11lll111_ba_ = l11lll111_ba_.replace(l11l11_ba_ (u"ࠩ࡟ࡹ࠵࠷࠴࠵ࠩॱ"),l11l11_ba_ (u"ࠪैࠬॲ")).replace(l11l11_ba_ (u"ࠫࡡࡻ࠰࠲࠶࠷ࠫॳ"),l11l11_ba_ (u"ࠬॉࠧॴ"))
    l11lll111_ba_ = l11lll111_ba_.replace(l11l11_ba_ (u"࠭࡜ࡶ࠲࠳ࡪ࠸࠭ॵ"),l11l11_ba_ (u"ࠧࣴࠩॶ")).replace(l11l11_ba_ (u"ࠨ࡞ࡸ࠴࠵ࡪ࠳ࠨॷ"),l11l11_ba_ (u"ࠩࣖࠫॸ"))
    l11lll111_ba_ = l11lll111_ba_.replace(l11l11_ba_ (u"ࠪࡠࡺ࠶࠱࠶ࡤࠪॹ"),l11l11_ba_ (u"ࠫॠ࠭ॺ")).replace(l11l11_ba_ (u"ࠬࡢࡵ࠱࠳࠸ࡥࠬॻ"),l11l11_ba_ (u"࠭ग़ࠨॼ"))
    l11lll111_ba_ = l11lll111_ba_.replace(l11l11_ba_ (u"ࠧ࡝ࡷ࠳࠵࠼ࡧࠧॽ"),l11l11_ba_ (u"ࠨॼࠪॾ")).replace(l11l11_ba_ (u"ࠩ࡟ࡹ࠵࠷࠷࠺ࠩॿ"),l11l11_ba_ (u"ࠪॽࠬঀ"))
    l11lll111_ba_ = l11lll111_ba_.replace(l11l11_ba_ (u"ࠫࡡࡻ࠰࠲࠹ࡦࠫঁ"),l11l11_ba_ (u"ࠬংࠧং")).replace(l11l11_ba_ (u"࠭࡜ࡶ࠲࠴࠻ࡧ࠭ঃ"),l11l11_ba_ (u"ࠧॼࠩ঄"))
    return l11lll111_ba_
