# -*- coding: utf-8 -*-
import sys
l1llll1_ba_ = sys.version_info [0] == 2
l1lll1_ba_ = 2048
l1111_ba_ = 7
def l11l11_ba_ (ll_ba_):
	global l1lll1l_ba_
	l11l11l_ba_ = ord (ll_ba_ [-1])
	l1lllll_ba_ = ll_ba_ [:-1]
	l1l11l1_ba_ = l11l11l_ba_ % len (l1lllll_ba_)
	l1lll_ba_ = l1lllll_ba_ [:l1l11l1_ba_] + l1lllll_ba_ [l1l11l1_ba_:]
	if l1llll1_ba_:
		l1l1ll1_ba_ = unicode () .join ([unichr (ord (char) - l1lll1_ba_ - (l11ll1_ba_ + l11l11l_ba_) % l1111_ba_) for l11ll1_ba_, char in enumerate (l1lll_ba_)])
	else:
		l1l1ll1_ba_ = str () .join ([chr (ord (char) - l1lll1_ba_ - (l11ll1_ba_ + l11l11l_ba_) % l1111_ba_) for l11ll1_ba_, char in enumerate (l1lll_ba_)])
	return eval (l1l1ll1_ba_)
l11l11_ba_ (u"ࠣࠤࠥࠑࠏࡉࡲࡦࡣࡷࡩࡩࠦ࡯࡯ࠢࡗ࡬ࡺࠦࡆࡦࡤࠣ࠵࠶ࠦ࠱࠹࠼࠷࠻࠿࠺࠳ࠡ࠴࠳࠵࠻ࠓࠊࠎࠌࡃࡥࡺࡺࡨࡰࡴ࠽ࠤࡷࡧ࡭ࡪࡥࠐࠎࠧࠨࠢঅ")
import urllib2
import re
import l11ll11l1_ba_ as l11ll11l1_ba_
l1l11111l_ba_=l11l11_ba_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡣࡥࡣ࠱ࡴࡱ࠭আ")
l11llll11_ba_ = 5
def l1l11l111_ba_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l11l11_ba_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧই"), l11l11_ba_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡐ࡙࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠸࠽࠴࠰࠯࠴࠸࠺࠹࠴࠹࠸ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩঈ"))
    if cookies:
        req.add_header(l11l11_ba_ (u"ࠧࡉ࡯ࡰ࡭࡬ࡩࠧউ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11llll11_ba_)
        l1l1l1l_ba_ =  response.read()
        response.close()
    except:
        l1l1l1l_ba_=l11l11_ba_ (u"࠭ࠧঊ")
    return l1l1l1l_ba_
def _11ll1l11_ba_(content):
    src =l11l11_ba_ (u"ࠧࠨঋ")
    l11l1ll11_ba_ = re.compile(l11l11_ba_ (u"ࠣࡧࡹࡥࡱ࠮࠮ࠫࡁࠬࡠࢀࡢࡽ࡝ࠫ࡟࠭ࠧঌ"),re.DOTALL).findall(content)
    for l11l1l1ll_ba_ in l11l1ll11_ba_:
        l11l1l1ll_ba_=re.sub(l11l11_ba_ (u"ࠩࠣࠤࠬ঍"),l11l11_ba_ (u"ࠪࠤࠬ঎"),l11l1l1ll_ba_)
        l11l1l1ll_ba_=re.sub(l11l11_ba_ (u"ࠫࡡࡴࠧএ"),l11l11_ba_ (u"ࠬ࠭ঐ"),l11l1l1ll_ba_)
        try:
            l11ll1111_ba_ = l11ll11l1_ba_.unpack(l11l1l1ll_ba_)
        except:
            l11ll1111_ba_=l11l11_ba_ (u"࠭ࠧ঑")
        if l11ll1111_ba_:
            l11ll1111_ba_=re.sub(l11l11_ba_ (u"ࡲࠨ࡞࡟ࠫ঒"),l11l11_ba_ (u"ࡳࠩࠪও"),l11ll1111_ba_)
            l11l1ll1l_ba_ = re.compile(l11l11_ba_ (u"ࠩࡩ࡭ࡱ࡫࠺࡝ࡵ࠭࡟ࡡ࠭ࠢ࡞ࠪ࠱࠯ࡄ࠯࡛࡝ࠩࠥࡡ࠱࠭ঔ"),  re.DOTALL).search(l11ll1111_ba_)
            l11l1llll_ba_ = re.compile(l11l11_ba_ (u"ࠪࡹࡷࡲ࠺࡝ࡵ࠭࡟ࡡ࠭ࠢ࡞ࠪ࠱࠯ࡄ࠯࡛࡝ࠩࠥࡡ࠱࠭ক"),  re.DOTALL).search(l11ll1111_ba_)
            if l11l1ll1l_ba_:
                src = l11l1ll1l_ba_.group(1)
            elif l11l1llll_ba_:
                src = l11l1llll_ba_.group(1)
            if src:
                break
    return src
def _11l1lll1_ba_(content):
    src=l11l11_ba_ (u"ࠫࠬখ")
    l11l11l1l_ba_ = content.find(l11l11_ba_ (u"ࠬࢂࡼࡽࡪࡷࡸࡵ࠭গ"))
    if l11l11l1l_ba_>0:
        l11l11lll_ba_ = content.find(l11l11_ba_ (u"࠭࠮ࡴࡲ࡯࡭ࡹ࠭ঘ"),l11l11l1l_ba_)
        encoded =content[l11l11l1l_ba_:l11l11lll_ba_]
        if encoded:
            l11ll1l1l_ba_ = encoded.split(l11l11_ba_ (u"ࠧࡱ࡮ࡤࡽࡪࡸࠧঙ"))[0]
            l11ll1l1l_ba_=re.sub(l11l11_ba_ (u"ࡳࠩ࡞ࢀࡢ࠱࡜ࡸࡽ࠵࠰࠸ࢃ࡛ࡽ࡟࠮ࠫচ"),l11l11_ba_ (u"ࠩࡿࠫছ"),l11ll1l1l_ba_,re.DOTALL)
            l11ll1l1l_ba_=re.sub(l11l11_ba_ (u"ࡵࠫࡠࢂ࡝ࠬ࡞ࡺࡿ࠷࠲࠳ࡾ࡝ࡿࡡ࠰࠭জ"),l11l11_ba_ (u"ࠫࢁ࠭ঝ"),l11ll1l1l_ba_,re.DOTALL)
            l11l111ll_ba_=[l11l11_ba_ (u"ࠬ࡮ࡴࡵࡲࠪঞ"),l11l11_ba_ (u"࠭ࡣࡥࡣࠪট"),l11l11_ba_ (u"ࠧࡱ࡮ࠪঠ"),l11l11_ba_ (u"ࠨ࡮ࡲ࡫ࡴ࠭ড"),l11l11_ba_ (u"ࠩࡺ࡭ࡩࡺࡨࠨঢ"),l11l11_ba_ (u"ࠪ࡬ࡪ࡯ࡧࡩࡶࠪণ"),l11l11_ba_ (u"ࠫࡹࡸࡵࡦࠩত"),l11l11_ba_ (u"ࠬࡹࡴࡢࡶ࡬ࡧࠬথ"),l11l11_ba_ (u"࠭ࡳࡵࠩদ"),l11l11_ba_ (u"ࠧ࡮ࡲ࠷ࠫধ"),l11l11_ba_ (u"ࠨࡨࡤࡰࡸ࡫ࠧন"),l11l11_ba_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ঩"),l11l11_ba_ (u"ࠪࡷࡹࡧࡴࡪࡥࠪপ"),
                    l11l11_ba_ (u"ࠫࡹࡿࡰࡦࠩফ"),l11l11_ba_ (u"ࠬࡹࡷࡧࠩব"),l11l11_ba_ (u"࠭ࡰ࡭ࡣࡼࡩࡷ࠭ভ"),l11l11_ba_ (u"ࠧࡧ࡫࡯ࡩࠬম"),l11l11_ba_ (u"ࠨࡥࡲࡲࡹࡸ࡯࡭ࡤࡤࡶࠬয"),l11l11_ba_ (u"ࠩࡤࡨࡸ࠭র"),l11l11_ba_ (u"ࠪࡧࡿࡧࡳࠨ঱"),l11l11_ba_ (u"ࠫࡵࡵࡳࡪࡶ࡬ࡳࡳ࠭ল"),l11l11_ba_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧ঳"),l11l11_ba_ (u"࠭ࡢࡰࡶࡷࡳࡲ࠭঴"),l11l11_ba_ (u"ࠧࡶࡵࡨࡶࡆ࡭ࡥ࡯ࡶࠪ঵"),
                    l11l11_ba_ (u"ࠨ࡯ࡤࡸࡨ࡮ࠧশ"),l11l11_ba_ (u"ࠩࡳࡲ࡬࠭ষ"),l11l11_ba_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷࡳࡷ࠭স"),l11l11_ba_ (u"ࠫ࡮ࡪࠧহ"), l11l11_ba_ (u"ࠬ࠹࠷ࠨ঺"), l11l11_ba_ (u"࠭ࡲࡦࡩ࡬ࡳࡳࡹࠧ঻"), l11l11_ba_ (u"ࠧ࠱࠻়ࠪ"), l11l11_ba_ (u"ࠨࡧࡱࡥࡧࡲࡥࡥࠩঽ"), l11l11_ba_ (u"ࠩࡶࡶࡨ࠭া"), l11l11_ba_ (u"ࠪࡱࡪࡪࡩࡢࠩি")]
            l11l111ll_ba_=[l11l11_ba_ (u"ࠫ࡭ࡺࡴࡱࠩী"), l11l11_ba_ (u"ࠬࡲ࡯ࡨࡱࠪু"), l11l11_ba_ (u"࠭ࡷࡪࡦࡷ࡬ࠬূ"), l11l11_ba_ (u"ࠧࡩࡧ࡬࡫࡭ࡺࠧৃ"), l11l11_ba_ (u"ࠨࡶࡵࡹࡪ࠭ৄ"), l11l11_ba_ (u"ࠩࡶࡸࡦࡺࡩࡤࠩ৅"), l11l11_ba_ (u"ࠪࡪࡦࡲࡳࡦࠩ৆"), l11l11_ba_ (u"ࠫࡻ࡯ࡤࡦࡱࠪে"), l11l11_ba_ (u"ࠬࡶ࡬ࡢࡻࡨࡶࠬৈ"),
                l11l11_ba_ (u"࠭ࡦࡪ࡮ࡨࠫ৉"), l11l11_ba_ (u"ࠧࡵࡻࡳࡩࠬ৊"), l11l11_ba_ (u"ࠨࡴࡨ࡫࡮ࡵ࡮ࡴࠩো"), l11l11_ba_ (u"ࠩࡱࡳࡳ࡫ࠧৌ"), l11l11_ba_ (u"ࠪࡧࡿࡧࡳࠨ্"), l11l11_ba_ (u"ࠫࡪࡴࡡࡣ࡮ࡨࡨࠬৎ"), l11l11_ba_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧ৏"), l11l11_ba_ (u"࠭ࡣࡰࡰࡷࡶࡴࡲࡢࡢࡴࠪ৐"), l11l11_ba_ (u"ࠧ࡮ࡣࡷࡧ࡭࠭৑"), l11l11_ba_ (u"ࠨࡤࡲࡸࡹࡵ࡭ࠨ৒"),
                l11l11_ba_ (u"ࠩࡦࡩࡳࡺࡥࡳࠩ৓"), l11l11_ba_ (u"ࠪࡴࡴࡹࡩࡵ࡫ࡲࡲࠬ৔"), l11l11_ba_ (u"ࠫࡺࡹࡥࡳࡃࡪࡩࡳࡺࠧ৕"), l11l11_ba_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹࡵࡲࠨ৖"), l11l11_ba_ (u"࠭ࡣࡰࡰࡩ࡭࡬࠭ৗ"), l11l11_ba_ (u"ࠧࡩࡶࡰࡰࠬ৘"), l11l11_ba_ (u"ࠨࡪࡷࡱࡱ࠻ࠧ৙"), l11l11_ba_ (u"ࠩࡳࡶࡴࡼࡩࡥࡧࡵࠫ৚"), l11l11_ba_ (u"ࠪࡦࡱࡧࡣ࡬ࠩ৛"),
                l11l11_ba_ (u"ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡂ࡮࡬࡫ࡳ࠭ড়"), l11l11_ba_ (u"ࠬࡩࡡ࡯ࡈ࡬ࡶࡪࡋࡶࡦࡰࡷࡅࡕࡏࡃࡢ࡮࡯ࡷࠬঢ়"), l11l11_ba_ (u"࠭ࡵࡴࡧ࡙࠶ࡆࡖࡉࡄࡣ࡯ࡰࡸ࠭৞"), l11l11_ba_ (u"ࠧࡷࡧࡵࡸ࡮ࡩࡡ࡭ࡃ࡯࡭࡬ࡴࠧয়"), l11l11_ba_ (u"ࠨࡶ࡬ࡱࡪࡹ࡬ࡪࡦࡨࡶࡹࡵ࡯࡭ࡶ࡬ࡴࡵࡲࡵࡨ࡫ࡱࠫৠ"),
                l11l11_ba_ (u"ࠩࡲࡺࡪࡸ࡬ࡢࡻࡶࠫৡ"), l11l11_ba_ (u"ࠪࡦࡦࡩ࡫ࡨࡴࡲࡹࡳࡪࡃࡰ࡮ࡲࡶࠬৢ"), l11l11_ba_ (u"ࠫࡲࡧࡲࡨ࡫ࡱࡦࡴࡺࡴࡰ࡯ࠪৣ"), l11l11_ba_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲࡸ࠭৤"), l11l11_ba_ (u"࠭࡬ࡪࡰ࡮ࠫ৥"), l11l11_ba_ (u"ࠧࡴࡶࡵࡩࡹࡩࡨࡪࡰࡪࠫ০"), l11l11_ba_ (u"ࠨࡷࡱ࡭࡫ࡵࡲ࡮ࠩ১"), l11l11_ba_ (u"ࠩࡶࡸࡦࡺࡩࡤ࠳ࠪ২"),
                l11l11_ba_ (u"ࠪࡷࡪࡺࡵࡱࠩ৩"), l11l11_ba_ (u"ࠫ࡯ࡽࡰ࡭ࡣࡼࡩࡷ࠭৪"), l11l11_ba_ (u"ࠬࡩࡨࡦࡥ࡮ࡊࡱࡧࡳࡩࠩ৫"), l11l11_ba_ (u"࠭ࡓ࡮ࡣࡵࡸ࡙࡜ࠧ৬"), l11l11_ba_ (u"ࠧࡷ࠲࠳࠵ࠬ৭"), l11l11_ba_ (u"ࠨࡥࡵࡩࡲ࡫ࠧ৮"), l11l11_ba_ (u"ࠩࡧࡳࡨࡱࠧ৯"), l11l11_ba_ (u"ࠪࡥࡺࡺ࡯ࡴࡶࡤࡶࡹ࠭ৰ"), l11l11_ba_ (u"ࠫ࡮ࡪ࡬ࡦࡪ࡬ࡨࡪ࠭ৱ"), l11l11_ba_ (u"ࠬࡳ࡯ࡥࡧࡶࠫ৲"),
               l11l11_ba_ (u"࠭ࡦ࡭ࡣࡶ࡬ࠬ৳"), l11l11_ba_ (u"ࠧࡰࡸࡨࡶࠬ৴"), l11l11_ba_ (u"ࠨ࡮ࡨࡪࡹ࠭৵"), l11l11_ba_ (u"ࠩ࡫࡭ࡩ࡫ࠧ৶"), l11l11_ba_ (u"ࠪࡴࡱࡧࡹࡦࡴ࠸ࠫ৷"), l11l11_ba_ (u"ࠫ࡮ࡳࡡࡨࡧࠪ৸"), l11l11_ba_ (u"ࠬࡑࡌࡊࡍࡑࡍࡏ࠭৹"), l11l11_ba_ (u"࠭ࡣࡰ࡯ࡳࡥࡳ࡯࡯࡯ࡵࠪ৺"), l11l11_ba_ (u"ࠧࡳࡧࡶࡸࡴࡸࡥࠨ৻"), l11l11_ba_ (u"ࠨࡥ࡯࡭ࡨࡱࡓࡪࡩࡱࠫৼ"),
                l11l11_ba_ (u"ࠩࡶࡧ࡭࡫ࡤࡶ࡮ࡨࠫ৽"), l11l11_ba_ (u"ࠪࡣࡨࡵࡵ࡯ࡶࡧࡳࡼࡴ࡟ࠨ৾"), l11l11_ba_ (u"ࠫࡨࡵࡵ࡯ࡶࡧࡳࡼࡴࠧ৿"), l11l11_ba_ (u"ࠬࡸࡥࡨ࡫ࡲࡲࠬ਀"), l11l11_ba_ (u"࠭ࡥ࡭ࡵࡨࠫਁ"), l11l11_ba_ (u"ࠧࡤࡱࡱࡸࡷࡵ࡬ࡴࠩਂ"), l11l11_ba_ (u"ࠨࡲࡵࡩࡱࡵࡡࡥࠩਃ"), l11l11_ba_ (u"ࠩࡲࡶࡾ࡭ࡩ࡯ࡣ࡯ࡲࡪ࠭਄"), l11l11_ba_ (u"ࠪࡷࡹࡿ࡬ࡦࠩਅ"),
                l11l11_ba_ (u"ࠫ࠻࠸࠰ࡱࡺࠪਆ"), l11l11_ba_ (u"ࠬ࠹࠸࠸ࡲࡻࠫਇ"), l11l11_ba_ (u"࠭ࡰࡰࡵࡷࡩࡷ࠭ਈ"), l11l11_ba_ (u"ࠧࡻࡰ࡬࡯ࡳ࡯ࡥࠨਉ"), l11l11_ba_ (u"ࠨࡵࡨ࡯ࡺࡴࡤࠨਊ"), l11l11_ba_ (u"ࠩࡶ࡬ࡴࡽࡁࡧࡶࡨࡶࡘ࡫ࡣࡰࡰࡧࡷࠬ਋"), l11l11_ba_ (u"ࠪ࡭ࡲࡧࡧࡦࡵࠪ਌"), l11l11_ba_ (u"ࠫࡗ࡫࡫࡭ࡣࡰࡥࠬ਍"), l11l11_ba_ (u"ࠬࡹ࡫ࡪࡲࡄࡨࠬ਎"),
                 l11l11_ba_ (u"࠭࡬ࡦࡸࡨࡰࡸ࠭ਏ"), l11l11_ba_ (u"ࠧࡱࡣࡧࡨ࡮ࡴࡧࠨਐ"), l11l11_ba_ (u"ࠨࡱࡳࡥࡨ࡯ࡴࡺࠩ਑"), l11l11_ba_ (u"ࠩࡧࡩࡧࡻࡧࠨ਒"), l11l11_ba_ (u"ࠪࡺ࡮ࡪࡥࡰ࠵ࠪਓ"), l11l11_ba_ (u"ࠫࡨࡲ࡯ࡴࡧࠪਔ"), l11l11_ba_ (u"ࠬࡹ࡭ࡢ࡮࡯ࡸࡪࡾࡴࠨਕ"), l11l11_ba_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧਖ"), l11l11_ba_ (u"ࠧࡤ࡮ࡤࡷࡸ࠭ਗ"), l11l11_ba_ (u"ࠨࡣ࡯࡭࡬ࡴࠧਘ"),
                  l11l11_ba_ (u"ࠩࡱࡳࡹ࡯ࡣࡦࠩਙ"), l11l11_ba_ (u"ࠪࡱࡪࡪࡩࡢࠩਚ")]
            for l1l11lll1_ba_ in l11l111ll_ba_:
                l11ll1l1l_ba_=l11ll1l1l_ba_.replace(l1l11lll1_ba_,l11l11_ba_ (u"ࠫࠬਛ"))
            cleanup=l11ll1l1l_ba_.replace(l11l11_ba_ (u"ࠬࢂࠧਜ"),l11l11_ba_ (u"࠭ࠠࠨਝ")).split()
            out={l11l11_ba_ (u"ࠧࡴࡧࡵࡺࡪࡸࠧਞ"): l11l11_ba_ (u"ࠨࠩਟ"), l11l11_ba_ (u"ࠩࡨࠫਠ"): l11l11_ba_ (u"ࠪࠫਡ"), l11l11_ba_ (u"ࠫ࡫࡯࡬ࡦࠩਢ"): l11l11_ba_ (u"ࠬ࠭ਣ"), l11l11_ba_ (u"࠭ࡳࡵࠩਤ"): l11l11_ba_ (u"ࠧࠨਥ")}
            if len(cleanup)==4:
                print l11l11_ba_ (u"ࠨࡎࡨࡲ࡬ࡺࡨࠡࡑࡎࠫਦ")
                for l1l11lll1_ba_ in cleanup:
                    if l1l11lll1_ba_.isdigit():
                        out[l11l11_ba_ (u"ࠩࡨࠫਧ")]=l1l11lll1_ba_
                    elif re.match(l11l11_ba_ (u"ࠪ࡟ࡦ࠳ࡺ࡞ࡽ࠵࠰ࢂࡢࡤࡼ࠵ࢀࠫਨ"),l1l11lll1_ba_) and len(l1l11lll1_ba_)<10:
                        out[l11l11_ba_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࠫ਩")] = l1l11lll1_ba_
                    elif len(l1l11lll1_ba_)==22:
                        out[l11l11_ba_ (u"ࠬࡹࡴࠨਪ")] = l1l11lll1_ba_
                    else:
                        out[l11l11_ba_ (u"࠭ࡦࡪ࡮ࡨࠫਫ")] = l1l11lll1_ba_
                src=l11l11_ba_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࠦࡵ࠱ࡧࡩࡧ࠮ࡱ࡮࠲ࠩࡸ࠴࡭ࡱ࠶ࡂࡷࡹࡃࠥࡴࠨࡨࡁࠪࡹࠧਬ")%(out.get(l11l11_ba_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࠨਭ")),out.get(l11l11_ba_ (u"ࠩࡩ࡭ࡱ࡫ࠧਮ")),out.get(l11l11_ba_ (u"ࠪࡷࡹ࠭ਯ")),out.get(l11l11_ba_ (u"ࠫࡪ࠭ਰ")))
    return src
def l11ll11ll_ba_(content):
    l11l11_ba_ (u"ࠧࠨࠢࠎࠌࠣࠤࠥࠦࡓࡤࡣࡱࡷࠥ࡬࡯ࡳࠢࡹ࡭ࡩ࡫࡯ࠡ࡮࡬ࡲࡰࠦࡩ࡯ࡥ࡯ࡹࡩ࡫ࡤࠡࡧࡱࡧࡴࡪࡥࡥࠢࡲࡲࡪࠓࠊࠡࠢࠣࠤࠧࠨࠢ਱")
    l11l1l1l1_ba_=l11l11_ba_ (u"࠭ࠧਲ")
    l11l1ll1l_ba_ = re.compile(l11l11_ba_ (u"ࠧࡧ࡫࡯ࡩ࠿࡛ࠦ࡝ࠩࠥࡡ࠭࠴ࠫࡀࠫ࡞ࡠࠬࠨ࡝࠭ࠩਲ਼"),  re.DOTALL).search(content)
    l11l1llll_ba_ = re.compile(l11l11_ba_ (u"ࠨࡷࡵࡰ࠿࡛ࠦ࡝ࠩࠥࡡ࠭࠴ࠫࡀࠫ࡞ࡠࠬࠨ࡝࠭ࠩ਴"),  re.DOTALL).search(content)
    if l11l1ll1l_ba_:
        print l11l11_ba_ (u"ࠩࡩࡳࡺࡴࡤࠡࡔࡈࠤࡠ࡬ࡩ࡭ࡧ࠽ࡡࠬਵ")
        l11l1l1l1_ba_ = l11l1ll1l_ba_.group(1)
    elif l11l1llll_ba_:
        print l11l11_ba_ (u"ࠪࡪࡴࡻ࡮ࡥࠢࡕࡉࠥࡡࡵࡳ࡮࠽ࡡࠬਸ਼")
        l11l1l1l1_ba_ = l11l1llll_ba_.group(1)
    else:
        print l11l11_ba_ (u"ࠫࡪࡴࡣࡰࡦࡨࡨࠥࡀࠠࡶࡰࡳࡥࡨࡱࡥࡳࠩ਷")
        l11l1l1l1_ba_ = _11ll1l11_ba_(content)
        if not l11l1l1l1_ba_:
            print l11l11_ba_ (u"ࠬ࡫࡮ࡤࡱࡧࡩࡩࠦ࠺ࠡࡨࡲࡶࡨ࡫ࠠࠨਸ")
            l11l1l1l1_ba_ = _11l1lll1_ba_(content)
    return l11l1l1l1_ba_
def l1l1111_ba_(url):
    l11l11_ba_ (u"ࠨࠢࠣࠏࠍࠤࠥࠦࠠࡳࡧࡷࡹࡷࡴࡳࠡࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠲ࠦࡵ࡭ࡴࠣ࡬ࡹࡺࡰ࠻࠱࠲࠲࠳࠴࠮ࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠱ࠥࡵࡲࠡ࡮࡬ࡷࡹࠦ࡯ࡧࠢ࡞ࠬࠬ࠽࠲࠱ࡲࠪ࠰ࠥ࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡧࡩࡧ࠮ࡱ࡮࠲ࡺ࡮ࡪࡥࡰ࠱࠴࠽࠹࠼࠹࠺࠳ࡩࡃࡼ࡫ࡲࡴ࡬ࡤࡁ࠼࠸࠰ࡱࠩࠬ࠰࠳࠴࠮࡞ࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠓࠊࠡࠢࠣࠤࠧࠨࠢਹ")
    if l11l11_ba_ (u"ࠧࡦࡤࡧ࠲ࡨࡪࡡ࠯ࡲ࡯ࠫ਺") in url:
        id = url.split(l11l11_ba_ (u"ࠨ࠱ࠪ਻"))[-1]
        url = l11l11_ba_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡣࡥࡣ࠱ࡴࡱ࠵ࡶࡪࡦࡨࡳ࠴ࠫࡳࠨ਼")%id
    l11l1l11l_ba_=l11l11_ba_ (u"ࠪࢀࡈࡵ࡯࡬࡫ࡨࡁࠧࡖࡈࡑࡕࡈࡗࡘࡏࡄ࠾࠳ࠩࡖࡪ࡬ࡥࡳࡧࡵࡁ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡺࡡࡵ࡫ࡦ࠲ࡨࡪࡡ࠯ࡲ࡯࠳ࡵࡲࡡࡺࡧࡵ࠹࠳࠿࠯ࡱ࡮ࡤࡽࡪࡸ࠮ࡴࡹࡩࠫ਽")
    l11l11ll1_ba_=l11l11_ba_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࡨࡵࡶࡳ࠾࠴࠵ࡳࡵࡣࡷ࡭ࡨ࠴ࡣࡥࡣ࠱ࡴࡱ࠵ࡰ࡭ࡣࡼࡩࡷ࠻࠮࠺࠱ࡳࡰࡦࡿࡥࡳ࠰ࡶࡻ࡫࠭ਾ")
    print url
    content = l1l11l111_ba_(url)
    src=[]
    if not l11l11_ba_ (u"ࠬࡅࡷࡦࡴࡶ࡮ࡦ࠭ਿ") in url:
         l11l1l111_ba_ = re.compile(l11l11_ba_ (u"࠭࠼ࡢࠢࡧࡥࡹࡧ࠭ࡲࡷࡤࡰ࡮ࡺࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࠫࡃࡕࡂࡈ࠿࠰࠭ࡃ࠮ࡄࠨࡀࡒ࠿ࡕࡃ࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧੀ"), re.DOTALL).findall(content)
         for quality in l11l1l111_ba_:
             l1l1l1l_ba_ = re.search(l11l11_ba_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ੁ"),quality[1])
             l11l11l11_ba_ = quality[2]
             src.insert(0,(l11l11l11_ba_,l1l11111l_ba_+l1l1l1l_ba_.group(1)))
    if not src:
        src = l11ll11ll_ba_(content)
        if src:
            src+=l11l1l11l_ba_+l11l11ll1_ba_
    return src
def l11ll111l_ba_(url,quality=0):
    l11l11_ba_ (u"ࠣࠤࠥࠑࠏࠦࠠࠡࠢࡵࡩࡹࡻࡲ࡯ࡵࠣࡹࡷࡲࠠࡵࡱࠣࡺ࡮ࡪࡥࡰࠏࠍࠤࠥࠦࠠࠣࠤࠥੂ")
    src = l1l1111_ba_(url)
    if type(src)==list:
        selected=src[quality]
        print l11l11_ba_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࠣ࠾ࠬ੃"),selected[0]
        src = l1l1111_ba_(selected[1])
    return src
