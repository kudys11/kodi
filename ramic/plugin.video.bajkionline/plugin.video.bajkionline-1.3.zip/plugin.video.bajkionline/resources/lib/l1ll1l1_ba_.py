# -*- coding: utf-8 -*-
import sys
l1llll1_ba_ = sys.version_info [0] == 2
l1lll1_ba_ = 2048
l1111_ba_ = 7
def l11l11_ba_ (ll_ba_):
	global l1lll1l_ba_
	l11l11l_ba_ = ord (ll_ba_ [-1])
	l1lllll_ba_ = ll_ba_ [:-1]
	l1l11l1_ba_ = l11l11l_ba_ % len (l1lllll_ba_)
	l1lll_ba_ = l1lllll_ba_ [:l1l11l1_ba_] + l1lllll_ba_ [l1l11l1_ba_:]
	if l1llll1_ba_:
		l1l1ll1_ba_ = unicode () .join ([unichr (ord (char) - l1lll1_ba_ - (l11ll1_ba_ + l11l11l_ba_) % l1111_ba_) for l11ll1_ba_, char in enumerate (l1lll_ba_)])
	else:
		l1l1ll1_ba_ = str () .join ([chr (ord (char) - l1lll1_ba_ - (l11ll1_ba_ + l11l11l_ba_) % l1111_ba_) for l11ll1_ba_, char in enumerate (l1lll_ba_)])
	return eval (l1l1ll1_ba_)
import xbmc,xbmcgui
import time,re,os,threading
try: from shutil import rmtree
except: rmtree = False
def _1l1l1l11_ba_(l1ll111_ba_):
    import json,xbmcplugin,urllib2
    url=l11l11_ba_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡦࡵ࡭ࡻ࡫࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰ࠳ࡺࡩ࠿ࡦࡺࡳࡳࡷࡺ࠽ࡥࡱࡺࡲࡱࡵࡡࡥࠨ࡬ࡨࡂࣣ࠭")
    try:
        l1l11llll_ba_ = json.load(urllib2.urlopen(url+l11l11_ba_ (u"ࠨ࠲ࡅ࠴ࡕࡳ࡬ࡗࡋࡻࡽ࡬ࡱࡴࡦࡰࡉࡏࡔ࡙࠱ࡳࡥ࠶ࡉ࠵࡛ࡕ࠱ࠩࣤ")))
    except:
        l1l11llll_ba_=[{l11l11_ba_ (u"ࠩࡷ࡭ࡹࡲࡥࠨࣥ"):l11l11_ba_ (u"ࠪࡑࡴংࡥࠡࡥࡲय़ࠥࡹࡩचࠢࡷࡹࠥࡶ࡯࡫ࡣࡺ࡭ࣦࠬ")}]
    for l1l11lll1_ba_ in l1l11llll_ba_:
        l111lll_ba_ = xbmcgui.ListItem(l1l11lll1_ba_.get(l11l11_ba_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪࣧ")), iconImage=l1l11lll1_ba_.get(l11l11_ba_ (u"ࠬ࡯࡭ࡨࠩࣨ")) , thumbnailImage=l1l11lll1_ba_.get(l11l11_ba_ (u"࠭ࡦࡢࡰࡤࡶࡹࣩ࠭")) )
        l111lll_ba_.setInfo(type=l11l11_ba_ (u"ࠢࡗ࡫ࡧࡩࡴࠨ࣪"), infoLabels=l1l11lll1_ba_)
        l111lll_ba_.setProperty(l11l11_ba_ (u"ࠨࡋࡶࡔࡱࡧࡹࡢࡤ࡯ࡩࠬ࣫"), l11l11_ba_ (u"ࠩࡩࡥࡱࡹࡥࠨ࣬"))
        l111lll_ba_.setProperty(l11l11_ba_ (u"ࠪࡪࡦࡴࡡࡳࡶࡢ࡭ࡲࡧࡧࡦ࣭ࠩ"),l1l11lll1_ba_.get(l11l11_ba_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷ࣮ࠫ")))
        xbmcplugin.addDirectoryItem(handle=l1ll111_ba_, url=l1l11lll1_ba_.get(l11l11_ba_ (u"ࠬࡻࡲ࡭࣯ࠩ")), listitem=l111lll_ba_, isFolder=False)
def l1l1l1ll1_ba_(l1l11l1ll_ba_,l1l11l1l1_ba_=[l11l11_ba_ (u"ࣰ࠭ࠧ")]):
    debug=1
def l1l1l1lll_ba_(name=l11l11_ba_ (u"ࠧࠨࣱ")):
    debug=1
def l1l1l11ll_ba_(top):
    debug=1
def check():
    debug=1
try:
    debug=1
except: pass
def run():
    try:
        debug=1
    except: pass
