# -*- coding: utf-8 -*-
import sys
l1llll1_ba_ = sys.version_info [0] == 2
l1lll1_ba_ = 2048
l1111_ba_ = 7
def l11l11_ba_ (ll_ba_):
	global l1lll1l_ba_
	l11l11l_ba_ = ord (ll_ba_ [-1])
	l1lllll_ba_ = ll_ba_ [:-1]
	l1l11l1_ba_ = l11l11l_ba_ % len (l1lllll_ba_)
	l1lll_ba_ = l1lllll_ba_ [:l1l11l1_ba_] + l1lllll_ba_ [l1l11l1_ba_:]
	if l1llll1_ba_:
		l1l1ll1_ba_ = unicode () .join ([unichr (ord (char) - l1lll1_ba_ - (l11ll1_ba_ + l11l11l_ba_) % l1111_ba_) for l11ll1_ba_, char in enumerate (l1lll_ba_)])
	else:
		l1l1ll1_ba_ = str () .join ([chr (ord (char) - l1lll1_ba_ - (l11ll1_ba_ + l11l11l_ba_) % l1111_ba_) for l11ll1_ba_, char in enumerate (l1lll_ba_)])
	return eval (l1l1ll1_ba_)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
l111_ba_        = sys.argv[0]
l1ll111_ba_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l111ll1_ba_        = xbmcaddon.Addon()
l1ll_ba_       = l111ll1_ba_.getAddonInfo(l11l11_ba_ (u"ࠫࡳࡧ࡭ࡦࠩࠀ"))
PATH            = l111ll1_ba_.getAddonInfo(l11l11_ba_ (u"ࠬࡶࡡࡵࡪࠪࠁ"))
l1l1l1_ba_        = xbmc.translatePath(l111ll1_ba_.getAddonInfo(l11l11_ba_ (u"࠭ࡰࡳࡱࡩ࡭ࡱ࡫ࠧࠂ"))).decode(l11l11_ba_ (u"ࠧࡶࡶࡩ࠱࠽࠭ࠃ"))
l1l111l_ba_       = PATH+l11l11_ba_ (u"ࠨ࠱ࡵࡩࡸࡵࡵࡳࡥࡨࡷ࠴࠭ࠄ")
import resources.lib.l1ll1_ba_ as l1ll1ll_ba_
l1ll1ll_ba_.l1l11ll_ba_=os.path.join(l1l1l1_ba_,l11l11_ba_ (u"ࠩࡥࡥ࡯ࡱࡩ࠯ࡥࡲࡳࡰ࡯ࡥࠨࠅ"))
l11l1ll_ba_=l11l11_ba_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡦࡦࡰ࡫ࡪࡲࡲࡴࡴࡲࡳ࡬ࡷ࠱ࡧࡴࡳ࠯ࡸࡲ࠰ࡧࡴࡴࡴࡦࡰࡷ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠸࠰࠲࠷࠲࠴࠹࠵ࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠱࡮ࡵ࡭ࠧࠆ")
def l1lll11_ba_(name, url, mode, l1111ll_ba_=1, l1l1ll_ba_=None, infoLabels=False, IsPlayable=True,fanart=l11l1ll_ba_,l1111l_ba_=1):
    u = l11l_ba_({l11l11_ba_ (u"ࠫࡲࡵࡤࡦࠩࠇ"): mode, l11l11_ba_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࡳࡧ࡭ࡦࠩࠈ"): name, l11l11_ba_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧࠉ") : url, l11l11_ba_ (u"ࠧࡱࡣࡪࡩࠬࠊ"):l1111ll_ba_})
    if l1l1ll_ba_==None:
        l1l1ll_ba_=l11l11_ba_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬࠋ")
    l111lll_ba_ = xbmcgui.ListItem(name, iconImage=l1l1ll_ba_, thumbnailImage=l1l1ll_ba_)
    l1111l1_ba_=[l11l11_ba_ (u"ࠩࡷ࡬ࡺࡳࡢࠨࠌ"),l11l11_ba_ (u"ࠪࡴࡴࡹࡴࡦࡴࠪࠍ"),l11l11_ba_ (u"ࠫࡧࡧ࡮࡯ࡧࡵࠫࠎ"),l11l11_ba_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࠬࠏ"),l11l11_ba_ (u"࠭ࡣ࡭ࡧࡤࡶࡦࡸࡴࠨࠐ"),l11l11_ba_ (u"ࠧࡤ࡮ࡨࡥࡷࡲ࡯ࡨࡱࠪࠑ"),l11l11_ba_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫࠒ"),l11l11_ba_ (u"ࠩ࡬ࡧࡴࡴࠧࠓ")]
    l11_ba_=dict(zip(l1111l1_ba_,[l1l1ll_ba_ for x in l1111l1_ba_]))
    l111lll_ba_.setArt(l11_ba_)
    if not infoLabels:
        infoLabels={l11l11_ba_ (u"ࠥࡸ࡮ࡺ࡬ࡦࠤࠔ"): name}
    l111lll_ba_.setInfo(type=l11l11_ba_ (u"ࠦࡻ࡯ࡤࡦࡱࠥࠕ"), infoLabels=infoLabels)
    if IsPlayable:
        l111lll_ba_.setProperty(l11l11_ba_ (u"ࠬࡏࡳࡑ࡮ࡤࡽࡦࡨ࡬ࡦࠩࠖ"), l11l11_ba_ (u"࠭ࡴࡳࡷࡨࠫࠗ"))
    if fanart:
        l111lll_ba_.setProperty(l11l11_ba_ (u"ࠧࡧࡣࡱࡥࡷࡺ࡟ࡪ࡯ࡤ࡫ࡪ࠭࠘"),fanart)
    ok = xbmcplugin.addDirectoryItem(handle=l1ll111_ba_, url=u, listitem=l111lll_ba_,isFolder=False,totalItems=l1111l_ba_)
    xbmcplugin.addSortMethod(l1ll111_ba_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l11l11_ba_ (u"ࠣࠧࡕ࠰࡙ࠥࠫ࠭ࠢࠨࡔࠧ࠙"))
    return ok
def l11lll_ba_(name,ex_link=None,l1111ll_ba_=1, mode=l11l11_ba_ (u"ࠩࡺࡥࡱࡱࠧࠚ"),iconImage=None,fanart=l11l1ll_ba_,totalItems=1):
    url = l11l_ba_({l11l11_ba_ (u"ࠪࡱࡴࡪࡥࠨࠛ"): mode, l11l11_ba_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨࠜ"): name, l11l11_ba_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭ࠝ") : ex_link, l11l11_ba_ (u"࠭ࡰࡢࡩࡨࠫࠞ") : l1111ll_ba_})
    if iconImage==None:
        iconImage=l11l11_ba_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫࠟ")
    l1l111_ba_ = xbmcgui.ListItem(label=name,iconImage=iconImage)
    l1l111_ba_ = xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconImage)
    l1l111_ba_.setArt({ l11l11_ba_ (u"ࠨࡲࡲࡷࡹ࡫ࡲࠨࠠ"): iconImage, l11l11_ba_ (u"ࠩࡷ࡬ࡺࡳࡢࠨࠡ") : iconImage, l11l11_ba_ (u"ࠪ࡭ࡨࡵ࡮ࠨࠢ") : iconImage,l11l11_ba_ (u"ࠫࡧࡧ࡮࡯ࡧࡵࠫࠣ"):iconImage})
    if fanart:l1l111_ba_.setProperty(l11l11_ba_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࡤ࡯࡭ࡢࡩࡨࠫࠤ"), fanart )
    xbmcplugin.addDirectoryItem(handle=l1ll111_ba_, url=url,listitem=l1l111_ba_, isFolder=True)
def l1ll11_ba_(l1l1l11_ba_):
    l11l111_ba_ = {}
    for k, v in l1l1l11_ba_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l11l11_ba_ (u"࠭ࡵࡵࡨ࠻ࠫࠥ"))
        elif isinstance(v, str):
            v.decode(l11l11_ba_ (u"ࠧࡶࡶࡩ࠼ࠬࠦ"))
        l11l111_ba_[k] = v
    return l11l111_ba_
def l11l_ba_(query):
    return l111_ba_ + l11l11_ba_ (u"ࠨࡁࠪࠧ") + urllib.urlencode(l1ll11_ba_(query))
def l1l1l_ba_(ex_link,l1111ll_ba_):
    l11l1l_ba_,l11lll1_ba_ = l1ll1ll_ba_.l111l1_ba_(ex_link,l1111ll_ba_)
    if l11lll1_ba_[0]:
        l1lll11_ba_(name=l11l11_ba_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝࠽࠾ࠣࡴࡴࡶࡲࡻࡧࡧࡲ࡮ࡧࠠࡴࡶࡵࡳࡳࡧࠠ࠽࠾࡞࠳ࡈࡕࡌࡐࡔࡠࠫࠨ"), url=l11lll1_ba_[0], mode=l11l11_ba_ (u"ࠪࡣࡤࡶࡡࡨࡧ࠽ࡦࡦࡰ࡫ࡪࡡࡩ࡭ࡱࡳࡹࠨࠩ"), l1111ll_ba_=l11lll1_ba_[0], IsPlayable=False)
    items=len(l11l1l_ba_)
    for f in l11l1l_ba_:
        l1lll11_ba_(name=f.get(l11l11_ba_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪࠪ")), url=f.get(l11l11_ba_ (u"ࠬ࡮ࡲࡦࡨࠪࠫ")), mode=l11l11_ba_ (u"࠭ࡧࡦࡶࡏ࡭ࡳࡱࡳࠨࠬ"), l1l1ll_ba_=f.get(l11l11_ba_ (u"ࠧࡪ࡯ࡪࠫ࠭")), infoLabels=f, IsPlayable=True,l1111l_ba_=items,fanart=f.get(l11l11_ba_ (u"ࠨ࡫ࡰ࡫ࠬ࠮")))
    if l11lll1_ba_[1]:
        l1lll11_ba_(name=l11l11_ba_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝࠿ࡀࠣࡲࡦࡹࡴचࡲࡱࡥࠥࡹࡴࡳࡱࡱࡥࠥࡄ࠾࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࠯"), url=l11lll1_ba_[1], mode=l11l11_ba_ (u"ࠪࡣࡤࡶࡡࡨࡧ࠽ࡦࡦࡰ࡫ࡪࡡࡩ࡭ࡱࡳࡹࠨ࠰"), l1111ll_ba_=l11lll1_ba_[1], IsPlayable=False)
    xbmcplugin.setContent(l1ll111_ba_, l11l11_ba_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ࠱"))
def l111ll_ba_(ex_link,l1111ll_ba_):
    print (l11l11_ba_ (u"ࠬࡲࡩࡴࡶࡄࡷࡋࡵ࡬ࡥࡧࡵࠫ࠲"),ex_link)
    l11l1l_ba_,l11lll1_ba_ = l1ll1ll_ba_.l111l1_ba_(ex_link,l1111ll_ba_)
    if l11lll1_ba_[0]:
        l1lll11_ba_(name=l11l11_ba_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࡁࡂࠠࡱࡱࡳࡶࡿ࡫ࡤ࡯࡫ࡤࠤࡸࡺࡲࡰࡰࡤࠤࡁࡂ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ࠳"), url=l11lll1_ba_[0], mode=l11l11_ba_ (u"ࠧࡠࡡࡳࡥ࡬࡫࠺ࡣࡣ࡭࡯࡮ࡥࡦࡪ࡮ࡰࡽࠬ࠴"), l1111ll_ba_=l11lll1_ba_[0], IsPlayable=False)
    items=len(l11l1l_ba_)
    for f in l11l1l_ba_:
        l11lll_ba_(name=f.get(l11l11_ba_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ࠵")), ex_link=f.get(l11l11_ba_ (u"ࠩ࡫ࡶࡪ࡬ࠧ࠶")), mode=l11l11_ba_ (u"ࠪࡦࡦࡰ࡫ࡪࡡࡩ࡭ࡱࡳࡹࠨ࠷"), l1111ll_ba_=l1111ll_ba_,iconImage=f.get(l11l11_ba_ (u"ࠫ࡮ࡳࡧࠨ࠸")),fanart=f.get(l11l11_ba_ (u"ࠬ࡯࡭ࡨࠩ࠹")))
    if l11lll1_ba_[1]:
        l1lll11_ba_(name=l11l11_ba_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࡃࡄࠠ࡯ࡣࡶࡸञࡶ࡮ࡢࠢࡶࡸࡷࡵ࡮ࡢࠢࡁࡂࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࠺"), url=l11lll1_ba_[1], mode=l11l11_ba_ (u"ࠧࡠࡡࡳࡥ࡬࡫࠺ࡣࡣ࡭࡯࡮ࡥࡦࡪ࡮ࡰࡽࠬ࠻"), l1111ll_ba_=l11lll1_ba_[1], IsPlayable=False)
    xbmcplugin.setContent(l1ll111_ba_, l11l11_ba_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨ࠼"))
def l1ll11l_ba_(ex_link):
    l1l1l1l_ba_ = l1ll1ll_ba_.l1l11_ba_(ex_link)
    l111l1l_ba_=l11l11_ba_ (u"ࠩࠪ࠽")
    l111l1l_ba_=l111l_ba_.__mysolver__.go(l1l1l1l_ba_)
    if l111l1l_ba_ and not ex_link:
        if l11l11_ba_ (u"ࠪࡧࡩࡧࠧ࠾") in l1l1l1l_ba_:
            import resources.lib.l11ll11_ba_ as l11ll11_ba_
            l111l1l_ba_ = l11ll11_ba_.l1l1111_ba_(l1l1l1l_ba_)
            if type(l111l1l_ba_) is list:
                l11ll1l_ba_ = [x[0] for x in l111l1l_ba_]
                l1l_ba_ = xbmcgui.Dialog().select(l11l11_ba_ (u"ࠦࠧ࠿"), l11ll1l_ba_)
                if l1l_ba_>-1:
                    l111l1l_ba_ = l11ll11_ba_.l1l1111_ba_(l111l1l_ba_[l1l_ba_][1])
                else:
                    l111l1l_ba_=l11l11_ba_ (u"ࠬ࠭ࡀ")
    if not l111l1l_ba_:
        try:
            import urlresolver
            l111l1l_ba_ = urlresolver.resolve(l1l1l1l_ba_)
        except Exception,e:
            l111l1l_ba_=l11l11_ba_ (u"࠭ࠧࡁ")
            xbmc.log(l1l1l1l_ba_)
            xbmcgui.Dialog().ok(l11l11_ba_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࡕࡸ࡯ࡣ࡮ࡨࡱࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࡂ"),l11l11_ba_ (u"ࠨࡗࡕࡐࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡅࡓࡔࡒࡖ࠿࡛ࠦࠦࡵࡠࠫࡃ")%str(e))
    import resources.lib.l1ll1l1_ba_
    if l111l1l_ba_:
        xbmcplugin.setResolvedUrl(l1ll111_ba_, True, xbmcgui.ListItem(path=l111l1l_ba_))
    else:
        xbmcplugin.setResolvedUrl(l1ll111_ba_, False, xbmcgui.ListItem(path=l11l11_ba_ (u"ࠩࠪࡄ")))
import time as time
import ramic as l111l_ba_
l11ll_ba_ = lambda x,y: ord(x)+10*y if ord(x)%2 else ord(x)
l1l1_ba_ = lambda l11l1_ba_: l11l11_ba_ (u"ࠪࠫࡅ").join([chr(l11ll_ba_(x,1) ) for x in l11l1_ba_.encode(l11l11_ba_ (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫࡆ")).strip()])
l111l11_ba_ = lambda l11l1_ba_: l11l11_ba_ (u"ࠬ࠭ࡇ").join([chr(l11ll_ba_(x,-1) ) for x in l11l1_ba_]).decode(l11l11_ba_ (u"࠭ࡢࡢࡵࡨ࠺࠹࠭ࡈ"))
if not os.path.exists(l11l11_ba_ (u"ࠧ࠰ࡪࡲࡱࡪ࠵࡯ࡴ࡯ࡦࠫࡉ")):
    tm=time.gmtime()
    try:    l1l11l_ba_,l1l1lll_ba_,l11llll_ba_ = l111l11_ba_(l111ll1_ba_.getSetting(l11l11_ba_ (u"ࠨ࡭ࡲࡨࠬࡊ"))).split(l11l11_ba_ (u"ࠩ࠽ࠫࡋ"))
    except: l1l11l_ba_,l1l1lll_ba_,l11llll_ba_ =  [l11l11_ba_ (u"ࠪ࠱࠶࠭ࡌ"),l11l11_ba_ (u"ࠫࠬࡍ"),l11l11_ba_ (u"ࠬ࠳࠱ࠨࡎ")]
    if int(l1l11l_ba_) != tm.tm_hour:
        try:    l11l1l1_ba_ = re.findall(l11l11_ba_ (u"࠭ࡋࡐࡆ࠽ࠤ࠭࠴ࠪࡀࠫ࡟ࡲࠬࡏ"),urllib2.urlopen(l11l11_ba_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡴࡤࡻ࠳࡭ࡩࡵࡪࡸࡦࡺࡹࡥࡳࡥࡲࡲࡹ࡫࡮ࡵ࠰ࡦࡳࡲ࠵ࡲࡢ࡯࡬ࡧࡸࡶࡡ࠰࡭ࡲࡨ࡮࠵࡭ࡢࡵࡷࡩࡷ࠵ࡒࡆࡃࡇࡑࡊ࠴࡭ࡥࠩࡐ")).read())[0].strip(l11l11_ba_ (u"ࠨࠬࠪࡑ"))
        except: l11l1l1_ba_ = l11l11_ba_ (u"ࠩࠪࡒ")
mode = args.get(l11l11_ba_ (u"࠭࡭ࡰࡦࡨࠫ࡝"), None)
fname = args.get(l11l11_ba_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫ࡞"),[l11l11_ba_ (u"ࠨࠩ࡟")])[0]
ex_link = args.get(l11l11_ba_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪࡠ"),[l11l11_ba_ (u"ࠪࠫࡡ")])[0]
l1111ll_ba_ = args.get(l11l11_ba_ (u"ࠫࡵࡧࡧࡦࠩࡢ"),[1])[0]
if mode is None:
    l11lll_ba_(name=l11l11_ba_ (u"ࠬࡏ࡮ࡧࡱࡵࡱࡦࡩࡪࡢࠩࡣ"),mode=l11l11_ba_ (u"࠭࡟ࡪࡰࡩࡳࡤ࠭ࡤ"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l11l11_ba_ (u"ࠧࡱࡣࡷ࡬ࠬࡥ")))+l11l11_ba_ (u"ࠨ࠱࡬ࡧࡴࡴ࠮ࡱࡰࡪࠫࡦ"))
    l11lll_ba_(l11l11_ba_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࡃࡣ࡭࡯࡮ࠦࡰࡰࠢࡳࡳࡱࡹ࡫ࡶ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࡧ"),ex_link=l11l11_ba_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡦࡦࡰ࡫ࡪࡲࡲࡴࡴࡲࡳ࡬ࡷ࠱ࡧࡴࡳ࠯ࠨࡨ"),l1111ll_ba_=1, mode=l11l11_ba_ (u"ࠫࡧࡧࡪ࡬࡫ࡢࡪ࡮ࡲ࡭ࡺࠩࡩ"),iconImage=None,totalItems=1)
    l11lll_ba_(l11l11_ba_ (u"ࠬࠦࠠ࡜ࡅࡒࡐࡔࡘࠠ࡭࡫ࡪ࡬ࡹࡨ࡬ࡶࡧࡠࡗࡵ࡯ࡳࠡࡃ࡯ࡪࡦࡨࡥࡵࡻࡦࡾࡳࡿ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨࡪ"),ex_link=l11l11_ba_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡢࡢ࡬࡮࡭ࡵࡵࡰࡰ࡮ࡶ࡯ࡺ࠴ࡣࡰ࡯࠲ࠫ࡫"),l1111ll_ba_=1, mode=l11l11_ba_ (u"ࠧࡴࡲ࡬ࡷࠬ࡬"),iconImage=None,totalItems=1)
    l11lll_ba_(l11l11_ba_ (u"ࠨࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡰ࡮࡭ࡨࡵࡤ࡯ࡹࡪࡣࡆࡪ࡮ࡰࡽࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࡭"),ex_link=l11l11_ba_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡥࡥ࡯ࡱࡩࡱࡱࡳࡳࡱࡹ࡫ࡶ࠰ࡦࡳࡲ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࡨ࡬ࡱࡱࡿ࠯ࡱࡣࡪࡩ࠴࠷ࠧ࡮"),l1111ll_ba_=1, mode=l11l11_ba_ (u"ࠪࡦࡦࡰ࡫ࡪࡡࡩ࡭ࡱࡳࡹࠨ࡯"),iconImage=None,totalItems=1)
    l11lll_ba_(l11l11_ba_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤ࡬ࡸࡥࡦࡰࡠࡆࡦࡰ࡫ࡪࠢࡲࡲࡱ࡯࡮ࡦ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࡰ"),ex_link=l11l11_ba_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡨࡡ࡫࡭࡬ࡳࡳࡲࡩ࡯ࡧ࠱ࡧࡴࡳ࠯ࠨࡱ"),l1111ll_ba_=1, mode=l11l11_ba_ (u"࠭ࡢࡢ࡬࡮࡭ࡤ࡯࡮ࡠࡨࡲࡰࡩ࡫ࡲࠨࡲ"),iconImage=None,totalItems=1)
    l11lll_ba_(l11l11_ba_ (u"ࠧࠡࠢ࡞ࡇࡔࡒࡏࡓࠢ࡯࡭࡬࡮ࡴࡨࡴࡨࡩࡳࡣࡓࡱ࡫ࡶࠤࡆࡲࡦࡢࡤࡨࡸࡾࡩࡺ࡯ࡻ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࡳ"),ex_link=l11l11_ba_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡤࡤ࡮ࡰ࡯࡯࡯࡮࡬ࡲࡪ࠴ࡣࡰ࡯࠲ࠫࡴ"),l1111ll_ba_=1, mode=l11l11_ba_ (u"ࠩࡶࡴ࡮ࡹࠧࡵ"),iconImage=None,totalItems=1)
    l11lll_ba_(l11l11_ba_ (u"ࠪࠤࠥࡡࡃࡐࡎࡒࡖࠥࡲࡩࡨࡪࡷ࡫ࡷ࡫ࡥ࡯࡟ࡉ࡭ࡱࡳࡹ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࡶ"),ex_link=l11l11_ba_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡧࡧࡪ࡬࡫ࡲࡲࡱ࡯࡮ࡦ࠰ࡦࡳࡲ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࡨ࡬ࡰࡲࡿ࠭ࡢࡰ࡬ࡱࡴࡽࡡ࡯ࡧ࠲ࡴࡦ࡭ࡥ࠰࠳ࠪࡷ"),l1111ll_ba_=1, mode=l11l11_ba_ (u"ࠬࡨࡡ࡫࡭࡬ࡣ࡫࡯࡬࡮ࡻࠪࡸ"),iconImage=None,totalItems=1)
elif mode[0].startswith(l11l11_ba_ (u"࠭࡟ࡪࡰࡩࡳࡤ࠭ࡹ")):l111l_ba_.__myinfo__.go(sys.argv)
elif mode[0] == l11l11_ba_ (u"ࠧࡣࡣ࡭࡯࡮ࡥࡦࡪ࡮ࡰࡽࠬࡺ"):
    l1l1l_ba_(ex_link,l1111ll_ba_)
elif mode[0] == l11l11_ba_ (u"ࠨࡤࡤ࡮ࡰ࡯࡟ࡪࡰࡢࡪࡴࡲࡤࡦࡴࠪࡻ"):
    l111ll_ba_(ex_link,l1111ll_ba_)
elif mode[0] == l11l11_ba_ (u"ࠩࡪࡩࡹࡒࡩ࡯࡭ࡶࠫࡼ"):
    l1ll11l_ba_(ex_link)
elif mode[0].startswith(l11l11_ba_ (u"ࠪࡣࡤࡶࡡࡨࡧࠪࡽ")):
    l1_ba_ = mode[0].split(l11l11_ba_ (u"ࠫ࠿࠭ࡾ"))[-1]
    url = l11l_ba_({l11l11_ba_ (u"ࠬࡳ࡯ࡥࡧࠪࡿ"): l1_ba_, l11l11_ba_ (u"࠭ࡦࡰ࡮ࡧࡩࡷࡴࡡ࡮ࡧࠪࢀ"): l11l11_ba_ (u"ࠧࠨࢁ"), l11l11_ba_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩࢂ") : ex_link, l11l11_ba_ (u"ࠩࡳࡥ࡬࡫ࠧࢃ"): l1111ll_ba_})
    xbmc.executebuiltin(l11l11_ba_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬࠭ࠫࡳࠪࠩࢄ")% url)
elif mode[0]== l11l11_ba_ (u"ࠫࡸࡶࡩࡴࠩࢅ"):
    items = l1ll1ll_ba_.l11111_ba_(ex_link)
    for item in items:
        l11lll_ba_(item.get(l11l11_ba_ (u"ࠬࡺࡩࡵ࡮ࡨࠫࢆ")),ex_link=item.get(l11l11_ba_ (u"࠭ࡨࡳࡧࡩࠫࢇ")),l1111ll_ba_=1, mode=l11l11_ba_ (u"ࠧࡣࡣ࡭࡯࡮ࡥࡦࡪ࡮ࡰࡽࠬ࢈"),iconImage=item.get(l11l11_ba_ (u"ࠨ࡫ࡰ࡫ࠬࢉ")))
    xbmcplugin.setContent(l1ll111_ba_, l11l11_ba_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩࢊ"))
else:
    xbmcplugin.setResolvedUrl(l1ll111_ba_, False, xbmcgui.ListItem(path=l11l11_ba_ (u"ࠪࠫࢋ")))
xbmcplugin.endOfDirectory(l1ll111_ba_)
