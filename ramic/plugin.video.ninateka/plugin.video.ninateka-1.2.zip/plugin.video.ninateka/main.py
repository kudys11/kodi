# -*- coding: utf-8 -*-
import sys
l1ll1_nktv_ = sys.version_info [0] == 2
l111_nktv_ = 2048
l1l1l_nktv_ = 7
def l1l11_nktv_ (keyedStringLiteral):
	global l11ll_nktv_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll1_nktv_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111_nktv_ - (charIndex + stringNr) % l1l1l_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111_nktv_ - (charIndex + stringNr) % l1l1l_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import ramic as l1111l_nktv_
l1ll111_nktv_        = sys.argv[0]
l11lll1_nktv_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l1lll1ll_nktv_        = xbmcaddon.Addon()
import time,threading
try: from shutil import rmtree
except: rmtree = False
def l1l_nktv_(l1111_nktv_,l1llll_nktv_=[l1l11_nktv_ (u"ࠧࠨ࠭")]):
    debug=1
def l1_nktv_(name=l1l11_nktv_ (u"ࠨࠩ࠮")):
    debug=1
def l1ll_nktv_(top):
    debug=1
def check():
    debug=1
def run():
    try:
        debug=1
    except: pass
run()
l11lll_nktv_ = lambda x,y: ord(x)+8*y if ord(x)%2 else ord(x)
l1ll1ll1_nktv_ = lambda l111l1_nktv_: l1l11_nktv_ (u"࡙ࠩࠪ").join([chr(l11lll_nktv_(x,1) ) for x in l111l1_nktv_.encode(l1l11_nktv_ (u"ࠪࡦࡦࡹࡥ࠷࠶࡚ࠪ")).strip()])
l1l1l1_nktv_ = lambda l111l1_nktv_: l1ll1ll1_nktv_(l111l1_nktv_).encode(l1l11_nktv_ (u"ࠫ࡭࡫ࡸࠨ࡛"))
l1l1l1l_nktv_ = lambda l111l1_nktv_: l1l11_nktv_ (u"ࠬ࠭࡜").join([chr(l11lll_nktv_(x,-1) ) for x in l111l1_nktv_]).decode(l1l11_nktv_ (u"࠭ࡢࡢࡵࡨ࠺࠹࠭࡝"))
l1lll11l_nktv_ = lambda l111l1_nktv_: l1l1l1l_nktv_(l111l1_nktv_.decode(l1l11_nktv_ (u"ࠧࡩࡧࡻࠫ࡞")))
if not os.path.exists(l1l11_nktv_ (u"ࠨ࠱࡫ࡳࡲ࡫࠯ࡰࡵࡰࡧࠬ࡟")):
    tm=time.gmtime()
    try:    l1l1lll_nktv_,l11l11l_nktv_,l1ll11l_nktv_ = l1lll11l_nktv_(l1lll1ll_nktv_.getSetting(l1l11_nktv_ (u"ࠩ࡮ࡳࡩ࠭ࡠ"))).split(l1l11_nktv_ (u"ࠪ࠾ࠬࡡ"))
    except: l1l1lll_nktv_,l11l11l_nktv_,l1ll11l_nktv_ =  [l1l11_nktv_ (u"ࠫ࠲࠷ࠧࡢ"),l1l11_nktv_ (u"ࠬ࠭ࡣ"),l1l11_nktv_ (u"࠭࠭࠲ࠩࡤ")]
    if int(l1l1lll_nktv_) != tm.tm_hour:
        try:    l11llll_nktv_ = re.findall(l1l11_nktv_ (u"ࠧࡌࡑࡇ࠾ࠥ࠮࠮ࠫࡁࠬࡠࡳ࠭ࡥ"),urllib2.urlopen(l1l11_nktv_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡹࡧࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳ࠯ࡳࡣࡰ࡭ࡨࡹࡰࡢ࠱࡮ࡳࡩ࡯࠯࡮ࡣࡶࡸࡪࡸ࠯ࡓࡇࡄࡈࡒࡋ࠮࡮ࡦࠪࡦ")).read())[0].strip(l1l11_nktv_ (u"ࠩ࠭ࠫࡧ"))
        except: l11llll_nktv_ = l1l11_nktv_ (u"ࠪࠫࡨ")
        l11111_nktv_ = l1l1l1_nktv_(l1l11_nktv_ (u"ࠬࠫࡤ࠻ࠧࡶ࠾ࠪࡪࠧࡱ")%(tm.tm_hour,l11llll_nktv_,tm.tm_min))
        l1lll1ll_nktv_.setSetting(l1l11_nktv_ (u"࠭࡫ࡰࡦࠪࡲ"),l11111_nktv_)
l1111l1_nktv_=l1l11_nktv_ (u"ࠧࠨࡳ")
l11111l_nktv_=l1l11_nktv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡰ࡬ࡲࡦࡺࡥ࡬ࡣ࠱ࡴࡱ࠭ࡴ")
l11l11_nktv_ = 15
l1lll111_nktv_=l1l11_nktv_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠶࠻࠲࠵࠴࠲࠶࠸࠷࠲࠾࠽ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧࡵ")
def l1l111l_nktv_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l1l11_nktv_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧࡶ"), l1lll111_nktv_)
    req.add_header(l1l11_nktv_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬࡷ"), l11111l_nktv_)
    l1llll1_nktv_=l1l11_nktv_ (u"ࠬ࠭ࡸ")
    if cookies:
        req.add_header(l1l11_nktv_ (u"ࠨࡃࡰࡱ࡮࡭ࡪࠨࡹ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11l11_nktv_)
        l11ll11_nktv_ = response.read()
    except:
        l11ll11_nktv_=l1l11_nktv_ (u"ࠧࠨࡺ")
    return l11ll11_nktv_
def l1lllll_nktv_(l11ll1l_nktv_):
    return l11ll1l_nktv_
l1llll1l_nktv_=l1111l_nktv_.go.get(l1l11_nktv_ (u"ࠨࡦࡨࡧࡴࡪࡥࡉࡖࡐࡐࡪࡴࡴࡳ࡫ࡨࡷࠬࡻ"),l1lllll_nktv_)
def l1lll11_nktv_(url):
    if l11111l_nktv_ not in url:
        url = urlparse.urljoin(l11111l_nktv_,url)
    content = l1l111l_nktv_(url)
    out=[]
    l111lll_nktv_ = re.compile(l1l11_nktv_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡨࡲࡡࡴࡵࡀࠦࡳ࡫ࡸࡵࡒࡤ࡫ࡪࠨ࠾ࠨࡼ")).search(content)
    l111lll_nktv_ = l111lll_nktv_.group(1) if l111lll_nktv_ else False
    l11ll1_nktv_ = re.compile(l1l11_nktv_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡩ࡬ࡢࡵࡶࡁࠧࡶࡲࡦࡸࡓࡥ࡬࡫ࠢ࠿ࠩࡽ")).search(content)
    l11ll1_nktv_ = l11ll1_nktv_.group(1) if l11ll1_nktv_ else False
    l1l1l11_nktv_ = re.compile(l1l11_nktv_ (u"ࠫࡁࡲࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰࡮࡬ࡂࠬࡾ"),re.DOTALL).findall(content)
    for l1l1ll1_nktv_ in l1l1l11_nktv_:
        l111l11_nktv_ = re.compile(l1l11_nktv_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡤ࡮ࡤࡷࡸࡃࠢࡪ࡯ࡤ࡫ࡪࠨ࠾ࠨࡿ")).findall(l1l1ll1_nktv_)
        l111l1l_nktv_ = re.compile(l1l11_nktv_ (u"࠭࠼ࡪ࡯ࡪࠤࡦࡲࡴ࠾ࠤ࠱࠮ࡄࠨࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬࢀ")).findall(l1l1ll1_nktv_)
        l1ll11_nktv_=re.compile(l1l11_nktv_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵ࡫ࡷࡰࡪࠨ࡛࡟ࡀࡠ࠮ࡃ࠮࠮ࠫࡁࠬࡀࠬࢁ")).findall(l1l1ll1_nktv_)
        l11l111_nktv_= re.compile(l1l11_nktv_ (u"ࠨ࠾ࡶࡴࡦࡴࠠࡤ࡮ࡤࡷࡸࡃࠢࡵࡧࡻࡸࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬࢂ")).findall(l1l1ll1_nktv_)
        l111ll_nktv_ = re.compile(l1l11_nktv_ (u"ࠩ࠿ࡷࡵࡧ࡮ࠡࡣࡵ࡭ࡦ࠳ࡨࡪࡦࡧࡩࡳࡃࠢࡵࡴࡸࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬࢃ")).findall(l1l1ll1_nktv_)
        if l111l11_nktv_ and l1ll11_nktv_:
            l1l111_nktv_={
                l1l11_nktv_ (u"ࠪ࡬ࡷ࡫ࡦࠨࢄ"):l11111l_nktv_+l111l11_nktv_[0],
                l1l11_nktv_ (u"ࠫ࡮ࡳࡧࠨࢅ"):l111l1l_nktv_[0].split(l1l11_nktv_ (u"ࠬࡅࠧࢆ"))[0] if l111l1l_nktv_ else l1l11_nktv_ (u"࠭ࠧࢇ"),
                l1l11_nktv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭࢈"): l1llll1l_nktv_(l1ll11_nktv_[0]),
                l1l11_nktv_ (u"ࠨࡲ࡯ࡳࡹ࠭ࢉ"):l1llll1l_nktv_(l11l111_nktv_[0]) if l11l111_nktv_ else l1l11_nktv_ (u"ࠩࠪࢊ"),
                l1l11_nktv_ (u"ࠪࡧࡴࡪࡥࠨࢋ") : l111ll_nktv_[0].replace(l1l11_nktv_ (u"ࠫࡏ࡯ࡍࡻࡑࡗࡷࡂ࠭ࢌ").decode(l1l11_nktv_ (u"ࠬࡨࡡࡴࡧ࠹࠸ࠬࢍ")),l1l11_nktv_ (u"࠭࡜ࠨࠩࢎ")) if l111ll_nktv_ else l1l11_nktv_ (u"ࠧࠨ࢏")
                }
            out.append(l1l111_nktv_)
    print out
    print (l11ll1_nktv_,l111lll_nktv_)
    return out,(l11ll1_nktv_,l111lll_nktv_)
def decode(a,e):
    out=[]
    for s in a.get(l1l11_nktv_ (u"ࠨࡵࡲࡹࡷࡩࡥࡴࠩ࢐"),[]):
        s[l1l11_nktv_ (u"ࠩࡸࡶࡱ࠭࢑")] = l1l11_nktv_ (u"ࠪࠫ࢒").join([chr(int(e)^ord(i)) for i in s.get(l1l11_nktv_ (u"ࠫࡸࡸࡣࠨ࢓"),l1l11_nktv_ (u"ࠬ࠭࢔"))] )
        s[l1l11_nktv_ (u"࠭࡬ࡢࡤࡨࡰࠬ࢕")] = s[l1l11_nktv_ (u"ࠧࡶࡴ࡯ࠫ࢖")].split(l1l11_nktv_ (u"ࠨ࠱ࠪࢗ"))[-1].split(l1l11_nktv_ (u"ࠩ࠱ࠫ࢘"))[-1]
        if s[l1l11_nktv_ (u"ࠪࡰࡦࡨࡥ࡭࢙ࠩ")] in [l1l11_nktv_ (u"ࠫࡲ࠹ࡵ࠹࢚ࠩ"),l1l11_nktv_ (u"ࠬࡳࡰ࠵࢛ࠩ"),l1l11_nktv_ (u"࠭࡭࠴ࡷࠪ࢜")]:
            out.append({l1l11_nktv_ (u"ࠧࡶࡴ࡯ࠫ࢝"):s[l1l11_nktv_ (u"ࠨࡷࡵࡰࠬ࢞")],l1l11_nktv_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨ࢟"):s[l1l11_nktv_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࢠ")]})
    return out
def l1llllll_nktv_(url):
    if l11111l_nktv_ not in url: url = urljoin(l11111l_nktv_,url)
    content = l1l111l_nktv_(url)
    l11l1l_nktv_=[]
    l1111ll_nktv_ = re.compile(l1l11_nktv_ (u"ࠫࡵࡲࡡࡺࡧࡵࡓࡵࡺࡩࡰࡰࡶ࡛࡮ࡺࡨࡎࡣ࡬ࡲࡘࡵࡵࡳࡥࡨࡠࡸ࠰࠽࡝ࡵ࠭ࠬ࠳࠰࠿ࡾࠫ࠾ࠫࢡ"),re.DOTALL).findall(content)
    code = re.compile(l1l11_nktv_ (u"ࠬࡢࠨࡱ࡮ࡤࡽࡪࡸࡏࡱࡶ࡬ࡳࡳࡹࡗࡪࡶ࡫ࡑࡦ࡯࡮ࡔࡱࡸࡶࡨ࡫ࠬ࡝ࡵ࠭ࠬࡡࡪࠫࠪ࡞ࠬࠫࢢ")).findall(content)
    if l1111ll_nktv_ and code:
        l1111ll_nktv_ = eval(l1111ll_nktv_[0].replace(l1l11_nktv_ (u"࠭ࡦࡢ࡮ࡶࡩࠬࢣ"),l1l11_nktv_ (u"ࠧࡇࡣ࡯ࡷࡪ࠭ࢤ")).replace(l1l11_nktv_ (u"ࠨࡶࡵࡹࡪ࠭ࢥ"),l1l11_nktv_ (u"ࠩࡗࡶࡺ࡫ࠧࢦ")))
        l11l1l_nktv_ = decode(l1111ll_nktv_,code[0])
    elif l1l11_nktv_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡰ࡬ࡩࡩࡵࡳࡵࡧࡳࡲࡾࠨ࠾ࠨࢧ") in content:
        l11l1l_nktv_=[{l1l11_nktv_ (u"ࠫࡺࡸ࡬ࠨࢨ"):l1l11_nktv_ (u"ࠬ࠭ࢩ"),l1l11_nktv_ (u"࠭࡬ࡢࡤࡨࡰࠬࢪ"):l1l11_nktv_ (u"ࠧࡕࡧࡱࠤࡲࡧࡴࡦࡴ࡬ࡥेࠦࡷࡪࡦࡨࡳ࠴ࡧࡵࡥ࡫ࡲࠤ࡯࡫ࡳࡵࠢࡱ࡭ࡪࡪ࡯ࡴࡶजࡴࡳࡿࠠࡱࡱࡽࡥࠥ࡭ࡲࡢࡰ࡬ࡧࡦࡳࡩࠡࡒࡲࡰࡸࡱࡩࠨࢫ")},
               {l1l11_nktv_ (u"ࠨࡷࡵࡰࠬࢬ"):l1l11_nktv_ (u"ࠩࠪࢭ"),l1l11_nktv_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࢮ"):l1l11_nktv_ (u"࡙ࠫ࡮ࡩࡴࠢࡦࡳࡳࡺࡥ࡯ࡶࠣ࡭ࡸࠦࡡࡷࡣ࡬ࡰࡦࡨࡥࠡ࡫ࡱࠤࡕࡵ࡬ࡢࡰࡧࠤࡴࡴ࡬ࡺࠩࢯ")}]
    return l11l1l_nktv_
def l111111_nktv_():
    data = l1l11_nktv_ (u"ࠧࠨࠢࠋࠢࠣࠤࠥࡂ࡬ࡪࠢࡧࡥࡹࡧ࠭ࡤࡱࡧࡩࡳࡧ࡭ࡦ࠿ࠥࡪ࡮ࡲ࡭ࠣࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠴࡬ࡩ࡭࡯ࡼ࠳࡫࡯࡬࡮ࠤࡁࡪ࡮ࡲ࡭࠽࠱ࡤࡂࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡂࡵ࡭ࡀࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡁࡲࡩࠡࡦࡤࡸࡦ࠳ࡣࡰࡦࡨࡲࡦࡳࡥ࠾ࠤࡤࡲ࡮ࡳࡡࡤ࡬ࡨࠦࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢ࠰ࡨ࡬ࡰࡲࡿ࠯ࡧ࡫࡯ࡱ࠱ࡧ࡮ࡪ࡯ࡤࡧ࡯࡫ࠢ࠿ࡣࡱ࡭ࡲࡧࡣ࡫ࡧ࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠼࡭࡫ࠣࡨࡦࡺࡡ࠮ࡥࡲࡨࡪࡴࡡ࡮ࡧࡀࠦࡧࡧࡪ࡬࡫ࠥࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠯ࡧ࡫࡯ࡱࡾ࠵ࡦࡪ࡮ࡰ࠰ࡧࡧࡪ࡬࡫ࠥࡂࡧࡧࡪ࡬࡫࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠼࡭࡫ࠣࡨࡦࡺࡡ࠮ࡥࡲࡨࡪࡴࡡ࡮ࡧࡀࠦࡩࡵ࡫ࡶ࡯ࡨࡲࡹࡿࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳࡫࡯࡬࡮ࡻ࠲ࡪ࡮ࡲ࡭࠭ࡦࡲ࡯ࡺࡳࡥ࡯ࡶࡼࠦࡃࡪ࡯࡬ࡷࡰࡩࡳࡺࡹ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡁࡲࡩࠡࡦࡤࡸࡦ࠳ࡣࡰࡦࡨࡲࡦࡳࡥ࠾ࠤࡨ࡯ࡸࡶࡥࡳࡻࡰࡩࡳࡺࡹࠣࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠴࡬ࡩ࡭࡯ࡼ࠳࡫࡯࡬࡮࠮ࡨ࡯ࡸࡶࡥࡳࡻࡰࡩࡳࡺࡹࠣࡀࡨ࡯ࡸࡶࡥࡳࡻࡰࡩࡳࡺࡹ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡁࡲࡩࠡࡦࡤࡸࡦ࠳ࡣࡰࡦࡨࡲࡦࡳࡥ࠾ࠤࡩࡥࡧࡻ࡬ࡺࠤࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠵ࡦࡪ࡮ࡰࡽ࠴࡬ࡩ࡭࡯࠯ࡪࡦࡨࡵ࡭ࡻࠥࡂ࡫ࡧࡢࡶॄࡼࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠽࡮࡬ࠤࡩࡧࡴࡢ࠯ࡦࡳࡩ࡫࡮ࡢ࡯ࡨࡁࠧࡵ࠭ࡧ࡫࡯ࡱ࡮࡫ࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳࡫࡯࡬࡮ࡻ࠲ࡪ࡮ࡲ࡭࠭ࡱ࠰ࡪ࡮ࡲ࡭ࡪࡧࠥࡂࡴࠦࡦࡪ࡮ࡰ࡭ࡪࡂ࠯ࡢࡀ࠿࠳ࡱ࡯࠾ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠾࠲ࡹࡱࡄࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠼࠰࡮࡬ࡂࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠿ࡰ࡮ࠦࡤࡢࡶࡤ࠱ࡨࡵࡤࡦࡰࡤࡱࡪࡃࠢࡵࡧࡤࡸࡷࠨ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠲ࡪ࡮ࡲ࡭ࡺ࠱ࡷࡩࡦࡺࡲࠣࡀࡷࡩࡦࡺࡲ࠽࠱ࡤࡂࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡂࡵ࡭ࡀࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡁࡲࡩࠡࡦࡤࡸࡦ࠳ࡣࡰࡦࡨࡲࡦࡳࡥ࠾ࠤࡶࡴࡪࡱࡴࡢ࡭࡯ࡩࠧࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣ࠱ࡩ࡭ࡱࡳࡹ࠰ࡶࡨࡥࡹࡸࠬࡴࡲࡨ࡯ࡹࡧ࡫࡭ࡧࠥࡂࡸࡶࡥ࡬ࡶࡤ࡯ࡱ࡫࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡀࡱ࡯ࠠࡥࡣࡷࡥ࠲ࡩ࡯ࡥࡧࡱࡥࡲ࡫࠽ࠣࡱࡳࡩࡷࡧࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳࡫࡯࡬࡮ࡻ࠲ࡸࡪࡧࡴࡳ࠮ࡲࡴࡪࡸࡡࠣࡀࡲࡴࡪࡸࡡ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡁࡲࡩࠡࡦࡤࡸࡦ࠳ࡣࡰࡦࡨࡲࡦࡳࡥ࠾ࠤࡶࡰࡺࡩࡨࡰࡹ࡬ࡷࡰࡧࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳࡫࡯࡬࡮ࡻ࠲ࡸࡪࡧࡴࡳ࠮ࡶࡰࡺࡩࡨࡰࡹ࡬ࡷࡰࡧࠢ࠿ࡵॅࡹࡨ࡮࡯ࡸ࡫ࡶ࡯ࡦࡂ࠯ࡢࡀ࠿࠳ࡱ࡯࠾ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠿ࡰ࡮ࠦࡤࡢࡶࡤ࠱ࡨࡵࡤࡦࡰࡤࡱࡪࡃࠢࡵࡣࡱ࡭ࡪࡩࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳࡫࡯࡬࡮ࡻ࠲ࡸࡪࡧࡴࡳ࠮ࡷࡥࡳ࡯ࡥࡤࠤࡁࡸࡦࡴࡩࡦࡥ࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠼࡭࡫ࠣࡨࡦࡺࡡ࠮ࡥࡲࡨࡪࡴࡡ࡮ࡧࡀࠦࡴ࠳ࡴࡦࡣࡷࡶࡿ࡫ࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳࡫࡯࡬࡮ࡻ࠲ࡸࡪࡧࡴࡳ࠮ࡲ࠱ࡹ࡫ࡡࡵࡴࡽࡩࠧࡄ࡯ࠡࡶࡨࡥࡹࡸࡺࡦ࠾࠲ࡥࡃࡂ࠯࡭࡫ࡁࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡁ࠵ࡵ࡭ࡀࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠿࠳ࡱ࡯࠾ࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡂ࡬ࡪࠢࡧࡥࡹࡧ࠭ࡤࡱࡧࡩࡳࡧ࡭ࡦ࠿ࠥࡱࡺࢀࡹ࡬ࡣࠥࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠯ࡧ࡫࡯ࡱࡾ࠵࡭ࡶࡼࡼ࡯ࡦࠨ࠾࡮ࡷࡽࡽࡰࡧ࠼࠰ࡣࡁࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡁࡻ࡬࠿ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡀࡱ࡯ࠠࡥࡣࡷࡥ࠲ࡩ࡯ࡥࡧࡱࡥࡲ࡫࠽ࠣࡱ࠰ࡱࡺࢀࡹࡤࡧࠥࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠯ࡧ࡫࡯ࡱࡾ࠵࡭ࡶࡼࡼ࡯ࡦ࠲࡯࠮࡯ࡸࡾࡾࡩࡥࠣࡀࡲࠤࡲࡻࡺࡺࡥࡨࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠽࡮࡬ࠤࡩࡧࡴࡢ࠯ࡦࡳࡩ࡫࡮ࡢ࡯ࡨࡁࠧࡱ࡯࡯ࡥࡨࡶࡹࡿࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳࡫࡯࡬࡮ࡻ࠲ࡱࡺࢀࡹ࡬ࡣ࠯࡯ࡴࡴࡣࡦࡴࡷࡽࠧࡄ࡫ࡰࡰࡦࡩࡷࡺࡹ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡁࡲࡩࠡࡦࡤࡸࡦ࠳ࡣࡰࡦࡨࡲࡦࡳࡥ࠾ࠤࡰࡹࡿࡿ࡫ࡰࡶࡨ࡯ࡦࡹࡺ࡬ࡱ࡯ࡲࡦࠨ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠲ࡪ࡮ࡲ࡭ࡺ࠱ࡰࡹࡿࡿ࡫ࡢ࠮ࡰࡹࡿࡿ࡫ࡰࡶࡨ࡯ࡦࡹࡺ࡬ࡱ࡯ࡲࡦࠨ࠾ࡎࡷࡽࡽࡰࡵࡴࡦ࡭ࡤࠤࡘࢀ࡫ࡰ࡮ࡱࡥࡁ࠵ࡡ࠿࠾࠲ࡰ࡮ࡄࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠾࡯࡭ࠥࡪࡡࡵࡣ࠰ࡧࡴࡪࡥ࡯ࡣࡰࡩࡂࠨࡰࡰࡹࡤࡾࡳࡧࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳࡫࡯࡬࡮ࡻ࠲ࡱࡺࢀࡹ࡬ࡣ࠯ࡴࡴࡽࡡࡻࡰࡤࠦࡃࡶ࡯ࡸࡣॿࡲࡦࡂ࠯ࡢࡀ࠿࠳ࡱ࡯࠾ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠿ࡰ࡮ࠦࡤࡢࡶࡤ࠱ࡨࡵࡤࡦࡰࡤࡱࡪࡃࠢ࡭ࡷࡧࡳࡼࡧࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳࡫࡯࡬࡮ࡻ࠲ࡱࡺࢀࡹ࡬ࡣ࠯ࡰࡺࡪ࡯ࡸࡣࠥࡂࡱࡻࡤࡰࡹࡤࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠽࡮࡬ࠤࡩࡧࡴࡢ࠯ࡦࡳࡩ࡫࡮ࡢ࡯ࡨࡁࠧࡶ࡯ࡱࡷ࡯ࡥࡷࡴࡡࠣࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠴࡬ࡩ࡭࡯ࡼ࠳ࡲࡻࡺࡺ࡭ࡤ࠰ࡵࡵࡰࡶ࡮ࡤࡶࡳࡧࠢ࠿ࡲࡲࡴࡺࡲࡡࡳࡰࡤࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠼࠰ࡷ࡯ࡂࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡁ࠵࡬ࡪࡀࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠽࡮࡬ࠤࡩࡧࡴࡢ࠯ࡦࡳࡩ࡫࡮ࡢ࡯ࡨࡁࠧࡹࡺࡵࡷ࡮ࡥࠧࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣ࠱ࡩ࡭ࡱࡳࡹ࠰ࡵࡽࡸࡺࡱࡡࠣࡀࡶࡾࡹࡻ࡫ࡢ࠾࠲ࡥࡃࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠼ࡶ࡮ࡁࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡂ࡬ࡪࠢࡧࡥࡹࡧ࠭ࡤࡱࡧࡩࡳࡧ࡭ࡦ࠿ࠥࡥࡷࡩࡨࡪࡶࡨ࡯ࡹࡻࡲࡢࠤࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠵ࡦࡪ࡮ࡰࡽ࠴ࡹࡺࡵࡷ࡮ࡥ࠱ࡧࡲࡤࡪ࡬ࡸࡪࡱࡴࡶࡴࡤࠦࡃࡧࡲࡤࡪ࡬ࡸࡪࡱࡴࡶࡴࡤࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠽࡮࡬ࠤࡩࡧࡴࡢ࠯ࡦࡳࡩ࡫࡮ࡢ࡯ࡨࡁࠧ࡬࡯ࡵࡱࡪࡶࡦ࡬ࡩࡢࠤࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠵ࡦࡪ࡮ࡰࡽ࠴ࡹࡺࡵࡷ࡮ࡥ࠱࡬࡯ࡵࡱࡪࡶࡦ࡬ࡩࡢࠤࡁࡪࡴࡺ࡯ࡨࡴࡤࡪ࡮ࡧ࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡀࡱ࡯ࠠࡥࡣࡷࡥ࠲ࡩ࡯ࡥࡧࡱࡥࡲ࡫࠽ࠣࡲࡨࡶ࡫ࡵࡲ࡮ࡣࡱࡷࠧࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣ࠱ࡩ࡭ࡱࡳࡹ࠰ࡵࡽࡸࡺࡱࡡ࠭ࡲࡨࡶ࡫ࡵࡲ࡮ࡣࡱࡷࠧࡄࡰࡦࡴࡩࡳࡷࡳࡡ࡯ࡵ࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠼࡭࡫ࠣࡨࡦࡺࡡ࠮ࡥࡲࡨࡪࡴࡡ࡮ࡧࡀࠦࡼ࡯ࡤࡦࡱ࠰ࡥࡷࡺࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳࡫࡯࡬࡮ࡻ࠲ࡷࡿࡺࡵ࡬ࡣ࠯ࡻ࡮ࡪࡥࡰ࠯ࡤࡶࡹࠨ࠾ࡸ࡫ࡧࡩࡴ࠳ࡡࡳࡶ࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠼࡭࡫ࠣࡨࡦࡺࡡ࠮ࡥࡲࡨࡪࡴࡡ࡮ࡧࡀࠦࡼࡿࡳࡵࡣࡺࡽࠧࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣ࠱ࡩ࡭ࡱࡳࡹ࠰ࡵࡽࡸࡺࡱࡡ࠭ࡹࡼࡷࡹࡧࡷࡺࠤࡁࡻࡾࡹࡴࡢࡹࡼࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠽࡮࡬ࠤࡩࡧࡴࡢ࠯ࡦࡳࡩ࡫࡮ࡢ࡯ࡨࡁࠧࡵ࠭ࡴࡼࡷࡹࡨ࡫ࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳࡫࡯࡬࡮ࡻ࠲ࡷࡿࡺࡵ࡬ࡣ࠯ࡳ࠲ࡹࡺࡵࡷࡦࡩࠧࡄ࡯ࠡࡵࡽࡸࡺࡩࡥ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡀ࠴ࡻ࡬࠿ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠾࠲ࡰ࡮ࡄࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡁࡲࡩࠡࡦࡤࡸࡦ࠳ࡣࡰࡦࡨࡲࡦࡳࡥ࠾ࠤ࡯࡭ࡹ࡫ࡲࡢࡶࡸࡶࡦࠨ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠲ࡪ࡮ࡲ࡭ࡺ࠱࡯࡭ࡹ࡫ࡲࡢࡶࡸࡶࡦࠨ࠾࡭࡫ࡷࡩࡷࡧࡴࡶࡴࡤࡀ࠴ࡧ࠾ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠾ࡸࡰࡃࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠽࡮࡬ࠤࡩࡧࡴࡢ࠯ࡦࡳࡩ࡫࡮ࡢ࡯ࡨࡁࠧࡹ࡬ࡶࡥ࡫ࡳࡼ࡯ࡳ࡬ࡣࠥࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠯ࡧ࡫࡯ࡱࡾ࠵࡬ࡪࡶࡨࡶࡦࡺࡵࡳࡣ࠯ࡷࡱࡻࡣࡩࡱࡺ࡭ࡸࡱࡡࠣࡀࡶॆࡺࡩࡨࡰࡹ࡬ࡷࡰࡧ࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡀࡱ࡯ࠠࡥࡣࡷࡥ࠲ࡩ࡯ࡥࡧࡱࡥࡲ࡫࠽ࠣࡲࡲࡩࡿࡰࡡࠣࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠴࡬ࡩ࡭࡯ࡼ࠳ࡱ࡯ࡴࡦࡴࡤࡸࡺࡸࡡ࠭ࡲࡲࡩࡿࡰࡡࠣࡀࡳࡳࡪࢀࡪࡢ࠾࠲ࡥࡃࡂ࠯࡭࡫ࡁࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡂ࡬ࡪࠢࡧࡥࡹࡧ࠭ࡤࡱࡧࡩࡳࡧ࡭ࡦ࠿ࠥࡴࡷࡵࡺࡢࠤࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠵ࡦࡪ࡮ࡰࡽ࠴ࡲࡩࡵࡧࡵࡥࡹࡻࡲࡢ࠮ࡳࡶࡴࢀࡡࠣࡀࡳࡶࡴࢀࡡ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡁࡲࡩࠡࡦࡤࡸࡦ࠳ࡣࡰࡦࡨࡲࡦࡳࡥ࠾ࠤࡲ࠱ࡱ࡯ࡴࡦࡴࡤࡸࡺࡸࡺࡦࠤࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠵ࡦࡪ࡮ࡰࡽ࠴ࡲࡩࡵࡧࡵࡥࡹࡻࡲࡢ࠮ࡲ࠱ࡱ࡯ࡴࡦࡴࡤࡸࡺࡸࡺࡦࠤࡁࡳࠥࡲࡩࡵࡧࡵࡥࡹࡻࡲࡻࡧ࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠼࡭࡫ࠣࡨࡦࡺࡡ࠮ࡥࡲࡨࡪࡴࡡ࡮ࡧࡀࠦࡩࡸࡡ࡮ࡣࡷ࠱࠶ࠨ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠲ࡪ࡮ࡲ࡭ࡺ࠱࡯࡭ࡹ࡫ࡲࡢࡶࡸࡶࡦ࠲ࡤࡳࡣࡰࡥࡹ࠳࠱ࠣࡀࡧࡶࡦࡳࡡࡵ࠾࠲ࡥࡃࡂ࠯࡭࡫ࡁࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡁ࠵ࡵ࡭ࡀࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠿࠳ࡱ࡯࠾ࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡂ࡬ࡪࠢࡧࡥࡹࡧ࠭ࡤࡱࡧࡩࡳࡧ࡭ࡦ࠿ࠥࡴࡺࡨ࡬ࡪࡥࡼࡷࡹࡿ࡫ࡢࠤࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠵ࡦࡪ࡮ࡰࡽ࠴ࡶࡵࡣ࡮࡬ࡧࡾࡹࡴࡺ࡭ࡤࠦࡃࡶࡵࡣ࡮࡬ࡧࡾࡹࡴࡺ࡭ࡤࡀ࠴ࡧ࠾ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠾ࡸࡰࡃࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠽࡮࡬ࠤࡩࡧࡴࡢ࠯ࡦࡳࡩ࡫࡮ࡢ࡯ࡨࡁࠧࡧࡵࡥࡻࡦ࡮ࡪ࠳ࡲࡢࡦ࡬ࡳࡼ࡫ࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳࡫࡯࡬࡮ࡻ࠲ࡴࡺࡨ࡬ࡪࡥࡼࡷࡹࡿ࡫ࡢ࠮ࡤࡹࡩࡿࡣ࡫ࡧ࠰ࡶࡦࡪࡩࡰࡹࡨࠦࡃࡧࡵࡥࡻࡦ࡮ࡪࠦࡲࡢࡦ࡬ࡳࡼ࡫࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡀࡱ࡯ࠠࡥࡣࡷࡥ࠲ࡩ࡯ࡥࡧࡱࡥࡲ࡫࠽ࠣࡦࡨࡦࡦࡺࡹ࠮࡫࠰࡯ࡴࡴࡦࡦࡴࡨࡲࡨࡰࡥࠣࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠴࡬ࡩ࡭࡯ࡼ࠳ࡵࡻࡢ࡭࡫ࡦࡽࡸࡺࡹ࡬ࡣ࠯ࡨࡪࡨࡡࡵࡻ࠰࡭࠲ࡱ࡯࡯ࡨࡨࡶࡪࡴࡣ࡫ࡧࠥࡂࡩ࡫ࡢࡢࡶࡼࠤ࡮ࠦ࡫ࡰࡰࡩࡩࡷ࡫࡮ࡤ࡬ࡨࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠽࡮࡬ࠤࡩࡧࡴࡢ࠯ࡦࡳࡩ࡫࡮ࡢ࡯ࡨࡁࠧ࡮ࡩࡴࡶࡲࡶ࡮ࡧ࠭ࡪ࠯ࡳࡳࡱ࡯ࡴࡺ࡭ࡤࠦࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢ࠰ࡨ࡬ࡰࡲࡿ࠯ࡱࡷࡥࡰ࡮ࡩࡹࡴࡶࡼ࡯ࡦ࠲ࡨࡪࡵࡷࡳࡷ࡯ࡡ࠮࡫࠰ࡴࡴࡲࡩࡵࡻ࡮ࡥࠧࡄࡨࡪࡵࡷࡳࡷ࡯ࡡࠡ࡫ࠣࡴࡴࡲࡩࡵࡻ࡮ࡥࡁ࠵ࡡ࠿࠾࠲ࡰ࡮ࡄࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠾࡯࡭ࠥࡪࡡࡵࡣ࠰ࡧࡴࡪࡥ࡯ࡣࡰࡩࡂࠨࡲࡰࡼࡰࡳࡼࡿࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳࡫࡯࡬࡮ࡻ࠲ࡴࡺࡨ࡬ࡪࡥࡼࡷࡹࡿ࡫ࡢ࠮ࡵࡳࡿࡳ࡯ࡸࡻࠥࡂࡷࡵࡺ࡮ࡱࡺࡽࡁ࠵ࡡ࠿࠾࠲ࡰ࡮ࡄࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠾࡯࡭ࠥࡪࡡࡵࡣ࠰ࡧࡴࡪࡥ࡯ࡣࡰࡩࡂࠨࡷࡺࡦࡤࡶࡿ࡫࡮ࡪࡣࠥࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠯ࡧ࡫࡯ࡱࡾ࠵ࡰࡶࡤ࡯࡭ࡨࡿࡳࡵࡻ࡮ࡥ࠱ࡽࡹࡥࡣࡵࡾࡪࡴࡩࡢࠤࡁࡻࡾࡪࡡࡳࡼࡨࡲ࡮ࡧ࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡀࡱ࡯ࠠࡥࡣࡷࡥ࠲ࡩ࡯ࡥࡧࡱࡥࡲ࡫࠽ࠣࡲࡵࡳ࡬ࡸࡡ࡮࠯ࡷࡺࠧࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣ࠱ࡩ࡭ࡱࡳࡹ࠰ࡲࡸࡦࡱ࡯ࡣࡺࡵࡷࡽࡰࡧࠬࡱࡴࡲ࡫ࡷࡧ࡭࠮ࡶࡹࠦࡃࡶࡲࡰࡩࡵࡥࡲࠦࡴࡷ࠾࠲ࡥࡃࡂ࠯࡭࡫ࡁࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡁ࠵ࡵ࡭ࡀࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠿࠳ࡱ࡯࠾ࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡂ࡬ࡪࠢࡧࡥࡹࡧ࠭ࡤࡱࡧࡩࡳࡧ࡭ࡦ࠿ࠥࡱࡪࡪࡩࡢ࠯࡬࠱ࡹ࡫ࡣࡩࡰࡲࡰࡴ࡭ࡩࡦࠤࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠵ࡦࡪ࡮ࡰࡽ࠴ࡳࡥࡥ࡫ࡤ࠱࡮࠳ࡴࡦࡥ࡫ࡲࡴࡲ࡯ࡨ࡫ࡨࠦࡃࡳࡥࡥ࡫ࡤࠤ࡮ࠦࡴࡦࡥ࡫ࡲࡴࡲ࡯ࡨ࡫ࡨࡀ࠴ࡧ࠾ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠾ࡸࡰࡃࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠽࡮࡬ࠤࡩࡧࡴࡢ࠯ࡦࡳࡩ࡫࡮ࡢ࡯ࡨࡁࠧࡱࡵ࡭ࡶࡸࡶࡦ࠳࠲࠱ࠤࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠵ࡦࡪ࡮ࡰࡽ࠴ࡳࡥࡥ࡫ࡤ࠱࡮࠳ࡴࡦࡥ࡫ࡲࡴࡲ࡯ࡨ࡫ࡨ࠰ࡰࡻ࡬ࡵࡷࡵࡥ࠲࠸࠰ࠣࡀ࡮ࡹࡱࡺࡵࡳࡣࠣ࠶࠳࠶࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡀࡱ࡯ࠠࡥࡣࡷࡥ࠲ࡩ࡯ࡥࡧࡱࡥࡲ࡫࠽ࠣࡦ࡬࡫࡮ࡺࡡ࡭࡫ࡽࡥࡨࡰࡡࠣࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠴࡬ࡩ࡭࡯ࡼ࠳ࡲ࡫ࡤࡪࡣ࠰࡭࠲ࡺࡥࡤࡪࡱࡳࡱࡵࡧࡪࡧ࠯ࡨ࡮࡭ࡩࡵࡣ࡯࡭ࡿࡧࡣ࡫ࡣࠥࡂࡩ࡯ࡧࡪࡶࡤࡰ࡮ࢀࡡࡤ࡬ࡤࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠽࡮࡬ࠤࡩࡧࡴࡢ࠯ࡦࡳࡩ࡫࡮ࡢ࡯ࡨࡁࠧࡧࡲࡤࡪ࡬ࡻࡦ࠳ࡰࡳࡻࡺࡥࡹࡴࡥࠣࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠴࡬ࡩ࡭࡯ࡼ࠳ࡲ࡫ࡤࡪࡣ࠰࡭࠲ࡺࡥࡤࡪࡱࡳࡱࡵࡧࡪࡧ࠯ࡥࡷࡩࡨࡪࡹࡤ࠱ࡵࡸࡹࡸࡣࡷࡲࡪࠨ࠾ࡢࡴࡦ࡬࡮ࡽࡡࠡࡲࡵࡽࡼࡧࡴ࡯ࡧ࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠼࡭࡫ࠣࡨࡦࡺࡡ࠮ࡥࡲࡨࡪࡴࡡ࡮ࡧࡀࠦࡹࡻࡴࡰࡴ࡬ࡥࡱࠨ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠲ࡪ࡮ࡲ࡭ࡺ࠱ࡰࡩࡩ࡯ࡡ࠮࡫࠰ࡸࡪࡩࡨ࡯ࡱ࡯ࡳ࡬࡯ࡥ࠭ࡶࡸࡸࡴࡸࡩࡢ࡮ࠥࡂࡹࡻࡴࡰࡴ࡬ࡥࡱ࡫࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠿࠳ࡺࡲ࠾ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠽࠱࡯࡭ࡃࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠎࠥࠦࠠࠡࠤࠥࠦࢰ")
    items = re.compile(l1l11_nktv_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫࢱ"),).findall(data)
    return items
def l1l1111_nktv_(name, url, mode, l1ll1lll_nktv_=1, l1lll1l_nktv_=None, infoLabels=False, IsPlayable=True, isFolder = False, fanart=l1111l1_nktv_,l1l11ll_nktv_=1):
    u = l1l11l_nktv_({l1l11_nktv_ (u"ࠧ࡮ࡱࡧࡩࠬࢲ"): mode, l1l11_nktv_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬࢳ"): name, l1l11_nktv_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪࢴ") : url, l1l11_nktv_ (u"ࠪࡴࡦ࡭ࡥࠨࢵ"):l1ll1lll_nktv_})
    if l1lll1l_nktv_==None:
        l1lll1l_nktv_=l1l11_nktv_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠨࢶ")
    l1l11l1_nktv_ = xbmcgui.ListItem(name, iconImage=l1lll1l_nktv_, thumbnailImage=l1lll1l_nktv_)
    l1llll11_nktv_=[l1l11_nktv_ (u"ࠬࡺࡨࡶ࡯ࡥࠫࢷ"),l1l11_nktv_ (u"࠭ࡰࡰࡵࡷࡩࡷ࠭ࢸ"),l1l11_nktv_ (u"ࠧࡣࡣࡱࡲࡪࡸࠧࢹ"),l1l11_nktv_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨࢺ"),l1l11_nktv_ (u"ࠩࡦࡰࡪࡧࡲࡢࡴࡷࠫࢻ"),l1l11_nktv_ (u"ࠪࡧࡱ࡫ࡡࡳ࡮ࡲ࡫ࡴ࠭ࢼ"),l1l11_nktv_ (u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫ࠧࢽ"),l1l11_nktv_ (u"ࠬ࡯ࡣࡰࡰࠪࢾ")]
    l1ll1l_nktv_=dict(zip(l1llll11_nktv_,[l1lll1l_nktv_ for x in l1llll11_nktv_]))
    l1l11l1_nktv_.setArt(l1ll1l_nktv_)
    if not infoLabels:
        infoLabels={l1l11_nktv_ (u"ࠨࡴࡪࡶ࡯ࡩࠧࢿ"): name}
    l1l11l1_nktv_.setInfo(type=l1l11_nktv_ (u"ࠢࡷ࡫ࡧࡩࡴࠨࣀ"), infoLabels=infoLabels)
    if IsPlayable:
        l1l11l1_nktv_.setProperty(l1l11_nktv_ (u"ࠨࡋࡶࡔࡱࡧࡹࡢࡤ࡯ࡩࠬࣁ"), l1l11_nktv_ (u"ࠩࡷࡶࡺ࡫ࠧࣂ"))
    if fanart:
        l1l11l1_nktv_.setProperty(l1l11_nktv_ (u"ࠪࡪࡦࡴࡡࡳࡶࡢ࡭ࡲࡧࡧࡦࠩࣃ"),fanart)
    l1ll1ll_nktv_ = []
    l1ll1ll_nktv_.append((l1l11_nktv_ (u"ࠫࡎࡴࡦࡰࡴࡰࡥࡨࡰࡡࠨࣄ"), l1l11_nktv_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡅࡨࡺࡩࡰࡰࠫࡍࡳ࡬࡯ࠪࠩࣅ")))
    l1l11l1_nktv_.addContextMenuItems(l1ll1ll_nktv_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l11lll1_nktv_, url=u, listitem=l1l11l1_nktv_,isFolder=isFolder,totalItems=l1l11ll_nktv_)
    xbmcplugin.addSortMethod(l11lll1_nktv_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1l11_nktv_ (u"ࠨࠥࡓ࠮ࠣࠩ࡞࠲ࠠࠦࡒࠥࣆ"))
    return ok
def l1ll1l1_nktv_(l11l1ll_nktv_):
    l11l1l1_nktv_ = {}
    for k, v in l11l1ll_nktv_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l1l11_nktv_ (u"ࠧࡶࡶࡩ࠼ࠬࣇ"))
        elif isinstance(v, str):
            v.decode(l1l11_nktv_ (u"ࠨࡷࡷࡪ࠽࠭ࣈ"))
        l11l1l1_nktv_[k] = v
    return l11l1l1_nktv_
def l1l11l_nktv_(query):
    return l1ll111_nktv_ + l1l11_nktv_ (u"ࠩࡂࠫࣉ") + urllib.urlencode(l1ll1l1_nktv_(query))
mode = args.get(l1l11_nktv_ (u"ࠪࡱࡴࡪࡥࠨ࣊"), None)
fname = args.get(l1l11_nktv_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨ࣋"),[l1l11_nktv_ (u"ࠬ࠭࣌")])[0]
ex_link = args.get(l1l11_nktv_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧ࣍"),[l1l11_nktv_ (u"ࠧࠨ࣎")])[0]
l1ll1lll_nktv_ = args.get(l1l11_nktv_ (u"ࠨࡲࡤ࡫ࡪ࣏࠭"),[1])[0]
if mode is None:
    l1l1111_nktv_(l1l11_nktv_ (u"ࠩࡌࡲ࡫ࡵࡲ࡮ࡣࡦ࡮ࡦ࣐࠭"),l1l11_nktv_ (u"࣑ࠪࠫ"),mode=l1l11_nktv_ (u"ࠫࡤ࡯࡮ࡧࡱࡢ࣒ࠫ"),isFolder=True,IsPlayable=False,l1lll1l_nktv_=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1l11_nktv_ (u"ࠬࡶࡡࡵࡪ࣓ࠪ")))+l1l11_nktv_ (u"࠭࠯ࡪࡥࡲࡲ࠳ࡶ࡮ࡨࠩࣔ"))
    for href,title in l111111_nktv_():
        title = l1l11_nktv_ (u"ࠧࠡࠢࠣࠫࣕ")+title if l1l11_nktv_ (u"ࠨ࠮ࠪࣖ") in href else l1l11_nktv_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࠦࡵ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࣗ")%title
        l1l1111_nktv_(title, url=href, mode=l1l11_nktv_ (u"ࠪ࡫ࡪࡺࡃࡰࡰࡷࡩࡳࡺࠧࣘ"), l1ll1lll_nktv_=1, IsPlayable=False, isFolder=True, fanart=l1l11_nktv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡳ࡯࡮ࡢ࠰ࡩ࡭ࡱ࡫ࡳ࠯ࡧ࠸࠵࠲ࡶ࡯࠯࡫ࡱࡷࡾࡹࡣࡥ࠰ࡱࡩࡹ࠵ࡴ࡭ࡱ࠰ࡲࡦ࠳ࡳࡵࡴࡲࡲࡪ࠳ࡧ࡭ࡱࡺࡲࡦ࠳࡮ࡪࡰࡤࡸࡪࡱࡩ࠰ࡶ࡯ࡳ࠲ࡹࡷࡪࡣࡷࡩࡨࢀ࡮ࡦ࠯࠵࠲࡯ࡶࡧࠨࣙ"))
elif mode[0].startswith(l1l11_nktv_ (u"ࠬࡥࡩ࡯ࡨࡲࡣࠬࣚ")):l1111l_nktv_.__myinfo__.go(sys.argv)
elif mode[0]==l1l11_nktv_ (u"࠭ࡧࡦࡶࡆࡳࡳࡺࡥ࡯ࡶࠪࣛ"):
    items,l111ll1_nktv_ =  l1lll11_nktv_(ex_link)
    if l111ll1_nktv_[0]:l1l1111_nktv_(name=l1l11_nktv_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࡂ࠼ࠡࡲࡲࡴࡷࢀࡥࡥࡰ࡬ࡥࠥࡹࡴࡳࡱࡱࡥࠥࡂ࠼࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࣜ"), url=l111ll1_nktv_[0], mode=l1l11_nktv_ (u"ࠨࡡࡢࡴࡦ࡭ࡥ࠻ࡩࡨࡸࡈࡵ࡮ࡵࡧࡱࡸࠬࣝ"), l1ll1lll_nktv_=1, IsPlayable=False)
    for f in items: l1l1111_nktv_(name=f.get(l1l11_nktv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨࣞ")), url=f.get(l1l11_nktv_ (u"ࠪ࡬ࡷ࡫ࡦࠨࣟ")), mode=l1l11_nktv_ (u"ࠫ࡬࡫ࡴࡍ࡫ࡱ࡯ࡸ࠭࣠"), l1lll1l_nktv_=f.get(l1l11_nktv_ (u"ࠬ࡯࡭ࡨࠩ࣡")), infoLabels=f, IsPlayable=True,l1l11ll_nktv_=len(items))
    if l111ll1_nktv_[1]: l1l1111_nktv_(name=l1l11_nktv_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࡃࡄࠠ࡯ࡣࡶࡸࡪࡶ࡮ࡢࠢࡶࡸࡷࡵ࡮ࡢࠢࡁࡂࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࣢"), url=l111ll1_nktv_[1], mode=l1l11_nktv_ (u"ࠧࡠࡡࡳࡥ࡬࡫࠺ࡨࡧࡷࡇࡴࡴࡴࡦࡰࡷࣣࠫ"), l1ll1lll_nktv_=1, IsPlayable=False)
elif mode[0].startswith(l1l11_nktv_ (u"ࠨࡡࡢࡴࡦ࡭ࡥ࠻ࠩࣤ")):
    url = l1l11l_nktv_({l1l11_nktv_ (u"ࠩࡰࡳࡩ࡫ࠧࣥ"): mode[0].split(l1l11_nktv_ (u"ࠪ࠾ࣦࠬ"))[-1], l1l11_nktv_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨࣧ"): l1l11_nktv_ (u"ࠬ࠭ࣨ"), l1l11_nktv_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࣩࠧ") : ex_link, l1l11_nktv_ (u"ࠧࡱࡣࡪࡩࠬ࣪"): l1ll1lll_nktv_})
    xbmc.executebuiltin(l1l11_nktv_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠫࠩࡸ࠯ࠧ࣫")% url)
elif mode[0] == l1l11_nktv_ (u"ࠩࡪࡩࡹࡒࡩ࡯࡭ࡶࠫ࣬"):
    run()
    l1l1ll_nktv_ = l1llllll_nktv_(ex_link)
    l1lll1l1_nktv_=l1l11_nktv_ (u"࣭ࠪࠫ")
    t = [ x.get(l1l11_nktv_ (u"ࠫࡱࡧࡢࡦ࡮࣮ࠪ")) for x in l1l1ll_nktv_]
    l1lll1_nktv_ = xbmcgui.Dialog().select(l1l11_nktv_ (u"ࠧࡒࡩ࡯࡭࡬࣯ࠦ"), t)
    if l1lll1_nktv_>-1: l1lll1l1_nktv_ = l1l1ll_nktv_[l1lll1_nktv_].get(l1l11_nktv_ (u"࠭ࡵࡳ࡮ࣰࠪ"))
    print l1lll1l1_nktv_
    if l1lll1l1_nktv_: xbmcplugin.setResolvedUrl(l11lll1_nktv_, True, xbmcgui.ListItem(path=l1lll1l1_nktv_))
    else: xbmcplugin.setResolvedUrl(l11lll1_nktv_, False, xbmcgui.ListItem(path=l1l11_nktv_ (u"ࠧࠨࣱ")))
else:
    xbmcplugin.setResolvedUrl(l11lll1_nktv_, False, xbmcgui.ListItem(path=l1l11_nktv_ (u"ࠨࣲࠩ")))
xbmcplugin.endOfDirectory(l11lll1_nktv_)
