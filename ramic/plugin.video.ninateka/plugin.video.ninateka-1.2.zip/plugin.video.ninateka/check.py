# coding: UTF-8
import sys
l1ll1_nktv_ = sys.version_info [0] == 2
l111_nktv_ = 2048
l1l1l_nktv_ = 7
def l1l11_nktv_ (keyedStringLiteral):
	global l11ll_nktv_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll1_nktv_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111_nktv_ - (charIndex + stringNr) % l1l1l_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111_nktv_ - (charIndex + stringNr) % l1l1l_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import xbmc,xbmcgui
import time,re,os,threading
try: from shutil import rmtree
except: rmtree = False
def l1l_nktv_(l1111_nktv_,l1llll_nktv_=[l1l11_nktv_ (u"ࠫࠬࠀ")]):
    debug=1
def l1_nktv_(name=l1l11_nktv_ (u"ࠬ࠭ࠁ")):
    debug=1
def l1ll_nktv_(top):
    debug=1
def check():
    debug=1
try:
    debug=1
except: pass
def run():
    try:
        debug=1
    except: pass
