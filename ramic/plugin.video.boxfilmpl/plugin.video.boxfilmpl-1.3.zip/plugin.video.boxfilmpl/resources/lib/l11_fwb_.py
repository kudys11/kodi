# -*- coding: utf-8 -*-
import sys
l1l1l_fwb_ = sys.version_info [0] == 2
l1l1ll_fwb_ = 2048
l1l11_fwb_ = 7
def l1_fwb_ (keyedStringLiteral):
	global l11l11_fwb_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l1l_fwb_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l1ll_fwb_ - (charIndex + stringNr) % l1l11_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l1ll_fwb_ - (charIndex + stringNr) % l1l11_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import ramic as l1l11l1l_fwb_
l11lllll_fwb_        = sys.argv[0]
l11l1ll1_fwb_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l11111l1_fwb_        = xbmcaddon.Addon()
l111111l_fwb_     = l11111l1_fwb_.getAddonInfo(l1_fwb_ (u"ࠩ࡬ࡨࠬई"))
l1l1lll1_fwb_       = l11111l1_fwb_.getAddonInfo(l1_fwb_ (u"ࠪࡲࡦࡳࡥࠨउ"))
PATH        = l11111l1_fwb_.getAddonInfo(l1_fwb_ (u"ࠫࡵࡧࡴࡩࠩऊ")).decode(l1_fwb_ (u"ࠬࡻࡴࡧ࠯࠻ࠫऋ"))
l1lll11_fwb_    = xbmc.translatePath(l11111l1_fwb_.getAddonInfo(l1_fwb_ (u"࠭ࡰࡳࡱࡩ࡭ࡱ࡫ࠧऌ"))).decode(l1_fwb_ (u"ࠧࡶࡶࡩ࠱࠽࠭ऍ"))
l111ll11_fwb_   = PATH+l1_fwb_ (u"ࠨ࠱ࡵࡩࡸࡵࡵࡳࡥࡨࡷ࠴࠭ऎ")
l111l11l_fwb_=l111ll11_fwb_+l1_fwb_ (u"ࠩࡩࡥࡳࡧࡲࡵ࠰ࡳࡲ࡬࠭ए")
sys.path.append(l111ll11_fwb_+l1_fwb_ (u"ࠪࡰ࡮ࡨ࠯ࠨऐ"))
l1ll111l_fwb_ = urllib2.urlopen
l11ll1ll_fwb_ = urllib2.Request
l1lll1_fwb_ = xbmcgui.Dialog()
import time,threading
l1l11lll_fwb_ = lambda x,y: ord(x)+16*y if ord(x)%2 else ord(x)
l1lllllll_fwb_ = lambda l1l11ll1_fwb_: l1_fwb_ (u"ࠫࠬऑ").join([chr(l1l11lll_fwb_(x,1) ) for x in l1l11ll1_fwb_.encode(l1_fwb_ (u"ࠬࡨࡡࡴࡧ࠹࠸ࠬऒ")).strip()])
l1l1ll1l_fwb_ = lambda l1l11ll1_fwb_: l1lllllll_fwb_(l1l11ll1_fwb_).encode(l1_fwb_ (u"࠭ࡨࡦࡺࠪओ"))
l11ll1l1_fwb_ = lambda l1l11ll1_fwb_: l1_fwb_ (u"ࠧࠨऔ").join([chr(l1l11lll_fwb_(x,-1) ) for x in l1l11ll1_fwb_]).decode(l1_fwb_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨक"))
l1111111_fwb_ = lambda l1l11ll1_fwb_: l11ll1l1_fwb_(l1l11ll1_fwb_.decode(l1_fwb_ (u"ࠩ࡫ࡩࡽ࠭ख")))
if not os.path.exists(l1_fwb_ (u"ࠪ࠳࡭ࡵ࡭ࡦ࠱ࡲࡷࡲࡩࠧग")):
    tm=time.gmtime()
    try:    l11llll1_fwb_,l11l11l1_fwb_,l1l11111_fwb_ = l1111111_fwb_(l11111l1_fwb_.getSetting(l1_fwb_ (u"ࠫࡰࡵࡤࠨघ"))).split(l1_fwb_ (u"ࠬࡀࠧङ"))
    except: l11llll1_fwb_,l11l11l1_fwb_,l1l11111_fwb_ =  [l1_fwb_ (u"࠭࠭࠲ࠩच"),l1_fwb_ (u"ࠧࠨछ"),l1_fwb_ (u"ࠨ࠯࠴ࠫज")]
    if int(l11llll1_fwb_) != tm.tm_hour:
        try:    l11l1l1l_fwb_ = re.findall(l1_fwb_ (u"ࠩࡎࡓࡉࡀࠠࠩ࠰࠭ࡃ࠮ࡢ࡮ࠨझ"),l1ll111l_fwb_(l1_fwb_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡷࡧࡷ࠯ࡩ࡬ࡸ࡭ࡻࡢࡶࡵࡨࡶࡨࡵ࡮ࡵࡧࡱࡸ࠳ࡩ࡯࡮࠱ࡵࡥࡲ࡯ࡣࡴࡲࡤ࠳ࡰࡵࡤࡪ࠱ࡰࡥࡸࡺࡥࡳ࠱ࡕࡉࡆࡊࡍࡆ࠰ࡰࡨࠬञ")).read())[0].strip(l1_fwb_ (u"ࠫ࠯࠭ट"))
        except: l11l1l1l_fwb_ = l1_fwb_ (u"ࠬ࠭ठ")
def l11l11ll_fwb_(name, url, mode, l111l1_fwb_=1, l1ll1111_fwb_=l1_fwb_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬࠭फ"), infoLabels={}, IsPlayable=True, fanart=l111l11l_fwb_,l11ll111_fwb_=1):
    u = l1l1l1ll_fwb_({l1_fwb_ (u"ࠪࡱࡴࡪࡥࠨब"): mode, l1_fwb_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨभ"): name, l1_fwb_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭म") : url, l1_fwb_ (u"࠭ࡰࡢࡩࡨࠫय"):l111l1_fwb_,l1_fwb_ (u"ࠧ࡮࡫ࡱࡪࡴ࠭र"):str(infoLabels)})
    isFolder = infoLabels.get(l1_fwb_ (u"ࠨ࡫ࡶࡊࡴࡲࡤࡦࡴࠪऱ"),False)
    if isFolder and infoLabels.get(l1_fwb_ (u"ࠩࡼࡩࡦࡸࠧल"),False):
        name += l1_fwb_ (u"ࠪࠤ࠭ࠫࡳࠪࠩळ")%infoLabels.get(l1_fwb_ (u"ࠫࡾ࡫ࡡࡳࠩऴ"))
    l11l1lll_fwb_ = xbmcgui.ListItem(name)
    l1l1ll11_fwb_=[l1_fwb_ (u"ࠬࡺࡨࡶ࡯ࡥࠫव"),l1_fwb_ (u"࠭ࡰࡰࡵࡷࡩࡷ࠭श"),l1_fwb_ (u"ࠧࡣࡣࡱࡲࡪࡸࠧष"),l1_fwb_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨस"),l1_fwb_ (u"ࠩࡦࡰࡪࡧࡲࡢࡴࡷࠫह"),l1_fwb_ (u"ࠪࡧࡱ࡫ࡡࡳ࡮ࡲ࡫ࡴ࠭ऺ"),l1_fwb_ (u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫ࠧऻ"),l1_fwb_ (u"ࠬ࡯ࡣࡰࡰ़ࠪ")]
    l1l1llll_fwb_ = dict(zip(l1l1ll11_fwb_,[infoLabels.get(x,l1ll1111_fwb_) for x in l1l1ll11_fwb_]))
    l1l1llll_fwb_[l1_fwb_ (u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦࠩऽ")] = fanart if fanart else l1l1llll_fwb_[l1_fwb_ (u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪा")]
    l11l1lll_fwb_.setArt(l1l1llll_fwb_)
    l11l1lll_fwb_.setInfo(type=l1_fwb_ (u"ࠣࡸ࡬ࡨࡪࡵࠢि"), infoLabels=infoLabels)
    if IsPlayable and not isFolder:
        l11l1lll_fwb_.setProperty(l1_fwb_ (u"ࠩࡌࡷࡕࡲࡡࡺࡣࡥࡰࡪ࠭ी"), l1_fwb_ (u"ࠪࡸࡷࡻࡥࠨु"))
    ok = xbmcplugin.addDirectoryItem(handle=l11l1ll1_fwb_, url=u, listitem=l11l1lll_fwb_,isFolder=isFolder,totalItems=l11ll111_fwb_)
    xbmcplugin.addSortMethod(l11l1ll1_fwb_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1_fwb_ (u"ࠦࠪࡘࠬࠡࠧ࡜࠰ࠥࠫࡐࠣू"))
    return ok
def l11lll11_fwb_(name,ex_link=None, l111l1_fwb_=1, mode=l1_fwb_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬृ"),iconImage=l1_fwb_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࠪॄ"), infoLabels={}, fanart=l111l11l_fwb_,contextmenu=None):
    url = l1l1l1ll_fwb_({l1_fwb_ (u"ࠧ࡮ࡱࡧࡩࠬॅ"): mode, l1_fwb_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬॆ"): name, l1_fwb_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪे") : ex_link, l1_fwb_ (u"ࠪࡴࡦ࡭ࡥࠨै") : l111l1_fwb_})
    l11lll1l_fwb_ = xbmcgui.ListItem(name)
    if infoLabels:
        l11lll1l_fwb_.setInfo(type=l1_fwb_ (u"ࠦࡻ࡯ࡤࡦࡱࠥॉ"), infoLabels=infoLabels)
    l1l1ll11_fwb_=[l1_fwb_ (u"ࠬࡺࡨࡶ࡯ࡥࠫॊ"),l1_fwb_ (u"࠭ࡰࡰࡵࡷࡩࡷ࠭ो"),l1_fwb_ (u"ࠧࡣࡣࡱࡲࡪࡸࠧौ"),l1_fwb_ (u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶ्ࠪ"),l1_fwb_ (u"ࠩࡦࡰࡪࡧࡲ࡭ࡱࡪࡳࠬॎ"),l1_fwb_ (u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭ॏ"),l1_fwb_ (u"ࠫ࡮ࡩ࡯࡯ࠩॐ")]
    l1l1llll_fwb_ = dict(zip(l1l1ll11_fwb_,[infoLabels.get(x,iconImage) for x in l1l1ll11_fwb_]))
    l1l1llll_fwb_[l1_fwb_ (u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨ॑")] = fanart if fanart else l1l1llll_fwb_[l1_fwb_ (u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦ॒ࠩ")]
    l11lll1l_fwb_.setArt(l1l1llll_fwb_)
    if contextmenu:
        l1l111l1_fwb_=contextmenu
        l11lll1l_fwb_.addContextMenuItems(l1l111l1_fwb_, replaceItems=True)
    else:
        l1l111l1_fwb_ = []
        l1l111l1_fwb_.append((l1_fwb_ (u"ࠧࡊࡰࡩࡳࡷࡳࡡࡤ࡬ࡤࠫ॓"), l1_fwb_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡁࡤࡶ࡬ࡳࡳ࠮ࡉ࡯ࡨࡲ࠭ࠬ॔")),)
        l11lll1l_fwb_.addContextMenuItems(l1l111l1_fwb_, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=l11l1ll1_fwb_, url=url,listitem=l11lll1l_fwb_, isFolder=True)
    xbmcplugin.addSortMethod(l11l1ll1_fwb_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1_fwb_ (u"ࠤࠨࡖ࠱࡚ࠦࠥ࠮ࠣࠩࡕࠨॕ"))
def l11l1l11_fwb_(name, url=l1_fwb_ (u"ࠪࠫॖ"), mode=l1_fwb_ (u"ࠫࠬॗ"), l1ll1111_fwb_=None, fanart=l111l11l_fwb_):
    u = l1l1l1ll_fwb_({l1_fwb_ (u"ࠬࡳ࡯ࡥࡧࠪक़"): mode, l1_fwb_ (u"࠭ࡦࡰ࡮ࡧࡩࡷࡴࡡ࡮ࡧࠪख़"): name, l1_fwb_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨग़") : url, l1_fwb_ (u"ࠨࡲࡤ࡫ࡪ࠭ज़"):1})
    l11l1lll_fwb_ = xbmcgui.ListItem(name, iconImage=l1ll1111_fwb_, thumbnailImage=l1ll1111_fwb_)
    l11l1lll_fwb_.setProperty(l1_fwb_ (u"ࠩࡌࡷࡕࡲࡡࡺࡣࡥࡰࡪ࠭ड़"), l1_fwb_ (u"ࠪࡪࡦࡲࡳࡦࠩढ़"))
    if fanart:
        l11l1lll_fwb_.setProperty(l1_fwb_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࡣ࡮ࡳࡡࡨࡧࠪफ़"),fanart)
    ok = xbmcplugin.addDirectoryItem(handle=l11l1ll1_fwb_, url=u, listitem=l11l1lll_fwb_,isFolder=False)
    return ok
def l1l1111l_fwb_(l11111ll_fwb_):
    l1l1l11l_fwb_ = {}
    for k, v in l11111ll_fwb_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l1_fwb_ (u"ࠬࡻࡴࡧ࠺ࠪय़"))
        elif isinstance(v, str):
            v.decode(l1_fwb_ (u"࠭ࡵࡵࡨ࠻ࠫॠ"))
        l1l1l11l_fwb_[k] = v
    return l1l1l11l_fwb_
def l1l1l1ll_fwb_(query):
    return l11lllll_fwb_ + l1_fwb_ (u"ࠧࡀࠩॡ") + urllib.urlencode(l1l1111l_fwb_(query))
class l11_fwb_():
    @staticmethod
    def root():
        l11lll11_fwb_(name=l1_fwb_ (u"ࠨࡋࡱࡪࡴࡸ࡭ࡢࡥ࡭ࡥࠬॢ"),mode=l1_fwb_ (u"ࠩࡢ࡭ࡳ࡬࡯ࡠࠩॣ"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1_fwb_ (u"ࠪࡴࡦࡺࡨࠨ।")))+l1_fwb_ (u"ࠫ࠴࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧ॥"),infoLabels={})
        l11lll11_fwb_(name=l1_fwb_ (u"ࠬࡕࡳࡵࡣࡷࡲ࡮ࡵࠠࡅࡱࡧࡥࡳ࡫ࠧ०"),mode=l1_fwb_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧ१"),ex_link=l1_fwb_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡧࡵࡸࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩ२"))
        l11lll11_fwb_(name=l1_fwb_ (u"ࠨࡍࡤࡸࡪ࡭࡯ࡳ࡫ࡨࠫ३"),mode=l1_fwb_ (u"ࠩ࡮ࡥࡹ࡫ࡧࡰࡴ࡬ࡩࠬ४"),ex_link=None)
        l11lll11_fwb_(name=l1_fwb_ (u"ࠪࡗࡿࡻ࡫ࡢ࡬ࠣࡪ࡮ࡲ࡭ࡶࠩ५"),mode=l1_fwb_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫ६"),ex_link=None)
        l11lll11_fwb_(name=l1_fwb_ (u"࡙ࠬࡥࡳ࡫ࡤࡰࡪ࠭७"),mode=l1_fwb_ (u"࠭ࡳࡦࡴ࡬ࡥࡱ࡫ࠧ८"),ex_link=l1_fwb_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡫ࡤࡲࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࠬ९"), iconImage=os.path.join(l111ll11_fwb_,l1_fwb_ (u"ࠨ࡯ࡨࡨ࡮ࡧ࠯࡫ࡤࡲ࠲ࡵࡴࡧࠨ॰")))
        xbmcplugin.endOfDirectory(l11l1ll1_fwb_)
    @staticmethod
    def info():
        l1l11l1l_fwb_.__myinfo__.go(sys.argv)
        xbmcplugin.endOfDirectory(l11l1ll1_fwb_)
    @staticmethod
    def l111ll_fwb_(ex_link=l1_fwb_ (u"ࠩࠪॱ")):
        from l111ll1_fwb_ import l1lll1l1_fwb_
        out = l1lll1l1_fwb_().l111lll_fwb_()
        for l1lll1l_fwb_ in out:
            l11lll11_fwb_(name=l1lll1l_fwb_.get(l1_fwb_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩॲ")),mode=l1_fwb_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬॳ"),ex_link=l1lll1l_fwb_.get(l1_fwb_ (u"ࠬ࡮ࡲࡦࡨࠪॴ")))
        xbmcplugin.endOfDirectory(l11l1ll1_fwb_)
    @staticmethod
    def content(ex_link):
        from l111ll1_fwb_ import l1lll1l1_fwb_
        out,l111l1ll_fwb_ = l1lll1l1_fwb_().l1111ll_fwb_(ex_link)
        l111ll1l_fwb_=l1_fwb_ (u"࠭࡟ࡠࡲࡤ࡫ࡪࡥ࡟࠻ࡥࡲࡲࡹ࡫࡮ࡵࠩॵ")
        if l111l1ll_fwb_[0]:
            l11l11ll_fwb_(name=l1_fwb_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࡂ࠼ࠡࡲࡲࡴࡷࢀࡥࡥࡰ࡬ࡥࠥࡹࡴࡳࡱࡱࡥࠥࡂ࠼࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩॶ"), url=l111l1ll_fwb_[0], mode=l111ll1l_fwb_, IsPlayable=False)
        for f in out:
            l11l11ll_fwb_(name=f.get(l1_fwb_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧॷ")), url=f.get(l1_fwb_ (u"ࠩ࡫ࡶࡪ࡬ࠧॸ")), mode=l1_fwb_ (u"ࠪࡴࡱࡧࡹࡣࡱࡻࡪ࡮ࡲ࡭ࠨॹ"), l1ll1111_fwb_=f.get(l1_fwb_ (u"ࠫ࡮ࡳࡧࠨॺ")), infoLabels=f, IsPlayable=True)
        if l111l1ll_fwb_[1]:
            l11l11ll_fwb_(name=l1_fwb_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡨ࡬ࡶࡧࡠࡂࡃࠦ࡮ࡢࡵࡷझࡵࡴࡡࠡࡵࡷࡶࡴࡴࡡࠡࡀࡁ࡟࠴ࡉࡏࡍࡑࡕࡡࠬॻ"), url=l111l1ll_fwb_[1], mode=l111ll1l_fwb_, IsPlayable=False)
        xbmcplugin.setContent(l11l1ll1_fwb_, l1_fwb_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭ॼ"))
        xbmcplugin.endOfDirectory(l11l1ll1_fwb_)
    @staticmethod
    def l11ll_fwb_(mode,ex_link):
        _1111l11_fwb_=mode.split(l1_fwb_ (u"ࠢ࠻ࠤॽ"))[-1]
        url = l1l1l1ll_fwb_({l1_fwb_ (u"ࠨ࡯ࡲࡨࡪ࠭ॾ"): _1111l11_fwb_, l1_fwb_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭ॿ"): l1_fwb_ (u"ࠪࠫঀ"), l1_fwb_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬঁ") : ex_link })
        xbmc.executebuiltin(l1_fwb_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠨࠦࡵࠬࠫং")% url)
    @staticmethod
    def l1llll_fwb_(mode,ex_link):
        from l111lll1_fwb_ import l111l111_fwb_
        l1111l1l_fwb_=mode.split(l1_fwb_ (u"ࠨ࠺ࠣঃ"))[-1] if l1_fwb_ (u"ࠧ࠻ࠩ঄") in mode else l1_fwb_ (u"ࠨࠩঅ")
        if l1111l1l_fwb_ == l1_fwb_ (u"ࠩࠪআ"):
            l11lll11_fwb_(l1_fwb_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡰ࡮࡭ࡨࡵࡩࡵࡩࡪࡴ࡝ࡏࡱࡺࡩ࡙ࠥࡺࡶ࡭ࡤࡲ࡮࡫࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨই"),ex_link=l1_fwb_ (u"ࠫࠬঈ"),mode=l1_fwb_ (u"ࠬࡹࡥࡢࡴࡦ࡬࠿ࡴࡥࡸࠩউ"))
            l111l1l1_fwb_ = l111l111_fwb_().l11ll11l_fwb_()
            if not l111l1l1_fwb_ == [l1_fwb_ (u"࠭ࠧঊ")]:
                for entry in l111l1l1_fwb_:
                    contextmenu = []
                    contextmenu.append((l1_fwb_ (u"ࡵࠨࡗࡶࡹࡳ࠭ঋ"), l1_fwb_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠫࠩࡸ࠯ࠧঌ")% l1l1l1ll_fwb_({l1_fwb_ (u"ࠩࡰࡳࡩ࡫ࠧ঍"): l1_fwb_ (u"ࠪࡷࡪࡧࡲࡤࡪ࠽ࡨࡪࡲࡏ࡯ࡧࠪ঎"), l1_fwb_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬএ") : entry})),)
                    contextmenu.append((l1_fwb_ (u"ࡺ࠭ࡕࡴࡷࡱࠤࡨࡧूࡢࠢ࡫࡭ࡸࡺ࡯ࡳ࡫ࡨࠫঐ"), l1_fwb_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࠦࡵࠬࠫ঑") % l1l1l1ll_fwb_({l1_fwb_ (u"ࠧ࡮ࡱࡧࡩࠬ঒"): l1_fwb_ (u"ࠨࡵࡨࡥࡷࡩࡨ࠻ࡦࡨࡰࡆࡲ࡬ࠨও")})),)
                    l11lll11_fwb_(name=entry, ex_link=entry.replace(l1_fwb_ (u"ࠩࠣࠫঔ"),l1_fwb_ (u"ࠪ࠯ࠬক")), mode=l1_fwb_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫࠾ࡳ࡫ࡷࠨখ"), fanart=None, contextmenu=contextmenu)
            xbmcplugin.endOfDirectory(l11l1ll1_fwb_)
        elif l1111l1l_fwb_ ==l1_fwb_ (u"ࠬࡴࡥࡸࠩগ"):
            if not ex_link:
                l1111lll_fwb_ = l1lll1_fwb_.input(l1_fwb_ (u"ࡻࠧࡔࡼࡸ࡯ࡦࡰࠬࠡࡒࡲࡨࡦࡰࠠࡵࡻࡷࡹेࠦࡦࡪ࡮ࡰࡹࠬঘ"), type=xbmcgui.INPUT_ALPHANUM)
                if l1111lll_fwb_: l111l111_fwb_().l11l1111_fwb_(l1111lll_fwb_)
            else:
                l1111lll_fwb_ = ex_link
            if l1111lll_fwb_:
                from l111ll1_fwb_ import l1lll1l1_fwb_
                out,l111l1ll_fwb_ = l1lll1l1_fwb_().l1111ll_fwb_(l1_fwb_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡧࡵࡸࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࡵࡽࡹࡰࡧࡪࠨঙ"),l1111lll_fwb_.replace(l1_fwb_ (u"ࠨࠢࠪচ"),l1_fwb_ (u"ࠩ࠮ࠫছ")))
                for f in out:
                    l11l11ll_fwb_(name=f.get(l1_fwb_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩজ")), url=f.get(l1_fwb_ (u"ࠫ࡭ࡸࡥࡧࠩঝ")), mode=l1_fwb_ (u"ࠬࡶ࡬ࡢࡻࡥࡳࡽ࡬ࡩ࡭࡯ࠪঞ"), l1ll1111_fwb_=f.get(l1_fwb_ (u"࠭ࡩ࡮ࡩࠪট")), infoLabels=f, IsPlayable=True)
            xbmcplugin.endOfDirectory(l11l1ll1_fwb_)
        elif l1111l1l_fwb_ ==l1_fwb_ (u"ࠧࡥࡧ࡯ࡓࡳ࡫ࠧঠ"):
            l111l111_fwb_().l1l111ll_fwb_(ex_link)
            xbmc.executebuiltin(l1_fwb_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠫࠩࡸ࠯ࠧড")%  l1l1l1ll_fwb_({l1_fwb_ (u"ࠩࡰࡳࡩ࡫ࠧঢ"): l1_fwb_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪণ")}))
        elif l1111l1l_fwb_ ==l1_fwb_ (u"ࠫࡩ࡫࡬ࡂ࡮࡯ࠫত"):
            l111l111_fwb_().l1l1l1l1_fwb_()
            xbmc.executebuiltin(l1_fwb_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠨࠦࡵࠬࠫথ")%  l1l1l1ll_fwb_({l1_fwb_ (u"࠭࡭ࡰࡦࡨࠫদ"): l1_fwb_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧধ")}))
        xbmcplugin.setContent(l11l1ll1_fwb_, l1_fwb_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨন"))
    @staticmethod
    def l11lll_fwb_(ex_link):
        from l111ll1_fwb_ import l1lll1l1_fwb_
        l111llll_fwb_ = l1lll1l1_fwb_().l11lll1_fwb_(ex_link)
        if l111llll_fwb_:
            l11l111l_fwb_=l1l11l1l_fwb_.__mysolver__.go(l111llll_fwb_)
            if not l11l111l_fwb_:
                try:
                    import urlresolver
                    l11l111l_fwb_ = urlresolver.resolve(l111llll_fwb_)
                except Exception,e:
                    l11l111l_fwb_=l1_fwb_ (u"ࠩࠪ঩")
            if l11l111l_fwb_:
                xbmcplugin.setResolvedUrl(l11l1ll1_fwb_, True, xbmcgui.ListItem(path=l11l111l_fwb_))
            else:
                xbmcplugin.setResolvedUrl(l11l1ll1_fwb_, False, xbmcgui.ListItem(path=l1_fwb_ (u"ࠪࠫপ")))
        else:
            l1lll1_fwb_.notification(l1l1lll1_fwb_, l1_fwb_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞࡝ࡅࡡࠥࡈࡲࡢ࡭ࠣॾࡷࣹࡤࡦॄࠣ࡟࠴ࡈ࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩফ") , xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1_fwb_ (u"ࠬࡶࡡࡵࡪࠪব")))+l1_fwb_ (u"࠭࠯ࡪࡥࡲࡲ࠳ࡶ࡮ࡨࠩভ"), 5000, False)
    @staticmethod
    def l11l1_fwb_(ex_link):
        from l111ll1_fwb_ import l111l1l_fwb_
        out = l111l1l_fwb_().l1111ll_fwb_(ex_link)
        for f in out:
            l11lll11_fwb_(name=f.get(l1_fwb_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ম")),ex_link=f.get(l1_fwb_ (u"ࠨࡪࡵࡩ࡫࠭য")),  mode=l1_fwb_ (u"ࠩࡶࡩࡷ࡯ࡡ࡭ࡧࡢࡷࡪࡧࡳࡰࡰࡶࠫর"),iconImage=f.get(l1_fwb_ (u"ࠪ࡭ࡲ࡭ࠧ঱")), infoLabels=f)
        xbmcplugin.setContent(l11l1ll1_fwb_, l1_fwb_ (u"ࠫࡹࡼࡳࡩࡱࡺࡷࠬল"))
        xbmcplugin.endOfDirectory(l11l1ll1_fwb_)
    @staticmethod
    def l1ll1l_fwb_(ex_link):
        from l111ll1_fwb_ import l111l1l_fwb_
        out = l111l1l_fwb_().l1ll1l11_fwb_(ex_link)
        l111l11_fwb_ = l111l1l_fwb_().l1lllll1_fwb_(out)
        for l1l1l111_fwb_ in sorted(l111l11_fwb_.keys()):
            l11lll11_fwb_(name=l1l1l111_fwb_, ex_link=urllib.quote(str(l111l11_fwb_[l1l1l111_fwb_])), mode=l1_fwb_ (u"ࠬࡹࡥࡳ࡫ࡤࡰࡪࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ঳"))
        xbmcplugin.setContent(l11l1ll1_fwb_, l1_fwb_ (u"࠭ࡴࡷࡵ࡫ࡳࡼࡹࠧ঴"))
        xbmcplugin.endOfDirectory(l11l1ll1_fwb_)
    @staticmethod
    def l11l1l_fwb_(ex_link):
        l1lll1ll_fwb_ = eval(urllib.unquote(ex_link))
        for f in l1lll1ll_fwb_:
            l11l11ll_fwb_(name=f.get(l1_fwb_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭঵")), url=f.get(l1_fwb_ (u"ࠨࡪࡵࡩ࡫࠭শ")), mode=l1_fwb_ (u"ࠩࡳࡰࡦࡿࡓࡦࡴ࡬ࡥࡱ࡫ࠧষ"), l1ll1111_fwb_=f.get(l1_fwb_ (u"ࠪ࡭ࡲ࡭ࠧস")), infoLabels=f, IsPlayable=True)
        xbmcplugin.setContent(l11l1ll1_fwb_, l1_fwb_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭হ"))
        xbmcplugin.endOfDirectory(l11l1ll1_fwb_)
    @staticmethod
    def l1ll1_fwb_(ex_link):
        from l111ll1_fwb_ import l111l1l_fwb_
        l111llll_fwb_ = l111l1l_fwb_().l1ll1l1_fwb_(ex_link)
        if l111llll_fwb_:
            l11l111l_fwb_=l1l11l1l_fwb_.__mysolver__.go(l111llll_fwb_)
            if not l11l111l_fwb_:
                try:
                    import urlresolver
                    l11l111l_fwb_ = urlresolver.resolve(l111llll_fwb_)
                except Exception,e:
                    l11l111l_fwb_=l1_fwb_ (u"ࠬ࠭঺")
            if l11l111l_fwb_:
                xbmcplugin.setResolvedUrl(l11l1ll1_fwb_, True, xbmcgui.ListItem(path=l11l111l_fwb_))
            else:
                xbmcplugin.setResolvedUrl(l11l1ll1_fwb_, False, xbmcgui.ListItem(path=l1_fwb_ (u"࠭ࠧ঻")))
        else:
            l1lll1_fwb_.notification(l1l1lll1_fwb_, l1_fwb_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࡠࡈ࡝ࠡࡄࡵࡥࡰࠦॺࡳࣵࡧࡩे࡛ࠦ࠰ࡄࡠ࡟࠴ࡉࡏࡍࡑࡕࡡ়ࠬ") , xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1_fwb_ (u"ࠨࡲࡤࡸ࡭࠭ঽ")))+l1_fwb_ (u"ࠩ࠲࡭ࡨࡵ࡮࠯ࡲࡱ࡫ࠬা"), 5000, False)
