# -*- coding: utf-8 -*-
import sys
l1l1l_fwb_ = sys.version_info [0] == 2
l1l1ll_fwb_ = 2048
l1l11_fwb_ = 7
def l1_fwb_ (keyedStringLiteral):
	global l11l11_fwb_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l1l_fwb_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l1ll_fwb_ - (charIndex + stringNr) % l1l11_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l1ll_fwb_ - (charIndex + stringNr) % l1l11_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import xbmcaddon
l1l1lll1_fwb_       = xbmcaddon.Addon().getAddonInfo(l1_fwb_ (u"ࠪࡲࡦࡳࡥࠨি"))
class l111l111_fwb_():
    def __init__(self,name=l1l1lll1_fwb_):
        try:
            import StorageServer
        except:
            import storageserverdummy as StorageServer
        self.cache = StorageServer.StorageServer(name)
    def l1llllll1_fwb_(self,t):
        return t.encode(l1_fwb_ (u"ࠫࡺࡺࡦ࠮࠺ࠪী")) if isinstance(t,unicode) else t
    def l11ll11l_fwb_(self):
        return self.cache.get(l1_fwb_ (u"ࠬ࡮ࡩࡴࡶࡲࡶࡾ࠭ু")).split(l1_fwb_ (u"࠭࠻ࠨূ"))
    def l11l1111_fwb_(self,entry):
        l1lllll1l_fwb_ = self.l11ll11l_fwb_()
        if l1lllll1l_fwb_ == [l1_fwb_ (u"ࠧࠨৃ")]:
            l1lllll1l_fwb_ = []
        l1lllll1l_fwb_.insert(0, self.l1llllll1_fwb_(entry))
        try:
            self.cache.set(l1_fwb_ (u"ࠨࡪ࡬ࡷࡹࡵࡲࡺࠩৄ"),l1_fwb_ (u"ࡷࠪ࠿ࠬ৅").join(l1lllll1l_fwb_[:50]))
        except:
            pass
    def l1l111ll_fwb_(self,entry):
        l1lllll1l_fwb_ = self.l11ll11l_fwb_()
        if l1lllll1l_fwb_:
            try:
                self.cache.set(l1_fwb_ (u"ࠪ࡬࡮ࡹࡴࡰࡴࡼࠫ৆"),l1_fwb_ (u"ࠫࡀ࠭ে").join(l1lllll1l_fwb_[:50]))
            except:
                pass
        else:
            self.l1l1l1l1_fwb_()
    def l1l1l1l1_fwb_(self):
        self.cache.delete(l1_fwb_ (u"ࠬ࡮ࡩࡴࡶࡲࡶࡾ࠭ৈ"))
