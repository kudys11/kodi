# coding: UTF-8
import sys
l1l1l_fwb_ = sys.version_info [0] == 2
l1l1ll_fwb_ = 2048
l1l11_fwb_ = 7
def l1_fwb_ (keyedStringLiteral):
	global l11l11_fwb_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l1l_fwb_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l1ll_fwb_ - (charIndex + stringNr) % l1l11_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l1ll_fwb_ - (charIndex + stringNr) % l1l11_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)