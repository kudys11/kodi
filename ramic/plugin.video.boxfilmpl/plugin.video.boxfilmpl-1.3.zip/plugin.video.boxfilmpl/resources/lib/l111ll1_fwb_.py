# -*- coding: utf-8 -*-
import sys
l1l1l_fwb_ = sys.version_info [0] == 2
l1l1ll_fwb_ = 2048
l1l11_fwb_ = 7
def l1_fwb_ (keyedStringLiteral):
	global l11l11_fwb_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l1l_fwb_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l1ll_fwb_ - (charIndex + stringNr) % l1l11_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l1ll_fwb_ - (charIndex + stringNr) % l1l11_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os,json,base64
import cookielib
from urlparse import urlparse,urljoin
l1ll11l_fwb_ = 15
l1ll11l1_fwb_=l1_fwb_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠻࠴࠱࠼࡚ࠢ࡭ࡳ࠼࠴࠼ࠢࡻ࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠻࠷࠮࠱࠰࠶࠵࠻࠹࠮࠲࠲࠳ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫ࡟")
try:
    from xbmc import translatePath
    from xbmcaddon import Addon
    l1lll11_fwb_    = translatePath(Addon().getAddonInfo(l1_fwb_ (u"ࠩࡳࡶࡴ࡬ࡩ࡭ࡧࠪࡠ"))).decode(l1_fwb_ (u"ࠪࡹࡹ࡬࠭࠹ࠩࡡ"))
    l1111l1_fwb_=os.path.join(l1lll11_fwb_,l1_fwb_ (u"ࠫࡨࡵ࡯࡬࡫ࡨࠫࡢ"))
except:
    l1111l1_fwb_=l1_fwb_ (u"ࡷ࠭ࡢࡰࡺࡩ࡭ࡱࡳ࠮ࡤࡱࡲ࡯࡮࡫ࠧࡣ")
l1llll1l_fwb_ = l1_fwb_ (u"࠭ࠧࡤ")
class l1ll1lll_fwb_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
def l11l111_fwb_(url,data=None):
    l1llll1_fwb_ = cookielib.LWPCookieJar()
    if data:
        opener = urllib2.build_opener(l1ll1lll_fwb_, urllib2.HTTPCookieProcessor(l1llll1_fwb_))
    else:
        opener = urllib2.build_opener( urllib2.HTTPCookieProcessor(l1llll1_fwb_))
    opener.addheaders = [(l1_fwb_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫࡥ"), l1ll11l1_fwb_)]
    try:
        response = opener.open(url,data,l1ll11l_fwb_)
        result= response.read()
        response.close()
    except:
        result=l11111l_fwb_ = e.read()
    return result
def l11ll11_fwb_(l1l1ll1_fwb_):
    if isinstance(l1l1ll1_fwb_, unicode):
        l1l1ll1_fwb_ = l1l1ll1_fwb_.encode(l1_fwb_ (u"ࠨࡷࡷࡪ࠲࠾ࠧࡦ"))
    l1l1ll1_fwb_ = l1l1ll1_fwb_.replace(l1_fwb_ (u"ࠩࠩࡰࡹࡁࡢࡳ࠱ࠩ࡫ࡹࡁࠧࡧ"),l1_fwb_ (u"ࠪࠤࠬࡨ"))
    s=l1_fwb_ (u"ࠫࡏ࡯ࡎࡤ࡜ࡆࡷ࠼࠭ࡩ")
    l1l1ll1_fwb_ = re.sub(s.decode(l1_fwb_ (u"ࠬࡨࡡࡴࡧ࠹࠸ࠬࡪ")),l1_fwb_ (u"࠭ࠧ࡫"),l1l1ll1_fwb_)
    l1l1ll1_fwb_ = l1l1ll1_fwb_.replace(l1_fwb_ (u"ࠧ࡝ࡰࠪ࡬"),l1_fwb_ (u"ࠨࠩ࡭")).replace(l1_fwb_ (u"ࠩ࡟ࡶࠬ࡮"),l1_fwb_ (u"ࠪࠫ࡯"))
    l1l1ll1_fwb_ = l1l1ll1_fwb_.replace(l1_fwb_ (u"ࠫࠫࡴࡢࡴࡲ࠾ࠫࡰ"),l1_fwb_ (u"ࠬ࠭ࡱ"))
    l1l1ll1_fwb_ = l1l1ll1_fwb_.replace(l1_fwb_ (u"࠭ࠦࡲࡷࡲࡸࡀ࠭ࡲ"),l1_fwb_ (u"ࠧࠣࠩࡳ")).replace(l1_fwb_ (u"ࠨࠨࡤࡱࡵࡁࡱࡶࡱࡷ࠿ࠬࡴ"),l1_fwb_ (u"ࠩࠥࠫࡵ"))
    l1l1ll1_fwb_ = l1l1ll1_fwb_.replace(l1_fwb_ (u"ࠪࠪࡴࡧࡣࡶࡶࡨ࠿ࠬࡶ"),l1_fwb_ (u"ࠫࣸ࠭ࡷ")).replace(l1_fwb_ (u"ࠬࠬࡏࡢࡥࡸࡸࡪࡁࠧࡸ"),l1_fwb_ (u"࣓࠭ࠨࡹ"))
    l1l1ll1_fwb_ = l1l1ll1_fwb_.replace(l1_fwb_ (u"ࠧࠧࡣࡰࡴࡀࡵࡡࡤࡷࡷࡩࡀ࠭ࡺ"),l1_fwb_ (u"ࠨࣵࠪࡻ")).replace(l1_fwb_ (u"ࠩࠩࡥࡲࡶ࠻ࡐࡣࡦࡹࡹ࡫࠻ࠨࡼ"),l1_fwb_ (u"ࠪࣗࠬࡽ"))
    l1l1ll1_fwb_ = l1l1ll1_fwb_.replace(l1_fwb_ (u"ࠫࠫࡧ࡭ࡱ࠽ࠪࡾ"),l1_fwb_ (u"ࠬࠬࠧࡿ"))
    l1l1ll1_fwb_ = l1l1ll1_fwb_.replace(l1_fwb_ (u"࠭࡜ࡶ࠲࠴࠴࠺࠭ࢀ"),l1_fwb_ (u"ࠧआࠩࢁ")).replace(l1_fwb_ (u"ࠨ࡞ࡸ࠴࠶࠶࠴ࠨࢂ"),l1_fwb_ (u"ࠩइࠫࢃ"))
    l1l1ll1_fwb_ = l1l1ll1_fwb_.replace(l1_fwb_ (u"ࠪࡠࡺ࠶࠱࠱࠹ࠪࢄ"),l1_fwb_ (u"ࠫऌ࠭ࢅ")).replace(l1_fwb_ (u"ࠬࡢࡵ࠱࠳࠳࠺ࠬࢆ"),l1_fwb_ (u"࠭आࠨࢇ"))
    l1l1ll1_fwb_ = l1l1ll1_fwb_.replace(l1_fwb_ (u"ࠧ࡝ࡷ࠳࠵࠶࠿ࠧ࢈"),l1_fwb_ (u"ࠨछࠪࢉ")).replace(l1_fwb_ (u"ࠩ࡟ࡹ࠵࠷࠱࠹ࠩࢊ"),l1_fwb_ (u"ࠪजࠬࢋ"))
    l1l1ll1_fwb_ = l1l1ll1_fwb_.replace(l1_fwb_ (u"ࠫࡡࡻ࠰࠲࠶࠵ࠫࢌ"),l1_fwb_ (u"ࠬैࠧࢍ")).replace(l1_fwb_ (u"࠭࡜ࡶ࠲࠴࠸࠶࠭ࢎ"),l1_fwb_ (u"ࠧूࠩ࢏"))
    l1l1ll1_fwb_ = l1l1ll1_fwb_.replace(l1_fwb_ (u"ࠨ࡞ࡸ࠴࠶࠺࠴ࠨ࢐"),l1_fwb_ (u"ࠩेࠫ࢑")).replace(l1_fwb_ (u"ࠪࡠࡺ࠶࠱࠵࠶ࠪ࢒"),l1_fwb_ (u"ࠫै࠭࢓"))
    l1l1ll1_fwb_ = l1l1ll1_fwb_.replace(l1_fwb_ (u"ࠬࡢࡵ࠱࠲ࡩ࠷ࠬ࢔"),l1_fwb_ (u"࠭ࣳࠨ࢕")).replace(l1_fwb_ (u"ࠧ࡝ࡷ࠳࠴ࡩ࠹ࠧ࢖"),l1_fwb_ (u"ࠨࣕࠪࢗ"))
    l1l1ll1_fwb_ = l1l1ll1_fwb_.replace(l1_fwb_ (u"ࠩ࡟ࡹ࠵࠷࠵ࡣࠩ࢘"),l1_fwb_ (u"ࠪय़࢙ࠬ")).replace(l1_fwb_ (u"ࠫࡡࡻ࠰࠲࠷ࡤ࢚ࠫ"),l1_fwb_ (u"ࠬॠ࢛ࠧ"))
    l1l1ll1_fwb_ = l1l1ll1_fwb_.replace(l1_fwb_ (u"࠭࡜ࡶ࠲࠴࠻ࡦ࠭࢜"),l1_fwb_ (u"ࠧॻࠩ࢝")).replace(l1_fwb_ (u"ࠨ࡞ࡸ࠴࠶࠽࠹ࠨ࢞"),l1_fwb_ (u"ࠩॼࠫ࢟"))
    l1l1ll1_fwb_ = l1l1ll1_fwb_.replace(l1_fwb_ (u"ࠪࡠࡺ࠶࠱࠸ࡥࠪࢠ"),l1_fwb_ (u"ࠫঁ࠭ࢡ")).replace(l1_fwb_ (u"ࠬࡢࡵ࠱࠳࠺ࡦࠬࢢ"),l1_fwb_ (u"࠭ॻࠨࢣ"))
    return l1l1ll1_fwb_
class l111l1l_fwb_:
    def l1l11ll_fwb_(self,url):
        if not url:
            url = l1_fwb_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡫ࡤࡲࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࠬࢤ")
        elif url.startswith(l1_fwb_ (u"ࠨ࠱࠲ࠫࢥ")):
            url = l1_fwb_ (u"ࠩ࡫ࡸࡹࡶࠧࢦ")+url
        elif url.startswith(l1_fwb_ (u"ࠪ࠳ࠬࢧ")):
            url = urljoin(l1_fwb_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩࢨ"),url)
        return url
    @staticmethod
    def l1111ll_fwb_(url=l1_fwb_ (u"ࠬ࠭ࢩ")):
        if not url:
            url = l1_fwb_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡪࡣࡱࡩ࡭ࡱࡳ࠮ࡱ࡮࠲ࠫࢪ")
        elif url.startswith(l1_fwb_ (u"ࠧ࠰ࠩࢫ")):
            url = urljoin(l1_fwb_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡬ࡥࡳ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭ࢬ"),url)
        content = l11l111_fwb_(url)
        out=[]
        l11l11l_fwb_ = re.compile(l1_fwb_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡪࡴࡴ࠮ࡩࡵ࡭ࡩࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬࢭ"),re.DOTALL).findall(content)
        for show in l11l11l_fwb_:
            l11llll_fwb_ = re.findall(l1_fwb_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠯ࡴࡧࡵ࡭ࡦࡲࡥ࠰࠰࠭࠭ࠧࡄ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࢮ"),show)
            if l11llll_fwb_:
                l1l1111_fwb_ = l11llll_fwb_[0][1]
                l1l1111_fwb_ = urljoin(l1_fwb_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩࢯ"),l1l1111_fwb_) if not l1l1111_fwb_.startswith(l1_fwb_ (u"ࠬ࡮ࡴࡵࡲࠪࢰ")) else l1l1111_fwb_
                title = l11llll_fwb_[0][0].replace(l1_fwb_ (u"࠭࠯ࡴࡧࡵ࡭ࡦࡲࡥ࠰ࠩࢱ"),l1_fwb_ (u"ࠧࠨࢲ")).replace(l1_fwb_ (u"ࠨ࠯ࠪࢳ"),l1_fwb_ (u"ࠩࠣࠫࢴ")).replace(l1_fwb_ (u"ࠪ࠳ࠬࢵ"),l1_fwb_ (u"ࠫࠬࢶ")).title()
                out.append({l1_fwb_ (u"ࠬ࡮ࡲࡦࡨࠪࢷ"):l11llll_fwb_[0][0],l1_fwb_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࢸ"):title,l1_fwb_ (u"ࠧࡪ࡯ࡪࠫࢹ"):l1l1111_fwb_})
        idx = content.find(l1_fwb_ (u"ࠨࡪ࠶ࡂࡘ࡫ࡲࡪࡣ࡯ࡩࡁ࠵ࡨ࠴ࡀࠪࢺ"))
        if idx:
            l1lll11l_fwb_ = re.compile(l1_fwb_ (u"ࠩ࠿ࡹࡱࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪࢻ"),re.DOTALL).search(content[idx:-1])
            l1lll11l_fwb_ = l1lll11l_fwb_.group(1) if l1lll11l_fwb_ else l1_fwb_ (u"ࠪࠫࢼ")
            l1lll11l_fwb_ = re.sub(l1_fwb_ (u"ࡶࠧࡂࠡ࠮࠯ࠫ࠲ࢁࡢࡳࡽ࡞ࡱ࠭࠯ࡅ࠭࠮ࡀࠥࢽ"), l1_fwb_ (u"ࠧࠨࢾ"), l1lll11l_fwb_)
            l1lll111_fwb_ = re.compile(l1_fwb_ (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠯ࡴࡧࡵ࡭ࡦࡲࡥ࠰࠰࠭ࡃ࠮ࠨ࠾ࠩ࡝ࡡࡂࡢ࠰ࠩ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠪࢿ")).findall(l1lll11l_fwb_)
            for href,title in l1lll111_fwb_:
                out.append({l1_fwb_ (u"ࠧࡩࡴࡨࡪࠬࣀ"):href,l1_fwb_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࣁ"):title})
        return out
    @staticmethod
    def l1ll1l11_fwb_(url=l1_fwb_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡭ࡦࡴ࡬ࡩ࡭࡯࠱ࡴࡱ࠵ࡳࡦࡴ࡬ࡥࡱ࡫࠯ࡥࡧࡷࡩࡰࡺࡹࡸ࠱ࠪࣂ")):
        if not url:
            url = l1_fwb_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡮ࡧࡵࡦࡪ࡮ࡰ࠲ࡵࡲ࠯ࠨࣃ")
        if url.startswith(l1_fwb_ (u"ࠫ࠴࠵ࠧࣄ")):
            url = l1_fwb_ (u"ࠬ࡮ࡴࡵࡲࠪࣅ")+url
        if url.startswith(l1_fwb_ (u"࠭࠯ࠨࣆ")):
            url = urljoin(l1_fwb_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡫ࡤࡲࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࠬࣇ"),url)
        url += l1_fwb_ (u"ࠨ࠱ࠪࣈ") if not url.endswith(l1_fwb_ (u"ࠩ࠲ࠫࣉ")) else l1_fwb_ (u"ࠪࠫ࣊")
        content = l11l111_fwb_(url)
        out=[]
        l1lll1ll_fwb_ = re.compile(l1_fwb_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶ࠰࡫ࡷ࡯ࡤࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ࣋"),re.DOTALL).findall(content)
        for l1l1l1l_fwb_ in l1lll1ll_fwb_:
            l1llllll_fwb_ = re.findall(l1_fwb_ (u"ࠬࡹࡥࡻࡱࡱࡠࡸ࠰ࠨ࡝ࡦ࠮࠭ࠬ࣌"),l1l1l1l_fwb_,re.I)
            l1llllll_fwb_ = l1llllll_fwb_[0] if l1llllll_fwb_ else l1_fwb_ (u"࠭ࠧ࣍")
            l1ll11ll_fwb_ = re.findall(l1_fwb_ (u"ࠧࡐࡦࡦ࡭ࡳ࡫࡫࡝ࡵ࠭ࠬࡡࡪࠫࠪࠩ࣎"),l1l1l1l_fwb_,re.I)
            l1ll11ll_fwb_ = l1ll11ll_fwb_[0] if l1ll11ll_fwb_ else l1_fwb_ (u"ࠨ࣏ࠩ")
            href = re.compile(l1_fwb_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭ࡹࡩ࡯ࡩ࡯ࡩࡵࡧࡧࡦ࠰ࡳ࡬ࡵࡢ࠿ࡪࡦࡀࡠࡩ࠱࣐ࠩࠣࠩ")).findall(l1l1l1l_fwb_)
            l1l1111_fwb_ = re.findall(l1_fwb_ (u"ࠪࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࣑࠭ࠧ࠭"),l1l1l1l_fwb_)
            if href and l1llllll_fwb_ and l1ll11ll_fwb_:
                l1l1111_fwb_ = urljoin(l1_fwb_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰࣒ࠩ"),l1l1111_fwb_[0]) if not l1l1111_fwb_[0].startswith(l1_fwb_ (u"ࠬ࡮ࡴࡵࡲ࣓ࠪ")) else l1_fwb_ (u"࠭ࠧࣔ")
                out.append({l1_fwb_ (u"ࠧࡩࡴࡨࡪࠬࣕ"):url+href[0],l1_fwb_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࣖ"):l1_fwb_ (u"ࠩࡖࡩࡿࡵ࡮ࠡࠧࡶ࠰ࠥࡋࡰࡪࡼࡲࡨࠥࠫࡳࠨࣗ")%(l1llllll_fwb_,l1ll11ll_fwb_),l1_fwb_ (u"ࠪ࡭ࡲ࡭ࠧࣘ"):l1l1111_fwb_,
                l1_fwb_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࠫࣙ"):int(l1llllll_fwb_),l1_fwb_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪ࠭ࣚ"):int(l1ll11ll_fwb_)})
        return out
    @staticmethod
    def l1lllll1_fwb_(out):
        l1ll111_fwb_={}
        l111l11_fwb_ = [x.get(l1_fwb_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭ࣛ")) for x in out]
        for s in set(l111l11_fwb_):
            l1ll111_fwb_[l1_fwb_ (u"ࠧࡔࡧࡽࡳࡳࠦࠥ࠱࠴ࡧࠫࣜ")%s]=[out[i] for i, j in enumerate(l111l11_fwb_) if j == s]
        return l1ll111_fwb_
    @staticmethod
    def l1ll1l1_fwb_(url):
        content = l11l111_fwb_(url)
        l1l11l1_fwb_=l1_fwb_ (u"ࠨࠩࣝ")
        l1l111l_fwb_ = re.compile(l1_fwb_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠫ࠲࠯ࡅࠩ࠽࠱࡬ࡪࡷࡧ࡭ࡦࡀࠪࣞ"),re.DOTALL).findall(content)
        if l1l111l_fwb_:
            src = re.compile(l1_fwb_ (u"ࠪࡷࡷࡩ࠽࡜࡞ࠪࠦࡢ࠮࠮ࠫࡁࠬ࡟ࡡ࠭ࠢ࡞ࠩࣟ"),re.DOTALL).findall(l1l111l_fwb_[0])
            l1l11l1_fwb_ = src[0] if src else l1_fwb_ (u"ࠫࠬ࣠")
        return l1l11l1_fwb_
class l1lll1l1_fwb_:
    @staticmethod
    def l1111ll_fwb_(url,l11ll1l_fwb_=None):
        if l11ll1l_fwb_:
            l11ll1l_fwb_ = l1_fwb_ (u"ࠬࡹࡺࡶ࡭ࡤ࡮ࡂ࠭࣡")+l11ll1l_fwb_.replace(l1_fwb_ (u"࠭ࠠࠨ࣢"),l1_fwb_ (u"ࣣࠧࠬࠩ"))
            url= l1_fwb_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡨ࡯ࡹࡨ࡬ࡰࡲ࠴ࡰ࡭࠱ࡶࡾࡺࡱࡡ࡫ࠩࣤ")
        if not url:
            url = l1_fwb_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡰࡺࡩ࡭ࡱࡳ࠮ࡱ࡮࠲ࠫࣥ")
        elif url.startswith(l1_fwb_ (u"ࠪ࠳ࣦࠬ")):
            url = urljoin(l1_fwb_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡲࡼ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭ࣧ"),url)
        content = l11l111_fwb_(url,l11ll1l_fwb_)
        ids = [(a.start(), a.end()) for a in re.finditer(l1_fwb_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡺ࡮ࡪࡥࡰࡡ࡬ࡲ࡫ࡵࠢ࠿ࠩࣨ"), content,re.IGNORECASE)]
        ids.append( (-1,-1) )
        out=[]
        for i in range(len(ids[:-1])):
            l1lllll_fwb_ = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile(l1_fwb_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࣩ"),re.DOTALL).search(l1lllll_fwb_)
            title = re.compile(l1_fwb_ (u"ࠧ࠽ࡪ࠴ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠷࠾ࠨ࣪"),re.DOTALL).search(l1lllll_fwb_)
            l1l1111_fwb_ = re.compile(l1_fwb_ (u"ࠨ࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࣫"),re.DOTALL).search(l1lllll_fwb_)
            l1ll1ll1_fwb_ = re.findall(l1_fwb_ (u"ࠩࡏࡩࡰࡺ࡯ࡳ࠼࡟ࡷ࠯ࡂࡳࡱࡣࡱࠤࡸࡺࡹ࡭ࡧࡀࠦࡠࡤ࠾࡞ࠬࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ࣬"),l1lllll_fwb_)
            l1llll11_fwb_ = re.findall(l1_fwb_ (u"ࠪࡈࡴࡪࡡ࡯ࡻ࠽ࡠࡸ࠰࠼ࡴࡲࡤࡲࠥࡹࡴࡺ࡮ࡨࡁࠧࡡ࡞࠿࡟࠭ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁ࣭ࠫ"),l1lllll_fwb_)
            l1ll1l1l_fwb_ = re.findall(l1_fwb_ (u"ࠫࡌࡧࡴࡶࡰࡨ࡯࠿ࡢࡳࠫ࠾ࡶࡴࡦࡴࠠࡴࡶࡼࡰࡪࡃࠢ࡜ࡠࡁࡡ࠯ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࣮࠭"),l1lllll_fwb_)
            l1ll1ll1_fwb_ = l1ll1ll1_fwb_[0] if l1ll1ll1_fwb_ else l1_fwb_ (u"࣯ࠬ࠭")
            l1llll11_fwb_ = l1llll11_fwb_[0] if l1llll11_fwb_ else l1_fwb_ (u"ࣰ࠭ࠧ")
            l1ll1l1l_fwb_ = l1ll1l1l_fwb_[0] if l1ll1l1l_fwb_ else l1_fwb_ (u"ࠧࠨࣱ")
            code = l1ll1ll1_fwb_
            l1l1l11_fwb_ = l1_fwb_ (u"ࠣࡎࡨ࡯ࡹࡵࡲ࠻ࠢࠨࡷࠥࡢ࡮ࡅࡱࡧࡥࡳࡿ࠺ࠡࠧࡶࠤࡡࡴࡇࡢࡶࡸࡲࡪࡱ࠺ࠡࠧࡶࠤࡡࡴࣲࠢ") %(l1ll1ll1_fwb_,l1llll11_fwb_,l1ll1l1l_fwb_)
            if href and title:
                l1l1111_fwb_ = urljoin(l1_fwb_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡰࡺࡩ࡭ࡱࡳ࠮ࡱ࡮ࠪࣳ"),l1l1111_fwb_.group(1)) if l1l1111_fwb_ else l1_fwb_ (u"ࠪࠫࣴ")
                title = title.group(1)
                year =  re.findall(l1_fwb_ (u"ࠫࡡ࠮ࠨ࡝ࡦࡾ࠸ࢂ࠯࡜ࠪࠩࣵ"),title)
                l1lll1l_fwb_ = {l1_fwb_ (u"ࠬ࡮ࡲࡦࡨࣶࠪ")   : href.group(1),
                       l1_fwb_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࣷ")  : l11ll11_fwb_(title),
                       l1_fwb_ (u"ࠧࡪ࡯ࡪࠫࣸ")    : l1l1111_fwb_,
                       l1_fwb_ (u"ࠨࡲ࡯ࡳࡹࣹ࠭")   : l11ll11_fwb_(l1l1l11_fwb_),
                       l1_fwb_ (u"ࠩࡼࡩࡦࡸࣺࠧ")   : year[0] if year else l1_fwb_ (u"ࠪࠫࣻ"),
                       l1_fwb_ (u"ࠫࡨࡵࡤࡦࠩࣼ")   : code,
                        }
                out.append(l1lll1l_fwb_)
        l111111_fwb_=False
        l1ll1ll_fwb_ = re.findall(l1_fwb_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࡝ࡡࠦࡢ࠰ࠩࠣࡀ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢ࡯ࡧࡻࡸࡤࡹࡩࡵࡧࠥࡂࡕࡵࡰࡳࡼࡨࡨࡳ࡯ࡡ࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡣࡁࠫࣽ"),content)
        l1ll1ll_fwb_ = l1ll1ll_fwb_[0] if l1ll1ll_fwb_ else False
        l111111_fwb_ = re.findall(l1_fwb_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࡞ࡢࠧࡣࠪࠪࠤࡁࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡰࡨࡼࡹࡥࡳࡪࡶࡨࠦࡃࡔࡡࡴࡶ࠱࠯ࡵࡴࡡ࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡣࡁࠫࣾ"),content)
        l111111_fwb_ = l111111_fwb_[0] if l111111_fwb_ else False
        return (out, (l1ll1ll_fwb_,l111111_fwb_))
    @staticmethod
    def l111lll_fwb_():
        content = l11l111_fwb_(l1_fwb_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡧࡵࡸࡧ࡫࡯ࡱ࠳ࡶ࡬࠰࡭ࡲࡲࡹࡧ࡫ࡵࠩࣿ"))
        l11l1ll_fwb_=re.findall(l1_fwb_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠴ࡱࡡࡵࡣ࡯ࡳ࡬࠵࠮ࠫࠫࠥࠤࡨࡲࡡࡴࡵࡀࠦࡳࡧࡶࡠ࡮࡬ࡲࡰࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪऀ"),content)
        out=[]
        for href,name in l11l1ll_fwb_:
            out.append({l1_fwb_ (u"ࠩ࡫ࡶࡪ࡬ࠧँ"):href,l1_fwb_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩं"):name})
        return out
    @staticmethod
    def l11lll1_fwb_(url):
        url = urljoin(l1_fwb_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡲࡼ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭ः"),url)
        content = l11l111_fwb_(url)
        l11l1l1_fwb_=l1_fwb_ (u"ࠬ࠭ऄ")
        l1l1lll_fwb_=re.findall(l1_fwb_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡩࡧࡴࡤࡱࡪࡄࠧअ"),content,re.DOTALL|re.IGNORECASE)
        if l1l1lll_fwb_:
            l11l1l1_fwb_ = re.findall(l1_fwb_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬआ"),l1l1lll_fwb_[0],re.DOTALL|re.IGNORECASE)
            l11l1l1_fwb_ = l11l1l1_fwb_[0] if l11l1l1_fwb_ else l1_fwb_ (u"ࠨࠩइ")
        return l11l1l1_fwb_
