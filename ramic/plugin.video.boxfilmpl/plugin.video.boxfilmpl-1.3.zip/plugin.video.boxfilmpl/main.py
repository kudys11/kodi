# -*- coding: utf-8 -*-
import sys
l1l1l_fwb_ = sys.version_info [0] == 2
l1l1ll_fwb_ = 2048
l1l11_fwb_ = 7
def l1_fwb_ (keyedStringLiteral):
	global l11l11_fwb_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l1l_fwb_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l1ll_fwb_ - (charIndex + stringNr) % l1l11_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l1ll_fwb_ - (charIndex + stringNr) % l1l11_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urlparse,sys,urllib
params = dict(urlparse.parse_qsl(sys.argv[2].replace(l1_fwb_ (u"ࠫࡄ࠭ࠀ"),l1_fwb_ (u"ࠬ࠭ࠁ"))))
mode = params.get(l1_fwb_ (u"࠭࡭ࡰࡦࡨࠫࠂ"))
fname = params.get(l1_fwb_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫࠃ"))
ex_link = params.get(l1_fwb_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩࠄ"))
l111l1_fwb_ = params.get(l1_fwb_ (u"ࠩࡳࡥ࡬࡫ࠧࠅ"))
import xbmcgui,xbmc
import time,os
l1lll1_fwb_ = xbmcgui.Dialog()
import time,threading
try: from shutil import rmtree
except: rmtree = False
def ll_fwb_(l1111l_fwb_,l1ll_fwb_=[l1_fwb_ (u"ࠪࠫࠆ")]):
    debug=1
def l1111_fwb_(name=l1_fwb_ (u"ࠫࠬࠇ")):
    debug=1
def l11l_fwb_(top):
    debug=1
def l11ll1_fwb_():
    l1111l_fwb_ = os.path.join(xbmc.translatePath(l1_fwb_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭ࠏ")),l1_fwb_ (u"࠭ࡡࡥࡦࡲࡲࡸ࠭ࠐ"))
    xbmc.log(l1111l_fwb_)
    if ll_fwb_(l1111l_fwb_,[l1_fwb_ (u"ࠧࡢ࡮࡬ࡩࡳࡽࡩࡻࡣࡵࡨࠬࠑ"),l1_fwb_ (u"ࠨࡧࡻࡸࡪࡴࡤࡦࡴ࠱ࡥࡱ࡯ࡥ࡯ࠩࠒ")])>0:
        l1111_fwb_(l1_fwb_ (u"ࠩࡺ࡭ࡿࡧࡲࡥࠩࠓ"))
        return
    l1l111_fwb_ = os.path.join(xbmc.translatePath(l1_fwb_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡵࡴࡧࡵࡨࡦࡺࡡࠨࠔ")),l1_fwb_ (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨࠕ"),l1_fwb_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡥࡪࡵ࡮࠯ࡰࡲࡼ࠳࠻ࠧࠖ"),l1_fwb_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬࠗ"))
    if os.path.exists(l1l111_fwb_):
        data = open(l1l111_fwb_,l1_fwb_ (u"ࠧࡳࠩ࠘")).read()
        data= re.sub(l1_fwb_ (u"ࠨ࡞࡞࠲࠯ࡢ࡝ࠨ࠙"),l1_fwb_ (u"ࠩࠪࠚ"),data)
        if len(re.compile(l1_fwb_ (u"ࠪࡂ࠳࠰ࠨࡱࡱ࡯ࡷࡰࡧ࡜ࡴࠬࡷࡠࡸ࠰ࡶࠪࠩࠛ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1111_fwb_(l1_fwb_ (u"ࠫࡸࡱࡩ࡯࠰ࡤࡩࡴࡴ࠮࡯ࡱࡻ࠲࠺࠭ࠜ"))
            return
        if len(re.compile(l1_fwb_ (u"ࠬࡄ࠮ࠫࠪࡧࡥࡷࡳ࡯ࡸࡣ࡟ࡷ࠯ࡺ࡜ࡴࠬࡹ࠭ࠬࠝ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1111_fwb_(l1_fwb_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡦ࡫࡯࡯࠰ࡱࡳࡽ࠴࠵ࠨࠞ"))
            return
    l1l111_fwb_ = os.path.join(xbmc.translatePath(l1_fwb_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡹࡸ࡫ࡲࡥࡣࡷࡥࠬࠟ")),l1_fwb_ (u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬࠠ"),l1_fwb_ (u"ࠩࡶ࡯࡮ࡴ࠮ࡹࡱࡱࡪࡱࡻࡥ࡯ࡥࡨࠫࠡ"),l1_fwb_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩࠢ"))
    if os.path.exists(l1l111_fwb_):
        data = open(l1l111_fwb_,l1_fwb_ (u"ࠫࡷ࠭ࠣ")).read()
        data= re.sub(l1_fwb_ (u"ࠬࡢ࡛࠯ࠬ࡟ࡡࠬࠤ"),l1_fwb_ (u"࠭ࠧࠥ"),data)
        if len(re.compile(l1_fwb_ (u"ࠧ࠿࠰࠭ࠬࡵࡵ࡬ࡴ࡭ࡤࡠࡸ࠰ࡴ࡝ࡵ࠭ࡺ࠮࠭ࠦ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1111_fwb_(l1_fwb_ (u"ࠨࡵ࡮࡭ࡳ࠴ࡸࡰࡰࡩࡰࡺ࡫࡮ࡤࡧࠪࠧ"))
            return
    l1111l_fwb_ = os.path.join(xbmc.translatePath(l1_fwb_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡻࡳࡦࡴࡧࡥࡹࡧࠧࠨ")),l1_fwb_ (u"ࠪࡴࡷࡵࡦࡪ࡮ࡨࡷࠬࠩ"))
    if os.path.exists(l1111l_fwb_):
        if ll_fwb_(l1111l_fwb_,[l1_fwb_ (u"ࠫࡰ࡯ࡤࡴࠩࠪ")])>0:
            l1111_fwb_(l1_fwb_ (u"ࠬࡽࡩࡻࡣࡵࡨࠬࠫ"))
            return
    l1l_fwb_ = xbmc.translatePath(l1_fwb_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧࠬ"))
    for f in os.listdir(l1l_fwb_):
        if f.startswith(l1_fwb_ (u"ࠧࡎࡏࡈࡗࠬ࠭")):
            l1111_fwb_()
            return
def l1l1_fwb_():
    try:
        debug=1
    except: pass
import resources.lib.l1ll11_fwb_
if mode is None:
    from resources.lib import l11_fwb_
    l11_fwb_.l11_fwb_().root()
elif mode.startswith(l1_fwb_ (u"ࠩࡢ࡭ࡳ࡬࡯ࡠࠩ࠯"))  :
    from resources.lib import l11_fwb_
    l11_fwb_.l11_fwb_().info()
elif mode == l1_fwb_ (u"ࠪ࡯ࡦࡺࡥࡨࡱࡵ࡭ࡪ࠭࠰"):
    from resources.lib import l11_fwb_
    l11_fwb_.l11_fwb_().l111ll_fwb_()
elif mode == l1_fwb_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬ࠱"):
    from resources.lib import l11_fwb_
    l11_fwb_.l11_fwb_().content(ex_link)
elif mode.startswith(l1_fwb_ (u"ࠬࡥ࡟ࡱࡣࡪࡩࡤࡥ࠺ࠨ࠲")):
    from resources.lib import l11_fwb_
    l11_fwb_.l11_fwb_().l11ll_fwb_(mode,ex_link)
elif mode.startswith(l1_fwb_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭࠳")):
    from resources.lib import l11_fwb_
    l11_fwb_.l11_fwb_().l1llll_fwb_(mode,ex_link)
elif mode == l1_fwb_ (u"ࠧࡱ࡮ࡤࡽࡧࡵࡸࡧ࡫࡯ࡱࠬ࠴"):
    from resources.lib import l11_fwb_
    l11_fwb_.l11_fwb_().l11lll_fwb_(ex_link)
elif mode == l1_fwb_ (u"ࠨࡵࡨࡶ࡮ࡧ࡬ࡦࠩ࠵"):
    from resources.lib import l11_fwb_
    l11_fwb_.l11_fwb_().l11l1_fwb_(ex_link)
elif mode == l1_fwb_ (u"ࠩࡶࡩࡷ࡯ࡡ࡭ࡧࡢࡷࡪࡧࡳࡰࡰࡶࠫ࠶"):
    from resources.lib import l11_fwb_
    l11_fwb_.l11_fwb_().l1ll1l_fwb_(ex_link)
elif mode == l1_fwb_ (u"ࠪࡷࡪࡸࡩࡢ࡮ࡨࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭࠷"):
    from resources.lib import l11_fwb_
    l11_fwb_.l11_fwb_().l11l1l_fwb_(ex_link)
elif mode == l1_fwb_ (u"ࠫࡵࡲࡡࡺࡕࡨࡶ࡮ࡧ࡬ࡦࠩ࠸"):
    from resources.lib import l11_fwb_
    l11_fwb_.l11_fwb_().l1ll1_fwb_(ex_link)
