# coding: UTF-8
import sys
l1111ll11l1l11_nktv_ = sys.version_info [0] == 2
l111ll11l1l11_nktv_ = 2048
l1l1lll11l1l11_nktv_ = 7
def l1l11ll11l1l11_nktv_ (keyedStringLiteral):
	global l11llll11l1l11_nktv_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1111ll11l1l11_nktv_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import re,os
import urllib2
import urllib
import urlparse
import time
import cookielib
l1ll11ll1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠰࠯࠲࠱࠶࠻࠼࠱࠯࠳࠳࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬక")
l11ll1l11ll11l1l11_nktv_=l1ll11ll1ll11l1l11_nktv_
l111lll1lll11l1l11_nktv_ = 3
class l11ll111lll11l1l11_nktv_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
    https_response = http_response
def l11l1l111ll11l1l11_nktv_(l111ll1l1ll11l1l11_nktv_):
    try:
        offset = 1 if l111ll1l1ll11l1l11_nktv_[0] == l1l11ll11l1l11_nktv_ (u"ࠧࠬࠩఖ") else 0
        return int(eval(l111ll1l1ll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠨࠣ࠮࡟ࡢ࠭గ"), l1l11ll11l1l11_nktv_ (u"ࠩ࠴ࠫఘ")).replace(l1l11ll11l1l11_nktv_ (u"ࠪࠥࠦࡡ࡝ࠨఙ"), l1l11ll11l1l11_nktv_ (u"ࠫ࠶࠭చ")).replace(l1l11ll11l1l11_nktv_ (u"ࠬࡡ࡝ࠨఛ"), l1l11ll11l1l11_nktv_ (u"࠭࠰ࠨజ")).replace(l1l11ll11l1l11_nktv_ (u"ࠧࠩࠩఝ"), l1l11ll11l1l11_nktv_ (u"ࠨࡵࡷࡶ࠭࠭ఞ"))[offset:]))
    except:
        pass
url=l1l11ll11l1l11_nktv_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧࡩࡧࡸ࠯ࡶࡹ࠳ࠬట")
wait=True
l111l1lllll11l1l11_nktv_=l1ll11ll1ll11l1l11_nktv_
l111l1l1ll11l1l11_nktv_ = cookielib.LWPCookieJar()
def l1lllll11ll11l1l11_nktv_(url,l111l1l1ll11l1l11_nktv_=l111l1l1ll11l1l11_nktv_,l11ll1l11ll11l1l11_nktv_=l1ll11ll1ll11l1l11_nktv_):
    return l111ll111ll11l1l11_nktv_(url,l111l1l1ll11l1l11_nktv_,l111l1lllll11l1l11_nktv_=l11ll1l11ll11l1l11_nktv_, wait=True)
def l111ll111ll11l1l11_nktv_(url, l111l1l1ll11l1l11_nktv_, l111l1lllll11l1l11_nktv_=None, wait=True):
    if l111l1lllll11l1l11_nktv_ is None: l111l1lllll11l1l11_nktv_ = l1ll11ll1ll11l1l11_nktv_
    headers = {l1l11ll11l1l11_nktv_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧఠ"): l111l1lllll11l1l11_nktv_, l1l11ll11l1l11_nktv_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬడ"): url}
    if l111l1l1ll11l1l11_nktv_ is not None:
        try: l111l1l1ll11l1l11_nktv_.load(ignore_discard=True)
        except: pass
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l111l1l1ll11l1l11_nktv_))
        urllib2.install_opener(opener)
    request = urllib2.Request(url)
    for key in headers: request.add_header(key, headers[key])
    try:
        response = urllib2.urlopen(request)
        html = response.read()
    except urllib2.HTTPError as e:
        html = e.read()
    l111llll1ll11l1l11_nktv_ = 0
    while l111llll1ll11l1l11_nktv_ < l111lll1lll11l1l11_nktv_:
        l111ll11lll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠬࡼࡡࡳࠢࠫࡃ࠿ࡹࠬࡵ࠮ࡲ࠰ࡵ࠲ࡢ࠭ࡴ࠯ࡩ࠱ࡧࠬ࡬࠮࡬࠰ࡳ࠲ࡧࡽࡶ࠯ࡶ࠱ࡧࠩ࠭ࡨ࠯ࡠࡸ࠰ࠨ࡜ࡠࡀࡡ࠰࠯࠽ࡼࠤࠫ࡟ࡣࠨ࡝ࠬࠫࠥ࠾࠭ࡡ࡞ࡾ࡟࠮࠭ࢂࡁ࠮ࠬࡥ࡫ࡥࡱࡲࡥ࡯ࡩࡨ࠱࡫ࡵࡲ࡮࡞ࠪࡠ࠮ࡁ࠮ࠫࡁ࡟ࡲ࠳࠰࠿࠼ࠪ࠱࠮ࡄ࠯࠻ࡢ࡞࠱ࡺࡦࡲࡵࡦࠩఢ")
        l11l111llll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"࠭ࡩ࡯ࡲࡸࡸࠥࡺࡹࡱࡧࡀࠦ࡭࡯ࡤࡥࡧࡱࠦࠥࡴࡡ࡮ࡧࡀࠦ࡯ࡹࡣࡩ࡮ࡢࡺࡨࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࡝ࡡࠦࡢ࠱ࠩࠨణ")
        l11l111l1ll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠧࡪࡰࡳࡹࡹࠦࡴࡺࡲࡨࡁࠧ࡮ࡩࡥࡦࡨࡲࠧࠦ࡮ࡢ࡯ࡨࡁࠧࡶࡡࡴࡵࠥࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭ࡡ࡞ࠣ࡟࠮࠭ࠬత")
        l11l1111lll11l1l11_nktv_ = re.search(l111ll11lll11l1l11_nktv_, html, re.DOTALL)
        l11l11l11ll11l1l11_nktv_ = re.search(l11l111llll11l1l11_nktv_, html)
        l11l1l11lll11l1l11_nktv_ = re.search(l11l111l1ll11l1l11_nktv_, html)
        if not l11l1111lll11l1l11_nktv_ or not l11l11l11ll11l1l11_nktv_ or not l11l1l11lll11l1l11_nktv_:
            return False
        l11l1l1l1ll11l1l11_nktv_, l111lll11ll11l1l11_nktv_, l11l11111ll11l1l11_nktv_, l11l11ll1ll11l1l11_nktv_ = l11l1111lll11l1l11_nktv_.groups()
        l11l1l1llll11l1l11_nktv_ = l11l11l11ll11l1l11_nktv_.group(1)
        password = l11l1l11lll11l1l11_nktv_.group(1)
        l111ll1llll11l1l11_nktv_ = (l11l1l1l1ll11l1l11_nktv_, l111lll11ll11l1l11_nktv_)
        result = int(l11l1l111ll11l1l11_nktv_(l11l11111ll11l1l11_nktv_.rstrip()))
        for l111ll1l1ll11l1l11_nktv_ in l11l11ll1ll11l1l11_nktv_.split(l1l11ll11l1l11_nktv_ (u"ࠨ࠽ࠪథ")):
            l111ll1l1ll11l1l11_nktv_ = l111ll1l1ll11l1l11_nktv_.rstrip()
            if l111ll1l1ll11l1l11_nktv_[:len(l1l11ll11l1l11_nktv_ (u"ࠩ࠱ࠫద").join(l111ll1llll11l1l11_nktv_))] != l1l11ll11l1l11_nktv_ (u"ࠪ࠲ࠬధ").join(l111ll1llll11l1l11_nktv_):
                    print l1l11ll11l1l11_nktv_ (u"ࠫࡊࡷࡵࡢࡶ࡬ࡳࡳࠦࡤࡰࡧࡶࠤࡳࡵࡴࠡࡵࡷࡥࡷࡺࠠࡸ࡫ࡷ࡬ࠥࡼࡡࡳࡰࡤࡱࡪࠦࡼࠦࡵࡿࠫన") % (l111ll1l1ll11l1l11_nktv_)
            else:
                    l111ll1l1ll11l1l11_nktv_ = l111ll1l1ll11l1l11_nktv_[len(l1l11ll11l1l11_nktv_ (u"ࠬ࠴ࠧ఩").join(l111ll1llll11l1l11_nktv_)):]
            l111l1ll1ll11l1l11_nktv_ = l111ll1l1ll11l1l11_nktv_[2:]
            l11l11lllll11l1l11_nktv_ = l111ll1l1ll11l1l11_nktv_[0]
            if l11l11lllll11l1l11_nktv_ not in [l1l11ll11l1l11_nktv_ (u"࠭ࠫࠨప"), l1l11ll11l1l11_nktv_ (u"ࠧ࠮ࠩఫ"), l1l11ll11l1l11_nktv_ (u"ࠨࠬࠪబ"), l1l11ll11l1l11_nktv_ (u"ࠩ࠲ࠫభ")]:
                print l1l11ll11l1l11_nktv_ (u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡴࡶࡥࡳࡣࡷࡳࡷࡀࠠࡽࠧࡶࢀࠬమ") % (l111ll1l1ll11l1l11_nktv_)
                continue
            result = int(str(eval(str(result) + l11l11lllll11l1l11_nktv_ + str(l11l1l111ll11l1l11_nktv_(l111l1ll1ll11l1l11_nktv_)))))
        scheme = urlparse.urlparse(url).scheme
        l11l1ll11ll11l1l11_nktv_ = urlparse.urlparse(url).hostname
        result += len(l11l1ll11ll11l1l11_nktv_)
        if wait: time.sleep(5)
        url = l1l11ll11l1l11_nktv_ (u"ࠫࠪࡹ࠺࠰࠱ࠨࡷ࠴ࡩࡤ࡯࠯ࡦ࡫࡮࠵࡬࠰ࡥ࡫࡯ࡤࡰࡳࡤࡪ࡯ࡃ࡯ࡹࡣࡩ࡮ࡢࡺࡨࡃࠥࡴࠨ࡭ࡷࡨ࡮࡬ࡠࡣࡱࡷࡼ࡫ࡲ࠾ࠧࡶࠪࡵࡧࡳࡴ࠿ࠨࡷࠬయ") % (scheme, l11l1ll11ll11l1l11_nktv_, l11l1l1llll11l1l11_nktv_, result, urllib.quote(password))
        request = urllib2.Request(url)
        for key in headers: request.add_header(key, headers[key])
        try:
            opener = urllib2.build_opener(l11ll111lll11l1l11_nktv_)
            urllib2.install_opener(opener)
            response = urllib2.urlopen(request)
            while response.getcode() in [301, 302, 303, 307]:
                if l111l1l1ll11l1l11_nktv_ is not None:
                    l111l1l1ll11l1l11_nktv_.l11l11l1lll11l1l11_nktv_(response, request)
                request = urllib2.Request(response.info().getheader(l1l11ll11l1l11_nktv_ (u"ࠬࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠧర")))
                for key in headers: request.add_header(key, headers[key])
                if l111l1l1ll11l1l11_nktv_ is not None:
                    l111l1l1ll11l1l11_nktv_.l111lllllll11l1l11_nktv_(request)
                response = urllib2.urlopen(request)
            final = response.read()
            if l1l11ll11l1l11_nktv_ (u"࠭ࡣࡧ࠯ࡥࡶࡴࡽࡳࡦࡴ࠰ࡺࡪࡸࡩࡧ࡫ࡦࡥࡹ࡯࡯࡯ࠩఱ") in final:
                l111llll1ll11l1l11_nktv_ += 1
                html = final
            else:
                break
        except urllib2.HTTPError as e:
            print l1l11ll11l1l11_nktv_ (u"ࠧࡄ࡮ࡲࡹࡩࡌ࡬ࡢࡴࡨࠤࡊࡸࡲࡰࡴ࠽ࠤࠪࡹࠠࡰࡰࠣࡹࡷࡲ࠺ࠡࠧࡶࠫల") % (e.code, url)
            return False
    return l111l1l1ll11l1l11_nktv_
def l1ll1l1llll11l1l11_nktv_(l11ll1ll11l1l11_nktv_):
    l11ll11l1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠨࠩళ")
    if os.path.isfile(l11ll1ll11l1l11_nktv_):
        l111l1l1ll11l1l11_nktv_ = cookielib.LWPCookieJar()
        l111l1l1ll11l1l11_nktv_.load(l11ll1ll11l1l11_nktv_)
        for c in l111l1l1ll11l1l11_nktv_:
            l11ll11l1ll11l1l11_nktv_+=l1l11ll11l1l11_nktv_ (u"ࠩࠨࡷࡂࠫࡳ࠼ࠩఴ")%(c.name, c.value)
    return l11ll11l1ll11l1l11_nktv_
