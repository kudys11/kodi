# -*- coding: utf-8 -*-
import sys
l1111ll11l1l11_nktv_ = sys.version_info [0] == 2
l111ll11l1l11_nktv_ = 2048
l1l1lll11l1l11_nktv_ = 7
def l1l11ll11l1l11_nktv_ (keyedStringLiteral):
	global l11llll11l1l11_nktv_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1111ll11l1l11_nktv_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import re
import time
import json
import urllib2
_1lll1ll1lll11l1l11_nktv_ = { l1l11ll11l1l11_nktv_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭๏"): l1l11ll11l1l11_nktv_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠶࠯࠴࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠵࠳࠲࠵࠴࠱࠶࠻࠼࠲࠻࠿ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧ๐")}
_1llll1111ll11l1l11_nktv_ = 10
def l1lll11l1ll11l1l11_nktv_(url,data={},headers={}):
    req = urllib2.Request(url,json.dumps(data),headers=headers)
    try:
        response = urllib2.urlopen(req, timeout=10)
        l1ll11l1ll11l1l11_nktv_ = response.read()
        response.close()
    except:
        l1ll11l1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠫࠬ๑")
    return l1ll11l1ll11l1l11_nktv_
def l111111ll11l1l11_nktv_(url):
    if l1l11ll11l1l11_nktv_ (u"ࠬࡹࡨ࠯ࡵࡷ࠳ࠬ๒") in url:
        url = _1llll11llll11l1l11_nktv_(url)
    elif l1l11ll11l1l11_nktv_ (u"࠭ࡳࡢࡨࡨࡰ࡮ࡴ࡫ࡪࡰࡪ࠲ࡳ࡫ࡴࠨ๓") in url:
        url = _1llll11l1ll11l1l11_nktv_(url)
    elif l1l11ll11l1l11_nktv_ (u"ࠧࡷ࡫࡬ࡨ࠳ࡳࡥࠨ๔") in url:
        url = _1lll1lll1ll11l1l11_nktv_(url)
    return url
def _1lll1lll1ll11l1l11_nktv_(uri):
    l1llll1l1lll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠨࠩ๕")
    html = l1lll11l1ll11l1l11_nktv_(uri, headers=_1lll1ll1lll11l1l11_nktv_)
    l1llll111lll11l1l11_nktv_ = re.findall(l1l11ll11l1l11_nktv_ (u"ࡴࠪࡷࡪࡹࡳࡪࡱࡱࡍࡩࡢ࠺ࠩ࠰࠭ࡃ࠮ࡢࠢ࡝࠮ࠪ๖"), html)
    if len(l1llll111lll11l1l11_nktv_) > 0:
        l1llll111lll11l1l11_nktv_ = re.sub(l1l11ll11l1l11_nktv_ (u"ࡵࠫࡡࡹ࡜ࠣࠩ๗"), l1l11ll11l1l11_nktv_ (u"ࠫࠬ๘"), l1llll111lll11l1l11_nktv_[0])
        l1llll1ll1ll11l1l11_nktv_ = {
            l1l11ll11l1l11_nktv_ (u"࡛ࠧࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠤ๙"): l1l11ll11l1l11_nktv_ (u"ࠨࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡞࠱࠲࠽ࠣࡐ࡮ࡴࡵࡹࠢࡻ࠼࠻ࡥ࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠹࠳࠷࠱ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠲࠹࠱࠴࠳࠿࠶࠴࠰࠷࠺࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠶࠰࠴࠵ࠧ๚"),
            l1l11ll11l1l11_nktv_ (u"ࠢࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠤ๛"): l1l11ll11l1l11_nktv_ (u"ࠣࡩࡽ࡭ࡵ࠲ࡤࡦࡨ࡯ࡥࡹ࡫ࠬࡴࡦࡦ࡬ࠧ๜"),
            l1l11ll11l1l11_nktv_ (u"ࠤࡄࡧࡨ࡫ࡰࡵ࠯ࡏࡥࡳ࡭ࡵࡢࡩࡨࠦ๝"): l1l11ll11l1l11_nktv_ (u"ࠥࡩࡳ࠳ࡕࡔ࠮ࡨࡲࡀ࠲ࡱ࠾࠲࠱࠼ࠧ๞"),
            l1l11ll11l1l11_nktv_ (u"ࠦࡈࡵ࡮࡯ࡧࡦࡸ࡮ࡵ࡮ࠣ๟"): l1l11ll11l1l11_nktv_ (u"ࠧࡱࡥࡦࡲ࠰ࡥࡱ࡯ࡶࡦࠤ๠"),
            l1l11ll11l1l11_nktv_ (u"ࠨࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠧ๡"): l1l11ll11l1l11_nktv_ (u"ࠢࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࠨ๢"),
            l1l11ll11l1l11_nktv_ (u"ࠣࡊࡲࡷࡹࠨ๣"): l1l11ll11l1l11_nktv_ (u"ࠤࡶ࡬࠳ࡹࡴࠣ๤"),
            l1l11ll11l1l11_nktv_ (u"ࠥࡖࡪ࡬ࡥࡳࡧࡵࠦ๥"): uri,
            l1l11ll11l1l11_nktv_ (u"ࠦࡔࡸࡩࡨ࡫ࡱࠦ๦"): l1l11ll11l1l11_nktv_ (u"ࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡼࡩࡪࡦ࠱ࡱࡪࠨ๧"),
            l1l11ll11l1l11_nktv_ (u"ࠨࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠤ๨"): l1l11ll11l1l11_nktv_ (u"࡙ࠢࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠣ๩")
        }
        time.sleep(5)
        l1llll1lllll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡸ࡬࡭ࡩ࠴࡭ࡦ࠱ࡶ࡬ࡴࡸࡴࡦࡵࡷ࠱ࡺࡸ࡬࠰ࡧࡱࡨ࠲ࡧࡤࡴࡧࡶࡷ࡮ࡵ࡮ࡀࡣࡧࡗࡪࡹࡳࡪࡱࡱࡍࡩࡃࠥࡴࠨࡤࡨࡧࡪ࠽࠲ࠨࡦࡥࡱࡲࡢࡢࡥ࡮ࡁࡨ࠭๪")%l1llll111lll11l1l11_nktv_
        response = l1lll11l1ll11l1l11_nktv_(l1llll1lllll11l1l11_nktv_, headers=l1llll1ll1ll11l1l11_nktv_)
        l1llll1l1lll11l1l11_nktv_=re.search(l1l11ll11l1l11_nktv_ (u"ࠩࠥࡨࡪࡹࡴࡪࡰࡤࡸ࡮ࡵ࡮ࡖࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭๫"),response)
        if l1llll1l1lll11l1l11_nktv_:
            l1llll1l1lll11l1l11_nktv_=l1llll1l1lll11l1l11_nktv_.group(1).replace(l1l11ll11l1l11_nktv_ (u"ࠪࡠࡡ࠭๬"),l1l11ll11l1l11_nktv_ (u"ࠫࠬ๭"))
    return l1llll1l1lll11l1l11_nktv_
def _1llll11l1ll11l1l11_nktv_(url):
    hash = url.split(l1l11ll11l1l11_nktv_ (u"ࠬ࠵ࠧ๮"))[-1]
    l1lll1llllll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"࠭ࡨࡢࡵ࡫ࠫ๯"): hash}
    headers = { l1l11ll11l1l11_nktv_ (u"ࠢࡂࡥࡦࡩࡵࡺࠢ๰"): l1l11ll11l1l11_nktv_ (u"ࠣࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱ࠰ࠥࡺࡥࡹࡶ࠲ࡴࡱࡧࡩ࡯࠮ࠣ࠮࠴࠰ࠢ๱"),
                l1l11ll11l1l11_nktv_ (u"ࠤࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠣ๲"): l1l11ll11l1l11_nktv_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰࡬ࡶࡳࡳ࠭๳")}
    response = l1lll11l1ll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡧࡦࡦ࡮࡬ࡲࡰ࡯࡮ࡨ࠰ࡱࡩࡹ࠵ࡶ࠲࠱ࡳࡶࡴࡺࡥࡤࡶࡨࡨࠬ๴"),data=l1lll1llllll11l1l11_nktv_,headers=headers)
    l1llll1l11ll11l1l11_nktv_ = json.loads( response)
    if l1llll1l11ll11l1l11_nktv_:
        l1l1l1l1ll11l1l11_nktv_=l1llll1l11ll11l1l11_nktv_.get(l1l11ll11l1l11_nktv_ (u"ࠬࡲࡩ࡯࡭ࡶࠫ๵"),[])
        if len(l1l1l1l1ll11l1l11_nktv_):
            url=l1l1l1l1ll11l1l11_nktv_[0].get(l1l11ll11l1l11_nktv_ (u"࠭ࡵࡳ࡮ࠪ๶"),l1l11ll11l1l11_nktv_ (u"ࠧࠨ๷"))
    return url
def _1llll11llll11l1l11_nktv_(uri):
    l1llll1l1lll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠨࠩ๸")
    html = l1lll11l1ll11l1l11_nktv_(uri, headers=_1lll1ll1lll11l1l11_nktv_)
    l1llll111lll11l1l11_nktv_ = re.findall(l1l11ll11l1l11_nktv_ (u"ࡴࠪࡷࡪࡹࡳࡪࡱࡱࡍࡩࡢ࠺ࠩ࠰࠭ࡃ࠮ࡢࠢ࡝࠮ࠪ๹"), html)
    if len(l1llll111lll11l1l11_nktv_) > 0:
        l1llll111lll11l1l11_nktv_ = re.sub(l1l11ll11l1l11_nktv_ (u"ࡵࠫࡡࡹ࡜ࠣࠩ๺"), l1l11ll11l1l11_nktv_ (u"ࠫࠬ๻"), l1llll111lll11l1l11_nktv_[0])
        l1llll1ll1ll11l1l11_nktv_ = {
            l1l11ll11l1l11_nktv_ (u"࡛ࠧࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠤ๼"): l1l11ll11l1l11_nktv_ (u"ࠨࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡞࠱࠲࠽ࠣࡐ࡮ࡴࡵࡹࠢࡻ࠼࠻ࡥ࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠹࠳࠷࠱ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠲࠹࠱࠴࠳࠿࠶࠴࠰࠷࠺࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠶࠰࠴࠵ࠧ๽"),
            l1l11ll11l1l11_nktv_ (u"ࠢࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠤ๾"): l1l11ll11l1l11_nktv_ (u"ࠣࡩࡽ࡭ࡵ࠲ࡤࡦࡨ࡯ࡥࡹ࡫ࠬࡴࡦࡦ࡬ࠧ๿"),
            l1l11ll11l1l11_nktv_ (u"ࠤࡄࡧࡨ࡫ࡰࡵ࠯ࡏࡥࡳ࡭ࡵࡢࡩࡨࠦ຀"): l1l11ll11l1l11_nktv_ (u"ࠥࡩࡳ࠳ࡕࡔ࠮ࡨࡲࡀ࠲ࡱ࠾࠲࠱࠼ࠧກ"),
            l1l11ll11l1l11_nktv_ (u"ࠦࡈࡵ࡮࡯ࡧࡦࡸ࡮ࡵ࡮ࠣຂ"): l1l11ll11l1l11_nktv_ (u"ࠧࡱࡥࡦࡲ࠰ࡥࡱ࡯ࡶࡦࠤ຃"),
            l1l11ll11l1l11_nktv_ (u"ࠨࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠧຄ"): l1l11ll11l1l11_nktv_ (u"ࠢࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࠨ຅"),
            l1l11ll11l1l11_nktv_ (u"ࠣࡊࡲࡷࡹࠨຆ"): l1l11ll11l1l11_nktv_ (u"ࠤࡶ࡬࠳ࡹࡴࠣງ"),
            l1l11ll11l1l11_nktv_ (u"ࠥࡖࡪ࡬ࡥࡳࡧࡵࠦຈ"): uri,
            l1l11ll11l1l11_nktv_ (u"ࠦࡔࡸࡩࡨ࡫ࡱࠦຉ"): l1l11ll11l1l11_nktv_ (u"ࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡨ࠯ࡵࡷࠦຊ"),
            l1l11ll11l1l11_nktv_ (u"ࠨࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠤ຋"): l1l11ll11l1l11_nktv_ (u"࡙ࠢࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠣຌ")
        }
        time.sleep(5)
        l1llll1lllll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵ࡫࠲ࡸࡺ࠯ࡴࡪࡲࡶࡹ࡫ࡳࡵ࠯ࡸࡶࡱ࠵ࡥ࡯ࡦ࠰ࡥࡩࡹࡥࡴࡵ࡬ࡳࡳࡅࡡࡥࡕࡨࡷࡸ࡯࡯࡯ࡋࡧࡁࠪࡹࠦࡢࡦࡥࡨࡂ࠷ࠦࡤࡣ࡯ࡰࡧࡧࡣ࡬࠿ࡦࠫຍ")%l1llll111lll11l1l11_nktv_
        response = l1lll11l1ll11l1l11_nktv_(l1llll1lllll11l1l11_nktv_, headers=l1llll1ll1ll11l1l11_nktv_)
        l1llll1l1lll11l1l11_nktv_=re.search(l1l11ll11l1l11_nktv_ (u"ࠩࠥࡨࡪࡹࡴࡪࡰࡤࡸ࡮ࡵ࡮ࡖࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ຎ"),response)
        if l1llll1l1lll11l1l11_nktv_:
            l1llll1l1lll11l1l11_nktv_=l1llll1l1lll11l1l11_nktv_.group(1).replace(l1l11ll11l1l11_nktv_ (u"ࠪࡠࡡ࠭ຏ"),l1l11ll11l1l11_nktv_ (u"ࠫࠬຐ"))
    return l1llll1l1lll11l1l11_nktv_
