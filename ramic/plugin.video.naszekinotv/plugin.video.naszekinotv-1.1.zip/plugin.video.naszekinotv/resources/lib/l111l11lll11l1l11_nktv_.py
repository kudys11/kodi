# -*- coding: utf-8 -*-
import sys
l1111ll11l1l11_nktv_ = sys.version_info [0] == 2
l111ll11l1l11_nktv_ = 2048
l1l1lll11l1l11_nktv_ = 7
def l1l11ll11l1l11_nktv_ (keyedStringLiteral):
	global l11llll11l1l11_nktv_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1111ll11l1l11_nktv_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os
import l1lll1l1lll11l1l11_nktv_,cookielib
from urlparse import urlparse
l1ll1l11lll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡥࡧࡥ࠲࡮ࡤ࠯ࡲ࡯࠳ࠬঽ")
l1111lllll11l1l11_nktv_ = 10
l1ll11ll1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠶࠻࠲࠵࠴࠲࠶࠸࠷࠲࠾࠽ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧা")
l11ll1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࡵࠫࡨࡵ࡯࡬࡫ࡨ࠲ࡨࡪࡡࠨি")
l1ll1l1l1ll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡵࡥࡲࡱࡡ࠯ࡲࡵࡳࡽࡿ࠮࡯ࡧࡷ࠲ࡵࡲ࠯ࡪࡰࡧࡩࡽ࠴ࡰࡩࡲࡂࡵࡂ࠭ী")
def _1ll1ll1lll11l1l11_nktv_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l1l11ll11l1l11_nktv_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩু"), l1ll11ll1ll11l1l11_nktv_)
    if cookies:
        req.add_header(l1l11ll11l1l11_nktv_ (u"ࠨࡃࡰࡱ࡮࡭ࡪࠨূ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l1111lllll11l1l11_nktv_)
        l1ll11l1ll11l1l11_nktv_ = response.read()
        response.close()
    except:
        l1ll11l1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠧࠨৃ")
    return l1ll11l1ll11l1l11_nktv_
def l1lll11l1ll11l1l11_nktv_(url,data=None):
    cookies=l1lll1l1lll11l1l11_nktv_.l1ll1l1llll11l1l11_nktv_(l11ll1ll11l1l11_nktv_)
    content=_1ll1ll1lll11l1l11_nktv_(url,data,cookies)
    if not content:
        l111l1l1ll11l1l11_nktv_=l1ll1lll1ll11l1l11_nktv_(l1ll1l11lll11l1l11_nktv_,l11ll1ll11l1l11_nktv_)
        cookies=l1lll1l1lll11l1l11_nktv_.l1ll1l1llll11l1l11_nktv_(l11ll1ll11l1l11_nktv_)
        content=_1ll1ll1lll11l1l11_nktv_(url,data,cookies)
        if not content:
            content=_1ll1ll1lll11l1l11_nktv_(l1ll1l1l1ll11l1l11_nktv_+url,data,cookies)
    return content
def l1ll1lll1ll11l1l11_nktv_(l1ll11l1ll11l1l11_nktv_,l1lll11llll11l1l11_nktv_):
    l111l1l1ll11l1l11_nktv_ = cookielib.LWPCookieJar()
    l1lll111lll11l1l11_nktv_ = l1lll1l1lll11l1l11_nktv_.l1lllll11ll11l1l11_nktv_(l1ll11l1ll11l1l11_nktv_,l111l1l1ll11l1l11_nktv_,l1ll11ll1ll11l1l11_nktv_)
    l11l11l1ll11l1l11_nktv_=os.path.dirname(l1lll11llll11l1l11_nktv_)
    if not os.path.exists(l11l11l1ll11l1l11_nktv_):
        os.makedirs(l11l11l1ll11l1l11_nktv_)
    if l111l1l1ll11l1l11_nktv_:
        l111l1l1ll11l1l11_nktv_.save(l1lll11llll11l1l11_nktv_, ignore_discard = True)
    return l111l1l1ll11l1l11_nktv_
def l1ll1ll1ll11l1l11_nktv_(url,l1l11llll11l1l11_nktv_=1):
    if l1l11ll11l1l11_nktv_ (u"ࠨࡁࡶࡁࠬৄ") in url:
        url = url.replace(l1l11ll11l1l11_nktv_ (u"ࠩࡂࡷࡂ࠭৅"),l1l11ll11l1l11_nktv_ (u"ࠪࡴࡦ࡭ࡥ࠰ࠧࡧ࠳ࡄࡹ࠽ࠨ৆") %l1l11llll11l1l11_nktv_)
    else:
        url += l1l11ll11l1l11_nktv_ (u"ࠫ࠴࠭ে") if url[-1] != l1l11ll11l1l11_nktv_ (u"ࠬ࠵ࠧৈ") else l1l11ll11l1l11_nktv_ (u"࠭ࠧ৉")
        url = url + l1l11ll11l1l11_nktv_ (u"ࠧࡱࡣࡪࡩ࠴ࠫࡤ࠰ࠩ৊") %l1l11llll11l1l11_nktv_
    content = l1lll11l1ll11l1l11_nktv_(url)
    l1l1llllll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࡡࠢ࡝ࠩࡠࡴࡦ࡭ࡩ࡯ࡣࡧࡳࡠࠨ࡜ࠨ࡟ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨো"),re.DOTALL).findall(content)
    l1l1llllll11l1l11_nktv_ = urllib.unquote(l1l1llllll11l1l11_nktv_[0]) if l1l1llllll11l1l11_nktv_ else content
    l1ll1ll11ll11l1l11_nktv_=False
    l1ll1l111ll11l1l11_nktv_=url.replace(l1l11ll11l1l11_nktv_ (u"ࠩࡳࡥ࡬࡫࠯ࠦࡦ࠲ࠫৌ")%l1l11llll11l1l11_nktv_,l1l11ll11l1l11_nktv_ (u"ࠪࡴࡦ࡭ࡥ࠰ࠧࡧ࠳্ࠬ") %(l1l11llll11l1l11_nktv_+1))
    if l1l1llllll11l1l11_nktv_.find(l1ll1l111ll11l1l11_nktv_.split(l1l11ll11l1l11_nktv_ (u"ࠫ࠴࠵ࠧৎ"))[-1])>-1:
        l1ll1ll11ll11l1l11_nktv_ = l1l11llll11l1l11_nktv_+1
    ids = [(a.start(), a.end()) for a in re.finditer(l1l11ll11l1l11_nktv_ (u"ࠬࡂࡤࡪࡸࠣ࡭ࡩࡃ࡜ࠣ࡯ࡷ࠲࠯ࡢࠢࠡࡥ࡯ࡥࡸࡹ࠽࡝ࠤ࡬ࡸࡪࡳ࡜ࠣࡀࠪ৏"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l111l1llll11l1l11_nktv_ = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile(l1l11ll11l1l11_nktv_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡧࡵࡸࡪࡰࡩࡳࠧࡄ࡛࡝ࡵ࡟ࡲࡢ࠱࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠩ৐"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        title = re.compile(l1l11ll11l1l11_nktv_ (u"ࠧ࠽ࡵࡳࡥࡳࠦࡣ࡭ࡣࡶࡷࡂࠨࡴࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ৑"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        l1llll11lll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠨ࠾ࡶࡴࡦࡴࠠࡤ࡮ࡤࡷࡸࡃࠢࡵࡶࡻࠦࡃࡢ࡮ࠩ࠰࠭ࡃ࠮࠮࠿࠻࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡤࡦࡩࡵࡥࡩࡧࡤࡰࠤࡁࡀ࠴ࡪࡩࡷࡀࠬࡿ࠵࠲࠱ࡾ࡝࡟ࡷࡡࡴ࡝ࠫ࠾࠲ࡷࡵࡧ࡮࠿࡝࡟ࡷࡡࡴ࡝ࠫࠩ৒"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        l1lll1lllll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡪ࡯ࡤ࡫ࡪࠨ࠾࡜࡞ࡶࡠࡳࡣࠫ࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ৓"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        l1111111ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࡀࡸࡶࡡ࡯ࠢࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡱࡩࡨࡳࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ৔"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        year =  re.compile(l1l11ll11l1l11_nktv_ (u"ࠫࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥࡽࡪࡧࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ৕"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        quality = re.compile(l1l11ll11l1l11_nktv_ (u"ࠬࡂࡳࡱࡣࡱࠤࡨࡲࡡࡴࡵࡀࠦࡨࡧ࡬ࡪࡦࡤࡨ࠷ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭৖"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        l1llll111ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"࠭࠼ࡣࡀ࠱࠯ࡄࡂ࠯ࡣࡀࠣࡀࡧࡄࠨ࠯ࠬࡂࠤ࡬ै࡯ࡴࣵࡺ࠭ࡁ࠵ࡢ࠿ࠩৗ")).search(l111l1llll11l1l11_nktv_)
        if href and title:
            l1lll1lllll11l1l11_nktv_ = l1lll1lllll11l1l11_nktv_.group(1) if l1lll1lllll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠧࠨ৘")
            if l1lll1lllll11l1l11_nktv_.startswith(l1l11ll11l1l11_nktv_ (u"ࠨ࠱࠲ࠫ৙")):
                l1lll1lllll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ৚")+l1lll1lllll11l1l11_nktv_
            l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠪ࡬ࡷ࡫ࡦࠨ৛")   : href.group(1),
                l1l11ll11l1l11_nktv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪড়")  : l1lll1ll1ll11l1l11_nktv_(title.group(1)),
                l1l11ll11l1l11_nktv_ (u"ࠬࡶ࡬ࡰࡶࠪঢ়")   : l1lll1ll1ll11l1l11_nktv_(l1llll11lll11l1l11_nktv_.group(1)) if l1llll11lll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"࠭ࠧ৞"),
                l1l11ll11l1l11_nktv_ (u"ࠧࡪ࡯ࡪࠫয়")    : l1lll1lllll11l1l11_nktv_,
                l1l11ll11l1l11_nktv_ (u"ࠨࡴࡤࡸ࡮ࡴࡧࠨৠ") : l1111111ll11l1l11_nktv_.group(1) if l1111111ll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠩࠪৡ"),
                l1l11ll11l1l11_nktv_ (u"ࠪࡽࡪࡧࡲࠨৢ")   : year.group(1) if year else l1l11ll11l1l11_nktv_ (u"ࠫࠬৣ"),
                l1l11ll11l1l11_nktv_ (u"ࠬࡼ࡯ࡵࡧࡶࠫ৤")  : l1llll111ll11l1l11_nktv_.group(1) if l1llll111ll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"࠭ࠧ৥"),
                l1l11ll11l1l11_nktv_ (u"ࠧࡤࡱࡧࡩࠬ০")  : quality.group(1) if quality else l1l11ll11l1l11_nktv_ (u"ࠨࠩ১"),
                    }
            out.append(l11111llll11l1l11_nktv_)
    l11111l1ll11l1l11_nktv_ = l1l11llll11l1l11_nktv_-1 if l1l11llll11l1l11_nktv_>1 else False
    return (out, (l11111l1ll11l1l11_nktv_,l1ll1ll11ll11l1l11_nktv_))
def l111l111ll11l1l11_nktv_(url):
    content = l1lll11l1ll11l1l11_nktv_(url)
    token = re.search(l1l11ll11l1l11_nktv_ (u"ࠩࡱࡥࡲ࡫࠽ࠣࡡࡷࡳࡰ࡫࡮ࠣࠢࡷࡽࡵ࡫࠽ࠣࡪ࡬ࡨࡩ࡫࡮ࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠪ২"),content).group(1)
    l1ll1llllll11l1l11_nktv_ = re.search(l1l11ll11l1l11_nktv_ (u"ࠪࡷ࡮ࡺࡥ࡬ࡧࡼ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠭৩"),content).group(1)
    params = {l1l11ll11l1l11_nktv_ (u"ࠫࡤࡺ࡯࡬ࡧࡱࠫ৪"):l1l11ll11l1l11_nktv_ (u"ࠬࡓࡧ࡛ࡏࡅ࠵࡜࡬࠴ࡖࡄࡊࡴ࡭࡟ࡆ࠲࡫࠹࠷ࡲࡕ࠴࠷࠹ࡺࡼࡌ࠾ࡓ࠶࡭࠸ࡧࡰࡶ࠴ࡎࡑ࡭ࠫ৫"),
            l1l11ll11l1l11_nktv_ (u"࠭ࡧ࠮ࡴࡨࡧࡦࡶࡴࡤࡪࡤ࠱ࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭৬"):l1l11ll11l1l11_nktv_ (u"ࠧ࠱࠵ࡄࡌࡏࡥࡖࡶࡸࡺࡻࡰࡑࡆ࠲ࡋ࠼ࡐࡓ࡮ࡕࡓࡔࡶࡔࡏࡹࡑࡐ࠷ࡢࡗࡱࡎࡱࡈࡳ࡙࠽ࡧࡵࡲࡃࡣࡘ࡛ࡶࡳ࡮ࡲࡐࡇࡪࡶࡎ࠱ࡱࡖࡌࡔࡾࡳࡱࡖࡹࡏࡐࡰࡰ࠴ࡹࡪ࠹ࡲ࡜࡭ࡁ࡮ࡄࡱࡻ࡛ࡩ࡚ࡃࡘࡸ࡫ࡲࡓࡊࡪࡘࡦࡴࡑ࠼࠭ࡕ࠴ࡦࡎࡌࡻ࠵ࡧࡆࡎࡱࡊࡹࡸࡢ࡜ࡶ࠵ࡔࡗࡇࡒࡺࡳ࠼ࡹࡕࡲ࠳࡛ࡳࡥ࡛ࡩࡁࡗࡲࡨࡔࡪࡺࡑ࡭ࡄ࡙࠴ࡾࡇ࠸ࡨࡖࡆࡕࡨࡶ࡭࡯ࡨ࡜ࡨࡔ࡙ࡣࡒ࡭ࡻ࡙࠾ࡵ࡟ࡴ࠷ࡔ࠸ࡸࡰࡐ࠵ࡊࡲࡺ࠷ࡗࡢࡣࡪࡊ࡚࠾࡙ࡉ࠵ࡑ࠻ࡥ࠲࡜ࡒࡂࡘ࡛ࡶ࡚ࢀࡰࡧ࠸ࡻࡽࡺ࡫ࡶ࡚ࡵࡸ࡜࠸ࡎࡸࡉࡣࡢࡆࡸ࡟ࡑࡄ࠻ࡘ࠻ࡉ࡞࠰࡫ࡨ࡭ࡆࡏࡊ࡭ࡪ࡮ࡍࡥࡧ࠼ࡕࡅࡔࡧ࡚ࡈࡲࡥࡈ࠯࡭ࡊࡼ࠽ࡒࡌࡲ࠺࠹࡚࡛ࡨ࡭ࡼ࡛ࡅࡑࡕࡆࡰࡪ࠶ࡍ࡜ࡧ࡚ࡘ࠻࡭ࡐࡪ࠶ࡆ࠴࡯࡙ࡩࡲ࡜ࡔࡒ࠯࠴࠷ࡵ࠶ࡏࡂࡻࡱࡻࡺࡵࡁࡕ࡜࡚ࡊࡹ࡮ࡅࡍ࠺ࡆ࠴ࡓࡑࡍࡖࡤࡧ࡚࡬࠻ࡤ࠮ࡡ࠹࠶࠽ࡱ࡟ࡃࡹࡇ࠵ࡗ࠼ࡋࡥ࠶࡛࡮ࡺࡇ࠹ࡧ࡮ࡔࡇࡊࡓࡧࡖ࠷࡫ࡾࡑࡳ࠸ࡓࡡࡎ࠷ࡋࡑࡡࡇ࡭ࡓࡴ࡮ࡻࡕࡔ࠵ࡰࡶ࠲ࡺࡘࡻ࠹ࡹࡷࡹࡒ࠹ࡃࡋࡓ࡜࡯ࡗࡷ࠷࠺࡜࠵ࡺࡳ࡫ࡠ࠹ࡵࡕࡻࡑࡊࡨࡋࡔࡅ࠷ࡔࡦࡣ࠷ࡺࡥ࡙ࡇࡄࡇ࠳ࡪࡥࡈࡻࡳ࡚ࡏ࠷ࡨ࠶࠺ࡎࡉ࠻ࡉ࠹࠷ࡱࡅ࠵࡮ࡵࡨࡧࡧ࡙࠳ࡗࡖ࠽ࡺ࡯ࡎࡄࡳࡈࡪ࡞࡮ࡁࡤࡼ࡛ࡽࡋ࡭ࡸࡹࡳࡅࡎ࠺࠾ࡂ࠷ࡒࡓࡾ࠵ࡱ࠳ࡎ࠹࠰࡜ࡶࡠࡓࡵࡒࡽࡥࡒࡖ࠴ࡎࡆࡕࡊࡷ࠺ࡹࡶࡌ࠴ࡅࡳ࠽ࡤࡰࡰ࠷࡭ࡲ࠼࠹ࡤࡑ࠻ࡴࡈ࠶ࡹࡷࡩࡤࡽ࡜ࡾࡳࡢ࡮ࡐ࠼ࡏࡒࡃࡅ࡫ࡗ࠻࡛ࡳࡓ࡬ࡣ࠺࠼ࡌ࡟ࡤ࠱ࡄࡧࡻࡘࡥࡤࡄ࠳ࡗࡼ࡙࡯࡫ࡩࡘ࠻ࡧࡍ࠿ࡡࡥࡌ࡛࡝࠺ࡇࡴࡄࡌࡆࡍ࠷࡫ࡪࡵࡃࡦࡧࡾ࡟࠵ࡪࡻࡦ࡭ࡪ࠳ࡺࡷࡐ࡝ࡩ࡯ࡼࡡࡄ࠺ࡊ࡝ࡎ࡬ࡷࡌࡐࡨ࡝ࡆ࠹ࡖࡪ࠸࠳࡫࡞ࡔࡧࡊࡧࡹ࠶ࡦ࠻ࡕࡎࡋࡔ࡞࡫࡟࠴ࡻ࡙ࡩࡣࡵࡰࡳ࠹ࡖ࠺ࡻࡉࡒࡱࡳ࠲࠻࡯ࡗࡎࡴࡓ࠹࡫ࡽࡧࡳ࡭ࡌࡵࡹ࡝ࡼࡍࡆ࡬࡫ࡇࡑࡻ࡫ࡥࡲࡓࡻ࠱ࡻࢀࡖࡅ࠶ࡦ࠽ࡹ࡫࠷࠺࡜ࡳࡓࡺࡘࡓ࡮ࡃࡑ࠼࡮࡯࠲ࡂࡴࡧ࡝ࡍ࡝ࡢࡠࡏ࠹࠽ࡦ࠶ࡈࡧࡨࡤ࡫ࡿࡖࡴࡖ࠺ࡐࡇࡨ࠼ࡌࡸࡷ࠻ࡘ࠻࠻ࡷ࠲ࡺࡴ࠻ࡎࡒ࡮ࡒࡔࡲࡧࡨࡶࡰࡎࡹࡆ࠽ࡇ࠾ࡔ࠹࡮ࡽࡨࡎࡷࡓ࠳ࡻࡏࡇࡸ࡭ࡋࡹࡼࡦࡐࡋࡕࡥࡲࡲࡷࡣࡖࡇࡉࡥࡐࡪ࡭ࡧࡿࡆ࠴ࡳ࠺ࡈ࡟࡫ࡣ࡭࠶࠴ࡶ࠷࡮ࡸࡏ࡭ࡋࡴ࠻ࡳࡔ࠲࡭࡭࡯ࡈ࠾ࡧࡸࡼࡆࡦ࡬ࡼࡊࡂࡱࡴ࠻ࡿࡻ࡚ࡖ࡚ࡹࡳࡖࡉࡵࡆࡇࡘࡒࡆࡻࡣࡊࡶࡋࡑ࠾࡛ࡣࡎࡆࡔ࠸࡮ࡓ࡙ࡑࡹࡅ࡛ࡧࡹࡕࡧࡧࡽࡅࡇ࡯ࡏࡘࡰࡨ࠴ࡋ࠽ࡑࡒࡥࡈࡣࡐ࡜࡙࠵ࡻࡈ࠸ࡗࡌࡓࡆࡰࡷ࡛ࡱ࠿࡮ࡺࡻ࡛࠽ࡔ࠸ࡏ࡚࠸࡫ࡉ࡮࠸ࡥ࠲ࡉ࠸ࡆࡆ࡫ࡘࡅࡡ࠴ࡽ࡮ࡒ࠹ࡴ࠯ࡶ࠺࠽ࡶ࡬ࡪ࡭ࡉࡊࡤࡲࡂࡳࡓ࡜࠴ࡻࡩࡡࡑࡰࡐ࠺࠾ࡗࡓࡧࡰࡵ࡙ࡆࡴࡆ࠶ࡪ࠺ࡆࡌࡽ࡬ࡕ࡭ࡴࡆ࡬ࡲࡷ࠷࠴ࡸࡓࡼ࠻ࡐ࡯࠴࡮ࡸࡾ࡭ࡒࡑ࠯ࡅࡘ࡙ࡶࡧࡖࡺ࡙ࡥ࠵࡬ࡴࡩࡺࡈ࡮ࡗࡥ࠳࠲ࡘࡆ࡙ࡻࡈ࡭ࡅ࠵ࡱࡻࡻ࡯ࡏࡐࡃࡕࡆࡰࡔࡸࡸࡼࡑࡐࡻࢀࡂ࠮ࡎࡋࡕ࠹ࡏࡷࡵ࠺ࡕ࡛࡛ࡰ࠱ࡉࡆ࠵࠶ࡖ࡟ࡁࡘ࡬ࡉࡘࡍ࡛࡚ࡏࡏ࡜ࡳ࡬࠹ࡲࡇࡔ࠴࠵࡝࡯࠲ࡠ࠹ࡉ࡙ࡨ࡛ࡣࡐࡉࡉࡑࡿࢀ࡫ࡄ࡯ࡌࡳ࡫ࡶࡘ࠹࠳࠶ࡰࡰ࠻ࡤࡦࡆࡰࡌ࡮࡜ࡺࡰࡐ࡛࡫࠷ࡻࡒࡪࡣࡇࡎࡶࡪࡄࡨ࡮ࡷࡘ࠼࠾ࡁࡩࡏࡖࡊࡒࡠࡨࡰࡏ࡬ࡱࡏ࡛ࡶࡉ࡮ࡸࡹࡇ࠶࠹ࡊࡈࡆ࡯ࡊ࠶ࡍࡠ࠸ࡧࡾࡕࡿࡩ࠳࠵ࡪ࡭ࡩࡠࡒ࡫࡛ࡲࡨ࠽ࡶࡱࡗ࠴࠳ࡋ࠹࡟࠱ࡣࡅ࠹࡞ࡿࡺࡴ࡭ࡆࡥࡧࡗࡩࡣࡅࡨࡎࡥࡩࡩࡊࡶ࠻ࡈࡴࡌࡓࡣࡗࡎࡔࡲࡳࡈࡺࡴࡧࡗࡗ࠵ࡉࡇ࡮࠺ࡑ࠵ࡓࡲࡵࡅࡥ࡭ࡑ࡭ࡽ࡮ࡻ࡯࠻ࡸࡪ࡚ࡊࡊࡧࡪࡩࡸ࡯ࡰࡴࡊ࠺ࡕ࡟࠾ࡕࡺࡨࡪࡧࡾࡌࡐࡥ࠲࠰࠼ࡨࡕ࡫࡬࡯ࡎ࡫ࡱ࡫ࡅࡖࡆ࡙࡜ࡈࡺࡁ࡬࡜ࡖࡦ࡞࡚࠰࠴ࡕ࠰ࡸ࡚ࡷࡋࡹ࡫࡮ࡕ࠼ࡗࡸࡋࡑࡈ࡚ࡷࡎࡍ࠱࡛࠸ࡻ࡛ࡰࡌࡏࡖࡶ࠴࡙࡝ࡆࡖࡇࡇࡉࡴ࠻ࡩ࡙ࡸ࠰࠺ࡶࡽ࠹࠹ࡼࡸ࠺ࡾ࡯ࡗࡪࡓ࠵ࡴࡋࡨ࠷ࡔࡤࡻࡺ࡫ࡳࡘࡩࡍ࠶ࡵࡋ࡝ࡶ࡬ࡗࡆࡰࡽࡰࡧࡃࡪ࠺࡯࡛ࡻ࠵ࡵ࡭࡮ࡈࡓ࠶࠱࠲ࡕࡅ࠹ࡗ࡫࡯ࡄࡌࡸࡐࡩ࡬ࡈࡍࡶࡒ࡬࠷ࡌࡱ࡛࠴ࡺ࠻ࡕ࡮ࡇࡌࡄ࡭ࡩࡻࡪࡁࡍ࠴ࡩࡇࡗࡋࡨ࡙࠳ࡍࡸ࡞ࡔ࠸ࡺࡃࡘ࡭ࡕࡔࡪࡹ࡭ࡄࡆࡹࡇࡢ࡮ࡻࡏ࠻ࡸ࠳ࡋࡱ࠴࡚ࡦࡻࡼࡒࡲࡎ࠷࠷࠺࠽ࡴࡕ࠸ࡰࡒ࡝ࡉࡱࡨ࠯ࡩࡲࡒ࠷ࡩࡒ࠻ࡲ࡝ࡆࡺࡐࡪ࡯ࡍࡳࡩࡼࡄ࠹࡜ࡆࡏ࡞࠻ࡂ࠺࡯ࡦ࠷ࡦࡕࡵࡅࡋࡔࡾࡻ࠼ࡌࡕࡡࡲࡴࡪࡼࡖࡢ࠻࠺ࡳࡋ࠶࡬ࡦࡦ࡬࡙࠽࡭ࡏ࠷࠵ࡈࡹࡶࡳ࠶ࡨࡋ࠸ࡏ࠵ࡰ࠵ࡗࡒࡨ࡚ࡻࡶࡣ࠱ࡼࡼࡥ࡞࡜ࡘࡇ࠻ࡷࡼ࠺ࡗࡺࡇࡍࡷࡓࡊࡇࡃࡠࡍࡤࡘ࡭࠳ࡓࡶ࠹ࡘࡎࡳ࡝࠴ࡒࡤࡋ࡙࡮࠿ࡐ࡭ࡵࡪ࡫ࡖࡖ࠰ࡋࡃ࠸࠺ࡤ࡭ࡨࡕࡑ࠻ࡆ࡯ࡖ࡙࠳ࡷ࠻ࡏ࠾࠿ࡈࡅࡪࡢࡨࡵ࠺ࡅࡣ࠳ࡈ࠴࡙࠿ࡁ࠲ࡺࡷࡾࡷࡨࡘ࠴࡜ࡪࡊ࠵࠻ࡷࡄࡇࡍࡩ࠺ࡒ࡭࠳ࡳ࡛࠴࡚ࡪ࡚࡙ࡻࡢࡅ࡛ࡻࡱ࠸ࡕ࠶ࡉࡒ࠹ࡍ࡫ࡪࡍࡍ࡟࠳ࡋࡣ࡬ࡨ࠻ࡕࡵࡦࡲ࡮ࡻࡋࡲ࠶࠹ࡊࡪࡍࡼࡗࡩࡤࡆ࠶࡭࡜࡟࡭ࡲ࡭ࡦ࠺ࡥࡕ࡮ࡶ࠱ࡄࡗ࠵ࡖ࠿࠱ࡅ࡚ࡵࡖ࠽ࡲࡌࡵ࡛࠹ࡒࡗࡈࡳ࡛ࡨ࡮࡬࠾ࡔࠧ৭")
           }
    data=urllib.urlencode(params)
    a=l1lll11l1ll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡱࡸࡳ࠳࡯࡯࠰ࡩࡲ࠳ࡋࡱࡢࡤࡷࠪ৮"),data)
    print a
def _1llll1l1ll11l1l11_nktv_(url,host=l1l11ll11l1l11_nktv_ (u"ࠩࠪ৯")):
    l1111l11ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠪࠫৰ")
    if url.startswith(l1l11ll11l1l11_nktv_ (u"ࠫ࡭ࡺࡴࡱࠩৱ")):
        if l1l11ll11l1l11_nktv_ (u"ࠬࡲࡩ࡯࡭࡬࠲ࡴࡴ࡬ࡪࡰࡨࠫ৲") in url:
            content = l1lll11l1ll11l1l11_nktv_(url)
            l1l1l1l1ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"࠭ࡴࡰࡲ࠱ࡰࡴࡩࡡࡵ࡫ࡲࡲࠥࡃࠠ࡜࡞ࠪࠦࡢ࠮࠮ࠫࡁࠬ࡟ࡡ࠭ࠢ࡞࠽ࠪ৳")).search(content)
            if l1l1l1l1ll11l1l11_nktv_:
                l1111l11ll11l1l11_nktv_ = l1l1l1l1ll11l1l11_nktv_.group(1)
        if l1l11ll11l1l11_nktv_ (u"ࠧࡰࡷࡲ࠲࡮ࡵࠧ৴") in url:
            l1111l11ll11l1l11_nktv_ = url
        else:
            req = urllib2.Request(url)
            req.add_header(l1l11ll11l1l11_nktv_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ৵"), l1l11ll11l1l11_nktv_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠶࠻࠲࠵࠴࠲࠶࠸࠷࠲࠾࠽ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧ৶"))
            try:
                response = urllib2.urlopen(req)
                if response:
                    l1111l11ll11l1l11_nktv_=response.url
                    if l1111l11ll11l1l11_nktv_==url:
                        content=response.read()
                        l1l1l1l1ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࠫࠥࠤࡨࡲࡡࡴࡵࠪ৷")).findall(content)
                        for l in l1l1l1l1ll11l1l11_nktv_:
                            if host in l:
                                l1111l11ll11l1l11_nktv_ = l
                                break
                    response.close()
            except:
                pass
    return l1111l11ll11l1l11_nktv_
def l1111ll1ll11l1l11_nktv_(url,content=None):
    if not content:
        content = l1lll11l1ll11l1l11_nktv_(url)
    out  =[]
    l1ll11lllll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩࠥ࠮࠮ࠫࡁࠬࡀ࠴࡯ࡦࡳࡣࡰࡩࡃ࠭৸"),re.DOTALL).findall(content)
    names = re.compile(l1l11ll11l1l11_nktv_ (u"ࠬࡂࡵ࡭ࠢࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡨ࡙ࡧࡢࡴࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ৹"),re.DOTALL).findall(content)
    if names:
        names = [x.strip() for x in re.compile(l1l11ll11l1l11_nktv_ (u"࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ৺"),re.DOTALL).findall(names[0]) if x.strip()]
    else:
        names=[]
    for l1lllllllll11l1l11_nktv_ in l1ll11lllll11l1l11_nktv_:
        href = re.compile(l1l11ll11l1l11_nktv_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ৻"),re.DOTALL).search(l1lllllllll11l1l11_nktv_)
        if href:
            l111111lll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠨࡪࡷࡸࡵ࠭ৼ")+ urllib.unquote(href.group(1)).split(l1l11ll11l1l11_nktv_ (u"ࠩ࡫ࡸࡹࡶࠧ৽"))[-1]
            if l111111lll11l1l11_nktv_.startswith(l1l11ll11l1l11_nktv_ (u"ࠪ࡬ࡹࡺࡰࠨ৾")) and not l1l11ll11l1l11_nktv_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬ৿") in l111111lll11l1l11_nktv_ and not l1l11ll11l1l11_nktv_ (u"ࠬ࡬ࡡࡤࡧࡥࡳࡴࡱࠧ਀") in l111111lll11l1l11_nktv_:
                host = urlparse(l111111lll11l1l11_nktv_).netloc
                l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"࠭ࡵࡳ࡮ࠪਁ") : l111111lll11l1l11_nktv_,
                    l1l11ll11l1l11_nktv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ਂ"): l1l11ll11l1l11_nktv_ (u"ࠣ࡝ࠨࡷࡢࠨਃ") %(host),
                    l1l11ll11l1l11_nktv_ (u"ࠩ࡫ࡳࡸࡺࠧ਄"): host    }
                out.append(l11111llll11l1l11_nktv_)
    if len(names)==len(out):
        for l11111llll11l1l11_nktv_,name in zip(out,names):
            l11111llll11l1l11_nktv_[l1l11ll11l1l11_nktv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩਅ")] += l1l11ll11l1l11_nktv_ (u"ࠫࠥࠫࡳࠨਆ")%name
    return out
url=l1l11ll11l1l11_nktv_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡥࡣ࠰ࡳࡳࡲࡩ࡯ࡧ࠱ࡴࡱ࠵ࡨࡰࡰࡧࡳ࠴࠭ਇ")
def l1l1lllll11l1l11_nktv_(url):
    content = l1lll11l1ll11l1l11_nktv_(url)
    ids = [(a.start(), a.end()) for a in re.finditer(l1l11ll11l1l11_nktv_ (u"࠭࠼࡭࡫ࠣࡧࡱࡧࡳࡴ࠿ࠥࡩࡱ࡫࡭ࡦࡰࡷࡳࠧࡄࠧਈ"), content)]
    ids.append( (-1,-1) )
    out=l1111ll1ll11l1l11_nktv_(url,content)
    for i in range(len(ids[:-1])):
        l111l1llll11l1l11_nktv_ = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile(l1l11ll11l1l11_nktv_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩਉ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        host = re.compile(l1l11ll11l1l11_nktv_ (u"ࠨ࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭ࡅ࠺࠯ࠬࡂ࠭ࠧࠦࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࡠࡢࡳ࡝ࡰࡠ࠯࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪਊ")).search(l111l1llll11l1l11_nktv_)
        l1lll1111ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠩ࠿ࡷࡵࡧ࡮ࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡥࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ਋"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        l1llllll1ll11l1l11_nktv_ =re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࡀࡸࡶࡡ࡯ࠢࡦࡰࡦࡹࡳ࠾ࠤࡧࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ਌"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        if href and host:
            j= l1lll1111ll11l1l11_nktv_.group(1) if l1lll1111ll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠫࠬ਍")
            q= l1llllll1ll11l1l11_nktv_.group(1) if l1llllll1ll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠬ࠭਎")
            host = host.groups()[-1]
            l111111lll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"࠭ࡨࡵࡶࡳࠫਏ")+ urllib.unquote(href.group(1)).split(l1l11ll11l1l11_nktv_ (u"ࠧࡩࡶࡷࡴࠬਐ"))[-1]
            print i,host,l111111lll11l1l11_nktv_,l1l11ll11l1l11_nktv_ (u"ࠨ࡞ࡱࠫ਑")
            l1ll11l1ll11l1l11_nktv_ = l111111lll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡦࡨࡦ࠳࡯࡯࡮࡬ࡲࡪ࠴ࡰ࡭ࡁࠪ਒"),l1l11ll11l1l11_nktv_ (u"ࠪࠫਓ"))
            if l1ll11l1ll11l1l11_nktv_:
                msg =l1l11ll11l1l11_nktv_ (u"ࠫࠬਔ")
                if l1l11ll11l1l11_nktv_ (u"ࠬࡵࡵࡰ࠰࡬ࡳࠬਕ") in l1ll11l1ll11l1l11_nktv_:
                    msg = l1l11ll11l1l11_nktv_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠࠤࡴࡻ࡯࠯࡫ࡲࠤࡳࡵࡴࠡࡵࡸࡴࡵࡵࡲࡵࡧࡧ࡟࠴ࡉࡏࡍࡑࡕࡡࠬਖ")
                l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠧࡶࡴ࡯ࠫਗ") : urllib.unquote(l1ll11l1ll11l1l11_nktv_),
                    l1l11ll11l1l11_nktv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧਘ"): l1l11ll11l1l11_nktv_ (u"ࠤ࡞ࠩࡸࡣࠠࠦࡵ࠯ࠤࠪࡹࠠࠦࡵࠥਙ") %(host,j,q,msg),
                    l1l11ll11l1l11_nktv_ (u"ࠪ࡬ࡴࡹࡴࠨਚ"): host    }
                out.append(l11111llll11l1l11_nktv_)
    return out
url=l1l11ll11l1l11_nktv_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡤࡢ࠯ࡲࡲࡱ࡯࡮ࡦ࠰ࡳࡰ࠴ࡹࡥࡳ࡫ࡤࡰࡪ࠵ࡤࡦࡺࡷࡩࡷ࠵ࠧਛ")
def l1111l1ll11l1l11_nktv_(url):
    content = l1lll11l1ll11l1l11_nktv_(url)
    l1lll1lllll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠬ࡯࡭ࡢࡩࡨ࠾ࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪਜ")).findall(content)
    l1lll1lllll11l1l11_nktv_ = l1lll1lllll11l1l11_nktv_[0] if l1lll1lllll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"࠭ࠧਝ")
    ids = [(a.start(), a.end()) for a in re.finditer(l1l11ll11l1l11_nktv_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡴࡵ࡮ࡧࡵࡥࡳࡪ࡯ࠣࡀࠪਞ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l111l1llll11l1l11_nktv_ = content[ ids[i][1]:ids[i+1][0] ]
        l1111l1lll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁ࡟ࡡࡹ࡜࡯࡟࠮ࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ਟ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        date = re.compile(l1l11ll11l1l11_nktv_ (u"ࠩ࠿ࡷࡵࡧ࡮ࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡦࡤࡸࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭ਠ")).search(l111l1llll11l1l11_nktv_)
        l1ll11l11ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࠬࡡࡪࠫࡀࠫࠣࡼࠥ࠮࡜ࡥ࠭ࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫਡ")).findall(l111l1llll11l1l11_nktv_)
        if l1111l1lll11l1l11_nktv_:
            d= date.group(1) if date else l1l11ll11l1l11_nktv_ (u"ࠫࠬਢ")
            t= l1111l1lll11l1l11_nktv_.group(2)
            l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠬ࡮ࡲࡦࡨࠪਣ")  : l1111l1lll11l1l11_nktv_.group(1),
                l1l11ll11l1l11_nktv_ (u"࠭ࡰ࡭ࡱࡷࠫਤ"): l1lll1ll1ll11l1l11_nktv_(t.strip()),
                l1l11ll11l1l11_nktv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ਥ") : l1lll1ll1ll11l1l11_nktv_(t.strip()),
                l1l11ll11l1l11_nktv_ (u"ࠨ࡫ࡰ࡫ࠬਦ"):l1lll1lllll11l1l11_nktv_,
                l1l11ll11l1l11_nktv_ (u"ࠩࡶࡩࡦࡹ࡯࡯ࠩਧ"): int(l1ll11l11ll11l1l11_nktv_[0][0]) if l1ll11l11ll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠪࠫਨ"),
                l1l11ll11l1l11_nktv_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࠬ਩"): int(l1ll11l11ll11l1l11_nktv_[0][1]) if l1ll11l11ll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠬ࠭ਪ"),
                l1l11ll11l1l11_nktv_ (u"࠭ࡡࡪࡴࡨࡨࠬਫ") : d}
            out.append(l11111llll11l1l11_nktv_)
    return out
def l1lllll1lll11l1l11_nktv_(m):
    return l1l11ll11l1l11_nktv_ (u"ࠧࡩࡴࡨࡪࡂࠨࠧਬ")+urllib.unquote(m.group(1))
def l1l11ll1ll11l1l11_nktv_(l1l111l1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠨࡨ࡬ࡰࡲ࠭ਭ"),l11ll1llll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠩࡪࡥࡹࡻ࡮ࡦ࡭ࠪਮ")):
    content = l1lll11l1ll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡧࡩࡧ࠭ࡰࡰ࡯࡭ࡳ࡫࠮ࡱ࡮࠲ࠫਯ"))
    if l1ll1l1l1ll11l1l11_nktv_:
        content=content.replace(l1ll1l1l1ll11l1l11_nktv_,l1l11ll11l1l11_nktv_ (u"ࠫࠬਰ"))
        content=re.sub(l1l11ll11l1l11_nktv_ (u"ࡷ࠭ࡨࡳࡧࡩࡁࡠࡢࠧࠣ࡟ࡂࠬࡠࡤ࡜ࠨࠤࠣࡂࡢ࠱ࠩࠨ਱"),l1lllll1lll11l1l11_nktv_,content)
    selected = []
    if l1l111l1ll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"࠭ࡦࡪ࡮ࡰࠫਲ"):
        if l11ll1llll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠧࡨࡣࡷࡹࡳ࡫࡫ࠨਲ਼"):
            selected = re.compile(l1l11ll11l1l11_nktv_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࡝ࡶࡡ࠿࠵࠯ࡤࡦࡤ࠱ࡴࡴ࡬ࡪࡰࡨ࠲ࡵࡲ࠯࡬ࡣࡷࡩ࡬ࡵࡲࡪࡣ࠲࠲࠯ࡅ࠯ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ਴")).findall(content)
        elif l11ll1llll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠩࡵࡳࡰ࠭ਵ"):
            selected = re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࡟ࡸࡣ࠺࠰࠱ࡦࡨࡦ࠳࡯࡯࡮࡬ࡲࡪ࠴ࡰ࡭࠱ࡵࡳࡰ࠵࡜ࡥࡽ࠷ࢁ࠴࠯ࠢ࠿ࠪ࡟ࡨࢀ࠺ࡽࠪ࠾࠲ࡥࡃ࠭ਸ਼")).findall(content)
        elif l11ll1llll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠫ࡯ࡧ࡫ࡰࡵࡦࠫ਷"):
            selected = re.compile(l1l11ll11l1l11_nktv_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵࡡࡳ࡞࠼࠲࠳ࡨࡪࡡ࠮ࡱࡱࡰ࡮ࡴࡥ࠯ࡲ࡯࠳࡯ࡧ࡫ࡰࡵࡦ࠳࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ਸ")).findall(content)
    elif l1l111l1ll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"࠭ࡳࡦࡴ࡬ࡥࡱ࠭ਹ"):
        if l11ll1llll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠧࡨࡣࡷࡹࡳ࡫࡫ࠨ਺"):
            selected = re.compile(l1l11ll11l1l11_nktv_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࡝ࡶࡡ࠿࠵࠯ࡤࡦࡤ࠱ࡴࡴ࡬ࡪࡰࡨ࠲ࡵࡲ࠯ࡴࡧࡵ࡭ࡦࡲࡥ࠮ࡩࡤࡸࡺࡴࡥ࡬࠱࠱࠮ࡄ࠯ࠢ࡜࡞ࡷࡠࡳࠦ࡝ࠫࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ਻")).findall(content)
        elif l11ll1llll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠩࡵࡳࡰ਼࠭"):
            selected = re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࡟ࡸࡣ࠺࠰࠱ࡦࡨࡦ࠳࡯࡯࡮࡬ࡲࡪ࠴ࡰ࡭࠱ࡶࡩࡷ࡯ࡡ࡭ࡧ࠰ࡶࡴࡱ࠯࡝ࡦࡾ࠸ࢂ࠵ࠩࠣࡀࠫࡠࡩࢁ࠴ࡾࠫ࠿࠳ࡦࡄࠧ਽")).findall(content)
    if selected:
        l1lll1l11ll11l1l11_nktv_ = [x[0] for x in selected]
        l1ll11l1lll11l1l11_nktv_ = [l1l11ll11l1l11_nktv_ (u"ࠫࠥ࠭ਾ").join(x[1:]) for x in selected]
        return (l1ll11l1lll11l1l11_nktv_,l1lll1l11ll11l1l11_nktv_)
    return False
def l1lll1ll1ll11l1l11_nktv_(l1llll1llll11l1l11_nktv_):
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠬࠩ࠰࠴࠺࠾ࠫਿ"),l1l11ll11l1l11_nktv_ (u"࠭ࠧੀ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠧࠧ࡮ࡷ࠿ࡧࡸ࠯ࠧࡩࡷ࠿ࠬੁ"),l1l11ll11l1l11_nktv_ (u"ࠨࠢࠪੂ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠩࠩࠎࠥࠦࠠࠡࡶࡻࡸࠥࡃࠠࡵࡺࡷ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭੃")&
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠪࠪࠏࠦࠠࠡࠢࡷࡼࡹࠦ࠽ࠡࡶࡻࡸ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ੄")&
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠫࠫࠐࠠࠡࠢࠣࡸࡽࡺࠠ࠾ࠢࡷࡼࡹ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ੅")&
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠬࠬࡱࡶࡱࡷ࠿ࠬ੆"),l1l11ll11l1l11_nktv_ (u"࠭ࠢࠨੇ")).replace(l1l11ll11l1l11_nktv_ (u"ࠧࠧࡣࡰࡴࡀࡷࡵࡰࡶ࠾ࠫੈ"),l1l11ll11l1l11_nktv_ (u"ࠨࠤࠪ੉"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠩࠩࡳࡦࡩࡵࡵࡧ࠾ࠫ੊"),l1l11ll11l1l11_nktv_ (u"ࠪࣷࠬੋ")).replace(l1l11ll11l1l11_nktv_ (u"ࠫࠫࡕࡡࡤࡷࡷࡩࡀ࠭ੌ"),l1l11ll11l1l11_nktv_ (u"੍ࠬࣙࠧ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"࠭ࠦࡢ࡯ࡳ࠿ࡴࡧࡣࡶࡶࡨ࠿ࠬ੎"),l1l11ll11l1l11_nktv_ (u"ࠧࣴࠩ੏")).replace(l1l11ll11l1l11_nktv_ (u"ࠨࠨࡤࡱࡵࡁࡏࡢࡥࡸࡸࡪࡁࠧ੐"),l1l11ll11l1l11_nktv_ (u"ࠩࣖࠫੑ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠪࡠࡺ࠶࠱࠱࠷ࠪ੒"),l1l11ll11l1l11_nktv_ (u"ࠫऊ࠭੓")).replace(l1l11ll11l1l11_nktv_ (u"ࠬࡢࡵ࠱࠳࠳࠸ࠬ੔"),l1l11ll11l1l11_nktv_ (u"࠭ऄࠨ੕"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠧ࡝ࡷ࠳࠵࠵࠽ࠧ੖"),l1l11ll11l1l11_nktv_ (u"ࠨउࠪ੗")).replace(l1l11ll11l1l11_nktv_ (u"ࠩ࡟ࡹ࠵࠷࠰࠷ࠩ੘"),l1l11ll11l1l11_nktv_ (u"ࠪऊࠬਖ਼"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠫࡡࡻ࠰࠲࠳࠼ࠫਗ਼"),l1l11ll11l1l11_nktv_ (u"ࠬटࠧਜ਼")).replace(l1l11ll11l1l11_nktv_ (u"࠭࡜ࡶ࠲࠴࠵࠽࠭ੜ"),l1l11ll11l1l11_nktv_ (u"ࠧङࠩ੝"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠨ࡞ࡸ࠴࠶࠺࠲ࠨਫ਼"),l1l11ll11l1l11_nktv_ (u"ࠩॅࠫ੟")).replace(l1l11ll11l1l11_nktv_ (u"ࠪࡠࡺ࠶࠱࠵࠳ࠪ੠"),l1l11ll11l1l11_nktv_ (u"ࠫॆ࠭੡"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠬࡢࡵ࠱࠳࠷࠸ࠬ੢"),l1l11ll11l1l11_nktv_ (u"࠭ॄࠨ੣")).replace(l1l11ll11l1l11_nktv_ (u"ࠧ࡝ࡷ࠳࠵࠹࠺ࠧ੤"),l1l11ll11l1l11_nktv_ (u"ࠨॅࠪ੥"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠩ࡟ࡹ࠵࠶ࡦ࠴ࠩ੦"),l1l11ll11l1l11_nktv_ (u"ࠪࣷࠬ੧")).replace(l1l11ll11l1l11_nktv_ (u"ࠫࡡࡻ࠰࠱ࡦ࠶ࠫ੨"),l1l11ll11l1l11_nktv_ (u"ࠬࣙࠧ੩"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"࠭࡜ࡶ࠲࠴࠹ࡧ࠭੪"),l1l11ll11l1l11_nktv_ (u"ࠧड़ࠩ੫")).replace(l1l11ll11l1l11_nktv_ (u"ࠨ࡞ࡸ࠴࠶࠻ࡡࠨ੬"),l1l11ll11l1l11_nktv_ (u"ࠩढ़ࠫ੭"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠪࡠࡺ࠶࠱࠸ࡣࠪ੮"),l1l11ll11l1l11_nktv_ (u"ࠫॿ࠭੯")).replace(l1l11ll11l1l11_nktv_ (u"ࠬࡢࡵ࠱࠳࠺࠽ࠬੰ"),l1l11ll11l1l11_nktv_ (u"࠭ॹࠨੱ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠧ࡝ࡷ࠳࠵࠼ࡩࠧੲ"),l1l11ll11l1l11_nktv_ (u"ࠨॾࠪੳ")).replace(l1l11ll11l1l11_nktv_ (u"ࠩ࡟ࡹ࠵࠷࠷ࡣࠩੴ"),l1l11ll11l1l11_nktv_ (u"ࠪॿࠬੵ"))
    return l1llll1llll11l1l11_nktv_
