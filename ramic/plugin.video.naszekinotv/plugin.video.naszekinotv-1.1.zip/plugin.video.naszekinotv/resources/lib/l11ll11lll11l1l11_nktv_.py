# -*- coding: utf-8 -*-
import sys
l1111ll11l1l11_nktv_ = sys.version_info [0] == 2
l111ll11l1l11_nktv_ = 2048
l1l1lll11l1l11_nktv_ = 7
def l1l11ll11l1l11_nktv_ (keyedStringLiteral):
	global l11llll11l1l11_nktv_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1111ll11l1l11_nktv_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os
import json
import l11lll1llll11l1l11_nktv_ as l1lll1l1lll11l1l11_nktv_
import cookielib
from urlparse import urlparse
l1ll1l11lll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨࡪࡡࡹ࠰ࡷࡺ࠴࠭ଲ")
l1111lllll11l1l11_nktv_ = 15
l1ll11ll1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡐ࡙࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠸࠽࠴࠰࠯࠴࠸࠺࠹࠴࠹࠸ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩଳ")
l11ll1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࡷ࠭ࡄ࠻࡞ࡦࡨࡦࡾ࠮ࡤࡱࡲ࡯࡮࡫ࠧ଴")
l1ll1l1l1ll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"࠭ࠧଵ")
l1l111l1lll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠧࠨଶ")
l1l111l1lll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡨࡲࡢ࡯࡮ࡥ࠲ࡶࡲࡰࡺࡼ࠲ࡵࡲ࠯ࠨଷ")
l1l1l1111ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠩࠪସ")
def l1l111111ll11l1l11_nktv_(url,header={}):
    l1ll11l1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠪࠫହ")
    global l1l1l1111ll11l1l11_nktv_
    if not l1l1l1111ll11l1l11_nktv_:
        req = urllib2.Request(l1l111l1lll11l1l11_nktv_,data=None,headers={l1l11ll11l1l11_nktv_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ଺"): l1ll11ll1ll11l1l11_nktv_,l1l11ll11l1l11_nktv_ (u"࡛ࠬࡰࡨࡴࡤࡨࡪ࠳ࡉ࡯ࡵࡨࡧࡺࡸࡥ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡵࠪ଻"):1})
        response = urllib2.urlopen(req,timeout=l1111lllll11l1l11_nktv_)
        cookies=response.headers.get(l1l11ll11l1l11_nktv_ (u"࠭ࡳࡦࡶ࠰ࡧࡴࡵ࡫ࡪࡧ଼ࠪ"),l1l11ll11l1l11_nktv_ (u"ࠧࠡࠩଽ")).split(l1l11ll11l1l11_nktv_ (u"ࠨࠢࠪା"))[0]
        response.close()
        l1l1l1111ll11l1l11_nktv_ = cookies
    else:
        cookies=l1l1l1111ll11l1l11_nktv_
    data = l1l11ll11l1l11_nktv_ (u"ࠩࡸࡁࠪࡹࠦࡢ࡮࡯ࡳࡼࡉ࡯ࡰ࡭࡬ࡩࡸࡃ࡯࡯ࠩି")%urllib.quote_plus(url)
    l11lll1l1ll11l1l11_nktv_ = l1l111l1lll11l1l11_nktv_+l1l11ll11l1l11_nktv_ (u"ࠪ࠳࡮ࡴࡣ࡭ࡷࡧࡩࡸ࠵ࡰࡳࡱࡦࡩࡸࡹ࠮ࡱࡪࡳࡃࡦࡩࡴࡪࡱࡱࡁࡺࡶࡤࡢࡶࡨࠫୀ")
    headers={l1l11ll11l1l11_nktv_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨୁ"): l1ll11ll1ll11l1l11_nktv_,l1l11ll11l1l11_nktv_ (u"࡛ࠬࡰࡨࡴࡤࡨࡪ࠳ࡉ࡯ࡵࡨࡧࡺࡸࡥ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡵࠪୂ"):1,l1l11ll11l1l11_nktv_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭ୃ"):cookies}
    headers.update(header)
    req = urllib2.Request(l11lll1l1ll11l1l11_nktv_,data,headers)
    response = urllib2.urlopen(req,timeout=l1111lllll11l1l11_nktv_)
    l1ll11l1ll11l1l11_nktv_=response.read()
    if l1l11ll11l1l11_nktv_ (u"ࠧࡴࡵ࡯ࡥ࡬ࡸࡥࡦࠩୄ") in l1ll11l1ll11l1l11_nktv_:
        l11lll1l1ll11l1l11_nktv_ = l1l111l1lll11l1l11_nktv_+l1l11ll11l1l11_nktv_ (u"ࠨ࠱࡬ࡲࡨࡲࡵࡥࡧࡶ࠳ࡵࡸ࡯ࡤࡧࡶࡷ࠳ࡶࡨࡱࡁࡤࡧࡹ࡯࡯࡯࠿ࡶࡷࡱࡧࡧࡳࡧࡨࠫ୅")
        req = urllib2.Request(l11lll1l1ll11l1l11_nktv_,data,headers)
        response = urllib2.urlopen(req,timeout=l1111lllll11l1l11_nktv_)
        l1ll11l1ll11l1l11_nktv_=response.read()
    response.close()
    print l1l11ll11l1l11_nktv_ (u"ࠩࡊࡅ࡙ࡋࠠࡪࡰ࡙ࠣࡘࡋࠧ୆")
    return l1ll11l1ll11l1l11_nktv_
def _1ll1ll1lll11l1l11_nktv_(url,data=None,header={},cookies=None):
    headers={l1l11ll11l1l11_nktv_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧେ"): l1ll11ll1ll11l1l11_nktv_,l1l11ll11l1l11_nktv_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬୈ"):l1ll1l11lll11l1l11_nktv_}
    headers.update(header)
    req = urllib2.Request(url,data,headers)
    l11llll11ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠬ࠭୉")
    if cookies:
        req.add_header(l1l11ll11l1l11_nktv_ (u"ࠨࡃࡰࡱ࡮࡭ࡪࠨ୊"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l1111lllll11l1l11_nktv_)
        l11llll11ll11l1l11_nktv_ = response.headers[l1l11ll11l1l11_nktv_ (u"ࠧࡴࡧࡷ࠱ࡨࡵ࡯࡬࡫ࡨࠫୋ")]
        response = urllib2.urlopen(req,timeout=l1111lllll11l1l11_nktv_)
        l1ll11l1ll11l1l11_nktv_ = response.read()
    except:
        l1ll11l1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠨࠩୌ")
    return l1ll11l1ll11l1l11_nktv_
def l1lll11l1ll11l1l11_nktv_(url,data=None,header={}):
    cookies=l1lll1l1lll11l1l11_nktv_.l1ll1l1llll11l1l11_nktv_(l11ll1ll11l1l11_nktv_)
    content=_1ll1ll1lll11l1l11_nktv_(url,data,header,cookies)
    if not content or len(content)<100:
        l111l1l1ll11l1l11_nktv_=l1ll1lll1ll11l1l11_nktv_(url,l11ll1ll11l1l11_nktv_)
        cookies=l1lll1l1lll11l1l11_nktv_.l1ll1l1llll11l1l11_nktv_(l11ll1ll11l1l11_nktv_)
        content=_1ll1ll1lll11l1l11_nktv_(url,data,header,cookies)
        if not content:
            print l1l11ll11l1l11_nktv_ (u"ࠩࡹ࡭ࡦࠦࡇࡂࡖࡈ࠾ࠥࠫࡳࠨ୍")%url
            content=l1l111111ll11l1l11_nktv_(url,header)
    return content
def l1ll1lll1ll11l1l11_nktv_(l1ll11l1ll11l1l11_nktv_,l1lll11llll11l1l11_nktv_):
    l111l1l1ll11l1l11_nktv_ = cookielib.LWPCookieJar()
    l1lll111lll11l1l11_nktv_ = l1lll1l1lll11l1l11_nktv_.l1lllll11ll11l1l11_nktv_(l1ll11l1ll11l1l11_nktv_,l111l1l1ll11l1l11_nktv_,l1ll11ll1ll11l1l11_nktv_)
    l11l11l1ll11l1l11_nktv_=os.path.dirname(l1lll11llll11l1l11_nktv_)
    if not os.path.exists(l11l11l1ll11l1l11_nktv_):
        os.makedirs(l11l11l1ll11l1l11_nktv_)
    if l111l1l1ll11l1l11_nktv_:
        l111l1l1ll11l1l11_nktv_.save(l1lll11llll11l1l11_nktv_, ignore_discard = True)
    return l111l1l1ll11l1l11_nktv_
def l1ll1ll1ll11l1l11_nktv_(url,l1l11llll11l1l11_nktv_=1,group=l1l11ll11l1l11_nktv_ (u"ࠪࠫ୎")):
    if l1l11ll11l1l11_nktv_ (u"ࠫࡄࡶࡡࡨࡧࡀࠫ୏") in url:
        url = re.sub(l1l11ll11l1l11_nktv_ (u"ࠬ࠭ࠧࡱࡣࡪࡩࡂࡢࡤࠬࠩࠪࠫ୐"),l1l11ll11l1l11_nktv_ (u"࠭ࠧࠨࡲࡤ࡫ࡪࡃࠥࡥࠩࠪࠫ୑")%l1l11llll11l1l11_nktv_,url)
    else:
        url += l1l11ll11l1l11_nktv_ (u"ࠧ࠰ࠩ୒") if url[-1] != l1l11ll11l1l11_nktv_ (u"ࠨ࠱ࠪ୓") else l1l11ll11l1l11_nktv_ (u"ࠩࠪ୔")
        url = url + l1l11ll11l1l11_nktv_ (u"ࠪࡃࡵࡧࡧࡦ࠿ࠨࡨࠬ୕") %l1l11llll11l1l11_nktv_
    content = l1lll11l1ll11l1l11_nktv_(url)
    content = urllib.unquote(content)
    l1l1111l1ll11l1l11_nktv_ = l1lll1l1lll11l1l11_nktv_.l1ll1l1llll11l1l11_nktv_(l11ll1ll11l1l11_nktv_)
    l11lllll1ll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠦࢁࡉ࡯ࡰ࡭࡬ࡩࡂࠫࡳࠧࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠫࡳࠣୖ") % (l1l1111l1ll11l1l11_nktv_, l1ll11ll1ll11l1l11_nktv_) if l1l1111l1ll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠬ࠭ୗ")
    if group:
        idx = [(m.start(0), m.end(0)) for m in re.finditer(group.decode(l1l11ll11l1l11_nktv_ (u"࠭ࡵࡵࡨ࠰࠼ࠬ୘")), content,re.IGNORECASE) ]
        if idx:
            idx = idx[0][0]
            l1ll111llll11l1l11_nktv_=content[idx:]
            ids = [(a.start(), a.end()) for a in re.finditer(l1l11ll11l1l11_nktv_ (u"ࠧ࠽ࡦ࡬ࡺࠥ࡯ࡤ࠾ࠤ࡬ࡸࡪࡳ࠭࡭࡫ࡶࡸࠧ࠭୙"), l1ll111llll11l1l11_nktv_)]
            if not ids:
                ids = [(a.start(), a.end()) for a in re.finditer(l1l11ll11l1l11_nktv_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡩࡵࡧࡰ࠱ࡱ࡯ࡳࡵࠢࡵࡳࡼࠨࠧ୚"), l1ll111llll11l1l11_nktv_)]
            ids.append( (-1,-1) )
            if len(ids)>1: content = l1ll111llll11l1l11_nktv_[ ids[0][1]:ids[1][0] ]
    ids = [(a.start(), a.end()) for a in re.finditer(l1l11ll11l1l11_nktv_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡤࡱ࡯࠱ࡽࡹ࠭࡝ࡦࡾ࠵ࢂࠦࡣࡰ࡮࠰ࡷࡲ࠳࡜ࡥࡽ࠴ࢁࡠࡤࠢ࡞ࠬࠥࡂࠬ୛"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l111l1llll11l1l11_nktv_ = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࠫࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࠬ࠭ଡ଼")).search(l111l1llll11l1l11_nktv_)
        title = re.compile(l1l11ll11l1l11_nktv_ (u"ࠫࠬ࠭ࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠧࠨଢ଼"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        l1llll11lll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠬ࠭ࠧࡥࡣࡷࡥ࠲ࡩ࡯࡯ࡶࡨࡲࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧࠨࠩ୞")).search(l111l1llll11l1l11_nktv_)
        l1lll1lllll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"࠭ࠧࠨ࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࠬ࠭ୟ")).search(l111l1llll11l1l11_nktv_)
        year =  re.compile(l1l11ll11l1l11_nktv_ (u"ࠧࠨࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡺࡧࡤࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ࠧࠨୠ")).search(l111l1llll11l1l11_nktv_)
        l1l11ll1lll11l1l11_nktv_ =  re.compile(l1l11ll11l1l11_nktv_ (u"ࠨࠩࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡴࡤࡸࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧࠨࠩୡ")).search(l111l1llll11l1l11_nktv_)
        if href and title:
            l1lll1lllll11l1l11_nktv_ = l1lll1lllll11l1l11_nktv_.group(1) if l1lll1lllll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠩࠪୢ")
            l1lll1lllll11l1l11_nktv_ = _1l11ll11ll11l1l11_nktv_(l1lll1lllll11l1l11_nktv_)
            l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠪ࡬ࡷ࡫ࡦࠨୣ")   : _1l11ll11ll11l1l11_nktv_(href.group(1)),
                l1l11ll11l1l11_nktv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ୤")  : l1lll1ll1ll11l1l11_nktv_(title.group(1)),
                l1l11ll11l1l11_nktv_ (u"ࠬࡶ࡬ࡰࡶࠪ୥")   : l1lll1ll1ll11l1l11_nktv_(l1llll11lll11l1l11_nktv_.group(1)) if l1llll11lll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"࠭ࠧ୦"),
                l1l11ll11l1l11_nktv_ (u"ࠧࡪ࡯ࡪࠫ୧")    : l1lll1lllll11l1l11_nktv_,
                l1l11ll11l1l11_nktv_ (u"ࠨࡴࡤࡸ࡮ࡴࡧࠨ୨") : l1l11ll1lll11l1l11_nktv_.group(1) if l1l11ll1lll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠩࠪ୩"),
                l1l11ll11l1l11_nktv_ (u"ࠪࡽࡪࡧࡲࠨ୪")   : year.group(1) if year else l1l11ll11l1l11_nktv_ (u"ࠫࠬ୫"),
                    }
            out.append(l11111llll11l1l11_nktv_)
    l1ll1ll11ll11l1l11_nktv_ = l1l11llll11l1l11_nktv_+1 if  content.find(l1l11ll11l1l11_nktv_ (u"ࠬࡶࡡࡨࡧࡀࠩࡩ࠭୬") %(l1l11llll11l1l11_nktv_+1))>-1 else False
    l11111l1ll11l1l11_nktv_ = l1l11llll11l1l11_nktv_-1 if l1l11llll11l1l11_nktv_>1 else False
    return (out, (l11111l1ll11l1l11_nktv_,l1ll1ll11ll11l1l11_nktv_))
def l11llllllll11l1l11_nktv_(url):
    content = l1lll11l1ll11l1l11_nktv_(url)
    l111l1llll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"࠭ࠧࠨ࠾ࡸࡰࠥ࡯ࡤ࠾ࠤࡶࡩࡷ࡯ࡥࡴ࠯࡯࡭ࡸࡺࠢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡨ࡬ࡰࡹ࡫ࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ࠧࠨ୭"),re.DOTALL).findall(content)
    out=[]
    if l111l1llll11l1l11_nktv_:
        l1l1111llll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠧࠨࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࠬ࠭ࠧ୮"),re.MULTILINE).findall(l111l1llll11l1l11_nktv_[0])
        for href,title in l1l1111llll11l1l11_nktv_:
            l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠨࡪࡵࡩ࡫࠭୯")   : _1l11ll11ll11l1l11_nktv_(href),
                l1l11ll11l1l11_nktv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ୰")  : l1lll1ll1ll11l1l11_nktv_(title),
                l1l11ll11l1l11_nktv_ (u"ࠪࡴࡱࡵࡴࠨୱ")   : l1l11ll11l1l11_nktv_ (u"ࠫࠬ୲"),
                    }
            out.append(l11111llll11l1l11_nktv_)
    return out
def _1l11ll11ll11l1l11_nktv_(href):
    url = href.replace(l1l11ll11l1l11_nktv_ (u"ࠬ࠵ࡢࡳࡱࡺࡷࡪ࠴ࡰࡩࡲࡂࡹࡂ࠭୳"),l1l11ll11l1l11_nktv_ (u"࠭ࠧ୴"))
    url = url.split(l1l11ll11l1l11_nktv_ (u"ࠧࠧࡣࡰࡴࡀ࠭୵"))[0]
    return urllib.unquote(url)
url=l1l11ll11l1l11_nktv_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦࡨࡦࡾ࠮ࡵࡸ࠲࡬ࡺ࡭࡯࠮࡫࠰ࡰࡴࡽࡣࡺ࠯ࡧࡹࡨ࡮࡯ࡸࠩ୶")
def l1l1lllll11l1l11_nktv_(url):
    content = l1lll11l1ll11l1l11_nktv_(url)
    out=[]
    l1l11l1llll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠩࠪࠫࡁࡺࡢࡰࡦࡼࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡨ࡯ࡥࡻࡁࠫࠬ࠭୷"),re.DOTALL).findall(content)
    for l1l11l111ll11l1l11_nktv_ in l1l11l1llll11l1l11_nktv_:
        l11lll11lll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࠫࠬࡂࡴࡳࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡵࡂࠬ࠭ࠧ୸"),re.DOTALL).findall(l1l11l111ll11l1l11_nktv_)
        for l1lllll11l1l11_nktv_ in l11lll11lll11l1l11_nktv_:
            l11llll1lll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠫࠬ࠭࠼ࡵࡦࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡨࡃ࠭ࠧࠨ୹"),re.DOTALL).findall(l1lllll11l1l11_nktv_)
            host = re.compile(l1l11ll11l1l11_nktv_ (u"ࠬ࠭ࠧࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࠭ࠧ୺")).findall(l11llll1lll11l1l11_nktv_[0]) if len(l11llll1lll11l1l11_nktv_)>1 else l1l11ll11l1l11_nktv_ (u"࠭ࠧ୻")
            version = l11llll1lll11l1l11_nktv_[1].strip(l1l11ll11l1l11_nktv_ (u"ࠧ࠽ࡀࠪ୼")) if len(l11llll1lll11l1l11_nktv_)>2 else l1l11ll11l1l11_nktv_ (u"ࠨࠩ୽")
            quality = l11llll1lll11l1l11_nktv_[2].strip(l1l11ll11l1l11_nktv_ (u"ࠩ࠿ࡂࠬ୾")) if len(l11llll1lll11l1l11_nktv_)>3 else l1l11ll11l1l11_nktv_ (u"ࠪࠫ୿")
            href = re.compile(l1l11ll11l1l11_nktv_ (u"ࠫࠬ࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࠭ࠧ஀")).findall(l11llll1lll11l1l11_nktv_[3])if len(l11llll1lll11l1l11_nktv_)>4 else l1l11ll11l1l11_nktv_ (u"ࠬ࠭஁")
            if href:
                href=href[0]
                href = urllib.unquote(_1l11ll11ll11l1l11_nktv_(href))
                if l1l11ll11l1l11_nktv_ (u"࠭࡬ࡪࡰ࡮࡭࠳ࡵ࡮࡭࡫ࡱࡩࠬஂ") in href:
                    data = l1lll11l1ll11l1l11_nktv_(href)
                    l1ll11lllll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠧࠨࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠫ࠲࠯ࡅࠩ࠽࠱࡬ࡪࡷࡧ࡭ࡦࡀࠪࠫࠬஃ"),re.DOTALL).findall(data)
                    if l1ll11lllll11l1l11_nktv_:
                        src = re.compile(l1l11ll11l1l11_nktv_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭஄")).findall(l1ll11lllll11l1l11_nktv_[0])
                        href = src[0] if src else href
                href = urllib.unquote(_1l11ll11ll11l1l11_nktv_(href))
                host = host[0] if host else l1l11ll11l1l11_nktv_ (u"ࠩࠪஅ")
                l1l111lllll11l1l11_nktv_ = urlparse(href).netloc
                l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠪࡹࡷࡲࠧஆ") : urllib.unquote(href),
                    l1l11ll11l1l11_nktv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪஇ"): l1l11ll11l1l11_nktv_ (u"ࠧࡡࠥࡴ࡟ࠣࠩࡸ࠲ࠠࠦࡵࠥஈ") %(host,version,quality),
                    l1l11ll11l1l11_nktv_ (u"࠭ࡨࡰࡵࡷࠫஉ"): host }
                out.append(l11111llll11l1l11_nktv_)
    return out
def l1111l1ll11l1l11_nktv_(url):
    content = l1lll11l1ll11l1l11_nktv_(url)
    l1l1111l1ll11l1l11_nktv_ = l1lll1l1lll11l1l11_nktv_.l1ll1l1llll11l1l11_nktv_(l11ll1ll11l1l11_nktv_)
    l11lllll1ll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠢࡽࡅࡲࡳࡰ࡯ࡥ࠾ࠧࡶ࡚ࠪࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠧࡶࠦஊ") % (l1l1111l1ll11l1l11_nktv_, l1ll11ll1ll11l1l11_nktv_)
    l1l11lll1ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠨࠩࠪࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠧࠨ஋")).findall(content)
    l1lll1lllll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠩࠪ஌")
    for l1l11llllll11l1l11_nktv_ in l1l11lll1ll11l1l11_nktv_:
        if l1l11ll11l1l11_nktv_ (u"ࠪ࠲࡯ࡶࡧࠨ஍") in l1l11llllll11l1l11_nktv_:
            l1lll1lllll11l1l11_nktv_ = _1l11ll11ll11l1l11_nktv_(l1l11llllll11l1l11_nktv_)
            break
    l1lll1lllll11l1l11_nktv_ = l1lll1lllll11l1l11_nktv_ + l11lllll1ll11l1l11_nktv_
    ids = [(a.start(), a.end()) for a in re.finditer(l1l11ll11l1l11_nktv_ (u"ࠫࠬ࠭࠼ࡥ࡫ࡹࠤ࡮ࡪ࠽ࠣࡵࡨࡥࡸࡵ࡮࠮࡞ࡧ࠯ࠬ࠭ࠧஎ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l111l1llll11l1l11_nktv_ = content[ ids[i][1]:ids[i+1][0] ]
        l1l11l1l1ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠬ࠭ࠧ࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡪ࠾࡝ࡵ࠭ࡀࡹࡪ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡦࡁࡠࡸ࠰࠼ࡵࡦࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࠭ࠧஏ"),re.DOTALL).findall(l111l1llll11l1l11_nktv_)
        for l1l11111lll11l1l11_nktv_,title,href in l1l11l1l1ll11l1l11_nktv_:
            title = title.replace(l1l11ll11l1l11_nktv_ (u"࠭࡜࡯ࠩஐ"),l1l11ll11l1l11_nktv_ (u"ࠧࠡࠩ஑"))
            title = re.sub(l1l11ll11l1l11_nktv_ (u"ࡳࠩࠪࠫࠫ࠴ࠪ࠼ࠩࠪࠫஒ"),l1l11ll11l1l11_nktv_ (u"ࠩࠪஓ"),title)
            l1ll11l11ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࠫࠬࡹࠨ࡝ࡦ࠮ࡃ࠮࡫ࠨ࡝ࡦ࠮ࡃ࠮࠭ࠧࠨஔ")).findall(l1l11111lll11l1l11_nktv_)
            if l1l11ll11l1l11_nktv_ (u"ࠫࡸ࡫ࡲࡪࡣ࡯ࡩࠬக") in href:
                l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠬ࡮ࡲࡦࡨࠪ஖")  : _1l11ll11ll11l1l11_nktv_(href),
                    l1l11ll11l1l11_nktv_ (u"࠭ࡰ࡭ࡱࡷࠫ஗"): l1l11ll11l1l11_nktv_ (u"ࠧࠨ஘"),
                    l1l11ll11l1l11_nktv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧங") : l1l11ll11l1l11_nktv_ (u"ࠩࠨࡷࠥࠫࡳࠨச")%(l1l11111lll11l1l11_nktv_,l1lll1ll1ll11l1l11_nktv_(title.strip())),
                    l1l11ll11l1l11_nktv_ (u"ࠪ࡭ࡲ࡭ࠧ஛"):l1lll1lllll11l1l11_nktv_,
                    l1l11ll11l1l11_nktv_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࠫஜ"): int(l1ll11l11ll11l1l11_nktv_[0][0]) if l1ll11l11ll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠬ࠭஝"),
                    l1l11ll11l1l11_nktv_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࠧஞ"): int(l1ll11l11ll11l1l11_nktv_[0][1]) if l1ll11l11ll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠧࠨட"),
                    }
                out.append(l11111llll11l1l11_nktv_)
    return out
def l1lllll1lll11l1l11_nktv_(m):
    return l1l11ll11l1l11_nktv_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠨ஠")+urllib.unquote(m.group(1))
def l1l11ll1ll11l1l11_nktv_(l1l111l1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠩࡩ࡭ࡱࡳࠧ஡"),l11ll1llll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ஢")):
    content = l1lll11l1ll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡩࡤࡢࡺ࠱ࡸࡻ࠵ࡦࡪ࡮ࡰࡽ࠲ࡵ࡮࡭࡫ࡱࡩ࠴࠭ண"))
    selected = []
    if l1l111l1ll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠬ࡬ࡩ࡭࡯ࠪத"):
        if l11ll1llll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ஥"):
            l111l1llll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠧࠨࠩ࠿ࡹࡱࠦࡩࡥ࠿ࠥࡪ࡮ࡲࡴࡦࡴ࠰ࡧࡦࡺࡥࡨࡱࡵࡽࠧࠦࡣ࡭ࡣࡶࡷࡂࠨࡦࡪ࡮ࡷࡩࡷࠦ࡭ࡶ࡮ࡷ࡭ࡵࡲࡥ࠮ࡵࡨࡰࡪࡩࡴࠡࡶࡨࡶࡲ࠳࡬ࡪࡵࡷࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩࠪࠫ஦"),re.DOTALL).findall(content)[0]
            selected = re.compile(l1l11ll11l1l11_nktv_ (u"ࠨࠩࠪࡀࡱ࡯ࠠࡥࡣࡷࡥ࠲࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࡝ࡡࡂࡢ࠰࠾࡝ࡵ࠭ࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠴ࠪࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠪࠫࠬ஧"),re.MULTILINE).findall(l111l1llll11l1l11_nktv_)
        elif l11ll1llll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠩࡼࡩࡦࡸࠧந"):
            l111l1llll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࠫࠬࡂࡵ࡭ࠢ࡬ࡨࡂࠨࡦࡪ࡮ࡷࡩࡷ࠳ࡹࡦࡣࡵࠦࠥࡩ࡬ࡢࡵࡶࡁࠧ࡬ࡩ࡭ࡶࡨࡶࠥࡳࡵ࡭ࡶ࡬ࡴࡱ࡫࠭ࡴࡧ࡯ࡩࡨࡺࠠࡵࡧࡵࡱ࠲ࡲࡩࡴࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨࠩࠪன"),re.DOTALL).findall(content)[0]
            selected = re.compile(l1l11ll11l1l11_nktv_ (u"ࠫࠬ࠭࠼࡭࡫ࠣࡨࡦࡺࡡ࠮࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦࡠࡤ࠾࡞ࠬࡁࡠࡸ࠰࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣ࠰࠭ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃ࠭ࠧࠨப"),re.MULTILINE).findall(l111l1llll11l1l11_nktv_)
        elif l11ll1llll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭஫"):
            l111l1llll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"࠭ࠧࠨ࠾ࡸࡰࠥ࡯ࡤ࠾ࠤࡩ࡭ࡱࡺࡥࡳ࠯ࡦࡳࡺࡴࡴࡳࡻࠥࠤࡨࡲࡡࡴࡵࡀࠦ࡫࡯࡬ࡵࡧࡵࠤࡲࡻ࡬ࡵ࡫ࡳࡰࡪ࠳ࡳࡦ࡮ࡨࡧࡹࠦࡴࡦࡴࡰ࠱ࡱ࡯ࡳࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧࠨࠩ஬"),re.DOTALL).findall(content)[0]
            selected = re.compile(l1l11ll11l1l11_nktv_ (u"ࠧࠨࠩ࠿ࡰ࡮ࠦࡤࡢࡶࡤ࠱࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࡜ࡠࡁࡡ࠯ࡄ࡜ࡴࠬ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠳࠰ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠩࠪࠫ஭"),re.MULTILINE).findall(l111l1llll11l1l11_nktv_)
    elif l1l111l1ll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠨࡵࡨࡶ࡮ࡧ࡬ࠨம"):
        if l11ll1llll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠩࡪࡥࡹࡻ࡮ࡦ࡭ࠪய"):
            selected = re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࠫࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵࡡࡳ࡞࠼࠲࠳ࡨࡪࡡ࠮ࡱࡱࡰ࡮ࡴࡥ࠯ࡲ࡯࠳ࡸ࡫ࡲࡪࡣ࡯ࡩ࠲࡭ࡡࡵࡷࡱࡩࡰ࠵࠮ࠫࡁࠬࠦࡠࡢࡴ࡝ࡰࠣࡡ࠯ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩࠪࠫர")).findall(content)
        elif l11ll1llll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠫࡷࡵ࡫ࠨற"):
            selected = re.compile(l1l11ll11l1l11_nktv_ (u"ࠬ࠭ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࡜ࡵࡠ࠾࠴࠵ࡣࡥࡣ࠰ࡳࡳࡲࡩ࡯ࡧ࠱ࡴࡱ࠵ࡳࡦࡴ࡬ࡥࡱ࡫࠭ࡳࡱ࡮࠳ࡡࡪࡻ࠵ࡿ࠲࠭ࠧࡄࠨ࡝ࡦࡾ࠸ࢂ࠯࠼࠰ࡣࡁࠫࠬ࠭ல")).findall(content)
    if selected:
        l1lll1l11ll11l1l11_nktv_ = [x[0] for x in selected]
        l1ll11l1lll11l1l11_nktv_ = [l1l11ll11l1l11_nktv_ (u"࠭ࠠࠨள").join(x[1:]) for x in selected]
        return (l1ll11l1lll11l1l11_nktv_,l1lll1l11ll11l1l11_nktv_)
    return False
def search(l1llll1llll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠧࡢ࡭ࡤࡨࡪࡳࡩࡢࠢࡳࡥࡳࡧࠧழ")):
    url=l1l11ll11l1l11_nktv_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦࡨࡦࡾ࠮ࡵࡸ࠲ࡷࡿࡻ࡫ࡢ࡬ࠪவ")
    content = l1lll11l1ll11l1l11_nktv_(url,data=l1l11ll11l1l11_nktv_ (u"ࠩࡳ࡬ࡷࡧࡳࡦ࠿ࠪஶ")+l1llll1llll11l1l11_nktv_)
    l1l1111l1ll11l1l11_nktv_ = l1lll1l1lll11l1l11_nktv_.l1ll1l1llll11l1l11_nktv_(l11ll1ll11l1l11_nktv_)
    l11lllll1ll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠥࢀࡈࡵ࡯࡬࡫ࡨࡁࠪࡹࠦࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠪࡹࠢஷ") % (l1l1111l1ll11l1l11_nktv_, l1ll11ll1ll11l1l11_nktv_)
    ids = [(a.start(), a.end()) for a in re.finditer(l1l11ll11l1l11_nktv_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳ࡸࡴ࠯࡟ࡨࢀ࠷ࡽ࡜ࡠࠥࡡ࠯ࠨ࠾ࠨஸ"), content)]
    ids.append( (-1,-1) )
    l1l111ll1ll11l1l11_nktv_=[]
    l1l11l11lll11l1l11_nktv_=[]
    for i in range(len(ids[:-1])):
        l111l1llll11l1l11_nktv_ = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile(l1l11ll11l1l11_nktv_ (u"ࠬ࠭ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠧࠨஹ")).search(l111l1llll11l1l11_nktv_)
        title = re.compile(l1l11ll11l1l11_nktv_ (u"࠭ࠧࠨࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࠩࠪ஺"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        l1llll11lll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠧࠨࠩࡧࡥࡹࡧ࠭ࡤࡱࡱࡸࡪࡴࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࠪࠫ஻")).search(l111l1llll11l1l11_nktv_)
        l1lll1lllll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠨࠩࠪࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠧࠨ஼")).search(l111l1llll11l1l11_nktv_)
        year =  re.compile(l1l11ll11l1l11_nktv_ (u"ࠩࠪࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡼࡩࡦࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨࠩࠪ஽")).search(l111l1llll11l1l11_nktv_)
        l1l11ll1lll11l1l11_nktv_ =  re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࠫࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡶࡦࡺࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩࠪࠫா")).search(l111l1llll11l1l11_nktv_)
        if href and title:
            l1lll1lllll11l1l11_nktv_ = l1lll1lllll11l1l11_nktv_.group(1) if l1lll1lllll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠫࠬி")
            l1lll1lllll11l1l11_nktv_ = l1lll1lllll11l1l11_nktv_ + l11lllll1ll11l1l11_nktv_
            l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠬ࡮ࡲࡦࡨࠪீ")   : href.group(1),
                l1l11ll11l1l11_nktv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬு")  : l1lll1ll1ll11l1l11_nktv_(title.group(1)),
                l1l11ll11l1l11_nktv_ (u"ࠧࡱ࡮ࡲࡸࠬூ")   : l1lll1ll1ll11l1l11_nktv_(l1llll11lll11l1l11_nktv_.group(1)) if l1llll11lll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠨࠩ௃"),
                l1l11ll11l1l11_nktv_ (u"ࠩ࡬ࡱ࡬࠭௄")    : l1lll1lllll11l1l11_nktv_,
                l1l11ll11l1l11_nktv_ (u"ࠪࡶࡦࡺࡩ࡯ࡩࠪ௅") : l1l11ll1lll11l1l11_nktv_.group(1) if l1l11ll1lll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠫࠬெ"),
                l1l11ll11l1l11_nktv_ (u"ࠬࡿࡥࡢࡴࠪே")   : year.group(1) if year else l1l11ll11l1l11_nktv_ (u"࠭ࠧை"),
                    }
            if l1l11ll11l1l11_nktv_ (u"ࠧ࠰ࡵࡨࡶ࡮ࡧ࡬ࡦ࠱ࠪ௉") in l11111llll11l1l11_nktv_[l1l11ll11l1l11_nktv_ (u"ࠨࡪࡵࡩ࡫࠭ொ")]:
                l1l11l11lll11l1l11_nktv_.append(l11111llll11l1l11_nktv_)
            else:
                l1l111ll1ll11l1l11_nktv_.append(l11111llll11l1l11_nktv_)
    return l1l111ll1ll11l1l11_nktv_,l1l11l11lll11l1l11_nktv_
def search(l1llll1llll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠩࡧࡳࡱ࡯࡮ࡢࠩோ")):
    l1l111l11ll11l1l11_nktv_ = {
        l1l11ll11l1l11_nktv_ (u"ࠪࡌࡴࡹࡴࠨௌ"):l1l11ll11l1l11_nktv_ (u"ࠫࡦࡶࡩ࠯ࡵࡨࡥࡷࡩࡨࡪࡳ࠱ࡼࡾࢀ்ࠧ"),
        l1l11ll11l1l11_nktv_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ௎"):l1l11ll11l1l11_nktv_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠹࠲࠶ࡁࠠࡘࡑ࡚࠺࠹ࡁࠠࡳࡸ࠽࠹࠷࠴࠰ࠪࠢࡊࡩࡨࡱ࡯࠰࠴࠳࠵࠵࠶࠱࠱࠳ࠣࡊ࡮ࡸࡥࡧࡱࡻ࠳࠺࠸࠮࠱ࠩ௏"),
        l1l11ll11l1l11_nktv_ (u"ࠧࡂࡥࡦࡩࡵࡺࠧௐ"):l1l11ll11l1l11_nktv_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱ࠰ࠥࡺࡥࡹࡶ࠲࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠬࠡࠬ࠲࠮ࡀࠦࡱ࠾࠲࠱࠴࠶࠭௑"),
        l1l11ll11l1l11_nktv_ (u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡏࡥࡳ࡭ࡵࡢࡩࡨࠫ௒"):l1l11ll11l1l11_nktv_ (u"ࠪࡩࡳ࠳ࡕࡔ࠮ࡨࡲࡀࡷ࠽࠱࠰࠸ࠫ௓"),
        l1l11ll11l1l11_nktv_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ௔"):l1l11ll11l1l11_nktv_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡥࡣࡻ࠲ࡹࡼ࠯ࡸࡻࡶࡾࡺࡱࡩࡸࡣࡵ࡯ࡦࡅࡰࡩࡴࡤࡷࡪࡃࡤࡰ࡯ࠪ௕"),
        l1l11ll11l1l11_nktv_ (u"࠭ࡏࡳ࡫ࡪ࡭ࡳ࠭௖"):l1l11ll11l1l11_nktv_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥࡧࡥࡽ࠴ࡴࡷࠩௗ"),
        l1l11ll11l1l11_nktv_ (u"ࠨࡅࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠬ௘"):l1l11ll11l1l11_nktv_ (u"ࠩ࡮ࡩࡪࡶ࠭ࡢ࡮࡬ࡺࡪ࠭௙"),
        l1l11ll11l1l11_nktv_ (u"ࠪࡔࡷࡧࡧ࡮ࡣࠪ௚"):l1l11ll11l1l11_nktv_ (u"ࠫࡳࡵ࠭ࡤࡣࡦ࡬ࡪ࠭௛")}
    url=l1l11ll11l1l11_nktv_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡱ࡫࠱ࡷࡪࡧࡲࡤࡪ࡬ࡵ࠳ࡾࡹࡻ࠱ࡤࡴ࡮࠵ࡳࡦࡣࡵࡧ࡭࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡲ࠿ࠨࡷࠫ࡫࡮ࡨ࡫ࡱࡩࡐ࡫ࡹ࠾࠵࠻࠹ࡨ࠶࠰ࡢࡨ࠴࠴࠻࠽࠶ࡢ࠵࠸࠻࠷ࡪ࠸࠹࠲࠸࠹ࡪ࠹࠲ࡤ࠶࠴ࡧ࠹ࠬࡰࡢࡩࡨࡁ࠵ࠬࡩࡵࡧࡰࡷࡕ࡫ࡲࡑࡣࡪࡩࡂ࠻࠰ࠧࡩࡵࡳࡺࡶ࠽࠲ࠩ௜")
    try:
        req = urllib2.Request(url%l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"࠭ࠠࠨ௝"),l1l11ll11l1l11_nktv_ (u"ࠧࠬࠩ௞")),data=None,headers=l1l111l11ll11l1l11_nktv_)
        response = urllib2.urlopen(req,timeout=10)
        dd = json.loads(response.read())
    except:
        dd={}
    data = dd.get(l1l11ll11l1l11_nktv_ (u"ࠨ࡯ࡤ࡭ࡳ࠭௟"),{}).get(l1l11ll11l1l11_nktv_ (u"ࠩࡵࡩࡨࡵࡲࡥࡵࠪ௠"),[])
    l1l111ll1ll11l1l11_nktv_=[]
    l1l11l11lll11l1l11_nktv_=[]
    for item in data:
        href = item.get(l1l11ll11l1l11_nktv_ (u"ࠪࡹࡷࡲࠧ௡"),l1l11ll11l1l11_nktv_ (u"ࠫࠬ௢"))
        title = item.get(l1l11ll11l1l11_nktv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ௣"),l1l11ll11l1l11_nktv_ (u"࠭ࠧ௤"))
        title = re.sub(l1l11ll11l1l11_nktv_ (u"ࡲࠨࠩࠪࡀࡠ࠵࡝ࠫࡧࡰࡂࠬ࠭ࠧ௥"),l1l11ll11l1l11_nktv_ (u"ࠨࠢࠪ௦"),title)
        l1llll11lll11l1l11_nktv_ = item.get(l1l11ll11l1l11_nktv_ (u"ࠩࡥࡳࡩࡿࠧ௧"),l1l11ll11l1l11_nktv_ (u"ࠪࠫ௨"))
        if href and title:
            year = re.search(l1l11ll11l1l11_nktv_ (u"ࠫࡡࡪࡻ࠵ࡿࠪ௩"),title)
        l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠬ࡮ࡲࡦࡨࠪ௪") : href,
            l1l11ll11l1l11_nktv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ௫") : l1lll1ll1ll11l1l11_nktv_(title),
            l1l11ll11l1l11_nktv_ (u"ࠧࡱ࡮ࡲࡸࠬ௬") : l1lll1ll1ll11l1l11_nktv_(l1llll11lll11l1l11_nktv_) if l1llll11lll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠨࠩ௭"),
            l1l11ll11l1l11_nktv_ (u"ࠩ࡬ࡱ࡬࠭௮") : l1l11ll11l1l11_nktv_ (u"ࠪࠫ௯"),
            l1l11ll11l1l11_nktv_ (u"ࠫࡾ࡫ࡡࡳࠩ௰") : year.group() if year else l1l11ll11l1l11_nktv_ (u"ࠬ࠭௱"),
                }
        if l1l11ll11l1l11_nktv_ (u"࠭࠯ࡴࡧࡵ࡭ࡦࡲࡥ࠰ࠩ௲") in l11111llll11l1l11_nktv_[l1l11ll11l1l11_nktv_ (u"ࠧࡩࡴࡨࡪࠬ௳")]:
            l1l11l11lll11l1l11_nktv_.append(l11111llll11l1l11_nktv_)
        else:
            l1l111ll1ll11l1l11_nktv_.append(l11111llll11l1l11_nktv_)
    return l1l111ll1ll11l1l11_nktv_,l1l11l11lll11l1l11_nktv_
def l1lll1ll1ll11l1l11_nktv_(l1llll1llll11l1l11_nktv_):
    return l1llll1llll11l1l11_nktv_
