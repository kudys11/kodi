# -*- coding: utf-8 -*-
import sys
l1111ll11l1l11_nktv_ = sys.version_info [0] == 2
l111ll11l1l11_nktv_ = 2048
l1l1lll11l1l11_nktv_ = 7
def l1l11ll11l1l11_nktv_ (keyedStringLiteral):
	global l11llll11l1l11_nktv_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1111ll11l1l11_nktv_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
l1l11ll11l1l11_nktv_ (u"ࠦࠧࠨࠍࠋࡅࡵࡩࡦࡺࡥࡥࠢࡲࡲ࡚ࠥࡨࡶࠢࡉࡩࡧࠦ࠱࠲ࠢ࠴࠼࠿࠺࠷࠻࠶࠶ࠤ࠷࠶࠱࠷ࠏࠍࠑࠏࡆࡡࡶࡶ࡫ࡳࡷࡀࠠࡳࡣࡰ࡭ࡨࠓࠊࠣࠤࠥ੶")
import urllib2
import re
import l1ll11111ll11l1l11_nktv_ as l1ll11111ll11l1l11_nktv_
l1ll1l11lll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡦࡨࡦ࠴ࡰ࡭ࠩ੷")
l1111lllll11l1l11_nktv_ = 5
def l1lll11l1ll11l1l11_nktv_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l1l11ll11l1l11_nktv_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ੸"), l1l11ll11l1l11_nktv_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠴࠹࠰࠳࠲࠷࠻࠶࠵࠰࠼࠻࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬ੹"))
    if cookies:
        req.add_header(l1l11ll11l1l11_nktv_ (u"ࠣࡅࡲࡳࡰ࡯ࡥࠣ੺"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l1111lllll11l1l11_nktv_)
        l1ll11l1ll11l1l11_nktv_ =  response.read()
        response.close()
    except:
        l1ll11l1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠩࠪ੻")
    return l1ll11l1ll11l1l11_nktv_
def _1ll111l1ll11l1l11_nktv_(content):
    src =l1l11ll11l1l11_nktv_ (u"ࠪࠫ੼")
    l1l1ll1l1ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠦࡪࡼࡡ࡭ࠪ࠱࠮ࡄ࠯࡜ࡼ࡞ࢀࡠ࠮ࡢࠩࠣ੽"),re.DOTALL).findall(content)
    for l1l1ll11lll11l1l11_nktv_ in l1l1ll1l1ll11l1l11_nktv_:
        l1l1ll11lll11l1l11_nktv_=re.sub(l1l11ll11l1l11_nktv_ (u"ࠬࠦࠠࠨ੾"),l1l11ll11l1l11_nktv_ (u"࠭ࠠࠨ੿"),l1l1ll11lll11l1l11_nktv_)
        l1l1ll11lll11l1l11_nktv_=re.sub(l1l11ll11l1l11_nktv_ (u"ࠧ࡝ࡰࠪ઀"),l1l11ll11l1l11_nktv_ (u"ࠨࠩઁ"),l1l1ll11lll11l1l11_nktv_)
        try:
            l1l1llll1ll11l1l11_nktv_ = l1ll11111ll11l1l11_nktv_.unpack(l1l1ll11lll11l1l11_nktv_)
        except:
            l1l1llll1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠩࠪં")
        if l1l1llll1ll11l1l11_nktv_:
            l1l1llll1ll11l1l11_nktv_=re.sub(l1l11ll11l1l11_nktv_ (u"ࡵࠫࡡࡢࠧઃ"),l1l11ll11l1l11_nktv_ (u"ࡶࠬ࠭઄"),l1l1llll1ll11l1l11_nktv_)
            l1l1ll1llll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠬ࡬ࡩ࡭ࡧ࠽ࡠࡸ࠰࡛࡝ࠩࠥࡡ࠭࠴ࠫࡀࠫ࡞ࡠࠬࠨ࡝࠭ࠩઅ"),  re.DOTALL).search(l1l1llll1ll11l1l11_nktv_)
            l1l1lll1lll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"࠭ࡵࡳ࡮࠽ࡠࡸ࠰࡛࡝ࠩࠥࡡ࠭࠴ࠫࡀࠫ࡞ࡠࠬࠨ࡝࠭ࠩઆ"),  re.DOTALL).search(l1l1llll1ll11l1l11_nktv_)
            if l1l1ll1llll11l1l11_nktv_:
                src = l1l1ll1llll11l1l11_nktv_.group(1)
            elif l1l1lll1lll11l1l11_nktv_:
                src = l1l1lll1lll11l1l11_nktv_.group(1)
            if src:
                break
    return src
def _1l1lll11ll11l1l11_nktv_(content):
    src=l1l11ll11l1l11_nktv_ (u"ࠧࠨઇ")
    l1l1l11llll11l1l11_nktv_ = content.find(l1l11ll11l1l11_nktv_ (u"ࠨࡾࡿࢀ࡭ࡺࡴࡱࠩઈ"))
    if l1l1l11llll11l1l11_nktv_>0:
        l1l1l1l1lll11l1l11_nktv_ = content.find(l1l11ll11l1l11_nktv_ (u"ࠩ࠱ࡷࡵࡲࡩࡵࠩઉ"),l1l1l11llll11l1l11_nktv_)
        encoded =content[l1l1l11llll11l1l11_nktv_:l1l1l1l1lll11l1l11_nktv_]
        if encoded:
            l1ll111llll11l1l11_nktv_ = encoded.split(l1l11ll11l1l11_nktv_ (u"ࠪࡴࡱࡧࡹࡦࡴࠪઊ"))[0]
            l1ll111llll11l1l11_nktv_=re.sub(l1l11ll11l1l11_nktv_ (u"ࡶࠬࡡࡼ࡞࠭࡟ࡻࢀ࠸ࠬ࠴ࡿ࡞ࢀࡢ࠱ࠧઋ"),l1l11ll11l1l11_nktv_ (u"ࠬࢂࠧઌ"),l1ll111llll11l1l11_nktv_,re.DOTALL)
            l1ll111llll11l1l11_nktv_=re.sub(l1l11ll11l1l11_nktv_ (u"ࡸࠧ࡜ࡾࡠ࠯ࡡࡽࡻ࠳࠮࠶ࢁࡠࢂ࡝ࠬࠩઍ"),l1l11ll11l1l11_nktv_ (u"ࠧࡽࠩ઎"),l1ll111llll11l1l11_nktv_,re.DOTALL)
            l1l1l111lll11l1l11_nktv_=[l1l11ll11l1l11_nktv_ (u"ࠨࡪࡷࡸࡵ࠭એ"),l1l11ll11l1l11_nktv_ (u"ࠩࡦࡨࡦ࠭ઐ"),l1l11ll11l1l11_nktv_ (u"ࠪࡴࡱ࠭ઑ"),l1l11ll11l1l11_nktv_ (u"ࠫࡱࡵࡧࡰࠩ઒"),l1l11ll11l1l11_nktv_ (u"ࠬࡽࡩࡥࡶ࡫ࠫઓ"),l1l11ll11l1l11_nktv_ (u"࠭ࡨࡦ࡫ࡪ࡬ࡹ࠭ઔ"),l1l11ll11l1l11_nktv_ (u"ࠧࡵࡴࡸࡩࠬક"),l1l11ll11l1l11_nktv_ (u"ࠨࡵࡷࡥࡹ࡯ࡣࠨખ"),l1l11ll11l1l11_nktv_ (u"ࠩࡶࡸࠬગ"),l1l11ll11l1l11_nktv_ (u"ࠪࡱࡵ࠺ࠧઘ"),l1l11ll11l1l11_nktv_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪઙ"),l1l11ll11l1l11_nktv_ (u"ࠬࡼࡩࡥࡧࡲࠫચ"),l1l11ll11l1l11_nktv_ (u"࠭ࡳࡵࡣࡷ࡭ࡨ࠭છ"),
                    l1l11ll11l1l11_nktv_ (u"ࠧࡵࡻࡳࡩࠬજ"),l1l11ll11l1l11_nktv_ (u"ࠨࡵࡺࡪࠬઝ"),l1l11ll11l1l11_nktv_ (u"ࠩࡳࡰࡦࡿࡥࡳࠩઞ"),l1l11ll11l1l11_nktv_ (u"ࠪࡪ࡮ࡲࡥࠨટ"),l1l11ll11l1l11_nktv_ (u"ࠫࡨࡵ࡮ࡵࡴࡲࡰࡧࡧࡲࠨઠ"),l1l11ll11l1l11_nktv_ (u"ࠬࡧࡤࡴࠩડ"),l1l11ll11l1l11_nktv_ (u"࠭ࡣࡻࡣࡶࠫઢ"),l1l11ll11l1l11_nktv_ (u"ࠧࡱࡱࡶ࡭ࡹ࡯࡯࡯ࠩણ"),l1l11ll11l1l11_nktv_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪત"),l1l11ll11l1l11_nktv_ (u"ࠩࡥࡳࡹࡺ࡯࡮ࠩથ"),l1l11ll11l1l11_nktv_ (u"ࠪࡹࡸ࡫ࡲࡂࡩࡨࡲࡹ࠭દ"),
                    l1l11ll11l1l11_nktv_ (u"ࠫࡲࡧࡴࡤࡪࠪધ"),l1l11ll11l1l11_nktv_ (u"ࠬࡶ࡮ࡨࠩન"),l1l11ll11l1l11_nktv_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺ࡯ࡳࠩ઩"),l1l11ll11l1l11_nktv_ (u"ࠧࡪࡦࠪપ"), l1l11ll11l1l11_nktv_ (u"ࠨ࠵࠺ࠫફ"), l1l11ll11l1l11_nktv_ (u"ࠩࡵࡩ࡬࡯࡯࡯ࡵࠪબ"), l1l11ll11l1l11_nktv_ (u"ࠪ࠴࠾࠭ભ"), l1l11ll11l1l11_nktv_ (u"ࠫࡪࡴࡡࡣ࡮ࡨࡨࠬમ"), l1l11ll11l1l11_nktv_ (u"ࠬࡹࡲࡤࠩય"), l1l11ll11l1l11_nktv_ (u"࠭࡭ࡦࡦ࡬ࡥࠬર")]
            l1l1l111lll11l1l11_nktv_=[l1l11ll11l1l11_nktv_ (u"ࠧࡩࡶࡷࡴࠬ઱"), l1l11ll11l1l11_nktv_ (u"ࠨ࡮ࡲ࡫ࡴ࠭લ"), l1l11ll11l1l11_nktv_ (u"ࠩࡺ࡭ࡩࡺࡨࠨળ"), l1l11ll11l1l11_nktv_ (u"ࠪ࡬ࡪ࡯ࡧࡩࡶࠪ઴"), l1l11ll11l1l11_nktv_ (u"ࠫࡹࡸࡵࡦࠩવ"), l1l11ll11l1l11_nktv_ (u"ࠬࡹࡴࡢࡶ࡬ࡧࠬશ"), l1l11ll11l1l11_nktv_ (u"࠭ࡦࡢ࡮ࡶࡩࠬષ"), l1l11ll11l1l11_nktv_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭સ"), l1l11ll11l1l11_nktv_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲࠨહ"),
                l1l11ll11l1l11_nktv_ (u"ࠩࡩ࡭ࡱ࡫ࠧ઺"), l1l11ll11l1l11_nktv_ (u"ࠪࡸࡾࡶࡥࠨ઻"), l1l11ll11l1l11_nktv_ (u"ࠫࡷ࡫ࡧࡪࡱࡱࡷ઼ࠬ"), l1l11ll11l1l11_nktv_ (u"ࠬࡴ࡯࡯ࡧࠪઽ"), l1l11ll11l1l11_nktv_ (u"࠭ࡣࡻࡣࡶࠫા"), l1l11ll11l1l11_nktv_ (u"ࠧࡦࡰࡤࡦࡱ࡫ࡤࠨિ"), l1l11ll11l1l11_nktv_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪી"), l1l11ll11l1l11_nktv_ (u"ࠩࡦࡳࡳࡺࡲࡰ࡮ࡥࡥࡷ࠭ુ"), l1l11ll11l1l11_nktv_ (u"ࠪࡱࡦࡺࡣࡩࠩૂ"), l1l11ll11l1l11_nktv_ (u"ࠫࡧࡵࡴࡵࡱࡰࠫૃ"),
                l1l11ll11l1l11_nktv_ (u"ࠬࡩࡥ࡯ࡶࡨࡶࠬૄ"), l1l11ll11l1l11_nktv_ (u"࠭ࡰࡰࡵ࡬ࡸ࡮ࡵ࡮ࠨૅ"), l1l11ll11l1l11_nktv_ (u"ࠧࡶࡵࡨࡶࡆ࡭ࡥ࡯ࡶࠪ૆"), l1l11ll11l1l11_nktv_ (u"ࠨࡰࡤࡺ࡮࡭ࡡࡵࡱࡵࠫે"), l1l11ll11l1l11_nktv_ (u"ࠩࡦࡳࡳ࡬ࡩࡨࠩૈ"), l1l11ll11l1l11_nktv_ (u"ࠪ࡬ࡹࡳ࡬ࠨૉ"), l1l11ll11l1l11_nktv_ (u"ࠫ࡭ࡺ࡭࡭࠷ࠪ૊"), l1l11ll11l1l11_nktv_ (u"ࠬࡶࡲࡰࡸ࡬ࡨࡪࡸࠧો"), l1l11ll11l1l11_nktv_ (u"࠭ࡢ࡭ࡣࡦ࡯ࠬૌ"),
                l1l11ll11l1l11_nktv_ (u"ࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡅࡱ࡯ࡧ࡯્ࠩ"), l1l11ll11l1l11_nktv_ (u"ࠨࡥࡤࡲࡋ࡯ࡲࡦࡇࡹࡩࡳࡺࡁࡑࡋࡆࡥࡱࡲࡳࠨ૎"), l1l11ll11l1l11_nktv_ (u"ࠩࡸࡷࡪ࡜࠲ࡂࡒࡌࡇࡦࡲ࡬ࡴࠩ૏"), l1l11ll11l1l11_nktv_ (u"ࠪࡺࡪࡸࡴࡪࡥࡤࡰࡆࡲࡩࡨࡰࠪૐ"), l1l11ll11l1l11_nktv_ (u"ࠫࡹ࡯࡭ࡦࡵ࡯࡭ࡩ࡫ࡲࡵࡱࡲࡰࡹ࡯ࡰࡱ࡮ࡸ࡫࡮ࡴࠧ૑"),
                l1l11ll11l1l11_nktv_ (u"ࠬࡵࡶࡦࡴ࡯ࡥࡾࡹࠧ૒"), l1l11ll11l1l11_nktv_ (u"࠭ࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦࡆࡳࡱࡵࡲࠨ૓"), l1l11ll11l1l11_nktv_ (u"ࠧ࡮ࡣࡵ࡫࡮ࡴࡢࡰࡶࡷࡳࡲ࠭૔"), l1l11ll11l1l11_nktv_ (u"ࠨࡲ࡯ࡹ࡬࡯࡮ࡴࠩ૕"), l1l11ll11l1l11_nktv_ (u"ࠩ࡯࡭ࡳࡱࠧ૖"), l1l11ll11l1l11_nktv_ (u"ࠪࡷࡹࡸࡥࡵࡥ࡫࡭ࡳ࡭ࠧ૗"), l1l11ll11l1l11_nktv_ (u"ࠫࡺࡴࡩࡧࡱࡵࡱࠬ૘"), l1l11ll11l1l11_nktv_ (u"ࠬࡹࡴࡢࡶ࡬ࡧ࠶࠭૙"),
                l1l11ll11l1l11_nktv_ (u"࠭ࡳࡦࡶࡸࡴࠬ૚"), l1l11ll11l1l11_nktv_ (u"ࠧ࡫ࡹࡳࡰࡦࡿࡥࡳࠩ૛"), l1l11ll11l1l11_nktv_ (u"ࠨࡥ࡫ࡩࡨࡱࡆ࡭ࡣࡶ࡬ࠬ૜"), l1l11ll11l1l11_nktv_ (u"ࠩࡖࡱࡦࡸࡴࡕࡘࠪ૝"), l1l11ll11l1l11_nktv_ (u"ࠪࡺ࠵࠶࠱ࠨ૞"), l1l11ll11l1l11_nktv_ (u"ࠫࡨࡸࡥ࡮ࡧࠪ૟"), l1l11ll11l1l11_nktv_ (u"ࠬࡪ࡯ࡤ࡭ࠪૠ"), l1l11ll11l1l11_nktv_ (u"࠭ࡡࡶࡶࡲࡷࡹࡧࡲࡵࠩૡ"), l1l11ll11l1l11_nktv_ (u"ࠧࡪࡦ࡯ࡩ࡭࡯ࡤࡦࠩૢ"), l1l11ll11l1l11_nktv_ (u"ࠨ࡯ࡲࡨࡪࡹࠧૣ"),
               l1l11ll11l1l11_nktv_ (u"ࠩࡩࡰࡦࡹࡨࠨ૤"), l1l11ll11l1l11_nktv_ (u"ࠪࡳࡻ࡫ࡲࠨ૥"), l1l11ll11l1l11_nktv_ (u"ࠫࡱ࡫ࡦࡵࠩ૦"), l1l11ll11l1l11_nktv_ (u"ࠬ࡮ࡩࡥࡧࠪ૧"), l1l11ll11l1l11_nktv_ (u"࠭ࡰ࡭ࡣࡼࡩࡷ࠻ࠧ૨"), l1l11ll11l1l11_nktv_ (u"ࠧࡪ࡯ࡤ࡫ࡪ࠭૩"), l1l11ll11l1l11_nktv_ (u"ࠨࡍࡏࡍࡐࡔࡉࡋࠩ૪"), l1l11ll11l1l11_nktv_ (u"ࠩࡦࡳࡲࡶࡡ࡯࡫ࡲࡲࡸ࠭૫"), l1l11ll11l1l11_nktv_ (u"ࠪࡶࡪࡹࡴࡰࡴࡨࠫ૬"), l1l11ll11l1l11_nktv_ (u"ࠫࡨࡲࡩࡤ࡭ࡖ࡭࡬ࡴࠧ૭"),
                l1l11ll11l1l11_nktv_ (u"ࠬࡹࡣࡩࡧࡧࡹࡱ࡫ࠧ૮"), l1l11ll11l1l11_nktv_ (u"࠭࡟ࡤࡱࡸࡲࡹࡪ࡯ࡸࡰࡢࠫ૯"), l1l11ll11l1l11_nktv_ (u"ࠧࡤࡱࡸࡲࡹࡪ࡯ࡸࡰࠪ૰"), l1l11ll11l1l11_nktv_ (u"ࠨࡴࡨ࡫࡮ࡵ࡮ࠨ૱"), l1l11ll11l1l11_nktv_ (u"ࠩࡨࡰࡸ࡫ࠧ૲"), l1l11ll11l1l11_nktv_ (u"ࠪࡧࡴࡴࡴࡳࡱ࡯ࡷࠬ૳"), l1l11ll11l1l11_nktv_ (u"ࠫࡵࡸࡥ࡭ࡱࡤࡨࠬ૴"), l1l11ll11l1l11_nktv_ (u"ࠬࡵࡲࡺࡩ࡬ࡲࡦࡲ࡮ࡦࠩ૵"), l1l11ll11l1l11_nktv_ (u"࠭ࡳࡵࡻ࡯ࡩࠬ૶"),
                l1l11ll11l1l11_nktv_ (u"ࠧ࠷࠴࠳ࡴࡽ࠭૷"), l1l11ll11l1l11_nktv_ (u"ࠨ࠵࠻࠻ࡵࡾࠧ૸"), l1l11ll11l1l11_nktv_ (u"ࠩࡳࡳࡸࡺࡥࡳࠩૹ"), l1l11ll11l1l11_nktv_ (u"ࠪࡾࡳ࡯࡫࡯࡫ࡨࠫૺ"), l1l11ll11l1l11_nktv_ (u"ࠫࡸ࡫࡫ࡶࡰࡧࠫૻ"), l1l11ll11l1l11_nktv_ (u"ࠬࡹࡨࡰࡹࡄࡪࡹ࡫ࡲࡔࡧࡦࡳࡳࡪࡳࠨૼ"), l1l11ll11l1l11_nktv_ (u"࠭ࡩ࡮ࡣࡪࡩࡸ࠭૽"), l1l11ll11l1l11_nktv_ (u"ࠧࡓࡧ࡮ࡰࡦࡳࡡࠨ૾"), l1l11ll11l1l11_nktv_ (u"ࠨࡵ࡮࡭ࡵࡇࡤࠨ૿"),
                 l1l11ll11l1l11_nktv_ (u"ࠩ࡯ࡩࡻ࡫࡬ࡴࠩ଀"), l1l11ll11l1l11_nktv_ (u"ࠪࡴࡦࡪࡤࡪࡰࡪࠫଁ"), l1l11ll11l1l11_nktv_ (u"ࠫࡴࡶࡡࡤ࡫ࡷࡽࠬଂ"), l1l11ll11l1l11_nktv_ (u"ࠬࡪࡥࡣࡷࡪࠫଃ"), l1l11ll11l1l11_nktv_ (u"࠭ࡶࡪࡦࡨࡳ࠸࠭଄"), l1l11ll11l1l11_nktv_ (u"ࠧࡤ࡮ࡲࡷࡪ࠭ଅ"), l1l11ll11l1l11_nktv_ (u"ࠨࡵࡰࡥࡱࡲࡴࡦࡺࡷࠫଆ"), l1l11ll11l1l11_nktv_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪଇ"), l1l11ll11l1l11_nktv_ (u"ࠪࡧࡱࡧࡳࡴࠩଈ"), l1l11ll11l1l11_nktv_ (u"ࠫࡦࡲࡩࡨࡰࠪଉ"),
                  l1l11ll11l1l11_nktv_ (u"ࠬࡴ࡯ࡵ࡫ࡦࡩࠬଊ"), l1l11ll11l1l11_nktv_ (u"࠭࡭ࡦࡦ࡬ࡥࠬଋ")]
            for l11111llll11l1l11_nktv_ in l1l1l111lll11l1l11_nktv_:
                l1ll111llll11l1l11_nktv_=l1ll111llll11l1l11_nktv_.replace(l11111llll11l1l11_nktv_,l1l11ll11l1l11_nktv_ (u"ࠧࠨଌ"))
            cleanup=l1ll111llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠨࡾࠪ଍"),l1l11ll11l1l11_nktv_ (u"ࠩࠣࠫ଎")).split()
            out={l1l11ll11l1l11_nktv_ (u"ࠪࡷࡪࡸࡶࡦࡴࠪଏ"): l1l11ll11l1l11_nktv_ (u"ࠫࠬଐ"), l1l11ll11l1l11_nktv_ (u"ࠬ࡫ࠧ଑"): l1l11ll11l1l11_nktv_ (u"࠭ࠧ଒"), l1l11ll11l1l11_nktv_ (u"ࠧࡧ࡫࡯ࡩࠬଓ"): l1l11ll11l1l11_nktv_ (u"ࠨࠩଔ"), l1l11ll11l1l11_nktv_ (u"ࠩࡶࡸࠬକ"): l1l11ll11l1l11_nktv_ (u"ࠪࠫଖ")}
            if len(cleanup)==4:
                print l1l11ll11l1l11_nktv_ (u"ࠫࡑ࡫࡮ࡨࡶ࡫ࠤࡔࡑࠧଗ")
                for l11111llll11l1l11_nktv_ in cleanup:
                    if l11111llll11l1l11_nktv_.isdigit():
                        out[l1l11ll11l1l11_nktv_ (u"ࠬ࡫ࠧଘ")]=l11111llll11l1l11_nktv_
                    elif re.match(l1l11ll11l1l11_nktv_ (u"࡛࠭ࡢ࠯ࡽࡡࢀ࠸ࠬࡾ࡞ࡧࡿ࠸ࢃࠧଙ"),l11111llll11l1l11_nktv_) and len(l11111llll11l1l11_nktv_)<10:
                        out[l1l11ll11l1l11_nktv_ (u"ࠧࡴࡧࡵࡺࡪࡸࠧଚ")] = l11111llll11l1l11_nktv_
                    elif len(l11111llll11l1l11_nktv_)==22:
                        out[l1l11ll11l1l11_nktv_ (u"ࠨࡵࡷࠫଛ")] = l11111llll11l1l11_nktv_
                    else:
                        out[l1l11ll11l1l11_nktv_ (u"ࠩࡩ࡭ࡱ࡫ࠧଜ")] = l11111llll11l1l11_nktv_
                src=l1l11ll11l1l11_nktv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠩࡸ࠴ࡣࡥࡣ࠱ࡴࡱ࠵ࠥࡴ࠰ࡰࡴ࠹ࡅࡳࡵ࠿ࠨࡷࠫ࡫࠽ࠦࡵࠪଝ")%(out.get(l1l11ll11l1l11_nktv_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࠫଞ")),out.get(l1l11ll11l1l11_nktv_ (u"ࠬ࡬ࡩ࡭ࡧࠪଟ")),out.get(l1l11ll11l1l11_nktv_ (u"࠭ࡳࡵࠩଠ")),out.get(l1l11ll11l1l11_nktv_ (u"ࠧࡦࠩଡ")))
    return src
def l1ll1111lll11l1l11_nktv_(content):
    l1l11ll11l1l11_nktv_ (u"ࠣࠤࠥࠑࠏࠦࠠࠡࠢࡖࡧࡦࡴࡳࠡࡨࡲࡶࠥࡼࡩࡥࡧࡲࠤࡱ࡯࡮࡬ࠢ࡬ࡲࡨࡲࡵࡥࡧࡧࠤࡪࡴࡣࡰࡦࡨࡨࠥࡵ࡮ࡦࠏࠍࠤࠥࠦࠠࠣࠤࠥଢ")
    l1l1ll111ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠩࠪଣ")
    l1l1ll1llll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࡪ࡮ࡲࡥ࠻ࠢ࡞ࡠࠬࠨ࡝ࠩ࠰࠮ࡃ࠮ࡡ࡜ࠨࠤࡠ࠰ࠬତ"),  re.DOTALL).search(content)
    l1l1lll1lll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠫࡺࡸ࡬࠻ࠢ࡞ࡠࠬࠨ࡝ࠩ࠰࠮ࡃ࠮ࡡ࡜ࠨࠤࡠ࠰ࠬଥ"),  re.DOTALL).search(content)
    if l1l1ll1llll11l1l11_nktv_:
        print l1l11ll11l1l11_nktv_ (u"ࠬ࡬࡯ࡶࡰࡧࠤࡗࡋࠠ࡜ࡨ࡬ࡰࡪࡀ࡝ࠨଦ")
        l1l1ll111ll11l1l11_nktv_ = l1l1ll1llll11l1l11_nktv_.group(1)
    elif l1l1lll1lll11l1l11_nktv_:
        print l1l11ll11l1l11_nktv_ (u"࠭ࡦࡰࡷࡱࡨࠥࡘࡅࠡ࡝ࡸࡶࡱࡀ࡝ࠨଧ")
        l1l1ll111ll11l1l11_nktv_ = l1l1lll1lll11l1l11_nktv_.group(1)
    else:
        print l1l11ll11l1l11_nktv_ (u"ࠧࡦࡰࡦࡳࡩ࡫ࡤࠡ࠼ࠣࡹࡳࡶࡡࡤ࡭ࡨࡶࠬନ")
        l1l1ll111ll11l1l11_nktv_ = _1ll111l1ll11l1l11_nktv_(content)
        if not l1l1ll111ll11l1l11_nktv_:
            print l1l11ll11l1l11_nktv_ (u"ࠨࡧࡱࡧࡴࡪࡥࡥࠢ࠽ࠤ࡫ࡵࡲࡤࡧࠣࠫ଩")
            l1l1ll111ll11l1l11_nktv_ = _1l1lll11ll11l1l11_nktv_(content)
    return l1l1ll111ll11l1l11_nktv_
def l1ll1111ll11l1l11_nktv_(url):
    l1l11ll11l1l11_nktv_ (u"ࠤࠥࠦࠒࠐࠠࠡࠢࠣࡶࡪࡺࡵࡳࡰࡶࠤࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠮ࠢࡸࡰࡷࠦࡨࡵࡶࡳ࠾࠴࠵࠮࠯࠰࠱ࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠭ࠡࡱࡵࠤࡱ࡯ࡳࡵࠢࡲࡪࠥࡡࠨࠨ࠹࠵࠴ࡵ࠭ࠬࠡࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡣࡥࡣ࠱ࡴࡱ࠵ࡶࡪࡦࡨࡳ࠴࠷࠹࠵࠸࠼࠽࠶࡬࠿ࡸࡧࡵࡷ࡯ࡧ࠽࠸࠴࠳ࡴࠬ࠯ࠬ࠯࠰࠱ࡡࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠏࠍࠤࠥࠦࠠࠣࠤࠥପ")
    l1l1l1lllll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠪࢀࡈࡵ࡯࡬࡫ࡨࡁࠧࡖࡈࡑࡕࡈࡗࡘࡏࡄ࠾࠳ࠩࡖࡪ࡬ࡥࡳࡧࡵࡁ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡺࡡࡵ࡫ࡦ࠲ࡨࡪࡡ࠯ࡲ࡯࠳ࡵࡲࡡࡺࡧࡵ࠹࠳࠿࠯ࡱ࡮ࡤࡽࡪࡸ࠮ࡴࡹࡩࠫଫ")
    l1l1l1l11ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࡨࡵࡶࡳ࠾࠴࠵ࡳࡵࡣࡷ࡭ࡨ࠴ࡣࡥࡣ࠱ࡴࡱ࠵ࡰ࡭ࡣࡼࡩࡷ࠻࠮࠺࠱ࡳࡰࡦࡿࡥࡳ࠰ࡶࡻ࡫࠭ବ")
    print url
    content = l1lll11l1ll11l1l11_nktv_(url)
    src=[]
    if not l1l11ll11l1l11_nktv_ (u"ࠬࡅࡷࡦࡴࡶ࡮ࡦ࠭ଭ") in url:
         l1l1l1ll1ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"࠭࠼ࡢࠢࡧࡥࡹࡧ࠭ࡲࡷࡤࡰ࡮ࡺࡹ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࠫࡃࡕࡂࡈ࠿࠰࠭ࡃ࠮ࡄࠨࡀࡒ࠿ࡕࡃ࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧମ"), re.DOTALL).findall(content)
         for quality in l1l1l1ll1ll11l1l11_nktv_:
             l1ll11l1ll11l1l11_nktv_ = re.search(l1l11ll11l1l11_nktv_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ଯ"),quality[1])
             l1l1l11l1ll11l1l11_nktv_ = quality[2]
             src.insert(0,(l1l1l11l1ll11l1l11_nktv_,l1ll1l11lll11l1l11_nktv_+l1ll11l1ll11l1l11_nktv_.group(1)))
    if not src:
        src = l1ll1111lll11l1l11_nktv_(content)
        if src:
            src+=l1l1l1lllll11l1l11_nktv_+l1l1l1l11ll11l1l11_nktv_
    return src
def l1l1lllllll11l1l11_nktv_(url,quality=0):
    l1l11ll11l1l11_nktv_ (u"ࠣࠤࠥࠑࠏࠦࠠࠡࠢࡵࡩࡹࡻࡲ࡯ࡵࠣࡹࡷࡲࠠࡵࡱࠣࡺ࡮ࡪࡥࡰࠏࠍࠤࠥࠦࠠࠣࠤࠥର")
    src = l1ll1111ll11l1l11_nktv_(url)
    if type(src)==list:
        selected=src[quality]
        print l1l11ll11l1l11_nktv_ (u"ࠩࡔࡹࡦࡲࡩࡵࡻࠣ࠾ࠬ଱"),selected[0]
        src = l1ll1111ll11l1l11_nktv_(selected[1])
    return src
