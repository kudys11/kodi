# -*- coding: utf-8 -*-
import sys
l1111ll11l1l11_nktv_ = sys.version_info [0] == 2
l111ll11l1l11_nktv_ = 2048
l1l1lll11l1l11_nktv_ = 7
def l1l11ll11l1l11_nktv_ (keyedStringLiteral):
	global l11llll11l1l11_nktv_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1111ll11l1l11_nktv_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import os,re,urllib
import xbmc,xbmcaddon,xbmcgui,xbmcvfs
l11l1ll1ll11l1l11_nktv_    = xbmcaddon.Addon().getAddonInfo
l11l1lllll11l1l11_nktv_     = xbmcvfs.File
l111ll1lll11l1l11_nktv_   = xbmcvfs.delete
l11l11l1ll11l1l11_nktv_     = xbmc.translatePath(l11l1ll1ll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠬࡶࡲࡰࡨ࡬ࡰࡪ࠭঳"))).decode(l1l11ll11l1l11_nktv_ (u"࠭ࡵࡵࡨ࠰࠼ࠬ঴"))
l11l11llll11l1l11_nktv_        = xbmcgui.ControlImage
l111lll1ll11l1l11_nktv_ = xbmcgui.WindowDialog()
l111llllll11l1l11_nktv_     = xbmc.Keyboard
def l11l1111ll11l1l11_nktv_(response):
    try:
        i = os.path.join(l11l11l1ll11l1l11_nktv_,l1l11ll11l1l11_nktv_ (u"ࠧࡤࡣࡳࡸࡨ࡮ࡡ࠯ࡲࡱ࡫ࠬ঵"))
        f = l11l1lllll11l1l11_nktv_(i, l1l11ll11l1l11_nktv_ (u"ࠨࡹࠪশ"))
        f.write(response)
        f.close()
        f = l11l11llll11l1l11_nktv_(450,5,375,115, i)
        d = l111lll1ll11l1l11_nktv_
        d.addControl(f)
        l111ll1lll11l1l11_nktv_(i)
        d.show()
        k = xbmc.Keyboard(l1l11ll11l1l11_nktv_ (u"ࠩࠪষ"), l1l11ll11l1l11_nktv_ (u"ࠪࠫস"))
        k.doModal()
        c = k.getText() if k.isConfirmed() else None
        if c == l1l11ll11l1l11_nktv_ (u"ࠫࠬহ"): c = None
        d.removeControl(f)
        d.close()
        return c
    except:
        return
def l111ll11ll11l1l11_nktv_(title=l1l11ll11l1l11_nktv_ (u"ࠬ࠭঺"),l11l1l1lll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"࠭ࠧ঻"),l11l1l11ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠧࠨ়")):
    xbmcgui.Dialog().ok(title,l11l1l1lll11l1l11_nktv_,l11l1l11ll11l1l11_nktv_)
