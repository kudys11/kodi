# coding: UTF-8
import sys
l1111ll11l1l11_nktv_ = sys.version_info [0] == 2
l111ll11l1l11_nktv_ = 2048
l1l1lll11l1l11_nktv_ = 7
def l1l11ll11l1l11_nktv_ (keyedStringLiteral):
	global l11llll11l1l11_nktv_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1111ll11l1l11_nktv_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urlparse,cookielib,urllib2,urllib
import time,re,os
url=l1l11ll11l1l11_nktv_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦࡨࡦࡾ࠮ࡵࡸ࠲ࠫ௴")
l111l1l1ll11l1l11_nktv_= cookielib.LWPCookieJar()
l1ll11ll1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠷࠳࠲࠵࠴࠲࠷࠸࠴࠲࠶࠶࠲ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨ௵")
l11ll1l11ll11l1l11_nktv_=l1ll11ll1ll11l1l11_nktv_
def l1lllll11ll11l1l11_nktv_(url,l111l1l1ll11l1l11_nktv_=l111l1l1ll11l1l11_nktv_,l11ll1l11ll11l1l11_nktv_=l1ll11ll1ll11l1l11_nktv_):
    l11ll1ll1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠪࠫ௶")
    try:
        class l11ll111lll11l1l11_nktv_(urllib2.HTTPErrorProcessor):
            def http_response(self, request, response):
                return response
        def l11l1llllll11l1l11_nktv_(s):
            try:
                offset=1 if s[0]==l1l11ll11l1l11_nktv_ (u"ࠫ࠰࠭௷") else 0
                val = int(eval(s.replace(l1l11ll11l1l11_nktv_ (u"ࠬࠧࠫ࡜࡟ࠪ௸"),l1l11ll11l1l11_nktv_ (u"࠭࠱ࠨ௹")).replace(l1l11ll11l1l11_nktv_ (u"ࠧࠢࠣ࡞ࡡࠬ௺"),l1l11ll11l1l11_nktv_ (u"ࠨ࠳ࠪ௻")).replace(l1l11ll11l1l11_nktv_ (u"ࠩ࡞ࡡࠬ௼"),l1l11ll11l1l11_nktv_ (u"ࠪ࠴ࠬ௽")).replace(l1l11ll11l1l11_nktv_ (u"ࠫ࠭࠭௾"),l1l11ll11l1l11_nktv_ (u"ࠬࡹࡴࡳࠪࠪ௿"))[offset:]))
                return val
            except:
                pass
        if l111l1l1ll11l1l11_nktv_==None:
            l111l1l1ll11l1l11_nktv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(l11ll111lll11l1l11_nktv_, urllib2.HTTPCookieProcessor(l111l1l1ll11l1l11_nktv_))
        opener.addheaders = [(l1l11ll11l1l11_nktv_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪఀ"), l11ll1l11ll11l1l11_nktv_)]
        try:
            response = opener.open(url)
            result=l11ll1ll1ll11l1l11_nktv_ = response.read()
            response.close()
        except urllib2.HTTPError as e:
            result=l11ll1ll1ll11l1l11_nktv_ = e.read()
        time.sleep(1)
        try:
            response = opener.open(url+l1l11ll11l1l11_nktv_ (u"ࠧ࡮ࡱࡧࡩࡷ࠴ࡨࡵ࡯࡯ࠫఁ"))
            result=l11ll1ll1ll11l1l11_nktv_ = response.read()
            response.close()
        except urllib2.HTTPError as e:
            result=l11ll1ll1ll11l1l11_nktv_ = e.read()
        l11ll1lllll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠨࡰࡤࡱࡪࡃࠢ࡫ࡵࡦ࡬ࡱࡥࡶࡤࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠱࠿ࠪࠤ࠲ࡂࠬం")).findall(result)[0]
        init = re.compile(l1l11ll11l1l11_nktv_ (u"ࠩࡶࡩࡹ࡚ࡩ࡮ࡧࡲࡹࡹࡢࠨࡧࡷࡱࡧࡹ࡯࡯࡯࡞ࠫࡠ࠮ࢁ࡜ࡴࠬ࠱࠮ࡄ࠴ࠪ࠻ࠪ࠱࠮ࡄ࠯ࡽ࠼ࠩః")).findall(result)[0]
        l11lll111ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࡵࠦࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࠭ࡧࡱࡵࡱࡡ࠭࡜ࠪ࠽࡟ࡷ࠯࠮࠮ࠫࠫࡤ࠲ࡻࠨఄ")).findall(result)[0]
        l11ll1l1lll11l1l11_nktv_ = l11l1llllll11l1l11_nktv_(init)
        lines = l11lll111ll11l1l11_nktv_.split(l1l11ll11l1l11_nktv_ (u"ࠫࡀ࠭అ"))
        if l11ll1lllll11l1l11_nktv_:
            for line in lines:
                if len(line)>0 and l1l11ll11l1l11_nktv_ (u"ࠬࡃࠧఆ") in line:
                    l11l1lll1ll11l1l11_nktv_=line.split(l1l11ll11l1l11_nktv_ (u"࠭࠽ࠨఇ"))
                    l11l1ll1lll11l1l11_nktv_ = l11l1llllll11l1l11_nktv_(l11l1lll1ll11l1l11_nktv_[1])
                    l11ll1l1lll11l1l11_nktv_ = int(eval(str(l11ll1l1lll11l1l11_nktv_)+l11l1lll1ll11l1l11_nktv_[0][-1]+str(l11l1ll1lll11l1l11_nktv_)))
            l11ll1111ll11l1l11_nktv_ = l11ll1l1lll11l1l11_nktv_ + len(urlparse.urlparse(url).netloc)
            u=l1l11ll11l1l11_nktv_ (u"ࠧ࠰ࠩఈ").join(url.split(l1l11ll11l1l11_nktv_ (u"ࠨ࠱ࠪఉ"))[:-1])
            query = l1l11ll11l1l11_nktv_ (u"ࠩࠨࡷ࠴ࡩࡤ࡯࠯ࡦ࡫࡮࠵࡬࠰ࡥ࡫࡯ࡤࡰࡳࡤࡪ࡯ࡃ࡯ࡹࡣࡩ࡮ࡢࡺࡨࡃࠥࡴࠨ࡭ࡷࡨ࡮࡬ࡠࡣࡱࡷࡼ࡫ࡲ࠾ࠧࡶࠫఊ") % (u, l11ll1lllll11l1l11_nktv_, l11ll1111ll11l1l11_nktv_)
            if l1l11ll11l1l11_nktv_ (u"ࠪࡸࡾࡶࡥ࠾ࠤ࡫࡭ࡩࡪࡥ࡯ࠤࠣࡲࡦࡳࡥ࠾ࠤࡳࡥࡸࡹࠢࠨఋ") in result:
                l11ll11llll11l1l11_nktv_=re.compile(l1l11ll11l1l11_nktv_ (u"ࠫࡳࡧ࡭ࡦ࠿ࠥࡴࡦࡹࡳࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩఌ")).findall(result)[0]
                query = l1l11ll11l1l11_nktv_ (u"ࠬࠫࡳ࠰ࡥࡧࡲ࠲ࡩࡧࡪ࠱࡯࠳ࡨ࡮࡫ࡠ࡬ࡶࡧ࡭ࡲ࠿ࡱࡣࡶࡷࡂࠫࡳࠧ࡬ࡶࡧ࡭ࡲ࡟ࡷࡥࡀࠩࡸࠬࡪࡴࡥ࡫ࡰࡤࡧ࡮ࡴࡹࡨࡶࡂࠫࡳࠨ఍") % (u,urllib.quote_plus(l11ll11llll11l1l11_nktv_), l11ll1lllll11l1l11_nktv_, l11ll1111ll11l1l11_nktv_)
                time.sleep(5)
            l11lllll1ll11l1l11_nktv_ =l1l11ll11l1l11_nktv_ (u"࠭ࠧఎ").join([l1l11ll11l1l11_nktv_ (u"ࠧࠦࡵࡀࠩࡸࡁࠧఏ")%(c.name, c.value) for c in l111l1l1ll11l1l11_nktv_])
            opener = urllib2.build_opener(l11ll111lll11l1l11_nktv_,urllib2.HTTPCookieProcessor(l111l1l1ll11l1l11_nktv_))
            opener.addheaders = [(l1l11ll11l1l11_nktv_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬఐ"), l11ll1l11ll11l1l11_nktv_,l1l11ll11l1l11_nktv_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ఑"),url)]
            opener.addheaders.append((l1l11ll11l1l11_nktv_ (u"ࠪࡧࡴࡵ࡫ࡪࡧࠪఒ"),l11lllll1ll11l1l11_nktv_))
            try:
                response = opener.open(query)
                response.close()
            except urllib2.HTTPError as e:
                response = e.read()
        return l111l1l1ll11l1l11_nktv_
    except:
        return None
def l1ll1l1llll11l1l11_nktv_(l11ll1ll11l1l11_nktv_):
    l11ll11l1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠫࠬఓ")
    if os.path.isfile(l11ll1ll11l1l11_nktv_):
        l111l1l1ll11l1l11_nktv_ = cookielib.LWPCookieJar()
        l111l1l1ll11l1l11_nktv_.load(l11ll1ll11l1l11_nktv_)
        for c in l111l1l1ll11l1l11_nktv_:
            l11ll11l1ll11l1l11_nktv_+=l1l11ll11l1l11_nktv_ (u"ࠬࠫࡳ࠾ࠧࡶ࠿ࠬఔ")%(c.name, c.value)
    return l11ll11l1ll11l1l11_nktv_
