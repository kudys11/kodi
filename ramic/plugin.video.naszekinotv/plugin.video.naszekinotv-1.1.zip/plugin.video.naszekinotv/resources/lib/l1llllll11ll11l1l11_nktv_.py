# -*- coding: utf-8 -*-
import sys
l1111ll11l1l11_nktv_ = sys.version_info [0] == 2
l111ll11l1l11_nktv_ = 2048
l1l1lll11l1l11_nktv_ = 7
def l1l11ll11l1l11_nktv_ (keyedStringLiteral):
	global l11llll11l1l11_nktv_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1111ll11l1l11_nktv_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os,json,base64
import l1lll1l1lll11l1l11_nktv_,cookielib
from urlparse import urlparse
l1ll1l11lll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴࡫ࡪࡰࡲࡷࡹࡧࡣ࡫ࡣ࠱ࡴࡱ࠵ࠧൌ")
l1111lllll11l1l11_nktv_ = 10
l1ll11ll1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡏࡘ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠷࠼࠳࠶࠮࠳࠷࠹࠸࠳࠿࠷ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨ്")
l11ll1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࡶࠬࡩ࡯ࡰ࡭࡬ࡩ࠳ࡩࡤࡢࠩൎ")
l1ll1l1l1ll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠬ࠭൏")
def _1ll1ll1lll11l1l11_nktv_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l1l11ll11l1l11_nktv_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ൐"), l1ll11ll1ll11l1l11_nktv_)
    if cookies:
        req.add_header(l1l11ll11l1l11_nktv_ (u"ࠢࡄࡱࡲ࡯࡮࡫ࠢ൑"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l1111lllll11l1l11_nktv_)
        l1ll11l1ll11l1l11_nktv_ = response.read()
        response.close()
    except:
        l1ll11l1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠨࠩ൒")
    return l1ll11l1ll11l1l11_nktv_
def l1lll11l1ll11l1l11_nktv_(url,data=None):
    cookies=l1lll1l1lll11l1l11_nktv_.l1ll1l1llll11l1l11_nktv_(l11ll1ll11l1l11_nktv_)
    content=_1ll1ll1lll11l1l11_nktv_(url,data,cookies)
    if not content:
        l111l1l1ll11l1l11_nktv_=l1ll1lll1ll11l1l11_nktv_(l1ll1l11lll11l1l11_nktv_,l11ll1ll11l1l11_nktv_)
        cookies=l1lll1l1lll11l1l11_nktv_.l1ll1l1llll11l1l11_nktv_(l11ll1ll11l1l11_nktv_)
        content=_1ll1ll1lll11l1l11_nktv_(url,data,cookies)
    return content
def l1ll1lll1ll11l1l11_nktv_(l1ll11l1ll11l1l11_nktv_,l1lll11llll11l1l11_nktv_):
    l111l1l1ll11l1l11_nktv_ = cookielib.LWPCookieJar()
    l1lll111lll11l1l11_nktv_ = l1lll1l1lll11l1l11_nktv_.l1lllll11ll11l1l11_nktv_(l1ll11l1ll11l1l11_nktv_,l111l1l1ll11l1l11_nktv_,l1ll11ll1ll11l1l11_nktv_)
    l11l11l1ll11l1l11_nktv_=os.path.dirname(l1lll11llll11l1l11_nktv_)
    if not os.path.exists(l11l11l1ll11l1l11_nktv_):
        os.makedirs(l11l11l1ll11l1l11_nktv_)
    if l111l1l1ll11l1l11_nktv_:
        l111l1l1ll11l1l11_nktv_.save(l1lll11llll11l1l11_nktv_, ignore_discard = True)
    return l111l1l1ll11l1l11_nktv_
def l1ll1ll1ll11l1l11_nktv_(url,l1l11llll11l1l11_nktv_=1,group=l1l11ll11l1l11_nktv_ (u"ࠩࠪ൓")):
    if l1l11ll11l1l11_nktv_ (u"ࠪࡃࡵࡧࡧࡦ࠿ࠪൔ") in url:
        url = url.replace(l1l11ll11l1l11_nktv_ (u"ࠫࡄࡶࡡࡨࡧࡀࠫൕ"),l1l11ll11l1l11_nktv_ (u"ࠬࡅࡰࡢࡩࡨࡁࠪࡪࠧൖ") %l1l11llll11l1l11_nktv_)
    else:
        url += l1l11ll11l1l11_nktv_ (u"࠭࠯ࠨൗ") if url[-1] != l1l11ll11l1l11_nktv_ (u"ࠧ࠰ࠩ൘") else l1l11ll11l1l11_nktv_ (u"ࠨࠩ൙")
        url = url + l1l11ll11l1l11_nktv_ (u"ࠩࡂࡴࡦ࡭ࡥ࠾ࠧࡧࠫ൚") %l1l11llll11l1l11_nktv_
    content = l1lll11l1ll11l1l11_nktv_(url)
    out=[]
    l1ll1ll11ll11l1l11_nktv_=False
    l11111l1ll11l1l11_nktv_=False
    ids = []
    if group:
        idx = [(m.start(0), m.end(0)) for m in re.finditer(l1l11ll11l1l11_nktv_ (u"ࠪࡀ࡭࠹࠾ࠨ൛"), content,re.IGNORECASE) ]
        idx.append( (content.find(l1l11ll11l1l11_nktv_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮࡬࡫ࡱࡳࡸࡺࡡࡤ࡬ࡤ࠲ࡵࡲ࠯ࡳࡧ࡭ࡩࡸࡺࡲࡢࡥ࡭ࡥࠧ࠭൜")),content.find(l1l11ll11l1l11_nktv_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯࡭࡬ࡲࡴࡹࡴࡢࡥ࡭ࡥ࠳ࡶ࡬࠰ࡴࡨ࡮ࡪࡹࡴࡳࡣࡦ࡮ࡦࠨࠧ൝"))) )
        for i in range(len(idx[:-1])):
            print i
            l1ll111llll11l1l11_nktv_=content[ idx[i][0]:idx[i+1][0] ]
            if group in l1ll111llll11l1l11_nktv_:
                print group
                content = l1ll111llll11l1l11_nktv_
                ids = [(a.start(), a.end()) for a in re.finditer(l1l11ll11l1l11_nktv_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡬࠮ࡺࡶ࠱ࡡࡪࠫࠨ൞"), content)]
                ids.append( (-1,-1) )
                break
        for i in range(len(ids[:-1])):
            print content[ ids[i][1]:ids[i][1]+100 ]
            l111l1llll11l1l11_nktv_ = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile(l1l11ll11l1l11_nktv_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩൟ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
            title = re.compile(l1l11ll11l1l11_nktv_ (u"ࠨࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨൠ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
            l1lll1lllll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠩ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬൡ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
            l1111111ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࡀ࠴ࡨ࠾࡝ࡵ࠭ࠬࡡࡪ࡜࠯࡞ࡧ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬൢ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
            year =  re.compile(l1l11ll11l1l11_nktv_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡼࡩࡦࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨൣ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
            if href and title:
                l1lll1lllll11l1l11_nktv_ = l1lll1lllll11l1l11_nktv_.group(1) if l1lll1lllll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠬ࠭൤")
                if l1lll1lllll11l1l11_nktv_.startswith(l1l11ll11l1l11_nktv_ (u"࠭࠯࠰ࠩ൥")):
                    l1lll1lllll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠧࡩࡶࡷࡴ࠿࠭൦")+l1lll1lllll11l1l11_nktv_
                l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠨࡪࡵࡩ࡫࠭൧")   : href.group(1),
                    l1l11ll11l1l11_nktv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ൨")  : l1lll1ll1ll11l1l11_nktv_(title.group(1)),
                    l1l11ll11l1l11_nktv_ (u"ࠪ࡭ࡲ࡭ࠧ൩")    : l1lll1lllll11l1l11_nktv_,
                    l1l11ll11l1l11_nktv_ (u"ࠫࡷࡧࡴࡪࡰࡪࠫ൪") : l1111111ll11l1l11_nktv_.group(1) if l1111111ll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠬ࠭൫"),
                    l1l11ll11l1l11_nktv_ (u"࠭ࡹࡦࡣࡵࠫ൬")   : year.group(1) if year else l1l11ll11l1l11_nktv_ (u"ࠧࠨ൭"),
                        }
                out.append(l11111llll11l1l11_nktv_)
    else:
        l1l1llllll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠨ࠾ࡸࡰࠥࡩ࡬ࡢࡵࡶࡁࡠࠨ࡜ࠨ࡟ࡦࡰࡪࡧࡲࡧ࡫ࡻࠤࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮࡜ࠤ࡟ࠫࡢࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ൮"),re.DOTALL).findall(content)
        l1l1llllll11l1l11_nktv_ = urllib.unquote(l1l1llllll11l1l11_nktv_[0]) if l1l1llllll11l1l11_nktv_ else content
        l1ll1ll11ll11l1l11_nktv_=False
        if l1l1llllll11l1l11_nktv_.find( l1l11ll11l1l11_nktv_ (u"ࠩࡂࡴࡦ࡭ࡥ࠾ࠧࡧࠫ൯") %(l1l11llll11l1l11_nktv_+1))>-1:
            l1ll1ll11ll11l1l11_nktv_ = l1l11llll11l1l11_nktv_+1
        ids = [(a.start(), a.end()) for a in re.finditer(l1l11ll11l1l11_nktv_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡰ࠲ࡾࡳ࠮࡞ࡧࠫ൰"), content)]
        ids.append( (-1,-1) )
        for i in range(len(ids[:-1])):
            l111l1llll11l1l11_nktv_ = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile(l1l11ll11l1l11_nktv_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭൱"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
            title = re.compile(l1l11ll11l1l11_nktv_ (u"ࠬࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ൲"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
            l1lll1lllll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"࠭࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ൳"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
            l1111111ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠧ࠽࠱ࡥࡂࡡࡹࠪࠩ࡞ࡧࡠ࠳ࡢࡤࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ൴"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
            year =  re.compile(l1l11ll11l1l11_nktv_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡹࡦࡣࡵࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ൵"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
            if href and title:
                l1lll1lllll11l1l11_nktv_ = l1lll1lllll11l1l11_nktv_.group(1) if l1lll1lllll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠩࠪ൶")
                if l1lll1lllll11l1l11_nktv_.startswith(l1l11ll11l1l11_nktv_ (u"ࠪ࠳࠴࠭൷")):
                    l1lll1lllll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ൸")+l1lll1lllll11l1l11_nktv_
                l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠬ࡮ࡲࡦࡨࠪ൹")   : href.group(1),
                    l1l11ll11l1l11_nktv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬൺ")  : l1lll1ll1ll11l1l11_nktv_(title.group(1)),
                    l1l11ll11l1l11_nktv_ (u"ࠧࡪ࡯ࡪࠫൻ")    : l1lll1lllll11l1l11_nktv_,
                    l1l11ll11l1l11_nktv_ (u"ࠨࡴࡤࡸ࡮ࡴࡧࠨർ") : l1111111ll11l1l11_nktv_.group(1) if l1111111ll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠩࠪൽ"),
                    l1l11ll11l1l11_nktv_ (u"ࠪࡽࡪࡧࡲࠨൾ")   : year.group(1) if year else l1l11ll11l1l11_nktv_ (u"ࠫࠬൿ"),
                        }
                out.append(l11111llll11l1l11_nktv_)
        l11111l1ll11l1l11_nktv_ = l1l11llll11l1l11_nktv_-1 if l1l11llll11l1l11_nktv_>1 else False
    return (out, (l11111l1ll11l1l11_nktv_,l1ll1ll11ll11l1l11_nktv_))
def l111l111ll11l1l11_nktv_(url):
    content = l1lll11l1ll11l1l11_nktv_(url)
    token = re.search(l1l11ll11l1l11_nktv_ (u"ࠬࡴࡡ࡮ࡧࡀࠦࡤࡺ࡯࡬ࡧࡱࠦࠥࡺࡹࡱࡧࡀࠦ࡭࡯ࡤࡥࡧࡱࠦࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠭඀"),content).group(1)
    l1ll1llllll11l1l11_nktv_ = re.search(l1l11ll11l1l11_nktv_ (u"࠭ࡳࡪࡶࡨ࡯ࡪࡿ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩඁ"),content).group(1)
    params = {l1l11ll11l1l11_nktv_ (u"ࠧࡠࡶࡲ࡯ࡪࡴࠧං"):l1l11ll11l1l11_nktv_ (u"ࠨࡏࡪ࡞ࡒࡈ࠱ࡘࡨ࠷࡙ࡇࡍࡰࡩ࡛ࡉ࠵࡮࠼࠳࡮ࡑ࠷࠺࠼ࡽࡸࡈ࠺ࡖ࠹ࡰ࠻ࡣ࡬ࡲ࠷ࡑࡔࡰࠧඃ"),
            l1l11ll11l1l11_nktv_ (u"ࠩࡪ࠱ࡷ࡫ࡣࡢࡲࡷࡧ࡭ࡧ࠭ࡳࡧࡶࡴࡴࡴࡳࡦࠩ඄"):l1l11ll11l1l11_nktv_ (u"ࠪ࠴࠸ࡇࡈࡋࡡ࡙ࡹࡻࡽࡷ࡬ࡍࡉ࠵ࡎ࠿ࡌࡏࡪࡘࡖࡗࡹࡐࡋࡵࡔࡓ࠺ࡥࡓ࡭ࡊࡴࡋࡶ࡜࠹ࡣࡱࡵࡆࡦ࡛ࡗࡲ࡯ࡱࡵࡓࡊࡦࡲࡊ࠴ࡴ࡙ࡏࡐࡺ࡯ࡴ࡙ࡼࡒࡌ࡬࡬࠷ࡼ࡭࠼࡮ࡘࡩࡄࡱࡇࡴࡷࡗࡥ࡝ࡆ࡛ࡻࡧ࡮ࡏࡍ࡭࡛ࡩࡰࡍ࠸࠰ࡘ࠷ࡩࡊࡈࡷ࠸ࡪࡉࡑ࡭ࡆࡵࡻࡥ࡟ࡹ࠱ࡐࡓࡊࡕࡽࡶ࠸ࡵࡑࡵ࠶࡞ࡶࡡࡗࡥࡄ࡚ࡵ࡫ࡐࡦࡶࡔࡰࡇ࡜࠰ࡺࡃ࠻࡫࡙ࡉࡑࡤࡲࡰࡲ࡫࡟ࡤࡐࡕࡦࡕࡰࡾࡕ࠺ࡱࡢࡷ࠺ࡗ࠴ࡴ࡬ࡓ࠸ࡍࡵࡶ࠳ࡓࡥࡦ࡭ࡍࡖ࠺ࡕࡌ࠸ࡔ࠾ࡡ࠮ࡘࡕࡅ࡛࡞ࡲࡖࡼࡳࡪ࠻ࡾࡹࡶࡧࡹ࡝ࡸࡻࡘ࠴ࡊࡻࡌࡦࡥࡂࡴ࡛ࡔࡇ࠾࡛࠷ࡅ࡚࠳࡮࡫ࡰࡂࡋࡆࡰ࡭ࡱࡐࡡࡣ࠸ࡘࡈࡗࡪࡖࡄ࡮ࡨࡋ࠲ࡰࡆࡸ࠹ࡕࡏࡵ࠽࠵ࡖࡗ࡫ࡰࡿ࡞ࡁࡍࡑࡉࡳ࡭࠹ࡉࡘࡣ࡝࡛࠾ࡰࡌࡦ࠲ࡉ࠷ࡲ࡜ࡥ࡮ࡘࡗࡕ࠲࠷࠳ࡱ࠲ࡒࡅࡾࡴࡷࡶࡱࡄࡘ࡟࡝ࡆࡵࡪࡈࡐ࠽ࡉ࠰ࡏࡍࡐ࡙ࡧࡪࡖࡨ࠷ࡧ࠱ࡤ࠼࠲࠹࡭ࡢࡆࡼࡊ࠱ࡓ࠸ࡎࡨ࠹࡞ࡪࡶࡃ࠼ࡪࡱࡗࡃࡆࡏࡪ࡙࠺࡮ࡺࡍ࡯࠻ࡖࡤࡑ࠳ࡇࡍࡤࡊࡰࡖࡰࡪࡷࡘࡗ࠸ࡳࡲ࠮ࡶ࡛ࡾ࠼ࡼࡳࡵࡎ࠼ࡆࡎࡖࡘ࡫ࡓࡺ࠺࠽࡟࠱ࡶ࡯࡮ࡣ࠼ࡸࡑࡷࡍࡍ࡫ࡎࡗࡁ࠳ࡐࡩࡦ࠺ࡽࡡࡕࡃࡇࡊ࠶࡭ࡡࡄࡷࡶ࡝ࡒ࠺ࡤ࠲࠶ࡑࡌ࠾ࡌ࠵࠳࡭ࡈ࠸ࡱࡸࡤࡣࡣ࡜࠶࡚࡙࠹ࡶ࡫ࡑࡇࡶࡋࡦ࡚ࡪࡄࡧࡿ࡞ࡹࡇࡩࡻࡼࡶࡈࡊ࠶࠺ࡅ࠺ࡕࡖࡺ࠱࡭࠶ࡑ࠼࠳ࡘࡲ࡜ࡖࡸࡕࢀࡡࡎࡒ࠷ࡑࡉࡘࡆࡳ࠶ࡼࡹࡏ࠷ࡁ࡯࠹ࡧࡳࡳ࠺ࡩ࡮࠸࠼ࡧࡔ࠾ࡰࡄ࠲ࡼࡺ࡬ࡧࡹࡘࡺࡶࡥࡱࡓ࠸ࡋࡎࡆࡈ࡮࡚࠷ࡗ࡯ࡖ࡯ࡦ࠽࠸ࡈ࡛ࡧ࠴ࡇࡪࡷࡔࡡࡧࡇ࠶࡚ࡸࡕ࡫࡮࡬࡛࠾ࡣࡉ࠻ࡤࡨࡏ࡞࡙࠶ࡃࡷࡇࡏࡉࡉ࠳ࡧ࡭ࡸࡆࡩࡣࡺ࡛࠸࡭ࡾࡩࡩࡦ࠯ࡽࡺࡓࡠࡥ࡫ࡸࡤࡇ࠽ࡍ࡙ࡊࡨࡺࡏࡓ࡫࡙ࡂ࠵࡙࡭࠻࠶ࡧ࡚ࡐࡪࡍࡪࡼ࠲ࡢ࠷ࡘࡑࡎࡗ࡚ࡧ࡛࠷ࡾ࡜࡬࡟ࡱ࡬ࡶ࠼࡙࠽ࡷࡅࡎࡴࡶ࠵࠾࡫ࡓࡊࡷࡖ࠼࡮ࡹࡣ࡯ࡰࡏࡸࡼ࡙ࡸࡉࡉ࡯࡮ࡊࡍࡷࡧࡨࡵࡖࡾ࠭ࡷࡼ࡙ࡈ࠹ࡩ࠹ࡵࡧ࠺࠽࡟ࡶࡏࡶࡔࡖࡱࡆࡔ࠸ࡪ࡫࠵ࡅࡷࡪ࡙ࡉ࡙ࡥࡣࡒ࠼࠹ࡢ࠲ࡋࡪ࡫ࡧࡧࡻࡒࡷ࡙࠽ࡓࡃࡤ࠸ࡏࡻࡺ࠾ࡔ࠷࠷ࡺ࠵ࡽࡷ࠷ࡊࡎࡱࡕࡗࡵࡣࡤࡲࡳࡑࡼࡉ࠹ࡃ࠺ࡗ࠼ࡱࢀࡤࡊࡳࡖ࠶ࡾࡒࡃࡴࡩࡎࡼࡿࡩࡌࡇࡑࡨࡵࡵࡺ࡟ࡒࡃࡌࡨࡓ࡭ࡩࡣࡻࡉ࠷ࡶ࠽ࡄ࡛ࡧࡦࡰ࠹࠷ࡲ࠳ࡪࡻࡒࡰࡎࡰ࠷࡯ࡗ࠵ࡰࡰ࡫ࡄ࠺ࡪࡻࡿࡉࡢࡨࡸࡍࡅࡴࡷ࠷ࡻࡷ࡝࡙࡝ࡼ࡯ࡒࡅࡸࡉࡊ࡛ࡎࡂࡷࡦࡍࡹࡎࡍ࠺ࡗࡦࡑࡉࡗ࠴ࡪࡏ࡜ࡔࡼࡈࡗࡣࡵࡘࡪࡪࢀࡁࡃ࡫ࡒ࡛ࡳ࡫࠰ࡇ࠹ࡔࡕࡨࡋ࡟ࡌࡘ࡜࠸ࡾࡋ࠴ࡓࡈࡖࡉࡳࡺࡗ࡭࠻ࡱࡽࡾ࡞࠹ࡐ࠴ࡒ࡝࠻࡮ࡅࡪ࠴ࡨ࠵ࡌ࠻ࡂࡂࡧ࡛ࡈࡤ࠷ࡹࡪࡎ࠼ࡷ࠲ࡹ࠶࠹ࡲ࡯࡭ࡰࡌࡆࡠ࡮ࡅࡶࡖ࡟࠰ࡷࡥࡤࡔࡳࡓ࠶࠺ࡓࡖࡪࡳࡸࡕࡂࡰࡉ࠹࡭࠽ࡂࡈࡹ࡯ࡘࡰࡷࡂࡨ࡮ࡺ࠺࠷ࡻࡏࡸ࠷ࡓࡲ࠷ࡱࡴࡺࡩࡕࡔ࠲ࡈࡔࡕࡲࡪ࡙ࡽ࡜ࡡ࠱ࡨࡷ࡬ࡽࡋࡪࡓࡡ࠶࠵࡛ࡉࡕࡷࡄࡰࡈ࠸ࡴࡷࡷ࡫ࡒࡓࡆࡘࡂ࡬ࡐࡻࡻࡿࡔࡌࡷࡼࡅ࠱ࡑࡎࡑ࠵ࡋࡺࡸ࠽ࡘࡗࡗ࡬࠴ࡌࡉ࠸࠲ࡒ࡛ࡄ࡛࡯ࡌࡔࡉࡗ࡝ࡒࡒ࡟࡯ࡨ࠵ࡵࡊࡗ࠷࠱࡙࡫࠵ࡣ࠼ࡌࡕࡤࡗࡦࡓࡌࡌࡍࡻࡼ࡮ࡇࡲࡏ࡯ࡧࡲ࡛࠼࠶࠹࡬࡬࠷ࡧࡩࡉࡳࡈࡪࡘࡽࡳࡓ࡞ࡧ࠳ࡷࡕ࡭ࡦࡊࡊࡲࡦࡇ࡫ࡱࡺࡔ࠸࠺ࡄ࡬ࡒ࡙ࡆࡎ࡜࡫ࡳࡒ࡯࡭ࡋࡗࡹࡌࡱࡻࡵࡃ࠲࠼ࡍࡋࡉ࡫ࡆ࠲ࡐࡣ࠻ࡪࡺࡑࡻ࡬࠶࠸࡭ࡩࡥ࡜ࡕ࡮࡞ࡵࡤ࠹ࡲࡴ࡚࠷࠶ࡇ࠵࡛࠴ࡦࡈ࠼࡚ࡻࡶࡷࡰࡉࡨࡣࡓࡥࡦࡈ࡫ࡑࡡࡥࡥࡍࡹ࠾ࡋࡰࡈࡏࡦ࡚ࡑࡗ࡮࡯ࡄࡽࡷࡪ࡚ࡓ࠱ࡅࡊࡱ࠽ࡔ࠱ࡏ࡮ࡸࡈࡨࡰࡍࡩࡹࡱࡾࡲ࠾ࡴࡦࡖࡍࡍࡪ࡭ࡥࡴ࡫ࡳࡷࡍ࠽ࡑ࡛࠺ࡘࡽ࡫࡭ࡣࡺࡈࡓࡨ࠵࠳࠸ࡤࡑ࡮࡯ࡲࡑࡧ࡭ࡧࡈ࡙ࡉ࡜ࡘࡄࡶࡄ࡯࡟࡙ࡢ࡚ࡖ࠳࠷ࡘ࠳ࡴࡖࡳࡎࡼ࡮ࡱࡑ࠸ࡓࡻࡎࡔࡋࡖࡳࡊࡐ࠴࡞࠻ࡷࡗ࡬ࡏࡒ࡙ࡹ࠰ࡕ࡙ࡉ࡙ࡊࡊࡅࡰ࠷࡬࡜ࡻ࠳࠶ࡲࡹ࠼࠼ࡿࡻ࠶ࡺ࡫࡚࡭ࡖ࠸ࡰࡇࡤ࠺ࡗࡧࡾࡶࡧ࡯࡛࡬ࡐ࠹ࡱࡇ࡙ࡹ࡯࡚ࡉ࡬ࡹ࡬ࡪࡆ࡭࠽࡫ࡗࡷ࠸ࡸࡰࡱࡄࡏ࠲࠴࠵ࡘࡈ࠵ࡓࡧࡲࡇࡏࡻࡌࡥࡨࡋࡐࡹࡕࡨ࠳ࡈࡴ࡞࠷ࡽ࠷ࡑࡪࡊࡏࡇࡰࡥࡷࡦࡄࡐ࠷࡬ࡃࡓࡇ࡫࡜࠶ࡐࡴ࡚ࡐ࠻ࡽࡆ࡛ࡩࡑࡐ࡭ࡼࡰࡇࡂࡵࡃࡥࡱࡾࡒ࠷ࡴ࠯ࡎࡴ࠷࡝ࡢࡷࡸࡕࡵࡑ࠺࠳࠶࠹ࡷࡘ࠻ࡳࡎ࡙ࡅࡴ࡫࠲࡬࡮ࡎ࠳࡬ࡕ࠾ࡵ࡙ࡂࡶࡓ࡭ࡲࡐ࡯ࡥࡸࡇ࠼࡟ࡉࡋ࡚࠷ࡅ࠽ࡲࡩ࠳ࡢࡑࡸࡈࡎࡗࡺࡷ࠸ࡏࡘࡤࡵࡰࡦࡸ࡙ࡥ࠾࠽࡯ࡇ࠲࡯ࡩࡩ࡯ࡕ࠹ࡩࡒ࠺࠸ࡋࡵࡲ࡯࠹࡫ࡎ࠻ࡋ࠱࡬࠸࡚ࡕ࡫ࡖࡷࡲࡦ࠴ࡿࡿࡡ࡚ࡘ࡛ࡊ࠾ࡺࡸ࠶ࡓࡽࡊࡐࡺࡏࡆࡃࡆࡣࡐࡧࡔࡩ࠯ࡖࡹ࠼࡛ࡊ࡯࡙࠷ࡕࡧࡎࡕࡪ࠻ࡓࡰࡸ࡭ࡧࡒࡒ࠳ࡎࡆ࠻࠶ࡠࡩ࡫ࡘࡔ࠾ࡂ࡫ࡒ࡜࠶ࡺ࠾ࡋ࠺࠻ࡋࡈ࡭ࡥࡤࡱ࠶ࡈࡦ࠶ࡋ࠰ࡕ࠻ࡄ࠵ࡽࡺࡺࡳࡤ࡛࠷࡟࡭ࡆ࠱࠷ࡺࡇࡊࡐࡥ࠶ࡎࡰ࠶ࡶ࡞࠰ࡖࡦ࡝࡜ࡾࡥࡁࡗࡷࡴ࠻ࡘ࠹ࡅࡎ࠵ࡐ࡮࡭ࡐࡉ࡛࠯ࡎࡦ࡯࡫࠷ࡑࡱࡩࡵࡱࡾࡇ࡮࠲࠼ࡍ࡭ࡐࡸࡓࡥࡧࡉ࠹ࡰࡘ࡛ࡩࡵࡰࡩ࠽ࡡࡑࡪࡹ࠴ࡇ࡚࠱ࡒ࠻࠴ࡈ࡝ࡸࡒ࠹࡮ࡏࡸ࡞࠼ࡎࡓࡄࡶ࡞࡫ࡱࡨ࠺ࡐࠪඅ")
           }
    data=urllib.urlencode(params)
    a=l1lll11l1ll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡴࡻ࡯࠯࡫ࡲ࠳࡬ࡵ࠯ࡇ࡭ࡥࡧࡺ࠭ආ"),data)
    print a
def _1llll1l1ll11l1l11_nktv_(url,host=l1l11ll11l1l11_nktv_ (u"ࠬ࠭ඇ")):
    l1111l11ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"࠭ࠧඈ")
    if url.startswith(l1l11ll11l1l11_nktv_ (u"ࠧࡩࡶࡷࡴࠬඉ")):
        if l1l11ll11l1l11_nktv_ (u"ࠨ࡮࡬ࡲࡰ࡯࠮ࡰࡰ࡯࡭ࡳ࡫ࠧඊ") in url:
            content = l1lll11l1ll11l1l11_nktv_(url)
            l1l1l1l1ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠩࡷࡳࡵ࠴࡬ࡰࡥࡤࡸ࡮ࡵ࡮ࠡ࠿ࠣ࡟ࡡ࠭ࠢ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠩࠥࡡࡀ࠭උ")).search(content)
            if l1l1l1l1ll11l1l11_nktv_:
                l1111l11ll11l1l11_nktv_ = l1l1l1l1ll11l1l11_nktv_.group(1)
        if l1l11ll11l1l11_nktv_ (u"ࠪࡳࡺࡵ࠮ࡪࡱࠪඌ") in url:
            l1111l11ll11l1l11_nktv_ = url
        else:
            req = urllib2.Request(url)
            req.add_header(l1l11ll11l1l11_nktv_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨඍ"), l1l11ll11l1l11_nktv_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠹࠾࠮࠱࠰࠵࠹࠻࠺࠮࠺࠹ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪඎ"))
            try:
                response = urllib2.urlopen(req)
                if response:
                    l1111l11ll11l1l11_nktv_=response.url
                    if l1111l11ll11l1l11_nktv_==url:
                        content=response.read()
                        l1l1l1l1ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮࠮ࠨࠠࡤ࡮ࡤࡷࡸ࠭ඏ")).findall(content)
                        for l in l1l1l1l1ll11l1l11_nktv_:
                            if host in l:
                                l1111l11ll11l1l11_nktv_ = l
                                break
                    response.close()
            except:
                pass
    return l1111l11ll11l1l11_nktv_
def l1111ll1ll11l1l11_nktv_(url,content=None):
    if not content:
        content = l1lll11l1ll11l1l11_nktv_(url)
    out  =[]
    l1ll11lllll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠡࠪ࠱࠮ࡄ࠯࠼࠰࡫ࡩࡶࡦࡳࡥ࠿ࠩඐ"),re.DOTALL).findall(content)
    names = re.compile(l1l11ll11l1l11_nktv_ (u"ࠨ࠾ࡸࡰࠥࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡤࡕࡣࡥࡷࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪඑ"),re.DOTALL).findall(content)
    if names:
        names = [x.strip() for x in re.compile(l1l11ll11l1l11_nktv_ (u"ࠩࡁࠬ࠳࠰࠿ࠪ࠾ࠪඒ"),re.DOTALL).findall(names[0]) if x.strip()]
    else:
        names=[]
    for l1lllllllll11l1l11_nktv_ in l1ll11lllll11l1l11_nktv_:
        href = re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨඓ"),re.DOTALL).search(l1lllllllll11l1l11_nktv_)
        if href:
            l111111lll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠫ࡭ࡺࡴࡱࠩඔ")+ urllib.unquote(href.group(1)).split(l1l11ll11l1l11_nktv_ (u"ࠬ࡮ࡴࡵࡲࠪඕ"))[-1]
            if l111111lll11l1l11_nktv_.startswith(l1l11ll11l1l11_nktv_ (u"࠭ࡨࡵࡶࡳࠫඖ")) and not l1l11ll11l1l11_nktv_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥࠨ඗") in l111111lll11l1l11_nktv_ and not l1l11ll11l1l11_nktv_ (u"ࠨࡨࡤࡧࡪࡨ࡯ࡰ࡭ࠪ඘") in l111111lll11l1l11_nktv_:
                host = urlparse(l111111lll11l1l11_nktv_).netloc
                l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠩࡸࡶࡱ࠭඙") : l111111lll11l1l11_nktv_,
                    l1l11ll11l1l11_nktv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩක"): l1l11ll11l1l11_nktv_ (u"ࠦࡠࠫࡳ࡞ࠤඛ") %(host),
                    l1l11ll11l1l11_nktv_ (u"ࠬ࡮࡯ࡴࡶࠪග"): host    }
                out.append(l11111llll11l1l11_nktv_)
    if len(names)==len(out):
        for l11111llll11l1l11_nktv_,name in zip(out,names):
            l11111llll11l1l11_nktv_[l1l11ll11l1l11_nktv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬඝ")] += l1l11ll11l1l11_nktv_ (u"ࠧࠡࠧࡶࠫඞ")%name
    return out
url=l1l11ll11l1l11_nktv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡱࡩ࡯ࡱࡶࡸࡦࡩࡪࡢ࠰ࡳࡰ࠴࡬ࡩ࡭࡯࠰ࡳࡳࡲࡩ࡯ࡧ࠲࠵࠼࠿࠰࠵࠱ࡧࡾ࡮࡫࡮࠮ࡲࡤࡸࡷ࡯࡯ࡵࡱࡺ࠱ࡵࡧࡴࡳ࡫ࡲࡸࡸ࠳ࡤࡢࡻࠪඟ")
def l1l1lllll11l1l11_nktv_(url):
    content = l1lll11l1ll11l1l11_nktv_(url)
    l1111111lll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠩ࠿ࡸࡧࡵࡤࡺࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡦࡴࡪࡹ࠿ࠩච"),re.DOTALL).findall(content)
    l1111111lll11l1l11_nktv_ = l1111111lll11l1l11_nktv_[0] if l1111111lll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠪࠫඡ")
    ids = [(a.start(), a.end()) for a in re.finditer(l1l11ll11l1l11_nktv_ (u"ࠫࡁࡺࡲ࠿ࠩජ"), l1111111lll11l1l11_nktv_)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l111l1llll11l1l11_nktv_ = l1111111lll11l1l11_nktv_[ ids[i][1]:ids[i+1][0] ]
        href=re.compile(l1l11ll11l1l11_nktv_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫඣ")).search(l111l1llll11l1l11_nktv_)
        l11111l11ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"࠭ࡤࡢࡶࡤ࠱࡮࡬ࡲࡢ࡯ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬඤ")).search(l111l1llll11l1l11_nktv_)
        info = l1l11ll11l1l11_nktv_ (u"ࠧࠨඥ").join(re.compile(l1l11ll11l1l11_nktv_ (u"ࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠩඦ"),re.DOTALL).findall(l111l1llll11l1l11_nktv_))
        info = re.sub(l1l11ll11l1l11_nktv_ (u"ࠩࠣ࠯ࠬට"),l1l11ll11l1l11_nktv_ (u"ࠪࠤࠬඨ"),l1lll1ll1ll11l1l11_nktv_(info)).strip()
        if href:
            l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠫࡺࡸ࡬ࠨඩ") : href.group(1),l1l11ll11l1l11_nktv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫඪ"): info,}
            out.append(l11111llll11l1l11_nktv_)
    return out
def l1111l1ll11l1l11_nktv_(url):
    content = l1lll11l1ll11l1l11_nktv_(url)
    l1lll1lllll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"࠭࠼ࡥ࡫ࡹࠤ࡮ࡪ࠽ࠣ࡫ࡷࡩࡲ࠳ࡨࡦࡣࡧࡰ࡮ࡴࡥࠣ࠰࠭ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩණ")).findall(content)
    l1lll1lllll11l1l11_nktv_ = l1lll1lllll11l1l11_nktv_[-1] if l1lll1lllll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠧࠨඬ")
    out=[]
    l1l1l11llll11l1l11_nktv_= content.find(l1l11ll11l1l11_nktv_ (u"ࠨࡑࡧࡧ࡮ࡴ࡫ࡪࠩත"))
    l1l1l1l1lll11l1l11_nktv_= content.find(l1l11ll11l1l11_nktv_ (u"ࠩࡇࡳࡩࡧࡪࠡࡱࡧࡧ࡮ࡴࡥ࡬ࠩථ"))
    l1l11lll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨද"),re.DOTALL).findall(content[l1l1l11llll11l1l11_nktv_:l1l1l1l1lll11l1l11_nktv_])
    for h,t in l1l11lll11l1l11_nktv_:
        t= l1lll1ll1ll11l1l11_nktv_(t.strip())
        t=re.sub(l1l11ll11l1l11_nktv_ (u"ࠫࠥ࠱ࠧධ"),l1l11ll11l1l11_nktv_ (u"ࠬࠦࠧන"),t)
        l1ll11l11ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"࡛࠭ࡴࡕࡠࠬࡡࡪࠫࠪ࡝ࡈࡩࡢ࠮࡜ࡥ࠭ࠬࠫ඲")).findall(t)
        l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠧࡩࡴࡨࡪࠬඳ")  : h.strip(),
            l1l11ll11l1l11_nktv_ (u"ࠨࡲ࡯ࡳࡹ࠭ප"): t,
            l1l11ll11l1l11_nktv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨඵ") : t,
            l1l11ll11l1l11_nktv_ (u"ࠪ࡭ࡲ࡭ࠧබ"):l1lll1lllll11l1l11_nktv_,
            l1l11ll11l1l11_nktv_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࠫභ"): int(l1ll11l11ll11l1l11_nktv_[0][0]) if l1ll11l11ll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠬ࠭ම"),
            l1l11ll11l1l11_nktv_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࠧඹ"): int(l1ll11l11ll11l1l11_nktv_[0][1]) if l1ll11l11ll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠧࠨය"),
            l1l11ll11l1l11_nktv_ (u"ࠨࡣ࡬ࡶࡪࡪࠧර") : l1l11ll11l1l11_nktv_ (u"ࠩࠪ඼")}
        out.append(l11111llll11l1l11_nktv_)
    return out
def l11lllll11l1l11_nktv_(out):
    l111111l1ll11l1l11_nktv_={}
    l11lll11ll11l1l11_nktv_ = [x.get(l1l11ll11l1l11_nktv_ (u"ࠪࡷࡪࡧࡳࡰࡰࠪල")) for x in out]
    for s in set(l11lll11ll11l1l11_nktv_):
        l111111l1ll11l1l11_nktv_[l1l11ll11l1l11_nktv_ (u"ࠫࡘ࡫ࡺࡰࡰࠣࠩ࠵࠸ࡤࠨ඾")%s]=[out[i] for i, j in enumerate(l11lll11ll11l1l11_nktv_) if j == s]
    return l111111l1ll11l1l11_nktv_
def l1l1l1lll11l1l11_nktv_(url=l1l11ll11l1l11_nktv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰࡮࡭ࡳࡵࡳࡵࡣࡦ࡮ࡦ࠴ࡰ࡭࠱ࡶࡩࡷ࡯ࡡ࡭ࡧ࠰ࡳࡳࡲࡩ࡯ࡧ࠲ࠫ඿")):
    content = l1lll11l1ll11l1l11_nktv_(url)
    l11111111ll11l1l11_nktv_=re.compile(l1l11ll11l1l11_nktv_ (u"࠭࠼ࡶ࡮ࠣ࡭ࡩࡃࠢࡴࡧࡵ࡭ࡪࡹ࠭࡭࡫ࡶࡸࠧࠦࡣ࡭ࡣࡶࡷࡂࠨࡦࡪ࡮ࡷࡩࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࠪව"),re.DOTALL).findall(content)
    l1l1111llll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠰ࡅࠩࠣ࡝࡟ࡶࡡࡴࠠ࡝ࡶࡠ࠮ࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠫࡀࠫࠥࠫශ")).findall(l11111111ll11l1l11_nktv_[0])
    out=[]
    for href,title in l1l1111llll11l1l11_nktv_:
        l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠨࡪࡵࡩ࡫࠭ෂ")  : href,
            l1l11ll11l1l11_nktv_ (u"ࠩࡳࡰࡴࡺࠧස"): l1l11ll11l1l11_nktv_ (u"ࠪࠫහ"),
            l1l11ll11l1l11_nktv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪළ") : l1lll1ll1ll11l1l11_nktv_(title),
            l1l11ll11l1l11_nktv_ (u"ࠬ࡯࡭ࡨࠩෆ"):l1l11ll11l1l11_nktv_ (u"࠭ࠧ෇")}
        out.append(l11111llll11l1l11_nktv_)
    return (out, (False,False))
def l1lllll1lll11l1l11_nktv_(m):
    return l1l11ll11l1l11_nktv_ (u"ࠧࡩࡴࡨࡪࡂࠨࠧ෈")+urllib.unquote(m.group(1))
def l1l11ll1ll11l1l11_nktv_(l1l111l1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠨࡨ࡬ࡰࡲ࠭෉"),l11ll1llll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼ්ࠫ")):
    label=[]
    value=[]
    if l1l111l1ll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠪࡪ࡮ࡲ࡭ࠨ෋"):
        content = l1lll11l1ll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯࡭࡬ࡲࡴࡹࡴࡢࡥ࡭ࡥ࠳ࡶ࡬࠰ࡨ࡬ࡰࡲࡿ࠭ࡰࡰ࡯࡭ࡳ࡫࠯ࠨ෌"))
        if l11ll1llll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ෍"):
            l11111111ll11l1l11_nktv_=re.compile(l1l11ll11l1l11_nktv_ (u"࠭࠼ࡶ࡮ࠣ࡭ࡩࡃࠢࡧ࡫࡯ࡸࡪࡸ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡺࠤࠣࡧࡱࡧࡳࡴ࠿ࠥࡪ࡮ࡲࡴࡦࡴࠣࡱࡺࡲࡴࡪࡲ࡯ࡩ࠲ࡹࡥ࡭ࡧࡦࡸࠥࡺࡥࡳ࡯࠰ࡰ࡮ࡹࡴࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࠬ෎"),re.DOTALL).findall(content)[0]
            value=re.compile(l1l11ll11l1l11_nktv_ (u"ࠧࡥࡣࡷࡥ࠲࡯ࡤ࠾ࠤࠫࡠࡩ࠱ࠩࠣࠩා")).findall(l11111111ll11l1l11_nktv_)
            label=re.compile(l1l11ll11l1l11_nktv_ (u"ࠨࡀࠫ࠲࠰ࡅࠩ࠽ࠩැ")).findall(l11111111ll11l1l11_nktv_)
            label[0]=l1l11ll11l1l11_nktv_ (u"ࠩࠪෑ")
        elif l11ll1llll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠪࡽࡪࡧࡲࠨි"):
            l11111111ll11l1l11_nktv_=re.compile(l1l11ll11l1l11_nktv_ (u"ࠫࡁࡻ࡬ࠡ࡫ࡧࡁࠧ࡬ࡩ࡭ࡶࡨࡶ࠲ࡿࡥࡢࡴࠥࠤࡨࡲࡡࡴࡵࡀࠦ࡫࡯࡬ࡵࡧࡵࠤࡲࡻ࡬ࡵ࡫ࡳࡰࡪ࠳ࡳࡦ࡮ࡨࡧࡹࠦࡴࡦࡴࡰ࠱ࡱ࡯ࡳࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱ࠭ී"),re.DOTALL).findall(content)[0]
            value=re.compile(l1l11ll11l1l11_nktv_ (u"ࠬࡪࡡࡵࡣ࠰࡭ࡩࡃࠢࠩ࡞ࡧ࠯࠮ࠨࠧු")).findall(l11111111ll11l1l11_nktv_)
            label=re.compile(l1l11ll11l1l11_nktv_ (u"࠭࠾ࠩ࠰࠮ࡃ࠮ࡂࠧ෕")).findall(l11111111ll11l1l11_nktv_)
        elif l11ll1llll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨූ"):
            l11111111ll11l1l11_nktv_=re.compile(l1l11ll11l1l11_nktv_ (u"ࠨ࠾ࡸࡰࠥ࡯ࡤ࠾ࠤࡩ࡭ࡱࡺࡥࡳ࠯ࡦࡳࡺࡴࡴࡳࡻࠥࠤࡨࡲࡡࡴࡵࡀࠦ࡫࡯࡬ࡵࡧࡵࠤࡲࡻ࡬ࡵ࡫ࡳࡰࡪ࠳ࡳࡦ࡮ࡨࡧࡹࠦࡴࡦࡴࡰ࠱ࡱ࡯ࡳࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱ࠭෗"),re.DOTALL).findall(content)[0]
            value=re.compile(l1l11ll11l1l11_nktv_ (u"ࠩࡧࡥࡹࡧ࠭ࡪࡦࡀࠦ࠭ࡢࡤࠬࠫࠥࠫෘ")).findall(l11111111ll11l1l11_nktv_)
            label=re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࡂ࠭࠴ࠫࡀࠫ࠿ࠫෙ")).findall(l11111111ll11l1l11_nktv_)
    elif l1l111l1ll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠫࡸ࡫ࡲࡪࡣ࡯ࠫේ"):
        pass
    return (label,value)
def l1lll1ll1ll11l1l11_nktv_(l1llll1llll11l1l11_nktv_):
    if isinstance(l1llll1llll11l1l11_nktv_, unicode):
        l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.encode(l1l11ll11l1l11_nktv_ (u"ࠬࡻࡴࡧ࠯࠻ࠫෛ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"࠭ࠦ࡭ࡶ࠾ࡦࡷ࠵ࠦࡨࡶ࠾ࠫො"),l1l11ll11l1l11_nktv_ (u"ࠧࠡࠩෝ"))
    s=l1l11ll11l1l11_nktv_ (u"ࠨࡌ࡬ࡒࡨࡠࡃࡴ࠹ࠪෞ")
    l1llll1llll11l1l11_nktv_ = re.sub(s.decode(l1l11ll11l1l11_nktv_ (u"ࠩࡥࡥࡸ࡫࠶࠵ࠩෟ")),l1l11ll11l1l11_nktv_ (u"ࠪࠫ෠"),l1llll1llll11l1l11_nktv_)
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠫࡡࡴࠧ෡"),l1l11ll11l1l11_nktv_ (u"ࠬ࠭෢")).replace(l1l11ll11l1l11_nktv_ (u"࠭࡜ࡳࠩ෣"),l1l11ll11l1l11_nktv_ (u"ࠧࠨ෤"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠨࠨࡱࡦࡸࡶ࠻ࠨ෥"),l1l11ll11l1l11_nktv_ (u"ࠩࠪ෦"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠪࠪࡶࡻ࡯ࡵ࠽ࠪ෧"),l1l11ll11l1l11_nktv_ (u"ࠫࠧ࠭෨")).replace(l1l11ll11l1l11_nktv_ (u"ࠬࠬࡡ࡮ࡲ࠾ࡵࡺࡵࡴ࠼ࠩ෩"),l1l11ll11l1l11_nktv_ (u"࠭ࠢࠨ෪"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠧࠧࡱࡤࡧࡺࡺࡥ࠼ࠩ෫"),l1l11ll11l1l11_nktv_ (u"ࠨࣵࠪ෬")).replace(l1l11ll11l1l11_nktv_ (u"ࠩࠩࡓࡦࡩࡵࡵࡧ࠾ࠫ෭"),l1l11ll11l1l11_nktv_ (u"ࠪࣗࠬ෮"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠫࠫࡧ࡭ࡱ࠽ࡲࡥࡨࡻࡴࡦ࠽ࠪ෯"),l1l11ll11l1l11_nktv_ (u"ࣹࠬࠧ෰")).replace(l1l11ll11l1l11_nktv_ (u"࠭ࠦࡢ࡯ࡳ࠿ࡔࡧࡣࡶࡶࡨ࠿ࠬ෱"),l1l11ll11l1l11_nktv_ (u"ࠧࣔࠩෲ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠨࠨࡤࡱࡵࡁࠧෳ"),l1l11ll11l1l11_nktv_ (u"ࠩࠩࠫ෴"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠪࡠࡺ࠶࠱࠱࠷ࠪ෵"),l1l11ll11l1l11_nktv_ (u"ࠫऊ࠭෶")).replace(l1l11ll11l1l11_nktv_ (u"ࠬࡢࡵ࠱࠳࠳࠸ࠬ෷"),l1l11ll11l1l11_nktv_ (u"࠭ऄࠨ෸"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠧ࡝ࡷ࠳࠵࠵࠽ࠧ෹"),l1l11ll11l1l11_nktv_ (u"ࠨउࠪ෺")).replace(l1l11ll11l1l11_nktv_ (u"ࠩ࡟ࡹ࠵࠷࠰࠷ࠩ෻"),l1l11ll11l1l11_nktv_ (u"ࠪऊࠬ෼"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠫࡡࡻ࠰࠲࠳࠼ࠫ෽"),l1l11ll11l1l11_nktv_ (u"ࠬटࠧ෾")).replace(l1l11ll11l1l11_nktv_ (u"࠭࡜ࡶ࠲࠴࠵࠽࠭෿"),l1l11ll11l1l11_nktv_ (u"ࠧङࠩ฀"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠨ࡞ࡸ࠴࠶࠺࠲ࠨก"),l1l11ll11l1l11_nktv_ (u"ࠩॅࠫข")).replace(l1l11ll11l1l11_nktv_ (u"ࠪࡠࡺ࠶࠱࠵࠳ࠪฃ"),l1l11ll11l1l11_nktv_ (u"ࠫॆ࠭ค"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠬࡢࡵ࠱࠳࠷࠸ࠬฅ"),l1l11ll11l1l11_nktv_ (u"࠭ॄࠨฆ")).replace(l1l11ll11l1l11_nktv_ (u"ࠧ࡝ࡷ࠳࠵࠹࠺ࠧง"),l1l11ll11l1l11_nktv_ (u"ࠨॅࠪจ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠩ࡟ࡹ࠵࠶ࡦ࠴ࠩฉ"),l1l11ll11l1l11_nktv_ (u"ࠪࣷࠬช")).replace(l1l11ll11l1l11_nktv_ (u"ࠫࡡࡻ࠰࠱ࡦ࠶ࠫซ"),l1l11ll11l1l11_nktv_ (u"ࠬࣙࠧฌ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"࠭࡜ࡶ࠲࠴࠹ࡧ࠭ญ"),l1l11ll11l1l11_nktv_ (u"ࠧड़ࠩฎ")).replace(l1l11ll11l1l11_nktv_ (u"ࠨ࡞ࡸ࠴࠶࠻ࡡࠨฏ"),l1l11ll11l1l11_nktv_ (u"ࠩढ़ࠫฐ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠪࡠࡺ࠶࠱࠸ࡣࠪฑ"),l1l11ll11l1l11_nktv_ (u"ࠫॿ࠭ฒ")).replace(l1l11ll11l1l11_nktv_ (u"ࠬࡢࡵ࠱࠳࠺࠽ࠬณ"),l1l11ll11l1l11_nktv_ (u"࠭ॹࠨด"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠧ࡝ࡷ࠳࠵࠼ࡩࠧต"),l1l11ll11l1l11_nktv_ (u"ࠨॾࠪถ")).replace(l1l11ll11l1l11_nktv_ (u"ࠩ࡟ࡹ࠵࠷࠷ࡣࠩท"),l1l11ll11l1l11_nktv_ (u"ࠪॿࠬธ"))
    return l1llll1llll11l1l11_nktv_
def search(l1llll1llll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠫ࡮ࡴࡤࡪࡣࡱࡥ࠰ࡰ࡯ࠨน")):
    url=l1l11ll11l1l11_nktv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰࡮࡭ࡳࡵࡳࡵࡣࡦ࡮ࡦ࠴ࡰ࡭࠱ࡺࡽࡸࢀࡵ࡬࡫ࡺࡥࡷࡱࡡࡀࡲ࡫ࡶࡦࡹࡥ࠾ࠩบ")+l1llll1llll11l1l11_nktv_
    content=l1lll11l1ll11l1l11_nktv_(url)
    l1l111ll1ll11l1l11_nktv_=[]
    l1l11l11lll11l1l11_nktv_=[]
    ids = [(a.start(), a.end()) for a in re.finditer(l1l11ll11l1l11_nktv_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡬࠮ࡵࡰ࠱ࡡࡪࠫࠨป"), content)]
    ids.append( (-1,-1) )
    for i in range(len(ids[:-1])):
        l111l1llll11l1l11_nktv_ = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile(l1l11ll11l1l11_nktv_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩผ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        title = re.compile(l1l11ll11l1l11_nktv_ (u"ࠨࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨฝ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        l1llll11lll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠠࡵࡧࡻࡸ࠲ࡰࡵࡴࡶ࡬ࡪࡾࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧพ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        l1lll1lllll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨฟ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        l1111111ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠫࡁ࠵ࡢ࠿࡞ࡶ࠮࠭ࡢࡤ࡝࠰࡟ࡨ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭ภ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        year =  re.compile(l1l11ll11l1l11_nktv_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡽࡪࡧࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩม"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        if href and title:
            l1lll1lllll11l1l11_nktv_ = l1lll1lllll11l1l11_nktv_.group(1).replace(l1l11ll11l1l11_nktv_ (u"࠭࠯ࡵࡪࡸࡱࡧ࠵ࠧย"),l1l11ll11l1l11_nktv_ (u"ࠧ࠰ࡤ࡬࡫࠴࠭ร")) if l1lll1lllll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠨࠩฤ")
            l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠩ࡫ࡶࡪ࡬ࠧล")   : href.group(1),
                l1l11ll11l1l11_nktv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩฦ")  : l1lll1ll1ll11l1l11_nktv_(title.group(1)),
                l1l11ll11l1l11_nktv_ (u"ࠫࡵࡲ࡯ࡵࠩว")   : l1lll1ll1ll11l1l11_nktv_(l1llll11lll11l1l11_nktv_.group(1)) if l1llll11lll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠬ࠭ศ"),
                l1l11ll11l1l11_nktv_ (u"࠭ࡩ࡮ࡩࠪษ")    : l1lll1lllll11l1l11_nktv_,
                l1l11ll11l1l11_nktv_ (u"ࠧࡳࡣࡷ࡭ࡳ࡭ࠧส") : l1111111ll11l1l11_nktv_.group(1) if l1111111ll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠨࠩห"),
                l1l11ll11l1l11_nktv_ (u"ࠩࡼࡩࡦࡸࠧฬ")   : year.group(1) if year else l1l11ll11l1l11_nktv_ (u"ࠪࠫอ"),
                    }
            if l1l11ll11l1l11_nktv_ (u"ࠫ࠴࡬ࡩ࡭࡯࠰ࡳࡳࡲࡩ࡯ࡧ࠲ࠫฮ") in l11111llll11l1l11_nktv_[l1l11ll11l1l11_nktv_ (u"ࠬ࡮ࡲࡦࡨࠪฯ")]:
                l1l111ll1ll11l1l11_nktv_.append(l11111llll11l1l11_nktv_)
            elif l1l11ll11l1l11_nktv_ (u"࠭ࡳࡦࡴ࡬ࡥࡱ࠳࡯࡯࡮࡬ࡲࡪ࠭ะ")in l11111llll11l1l11_nktv_[l1l11ll11l1l11_nktv_ (u"ࠧࡩࡴࡨࡪࠬั")]:
                l1l11l11lll11l1l11_nktv_.append(l11111llll11l1l11_nktv_)
    return l1l111ll1ll11l1l11_nktv_,l1l11l11lll11l1l11_nktv_
