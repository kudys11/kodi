# -*- coding: utf-8 -*-
import sys
l1111ll11l1l11_nktv_ = sys.version_info [0] == 2
l111ll11l1l11_nktv_ = 2048
l1l1lll11l1l11_nktv_ = 7
def l1l11ll11l1l11_nktv_ (keyedStringLiteral):
	global l11llll11l1l11_nktv_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1111ll11l1l11_nktv_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os,json,base64
import l1lll1l1lll11l1l11_nktv_,cookielib
from urlparse import urlparse
l1ll1l11lll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡴࡡࡴࡼࡨ࠱ࡰ࡯࡮ࡰ࠰ࡷࡺ࠴࠭౒")
l1111lllll11l1l11_nktv_ = 10
l1ll11ll1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠹࠾࠮࠱࠰࠵࠹࠻࠺࠮࠺࠹ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪ౓")
try:
    import l11l111lll11l1l11_nktv_
except:
    pass
l11ll1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࡸࠧ࡯࡭ࡷࡺ࠳ࡩ࡯ࡰ࡭࡬ࡩࠬ౔")
l1ll1l1l1ll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠧࠨౕ")
def l1lll11l1ll11l1l11_nktv_(url,data=None,header={}):
    cookies=l1l11ll11l1l11_nktv_ (u"ࠨౖࠩ")
    l1ll11l1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠩࠪ౗")
    l111l1l1ll11l1l11_nktv_ = cookielib.LWPCookieJar()
    try:
        if l11ll1ll11l1l11_nktv_ and os.path.exists(l11ll1ll11l1l11_nktv_):
            l111l1l1ll11l1l11_nktv_.load(l11ll1ll11l1l11_nktv_,True,True)
            cookies = l1l11ll11l1l11_nktv_ (u"ࠪ࠿ࠬౘ").join([l1l11ll11l1l11_nktv_ (u"ࠫࠪࡹ࠽ࠦࡵࠪౙ")%(c.name,c.value) for c in l111l1l1ll11l1l11_nktv_])
    except:
        l111l1l1ll11l1l11_nktv_ = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l111l1l1ll11l1l11_nktv_))
    urllib2.install_opener(opener)
    headers={l1l11ll11l1l11_nktv_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩౚ"): l1ll11ll1ll11l1l11_nktv_}
    headers.update(header)
    req = urllib2.Request(url,data,headers)
    if cookies:
        req.add_header(l1l11ll11l1l11_nktv_ (u"ࠨࡃࡰࡱ࡮࡭ࡪࠨ౛"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l1111lllll11l1l11_nktv_)
        l1ll11l1ll11l1l11_nktv_ = response.read()
        response.close()
        l111l1l1ll11l1l11_nktv_.save(l11ll1ll11l1l11_nktv_, ignore_discard = True)
    except:
        pass
    return l1ll11l1ll11l1l11_nktv_
def l1ll1lll1ll11l1l11_nktv_(url,l1lll11llll11l1l11_nktv_):
    l111l1l1ll11l1l11_nktv_ = cookielib.LWPCookieJar()
    try:
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l111l1l1ll11l1l11_nktv_))
        urllib2.install_opener(opener)
        req = urllib2.Request(url,None,{l1l11ll11l1l11_nktv_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ౜"): l1ll11ll1ll11l1l11_nktv_})
        response = urllib2.urlopen(req,timeout=l1111lllll11l1l11_nktv_)
        l11lllll1ll11l1l11_nktv_ = response.headers[l1l11ll11l1l11_nktv_ (u"ࠨࡵࡨࡸ࠲ࡩ࡯ࡰ࡭࡬ࡩࠬౝ")]
        response.close()
        l11l11l1ll11l1l11_nktv_=os.path.dirname(l1lll11llll11l1l11_nktv_)
        if not os.path.exists(l11l11l1ll11l1l11_nktv_):
            os.makedirs(l11l11l1ll11l1l11_nktv_)
        if l111l1l1ll11l1l11_nktv_:
            l111l1l1ll11l1l11_nktv_.save(l1lll11llll11l1l11_nktv_, ignore_discard = True)
    except:
        l11lllll1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠩࠪ౞")
    return l111l1l1ll11l1l11_nktv_
def l1ll1ll1ll11l1l11_nktv_(url,l1l11llll11l1l11_nktv_=1,group=l1l11ll11l1l11_nktv_ (u"ࠪࠫ౟")):
    if l1l11ll11l1l11_nktv_ (u"ࠫࡄࡶࡡࡨࡧࡀࠫౠ") in url:
        url = url.replace(l1l11ll11l1l11_nktv_ (u"ࠬࡅࡰࡢࡩࡨࡁࠬౡ"),l1l11ll11l1l11_nktv_ (u"࠭࠿ࡱࡣࡪࡩࡂࠫࡤࠨౢ") %l1l11llll11l1l11_nktv_)
    else:
        url += l1l11ll11l1l11_nktv_ (u"ࠧ࠰ࠩౣ") if url[-1] != l1l11ll11l1l11_nktv_ (u"ࠨ࠱ࠪ౤") else l1l11ll11l1l11_nktv_ (u"ࠩࠪ౥")
        url = url + l1l11ll11l1l11_nktv_ (u"ࠪࡃࡵࡧࡧࡦ࠿ࠨࡨࠬ౦") %l1l11llll11l1l11_nktv_
    if group:
        url=url.split(l1l11ll11l1l11_nktv_ (u"ࠫࡄ࠭౧"))[0]
    content = l1lll11l1ll11l1l11_nktv_(url)
    out=[]
    l1ll1ll11ll11l1l11_nktv_=False
    l11111l1ll11l1l11_nktv_=False
    ids = []
    if group:
        idx = [(m.start(0), m.end(0)) for m in re.finditer(l1l11ll11l1l11_nktv_ (u"ࠬࡂࡨ࠴ࡀࠪ౨"), content,re.IGNORECASE) ]
        idx.append( (content.find(l1l11ll11l1l11_nktv_ (u"࠭࠼ࡧࡱࡲࡸࡪࡸ࠾ࠨ౩")),content.find(l1l11ll11l1l11_nktv_ (u"ࠧ࠽ࡨࡲࡳࡹ࡫ࡲ࠿ࠩ౪"))) )
        for i in range(len(idx[:-1])):
            l1ll111llll11l1l11_nktv_=content[ idx[i][0]:idx[i+1][0] ]
            if group in l1ll111llll11l1l11_nktv_:
                content = l1ll111llll11l1l11_nktv_
                ids = [(a.start(), a.end()) for a in re.finditer(l1l11ll11l1l11_nktv_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡣࡰ࡮࠰ࡼࡸ࠳࡜ࡥ࠭ࠪ౫"), content)]
                ids.append( (-1,-1) )
                break
        for i in range(len(ids[:-1])):
            l111l1llll11l1l11_nktv_ = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile(l1l11ll11l1l11_nktv_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ౬"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
            title = re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ౭"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
            l1lll1lllll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠫࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ౮"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
            l1111111ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡶࡦࡺࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ౯"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
            year =  re.compile(l1l11ll11l1l11_nktv_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡾ࡫ࡡࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ౰"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
            if href and title:
                l1lll1lllll11l1l11_nktv_ = l1lll1lllll11l1l11_nktv_.group(1) if l1lll1lllll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠧࠨ౱")
                if l1lll1lllll11l1l11_nktv_.startswith(l1l11ll11l1l11_nktv_ (u"ࠨ࠱࠲ࠫ౲")):
                    l1lll1lllll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ౳")+l1lll1lllll11l1l11_nktv_
                l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠪ࡬ࡷ࡫ࡦࠨ౴")   : href.group(1),
                    l1l11ll11l1l11_nktv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ౵")  : l1lll1ll1ll11l1l11_nktv_(title.group(1)),
                    l1l11ll11l1l11_nktv_ (u"ࠬ࡯࡭ࡨࠩ౶")    : l1lll1lllll11l1l11_nktv_,
                    l1l11ll11l1l11_nktv_ (u"࠭ࡲࡢࡶ࡬ࡲ࡬࠭౷") : l1111111ll11l1l11_nktv_.group(1) if l1111111ll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠧࠨ౸"),
                    l1l11ll11l1l11_nktv_ (u"ࠨࡻࡨࡥࡷ࠭౹")   : year.group(1) if year else l1l11ll11l1l11_nktv_ (u"ࠩࠪ౺"),
                        }
                out.append(l11111llll11l1l11_nktv_)
    else:
        l1l1llllll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࡀࡺࡲࠠࡤ࡮ࡤࡷࡸࡃ࡛ࠣ࡞ࠪࡡࡨࡲࡥࡢࡴࡩ࡭ࡽࠦࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰ࡞ࠦࡡ࠭࡝࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ౻"),re.DOTALL).findall(content)
        l1l1llllll11l1l11_nktv_ = urllib.unquote(l1l1llllll11l1l11_nktv_[0]) if l1l1llllll11l1l11_nktv_ else content
        l1ll1ll11ll11l1l11_nktv_=False
        if l1l1llllll11l1l11_nktv_.find( l1l11ll11l1l11_nktv_ (u"ࠫࡄࡶࡡࡨࡧࡀࠩࡩ࠭౼") %(l1l11llll11l1l11_nktv_+1))>-1:
            l1ll1ll11ll11l1l11_nktv_ = l1l11llll11l1l11_nktv_+1
        idx = content.find(l1l11ll11l1l11_nktv_ (u"ࠬࡂࡨ࠴ࡀࠪ౽"))
        if idx: content = content[0:idx]
        ids = [(a.start(), a.end()) for a in re.finditer(l1l11ll11l1l11_nktv_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡬࠮ࡺࡶ࠱ࡡࡪࠠࡤࡱ࡯࠱ࡸࡳ࠭࡝ࡦࠣࡧࡴࡲ࠭࡭ࡩ࠰ࡠࡩ࠭౾"), content)]
        ids.append( (-1,-1) )
        for i in range(len(ids[:-1])):
            l111l1llll11l1l11_nktv_ = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile(l1l11ll11l1l11_nktv_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ౿"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
            title = re.compile(l1l11ll11l1l11_nktv_ (u"ࠨࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨಀ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
            l1lll1lllll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠩ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬಁ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
            l1111111ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡴࡤࡸࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬಂ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
            year =  re.compile(l1l11ll11l1l11_nktv_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡼࡩࡦࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨಃ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
            if href and title:
                l1lll1lllll11l1l11_nktv_ = l1lll1lllll11l1l11_nktv_.group(1) if l1lll1lllll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠬ࠭಄")
                if l1lll1lllll11l1l11_nktv_.startswith(l1l11ll11l1l11_nktv_ (u"࠭࠯࠰ࠩಅ")):
                    l1lll1lllll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠧࡩࡶࡷࡴ࠿࠭ಆ")+l1lll1lllll11l1l11_nktv_
                l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠨࡪࡵࡩ࡫࠭ಇ")   : href.group(1),
                    l1l11ll11l1l11_nktv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨಈ")  : l1lll1ll1ll11l1l11_nktv_(title.group(1)),
                    l1l11ll11l1l11_nktv_ (u"ࠪ࡭ࡲ࡭ࠧಉ")    : l1lll1lllll11l1l11_nktv_,
                    l1l11ll11l1l11_nktv_ (u"ࠫࡷࡧࡴࡪࡰࡪࠫಊ") : l1111111ll11l1l11_nktv_.group(1) if l1111111ll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠬ࠭ಋ"),
                    l1l11ll11l1l11_nktv_ (u"࠭ࡹࡦࡣࡵࠫಌ")   : year.group(1) if year else l1l11ll11l1l11_nktv_ (u"ࠧࠨ಍"),
                        }
                out.append(l11111llll11l1l11_nktv_)
        l11111l1ll11l1l11_nktv_ = l1l11llll11l1l11_nktv_-1 if l1l11llll11l1l11_nktv_>1 else False
    return (out, (l11111l1ll11l1l11_nktv_,l1ll1ll11ll11l1l11_nktv_))
def l111l111ll11l1l11_nktv_(url):
    content = l1lll11l1ll11l1l11_nktv_(url)
    token = re.search(l1l11ll11l1l11_nktv_ (u"ࠨࡰࡤࡱࡪࡃࠢࡠࡶࡲ࡯ࡪࡴࠢࠡࡶࡼࡴࡪࡃࠢࡩ࡫ࡧࡨࡪࡴࠢࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠩಎ"),content).group(1)
    l1ll1llllll11l1l11_nktv_ = re.search(l1l11ll11l1l11_nktv_ (u"ࠩࡶ࡭ࡹ࡫࡫ࡦࡻ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬಏ"),content).group(1)
    params = {l1l11ll11l1l11_nktv_ (u"ࠪࡣࡹࡵ࡫ࡦࡰࠪಐ"):l1l11ll11l1l11_nktv_ (u"ࠫࡒ࡭࡚ࡎࡄ࠴࡛࡫࠺ࡕࡃࡉࡳ࡬࡞ࡌ࠱ࡪ࠸࠶ࡱࡔ࠺࠶࠸ࡹࡻࡋ࠽࡙࠵࡬࠷ࡦ࡯ࡵ࠺ࡍࡐ࡬ࠪ಑"),
            l1l11ll11l1l11_nktv_ (u"ࠬ࡭࠭ࡳࡧࡦࡥࡵࡺࡣࡩࡣ࠰ࡶࡪࡹࡰࡰࡰࡶࡩࠬಒ"):l1l11ll11l1l11_nktv_ (u"࠭࠰࠴ࡃࡋࡎࡤ࡜ࡵࡷࡹࡺ࡯ࡐࡌ࠱ࡊ࠻ࡏࡒ࡭࡛ࡒࡓࡵࡓࡎࡸࡗࡏ࠶ࡡࡖࡰࡍࡷࡇࡲࡘ࠼ࡦࡴࡸࡂࡢࡗ࡚ࡵࡲࡴࡱࡏࡆࡩࡵࡍ࠷ࡰࡕࡋࡓࡽࡲࡷࡕࡸࡎࡏ࡯࡯࠺ࡸࡩ࠸ࡱ࡛࡬ࡇ࡭ࡃࡰࡺ࡚ࡨࡠࡂࡗࡷࡪࡱࡒࡐࡩࡗࡥࡳࡐ࠻࠳ࡔ࠳ࡥࡍࡋࡺ࠻ࡦࡅࡍࡰࡉࡸࡾࡡ࡛ࡵ࠴ࡓࡖࡍࡑࡹࡲ࠻ࡸࡔࡸ࠲࡚ࡲࡤ࡚ࡨࡇࡖࡱࡧࡓࡩࡹࡗ࡬ࡃࡘ࠳ࡽࡆ࠾ࡧࡕࡅࡔࡧࡵࡳ࡮ࡧ࡛ࡧࡓࡘࡩࡑ࡬ࡺࡘ࠽ࡴࡥࡳ࠶ࡓ࠷ࡷ࡯ࡖ࠴ࡉࡱࡹ࠶ࡖࡨࡢࡩࡉ࡙࠽ࡘࡏ࠴ࡐ࠺ࡤ࠱࡛ࡘࡁࡗ࡚ࡵ࡙ࡿࡶࡦ࠷ࡺࡼࡹࡪࡼ࡙ࡴࡷ࡛࠷ࡍࡾࡈࡢࡡࡅࡷ࡞ࡗࡃ࠺ࡗ࠺ࡈ࡝࠶ࡪࡧ࡬ࡅࡎࡉࡳࡩ࡭ࡌࡤࡦ࠻࡛ࡄࡓࡦ࡙ࡇࡱ࡫ࡇ࠮࡬ࡉࡻ࠼ࡘࡋࡱ࠹࠸࡙࡚࡮࡬ࡻ࡚ࡄࡐࡔࡌ࡯ࡩ࠵ࡌ࡛ࡦࡠࡗ࠺࡬ࡏࡩ࠵ࡌ࠳࡮ࡘࡨࡱ࡛࡚ࡑ࠮࠳࠶ࡴ࠵ࡕࡁࡺࡰࡺࡹࡴࡇࡔ࡛࡙ࡉࡸ࡭ࡋࡌ࠹ࡅ࠳ࡒࡐࡓࡕࡣࡦ࡙࡫࠺ࡪ࠭ࡠ࠸࠵࠼ࡰࡥࡂࡸࡆ࠴ࡖ࠻ࡑࡤ࠵࡚࡭ࡹࡆ࠿ࡦ࡭ࡓࡆࡉࡒ࡭ࡕ࠶ࡪࡽࡐࡲ࠾ࡒࡠࡍ࠶ࡊࡐࡧࡆ࡬ࡒࡳ࡭ࡺ࡛ࡓ࠴࡯ࡵ࠱ࡹ࡞ࡺ࠸ࡸࡶࡸࡑ࠿ࡂࡊࡒ࡛࡮ࡖࡽ࠶࠹࡛࠴ࡹࡲࡱ࡟࠸ࡴࡔࡺࡐࡐࡧࡊࡓࡄ࠶ࡓ࡬ࡢ࠶ࡹࡤࡘࡆࡊࡆ࠲ࡩࡤࡇࡺࡹ࡙ࡎ࠶ࡧ࠵࠹ࡔࡈ࠺ࡈ࠸࠶ࡰࡋ࠴࡭ࡴࡧࡦࡦ࡟࠲ࡖࡕ࠼ࡹ࡮ࡔࡃࡲࡇࡩ࡝࡭ࡇࡣࡻ࡚ࡼࡊ࡬ࡾࡸࡲࡄࡍ࠹࠽ࡈ࠶ࡑࡒࡽ࠴ࡰ࠹ࡍ࠸࠯࡛ࡵ࡟࡙ࡴࡑࡼࡤࡑࡕ࠺ࡍࡅࡔࡉࡶ࠹ࡿࡵࡋ࠳ࡄࡲ࠼ࡪ࡯࡯࠶࡬ࡱ࠻࠿ࡣࡐ࠺ࡳࡇ࠵ࡿࡶࡨࡣࡼ࡛ࡽࡹࡡ࡭ࡏ࠻ࡎࡑࡉࡄࡪࡖ࠺࡚ࡲ࡙࡫ࡢ࠹࠻ࡋ࡞ࡪ࠰ࡃࡦࡺࡗࡤࡪࡃ࠲ࡖࡻࡘ࡮ࡱࡨࡗ࠺ࡦࡌ࠾ࡧࡤࡋ࡚࡜࠹ࡆࡺࡃࡋࡅࡌ࠶ࡪࡰࡴࡂࡥࡦࡽ࡞࠻ࡩࡺࡥ࡬ࡩ࠲ࢀࡶࡏ࡜ࡨ࡮ࡻࡧࡃ࠹ࡉ࡜ࡍ࡫ࡽࡋࡏࡧ࡜ࡅ࠸࡜ࡩ࠷࠲ࡪ࡝ࡓ࡭ࡉࡦࡸ࠵ࡥ࠺࡛ࡍࡊࡓ࡝ࡪ࡞࠺ࡺࡘࡨࡢࡴ࡯ࡹ࠸ࡕ࠹ࡺࡈࡑࡷࡲ࠱࠺࡮ࡖࡍࡺࡒ࠸ࡪࡼࡦࡲࡳࡋࡴࡸ࡜ࡻࡌࡌ࡫ࡪࡆࡐࡺࡪ࡫ࡱࡒࡺ࠰ࡺࡿ࡜ࡄ࠵ࡥ࠼ࡸࡪ࠽࠹࡛ࡲࡒࡹࡗ࡙࡭ࡂࡐ࠻࡭࡮࠸ࡁࡳࡦ࡜ࡌ࡜ࡨ࡟ࡎ࠸࠼ࡥ࠵ࡎࡦࡧࡣࡪࡾࡕࡺࡕ࠹ࡏࡆࡧ࠻ࡒࡷࡶ࠺ࡗ࠺࠺ࡽ࠱ࡹࡳ࠺ࡍࡑࡴࡑࡓࡱࡦࡧࡵࡶࡍࡸࡅ࠼ࡆ࠽࡚࠸࡭ࡼࡧࡍࡶ࡙࠲ࡺࡎࡆࡷ࡬ࡑࡸࡻࡥࡏࡊࡔ࡫ࡱࡱࡶࡢࡕࡆࡏࡤࡏࡩ࡬ࡦࡾࡌ࠳ࡲ࠹ࡇ࡞ࡪࡩ࡬࠵࠳ࡵ࠶࡭ࡾࡎ࡬ࡊࡳ࠺ࡲ࡚࠱࡬࡬࡮ࡇ࠽࡭ࡷࡻࡅࡥ࡫ࡻࡐࡁࡰࡳ࠺ࡾࡺࡠࡕ࡙ࡸࡲࡕࡈࡻࡅࡆࡗࡑࡅࡺࡩࡉࡵࡊࡐ࠽࡚ࡩࡍࡅࡓ࠷࡭ࡒ࡟ࡐࡸࡄ࡚ࡦࡸ࡛ࡦࡦࡼࡄࡆ࡮ࡕࡗ࡯ࡧ࠳ࡊ࠼ࡗࡑࡤࡇࡢࡏ࡛࡟࠴ࡺࡇ࠷ࡖࡋ࡙ࡅ࡯ࡶ࡚ࡰ࠾ࡴࡹࡺ࡚࠼ࡓ࠷ࡕ࡙࠷ࡪࡈ࡭࠷࡫࠱ࡈ࠷ࡅࡅࡪ࡞ࡄࡠ࠳ࡼ࡭ࡑ࠿ࡳ࠮ࡵ࠹࠼ࡵࡲࡩ࡬ࡈࡉࡣࡱࡈࡲࡒ࡛࠳ࡺࡨࡧࡐ࡯ࡏ࠹࠽ࡖ࡙ࡦ࡯ࡴࡘࡅࡳࡌ࠵ࡩ࠹ࡅࡋࡼࡲࡔ࡬ࡳࡅ࡫ࡱࡽ࠶࠳ࡷࡒࡻ࠺ࡖ࡮࠳࡭ࡷࡽ࡬ࡘࡐ࠮ࡄࡗࡘࡵ࡭ࡕࡹࡘࡤ࠴࡫ࡺࡨࡹࡇ࡭ࡖࡤ࠹࠱ࡗࡅࡘࡺࡇࡳࡄ࠴ࡰࡺࡺ࡮ࡕࡏࡂࡔࡅ࡯ࡓࡾࡷࡻࡐࡏࡺࡿࡈ࠭ࡍࡊࡔ࠸ࡎࡽࡴ࠹ࡔ࡚࡚࡯࠷ࡈࡅ࠴࠵ࡕ࡞ࡇࡗ࡫ࡈࡗࡌ࡚ࡠࡎࡎ࡛ࡲ࡫࠸ࡸࡆࡓ࠳࠴࡜࡮࠸࡟࠸ࡈࡘࡧ࡚ࡩࡏࡈࡈࡐࡾࡿࡱࡃ࡮ࡋࡲࡪࡵ࡞࠸࠲࠵࡯࡯࠺ࡪࡥࡅ࡯ࡋ࡭࡛ࢀ࡯ࡏ࡚ࡪ࠶ࡺࡘࡩࡢࡆࡍࡵࡩࡊࡧ࡭ࡶࡗ࠻࠽ࡇࡨࡎࡕࡉࡑ࡟࡮࡯ࡎ࡫ࡰࡎ࡚ࡼࡈ࡭ࡷࡸࡆ࠵࠿ࡉࡇࡅ࡮ࡉ࠵ࡓ࡟࠷ࡦࡽࡔࡾ࡯࠲࠴ࡩ࡬ࡨ࡟ࡘࡪ࡚ࡱࡧ࠼ࡵࡷࡖ࠳࠲ࡊ࠸࡞࠷ࡢࡄ࠸࡝ࡾࡹࡺ࡬ࡅࡤࡦࡖࡨࡩࡄࡧࡍࡤࡨࡨࡐࡵ࠺ࡇࡳࡋࡒࡩࡖࡍࡓࡱࡲࡇࢀࡳࡦࡖࡖ࠴ࡈࡍ࡭࠹ࡐ࠴ࡒࡱࡻࡄࡤ࡬ࡐ࡬ࡼࡴࡺ࡮࠺ࡷࡩ࡙ࡐࡉࡦࡩࡨࡷ࡮ࡶࡳࡉ࠹ࡔ࡞࠽࡛ࡹࡧࡩࡦࡽࡋࡖࡤ࠱࠯࠻ࡧࡔࡱ࡫࡮ࡍࡪࡰࡪࡋࡕࡅࡘ࡛ࡇࡹࡇ࡫࡛ࡕࡥ࡝࡙࠶࠳ࡔ࠯ࡷ࡙ࡶࡑࡸࡪ࡭ࡔ࠻ࡖࡾࡊࡐࡇ࡙ࡶࡍࡓ࠰࡚࠷ࡺ࡚࡯ࡒࡎࡕࡵ࠳ࡘ࡜ࡌࡕࡆࡆࡈࡳ࠺࡯ࡘࡷ࠯࠹ࡵࡼ࠿࠸ࡻࡷ࠹ࡽ࡮࡝ࡩࡒ࠴ࡳࡊࡧ࠽ࡓࡣࡺࡹࡪࡲ࡞ࡨࡌ࠵ࡴࡊ࡜ࡼ࡫ࡖࡅ࡯ࡼ࡯࡭ࡂࡩ࠹࡮࡚ࡺ࠻ࡴ࡬࡭ࡇࡒ࠵࠷࠱ࡔࡄ࠸ࡖࡪࡵࡃࡋࡷࡏࡨ࡫ࡎࡌࡵࡑ࡫࠶ࡋࡷ࡚࠳ࡹ࠺ࡔ࡭ࡍࡋࡃ࡬ࡨࡺࡩࡇࡌ࠳ࡨࡆࡖࡊ࡮ࡘ࠲ࡌࡷ࡝ࡓ࠾ࡹࡂࡗ࡬ࡔࡓࡰࡸ࡬ࡃࡅࡸࡆࡨ࡭ࡺࡎ࠺ࡷ࠲ࡑࡰ࠳࡙ࡥࡺࡻࡘࡱࡍ࠶࠶࠹࠼ࡺࡔ࠷࡯ࡑ࡜ࡈࡷࡧ࠮ࡨࡱࡑ࠶࡯ࡑ࠺ࡱ࡜ࡅࡹࡖࡩ࡮ࡌࡲࡨࡻࡊ࠸࡛ࡅࡎ࡝࠺ࡈ࠹࡮ࡥ࠶ࡥࡔࡻࡄࡊࡓࡽࡺ࠻ࡒࡔࡠࡱࡳࡩࡻ࡜ࡡ࠺࠹ࡲࡊ࠵ࡲࡥࡥ࡫ࡘ࠼࡬ࡕ࠶࠴ࡇࡸࡵࡲ࠼ࡧࡊ࠷ࡎ࠴࡯࠻ࡖࡑࡧ࡙ࡺࡵࡩ࠰ࡻࡻࡤ࡝࡛࡞ࡆ࠺ࡶࡻ࠹ࡖࢀࡆࡌࡶࡒࡉࡆࡉ࡟ࡌࡣࡗ࡬࠲࡙ࡵ࠸ࡗࡍࡲ࡜࠺ࡑࡣࡊࡘ࡭࠾ࡖ࡬ࡴࡩࡪࡕࡕ࠶ࡊࡂ࠷࠹ࡣ࡬࡮ࡔࡐ࠺ࡅ࡮ࡕ࡟࠲ࡶ࠺ࡎ࠽࠾ࡎࡄࡩࡡࡧࡴ࠹ࡋࡢ࠲ࡇ࠳ࡘ࠾ࡇ࠱ࡹࡶࡽࡶࡧ࡞࠳࡛ࡩࡉ࠴࠺ࡽࡃࡆࡌࡨ࠹ࡑࡳ࠲ࡲ࡚࠳࡙ࡩࡠࡘࡺࡡࡄ࡚ࡺࡷ࠷ࡔ࠵ࡈࡑ࠸ࡓࡪࡩࡌࡌ࡞࠲ࡑࡢ࡫ࡧ࠺ࡔࡴ࡬ࡱ࡭ࡺࡊࡱ࠵࠿ࡉࡩࡌࡻࡖࡨࡪࡅ࠵࡬࡛࡞࡬ࡸ࡬ࡥ࠹ࡤࡔ࡭ࡼ࠰ࡃࡖ࠴ࡕ࠾࠷ࡄ࡙ࡴࡕ࠼ࡱࡒࡴ࡚࠸ࡑࡖࡇࡹ࡚ࡧ࡭࡫࠽ࡓ࠭ಓ")
           }
    data=urllib.urlencode(params)
    a=l1lll11l1ll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡰࡷࡲ࠲࡮ࡵ࠯ࡨࡱ࠲ࡊࡰࡨࡣࡶࠩಔ"),data)
def _1llll1l1ll11l1l11_nktv_(url,host=l1l11ll11l1l11_nktv_ (u"ࠨࠩಕ")):
    l1111l11ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠩࠪಖ")
    if url.startswith(l1l11ll11l1l11_nktv_ (u"ࠪ࡬ࡹࡺࡰࠨಗ")):
        if l1l11ll11l1l11_nktv_ (u"ࠫࡱ࡯࡮࡬࡫࠱ࡳࡳࡲࡩ࡯ࡧࠪಘ") in url:
            content = l1lll11l1ll11l1l11_nktv_(url)
            l1l1l1l1ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠬࡺ࡯ࡱ࠰࡯ࡳࡨࡧࡴࡪࡱࡱࠤࡂ࡛ࠦ࡝ࠩࠥࡡ࠭࠴ࠪࡀࠫ࡞ࡠࠬࠨ࡝࠼ࠩಙ")).search(content)
            if l1l1l1l1ll11l1l11_nktv_:
                l1111l11ll11l1l11_nktv_ = l1l1l1l1ll11l1l11_nktv_.group(1)
        if l1l11ll11l1l11_nktv_ (u"࠭࡯ࡶࡱ࠱࡭ࡴ࠭ಚ") in url:
            l1111l11ll11l1l11_nktv_ = url
        else:
            req = urllib2.Request(url)
            req.add_header(l1l11ll11l1l11_nktv_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫಛ"), l1l11ll11l1l11_nktv_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠵࠺࠱࠴࠳࠸࠵࠷࠶࠱࠽࠼ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ಜ"))
            try:
                response = urllib2.urlopen(req)
                if response:
                    l1111l11ll11l1l11_nktv_=response.url
                    if l1111l11ll11l1l11_nktv_==url:
                        content=response.read()
                        l1l1l1l1ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࠪࠤࠣࡧࡱࡧࡳࡴࠩಝ")).findall(content)
                        for l in l1l1l1l1ll11l1l11_nktv_:
                            if host in l:
                                l1111l11ll11l1l11_nktv_ = l
                                break
                    response.close()
            except:
                pass
    return l1111l11ll11l1l11_nktv_
def l1111ll1ll11l1l11_nktv_(url,content=None):
    if not content:
        content = l1lll11l1ll11l1l11_nktv_(url)
    out  =[]
    l1ll11lllll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨࠤ࠭࠴ࠪࡀࠫ࠿࠳࡮࡬ࡲࡢ࡯ࡨࡂࠬಞ"),re.DOTALL).findall(content)
    names = re.compile(l1l11ll11l1l11_nktv_ (u"ࠫࡁࡻ࡬ࠡࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡧࡘࡦࡨࡳࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ಟ"),re.DOTALL).findall(content)
    if names:
        names = [x.strip() for x in re.compile(l1l11ll11l1l11_nktv_ (u"ࠬࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ಠ"),re.DOTALL).findall(names[0]) if x.strip()]
    else:
        names=[]
    for l1lllllllll11l1l11_nktv_ in l1ll11lllll11l1l11_nktv_:
        href = re.compile(l1l11ll11l1l11_nktv_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫಡ"),re.DOTALL).search(l1lllllllll11l1l11_nktv_)
        if href:
            l111111lll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠧࡩࡶࡷࡴࠬಢ")+ urllib.unquote(href.group(1)).split(l1l11ll11l1l11_nktv_ (u"ࠨࡪࡷࡸࡵ࠭ಣ"))[-1]
            if l111111lll11l1l11_nktv_.startswith(l1l11ll11l1l11_nktv_ (u"ࠩ࡫ࡸࡹࡶࠧತ")) and not l1l11ll11l1l11_nktv_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫಥ") in l111111lll11l1l11_nktv_ and not l1l11ll11l1l11_nktv_ (u"ࠫ࡫ࡧࡣࡦࡤࡲࡳࡰ࠭ದ") in l111111lll11l1l11_nktv_:
                host = urlparse(l111111lll11l1l11_nktv_).netloc
                l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠬࡻࡲ࡭ࠩಧ") : l111111lll11l1l11_nktv_,
                    l1l11ll11l1l11_nktv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬನ"): l1l11ll11l1l11_nktv_ (u"ࠢ࡜ࠧࡶࡡࠧ಩") %(host),
                    l1l11ll11l1l11_nktv_ (u"ࠨࡪࡲࡷࡹ࠭ಪ"): host    }
                out.append(l11111llll11l1l11_nktv_)
    if len(names)==len(out):
        for l11111llll11l1l11_nktv_,name in zip(out,names):
            l11111llll11l1l11_nktv_[l1l11ll11l1l11_nktv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨಫ")] += l1l11ll11l1l11_nktv_ (u"ࠪࠤࠪࡹࠧಬ")%name
    return out
url=l1l11ll11l1l11_nktv_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡴࡡࡴࡼࡨ࠱ࡰ࡯࡮ࡰ࠰ࡷࡺ࠴࡬ࡩ࡭࡯࠲ࡼࡽ࠳࠲࠱࠳࠺ࠫಭ")
def l1llllllllll11l1l11_nktv_(url,content,l1lllllll1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡮ࡢࡵࡽࡩ࠲ࡱࡩ࡯ࡱ࠱ࡸࡻ࠵ࡣࡢࡲࡷࡧ࡭ࡧ࠮࡫ࡲࡪࠫಮ")):
    data = l1lll11l1ll11l1l11_nktv_(l1lllllll1ll11l1l11_nktv_)
    r=l11l111lll11l1l11_nktv_.l11l1111ll11l1l11_nktv_(data)
    header={l1l11ll11l1l11_nktv_ (u"࠭ࡁࡤࡥࡨࡴࡹ࠭ಯ"):l1l11ll11l1l11_nktv_ (u"ࠧࡵࡧࡻࡸ࠴࡮ࡴ࡮࡮࠯ࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࡫ࡸࡲࡲࠫࡹ࡯࡯࠰ࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻࡱࡱࡁࡱ࠾࠲࠱࠽࠱࠰࠯ࠫ࠽ࡴࡁ࠵࠴࠸ࠨರ"),
        l1l11ll11l1l11_nktv_ (u"ࠨࡷࡳ࡫ࡷࡧࡤࡦ࠯࡬ࡲࡸ࡫ࡣࡶࡴࡨ࠱ࡷ࡫ࡱࡶࡧࡶࡸࡸ࠭ಱ"):1,
        l1l11ll11l1l11_nktv_ (u"ࠩࡵࡩ࡫࡫ࡲࡦࡴࠪಲ"):url}
    l111111llll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠪࡧࡦࡶࡴࡤࡪࡤࡁࠪࡹࠦࡴࡷࡥࡱ࡮ࡺ࠽ࠨಳ")%(r)
    data = l1lll11l1ll11l1l11_nktv_(url,l111111llll11l1l11_nktv_,header)
    content = l1lll11l1ll11l1l11_nktv_(url)
    if re.search(l1l11ll11l1l11_nktv_ (u"ࠫࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩࡪࡷࡸࡵ࠴ࠫࡀࡰࡤࡷࡿ࡫࠭࡬࡫ࡱࡳ࠳ࡺࡶ࠰ࡥࡤࡴࡹࡩࡨࡢ࠰࡭ࡴ࡬࠯ࠢ࠿ࠩ಴"),content):
        l11l111lll11l1l11_nktv_.l111ll11ll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡸࡥࡥ࡟ࡅॆऊࡪࠠࡤࡣࡳࡸࡨ࡮ࡡ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩವ"),l1l11ll11l1l11_nktv_ (u"࠭ࡎࡪࡧࠣࡳࠥࡺࡡ࡬࡫ࠣࡸࡪࡱࡳࡵࠢࡦ࡬ࡴࡪࡺࡪॄࡲࠥࠬಶ"),l1l11ll11l1l11_nktv_ (u"ࠧࡄࡼࡼࠤࡳࡧࠠࡱࡧࡺࡲࡴࠦࡪࡦࡵࡷࡩࡸࠦࡣࡻॄࡲࡻ࡮࡫࡫ࡪࡧࡰࡃࠬಷ"))
        content=l1l11ll11l1l11_nktv_ (u"ࠨࠩಸ")
    return content
url=l1l11ll11l1l11_nktv_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮࡯ࡣࡶࡾࡪ࠳࡫ࡪࡰࡲ࠲ࡹࡼ࠯ࡧ࡫࡯ࡱ࠴ࡹࡷࡪࡣࡧࡩࡰ࠳࡯ࡴ࡭ࡤࡶࡿ࡫࡮ࡪࡣ࠰ࡸ࡭࡫࠭ࡸ࡫ࡷࡲࡪࡹࡳ࠮ࡨࡲࡶ࠲ࡺࡨࡦ࠯ࡳࡶࡴࡹࡥࡤࡷࡷ࡭ࡴࡴ࠭࠳࠲࠴࠺ࠬಹ")
def l1l1lllll11l1l11_nktv_(url):
    content = l1lll11l1ll11l1l11_nktv_(url)
    l1llllll1lll11l1l11_nktv_ = re.search(l1l11ll11l1l11_nktv_ (u"ࠪࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨࡩࡶࡷࡴ࠳࠱࠿࡯ࡣࡶࡾࡪ࠳࡫ࡪࡰࡲ࠲ࡹࡼ࠯ࡤࡣࡳࡸࡨ࡮ࡡ࠯࡬ࡳ࡫࠮ࠨ࠾ࠨ಺"),content)
    if l1llllll1lll11l1l11_nktv_:
        content = l1llllllllll11l1l11_nktv_(url,content,l1llllll1lll11l1l11_nktv_.group(1))
    l1111111lll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠫࡁࡺࡢࡰࡦࡼࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡨ࡯ࡥࡻࡁࠫ಻"),re.DOTALL).findall(content)
    l1111111lll11l1l11_nktv_ = l1111111lll11l1l11_nktv_[0] if l1111111lll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"಼ࠬ࠭")
    ids = [(a.start(), a.end()) for a in re.finditer(l1l11ll11l1l11_nktv_ (u"࠭࠼ࡵࡴࡁࠫಽ"), l1111111lll11l1l11_nktv_)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l111l1llll11l1l11_nktv_ = l1111111lll11l1l11_nktv_[ ids[i][1]:ids[i+1][0] ]
        href=re.compile(l1l11ll11l1l11_nktv_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ಾ")).search(l111l1llll11l1l11_nktv_)
        l11111l11ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠨࡦࡤࡸࡦ࠳ࡩࡧࡴࡤࡱࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧಿ")).search(l111l1llll11l1l11_nktv_)
        info = l1l11ll11l1l11_nktv_ (u"ࠩࠪೀ").join(re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࡂ࠭࠴ࠪࡀࠫ࠿ࠫು"),re.DOTALL).findall(l111l1llll11l1l11_nktv_))
        info = re.sub(l1l11ll11l1l11_nktv_ (u"ࠫࠥ࠱ࠧೂ"),l1l11ll11l1l11_nktv_ (u"ࠬࠦࠧೃ"),l1lll1ll1ll11l1l11_nktv_(info)).strip()
        if href:
            l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"࠭ࡵࡳ࡮ࠪೄ") : href.group(1),l1l11ll11l1l11_nktv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭೅"): info,}
            out.append(l11111llll11l1l11_nktv_)
    return out
def l1111l1ll11l1l11_nktv_(url):
    content = l1lll11l1ll11l1l11_nktv_(url)
    l1lll1lllll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡩࡥ࠿ࠥ࡭ࡹ࡫࡭࠮ࡪࡨࡥࡩࡲࡩ࡯ࡧࠥ࠲࠯ࡻࡲ࡭࡞ࠫࠬ࠳࠰࠿ࠪ࡞ࠬࠫೆ")).findall(content)
    l1lll1lllll11l1l11_nktv_ = l1lll1lllll11l1l11_nktv_[-1] if l1lll1lllll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠩࠪೇ")
    out=[]
    l1l1l11llll11l1l11_nktv_= content.find(l1l11ll11l1l11_nktv_ (u"ࠪࡓࡩࡩࡩ࡯࡭࡬ࠫೈ"))
    l1l1l1l1lll11l1l11_nktv_= content.find(l1l11ll11l1l11_nktv_ (u"ࠫࡉࡵࡤࡢ࡬ࠣࡳࡩࡩࡩ࡯ࡧ࡮ࠫ೉"))
    l1l11lll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪೊ"),re.DOTALL).findall(content[l1l1l11llll11l1l11_nktv_:l1l1l1l1lll11l1l11_nktv_])
    for h,t in l1l11lll11l1l11_nktv_:
        t= l1lll1ll1ll11l1l11_nktv_(t.strip())
        t=re.sub(l1l11ll11l1l11_nktv_ (u"࠭ࠠࠬࠩೋ"),l1l11ll11l1l11_nktv_ (u"ࠧࠡࠩೌ"),t)
        l1ll11l11ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠨ࡝ࡶࡗࡢ࠮࡜ࡥ࠭ࠬ࡟ࡊ࡫࡝ࠩ࡞ࡧ࠯࠮್࠭")).findall(t)
        l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠩ࡫ࡶࡪ࡬ࠧ೎")  : h.strip(),
            l1l11ll11l1l11_nktv_ (u"ࠪࡴࡱࡵࡴࠨ೏"): t,
            l1l11ll11l1l11_nktv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ೐") : t,
            l1l11ll11l1l11_nktv_ (u"ࠬ࡯࡭ࡨࠩ೑"):l1lll1lllll11l1l11_nktv_,
            l1l11ll11l1l11_nktv_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭೒"): int(l1ll11l11ll11l1l11_nktv_[0][0]) if l1ll11l11ll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠧࠨ೓"),
            l1l11ll11l1l11_nktv_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࠩ೔"): int(l1ll11l11ll11l1l11_nktv_[0][1]) if l1ll11l11ll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠩࠪೕ"),
            l1l11ll11l1l11_nktv_ (u"ࠪࡥ࡮ࡸࡥࡥࠩೖ") : l1l11ll11l1l11_nktv_ (u"ࠫࠬ೗")}
        out.append(l11111llll11l1l11_nktv_)
    return out
def l11lllll11l1l11_nktv_(out):
    l111111l1ll11l1l11_nktv_={}
    l11lll11ll11l1l11_nktv_ = [x.get(l1l11ll11l1l11_nktv_ (u"ࠬࡹࡥࡢࡵࡲࡲࠬ೘")) for x in out]
    for s in set(l11lll11ll11l1l11_nktv_):
        l111111l1ll11l1l11_nktv_[l1l11ll11l1l11_nktv_ (u"࠭ࡓࡦࡼࡲࡲࠥࠫ࠰࠳ࡦࠪ೙")%s]=[out[i] for i, j in enumerate(l11lll11ll11l1l11_nktv_) if j == s]
    return l111111l1ll11l1l11_nktv_
def l1l1l1lll11l1l11_nktv_(url=l1l11ll11l1l11_nktv_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡰࡤࡷࡿ࡫࠭࡬࡫ࡱࡳ࠳ࡺࡶ࠰ࡵࡨࡶ࡮ࡧ࡬ࡦ࠯ࡲࡲࡱ࡯࡮ࡦ࠱ࠪ೚")):
    content = l1lll11l1ll11l1l11_nktv_(url)
    l11111111ll11l1l11_nktv_=re.compile(l1l11ll11l1l11_nktv_ (u"ࠨ࠾ࡸࡰࠥ࡯ࡤ࠾ࠤࡶࡩࡷ࡯ࡥࡴ࠯࡯࡭ࡸࡺࠢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡨ࡬ࡰࡹ࡫ࡲࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࠬ೛"),re.DOTALL).findall(content)
    l1l1111llll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠫࡀࠫࠥ࡟ࡡࡸ࡜࡯ࠢ࡟ࡸࡢ࠰ࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯࠭ࡂ࠭ࠧ࠭೜")).findall(l11111111ll11l1l11_nktv_[0])
    out=[]
    for href,title in l1l1111llll11l1l11_nktv_:
        l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠪ࡬ࡷ࡫ࡦࠨೝ")  : href,
            l1l11ll11l1l11_nktv_ (u"ࠫࡵࡲ࡯ࡵࠩೞ"): l1l11ll11l1l11_nktv_ (u"ࠬ࠭೟"),
            l1l11ll11l1l11_nktv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬೠ") : l1lll1ll1ll11l1l11_nktv_(title),
            l1l11ll11l1l11_nktv_ (u"ࠧࡪ࡯ࡪࠫೡ"):l1l11ll11l1l11_nktv_ (u"ࠨࠩೢ")}
        out.append(l11111llll11l1l11_nktv_)
    return (out, (False,False))
def l1lllll1lll11l1l11_nktv_(m):
    return l1l11ll11l1l11_nktv_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠩೣ")+urllib.unquote(m.group(1))
def l1l11ll1ll11l1l11_nktv_(l1l111l1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠪࡪ࡮ࡲ࡭ࠨ೤"),l11ll1llll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭೥")):
    label=[]
    value=[]
    if l1l111l1ll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠬ࡬ࡩ࡭࡯ࠪ೦"):
        content = l1lll11l1ll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡯ࡣࡶࡾࡪ࠳࡫ࡪࡰࡲ࠲ࡹࡼ࠯ࡧ࡫࡯ࡱࡾ࠳࡯࡯࡮࡬ࡲࡪ࠵ࠧ೧"))
        if l11ll1llll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ೨"):
            l11111111ll11l1l11_nktv_=re.compile(l1l11ll11l1l11_nktv_ (u"ࠨ࠾ࡸࡰࠥ࡯ࡤ࠾ࠤࡩ࡭ࡱࡺࡥࡳ࠯ࡦࡥࡹ࡫ࡧࡰࡴࡼࠦࠥࡩ࡬ࡢࡵࡶࡁࠧ࡬ࡩ࡭ࡶࡨࡶࠥࡳࡵ࡭ࡶ࡬ࡴࡱ࡫࠭ࡴࡧ࡯ࡩࡨࡺࠠࡵࡧࡵࡱ࠲ࡲࡩࡴࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲࠧ೩"),re.DOTALL).findall(content)[0]
            value=re.compile(l1l11ll11l1l11_nktv_ (u"ࠩࡧࡥࡹࡧ࠭ࡪࡦࡀࠦ࠭ࡢࡤࠬࠫࠥࠫ೪")).findall(l11111111ll11l1l11_nktv_)
            label=re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧࠩࠢ࠿ࠪ࠱࠯ࡄ࠯࠼ࠨ೫")).findall(l11111111ll11l1l11_nktv_)
        elif l11ll1llll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠫࡾ࡫ࡡࡳࠩ೬"):
            l11111111ll11l1l11_nktv_=re.compile(l1l11ll11l1l11_nktv_ (u"ࠬࡂࡵ࡭ࠢ࡬ࡨࡂࠨࡦࡪ࡮ࡷࡩࡷ࠳ࡹࡦࡣࡵࠦࠥࡩ࡬ࡢࡵࡶࡁࠧ࡬ࡩ࡭ࡶࡨࡶࠥࡳࡵ࡭ࡶ࡬ࡴࡱ࡫࠭ࡴࡧ࡯ࡩࡨࡺࠠࡵࡧࡵࡱ࠲ࡲࡩࡴࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲࠧ೭"),re.DOTALL).findall(content)[0]
            value=re.compile(l1l11ll11l1l11_nktv_ (u"࠭ࡤࡢࡶࡤ࠱࡮ࡪ࠽ࠣࠪ࡟ࡨ࠰࠯ࠢࠨ೮")).findall(l11111111ll11l1l11_nktv_)
            label=re.compile(l1l11ll11l1l11_nktv_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠦࠦࡃ࠮࠮ࠬࡁࠬࡀࠬ೯")).findall(l11111111ll11l1l11_nktv_)
        elif l11ll1llll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠨࡥࡲࡹࡳࡺࡲࡺࠩ೰"):
            l11111111ll11l1l11_nktv_=re.compile(l1l11ll11l1l11_nktv_ (u"ࠩ࠿ࡹࡱࠦࡩࡥ࠿ࠥࡪ࡮ࡲࡴࡦࡴ࠰ࡧࡴࡻ࡮ࡵࡴࡼࠦࠥࡩ࡬ࡢࡵࡶࡁࠧ࡬ࡩ࡭ࡶࡨࡶࠥࡳࡵ࡭ࡶ࡬ࡴࡱ࡫࠭ࡴࡧ࡯ࡩࡨࡺࠠࡵࡧࡵࡱ࠲ࡲࡩࡴࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲࠧೱ"),re.DOTALL).findall(content)[0]
            value=re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࡨࡦࡺࡡ࠮࡫ࡧࡁࠧ࠮࡜ࡥ࠭ࠬࠦࠬೲ")).findall(l11111111ll11l1l11_nktv_)
            label=re.compile(l1l11ll11l1l11_nktv_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠣࠣࡀࠫ࠲࠰ࡅࠩ࠽ࠩೳ")).findall(l11111111ll11l1l11_nktv_)
    elif l1l111l1ll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠬࡹࡥࡳ࡫ࡤࡰࠬ೴"):
        pass
    return (label,value)
def l1lll1ll1ll11l1l11_nktv_(l1llll1llll11l1l11_nktv_):
    if isinstance(l1llll1llll11l1l11_nktv_, unicode):
        l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.encode(l1l11ll11l1l11_nktv_ (u"࠭ࡵࡵࡨ࠰࠼ࠬ೵"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠧࠧ࡮ࡷ࠿ࡧࡸ࠯ࠧࡩࡷ࠿ࠬ೶"),l1l11ll11l1l11_nktv_ (u"ࠨࠢࠪ೷"))
    s=l1l11ll11l1l11_nktv_ (u"ࠩࡍ࡭ࡓࡩ࡚ࡄࡵ࠺ࠫ೸")
    l1llll1llll11l1l11_nktv_ = re.sub(s.decode(l1l11ll11l1l11_nktv_ (u"ࠪࡦࡦࡹࡥ࠷࠶ࠪ೹")),l1l11ll11l1l11_nktv_ (u"ࠫࠬ೺"),l1llll1llll11l1l11_nktv_)
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠬࡢ࡮ࠨ೻"),l1l11ll11l1l11_nktv_ (u"࠭ࠧ೼")).replace(l1l11ll11l1l11_nktv_ (u"ࠧ࡝ࡴࠪ೽"),l1l11ll11l1l11_nktv_ (u"ࠨࠩ೾"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠩࠩࡲࡧࡹࡰ࠼ࠩ೿"),l1l11ll11l1l11_nktv_ (u"ࠪࠫഀ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠫࠫࡷࡵࡰࡶ࠾ࠫഁ"),l1l11ll11l1l11_nktv_ (u"ࠬࠨࠧം")).replace(l1l11ll11l1l11_nktv_ (u"࠭ࠦࡢ࡯ࡳ࠿ࡶࡻ࡯ࡵ࠽ࠪഃ"),l1l11ll11l1l11_nktv_ (u"ࠧࠣࠩഄ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠨࠨࡲࡥࡨࡻࡴࡦ࠽ࠪഅ"),l1l11ll11l1l11_nktv_ (u"ࣶࠩࠫആ")).replace(l1l11ll11l1l11_nktv_ (u"ࠪࠪࡔࡧࡣࡶࡶࡨ࠿ࠬഇ"),l1l11ll11l1l11_nktv_ (u"ࠫࣘ࠭ഈ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠬࠬࡡ࡮ࡲ࠾ࡳࡦࡩࡵࡵࡧ࠾ࠫഉ"),l1l11ll11l1l11_nktv_ (u"࠭ࣳࠨഊ")).replace(l1l11ll11l1l11_nktv_ (u"ࠧࠧࡣࡰࡴࡀࡕࡡࡤࡷࡷࡩࡀ࠭ഋ"),l1l11ll11l1l11_nktv_ (u"ࠨࣕࠪഌ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠩࠩࡥࡲࡶ࠻ࠨ഍"),l1l11ll11l1l11_nktv_ (u"ࠪࠪࠬഎ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠫࡡࡻ࠰࠲࠲࠸ࠫഏ"),l1l11ll11l1l11_nktv_ (u"ࠬऋࠧഐ")).replace(l1l11ll11l1l11_nktv_ (u"࠭࡜ࡶ࠲࠴࠴࠹࠭഑"),l1l11ll11l1l11_nktv_ (u"ࠧअࠩഒ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠨ࡞ࡸ࠴࠶࠶࠷ࠨഓ"),l1l11ll11l1l11_nktv_ (u"ࠩऊࠫഔ")).replace(l1l11ll11l1l11_nktv_ (u"ࠪࡠࡺ࠶࠱࠱࠸ࠪക"),l1l11ll11l1l11_nktv_ (u"ࠫऋ࠭ഖ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠬࡢࡵ࠱࠳࠴࠽ࠬഗ"),l1l11ll11l1l11_nktv_ (u"࠭ङࠨഘ")).replace(l1l11ll11l1l11_nktv_ (u"ࠧ࡝ࡷ࠳࠵࠶࠾ࠧങ"),l1l11ll11l1l11_nktv_ (u"ࠨचࠪച"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠩ࡟ࡹ࠵࠷࠴࠳ࠩഛ"),l1l11ll11l1l11_nktv_ (u"ࠪॆࠬജ")).replace(l1l11ll11l1l11_nktv_ (u"ࠫࡡࡻ࠰࠲࠶࠴ࠫഝ"),l1l11ll11l1l11_nktv_ (u"ࠬेࠧഞ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"࠭࡜ࡶ࠲࠴࠸࠹࠭ട"),l1l11ll11l1l11_nktv_ (u"ࠧॅࠩഠ")).replace(l1l11ll11l1l11_nktv_ (u"ࠨ࡞ࡸ࠴࠶࠺࠴ࠨഡ"),l1l11ll11l1l11_nktv_ (u"ࠩॆࠫഢ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠪࡠࡺ࠶࠰ࡧ࠵ࠪണ"),l1l11ll11l1l11_nktv_ (u"ࠫࣸ࠭ത")).replace(l1l11ll11l1l11_nktv_ (u"ࠬࡢࡵ࠱࠲ࡧ࠷ࠬഥ"),l1l11ll11l1l11_nktv_ (u"࣓࠭ࠨദ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠧ࡝ࡷ࠳࠵࠺ࡨࠧധ"),l1l11ll11l1l11_nktv_ (u"ࠨढ़ࠪന")).replace(l1l11ll11l1l11_nktv_ (u"ࠩ࡟ࡹ࠵࠷࠵ࡢࠩഩ"),l1l11ll11l1l11_nktv_ (u"ࠪफ़ࠬപ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠫࡡࡻ࠰࠲࠹ࡤࠫഫ"),l1l11ll11l1l11_nktv_ (u"ࠬঀࠧബ")).replace(l1l11ll11l1l11_nktv_ (u"࠭࡜ࡶ࠲࠴࠻࠾࠭ഭ"),l1l11ll11l1l11_nktv_ (u"ࠧॺࠩമ"))
    l1llll1llll11l1l11_nktv_ = l1llll1llll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"ࠨ࡞ࡸ࠴࠶࠽ࡣࠨയ"),l1l11ll11l1l11_nktv_ (u"ࠩॿࠫര")).replace(l1l11ll11l1l11_nktv_ (u"ࠪࡠࡺ࠶࠱࠸ࡤࠪറ"),l1l11ll11l1l11_nktv_ (u"ࠫঀ࠭ല"))
    return l1llll1llll11l1l11_nktv_
def search(l1llll1llll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠬࡪ࡯࡮ࠩള")):
    url=l1l11ll11l1l11_nktv_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡯ࡣࡶࡾࡪ࠳࡫ࡪࡰࡲ࠲ࡹࡼ࠯ࡸࡻࡶࡾࡺࡱࡩࡸࡣࡵ࡯ࡦࡅࡰࡩࡴࡤࡷࡪࡃࠧഴ")+l1llll1llll11l1l11_nktv_
    content=l1lll11l1ll11l1l11_nktv_(url)
    l1l111ll1ll11l1l11_nktv_=[]
    l1l11l11lll11l1l11_nktv_=[]
    ids = [(a.start(), a.end()) for a in re.finditer(l1l11ll11l1l11_nktv_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡭࠯ࡶࡱ࠲ࡢࡤࠬࠩവ"), content)]
    ids.append( (-1,-1) )
    for i in range(len(ids[:-1])):
        l111l1llll11l1l11_nktv_ = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile(l1l11ll11l1l11_nktv_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪശ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        title = re.compile(l1l11ll11l1l11_nktv_ (u"ࠩࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩഷ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        l1llll11lll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠡࡶࡨࡼࡹ࠳ࡪࡶࡵࡷ࡭࡫ࡿࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨസ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        l1lll1lllll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩഹ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        l1111111ll11l1l11_nktv_ = re.compile(l1l11ll11l1l11_nktv_ (u"ࠬࡂ࠯ࡣࡀ࡟ࡷ࠯࠮࡜ࡥ࡞࠱ࡠࡩ࠯࠼࠰ࡵࡳࡥࡳࡄࠧഺ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        year =  re.compile(l1l11ll11l1l11_nktv_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡾ࡫ࡡࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾഻ࠪ"),re.DOTALL).search(l111l1llll11l1l11_nktv_)
        if href and title:
            l1lll1lllll11l1l11_nktv_ = l1lll1lllll11l1l11_nktv_.group(1).replace(l1l11ll11l1l11_nktv_ (u"ࠧ࠰ࡶ࡫ࡹࡲࡨ࠯ࠨ഼"),l1l11ll11l1l11_nktv_ (u"ࠨ࠱ࡥ࡭࡬࠵ࠧഽ")) if l1lll1lllll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠩࠪാ")
            l11111llll11l1l11_nktv_ = {l1l11ll11l1l11_nktv_ (u"ࠪ࡬ࡷ࡫ࡦࠨി")   : href.group(1),
                l1l11ll11l1l11_nktv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪീ")  : l1lll1ll1ll11l1l11_nktv_(title.group(1)),
                l1l11ll11l1l11_nktv_ (u"ࠬࡶ࡬ࡰࡶࠪു")   : l1lll1ll1ll11l1l11_nktv_(l1llll11lll11l1l11_nktv_.group(1)) if l1llll11lll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"࠭ࠧൂ"),
                l1l11ll11l1l11_nktv_ (u"ࠧࡪ࡯ࡪࠫൃ")    : l1lll1lllll11l1l11_nktv_,
                l1l11ll11l1l11_nktv_ (u"ࠨࡴࡤࡸ࡮ࡴࡧࠨൄ") : l1111111ll11l1l11_nktv_.group(1) if l1111111ll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠩࠪ൅"),
                l1l11ll11l1l11_nktv_ (u"ࠪࡽࡪࡧࡲࠨെ")   : year.group(1) if year else l1l11ll11l1l11_nktv_ (u"ࠫࠬേ"),
                    }
            if l1l11ll11l1l11_nktv_ (u"ࠬ࠵ࡦࡪ࡮ࡰࠫൈ") in l11111llll11l1l11_nktv_[l1l11ll11l1l11_nktv_ (u"࠭ࡨࡳࡧࡩࠫ൉")]:
                l1l111ll1ll11l1l11_nktv_.append(l11111llll11l1l11_nktv_)
            elif l1l11ll11l1l11_nktv_ (u"ࠧ࠰ࡵࡨࡶ࡮ࡧ࡬ࠨൊ")in l11111llll11l1l11_nktv_[l1l11ll11l1l11_nktv_ (u"ࠨࡪࡵࡩ࡫࠭ോ")]:
                l1l11l11lll11l1l11_nktv_.append(l11111llll11l1l11_nktv_)
    return l1l111ll1ll11l1l11_nktv_,l1l11l11lll11l1l11_nktv_
