# -*- coding: utf-8 -*-
import sys
l1111ll11l1l11_nktv_ = sys.version_info [0] == 2
l111ll11l1l11_nktv_ = 2048
l1l1lll11l1l11_nktv_ = 7
def l1l11ll11l1l11_nktv_ (keyedStringLiteral):
	global l11llll11l1l11_nktv_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1111ll11l1l11_nktv_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,random,json
import cookielib
l1111lllll11l1l11_nktv_=10
l1ll11ll1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠶࠲࠱࠴࠳࠸࠶࠷࠳࠱࠵࠵࠸ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧา")
def l1lll11l1ll11l1l11_nktv_(url,data=None,header={},l1lllll111ll11l1l11_nktv_=True):
    l11lllll1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠩࠪำ")
    l111l1l1ll11l1l11_nktv_=[]
    if l1lllll111ll11l1l11_nktv_:
        l111l1l1ll11l1l11_nktv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l111l1l1ll11l1l11_nktv_))
        urllib2.install_opener(opener)
    if not header:
        header = {l1l11ll11l1l11_nktv_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧิ"):l1ll11ll1ll11l1l11_nktv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1111lllll11l1l11_nktv_)
        l1ll11l1ll11l1l11_nktv_ =  response.read()
        response.close()
        l11lllll1ll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠫࠬี").join([l1l11ll11l1l11_nktv_ (u"ࠬࠫࡳ࠾ࠧࡶ࠿ࠬึ")%(c.name, c.value) for c in l111l1l1ll11l1l11_nktv_])
    except urllib2.HTTPError as e:
        l1ll11l1ll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"࠭ࠧื")
    return l1ll11l1ll11l1l11_nktv_,l11lllll1ll11l1l11_nktv_
url = l1l11ll11l1l11_nktv_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡸࡡࡱ࡫ࡧࡺ࡮ࡪࡥࡰ࠰ࡦࡳࡲ࠵ࡥ࡮ࡤࡨࡨ࠴࡜࠲ࡗࡵ࡙ࡏ࡝ࡖุࠧ")
url = l1l11ll11l1l11_nktv_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡲࡢࡲ࡬ࡨࡻ࡯ࡤࡦࡱ࠱ࡧࡴࡳ࠯ࡦ࡯ࡥࡩࡩ࠵ࡅࡄࡥࡼࡅࡗ࡭ࡍࠨู")
def l1ll1111ll11l1l11_nktv_(url):
    url = url.replace(l1l11ll11l1l11_nktv_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨฺ"),l1l11ll11l1l11_nktv_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ฻")).replace(l1l11ll11l1l11_nktv_ (u"ࠫ࠴࡫࡭ࡣࡧࡧ࠳ࠬ฼"),l1l11ll11l1l11_nktv_ (u"ࠬ࠵࠿ࡷ࠿ࠪ฽"))
    content,c = l1lll11l1ll11l1l11_nktv_(url)
    match = re.findall(l1l11ll11l1l11_nktv_ (u"࠭ࠧࠨ࡝ࠥࠫࡢࡅࡳࡰࡷࡵࡧࡪࡹ࡛ࠨࠤࡠࡃࡡࡹࠪ࠻࡞ࡶ࠮࠭ࡢ࡛࠯ࠬࡂࡠࡢ࠯ࠧࠨࠩ฾"), content)
    l1lllll11lll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠧࠨ฿")
    if not match:
        data = {}
        data[l1l11ll11l1l11_nktv_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮࠰ࡼࠫเ")] = random.randint(0, 120)
        data[l1l11ll11l1l11_nktv_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯࠱ࡼࠬแ")] = random.randint(0, 120)
        header={l1l11ll11l1l11_nktv_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧโ"):l1ll11ll1ll11l1l11_nktv_,l1l11ll11l1l11_nktv_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬใ"):url}
        l1lllll1llll11l1l11_nktv_ = url + l1l11ll11l1l11_nktv_ (u"ࠬࠩࠧไ")
        content,c = l1lll11l1ll11l1l11_nktv_(l1lllll1llll11l1l11_nktv_,urllib.urlencode(data),header=header)
        match = re.findall(l1l11ll11l1l11_nktv_ (u"࠭ࠧࠨ࡝ࠥࠫࡢࡅࡳࡰࡷࡵࡧࡪࡹ࡛ࠨࠤࡠࡃࡡࡹࠪ࠻࡞ࡶ࠮࠭ࡢ࡛࠯ࠬࡂࡠࡢ࠯ࠧࠨࠩๅ"), content)
    if match:
        try:
            data = json.loads(match[0])
            l1lllll11lll11l1l11_nktv_=[]
            for d in data:
                if isinstance(d,dict):
                    l1lllll1l1ll11l1l11_nktv_ = d.get(l1l11ll11l1l11_nktv_ (u"ࠧࡧ࡫࡯ࡩࠬๆ"),l1l11ll11l1l11_nktv_ (u"ࠨࠩ็"))+l1l11ll11l1l11_nktv_ (u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠦࡵࠩࡖࡪ࡬ࡥࡳࡧࡵࡁࠪࡹ่ࠧ")%(l1ll11ll1ll11l1l11_nktv_,url)
                    l1lllll11lll11l1l11_nktv_.append((d.get(l1l11ll11l1l11_nktv_ (u"ࠪࡰࡦࡨࡥ࡭้ࠩ"),l1l11ll11l1l11_nktv_ (u"๊ࠫࠬ")),l1lllll1l1ll11l1l11_nktv_))
        except:
            l1lllll11lll11l1l11_nktv_ = re.findall(l1l11ll11l1l11_nktv_ (u"ࠬ࠭ࠧ࡜ࠩࠥࡡࡄ࡬ࡩ࡭ࡧ࡞ࠫࠧࡣ࠿࡝ࡵ࠭࠾ࡡࡹࠪ࡜ࠩࠥࡡࡄ࠮࡛࡟ࠩࠥࡡ࠰࠯ࠧࠨ๋ࠩ"), match[0])
            if l1lllll11lll11l1l11_nktv_:
                l1lllll11lll11l1l11_nktv_ = l1lllll11lll11l1l11_nktv_[0].replace(l1l11ll11l1l11_nktv_ (u"࠭࡜࠰ࠩ์"), l1l11ll11l1l11_nktv_ (u"ࠧ࠰ࠩํ"))
                l1lllll11lll11l1l11_nktv_ += l1l11ll11l1l11_nktv_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠥࡴࠨࡕࡩ࡫࡫ࡲࡦࡴࡀࠩࡸ࠭๎")%(l1ll11ll1ll11l1l11_nktv_,url)
    return l1lllll11lll11l1l11_nktv_
