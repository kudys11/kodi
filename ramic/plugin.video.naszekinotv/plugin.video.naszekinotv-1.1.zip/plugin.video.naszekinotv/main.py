# -*- coding: utf-8 -*-
import sys
l1111ll11l1l11_nktv_ = sys.version_info [0] == 2
l111ll11l1l11_nktv_ = 2048
l1l1lll11l1l11_nktv_ = 7
def l1l11ll11l1l11_nktv_ (keyedStringLiteral):
	global l11llll11l1l11_nktv_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1111ll11l1l11_nktv_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import urlresolver
import check
try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
cache = StorageServer.StorageServer(l1l11ll11l1l11_nktv_ (u"ࠤࡱ࡯ࡹࡼࠢࠨ"))
import resources.lib.l1ll11llll11l1l11_nktv_ as l1l11l11ll11l1l11_nktv_
if False:
    import resources.lib.l1l1l1ll11l1l11_nktv_ as l1ll11ll11l1l11_nktv_
    import resources.lib.l11ll11lll11l1l11_nktv_ as l11ll11lll11l1l11_nktv_
    import resources.lib.l1111llll11l1l11_nktv_ as l1111llll11l1l11_nktv_
    import resources.lib.l1l1ll1ll11l1l11_nktv_ as l1l1ll1ll11l1l11_nktv_
    import resources.lib.l111111ll11l1l11_nktv_ as l1l1ll1lll11l1l11_nktv_
import ramic as l11lll1ll11l1l11_nktv_
l111llll11l1l11_nktv_        = sys.argv[0]
l1lll11lll11l1l11_nktv_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l11l1l1ll11l1l11_nktv_        = xbmcaddon.Addon()
l1llll1lll11l1l11_nktv_       = l11l1l1ll11l1l11_nktv_.getAddonInfo(l1l11ll11l1l11_nktv_ (u"ࠪࡲࡦࡳࡥࠨࠩ"))
PATH        = l11l1l1ll11l1l11_nktv_.getAddonInfo(l1l11ll11l1l11_nktv_ (u"ࠫࡵࡧࡴࡩࠩࠪ"))
l1lll1llll11l1l11_nktv_    = xbmc.translatePath(l11l1l1ll11l1l11_nktv_.getAddonInfo(l1l11ll11l1l11_nktv_ (u"ࠬࡶࡲࡰࡨ࡬ࡰࡪ࠭ࠫ"))).decode(l1l11ll11l1l11_nktv_ (u"࠭ࡵࡵࡨ࠰࠼ࠬࠬ"))
l11111ll11l1l11_nktv_   = PATH+l1l11ll11l1l11_nktv_ (u"ࠧ࠰ࡴࡨࡷࡴࡻࡲࡤࡧࡶ࠳ࠬ࠭")
l11ll1l1ll11l1l11_nktv_=l11111ll11l1l11_nktv_+l1l11ll11l1l11_nktv_ (u"ࠨࡨࡤࡲࡦࡸࡴ࠯ࡲࡱ࡫ࠬ࠮")
l1l11l11ll11l1l11_nktv_.l11ll1ll11l1l11_nktv_=os.path.join(l1lll1llll11l1l11_nktv_,l1l11ll11l1l11_nktv_ (u"ࠩࡦࡳࡴࡱࡩࡦࠩ࠯"))
import time,threading
try: from shutil import rmtree
except: rmtree = False
def l1lll11l1l11_nktv_(l1llllll11l1l11_nktv_,l1lll1ll11l1l11_nktv_=[l1l11ll11l1l11_nktv_ (u"ࠪࠫ࠰")]):
    debug=1
def l1ll11l1l11_nktv_(name=l1l11ll11l1l11_nktv_ (u"ࠫࠬ࠱")):
    debug=1
def l1llll11l1l11_nktv_(top):
    debug=1
def l1ll1ll11l1l11_nktv_():
    l1llllll11l1l11_nktv_ = os.path.join(xbmc.translatePath(l1l11ll11l1l11_nktv_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭࠹")),l1l11ll11l1l11_nktv_ (u"࠭ࡡࡥࡦࡲࡲࡸ࠭࠺"))
    xbmc.log(l1llllll11l1l11_nktv_)
    if l1lll11l1l11_nktv_(l1llllll11l1l11_nktv_,[l1l11ll11l1l11_nktv_ (u"ࠧࡢ࡮࡬ࡩࡳࡽࡩࡻࡣࡵࡨࠬ࠻"),l1l11ll11l1l11_nktv_ (u"ࠨࡧࡻࡸࡪࡴࡤࡦࡴ࠱ࡥࡱ࡯ࡥ࡯ࠩ࠼")])>0:
        l1ll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠩࡺ࡭ࡿࡧࡲࡥࠩ࠽"))
        return
    if os.path.exists(l1l1ll11l1l11_nktv_):
        data = open(l1l1ll11l1l11_nktv_,l1l11ll11l1l11_nktv_ (u"ࠪࡶࠬ࠾")).read()
        data= re.sub(l1l11ll11l1l11_nktv_ (u"ࠫࡡࡡ࠮ࠫ࡞ࡠࠫ࠿"),l1l11ll11l1l11_nktv_ (u"ࠬ࠭ࡀ"),data)
        if len(re.compile(l1l11ll11l1l11_nktv_ (u"࠭࠾࠯ࠬࠫࡴࡴࡲࡳ࡬ࡣ࡟ࡷ࠯ࡺ࡜ࡴࠬࡹ࠭ࠬࡁ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1ll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡾ࡯࡯ࡨ࡯ࡹࡪࡴࡣࡦࠩࡂ"))
            return
    l11l1ll11l1l11_nktv_ = xbmc.translatePath(l1l11ll11l1l11_nktv_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩࡃ"))
    for f in os.listdir(l11l1ll11l1l11_nktv_):
        if f.startswith(l1l11ll11l1l11_nktv_ (u"ࠩࡐࡑࡊ࡙ࠧࡄ")):
            l1ll11l1l11_nktv_()
            return
try:
    debug=1
except: pass
l1llllllll11l1l11_nktv_ = lambda x,y: ord(x)+4*y if ord(x)%2 else ord(x)
l1l1111ll11l1l11_nktv_ = lambda l1lllll1ll11l1l11_nktv_: l1l11ll11l1l11_nktv_ (u"ࠫࠬࡆ").join([chr(l1llllllll11l1l11_nktv_(x,1) ) for x in l1lllll1ll11l1l11_nktv_.encode(l1l11ll11l1l11_nktv_ (u"ࠬࡨࡡࡴࡧ࠹࠸ࠬࡇ")).strip()])
l1l1ll11ll11l1l11_nktv_ = lambda l1lllll1ll11l1l11_nktv_: l1l11ll11l1l11_nktv_ (u"࠭ࠧࡈ").join([chr(l1llllllll11l1l11_nktv_(x,-1) ) for x in l1lllll1ll11l1l11_nktv_]).decode(l1l11ll11l1l11_nktv_ (u"ࠧࡣࡣࡶࡩ࠻࠺ࠧࡉ"))
if not os.path.exists(l1l11ll11l1l11_nktv_ (u"ࠨ࠱࡫ࡳࡲ࡫࠯ࡰࡵࡰࡧࠬࡊ")):
    tm=time.gmtime()
    try:    l111l1ll11l1l11_nktv_,l1ll111ll11l1l11_nktv_,l11l11ll11l1l11_nktv_ = l1l1ll11ll11l1l11_nktv_(l11l1l1ll11l1l11_nktv_.getSetting(l1l11ll11l1l11_nktv_ (u"ࠩ࡮ࡳࡩ࠭ࡋ"))).split(l1l11ll11l1l11_nktv_ (u"ࠪ࠾ࠬࡌ"))
    except: l111l1ll11l1l11_nktv_,l1ll111ll11l1l11_nktv_,l11l11ll11l1l11_nktv_ =  [l1l11ll11l1l11_nktv_ (u"ࠫ࠲࠷ࠧࡍ"),l1l11ll11l1l11_nktv_ (u"ࠬ࠭ࡎ"),l1l11ll11l1l11_nktv_ (u"࠭࠭࠲ࠩࡏ")]
    if int(l111l1ll11l1l11_nktv_) != tm.tm_hour:
        try:    l1ll1l11ll11l1l11_nktv_ = re.findall(l1l11ll11l1l11_nktv_ (u"ࠧࡌࡑࡇ࠾ࠥ࠮࠮ࠫࡁࠬࡠࡳ࠭ࡐ"),urllib2.urlopen(l1l11ll11l1l11_nktv_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡹࡧࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳ࠯ࡳࡣࡰ࡭ࡨࡹࡰࡢ࠱࡮ࡳࡩ࡯࠯࡮ࡣࡶࡸࡪࡸ࠯ࡓࡇࡄࡈࡒࡋ࠮࡮ࡦࠪࡑ")).read())[0].strip(l1l11ll11l1l11_nktv_ (u"ࠩ࠭ࠫࡒ"))
        except: l1ll1l11ll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠪࠫࡓ")
        l1l1l111ll11l1l11_nktv_ = l1l1111ll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠬࠫࡤ࠻ࠧࡶ࠾ࠪࡪࠧ࡜")%(tm.tm_hour,l1ll1l11ll11l1l11_nktv_,tm.tm_min))
        l11l1l1ll11l1l11_nktv_.setSetting(l1l11ll11l1l11_nktv_ (u"࠭࡫ࡰࡦࠪ࡝"),l1l1l111ll11l1l11_nktv_)
def l11lllllll11l1l11_nktv_(name, url, mode, l1l11llll11l1l11_nktv_=1, l11l11lll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫ࡞"), infoLabels=False, IsPlayable=True,fanart=l11ll1l1ll11l1l11_nktv_,l111ll1ll11l1l11_nktv_=1):
    u = l1l1llll11l1l11_nktv_({l1l11ll11l1l11_nktv_ (u"ࠨ࡯ࡲࡨࡪ࠭࡟"): mode, l1l11ll11l1l11_nktv_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭ࡠ"): name, l1l11ll11l1l11_nktv_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫࡡ") : url, l1l11ll11l1l11_nktv_ (u"ࠫࡵࡧࡧࡦࠩࡢ"):l1l11llll11l1l11_nktv_})
    l1l111llll11l1l11_nktv_ = xbmcgui.ListItem(name)
    l11ll111ll11l1l11_nktv_=[l1l11ll11l1l11_nktv_ (u"ࠬࡺࡨࡶ࡯ࡥࠫࡣ"),l1l11ll11l1l11_nktv_ (u"࠭ࡰࡰࡵࡷࡩࡷ࠭ࡤ"),l1l11ll11l1l11_nktv_ (u"ࠧࡣࡣࡱࡲࡪࡸࠧࡥ"),l1l11ll11l1l11_nktv_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨࡦ"),l1l11ll11l1l11_nktv_ (u"ࠩࡦࡰࡪࡧࡲࡢࡴࡷࠫࡧ"),l1l11ll11l1l11_nktv_ (u"ࠪࡧࡱ࡫ࡡࡳ࡮ࡲ࡫ࡴ࠭ࡨ"),l1l11ll11l1l11_nktv_ (u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫ࠧࡩ"),l1l11ll11l1l11_nktv_ (u"ࠬ࡯ࡣࡰࡰࠪࡪ")]
    l1l111lll11l1l11_nktv_ = dict(zip(l11ll111ll11l1l11_nktv_,[l11l11lll11l1l11_nktv_ for x in l11ll111ll11l1l11_nktv_]))
    l1l111lll11l1l11_nktv_[l1l11ll11l1l11_nktv_ (u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦࠩ࡫")] = fanart if fanart else l1l111lll11l1l11_nktv_[l1l11ll11l1l11_nktv_ (u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪ࡬")]
    l1l111llll11l1l11_nktv_.setArt(l1l111lll11l1l11_nktv_)
    if not infoLabels:
        infoLabels={l1l11ll11l1l11_nktv_ (u"ࠣࡶ࡬ࡸࡱ࡫ࠢ࡭"): name}
    l1l111llll11l1l11_nktv_.setInfo(type=l1l11ll11l1l11_nktv_ (u"ࠤࡹ࡭ࡩ࡫࡯ࠣ࡮"), infoLabels=infoLabels)
    if IsPlayable:
        l1l111llll11l1l11_nktv_.setProperty(l1l11ll11l1l11_nktv_ (u"ࠪࡍࡸࡖ࡬ࡢࡻࡤࡦࡱ࡫ࠧ࡯"), l1l11ll11l1l11_nktv_ (u"ࠫࡹࡸࡵࡦࠩࡰ"))
    l11l1llll11l1l11_nktv_ = []
    l11l1llll11l1l11_nktv_.append((l1l11ll11l1l11_nktv_ (u"ࠬࡏ࡮ࡧࡱࡵࡱࡦࡩࡪࡢࠩࡱ"), l1l11ll11l1l11_nktv_ (u"࠭ࡘࡃࡏࡆ࠲ࡆࡩࡴࡪࡱࡱࠬࡎࡴࡦࡰࠫࠪࡲ")))
    l1l111llll11l1l11_nktv_.addContextMenuItems(l11l1llll11l1l11_nktv_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l1lll11lll11l1l11_nktv_, url=u, listitem=l1l111llll11l1l11_nktv_,isFolder=False,totalItems=l111ll1ll11l1l11_nktv_)
    xbmcplugin.addSortMethod(l1lll11lll11l1l11_nktv_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1l11ll11l1l11_nktv_ (u"ࠢࠦࡔ࠯ࠤࠪ࡟ࠬࠡࠧࡓࠦࡳ"))
    return ok
def l111lllll11l1l11_nktv_(name,ex_link=None, l1l11llll11l1l11_nktv_=1, mode=l1l11ll11l1l11_nktv_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨࡴ"),iconImage=l1l11ll11l1l11_nktv_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬࠭ࡵ"), infoLabels=None, fanart=l11ll1l1ll11l1l11_nktv_,contextmenu=None):
    url = l1l1llll11l1l11_nktv_({l1l11ll11l1l11_nktv_ (u"ࠪࡱࡴࡪࡥࠨࡶ"): mode, l1l11ll11l1l11_nktv_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨࡷ"): name, l1l11ll11l1l11_nktv_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭ࡸ") : ex_link, l1l11ll11l1l11_nktv_ (u"࠭ࡰࡢࡩࡨࠫࡹ") : l1l11llll11l1l11_nktv_})
    l1111lll11l1l11_nktv_ = xbmcgui.ListItem(name)
    if infoLabels:
        l1111lll11l1l11_nktv_.setInfo(type=l1l11ll11l1l11_nktv_ (u"ࠢࡷ࡫ࡧࡩࡴࠨࡺ"), infoLabels=infoLabels)
    l11ll111ll11l1l11_nktv_=[l1l11ll11l1l11_nktv_ (u"ࠨࡶ࡫ࡹࡲࡨࠧࡻ"),l1l11ll11l1l11_nktv_ (u"ࠩࡳࡳࡸࡺࡥࡳࠩࡼ"),l1l11ll11l1l11_nktv_ (u"ࠪࡦࡦࡴ࡮ࡦࡴࠪࡽ"),l1l11ll11l1l11_nktv_ (u"ࠫࡨࡲࡥࡢࡴࡤࡶࡹ࠭ࡾ"),l1l11ll11l1l11_nktv_ (u"ࠬࡩ࡬ࡦࡣࡵࡰࡴ࡭࡯ࠨࡿ"),l1l11ll11l1l11_nktv_ (u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦࠩࢀ"),l1l11ll11l1l11_nktv_ (u"ࠧࡪࡥࡲࡲࠬࢁ")]
    l1l111lll11l1l11_nktv_ = dict(zip(l11ll111ll11l1l11_nktv_,[iconImage for x in l11ll111ll11l1l11_nktv_]))
    l1l111lll11l1l11_nktv_[l1l11ll11l1l11_nktv_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫࢂ")] = fanart if fanart else l1l111lll11l1l11_nktv_[l1l11ll11l1l11_nktv_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬࢃ")]
    l1111lll11l1l11_nktv_.setArt(l1l111lll11l1l11_nktv_)
    if contextmenu:
        l11l1llll11l1l11_nktv_=contextmenu
        l1111lll11l1l11_nktv_.addContextMenuItems(l11l1llll11l1l11_nktv_, replaceItems=True)
    else:
        l11l1llll11l1l11_nktv_ = []
        l11l1llll11l1l11_nktv_.append((l1l11ll11l1l11_nktv_ (u"ࠪࡍࡳ࡬࡯ࡳ࡯ࡤࡧ࡯ࡧࠧࢄ"), l1l11ll11l1l11_nktv_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡄࡧࡹ࡯࡯࡯ࠪࡌࡲ࡫ࡵࠩࠨࢅ")),)
        l1111lll11l1l11_nktv_.addContextMenuItems(l11l1llll11l1l11_nktv_, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=l1lll11lll11l1l11_nktv_, url=url,listitem=l1111lll11l1l11_nktv_, isFolder=True)
    xbmcplugin.addSortMethod(l1lll11lll11l1l11_nktv_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1l11ll11l1l11_nktv_ (u"ࠧࠫࡒ࠭ࠢࠨ࡝࠱ࠦࠥࡑࠤࢆ"))
def l1l11111ll11l1l11_nktv_(name, url=l1l11ll11l1l11_nktv_ (u"࠭ࠧࢇ"), mode=l1l11ll11l1l11_nktv_ (u"ࠧࠨ࢈"), l11l11lll11l1l11_nktv_=None, fanart=l11ll1l1ll11l1l11_nktv_):
    u = l1l1llll11l1l11_nktv_({l1l11ll11l1l11_nktv_ (u"ࠨ࡯ࡲࡨࡪ࠭ࢉ"): mode, l1l11ll11l1l11_nktv_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭ࢊ"): name, l1l11ll11l1l11_nktv_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫࢋ") : url, l1l11ll11l1l11_nktv_ (u"ࠫࡵࡧࡧࡦࠩࢌ"):1})
    l1l111llll11l1l11_nktv_ = xbmcgui.ListItem(name, iconImage=l11l11lll11l1l11_nktv_, thumbnailImage=l11l11lll11l1l11_nktv_)
    l1l111llll11l1l11_nktv_.setProperty(l1l11ll11l1l11_nktv_ (u"ࠬࡏࡳࡑ࡮ࡤࡽࡦࡨ࡬ࡦࠩࢍ"), l1l11ll11l1l11_nktv_ (u"࠭ࡦࡢ࡮ࡶࡩࠬࢎ"))
    if fanart:
        l1l111llll11l1l11_nktv_.setProperty(l1l11ll11l1l11_nktv_ (u"ࠧࡧࡣࡱࡥࡷࡺ࡟ࡪ࡯ࡤ࡫ࡪ࠭࢏"),fanart)
    ok = xbmcplugin.addDirectoryItem(handle=l1lll11lll11l1l11_nktv_, url=u, listitem=l1l111llll11l1l11_nktv_,isFolder=False)
    return ok
def l11l1lll11l1l11_nktv_(l11lll1lll11l1l11_nktv_):
    l1l1l11lll11l1l11_nktv_ = {}
    for k, v in l11lll1lll11l1l11_nktv_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l1l11ll11l1l11_nktv_ (u"ࠨࡷࡷࡪ࠽࠭࢐"))
        elif isinstance(v, str):
            v.decode(l1l11ll11l1l11_nktv_ (u"ࠩࡸࡸ࡫࠾ࠧ࢑"))
        l1l1l11lll11l1l11_nktv_[k] = v
    return l1l1l11lll11l1l11_nktv_
def l1l1llll11l1l11_nktv_(query):
    return l111llll11l1l11_nktv_ + l1l11ll11l1l11_nktv_ (u"ࠪࡃࠬ࢒") + urllib.urlencode(l11l1lll11l1l11_nktv_(query))
def l1lllllll11l1l11_nktv_(ex_link,l1l11llll11l1l11_nktv_):
    l1l11llll11l1l11_nktv_ = int(l1l11llll11l1l11_nktv_) if l1l11llll11l1l11_nktv_ else 1
    group=l1l11ll11l1l11_nktv_ (u"ࠫࠬ࢓")
    if l1l11ll11l1l11_nktv_ (u"ࠬࢂࠧ࢔")in ex_link:
        ex_link,group = ex_link.split(l1l11ll11l1l11_nktv_ (u"࠭ࡼࠨ࢕"))
    l1lll1l1ll11l1l11_nktv_,l1l1llllll11l1l11_nktv_ = l1l11l11ll11l1l11_nktv_.l1ll1ll1ll11l1l11_nktv_(ex_link,l1l11llll11l1l11_nktv_,group)
    if l1l1llllll11l1l11_nktv_[0]:
        l11lllllll11l1l11_nktv_(name=l1l11ll11l1l11_nktv_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࡂ࠼ࠡࡲࡲࡴࡷࢀࡥࡥࡰ࡬ࡥࠥࡹࡴࡳࡱࡱࡥࠥࡂ࠼࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࢖"), url=ex_link, mode=l1l11ll11l1l11_nktv_ (u"ࠨࡡࡢࡴࡦ࡭ࡥࡠࡡࡐࠫࢗ"), l1l11llll11l1l11_nktv_=l1l1llllll11l1l11_nktv_[0], IsPlayable=False)
    items=len(l1lll1l1ll11l1l11_nktv_)
    for f in l1lll1l1ll11l1l11_nktv_:
        l11lllllll11l1l11_nktv_(name=f.get(l1l11ll11l1l11_nktv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ࢘")), url=f.get(l1l11ll11l1l11_nktv_ (u"ࠪ࡬ࡷ࡫ࡦࠨ࢙")), mode=l1l11ll11l1l11_nktv_ (u"ࠫ࡬࡫ࡴࡍ࡫ࡱ࡯ࡸ࢚࠭"), l11l11lll11l1l11_nktv_=f.get(l1l11ll11l1l11_nktv_ (u"ࠬ࡯࡭ࡨ࢛ࠩ")), infoLabels=f, IsPlayable=True,l111ll1ll11l1l11_nktv_=items)
    if l1l1llllll11l1l11_nktv_[1]:
        l11lllllll11l1l11_nktv_(name=l1l11ll11l1l11_nktv_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࡃࡄࠠ࡯ࡣࡶࡸञࡶ࡮ࡢࠢࡶࡸࡷࡵ࡮ࡢࠢࡁࡂࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࢜"), url=ex_link, mode=l1l11ll11l1l11_nktv_ (u"ࠧࡠࡡࡳࡥ࡬࡫࡟ࡠࡏࠪ࢝"), l1l11llll11l1l11_nktv_=l1l1llllll11l1l11_nktv_[1], IsPlayable=False)
def l1l11l1ll11l1l11_nktv_(ex_link,l1l11llll11l1l11_nktv_):
    l1l11llll11l1l11_nktv_ = int(l1l11llll11l1l11_nktv_) if l1l11llll11l1l11_nktv_ else 1
    group=l1l11ll11l1l11_nktv_ (u"ࠨࠩ࢞")
    if l1l11ll11l1l11_nktv_ (u"ࠩࡿࠫ࢟")in ex_link:
        ex_link,group = ex_link.split(l1l11ll11l1l11_nktv_ (u"ࠪࢀࠬࢠ"))
    if group:
        l1lll1l1ll11l1l11_nktv_,l1l1llllll11l1l11_nktv_ = l1l11l11ll11l1l11_nktv_.l1ll1ll1ll11l1l11_nktv_(ex_link,int(l1l11llll11l1l11_nktv_),group)
    else:
        l1lll1l1ll11l1l11_nktv_,l1l1llllll11l1l11_nktv_ = l1l11l11ll11l1l11_nktv_.l1l1l1lll11l1l11_nktv_(ex_link)
    l1ll1lllll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠫ࡬࡫ࡴࡆࡲ࡬ࡷࡴࡪࡥࡴࠩࢡ")
    if l1l11ll11l1l11_nktv_ (u"ࠬࡺࡲࡶࡧࠪࢢ") in l11l1l1ll11l1l11_nktv_.getSetting(l1l11ll11l1l11_nktv_ (u"࠭ࡧࡳࡱࡸࡴࡊࡶࡩࡴࡱࡧࡩࡸ࠭ࢣ")):
        l1ll1lllll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠧࡨࡧࡷࡗࡪࡧࡳࡰࡰࡶࠫࢤ")
    if l1l1llllll11l1l11_nktv_[0]:
        l11lllllll11l1l11_nktv_(name=l1l11ll11l1l11_nktv_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣ࠼࠽ࠢࡳࡳࡵࡸࡺࡦࡦࡱ࡭ࡦࠦࡳࡵࡴࡲࡲࡦࠦ࠼࠽࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢥ"), url=ex_link, mode=l1l11ll11l1l11_nktv_ (u"ࠩࡢࡣࡵࡧࡧࡦࡡࡢࡗࠬࢦ"), l1l11llll11l1l11_nktv_=l1l1llllll11l1l11_nktv_[0], IsPlayable=False)
    items=len(l1lll1l1ll11l1l11_nktv_)
    for f in l1lll1l1ll11l1l11_nktv_:
        l111lllll11l1l11_nktv_(name=f.get(l1l11ll11l1l11_nktv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩࢧ")), ex_link=f.get(l1l11ll11l1l11_nktv_ (u"ࠫ࡭ࡸࡥࡧࠩࢨ")), mode=l1ll1lllll11l1l11_nktv_, iconImage=f.get(l1l11ll11l1l11_nktv_ (u"ࠬ࡯࡭ࡨࠩࢩ")), infoLabels=f)
    if l1l1llllll11l1l11_nktv_[1]:
        l11lllllll11l1l11_nktv_(name=l1l11ll11l1l11_nktv_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࡃࡄࠠ࡯ࡣࡶࡸञࡶ࡮ࡢࠢࡶࡸࡷࡵ࡮ࡢࠢࡁࡂࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢪ"), url=ex_link, mode=l1l11ll11l1l11_nktv_ (u"ࠧࡠࡡࡳࡥ࡬࡫࡟ࡠࡕࠪࢫ"), l1l11llll11l1l11_nktv_=l1l1llllll11l1l11_nktv_[1], IsPlayable=False)
def l11l111ll11l1l11_nktv_(ex_link):
    l1l11lll11l1l11_nktv_ = l1l11l11ll11l1l11_nktv_.l1111l1ll11l1l11_nktv_(ex_link)
    for f in l1l11lll11l1l11_nktv_:
        l11lllllll11l1l11_nktv_(name=f.get(l1l11ll11l1l11_nktv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࢬ")), url=f.get(l1l11ll11l1l11_nktv_ (u"ࠩ࡫ࡶࡪ࡬ࠧࢭ")), mode=l1l11ll11l1l11_nktv_ (u"ࠪ࡫ࡪࡺࡌࡪࡰ࡮ࡷࠬࢮ"), l11l11lll11l1l11_nktv_=f.get(l1l11ll11l1l11_nktv_ (u"ࠫ࡮ࡳࡧࠨࢯ")), infoLabels=f, IsPlayable=True)
def l11111lll11l1l11_nktv_(ex_link):
    l1l11lll11l1l11_nktv_ = l1l11l11ll11l1l11_nktv_.l1111l1ll11l1l11_nktv_(ex_link)
    l11lll11ll11l1l11_nktv_ =l1l11l11ll11l1l11_nktv_.l11lllll11l1l11_nktv_(l1l11lll11l1l11_nktv_)
    for l1l111ll11l1l11_nktv_ in sorted(l11lll11ll11l1l11_nktv_.keys()):
        l111lllll11l1l11_nktv_(name=l1l111ll11l1l11_nktv_, ex_link=urllib.quote(str(l11lll11ll11l1l11_nktv_[l1l111ll11l1l11_nktv_])), mode=l1l11ll11l1l11_nktv_ (u"ࠬ࡭ࡥࡵࡇࡳ࡭ࡸࡵࡤࡦࡵ࠵ࠫࢰ"))
    xbmcplugin.setContent(l1lll11lll11l1l11_nktv_, l1l11ll11l1l11_nktv_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭ࢱ"))
def l1ll11lll11l1l11_nktv_(ex_link):
    l1l11lll11l1l11_nktv_ = eval(urllib.unquote(ex_link))
    for f in l1l11lll11l1l11_nktv_:
        l11lllllll11l1l11_nktv_(name=f.get(l1l11ll11l1l11_nktv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࢲ")), url=f.get(l1l11ll11l1l11_nktv_ (u"ࠨࡪࡵࡩ࡫࠭ࢳ")), mode=l1l11ll11l1l11_nktv_ (u"ࠩࡪࡩࡹࡒࡩ࡯࡭ࡶࠫࢴ"), l11l11lll11l1l11_nktv_=f.get(l1l11ll11l1l11_nktv_ (u"ࠪ࡭ࡲ࡭ࠧࢵ")), infoLabels=f, IsPlayable=True,fanart=f.get(l1l11ll11l1l11_nktv_ (u"ࠫ࡮ࡳࡧࠨࢶ")))
    xbmcplugin.setContent(l1lll11lll11l1l11_nktv_, l1l11ll11l1l11_nktv_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪࡹࠧࢷ"))
def l11llllll11l1l11_nktv_(ex_link):
    l1lll1l1ll11l1l11_nktv_,l1l11l1lll11l1l11_nktv_ = l1l11l11ll11l1l11_nktv_.search(ex_link)
    for f in l1lll1l1ll11l1l11_nktv_:
        l11lllllll11l1l11_nktv_(name=f.get(l1l11ll11l1l11_nktv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࢸ")), url=f.get(l1l11ll11l1l11_nktv_ (u"ࠧࡩࡴࡨࡪࠬࢹ")), mode=l1l11ll11l1l11_nktv_ (u"ࠨࡩࡨࡸࡑ࡯࡮࡬ࡵࠪࢺ"), l11l11lll11l1l11_nktv_=f.get(l1l11ll11l1l11_nktv_ (u"ࠩ࡬ࡱ࡬࠭ࢻ")), infoLabels=f, IsPlayable=True,l111ll1ll11l1l11_nktv_=len(l1lll1l1ll11l1l11_nktv_))
    for f in l1l11l1lll11l1l11_nktv_:
        l111lllll11l1l11_nktv_(name=f.get(l1l11ll11l1l11_nktv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩࢼ")), ex_link=f.get(l1l11ll11l1l11_nktv_ (u"ࠫ࡭ࡸࡥࡧࠩࢽ")), mode=l1l11ll11l1l11_nktv_ (u"ࠬ࡭ࡥࡵࡇࡳ࡭ࡸࡵࡤࡦࡵࠪࢾ"), iconImage=f.get(l1l11ll11l1l11_nktv_ (u"࠭ࡩ࡮ࡩࠪࢿ")), infoLabels=f)
def l111l11ll11l1l11_nktv_(ex_link):
    l1l1l1l1ll11l1l11_nktv_ = l1l11l11ll11l1l11_nktv_.l1l1lllll11l1l11_nktv_(ex_link)
    l11llll1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠧࠨࣀ")
    t = [ x.get(l1l11ll11l1l11_nktv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࣁ")) for x in l1l1l1l1ll11l1l11_nktv_]
    u = [ x.get(l1l11ll11l1l11_nktv_ (u"ࠩࡸࡶࡱ࠭ࣂ")) for x in l1l1l1l1ll11l1l11_nktv_]
    h = [ x.get(l1l11ll11l1l11_nktv_ (u"ࠪ࡬ࡴࡹࡴࠨࣃ")) for x in l1l1l1l1ll11l1l11_nktv_]
    l1ll1lll11l1l11_nktv_ = xbmcgui.Dialog().select(l1l11ll11l1l11_nktv_ (u"ࠦॾࡸࣳࡥॄࡤࠤࠧࣄ"), t) if len(t)>0 else -1
    if l1ll1lll11l1l11_nktv_>-1:
        l1ll11l1ll11l1l11_nktv_ = u[l1ll1lll11l1l11_nktv_]
        l11llll1ll11l1l11_nktv_=l11lll1ll11l1l11_nktv_.__mysolver__.go(l1ll11l1ll11l1l11_nktv_)
        if False:
            if l1l11ll11l1l11_nktv_ (u"ࠬࡶ࡬ࡢࡻࡨࡶࡳࡧࡵࡵࠩࣅ") in l1ll11l1ll11l1l11_nktv_: l1ll11l1ll11l1l11_nktv_ = l1ll11l1ll11l1l11_nktv_.replace(l1l11ll11l1l11_nktv_ (u"࠭ࡰ࡭ࡣࡼࡩࡷࡴࡡࡶࡶࠪࣆ"),l1l11ll11l1l11_nktv_ (u"ࠧࡳࡣࡳࡸࡺ࠭ࣇ"))
            if l1l11ll11l1l11_nktv_ (u"ࠨࡥࡧࡥࠬࣈ") in h[l1ll1lll11l1l11_nktv_]:
                l11llll1ll11l1l11_nktv_ = l1111llll11l1l11_nktv_.l1ll1111ll11l1l11_nktv_(l1ll11l1ll11l1l11_nktv_)
                if type(l11llll1ll11l1l11_nktv_) is list:
                    l1l1lll1ll11l1l11_nktv_ = [x[0] for x in l11llll1ll11l1l11_nktv_]
                    l1ll1lll11l1l11_nktv_ = xbmcgui.Dialog().select(l1l11ll11l1l11_nktv_ (u"ࠤ࡚ࡽࡧ࡯ࡥࡳࡼࠥࣉ"), l1l1lll1ll11l1l11_nktv_)
                    if l1ll1lll11l1l11_nktv_>-1:
                        l11llll1ll11l1l11_nktv_ = l1111llll11l1l11_nktv_.l1ll1111ll11l1l11_nktv_(l11llll1ll11l1l11_nktv_[l1ll1lll11l1l11_nktv_][1])
                    else:
                        l11llll1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠪࠫ࣊")
            elif l1l11ll11l1l11_nktv_ (u"ࠫࡷࡧࡰࡪࡦࡹ࡭ࡩ࡫࡯࠯ࡥࡲࡱࠬ࣋") in h[l1ll1lll11l1l11_nktv_] or l1l11ll11l1l11_nktv_ (u"ࠬࡸࡡࡱࡶࡸ࠲ࡨࡵ࡭ࠨ࣌") in h[l1ll1lll11l1l11_nktv_] or l1l11ll11l1l11_nktv_ (u"࠭ࡰ࡭ࡣࡼࡩࡷࡴࡡࡶࡶࠪ࣍") in h[l1ll1lll11l1l11_nktv_]:
                l11llll1ll11l1l11_nktv_ = l1l1ll1ll11l1l11_nktv_.l1ll1111ll11l1l11_nktv_(l1ll11l1ll11l1l11_nktv_)
                if type(l11llll1ll11l1l11_nktv_) is list:
                    l1l1lll1ll11l1l11_nktv_ = [x[0] for x in l11llll1ll11l1l11_nktv_]
                    l1ll1lll11l1l11_nktv_ = xbmcgui.Dialog().select(l1l11ll11l1l11_nktv_ (u"ࠢࡘࡻࡥ࡭ࡪࡸࡺࠣ࣎"), l1l1lll1ll11l1l11_nktv_)
                    if l1ll1lll11l1l11_nktv_>-1:
                        l11llll1ll11l1l11_nktv_ = l11llll1ll11l1l11_nktv_[l1ll1lll11l1l11_nktv_][1]
                    else:
                        l11llll1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠨ࣏ࠩ")
        if not l11llll1ll11l1l11_nktv_:
            try:
                l11llll1ll11l1l11_nktv_ = urlresolver.resolve(l1ll11l1ll11l1l11_nktv_)
            except Exception,e:
                l11llll1ll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"࣐ࠩࠪ")
                s = xbmcgui.Dialog().ok(l1l11ll11l1l11_nktv_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࡑࡴࡲࡦࡱ࡫࡭࡜࠱ࡆࡓࡑࡕࡒ࡞࣑ࠩ"),l1l11ll11l1l11_nktv_ (u"ࠫࡒࡵॼࡦࠢ࡬ࡲࡳࡿࠠ࡭࡫ࡱ࡯ࠥࡨࡥࡥࡼ࡬ࡩࠥࡪࡺࡪࡣॅࡥेࡅ࣒ࠧ"),l1l11ll11l1l11_nktv_ (u"ࠬࡋࡒࡓࡑࡕ࠾ࠥࠫࡳࠨ࣓")%str(e))
    if l11llll1ll11l1l11_nktv_:
        xbmcplugin.setResolvedUrl(l1lll11lll11l1l11_nktv_, True, xbmcgui.ListItem(path=l11llll1ll11l1l11_nktv_))
    else:
        xbmcplugin.setResolvedUrl(l1lll11lll11l1l11_nktv_, False, xbmcgui.ListItem(path=l1l11ll11l1l11_nktv_ (u"࠭ࠧࣔ")))
def l1lll111ll11l1l11_nktv_():
    return cache.get(l1l11ll11l1l11_nktv_ (u"ࠧࡩ࡫ࡶࡸࡴࡸࡹࠨࣕ")).split(l1l11ll11l1l11_nktv_ (u"ࠨ࠽ࠪࣖ"))
def l1ll1llll11l1l11_nktv_(entry):
    l1l1l1llll11l1l11_nktv_ = l1lll111ll11l1l11_nktv_()
    if l1l1l1llll11l1l11_nktv_ == [l1l11ll11l1l11_nktv_ (u"ࠩࠪࣗ")]:
        l1l1l1llll11l1l11_nktv_ = []
    l1l1l1llll11l1l11_nktv_.insert(0, entry)
    cache.set(l1l11ll11l1l11_nktv_ (u"ࠪ࡬࡮ࡹࡴࡰࡴࡼࠫࣘ"),l1l11ll11l1l11_nktv_ (u"ࠫࡀ࠭ࣙ").join(l1l1l1llll11l1l11_nktv_[:50]))
def l11ll11ll11l1l11_nktv_(entry):
    l1l1l1llll11l1l11_nktv_ = l1lll111ll11l1l11_nktv_()
    if l1l1l1llll11l1l11_nktv_:
        cache.set(l1l11ll11l1l11_nktv_ (u"ࠬ࡮ࡩࡴࡶࡲࡶࡾ࠭ࣚ"),l1l11ll11l1l11_nktv_ (u"࠭࠻ࠨࣛ").join(l1l1l1llll11l1l11_nktv_[:50]))
    else:
        l111l1lll11l1l11_nktv_()
def l111l1lll11l1l11_nktv_():
    cache.delete(l1l11ll11l1l11_nktv_ (u"ࠧࡩ࡫ࡶࡸࡴࡸࡹࠨࣜ"))
mode = args.get(l1l11ll11l1l11_nktv_ (u"ࠨ࡯ࡲࡨࡪ࠭ࣝ"), None)
fname = args.get(l1l11ll11l1l11_nktv_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭ࣞ"),[l1l11ll11l1l11_nktv_ (u"ࠪࠫࣟ")])[0]
ex_link = args.get(l1l11ll11l1l11_nktv_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬ࣠"),[l1l11ll11l1l11_nktv_ (u"ࠬ࠭࣡")])[0]
l1l11llll11l1l11_nktv_ = args.get(l1l11ll11l1l11_nktv_ (u"࠭ࡰࡢࡩࡨࠫ࣢"),[1])[0]
l11ll1lll11l1l11_nktv_ = l11l1l1ll11l1l11_nktv_.getSetting(l1l11ll11l1l11_nktv_ (u"ࠧࡴࡱࡵࡸ࡛ࣣ࠭"))
l1llll11ll11l1l11_nktv_ = l11l1l1ll11l1l11_nktv_.getSetting(l1l11ll11l1l11_nktv_ (u"ࠨࡵࡲࡶࡹࡔࠧࣤ")) if l11ll1lll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠩࡇࡥࡹࡿࠠࡥࡱࡧࡥࡳ࡯ࡡࠨࣥ")
l1lll1lll11l1l11_nktv_ = l11l1l1ll11l1l11_nktv_.getSetting(l1l11ll11l1l11_nktv_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼ࡚ࣦࠬ"))
l1ll1l1ll11l1l11_nktv_ = l11l1l1ll11l1l11_nktv_.getSetting(l1l11ll11l1l11_nktv_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࡓ࠭ࣧ")) if l1lll1lll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠬ࡝ࡳࡻࡻࡶࡸࡰ࡯ࡥࠨࣨ")
l1ll1l1lll11l1l11_nktv_ = l11l1l1ll11l1l11_nktv_.getSetting(l1l11ll11l1l11_nktv_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࡖࠨࣩ"))
l1ll111lll11l1l11_nktv_ = l11l1l1ll11l1l11_nktv_.getSetting(l1l11ll11l1l11_nktv_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࡏࠩ࣪")) if l1ll1l1lll11l1l11_nktv_ else l1l11ll11l1l11_nktv_ (u"ࠨ࡙ࡶࡾࡾࡹࡴ࡬࡫ࡨࠫ࣫")
if mode is None:
    l111lllll11l1l11_nktv_(name=l1l11ll11l1l11_nktv_ (u"ࠩࡌࡲ࡫ࡵࡲ࡮ࡣࡦ࡮ࡦ࠭࣬"),mode=l1l11ll11l1l11_nktv_ (u"ࠪࡣ࡮ࡴࡦࡰࡡ࣭ࠪ"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1l11ll11l1l11_nktv_ (u"ࠫࡵࡧࡴࡩ࣮ࠩ")))+l1l11ll11l1l11_nktv_ (u"ࠬ࠵ࡩࡤࡱࡱ࠲ࡵࡴࡧࠨ࣯"),infoLabels={})
    l11lllllll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠨ࡛ࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸࡧࡲࡵࡦ࡟ࡖࡳࡷࡺ࡯ࡸࡣࡱ࡭ࡪࡀ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠡ࡝ࡅࡡࣰࠧ")+l1llll11ll11l1l11_nktv_+l1l11ll11l1l11_nktv_ (u"ࠢ࡜࠱ࡅࡡࣱࠧ"),l1l11ll11l1l11_nktv_ (u"ࠨࣲࠩ"),mode=l1l11ll11l1l11_nktv_ (u"ࠩࡩ࡭ࡱࡺࡲ࠻ࡵࡲࡶࡹ࠭ࣳ"),l11l11lll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠪࠫࣴ"),IsPlayable=False)
    l11lllllll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠦࡠࡉࡏࡍࡑࡕࠤࡱ࡯ࡧࡩࡶࡥࡰࡺ࡫࡝ࡋࡣ࡮ࡳॠऍ࠺࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࡞ࡆࡢࠨࣵ")+l1ll1l1ll11l1l11_nktv_+l1l11ll11l1l11_nktv_ (u"ࠧࡡ࠯ࡃ࡟ࣶࠥ"),l1l11ll11l1l11_nktv_ (u"࠭ࠧࣷ"),mode=l1l11ll11l1l11_nktv_ (u"ࠧࡧ࡫࡯ࡸࡷࡀࡱࡶࡣ࡯࡭ࡹࡿࠧࣸ"),l11l11lll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"ࠨࣹࠩ"),IsPlayable=False)
    l11lllllll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠤ࡞ࡇࡔࡒࡏࡓࠢ࡯࡭࡬࡮ࡴࡣ࡮ࡸࡩࡢ࡝ࡥࡳࡵ࡭ࡥ࠿ࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࡜ࡄࡠࣺࠦ")+l1ll111lll11l1l11_nktv_+l1l11ll11l1l11_nktv_ (u"ࠥ࡟࠴ࡈ࡝ࠣࣻ"),l1l11ll11l1l11_nktv_ (u"ࠫࠬࣼ"),mode=l1l11ll11l1l11_nktv_ (u"ࠬ࡬ࡩ࡭ࡶࡵ࠾ࡻ࡫ࡲࡴ࡫ࡲࡲࠬࣽ"),l11l11lll11l1l11_nktv_=l1l11ll11l1l11_nktv_ (u"࠭ࠧࣾ"),IsPlayable=False)
    l111lllll11l1l11_nktv_(name=l1l11ll11l1l11_nktv_ (u"ࠢ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࡌࡩ࡭࡯ࡼ࡟࠴ࡉࡏࡍࡑࡕࡡࠧࣿ"),ex_link=l1l11ll11l1l11_nktv_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡱࡥࡸࢀࡥ࠮࡭࡬ࡲࡴ࠴ࡴࡷ࠱ࡩ࡭ࡱࡳࡹ࠮ࡱࡱࡰ࡮ࡴࡥ࠰ࠩऀ"),l1l11llll11l1l11_nktv_=1, mode=l1l11ll11l1l11_nktv_ (u"ࠩࡏ࡭ࡸࡺࡍࡰࡸ࡬ࡩࡸ࠭ँ"),iconImage=l1l11ll11l1l11_nktv_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧं"),fanart=l11ll1l1ll11l1l11_nktv_)
    l111lllll11l1l11_nktv_(name=l1l11ll11l1l11_nktv_ (u"ࠦࠥࡕࡳࡵࡣࡷࡲ࡮ࡵࠠࡥࡱࡧࡥࡳ࡫ࠠࡧ࡫࡯ࡱࡾࠨः"),ex_link=l1l11ll11l1l11_nktv_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡮ࡢࡵࡽࡩ࠲ࡱࡩ࡯ࡱ࠱ࡸࡻ࠵ࡼࡐࡵࡷࡥࡹࡴࡩࡰࠢࡧࡳࡩࡧ࡮ࡦࠢࡩ࡭ࡱࡳࡹࠨऄ"),l1l11llll11l1l11_nktv_=1, mode=l1l11ll11l1l11_nktv_ (u"࠭ࡌࡪࡵࡷࡑࡴࡼࡩࡦࡵࠪअ"),iconImage=l1l11ll11l1l11_nktv_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫआ"),fanart=l11ll1l1ll11l1l11_nktv_)
    l111lllll11l1l11_nktv_(name=l1l11ll11l1l11_nktv_ (u"ࠣࠢࡕࡥࡳࡱࡩ࡯ࡩࠣࡲࡴࡽ࡯ड़ࡥ࡬ࠦइ"),ex_link=l1l11ll11l1l11_nktv_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡲࡦࡹࡺࡦ࠯࡮࡭ࡳࡵ࠮ࡵࡸ࠲ࢀࡗࡧ࡮࡬࡫ࡱ࡫ࠥࡴ࡯ࡸࠩई"),l1l11llll11l1l11_nktv_=1, mode=l1l11ll11l1l11_nktv_ (u"ࠪࡐ࡮ࡹࡴࡎࡱࡹ࡭ࡪࡹࠧउ"),iconImage=l1l11ll11l1l11_nktv_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠨऊ"),fanart=l11ll1l1ll11l1l11_nktv_)
    l111lllll11l1l11_nktv_(name=l1l11ll11l1l11_nktv_ (u"࡛ࠧࠦࡌࡣࡷࡩ࡬ࡵࡲࡪࡣࡠࠦऋ"),ex_link=l1l11ll11l1l11_nktv_ (u"࠭ࡦࡪ࡮ࡰࢀࡨࡧࡴࡦࡩࡲࡶࡾ࠭ऌ"),l1l11llll11l1l11_nktv_=1, mode=l1l11ll11l1l11_nktv_ (u"ࠧࡈࡣࡷࡹࡳ࡫࡫ࡓࡱ࡮ࠫऍ"),iconImage=l1l11ll11l1l11_nktv_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬऎ"),fanart=l11ll1l1ll11l1l11_nktv_)
    l111lllll11l1l11_nktv_(name=l1l11ll11l1l11_nktv_ (u"ࠤࠣ࡟ࡗࡵ࡫࡞ࠤए"),ex_link=l1l11ll11l1l11_nktv_ (u"ࠪࡪ࡮ࡲ࡭ࡽࡻࡨࡥࡷ࠭ऐ"),l1l11llll11l1l11_nktv_=1, mode=l1l11ll11l1l11_nktv_ (u"ࠫࡌࡧࡴࡶࡰࡨ࡯ࡗࡵ࡫ࠨऑ"),iconImage=l1l11ll11l1l11_nktv_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹࡌ࡯࡭ࡦࡨࡶ࠳ࡶ࡮ࡨࠩऒ"),fanart=l11ll1l1ll11l1l11_nktv_)
    l111lllll11l1l11_nktv_(name=l1l11ll11l1l11_nktv_ (u"ࠨࠠ࡜ࡍࡵࡥ࡯ࡣࠢओ"),ex_link=l1l11ll11l1l11_nktv_ (u"ࠧࡧ࡫࡯ࡱࢁࡩ࡯ࡶࡰࡷࡶࡾ࠭औ"),l1l11llll11l1l11_nktv_=1, mode=l1l11ll11l1l11_nktv_ (u"ࠨࡉࡤࡸࡺࡴࡥ࡬ࡔࡲ࡯ࠬक"),iconImage=l1l11ll11l1l11_nktv_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬࠭ख"),fanart=l11ll1l1ll11l1l11_nktv_)
    l111lllll11l1l11_nktv_(name=l1l11ll11l1l11_nktv_ (u"ࠥ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞ࡕࡨࡶ࡮ࡧ࡬ࡦࠢࠫࡐ࡮ࡹࡴࡢࠫ࡞࠳ࡈࡕࡌࡐࡔࡠࠦग"),ex_link=l1l11ll11l1l11_nktv_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡴࡡࡴࡼࡨ࠱ࡰ࡯࡮ࡰ࠰ࡷࡺ࠴ࡹࡥࡳ࡫ࡤࡰࡪ࠳࡯࡯࡮࡬ࡲࡪ࠵ࠧघ"),l1l11llll11l1l11_nktv_=1, mode=l1l11ll11l1l11_nktv_ (u"ࠬࡒࡩࡴࡶࡖࡩࡷ࡯ࡡ࡭ࡧࠪङ"),iconImage=l1l11ll11l1l11_nktv_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࠪच"),fanart=l11ll1l1ll11l1l11_nktv_)
    l111lllll11l1l11_nktv_(name=l1l11ll11l1l11_nktv_ (u"ࠢࠡࡑࡶࡸࡦࡺ࡮ࡪࡱࠣࡨࡴࡪࡡ࡯ࡧࠣࡷࡪࡸࡩࡢ࡮ࡨࠦछ"),ex_link=l1l11ll11l1l11_nktv_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡱࡥࡸࢀࡥ࠮࡭࡬ࡲࡴ࠴ࡴࡷ࠱ࡶࡩࡷ࡯ࡡ࡭ࡧ࠰ࡳࡳࡲࡩ࡯ࡧ࠲ࢀࡔࡹࡴࡢࡶࡱ࡭ࡴࠦࡤࡰࡦࡤࡲࡪࠦࡳࡦࡴ࡬ࡥࡱ࡫ࠧज"),l1l11llll11l1l11_nktv_=1, mode=l1l11ll11l1l11_nktv_ (u"ࠩࡏ࡭ࡸࡺࡓࡦࡴ࡬ࡥࡱ࡫ࠧझ"),iconImage=l1l11ll11l1l11_nktv_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧञ"),fanart=l11ll1l1ll11l1l11_nktv_)
    l111lllll11l1l11_nktv_(name=l1l11ll11l1l11_nktv_ (u"ࠦࠥࡖ࡯ࡱࡷ࡯ࡥࡷࡴࡥࠡࡵࡨࡶ࡮ࡧ࡬ࡦࠤट"),ex_link=l1l11ll11l1l11_nktv_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡮ࡢࡵࡽࡩ࠲ࡱࡩ࡯ࡱ࠱ࡸࡻ࠵ࡳࡦࡴ࡬ࡥࡱ࡫࠭ࡰࡰ࡯࡭ࡳ࡫࠯ࡽࡒࡲࡴࡺࡲࡡࡳࡰࡨࠤࡸ࡫ࡲࡪࡣ࡯ࡩࠬठ"),l1l11llll11l1l11_nktv_=1, mode=l1l11ll11l1l11_nktv_ (u"࠭ࡌࡪࡵࡷࡗࡪࡸࡩࡢ࡮ࡨࠫड"),iconImage=l1l11ll11l1l11_nktv_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫढ"),fanart=l11ll1l1ll11l1l11_nktv_)
    l111lllll11l1l11_nktv_(name=l1l11ll11l1l11_nktv_ (u"ࠣ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣࡄ࡭ࡣࠣࡨࡿ࡯ࡥࡤ࡫࡞࠳ࡈࡕࡌࡐࡔࡠࠦण"),ex_link=l1l11ll11l1l11_nktv_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡲࡦࡹࡺࡦ࠯࡮࡭ࡳࡵ࠮ࡵࡸ࠲ࡨࡱࡧ࠭ࡥࡼ࡬ࡩࡨ࡯࠯ࠨत"),l1l11llll11l1l11_nktv_=1, mode=l1l11ll11l1l11_nktv_ (u"ࠪࡐ࡮ࡹࡴࡎࡱࡹ࡭ࡪࡹࠧथ"),iconImage=l1l11ll11l1l11_nktv_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠨद"),fanart=l11ll1l1ll11l1l11_nktv_)
    l111lllll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡲࡩࡨࡪࡷࡦࡱࡻࡥ࡞ࡕࡽࡹࡰࡧࡪ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩध"),l1l11ll11l1l11_nktv_ (u"࠭ࠧन"),mode=l1l11ll11l1l11_nktv_ (u"ࠧࡔࡼࡸ࡯ࡦࡰࠧऩ"))
    l11lllllll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡩࡲࡰࡩࡣ࠭࠾ࡑࡳࡧ࡯࡫࠽࠮࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪप"),l1l11ll11l1l11_nktv_ (u"ࠩࠪफ"),l1l11ll11l1l11_nktv_ (u"ࠪࡓࡵࡩࡪࡦࠩब"))
elif mode[0].startswith(l1l11ll11l1l11_nktv_ (u"ࠫࡤ࡯࡮ࡧࡱࡢࠫभ")): l11lll1ll11l1l11_nktv_.__myinfo__.go(sys.argv)
elif l1l11ll11l1l11_nktv_ (u"ࠬ࡬ࡩ࡭ࡶࡵࠫम") in mode[0]:
    _1l1111lll11l1l11_nktv_ = mode[0].split(l1l11ll11l1l11_nktv_ (u"ࠨ࠺ࠣय"))[-1]
    if _1l1111lll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠧࡴࡱࡵࡸࠬर"):
        label=[l1l11ll11l1l11_nktv_ (u"ࡶࠩࡇࡥࡹࡿࠠࡥࡱࡧࡥࡳ࡯ࡡࠨऱ"),l1l11ll11l1l11_nktv_ (u"ࡷࠪࡐ࡮ࡩࡺࡣࡣࠣ࡫ेࡵࡳࣴࡹࠪल"),l1l11ll11l1l11_nktv_ (u"ࡸࠫࡕࡸࡥ࡮࡫ࡨࡶࡦ࠭ळ"),l1l11ll11l1l11_nktv_ (u"ࡹࠬࡕࡤࡴॄࡲࡲࡾ࠭ऴ"),l1l11ll11l1l11_nktv_ (u"ࡺ࠭ࡏࡤࡧࡱࡥࠬव")]
        value=[l1l11ll11l1l11_nktv_ (u"࠭ࡳࡰࡴࡷ࠾ࡩࡧࡴࡦࠩश"),l1l11ll11l1l11_nktv_ (u"ࠧࡴࡱࡵࡸ࠿ࡼ࡯ࡵࡧࠪष"),l1l11ll11l1l11_nktv_ (u"ࠨࡵࡲࡶࡹࡀࡰࡳࡧࡰ࡭ࡪࡸࡥࠨस"),l1l11ll11l1l11_nktv_ (u"ࠩࡶࡳࡷࡺ࠺ࡷ࡫ࡨࡻࠬह"),l1l11ll11l1l11_nktv_ (u"ࠪࡷࡴࡸࡴ࠻ࡴࡤࡸࡪ࠭ऺ")]
        msg = l1l11ll11l1l11_nktv_ (u"ࠫࡘࡵࡲࡵࡱࡺࡥࡳ࡯ࡥࠨऻ")
    elif _1l1111lll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ़࠭"):
        label=[l1l11ll11l1l11_nktv_ (u"ࡻࠧࡘࡵࡽࡽࡸࡺ࡫ࡪࡧࠪऽ"),l1l11ll11l1l11_nktv_ (u"ࡵࠨࡍࡤࡱࡪࡸࡡࠨा"),l1l11ll11l1l11_nktv_ (u"ࡶࠩࡑ࡭ࡸࡱࡡࠨि"),l1l11ll11l1l11_nktv_ (u"ࡷࠪफ़ࡷ࡫ࡤ࡯࡫ࡤࠫी"),l1l11ll11l1l11_nktv_ (u"ࡸࠫ࡜ࡿࡳࡰ࡭ࡤࠫु")]
        value=[l1l11ll11l1l11_nktv_ (u"ࠫࠬू"),l1l11ll11l1l11_nktv_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾࡀ࠴ࠨृ"),l1l11ll11l1l11_nktv_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿ࠺࠳ࠩॄ"),l1l11ll11l1l11_nktv_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹ࠻࠴ࠪॅ"),l1l11ll11l1l11_nktv_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺ࠼࠶ࠫॆ")]
        msg = l1l11ll11l1l11_nktv_ (u"ࠩࡍࡥࡰࡵज़ईࠩे")
    elif _1l1111lll11l1l11_nktv_==l1l11ll11l1l11_nktv_ (u"ࠪࡺࡪࡸࡳࡪࡱࡱࠫै"):
        label=[l1l11ll11l1l11_nktv_ (u"ࠫ࡜ࡹࡺࡺࡵࡷ࡯࡮࡫ࠧॉ"),l1l11ll11l1l11_nktv_ (u"ࠬࡊࡵࡣࡤ࡬ࡲ࡬࠭ॊ"),l1l11ll11l1l11_nktv_ (u"࠭ࡌࡦ࡭ࡷࡳࡷ࠭ो"),l1l11ll11l1l11_nktv_ (u"ࠧࡍࡧ࡮ࡸࡴࡸࠠࡂ࡯ࡤࡸࡴࡸࠧौ"),l1l11ll11l1l11_nktv_ (u"ࠨࡎࡨ࡯ࡹࡵࡲࠡࡋ࡙ࡓ्ࠬ"),l1l11ll11l1l11_nktv_ (u"ࠩࡑࡥࡵ࡯ࡳࡺࠩॎ"),l1l11ll11l1l11_nktv_ (u"ࠪࡔࡑ࠭ॏ"),l1l11ll11l1l11_nktv_ (u"ࠫࡔࡸࡹࡨ࡫ࡱࡥࡱࡴࡡࠨॐ")]
        value=[l1l11ll11l1l11_nktv_ (u"ࠬ࠭॑"),    l1l11ll11l1l11_nktv_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴ࠺࠳॒ࠩ"),l1l11ll11l1l11_nktv_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮࠻࠳ࠪ॓"),l1l11ll11l1l11_nktv_ (u"ࠨࡸࡨࡶࡸ࡯࡯࡯࠼࠻ࠫ॔"),l1l11ll11l1l11_nktv_ (u"ࠩࡹࡩࡷࡹࡩࡰࡰ࠽࠺ࠬॕ"),l1l11ll11l1l11_nktv_ (u"ࠪࡺࡪࡸࡳࡪࡱࡱ࠾࠸࠭ॖ"),l1l11ll11l1l11_nktv_ (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲ࠿࠺ࠧॗ"),l1l11ll11l1l11_nktv_ (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳࡀ࠷ࠨक़")]
        msg = l1l11ll11l1l11_nktv_ (u"࠭ࡗࡦࡴࡶ࡮ࡦ࠭ख़")
    if _1l1111lll11l1l11_nktv_ in [l1l11ll11l1l11_nktv_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨग़"),l1l11ll11l1l11_nktv_ (u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩज़")]:
        try:
            s = xbmcgui.Dialog().l1l1l11ll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"࡚ࠩࡽࡧ࡯ࡥࡳࡼࠣࡻࡪࡸࡳ࡫ࡧࠣ࡮ञࢀࡹ࡬ࡱࡺउࠬड़"),label)
        except:
            s = xbmcgui.Dialog().select(l1l11ll11l1l11_nktv_ (u"࡛ࠪࡾࡨࡩࡦࡴࡽࠤࡼ࡫ࡲࡴ࡬ࡨࠤ࡯टࡺࡺ࡭ࡲࡻऊ࠭ढ़"),label)
        if isinstance(s,list):
            if 0 in s: s=[0]
            v = _1l1111lll11l1l11_nktv_+l1l11ll11l1l11_nktv_ (u"ࠫ࠿࠭फ़")+l1l11ll11l1l11_nktv_ (u"ࠬ࠲ࠧय़").join( [ value[i].replace(_1l1111lll11l1l11_nktv_+l1l11ll11l1l11_nktv_ (u"࠭࠺ࠨॠ"),l1l11ll11l1l11_nktv_ (u"ࠧࠨॡ")) for i in s])
            n = l1l11ll11l1l11_nktv_ (u"ࠨ࠮ࠪॢ").join( [ label[i] for i in s])
        else:
            s = s if s>-1 else 0
            v = value[s]
            n = label[s]
    else:
        s = xbmcgui.Dialog().select(msg,label)
        s = s if s>-1 else 0
        v = value[s]
        n = label[s]
    l11l1l1ll11l1l11_nktv_.setSetting(_1l1111lll11l1l11_nktv_+l1l11ll11l1l11_nktv_ (u"࡙ࠩࠫॣ"),v)
    l11l1l1ll11l1l11_nktv_.setSetting(_1l1111lll11l1l11_nktv_+l1l11ll11l1l11_nktv_ (u"ࠪࡒࠬ।"),n)
    xbmc.executebuiltin(l1l11ll11l1l11_nktv_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭॥"))
elif mode[0] == l1l11ll11l1l11_nktv_ (u"ࠬࡒࡩࡴࡶࡐࡳࡻ࡯ࡥࡴࠩ०"):
    l1llll1ll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"࠭࠯ࠨ१").join([x for x in [l11ll1lll11l1l11_nktv_,l1lll1lll11l1l11_nktv_,l1ll1l1lll11l1l11_nktv_] if x]) if l1l11ll11l1l11_nktv_ (u"ࠧ࠰ࡨ࡬ࡰࡲࡿ࠭ࡰࡰ࡯࡭ࡳ࡫࠯ࠨ२") in ex_link else l1l11ll11l1l11_nktv_ (u"ࠨࠩ३")
    l1lllllll11l1l11_nktv_(ex_link+l1llll1ll11l1l11_nktv_,l1l11llll11l1l11_nktv_)
    xbmcplugin.setContent(l1lll11lll11l1l11_nktv_, l1l11ll11l1l11_nktv_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩ४"))
elif mode[0] == l1l11ll11l1l11_nktv_ (u"ࠪࡐ࡮ࡹࡴࡎࡱࡹ࡭ࡪࡹࡋࡪࡦࡶࠫ५"):
    l1lllllll11l1l11_nktv_(ex_link,l1l11llll11l1l11_nktv_)
    xbmcplugin.setContent(l1lll11lll11l1l11_nktv_, l1l11ll11l1l11_nktv_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ६"))
elif mode[0] == l1l11ll11l1l11_nktv_ (u"ࠬࡕࡰࡤ࡬ࡨࠫ७"):
    l11l1l1ll11l1l11_nktv_.openSettings()
elif mode[0] == l1l11ll11l1l11_nktv_ (u"࠭࡟ࡠࡲࡤ࡫ࡪࡥ࡟ࡎࠩ८"):
    url = l1l1llll11l1l11_nktv_({l1l11ll11l1l11_nktv_ (u"ࠧ࡮ࡱࡧࡩࠬ९"): l1l11ll11l1l11_nktv_ (u"ࠨࡎ࡬ࡷࡹࡓ࡯ࡷ࡫ࡨࡷࠬ॰"), l1l11ll11l1l11_nktv_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭ॱ"): l1l11ll11l1l11_nktv_ (u"ࠪࠫॲ"), l1l11ll11l1l11_nktv_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬॳ") : ex_link, l1l11ll11l1l11_nktv_ (u"ࠬࡶࡡࡨࡧࠪॴ"): l1l11llll11l1l11_nktv_})
    xbmc.executebuiltin(l1l11ll11l1l11_nktv_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠩࠧࡶ࠭ࠬॵ")% url)
elif mode[0] == l1l11ll11l1l11_nktv_ (u"ࠧࡠࡡࡳࡥ࡬࡫࡟ࡠࡕࠪॶ"):
    url = l1l1llll11l1l11_nktv_({l1l11ll11l1l11_nktv_ (u"ࠨ࡯ࡲࡨࡪ࠭ॷ"): l1l11ll11l1l11_nktv_ (u"ࠩࡏ࡭ࡸࡺࡓࡦࡴ࡬ࡥࡱ࡫ࠧॸ"), l1l11ll11l1l11_nktv_ (u"ࠪࡪࡴࡲࡤࡦࡴࡱࡥࡲ࡫ࠧॹ"): l1l11ll11l1l11_nktv_ (u"ࠫࠬॺ"), l1l11ll11l1l11_nktv_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭ॻ") : ex_link, l1l11ll11l1l11_nktv_ (u"࠭ࡰࡢࡩࡨࠫॼ"): l1l11llll11l1l11_nktv_})
    xbmc.executebuiltin(l1l11ll11l1l11_nktv_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠪࠨࡷ࠮࠭ॽ")% url)
elif mode[0] == l1l11ll11l1l11_nktv_ (u"ࠨࡩࡨࡸࡊࡶࡩࡴࡱࡧࡩࡸ࠭ॾ"):
    l11l111ll11l1l11_nktv_(ex_link)
    xbmcplugin.setContent(l1lll11lll11l1l11_nktv_, l1l11ll11l1l11_nktv_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫॿ"))
elif mode[0] == l1l11ll11l1l11_nktv_ (u"ࠪ࡫ࡪࡺࡅࡱ࡫ࡶࡳࡩ࡫ࡳ࠳ࠩঀ"):
    l1ll11lll11l1l11_nktv_(ex_link)
    xbmcplugin.setContent(l1lll11lll11l1l11_nktv_, l1l11ll11l1l11_nktv_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭ঁ"))
elif mode[0] == l1l11ll11l1l11_nktv_ (u"ࠬࡒࡩࡴࡶࡖࡩࡷ࡯ࡡ࡭ࡧࠪং"):
    l1l11l1ll11l1l11_nktv_(ex_link,l1l11llll11l1l11_nktv_)
    xbmcplugin.setContent(l1lll11lll11l1l11_nktv_, l1l11ll11l1l11_nktv_ (u"࠭ࡴࡷࡵ࡫ࡳࡼࡹࠧঃ"))
elif mode[0] == l1l11ll11l1l11_nktv_ (u"ࠧࡨࡧࡷࡗࡪࡧࡳࡰࡰࡶࠫ঄"):
    l11111lll11l1l11_nktv_(ex_link)
    xbmcplugin.setContent(l1lll11lll11l1l11_nktv_, l1l11ll11l1l11_nktv_ (u"ࠨࡶࡹࡷ࡭ࡵࡷࡴࠩঅ"))
elif mode[0] == l1l11ll11l1l11_nktv_ (u"ࠩࡏ࡭ࡸࡺࡆࡔࠩআ"):
    l11llllll11l1l11_nktv_(ex_link)
    xbmcplugin.setContent(l1lll11lll11l1l11_nktv_, l1l11ll11l1l11_nktv_ (u"ࠪࡸࡻࡹࡨࡰࡹࡶࠫই"))
elif mode[0] == l1l11ll11l1l11_nktv_ (u"ࠫ࡬࡫ࡴࡍ࡫ࡱ࡯ࡸ࠭ঈ"):
    l111l11ll11l1l11_nktv_(ex_link)
elif mode[0] == l1l11ll11l1l11_nktv_ (u"ࠬࡍࡡࡵࡷࡱࡩࡰࡘ࡯࡬ࠩউ"):
    param = ex_link.split(l1l11ll11l1l11_nktv_ (u"࠭ࡼࠨঊ"))
    label,value = l1l11l11ll11l1l11_nktv_.l1l11ll1ll11l1l11_nktv_(l1l111l1ll11l1l11_nktv_=param[0],l11ll1llll11l1l11_nktv_=param[1])
    try:
        s = xbmcgui.Dialog().l1l1l11ll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠧࡘࡻࡥ࡭ࡪࡸࡺࠡࠩঋ"),label)
    except:
        s = xbmcgui.Dialog().select(l1l11ll11l1l11_nktv_ (u"ࠨ࡙ࡼࡦ࡮࡫ࡲࡻࠩঌ"),label)
    if isinstance(s,list):
        v = param[1]+l1l11ll11l1l11_nktv_ (u"ࠩ࠽ࠫ঍")+l1l11ll11l1l11_nktv_ (u"ࠪ࠰ࠬ঎").join([ value[i] for i in s])
    else:
        s = s if s>-1 else 0
        v = param[1]+l1l11ll11l1l11_nktv_ (u"ࠫ࠿࠭এ")+value[s]
    l1llll1ll11l1l11_nktv_ = l1l11ll11l1l11_nktv_ (u"ࠬ࠵ࠧঐ").join([x for x in [l11ll1lll11l1l11_nktv_,l1lll1lll11l1l11_nktv_,l1ll1l1lll11l1l11_nktv_,v] if x])
    l1lllllll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡯ࡣࡶࡾࡪ࠳࡫ࡪࡰࡲ࠲ࡹࡼ࠯ࡧ࡫࡯ࡱࡾ࠳࡯࡯࡮࡬ࡲࡪ࠵ࠧ঑")+l1llll1ll11l1l11_nktv_,1)
elif mode[0] == l1l11ll11l1l11_nktv_ (u"ࠧࡐࡲࡦ࡮ࡪ࠭঒"):
    l11l1l1ll11l1l11_nktv_.openSettings()
elif mode[0] ==l1l11ll11l1l11_nktv_ (u"ࠨࡕࡽࡹࡰࡧࡪࠨও"):
    l111lllll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡪࡶࡪ࡫࡮࡞ࡐࡲࡻࡪࠦࡓࡻࡷ࡮ࡥࡳ࡯ࡥ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩঔ"),l1l11ll11l1l11_nktv_ (u"ࠪࠫক"),mode=l1l11ll11l1l11_nktv_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭ࡒࡴࡽࡥࠨখ"))
    l1lll11ll11l1l11_nktv_ = l1lll111ll11l1l11_nktv_()
    if not l1lll11ll11l1l11_nktv_ == [l1l11ll11l1l11_nktv_ (u"ࠬ࠭গ")]:
        for entry in l1lll11ll11l1l11_nktv_:
            contextmenu = []
            contextmenu.append((l1l11ll11l1l11_nktv_ (u"ࡻࠧࡖࡵࡸࡲࠬঘ"), l1l11ll11l1l11_nktv_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠪࠨࡷ࠮࠭ঙ")% l1l1llll11l1l11_nktv_({l1l11ll11l1l11_nktv_ (u"ࠨ࡯ࡲࡨࡪ࠭চ"): l1l11ll11l1l11_nktv_ (u"ࠩࡖࡾࡺࡱࡡ࡫ࡗࡶࡹࡳ࠭ছ"), l1l11ll11l1l11_nktv_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫজ") : entry})),)
            contextmenu.append((l1l11ll11l1l11_nktv_ (u"ࡹ࡛ࠬࡳࡶࡰࠣࡧࡦैࡡࠡࡪ࡬ࡷࡹࡵࡲࡪࡧࠪঝ"), l1l11ll11l1l11_nktv_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠥࡴࠫࠪঞ") % l1l1llll11l1l11_nktv_({l1l11ll11l1l11_nktv_ (u"࠭࡭ࡰࡦࡨࠫট"): l1l11ll11l1l11_nktv_ (u"ࠧࡔࡼࡸ࡯ࡦࡰࡕࡴࡷࡱࡅࡱࡲࠧঠ")})),)
            l111lllll11l1l11_nktv_(name=entry, ex_link=entry.replace(l1l11ll11l1l11_nktv_ (u"ࠨࠢࠪড"),l1l11ll11l1l11_nktv_ (u"ࠩ࠮ࠫঢ")), mode=l1l11ll11l1l11_nktv_ (u"ࠪࡐ࡮ࡹࡴࡇࡕࠪণ"), fanart=None, contextmenu=contextmenu)
elif mode[0] ==l1l11ll11l1l11_nktv_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭ࡒࡴࡽࡥࠨত"):
    d = xbmcgui.Dialog().input(l1l11ll11l1l11_nktv_ (u"ࡺ࠭ࡓࡻࡷ࡮ࡥ࡯࠲ࠠࡑࡱࡧࡥ࡯ࠦࡴࡺࡶࡸॆࠥ࡬ࡩ࡭࡯ࡸ࠳ࡸ࡫ࡲࡪࡣ࡯ࡹࠬথ"), type=xbmcgui.INPUT_ALPHANUM)
    if d:
        l1ll1llll11l1l11_nktv_(d)
        ex_link=d.replace(l1l11ll11l1l11_nktv_ (u"࠭ࠠࠨদ"),l1l11ll11l1l11_nktv_ (u"ࠧࠬࠩধ"))
        l11llllll11l1l11_nktv_(ex_link)
        xbmcplugin.setContent(l1lll11lll11l1l11_nktv_, l1l11ll11l1l11_nktv_ (u"ࠨࡶࡹࡷ࡭ࡵࡷࡴࠩন"))
elif mode[0] ==l1l11ll11l1l11_nktv_ (u"ࠩࡖࡾࡺࡱࡡ࡫ࡗࡶࡹࡳ࠭঩"):
    l11ll11ll11l1l11_nktv_(ex_link)
    xbmc.executebuiltin(l1l11ll11l1l11_nktv_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬࠭ࠫࡳࠪࠩপ")%  l1l1llll11l1l11_nktv_({l1l11ll11l1l11_nktv_ (u"ࠫࡲࡵࡤࡦࠩফ"): l1l11ll11l1l11_nktv_ (u"࡙ࠬࡺࡶ࡭ࡤ࡮ࠬব")}))
elif mode[0] == l1l11ll11l1l11_nktv_ (u"࠭ࡓࡻࡷ࡮ࡥ࡯࡛ࡳࡶࡰࡄࡰࡱ࠭ভ"):
    l111l1lll11l1l11_nktv_()
    xbmc.executebuiltin(l1l11ll11l1l11_nktv_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠪࠨࡷ࠮࠭ম")%  l1l1llll11l1l11_nktv_({l1l11ll11l1l11_nktv_ (u"ࠨ࡯ࡲࡨࡪ࠭য"): l1l11ll11l1l11_nktv_ (u"ࠩࡖࡾࡺࡱࡡ࡫ࠩর")}))
elif mode[0] == l1l11ll11l1l11_nktv_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ঱"):
    pass
else:
    xbmcplugin.setResolvedUrl(l1lll11lll11l1l11_nktv_, False, xbmcgui.ListItem(path=l1l11ll11l1l11_nktv_ (u"ࠫࠬল")))
xbmcplugin.endOfDirectory(l1lll11lll11l1l11_nktv_)
