# coding: UTF-8
import sys
l1111ll11l1l11_nktv_ = sys.version_info [0] == 2
l111ll11l1l11_nktv_ = 2048
l1l1lll11l1l11_nktv_ = 7
def l1l11ll11l1l11_nktv_ (keyedStringLiteral):
	global l11llll11l1l11_nktv_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1111ll11l1l11_nktv_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll11l1l11_nktv_ - (charIndex + stringNr) % l1l1lll11l1l11_nktv_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import xbmc,xbmcgui
import time,re,os,threading
try: from shutil import rmtree
except: rmtree = False
def l1lll11l1l11_nktv_(l1llllll11l1l11_nktv_,l1lll1ll11l1l11_nktv_=[l1l11ll11l1l11_nktv_ (u"ࠫࠬࠀ")]):
    debug=1
def l1ll11l1l11_nktv_(name=l1l11ll11l1l11_nktv_ (u"ࠬ࠭ࠁ")):
    debug=1
def l1llll11l1l11_nktv_(top):
    debug=1
def l1ll1ll11l1l11_nktv_():
    l1llllll11l1l11_nktv_ = os.path.join(xbmc.translatePath(l1l11ll11l1l11_nktv_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧࠉ")),l1l11ll11l1l11_nktv_ (u"ࠧࡢࡦࡧࡳࡳࡹࠧࠊ"))
    xbmc.log(l1llllll11l1l11_nktv_)
    if l1lll11l1l11_nktv_(l1llllll11l1l11_nktv_,[l1l11ll11l1l11_nktv_ (u"ࠨࡣ࡯࡭ࡪࡴࡷࡪࡼࡤࡶࡩ࠭ࠋ"),l1l11ll11l1l11_nktv_ (u"ࠩࡨࡼࡹ࡫࡮ࡥࡧࡵ࠲ࡦࡲࡩࡦࡰࠪࠌ")])>0:
        l1ll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠪࡻ࡮ࢀࡡࡳࡦࠪࠍ"))
        return
    l1l1ll11l1l11_nktv_ = os.path.join(xbmc.translatePath(l1l11ll11l1l11_nktv_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡶࡵࡨࡶࡩࡧࡴࡢࠩࠎ")),l1l11ll11l1l11_nktv_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩࠏ"),l1l11ll11l1l11_nktv_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡦ࡫࡯࡯࠰ࡱࡳࡽ࠴࠵ࠨࠐ"),l1l11ll11l1l11_nktv_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭ࠑ"))
    if os.path.exists(l1l1ll11l1l11_nktv_):
        data = open(l1l1ll11l1l11_nktv_,l1l11ll11l1l11_nktv_ (u"ࠨࡴࠪࠒ")).read()
        data= re.sub(l1l11ll11l1l11_nktv_ (u"ࠩ࡟࡟࠳࠰࡜࡞ࠩࠓ"),l1l11ll11l1l11_nktv_ (u"ࠪࠫࠔ"),data)
        if len(re.compile(l1l11ll11l1l11_nktv_ (u"ࠫࡃ࠴ࠪࠩࡲࡲࡰࡸࡱࡡ࡝ࡵ࠭ࡸࡡࡹࠪࡷࠫࠪࠕ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1ll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡥࡪࡵ࡮࠯ࡰࡲࡼ࠳࠻ࠧࠖ"))
            return
        if len(re.compile(l1l11ll11l1l11_nktv_ (u"࠭࠾࠯ࠬࠫࡨࡦࡸ࡭ࡰࡹࡤࡠࡸ࠰ࡴ࡝ࡵ࠭ࡺ࠮࠭ࠗ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1ll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡧࡥࡰࡰ࠱ࡲࡴࡾ࠮࠶ࠩ࠘"))
            return
    l1l1ll11l1l11_nktv_ = os.path.join(xbmc.translatePath(l1l11ll11l1l11_nktv_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡺࡹࡥࡳࡦࡤࡸࡦ࠭࠙")),l1l11ll11l1l11_nktv_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭ࠚ"),l1l11ll11l1l11_nktv_ (u"ࠪࡷࡰ࡯࡮࠯ࡺࡲࡲ࡫ࡲࡵࡦࡰࡦࡩࠬࠛ"),l1l11ll11l1l11_nktv_ (u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪࠜ"))
    if os.path.exists(l1l1ll11l1l11_nktv_):
        data = open(l1l1ll11l1l11_nktv_,l1l11ll11l1l11_nktv_ (u"ࠬࡸࠧࠝ")).read()
        data= re.sub(l1l11ll11l1l11_nktv_ (u"࠭࡜࡜࠰࠭ࡠࡢ࠭ࠞ"),l1l11ll11l1l11_nktv_ (u"ࠧࠨࠟ"),data)
        if len(re.compile(l1l11ll11l1l11_nktv_ (u"ࠨࡀ࠱࠮࠭ࡶ࡯࡭ࡵ࡮ࡥࡡࡹࠪࡵ࡞ࡶ࠮ࡻ࠯ࠧࠠ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1ll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"ࠩࡶ࡯࡮ࡴ࠮ࡹࡱࡱࡪࡱࡻࡥ࡯ࡥࡨࠫࠡ"))
            return
    l1llllll11l1l11_nktv_ = os.path.join(xbmc.translatePath(l1l11ll11l1l11_nktv_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡵࡴࡧࡵࡨࡦࡺࡡࠨࠢ")),l1l11ll11l1l11_nktv_ (u"ࠫࡵࡸ࡯ࡧ࡫࡯ࡩࡸ࠭ࠣ"))
    if os.path.exists(l1llllll11l1l11_nktv_):
        if l1lll11l1l11_nktv_(l1llllll11l1l11_nktv_,[l1l11ll11l1l11_nktv_ (u"ࠬࡱࡩࡥࡵࠪࠤ")])>0:
            l1ll11l1l11_nktv_(l1l11ll11l1l11_nktv_ (u"࠭ࡷࡪࡼࡤࡶࡩ࠭ࠥ"))
            return
    l11l1ll11l1l11_nktv_ = xbmc.translatePath(l1l11ll11l1l11_nktv_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨࠦ"))
    for f in os.listdir(l11l1ll11l1l11_nktv_):
        if f.startswith(l1l11ll11l1l11_nktv_ (u"ࠨࡏࡐࡉࡘ࠭ࠧ")):
            l1ll11l1l11_nktv_()
            return
