# coding: UTF-8
import sys
l1ll1ll_fd_ = sys.version_info [0] == 2
l1lllll1_fd_ = 2048
l111l_fd_ = 7
def l11111_fd_ (ll_fd_):
	global l1ll11l_fd_
	l1ll1l_fd_ = ord (ll_fd_ [-1])
	l1lll11_fd_ = ll_fd_ [:-1]
	l11ll1l_fd_ = l1ll1l_fd_ % len (l1lll11_fd_)
	l1lll_fd_ = l1lll11_fd_ [:l11ll1l_fd_] + l1lll11_fd_ [l11ll1l_fd_:]
	if l1ll1ll_fd_:
		l1l11l1_fd_ = unicode () .join ([unichr (ord (char) - l1lllll1_fd_ - (l111ll_fd_ + l1ll1l_fd_) % l111l_fd_) for l111ll_fd_, char in enumerate (l1lll_fd_)])
	else:
		l1l11l1_fd_ = str () .join ([chr (ord (char) - l1lllll1_fd_ - (l111ll_fd_ + l1ll1l_fd_) % l111l_fd_) for l111ll_fd_, char in enumerate (l1lll_fd_)])
	return eval (l1l11l1_fd_)