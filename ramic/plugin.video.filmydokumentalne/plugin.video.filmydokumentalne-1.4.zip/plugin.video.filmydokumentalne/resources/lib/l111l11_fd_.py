# -*- coding: utf-8 -*-
import sys
l1ll1ll_fd_ = sys.version_info [0] == 2
l1lllll1_fd_ = 2048
l111l_fd_ = 7
def l11111_fd_ (ll_fd_):
	global l1ll11l_fd_
	l1ll1l_fd_ = ord (ll_fd_ [-1])
	l1lll11_fd_ = ll_fd_ [:-1]
	l11ll1l_fd_ = l1ll1l_fd_ % len (l1lll11_fd_)
	l1lll_fd_ = l1lll11_fd_ [:l11ll1l_fd_] + l1lll11_fd_ [l11ll1l_fd_:]
	if l1ll1ll_fd_:
		l1l11l1_fd_ = unicode () .join ([unichr (ord (char) - l1lllll1_fd_ - (l111ll_fd_ + l1ll1l_fd_) % l111l_fd_) for l111ll_fd_, char in enumerate (l1lll_fd_)])
	else:
		l1l11l1_fd_ = str () .join ([chr (ord (char) - l1lllll1_fd_ - (l111ll_fd_ + l1ll1l_fd_) % l111l_fd_) for l111ll_fd_, char in enumerate (l1lll_fd_)])
	return eval (l1l11l1_fd_)
l11111_fd_ (u"ࠤࠥࠦࠒࠐࡃࡳࡧࡤࡸࡪࡪࠠࡰࡰࠣࡘ࡭ࡻࠠࡇࡧࡥࠤ࠶࠷ࠠ࠲࠺࠽࠸࠼ࡀ࠴࠴ࠢ࠵࠴࠶࠼ࠍࠋࠏࠍࡄࡦࡻࡴࡩࡱࡵ࠾ࠥࡸࡡ࡮࡫ࡦࠑࠏࠨࠢࠣह")
import urllib2
import re
import l11llll1l_fd_ as l11llll1l_fd_
l11llll11_fd_=l11111_fd_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡤࡦࡤ࠲ࡵࡲࠧऺ")
l1l111111_fd_ = 5
def l11llllll_fd_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l11111_fd_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨऻ"), l11111_fd_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠹࠾࠮࠱࠰࠵࠹࠻࠺࠮࠺࠹ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸़ࠪ"))
    if cookies:
        req.add_header(l11111_fd_ (u"ࠨࡃࡰࡱ࡮࡭ࡪࠨऽ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l1l111111_fd_)
        l11llll_fd_ =  response.read()
        response.close()
    except:
        l11llll_fd_=l11111_fd_ (u"ࠧࠨा")
    return l11llll_fd_
def _1l11111l_fd_(content):
    src =l11111_fd_ (u"ࠨࠩि")
    l11ll1lll_fd_ = re.compile(l11111_fd_ (u"ࠤࡨࡺࡦࡲࠨ࠯ࠬࡂ࠭ࡡࢁ࡜ࡾ࡞ࠬࡠ࠮ࠨी"),re.DOTALL).findall(content)
    for l11ll1ll1_fd_ in l11ll1lll_fd_:
        l11ll1ll1_fd_=re.sub(l11111_fd_ (u"ࠪࠤࠥ࠭ु"),l11111_fd_ (u"ࠫࠥ࠭ू"),l11ll1ll1_fd_)
        l11ll1ll1_fd_=re.sub(l11111_fd_ (u"ࠬࡢ࡮ࠨृ"),l11111_fd_ (u"࠭ࠧॄ"),l11ll1ll1_fd_)
        try:
            l11ll1111_fd_ = l11llll1l_fd_.unpack(l11ll1ll1_fd_)
        except:
            l11ll1111_fd_=l11111_fd_ (u"ࠧࠨॅ")
        if l11ll1111_fd_:
            l11ll1111_fd_=re.sub(l11111_fd_ (u"ࡳࠩ࡟ࡠࠬॆ"),l11111_fd_ (u"ࡴࠪࠫे"),l11ll1111_fd_)
            l11lll111_fd_ = re.compile(l11111_fd_ (u"ࠪࡪ࡮ࡲࡥ࠻࡞ࡶ࠮ࡠࡢࠧࠣ࡟ࠫ࠲࠰ࡅࠩ࡜࡞ࠪࠦࡢ࠲ࠧै"),  re.DOTALL).search(l11ll1111_fd_)
            l11lll1l1_fd_ = re.compile(l11111_fd_ (u"ࠫࡺࡸ࡬࠻࡞ࡶ࠮ࡠࡢࠧࠣ࡟ࠫ࠲࠰ࡅࠩ࡜࡞ࠪࠦࡢ࠲ࠧॉ"),  re.DOTALL).search(l11ll1111_fd_)
            if l11lll111_fd_:
                src = l11lll111_fd_.group(1)
            elif l11lll1l1_fd_:
                src = l11lll1l1_fd_.group(1)
            if src:
                break
    return src
def _11lll11l_fd_(content):
    src=l11111_fd_ (u"ࠬ࠭ॊ")
    l11l1llll_fd_ = content.find(l11111_fd_ (u"࠭ࡼࡽࡾ࡫ࡸࡹࡶࠧो"))
    if l11l1llll_fd_>0:
        l11ll11l1_fd_ = content.find(l11111_fd_ (u"ࠧ࠯ࡵࡳࡰ࡮ࡺࠧौ"),l11l1llll_fd_)
        encoded =content[l11l1llll_fd_:l11ll11l1_fd_]
        if encoded:
            l1111_fd_ = encoded.split(l11111_fd_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲࠨ्"))[0]
            l1111_fd_=re.sub(l11111_fd_ (u"ࡴࠪ࡟ࢁࡣࠫ࡝ࡹࡾ࠶࠱࠹ࡽ࡜ࡾࡠ࠯ࠬॎ"),l11111_fd_ (u"ࠪࢀࠬॏ"),l1111_fd_,re.DOTALL)
            l1111_fd_=re.sub(l11111_fd_ (u"ࡶࠬࡡࡼ࡞࠭࡟ࡻࢀ࠸ࠬ࠴ࡿ࡞ࢀࡢ࠱ࠧॐ"),l11111_fd_ (u"ࠬࢂࠧ॑"),l1111_fd_,re.DOTALL)
            l11l1ll1l_fd_=[l11111_fd_ (u"࠭ࡨࡵࡶࡳ॒ࠫ"),l11111_fd_ (u"ࠧࡤࡦࡤࠫ॓"),l11111_fd_ (u"ࠨࡲ࡯ࠫ॔"),l11111_fd_ (u"ࠩ࡯ࡳ࡬ࡵࠧॕ"),l11111_fd_ (u"ࠪࡻ࡮ࡪࡴࡩࠩॖ"),l11111_fd_ (u"ࠫ࡭࡫ࡩࡨࡪࡷࠫॗ"),l11111_fd_ (u"ࠬࡺࡲࡶࡧࠪक़"),l11111_fd_ (u"࠭ࡳࡵࡣࡷ࡭ࡨ࠭ख़"),l11111_fd_ (u"ࠧࡴࡶࠪग़"),l11111_fd_ (u"ࠨ࡯ࡳ࠸ࠬज़"),l11111_fd_ (u"ࠩࡩࡥࡱࡹࡥࠨड़"),l11111_fd_ (u"ࠪࡺ࡮ࡪࡥࡰࠩढ़"),l11111_fd_ (u"ࠫࡸࡺࡡࡵ࡫ࡦࠫफ़"),
                    l11111_fd_ (u"ࠬࡺࡹࡱࡧࠪय़"),l11111_fd_ (u"࠭ࡳࡸࡨࠪॠ"),l11111_fd_ (u"ࠧࡱ࡮ࡤࡽࡪࡸࠧॡ"),l11111_fd_ (u"ࠨࡨ࡬ࡰࡪ࠭ॢ"),l11111_fd_ (u"ࠩࡦࡳࡳࡺࡲࡰ࡮ࡥࡥࡷ࠭ॣ"),l11111_fd_ (u"ࠪࡥࡩࡹࠧ।"),l11111_fd_ (u"ࠫࡨࢀࡡࡴࠩ॥"),l11111_fd_ (u"ࠬࡶ࡯ࡴ࡫ࡷ࡭ࡴࡴࠧ०"),l11111_fd_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ१"),l11111_fd_ (u"ࠧࡣࡱࡷࡸࡴࡳࠧ२"),l11111_fd_ (u"ࠨࡷࡶࡩࡷࡇࡧࡦࡰࡷࠫ३"),
                    l11111_fd_ (u"ࠩࡰࡥࡹࡩࡨࠨ४"),l11111_fd_ (u"ࠪࡴࡳ࡭ࠧ५"),l11111_fd_ (u"ࠫࡳࡧࡶࡪࡩࡤࡸࡴࡸࠧ६"),l11111_fd_ (u"ࠬ࡯ࡤࠨ७"), l11111_fd_ (u"࠭࠳࠸ࠩ८"), l11111_fd_ (u"ࠧࡳࡧࡪ࡭ࡴࡴࡳࠨ९"), l11111_fd_ (u"ࠨ࠲࠼ࠫ॰"), l11111_fd_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࡦࠪॱ"), l11111_fd_ (u"ࠪࡷࡷࡩࠧॲ"), l11111_fd_ (u"ࠫࡲ࡫ࡤࡪࡣࠪॳ")]
            l11l1ll1l_fd_=[l11111_fd_ (u"ࠬ࡮ࡴࡵࡲࠪॴ"), l11111_fd_ (u"࠭࡬ࡰࡩࡲࠫॵ"), l11111_fd_ (u"ࠧࡸ࡫ࡧࡸ࡭࠭ॶ"), l11111_fd_ (u"ࠨࡪࡨ࡭࡬࡮ࡴࠨॷ"), l11111_fd_ (u"ࠩࡷࡶࡺ࡫ࠧॸ"), l11111_fd_ (u"ࠪࡷࡹࡧࡴࡪࡥࠪॹ"), l11111_fd_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪॺ"), l11111_fd_ (u"ࠬࡼࡩࡥࡧࡲࠫॻ"), l11111_fd_ (u"࠭ࡰ࡭ࡣࡼࡩࡷ࠭ॼ"),
                l11111_fd_ (u"ࠧࡧ࡫࡯ࡩࠬॽ"), l11111_fd_ (u"ࠨࡶࡼࡴࡪ࠭ॾ"), l11111_fd_ (u"ࠩࡵࡩ࡬࡯࡯࡯ࡵࠪॿ"), l11111_fd_ (u"ࠪࡲࡴࡴࡥࠨঀ"), l11111_fd_ (u"ࠫࡨࢀࡡࡴࠩঁ"), l11111_fd_ (u"ࠬ࡫࡮ࡢࡤ࡯ࡩࡩ࠭ং"), l11111_fd_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨঃ"), l11111_fd_ (u"ࠧࡤࡱࡱࡸࡷࡵ࡬ࡣࡣࡵࠫ঄"), l11111_fd_ (u"ࠨ࡯ࡤࡸࡨ࡮ࠧঅ"), l11111_fd_ (u"ࠩࡥࡳࡹࡺ࡯࡮ࠩআ"),
                l11111_fd_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪই"), l11111_fd_ (u"ࠫࡵࡵࡳࡪࡶ࡬ࡳࡳ࠭ঈ"), l11111_fd_ (u"ࠬࡻࡳࡦࡴࡄ࡫ࡪࡴࡴࠨউ"), l11111_fd_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺ࡯ࡳࠩঊ"), l11111_fd_ (u"ࠧࡤࡱࡱࡪ࡮࡭ࠧঋ"), l11111_fd_ (u"ࠨࡪࡷࡱࡱ࠭ঌ"), l11111_fd_ (u"ࠩ࡫ࡸࡲࡲ࠵ࠨ঍"), l11111_fd_ (u"ࠪࡴࡷࡵࡶࡪࡦࡨࡶࠬ঎"), l11111_fd_ (u"ࠫࡧࡲࡡࡤ࡭ࠪএ"),
                l11111_fd_ (u"ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡃ࡯࡭࡬ࡴࠧঐ"), l11111_fd_ (u"࠭ࡣࡢࡰࡉ࡭ࡷ࡫ࡅࡷࡧࡱࡸࡆࡖࡉࡄࡣ࡯ࡰࡸ࠭঑"), l11111_fd_ (u"ࠧࡶࡵࡨ࡚࠷ࡇࡐࡊࡅࡤࡰࡱࡹࠧ঒"), l11111_fd_ (u"ࠨࡸࡨࡶࡹ࡯ࡣࡢ࡮ࡄࡰ࡮࡭࡮ࠨও"), l11111_fd_ (u"ࠩࡷ࡭ࡲ࡫ࡳ࡭࡫ࡧࡩࡷࡺ࡯ࡰ࡮ࡷ࡭ࡵࡶ࡬ࡶࡩ࡬ࡲࠬঔ"),
                l11111_fd_ (u"ࠪࡳࡻ࡫ࡲ࡭ࡣࡼࡷࠬক"), l11111_fd_ (u"ࠫࡧࡧࡣ࡬ࡩࡵࡳࡺࡴࡤࡄࡱ࡯ࡳࡷ࠭খ"), l11111_fd_ (u"ࠬࡳࡡࡳࡩ࡬ࡲࡧࡵࡴࡵࡱࡰࠫগ"), l11111_fd_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡹࠧঘ"), l11111_fd_ (u"ࠧ࡭࡫ࡱ࡯ࠬঙ"), l11111_fd_ (u"ࠨࡵࡷࡶࡪࡺࡣࡩ࡫ࡱ࡫ࠬচ"), l11111_fd_ (u"ࠩࡸࡲ࡮࡬࡯ࡳ࡯ࠪছ"), l11111_fd_ (u"ࠪࡷࡹࡧࡴࡪࡥ࠴ࠫজ"),
                l11111_fd_ (u"ࠫࡸ࡫ࡴࡶࡲࠪঝ"), l11111_fd_ (u"ࠬࡰࡷࡱ࡮ࡤࡽࡪࡸࠧঞ"), l11111_fd_ (u"࠭ࡣࡩࡧࡦ࡯ࡋࡲࡡࡴࡪࠪট"), l11111_fd_ (u"ࠧࡔ࡯ࡤࡶࡹ࡚ࡖࠨঠ"), l11111_fd_ (u"ࠨࡸ࠳࠴࠶࠭ড"), l11111_fd_ (u"ࠩࡦࡶࡪࡳࡥࠨঢ"), l11111_fd_ (u"ࠪࡨࡴࡩ࡫ࠨণ"), l11111_fd_ (u"ࠫࡦࡻࡴࡰࡵࡷࡥࡷࡺࠧত"), l11111_fd_ (u"ࠬ࡯ࡤ࡭ࡧ࡫࡭ࡩ࡫ࠧথ"), l11111_fd_ (u"࠭࡭ࡰࡦࡨࡷࠬদ"),
               l11111_fd_ (u"ࠧࡧ࡮ࡤࡷ࡭࠭ধ"), l11111_fd_ (u"ࠨࡱࡹࡩࡷ࠭ন"), l11111_fd_ (u"ࠩ࡯ࡩ࡫ࡺࠧ঩"), l11111_fd_ (u"ࠪ࡬࡮ࡪࡥࠨপ"), l11111_fd_ (u"ࠫࡵࡲࡡࡺࡧࡵ࠹ࠬফ"), l11111_fd_ (u"ࠬ࡯࡭ࡢࡩࡨࠫব"), l11111_fd_ (u"࠭ࡋࡍࡋࡎࡒࡎࡐࠧভ"), l11111_fd_ (u"ࠧࡤࡱࡰࡴࡦࡴࡩࡰࡰࡶࠫম"), l11111_fd_ (u"ࠨࡴࡨࡷࡹࡵࡲࡦࠩয"), l11111_fd_ (u"ࠩࡦࡰ࡮ࡩ࡫ࡔ࡫ࡪࡲࠬর"),
                l11111_fd_ (u"ࠪࡷࡨ࡮ࡥࡥࡷ࡯ࡩࠬ঱"), l11111_fd_ (u"ࠫࡤࡩ࡯ࡶࡰࡷࡨࡴࡽ࡮ࡠࠩল"), l11111_fd_ (u"ࠬࡩ࡯ࡶࡰࡷࡨࡴࡽ࡮ࠨ঳"), l11111_fd_ (u"࠭ࡲࡦࡩ࡬ࡳࡳ࠭঴"), l11111_fd_ (u"ࠧࡦ࡮ࡶࡩࠬ঵"), l11111_fd_ (u"ࠨࡥࡲࡲࡹࡸ࡯࡭ࡵࠪশ"), l11111_fd_ (u"ࠩࡳࡶࡪࡲ࡯ࡢࡦࠪষ"), l11111_fd_ (u"ࠪࡳࡷࡿࡧࡪࡰࡤࡰࡳ࡫ࠧস"), l11111_fd_ (u"ࠫࡸࡺࡹ࡭ࡧࠪহ"),
                l11111_fd_ (u"ࠬ࠼࠲࠱ࡲࡻࠫ঺"), l11111_fd_ (u"࠭࠳࠹࠹ࡳࡼࠬ঻"), l11111_fd_ (u"ࠧࡱࡱࡶࡸࡪࡸ়ࠧ"), l11111_fd_ (u"ࠨࡼࡱ࡭ࡰࡴࡩࡦࠩঽ"), l11111_fd_ (u"ࠩࡶࡩࡰࡻ࡮ࡥࠩা"), l11111_fd_ (u"ࠪࡷ࡭ࡵࡷࡂࡨࡷࡩࡷ࡙ࡥࡤࡱࡱࡨࡸ࠭ি"), l11111_fd_ (u"ࠫ࡮ࡳࡡࡨࡧࡶࠫী"), l11111_fd_ (u"ࠬࡘࡥ࡬࡮ࡤࡱࡦ࠭ু"), l11111_fd_ (u"࠭ࡳ࡬࡫ࡳࡅࡩ࠭ূ"),
                 l11111_fd_ (u"ࠧ࡭ࡧࡹࡩࡱࡹࠧৃ"), l11111_fd_ (u"ࠨࡲࡤࡨࡩ࡯࡮ࡨࠩৄ"), l11111_fd_ (u"ࠩࡲࡴࡦࡩࡩࡵࡻࠪ৅"), l11111_fd_ (u"ࠪࡨࡪࡨࡵࡨࠩ৆"), l11111_fd_ (u"ࠫࡻ࡯ࡤࡦࡱ࠶ࠫে"), l11111_fd_ (u"ࠬࡩ࡬ࡰࡵࡨࠫৈ"), l11111_fd_ (u"࠭ࡳ࡮ࡣ࡯ࡰࡹ࡫ࡸࡵࠩ৉"), l11111_fd_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨ৊"), l11111_fd_ (u"ࠨࡥ࡯ࡥࡸࡹࠧো"), l11111_fd_ (u"ࠩࡤࡰ࡮࡭࡮ࠨৌ"),
                  l11111_fd_ (u"ࠪࡲࡴࡺࡩࡤࡧ্ࠪ"), l11111_fd_ (u"ࠫࡲ࡫ࡤࡪࡣࠪৎ")]
            for l1l111ll1_fd_ in l11l1ll1l_fd_:
                l1111_fd_=l1111_fd_.replace(l1l111ll1_fd_,l11111_fd_ (u"ࠬ࠭৏"))
            cleanup=l1111_fd_.replace(l11111_fd_ (u"࠭ࡼࠨ৐"),l11111_fd_ (u"ࠧࠡࠩ৑")).split()
            out={l11111_fd_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࠨ৒"): l11111_fd_ (u"ࠩࠪ৓"), l11111_fd_ (u"ࠪࡩࠬ৔"): l11111_fd_ (u"ࠫࠬ৕"), l11111_fd_ (u"ࠬ࡬ࡩ࡭ࡧࠪ৖"): l11111_fd_ (u"࠭ࠧৗ"), l11111_fd_ (u"ࠧࡴࡶࠪ৘"): l11111_fd_ (u"ࠨࠩ৙")}
            if len(cleanup)==4:
                print l11111_fd_ (u"ࠩࡏࡩࡳ࡭ࡴࡩࠢࡒࡏࠬ৚")
                for l1l111ll1_fd_ in cleanup:
                    if l1l111ll1_fd_.isdigit():
                        out[l11111_fd_ (u"ࠪࡩࠬ৛")]=l1l111ll1_fd_
                    elif re.match(l11111_fd_ (u"ࠫࡠࡧ࠭ࡻ࡟ࡾ࠶࠱ࢃ࡜ࡥࡽ࠶ࢁࠬড়"),l1l111ll1_fd_) and len(l1l111ll1_fd_)<10:
                        out[l11111_fd_ (u"ࠬࡹࡥࡳࡸࡨࡶࠬঢ়")] = l1l111ll1_fd_
                    elif len(l1l111ll1_fd_)==22:
                        out[l11111_fd_ (u"࠭ࡳࡵࠩ৞")] = l1l111ll1_fd_
                    else:
                        out[l11111_fd_ (u"ࠧࡧ࡫࡯ࡩࠬয়")] = l1l111ll1_fd_
                src=l11111_fd_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠧࡶ࠲ࡨࡪࡡ࠯ࡲ࡯࠳ࠪࡹ࠮࡮ࡲ࠷ࡃࡸࡺ࠽ࠦࡵࠩࡩࡂࠫࡳࠨৠ")%(out.get(l11111_fd_ (u"ࠩࡶࡩࡷࡼࡥࡳࠩৡ")),out.get(l11111_fd_ (u"ࠪࡪ࡮ࡲࡥࠨৢ")),out.get(l11111_fd_ (u"ࠫࡸࡺࠧৣ")),out.get(l11111_fd_ (u"ࠬ࡫ࠧ৤")))
    return src
def l11lllll1_fd_(content):
    l11111_fd_ (u"ࠨࠢࠣࠏࠍࠤࠥࠦࠠࡔࡥࡤࡲࡸࠦࡦࡰࡴࠣࡺ࡮ࡪࡥࡰࠢ࡯࡭ࡳࡱࠠࡪࡰࡦࡰࡺࡪࡥࡥࠢࡨࡲࡨࡵࡤࡦࡦࠣࡳࡳ࡫ࠍࠋࠢࠣࠤࠥࠨࠢࠣ৥")
    l11ll1l1l_fd_=l11111_fd_ (u"ࠧࠨ০")
    l11lll111_fd_ = re.compile(l11111_fd_ (u"ࠨࡨ࡬ࡰࡪࡀࠠ࡜࡞ࠪࠦࡢ࠮࠮ࠬࡁࠬ࡟ࡡ࠭ࠢ࡞࠮ࠪ১"),  re.DOTALL).search(content)
    l11lll1l1_fd_ = re.compile(l11111_fd_ (u"ࠩࡸࡶࡱࡀࠠ࡜࡞ࠪࠦࡢ࠮࠮ࠬࡁࠬ࡟ࡡ࠭ࠢ࡞࠮ࠪ২"),  re.DOTALL).search(content)
    if l11lll111_fd_:
        print l11111_fd_ (u"ࠪࡪࡴࡻ࡮ࡥࠢࡕࡉࠥࡡࡦࡪ࡮ࡨ࠾ࡢ࠭৩")
        l11ll1l1l_fd_ = l11lll111_fd_.group(1)
    elif l11lll1l1_fd_:
        print l11111_fd_ (u"ࠫ࡫ࡵࡵ࡯ࡦࠣࡖࡊ࡛ࠦࡶࡴ࡯࠾ࡢ࠭৪")
        l11ll1l1l_fd_ = l11lll1l1_fd_.group(1)
    else:
        print l11111_fd_ (u"ࠬ࡫࡮ࡤࡱࡧࡩࡩࠦ࠺ࠡࡷࡱࡴࡦࡩ࡫ࡦࡴࠪ৫")
        l11ll1l1l_fd_ = _1l11111l_fd_(content)
        if not l11ll1l1l_fd_:
            print l11111_fd_ (u"࠭ࡥ࡯ࡥࡲࡨࡪࡪࠠ࠻ࠢࡩࡳࡷࡩࡥࠡࠩ৬")
            l11ll1l1l_fd_ = _11lll11l_fd_(content)
    return l11ll1l1l_fd_
def l11l1l1_fd_(url):
    l11111_fd_ (u"ࠢࠣࠤࠐࠎࠥࠦࠠࠡࡴࡨࡸࡺࡸ࡮ࡴࠢࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥ࠳ࠠࡶ࡮ࡵࠤ࡭ࡺࡴࡱ࠼࠲࠳࠳࠴࠮࠯ࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠲ࠦ࡯ࡳࠢ࡯࡭ࡸࡺࠠࡰࡨࠣ࡟࠭࠭࠷࠳࠲ࡳࠫ࠱ࠦࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡨࡪࡡ࠯ࡲ࡯࠳ࡻ࡯ࡤࡦࡱ࠲࠵࠾࠺࠶࠺࠻࠴ࡪࡄࡽࡥࡳࡵ࡭ࡥࡂ࠽࠲࠱ࡲࠪ࠭࠱࠴࠮࠯࡟ࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠍࠋࠢࠣࠤࠥࠨࠢࠣ৭")
    if l11111_fd_ (u"ࠨࡧࡥࡨ࠳ࡩࡤࡢ࠰ࡳࡰࠬ৮") in url:
        url = l11111_fd_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡣࡥࡣ࠱ࡴࡱ࠵ࡶࡪࡦࡨࡳ࠴࠭৯")+url.split(l11111_fd_ (u"ࠪ࠳ࠬৰ"))[-1]
    l11ll1l11_fd_=l11111_fd_ (u"ࠫࢁࡉ࡯ࡰ࡭࡬ࡩࡂࠨࡐࡉࡒࡖࡉࡘ࡙ࡉࡅ࠿࠴ࠪࡗ࡫ࡦࡦࡴࡨࡶࡂ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡴࡢࡶ࡬ࡧ࠳ࡩࡤࡢ࠰ࡳࡰ࠴ࡶ࡬ࡢࡻࡨࡶ࠺࠴࠹࠰ࡲ࡯ࡥࡾ࡫ࡲ࠯ࡵࡺࡪࠬৱ")
    l11ll111l_fd_=l11111_fd_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࡩࡶࡷࡴ࠿࠵࠯ࡴࡶࡤࡸ࡮ࡩ࠮ࡤࡦࡤ࠲ࡵࡲ࠯ࡱ࡮ࡤࡽࡪࡸ࠵࠯࠻࠲ࡴࡱࡧࡹࡦࡴ࠱ࡷࡼ࡬ࠧ৲")
    print url
    content = l11llllll_fd_(url)
    src=[]
    if not l11111_fd_ (u"࠭࠿ࡸࡧࡵࡷ࡯ࡧࠧ৳") in url:
         l11ll11ll_fd_ = re.compile(l11111_fd_ (u"ࠧ࠽ࡣࠣࡨࡦࡺࡡ࠮ࡳࡸࡥࡱ࡯ࡴࡺ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࠬࡄࡖ࠼ࡉࡀ࠱࠮ࡄ࠯࠾ࠩࡁࡓࡀࡖࡄ࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ৴"), re.DOTALL).findall(content)
         for quality in l11ll11ll_fd_:
             l11llll_fd_ = re.search(l11111_fd_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ৵"),quality[1])
             l11l1lll1_fd_ = quality[2]
             src.insert(0,(l11l1lll1_fd_,l11llll11_fd_+l11llll_fd_.group(1)))
    if not src:
        src = l11lllll1_fd_(content)
        if src:
            src+=l11ll1l11_fd_+l11ll111l_fd_
    return src
def l11lll1ll_fd_(url,quality=0):
    l11111_fd_ (u"ࠤࠥࠦࠒࠐࠠࠡࠢࠣࡶࡪࡺࡵࡳࡰࡶࠤࡺࡸ࡬ࠡࡶࡲࠤࡻ࡯ࡤࡦࡱࠐࠎࠥࠦࠠࠡࠤࠥࠦ৶")
    src = l11l1l1_fd_(url)
    if type(src)==list:
        selected=src[quality]
        print l11111_fd_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࠤ࠿࠭৷"),selected[0]
        src = l11l1l1_fd_(selected[1])
    return src
