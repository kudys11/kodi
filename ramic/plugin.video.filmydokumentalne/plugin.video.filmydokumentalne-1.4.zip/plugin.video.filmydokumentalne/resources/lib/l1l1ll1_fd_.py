# -*- coding: utf-8 -*-
import sys
l1ll1ll_fd_ = sys.version_info [0] == 2
l1lllll1_fd_ = 2048
l111l_fd_ = 7
def l11111_fd_ (ll_fd_):
	global l1ll11l_fd_
	l1ll1l_fd_ = ord (ll_fd_ [-1])
	l1lll11_fd_ = ll_fd_ [:-1]
	l11ll1l_fd_ = l1ll1l_fd_ % len (l1lll11_fd_)
	l1lll_fd_ = l1lll11_fd_ [:l11ll1l_fd_] + l1lll11_fd_ [l11ll1l_fd_:]
	if l1ll1ll_fd_:
		l1l11l1_fd_ = unicode () .join ([unichr (ord (char) - l1lllll1_fd_ - (l111ll_fd_ + l1ll1l_fd_) % l111l_fd_) for l111ll_fd_, char in enumerate (l1lll_fd_)])
	else:
		l1l11l1_fd_ = str () .join ([chr (ord (char) - l1lllll1_fd_ - (l111ll_fd_ + l1ll1l_fd_) % l111l_fd_) for l111ll_fd_, char in enumerate (l1lll_fd_)])
	return eval (l1l11l1_fd_)
import xbmc,xbmcgui
import time,re,os,threading
try: from shutil import rmtree
except: rmtree = False
def _1l11ll11_fd_(l1l1l11_fd_):
    import json,xbmcplugin,urllib2
    url=l11111_fd_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡦࡵ࡭ࡻ࡫࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰ࠳ࡺࡩ࠿ࡦࡺࡳࡳࡷࡺ࠽ࡥࡱࡺࡲࡱࡵࡡࡥࠨ࡬ࡨࡂ࠭ࣿ")
    try:
        l1l111lll_fd_ = json.load(urllib2.urlopen(url+l11111_fd_ (u"ࠨ࠲ࡅ࠴ࡕࡳ࡬ࡗࡋࡻࡽ࡬ࡱࡴࡦࡰࡉࡏࡔ࡙࠱ࡳࡥ࠶ࡉ࠵࡛ࡕ࠱ࠩऀ")))
    except:
        l1l111lll_fd_=[{l11111_fd_ (u"ࠩࡷ࡭ࡹࡲࡥࠨँ"):l11111_fd_ (u"ࠪࡑࡴংࡥࠡࡥࡲय़ࠥࡹࡩचࠢࡷࡹࠥࡶ࡯࡫ࡣࡺ࡭ࠬं")}]
    for l1l111ll1_fd_ in l1l111lll_fd_:
        l1lll1l_fd_ = xbmcgui.ListItem(l1l111ll1_fd_.get(l11111_fd_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪः")), iconImage=l1l111ll1_fd_.get(l11111_fd_ (u"ࠬ࡯࡭ࡨࠩऄ")) , thumbnailImage=l1l111ll1_fd_.get(l11111_fd_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠭अ")) )
        l1lll1l_fd_.setInfo(type=l11111_fd_ (u"ࠢࡗ࡫ࡧࡩࡴࠨआ"), infoLabels=l1l111ll1_fd_)
        l1lll1l_fd_.setProperty(l11111_fd_ (u"ࠨࡋࡶࡔࡱࡧࡹࡢࡤ࡯ࡩࠬइ"), l11111_fd_ (u"ࠩࡩࡥࡱࡹࡥࠨई"))
        l1lll1l_fd_.setProperty(l11111_fd_ (u"ࠪࡪࡦࡴࡡࡳࡶࡢ࡭ࡲࡧࡧࡦࠩउ"),l1l111ll1_fd_.get(l11111_fd_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫऊ")))
        xbmcplugin.addDirectoryItem(handle=l1l1l11_fd_, url=l1l111ll1_fd_.get(l11111_fd_ (u"ࠬࡻࡲ࡭ࠩऋ")), listitem=l1lll1l_fd_, isFolder=False)
def l1l11lll1_fd_(l1l1111ll_fd_,l1l1111l1_fd_=[l11111_fd_ (u"࠭ࠧऌ")]):
    debug=1
def l1l11llll_fd_(name=l11111_fd_ (u"ࠧࠨऍ")):
    debug=1
def l1l11l1ll_fd_(top):
    debug=1
def check():
    debug=1
try:
    debug=1
except: pass
def run():
    try:
        debug=1
    except: pass
