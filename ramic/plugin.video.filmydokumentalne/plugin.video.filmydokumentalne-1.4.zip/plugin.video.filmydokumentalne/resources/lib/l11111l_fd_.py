# -*- coding: utf-8 -*-
import sys
l1ll1ll_fd_ = sys.version_info [0] == 2
l1lllll1_fd_ = 2048
l111l_fd_ = 7
def l11111_fd_ (ll_fd_):
	global l1ll11l_fd_
	l1ll1l_fd_ = ord (ll_fd_ [-1])
	l1lll11_fd_ = ll_fd_ [:-1]
	l11ll1l_fd_ = l1ll1l_fd_ % len (l1lll11_fd_)
	l1lll_fd_ = l1lll11_fd_ [:l11ll1l_fd_] + l1lll11_fd_ [l11ll1l_fd_:]
	if l1ll1ll_fd_:
		l1l11l1_fd_ = unicode () .join ([unichr (ord (char) - l1lllll1_fd_ - (l111ll_fd_ + l1ll1l_fd_) % l111l_fd_) for l111ll_fd_, char in enumerate (l1lll_fd_)])
	else:
		l1l11l1_fd_ = str () .join ([chr (ord (char) - l1lllll1_fd_ - (l111ll_fd_ + l1ll1l_fd_) % l111l_fd_) for l111ll_fd_, char in enumerate (l1lll_fd_)])
	return eval (l1l11l1_fd_)
import urllib2,urllib
import re,os
import json
import cookielib
from urlparse import urlparse
l11llll11_fd_=l11111_fd_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡨ࡬ࡰࡲࡿࡤࡰ࡭ࡸࡱࡪࡴࡴࡢ࡮ࡱࡩ࠳࡫ࡵࠨ৸")
l1l111111_fd_ = 10
l11l11111_fd_=l11111_fd_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠹࠾࠮࠱࠰࠵࠹࠻࠺࠮࠺࠹ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪ৹")
def l11llllll_fd_(url,data=None,header={}):
    if not header:
        header = {l11111_fd_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ৺"):l11l11111_fd_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1l111111_fd_)
        l11llll_fd_ =  response.read()
    except urllib2.HTTPError as e:
        l11llll_fd_ = l11111_fd_ (u"ࠧࠨ৻")
    return l11llll_fd_
def l1ll1l1_fd_(url):
    content = l11llllll_fd_(url)
    out=[]
    l11l111l1_fd_= re.compile(l11111_fd_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡩࡥ࠿ࠥࡲࡪࡽࡳࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧৼ"),re.DOTALL).findall(content)
    for n in l11l111l1_fd_:
        l11l1l1ll_fd_ = re.compile(l11111_fd_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡹ࡯ࡴ࡭ࡧࡀࠦࡨࢀࡹࡵࡣ࡭ࠤࡼ࡯ࡥࡤࡧ࡭ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ৽")).findall(n)
        l11l1l1l1_fd_ = re.compile(l11111_fd_ (u"ࠪࡀࡵࡄࠨ࠯ࠬࡂ࠭ࡁ࠭৾")).findall(n)
        l11l1l1l1_fd_ = l11111_fd_ (u"ࠫࡡࡴࠧ৿").join(l11l1l1l1_fd_) if l11l1l1l1_fd_ else l11111_fd_ (u"ࠬ࠭਀")
        if l11l1l1ll_fd_:
            h = l11l1l1ll_fd_[0][0]
            t = l11l1l11l_fd_(l11l1l1ll_fd_[0][1].strip())
            out.append({l11111_fd_ (u"࠭ࡵࡳ࡮ࠪਁ"):h,l11111_fd_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ਂ"):t,l11111_fd_ (u"ࠨࡲ࡯ࡳࡹ࠭ਃ"):l11l1l1l1_fd_})
    l11l11lll_fd_ = re.compile(l11111_fd_ (u"ࠩ࠿ࡥࠥࡩ࡬ࡢࡵࡶࡁࠧࡶࡲࡦࡸ࡬ࡳࡺࡹࡰࡰࡵࡷࡷࡱ࡯࡮࡬ࠤࠣࡶࡪࡲ࠽ࠣࡲࡵࡩࡻࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠧ਄")).search(content)
    l11l11lll_fd_ = l11l11lll_fd_.group(1) if l11l11lll_fd_ else False
    l111lllll_fd_ = re.compile(l11111_fd_ (u"ࠪࡀࡦࠦࡣ࡭ࡣࡶࡷࡂࠨ࡮ࡦࡺࡷࡴࡴࡹࡴࡴ࡮࡬ࡲࡰࠨࠠࡳࡧ࡯ࡁࠧࡴࡥࡹࡶࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠫਅ")).search(content)
    l111lllll_fd_ = l111lllll_fd_.group(1) if l111lllll_fd_ else False
    return (out, (l11l11lll_fd_,l111lllll_fd_))
def l1llll_fd_():
    content = l11llllll_fd_(l11llll11_fd_)
    items = re.compile(l11111_fd_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࡡࠢ࡝ࠩࡠࠬ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡨ࡬ࡰࡲࡿࡤࡰ࡭ࡸࡱࡪࡴࡴࡢ࡮ࡱࡩ࠳࡫ࡵ࠰࡭ࡤࡲࡦࡲࡹ࠰࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠࡠࡸ࠰࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪਆ")).findall(content)
    out=[]
    for href,title in items:
        out.append({l11111_fd_ (u"ࠬࡺࡩࡵ࡮ࡨࠫਇ"):l11l1l11l_fd_(title.strip()),l11111_fd_ (u"࠭ࡵࡳ࡮ࠪਈ"):href})
    return out
def l1ll11_fd_():
    content = l11llllll_fd_(l11llll11_fd_)
    items = re.compile(l11111_fd_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾࡝ࠥࡠࠬࡣࠨࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲࡫࡯࡬࡮ࡻࡧࡳࡰࡻ࡭ࡦࡰࡷࡥࡱࡴࡥ࠯ࡧࡸ࠳ࡰࡧࡴࡦࡩࡲࡶ࡮࡫࠯࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟࡟ࡷ࠯ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩਉ")).findall(content)
    out=[]
    for href,title in items:
        out.append({l11111_fd_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧਊ"):l11l1l11l_fd_(title.strip()),l11111_fd_ (u"ࠩࡸࡶࡱ࠭਋"):href})
    return out
def l1l1l_fd_():
    content = l11llllll_fd_(l11llll11_fd_)
    items = re.compile(l11111_fd_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࡠࠨ࡜ࠨ࡟ࠫ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡧ࡫࡯ࡱࡾࡪ࡯࡬ࡷࡰࡩࡳࡺࡡ࡭ࡰࡨ࠲ࡪࡻ࠯࡝ࡦࡾ࠸ࢂ࠵࡜ࡥࡽ࠵ࢁ࠴࠯࡛ࠣ࡞ࠪࡡࡡࡹࠪ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ਌")).findall(content)
    out=[]
    for href,title in items:
        out.append({l11111_fd_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ਍"):l11l1l11l_fd_(title.strip()),l11111_fd_ (u"ࠬࡻࡲ࡭ࠩ਎"):href})
    return out
def l1lll1ll_fd_():
    out=[
    {l11111_fd_ (u"࠭ࡴࡪࡶ࡯ࡩࠬਏ"):l11111_fd_ (u"ࠧࡢࡰࡼࡪ࡮ࡲࡥࡴࠩਐ"),l11111_fd_ (u"ࠨࡷࡵࡰࠬ਑"):l11111_fd_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡦࡪ࡮ࡰࡽࡩࡵ࡫ࡶ࡯ࡨࡲࡹࡧ࡬࡯ࡧ࠱ࡩࡺ࠵ࡳࡦࡴࡺࡩࡷࡿ࠯ࡢࡰࡼࡪ࡮ࡲࡥࡴ࠱ࠪ਒")},
    {l11111_fd_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩਓ"):l11111_fd_ (u"ࠫࡨࡪࡡࠨਔ"),l11111_fd_ (u"ࠬࡻࡲ࡭ࠩਕ"):l11111_fd_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡪ࡮ࡲ࡭ࡺࡦࡲ࡯ࡺࡳࡥ࡯ࡶࡤࡰࡳ࡫࠮ࡦࡷ࠲ࡷࡪࡸࡷࡦࡴࡼ࠳ࡨࡪࡡ࠰ࠩਖ")},
    {l11111_fd_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ਗ"):l11111_fd_ (u"ࠨࡸ࡬ࡱࡪࡵࠧਘ"),l11111_fd_ (u"ࠩࡸࡶࡱ࠭ਙ"):l11111_fd_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡧ࡫࡯ࡱࡾࡪ࡯࡬ࡷࡰࡩࡳࡺࡡ࡭ࡰࡨ࠲ࡪࡻ࠯ࡴࡧࡵࡻࡪࡸࡹ࠰ࡸ࡬ࡱࡪࡵ࠯ࠨਚ")},
    {l11111_fd_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪਛ"):l11111_fd_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭ਜ"),l11111_fd_ (u"࠭ࡵࡳ࡮ࠪਝ"):l11111_fd_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲࡫࡯࡬࡮ࡻࡧࡳࡰࡻ࡭ࡦࡰࡷࡥࡱࡴࡥ࠯ࡧࡸ࠳ࡸ࡫ࡲࡸࡧࡵࡽ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࠵ࠧਞ")},
    ]
    return out
def l11l111_fd_():
    content = l11llllll_fd_(l11111_fd_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡬ࡩ࡭࡯ࡼࡨࡴࡱࡵ࡮ࡧࡱࡸࡦࡲ࡮ࡦ࠰ࡨࡹ࠴ࡹࡰࡪࡵ࠰ࡳࡩ࠳ࡡ࠮ࡦࡲ࠱ࡿ࠵ࠧਟ"))
    items = re.compile(l11111_fd_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡩ࡭ࡱࡳࡹࡥࡱ࡮ࡹࡲ࡫࡮ࡵࡣ࡯ࡲࡪ࠴ࡥࡶ࠱࠱࠮ࡄ࠯ࠢ࠿࠾ࡶࡴࡦࡴࠠࡤ࡮ࡤࡷࡸࡃࠢࡩࡧࡤࡨࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࡁ࠵ࡡ࠿ࠩਠ")).findall(content)
    out=[]
    for href,title in items:
        out.append({l11111_fd_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩਡ"):l11l1l11l_fd_(title.strip()),l11111_fd_ (u"ࠫࡺࡸ࡬ࠨਢ"):href})
    return out
def l1111l1_fd_(url):
    content = l11llllll_fd_(url)
    l11l111ll_fd_=l11111_fd_ (u"ࠬ࠭ਣ")
    l11l11l1l_fd_ = re.compile(l11111_fd_ (u"࠭࠼ࡱࡀ࡟ࡷ࠯ࡂࡩࡧࡴࡤࡱࡪ࠮࠮ࠫࡁࠬࡀ࠴࡯ࡦࡳࡣࡰࡩࡃ࠭ਤ"),re.DOTALL).findall(content)
    if l11l11l1l_fd_:
        src = re.compile(l11111_fd_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬਥ")).findall(l11l11l1l_fd_[0])
        if src:
            l11l111ll_fd_= src[0]
    return l11l111ll_fd_
def l11l1l111_fd_(url,data=None,header={},l11l1ll11_fd_=None):
    if not l11l1ll11_fd_:
        l11l1ll11_fd_ = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPHandler(), urllib2.HTTPCookieProcessor(l11l1ll11_fd_))
    urllib2.install_opener(opener)
    if not header:
        header = {l11111_fd_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬਦ"):l11l11111_fd_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1l111111_fd_)
        l11llll_fd_ =  response.read()
        response.close()
    except urllib2.HTTPError as e:
        l11llll_fd_ = l11111_fd_ (u"ࠩࠪਧ")
    return l11llll_fd_,l11l1ll11_fd_
def l1llll11_fd_(url):
    l11l1ll11_fd_ = cookielib.LWPCookieJar()
    id = re.compile(l11111_fd_ (u"ࠪ࡭ࡩࡃࠨ࡝ࡦ࠮࠭ࠬਨ")).search(url).group(1)
    l11l11ll1_fd_ = l11111_fd_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡻ࡯ࡤࡦࡱ࠱ࡥࡳࡿࡦࡪ࡮ࡨࡷ࠳ࡶ࡬࠰ࡸ࡬ࡨࡪࡵࡳ࠯࡬ࡶࡴࡄ࡯ࡤ࠾ࠩ਩")+id
    header = {l11111_fd_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩਪ"):l11111_fd_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠹࠲࠶ࡁࠠࡘࡑ࡚࠺࠹ࡁࠠࡕࡴ࡬ࡨࡪࡴࡴ࠰࠹࠱࠴ࡀࠦࡁࡔ࠽ࠣࡶࡻࡀ࠱࠲࠰࠳࠭ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠩਫ"),
            l11111_fd_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨਬ"):l11l11ll1_fd_}
    url = l11111_fd_ (u"ࠣࡪࡷࡸࡵࡀ࠯࠰ࡸ࡬ࡨࡪࡵ࠮ࡢࡰࡼࡪ࡮ࡲࡥࡴ࠰ࡳࡰ࠴ࡽ࠮࡫ࡵࡳࡃ࡮ࡪ࠽ࠦࡵࠩࡻ࡮ࡪࡴࡩ࠿࠹࠶࠵ࠬࡨࡦ࡫ࡪ࡬ࡹࡃ࠳࠵࠻ࠩࡴࡴࡹ࠽ࠧࡵ࡮࡭ࡳࡃ࠰ࠣਭ") % id
    content,l11l1ll11_fd_ = l11l1l111_fd_(l11111_fd_ (u"ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡹ࡭ࡩ࡫࡯࠯ࡣࡱࡽ࡫࡯࡬ࡦࡵ࠱ࡴࡱ࠵ࡷ࠯࡬ࡶࡴࡄ࡯ࡤ࠾ࠧࡶࠪࡼ࡯ࡤࡵࡪࡀ࠺࠷࠶ࠦࡩࡧ࡬࡫࡭ࡺ࠽࠴࠶࠼ࠪࡵࡵࡳ࠾ࠨࡶ࡯࡮ࡴ࠽࠱ࠤਮ") % id,header=header,l11l1ll11_fd_=l11l1ll11_fd_)
    r = re.search(l11111_fd_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡂࠬࡵࡩࡳ࡝ࡁࡦࡳࡩ࡫࠽࡜ࡠࠥࡡ࠰ࡅࠩࠣࠩਯ"), content, re.DOTALL)
    if r:
        l11l11l11_fd_ = l11111_fd_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡻ࡯ࡤࡦࡱ࠱ࡥࡳࡿࡦࡪ࡮ࡨࡷ࠳ࡶ࡬࠰ࠧࡶࠫਰ") % r.group(1)
        header[l11111_fd_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ਱")]=l11111_fd_ (u"࠭࠻ࠨਲ").join([l11111_fd_ (u"ࠧࠦࡵࡀࠩࡸ࠭ਲ਼")%(c.name,c.value) for c in l11l1ll11_fd_])
        header[l11111_fd_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ਴")]=url
        data,l11l1ll11_fd_ = l11l1l111_fd_(l11l11l11_fd_, header=header,l11l1ll11_fd_=l11l1ll11_fd_)
        match = re.search(l11111_fd_ (u"ࠩࠫ࡬ࡹࡺࡰ࡜ࡠࠥࡡ࠰ࡅ࡭ࡱ࠶ࠬࠫਵ"),data)
        if match:
            return match.group(1)
    return l11111_fd_ (u"ࠪࠫਸ਼")
def l11l1l11l_fd_(l11l1111l_fd_):
    s=l11111_fd_ (u"ࠫࡏ࡯ࡎࡤ࡜ࡆࡷ࠼࠭਷")
    l11l1111l_fd_ = re.sub(s.decode(l11111_fd_ (u"ࠬࡨࡡࡴࡧ࠹࠸ࠬਸ")),l11111_fd_ (u"࠭ࠧਹ"),l11l1111l_fd_)
    l11l1111l_fd_ = l11l1111l_fd_.replace(l11111_fd_ (u"ࠧࠧ࡮ࡷ࠿ࡧࡸ࠯ࠧࡩࡷ࠿ࠬ਺"),l11111_fd_ (u"ࠨࠢࠪ਻"))
    l11l1111l_fd_ = l11l1111l_fd_.replace(l11111_fd_ (u"ࠩࠩࡵࡺࡵࡴ࠼਼ࠩ"),l11111_fd_ (u"ࠪࠫ਽")).replace(l11111_fd_ (u"ࠫࠫࡧ࡭ࡱ࠽ࡴࡹࡴࡺ࠻ࠨਾ"),l11111_fd_ (u"ࠬ࠭ਿ"))
    l11l1111l_fd_ = l11l1111l_fd_.replace(l11111_fd_ (u"࠭ࠦࡰࡣࡦࡹࡹ࡫࠻ࠨੀ"),l11111_fd_ (u"ࠧࣴࠩੁ")).replace(l11111_fd_ (u"ࠨࠨࡒࡥࡨࡻࡴࡦ࠽ࠪੂ"),l11111_fd_ (u"ࠩࣖࠫ੃"))
    l11l1111l_fd_ = l11l1111l_fd_.replace(l11111_fd_ (u"ࠪࠪࡦࡳࡰ࠼ࡱࡤࡧࡺࡺࡥ࠼ࠩ੄"),l11111_fd_ (u"ࠫࣸ࠭੅")).replace(l11111_fd_ (u"ࠬࠬࡡ࡮ࡲ࠾ࡓࡦࡩࡵࡵࡧ࠾ࠫ੆"),l11111_fd_ (u"࣓࠭ࠨੇ"))
    l11l1111l_fd_ = l11l1111l_fd_.replace(l11111_fd_ (u"ࠧࠧࡣࡰࡴࡀ࠭ੈ"),l11111_fd_ (u"ࠨࠨࠪ੉"))
    l11l1111l_fd_ = l11l1111l_fd_.replace(l11111_fd_ (u"ࠩ࡟ࡹ࠵࠷࠰࠶ࠩ੊"),l11111_fd_ (u"ࠪउࠬੋ")).replace(l11111_fd_ (u"ࠫࡡࡻ࠰࠲࠲࠷ࠫੌ"),l11111_fd_ (u"ࠬऊ੍ࠧ"))
    l11l1111l_fd_ = l11l1111l_fd_.replace(l11111_fd_ (u"࠭࡜ࡶ࠲࠴࠴࠼࠭੎"),l11111_fd_ (u"ࠧईࠩ੏")).replace(l11111_fd_ (u"ࠨ࡞ࡸ࠴࠶࠶࠶ࠨ੐"),l11111_fd_ (u"ࠩउࠫੑ"))
    l11l1111l_fd_ = l11l1111l_fd_.replace(l11111_fd_ (u"ࠪࡠࡺ࠶࠱࠲࠻ࠪ੒"),l11111_fd_ (u"ࠫञ࠭੓")).replace(l11111_fd_ (u"ࠬࡢࡵ࠱࠳࠴࠼ࠬ੔"),l11111_fd_ (u"࠭घࠨ੕"))
    l11l1111l_fd_ = l11l1111l_fd_.replace(l11111_fd_ (u"ࠧ࡝ࡷ࠳࠵࠹࠸ࠧ੖"),l11111_fd_ (u"ࠨॄࠪ੗")).replace(l11111_fd_ (u"ࠩ࡟ࡹ࠵࠷࠴࠲ࠩ੘"),l11111_fd_ (u"ࠪॅࠬਖ਼"))
    l11l1111l_fd_ = l11l1111l_fd_.replace(l11111_fd_ (u"ࠫࡡࡻ࠰࠲࠶࠷ࠫਗ਼"),l11111_fd_ (u"ࠬॊࠧਜ਼")).replace(l11111_fd_ (u"࠭࡜ࡶ࠲࠴࠸࠹࠭ੜ"),l11111_fd_ (u"ࠧॄࠩ੝"))
    l11l1111l_fd_ = l11l1111l_fd_.replace(l11111_fd_ (u"ࠨ࡞ࡸ࠴࠵࡬࠳ࠨਫ਼"),l11111_fd_ (u"ࣶࠩࠫ੟")).replace(l11111_fd_ (u"ࠪࡠࡺ࠶࠰ࡥ࠵ࠪ੠"),l11111_fd_ (u"ࠫࣘ࠭੡"))
    l11l1111l_fd_ = l11l1111l_fd_.replace(l11111_fd_ (u"ࠬࡢࡵ࠱࠳࠸ࡦࠬ੢"),l11111_fd_ (u"࠭ज़ࠨ੣")).replace(l11111_fd_ (u"ࠧ࡝ࡷ࠳࠵࠺ࡧࠧ੤"),l11111_fd_ (u"ࠨड़ࠪ੥"))
    l11l1111l_fd_ = l11l1111l_fd_.replace(l11111_fd_ (u"ࠩ࡟ࡹ࠵࠷࠷ࡢࠩ੦"),l11111_fd_ (u"ࠪॾࠬ੧")).replace(l11111_fd_ (u"ࠫࡡࡻ࠰࠲࠹࠼ࠫ੨"),l11111_fd_ (u"ࠬॿࠧ੩"))
    l11l1111l_fd_ = l11l1111l_fd_.replace(l11111_fd_ (u"࠭࡜ࡶ࠲࠴࠻ࡨ࠭੪"),l11111_fd_ (u"ࠧॽࠩ੫")).replace(l11111_fd_ (u"ࠨ࡞ࡸ࠴࠶࠽ࡢࠨ੬"),l11111_fd_ (u"ࠩॾࠫ੭"))
    return l11l1111l_fd_
