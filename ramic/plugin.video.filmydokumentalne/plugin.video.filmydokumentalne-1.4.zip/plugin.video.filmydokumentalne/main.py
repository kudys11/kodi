# -*- coding: utf-8 -*-
import sys
l1ll1ll_fd_ = sys.version_info [0] == 2
l1lllll1_fd_ = 2048
l111l_fd_ = 7
def l11111_fd_ (ll_fd_):
	global l1ll11l_fd_
	l1ll1l_fd_ = ord (ll_fd_ [-1])
	l1lll11_fd_ = ll_fd_ [:-1]
	l11ll1l_fd_ = l1ll1l_fd_ % len (l1lll11_fd_)
	l1lll_fd_ = l1lll11_fd_ [:l11ll1l_fd_] + l1lll11_fd_ [l11ll1l_fd_:]
	if l1ll1ll_fd_:
		l1l11l1_fd_ = unicode () .join ([unichr (ord (char) - l1lllll1_fd_ - (l111ll_fd_ + l1ll1l_fd_) % l111l_fd_) for l111ll_fd_, char in enumerate (l1lll_fd_)])
	else:
		l1l11l1_fd_ = str () .join ([chr (ord (char) - l1lllll1_fd_ - (l111ll_fd_ + l1ll1l_fd_) % l111l_fd_) for l111ll_fd_, char in enumerate (l1lll_fd_)])
	return eval (l1l11l1_fd_)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
l111_fd_        = sys.argv[0]
l1l1l11_fd_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l1llll1l_fd_        = xbmcaddon.Addon()
l1ll_fd_       = l1llll1l_fd_.getAddonInfo(l11111_fd_ (u"ࠫࡳࡧ࡭ࡦࠩࠀ"))
PATH            = l1llll1l_fd_.getAddonInfo(l11111_fd_ (u"ࠬࡶࡡࡵࡪࠪࠁ"))
l11lll_fd_        = xbmc.translatePath(l1llll1l_fd_.getAddonInfo(l11111_fd_ (u"࠭ࡰࡳࡱࡩ࡭ࡱ࡫ࠧࠂ"))).decode(l11111_fd_ (u"ࠧࡶࡶࡩ࠱࠽࠭ࠃ"))
l11l1ll_fd_       = PATH+l11111_fd_ (u"ࠨ࠱ࡵࡩࡸࡵࡵࡳࡥࡨࡷ࠴࠭ࠄ")
import resources.lib.l11111l_fd_ as l11l11l_fd_
import resources.lib.l1l1ll1_fd_ as l1l1ll1_fd_
l1111ll_fd_=l11111_fd_ (u"ࠩࠪࠅ")
def l1ll111_fd_(name, url, mode, params={}, l1l11_fd_=l11111_fd_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧࠆ"), infoLabels=False, isFolder=False, IsPlayable=True,fanart=l1111ll_fd_,l1llll1_fd_=1):
    u = l11l_fd_({l11111_fd_ (u"ࠫࡲࡵࡤࡦࠩࠇ"): mode, l11111_fd_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࡳࡧ࡭ࡦࠩࠈ"): name, l11111_fd_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧࠉ") : url, l11111_fd_ (u"ࠧࡱࡣࡵࡥࡲࡹࠧࠊ"):params})
    l1lll1l_fd_ = xbmcgui.ListItem(name)
    l1lll1l1_fd_=[l11111_fd_ (u"ࠨࡶ࡫ࡹࡲࡨࠧࠋ"),l11111_fd_ (u"ࠩࡳࡳࡸࡺࡥࡳࠩࠌ"),l11111_fd_ (u"ࠪࡦࡦࡴ࡮ࡦࡴࠪࠍ"),l11111_fd_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫࠎ"),l11111_fd_ (u"ࠬࡩ࡬ࡦࡣࡵࡥࡷࡺࠧࠏ"),l11111_fd_ (u"࠭ࡣ࡭ࡧࡤࡶࡱࡵࡧࡰࠩࠐ"),l11111_fd_ (u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪࠑ"),l11111_fd_ (u"ࠨ࡫ࡦࡳࡳ࠭ࠒ")]
    l11_fd_ = dict(zip(l1lll1l1_fd_,[l1l11_fd_ for x in l1lll1l1_fd_]))
    l11_fd_[l11111_fd_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬࠓ")] = fanart if fanart else l11_fd_[l11111_fd_ (u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭ࠔ")]
    l11_fd_[l11111_fd_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫࠕ")] = fanart if fanart else l11_fd_[l11111_fd_ (u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨࠖ")]
    l1lll1l_fd_.setArt(l11_fd_)
    if not infoLabels:
        infoLabels={l11111_fd_ (u"ࠨࡴࡪࡶ࡯ࡩࠧࠗ"): name}
    l1lll1l_fd_.setInfo(type=l11111_fd_ (u"ࠢࡷ࡫ࡧࡩࡴࠨ࠘"), infoLabels=infoLabels)
    if IsPlayable:
        l1lll1l_fd_.setProperty(l11111_fd_ (u"ࠨࡋࡶࡔࡱࡧࡹࡢࡤ࡯ࡩࠬ࠙"), l11111_fd_ (u"ࠩࡷࡶࡺ࡫ࠧࠚ"))
    l1l1l1_fd_ = []
    l1l1l1_fd_.append((l11111_fd_ (u"ࠪࡍࡳ࡬࡯ࡳ࡯ࡤࡧ࡯ࡧࠧࠛ"), l11111_fd_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡄࡧࡹ࡯࡯࡯ࠪࡌࡲ࡫ࡵࠩࠨࠜ")))
    l1lll1l_fd_.addContextMenuItems(l1l1l1_fd_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l1l1l11_fd_, url=u, listitem=l1lll1l_fd_, isFolder=isFolder,totalItems=l1llll1_fd_)
    xbmcplugin.addSortMethod(l1l1l11_fd_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l11111_fd_ (u"ࠧࠫࡒ࠭ࠢࠨ࡝࠱ࠦࠥࡑࠤࠝ"))
    return ok
def l11l11_fd_(name,ex_link=None, params={}, mode=l11111_fd_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠞ"),iconImage=l11111_fd_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫࠟ"), infoLabels=None, fanart=l1111ll_fd_,contextmenu=None):
    url = l11l_fd_({l11111_fd_ (u"ࠨ࡯ࡲࡨࡪ࠭ࠠ"): mode, l11111_fd_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭ࠡ"): name, l11111_fd_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫࠢ") : ex_link, l11111_fd_ (u"ࠫࡵࡧࡲࡢ࡯ࡶࠫࠣ") : params})
    l11l1l_fd_ = xbmcgui.ListItem(name)
    if infoLabels:
        l11l1l_fd_.setInfo(type=l11111_fd_ (u"ࠧࡼࡩࡥࡧࡲࠦࠤ"), infoLabels=infoLabels)
    l1lll1l1_fd_=[l11111_fd_ (u"࠭ࡴࡩࡷࡰࡦࠬࠥ"),l11111_fd_ (u"ࠧࡱࡱࡶࡸࡪࡸࠧࠦ"),l11111_fd_ (u"ࠨࡤࡤࡲࡳ࡫ࡲࠨࠧ"),l11111_fd_ (u"ࠩࡩࡥࡳࡧࡲࡵࠩࠨ"),l11111_fd_ (u"ࠪࡧࡱ࡫ࡡࡳࡣࡵࡸࠬࠩ"),l11111_fd_ (u"ࠫࡨࡲࡥࡢࡴ࡯ࡳ࡬ࡵࠧࠪ"),l11111_fd_ (u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨࠫ"),l11111_fd_ (u"࠭ࡩࡤࡱࡱࠫࠬ")]
    l11_fd_ = dict(zip(l1lll1l1_fd_,[iconImage for x in l1lll1l1_fd_]))
    l11_fd_[l11111_fd_ (u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪ࠭")] = fanart if fanart else l11_fd_[l11111_fd_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫ࠮")]
    l11_fd_[l11111_fd_ (u"ࠩࡩࡥࡳࡧࡲࡵࠩ࠯")] = fanart if fanart else l11_fd_[l11111_fd_ (u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭࠰")]
    l11l1l_fd_.setArt(l11_fd_)
    if contextmenu:
        l1l1l1_fd_=contextmenu
        l11l1l_fd_.addContextMenuItems(l1l1l1_fd_, replaceItems=True)
    else:
        l1l1l1_fd_ = []
        l1l1l1_fd_.append((l11111_fd_ (u"ࠫࡎࡴࡦࡰࡴࡰࡥࡨࡰࡡࠨ࠱"), l11111_fd_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡅࡨࡺࡩࡰࡰࠫࡍࡳ࡬࡯ࠪࠩ࠲")),)
        l11l1l_fd_.addContextMenuItems(l1l1l1_fd_, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=l1l1l11_fd_, url=url,listitem=l11l1l_fd_, isFolder=True)
    xbmcplugin.addSortMethod(l1l1l11_fd_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l11111_fd_ (u"ࠨࠥࡓ࠮ࠣࠩ࡞࠲ࠠࠦࡒࠥ࠳"))
def l1l11l_fd_(l11lll1_fd_):
    l1_fd_ = {}
    for k, v in l11lll1_fd_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l11111_fd_ (u"ࠧࡶࡶࡩ࠼ࠬ࠴"))
        elif isinstance(v, str):
            v.decode(l11111_fd_ (u"ࠨࡷࡷࡪ࠽࠭࠵"))
        l1_fd_[k] = v
    return l1_fd_
def l11l_fd_(query):
    return l111_fd_ + l11111_fd_ (u"ࠩࡂࠫ࠶") + urllib.urlencode(l1l11l_fd_(query))
import ramic as l11l1_fd_
import time
l1ll1_fd_ = lambda x,y: ord(x)+8*y if ord(x)%2 else ord(x)
l1l1_fd_ = lambda l11ll_fd_: l11111_fd_ (u"ࠪࠫ࠷").join([chr(l1ll1_fd_(x,1) ) for x in l11ll_fd_.encode(l11111_fd_ (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫ࠸")).strip()])
l111ll1_fd_ = lambda l11ll_fd_: l11111_fd_ (u"ࠬ࠭࠹").join([chr(l1ll1_fd_(x,-1) ) for x in l11ll_fd_]).decode(l11111_fd_ (u"࠭ࡢࡢࡵࡨ࠺࠹࠭࠺"))
if not os.path.exists(l11111_fd_ (u"ࠧ࠰ࡪࡲࡱࡪ࠵࡯ࡴ࡯ࡦࠫ࠻")):
    tm=time.gmtime()
    try:    l11ll1_fd_,l1l11ll_fd_,l1l111_fd_ = l111ll1_fd_(l1llll1l_fd_.getSetting(l11111_fd_ (u"ࠨ࡭ࡲࡨࠬ࠼"))).split(l11111_fd_ (u"ࠩ࠽ࠫ࠽"))
    except: l11ll1_fd_,l1l11ll_fd_,l1l111_fd_ =  [l11111_fd_ (u"ࠪ࠱࠶࠭࠾"),l11111_fd_ (u"ࠫࠬ࠿"),l11111_fd_ (u"ࠬ࠳࠱ࠨࡀ")]
    if int(l11ll1_fd_) != tm.tm_hour:
        try:    l1l1lll_fd_ = re.findall(l11111_fd_ (u"࠭ࡋࡐࡆ࠽ࠤ࠭࠴ࠪࡀࠫ࡟ࡲࠬࡁ"),urllib2.urlopen(l11111_fd_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡴࡤࡻ࠳࡭ࡩࡵࡪࡸࡦࡺࡹࡥࡳࡥࡲࡲࡹ࡫࡮ࡵ࠰ࡦࡳࡲ࠵ࡲࡢ࡯࡬ࡧࡸࡶࡡ࠰࡭ࡲࡨ࡮࠵࡭ࡢࡵࡷࡩࡷ࠵ࡒࡆࡃࡇࡑࡊ࠴࡭ࡥࠩࡂ")).read())[0].strip(l11111_fd_ (u"ࠨࠬࠪࡃ"))
        except: l1l1lll_fd_ = l11111_fd_ (u"ࠩࠪࡄ")
def l1l111l_fd_(ex_link):
    l111l1_fd_,l111lll_fd_ = l11l11l_fd_.l1ll1l1_fd_(ex_link)
    if l111lll_fd_[0]:
        l1ll111_fd_(name=l11111_fd_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࡁࡂࠠࡑࡱࡳࡶࡿ࡫ࡤ࡯࡫ࡤࠤࡸࡺࡲࡰࡰࡤࠤࡁࡂ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨࡏ"), url=l111lll_fd_[0], params={}, mode=l11111_fd_ (u"ࠧࡱࡣࡪࡩ࠿ࡒࡩࡴࡶࡌࡸࡪࡳࡳࠨࡐ"), IsPlayable=False)
    items=len(l111l1_fd_)
    for f in l111l1_fd_:
        l1ll111_fd_(name=f.get(l11111_fd_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࡑ")), url=f.get(l11111_fd_ (u"ࠩࡸࡶࡱ࠭ࡒ"),l11111_fd_ (u"ࠪࠫࡓ")), mode=l11111_fd_ (u"ࠫ࡬࡫ࡴࡍ࡫ࡱ࡯ࡸ࠭ࡔ"), l1l11_fd_=f.get(l11111_fd_ (u"ࠬ࡯࡭ࡨࠩࡕ")), infoLabels=f, isFolder=False, IsPlayable=True,l1llll1_fd_=items)
    if l111lll_fd_[1]:
        l1ll111_fd_(name=l11111_fd_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࡃࡄࠠࡏࡣࡶࡸञࡶ࡮ࡢࠢࡶࡸࡷࡵ࡮ࡢࠢࡁࡂࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࡖ"), url=l111lll_fd_[1], params={}, mode=l11111_fd_ (u"ࠧࡱࡣࡪࡩ࠿ࡒࡩࡴࡶࡌࡸࡪࡳࡳࠨࡗ"), IsPlayable=False)
    xbmcplugin.setContent(l1l1l11_fd_, l11111_fd_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨࡘ"))
def l1111l_fd_(l1llllll_fd_):
    if  l1llllll_fd_==l11111_fd_ (u"ࠩࡪࡩࡹࡑࡡ࡯ࡣ࡯ࡽ࡙ࠬ"):l11ll11_fd_=l11l11l_fd_.l1llll_fd_
    elif l1llllll_fd_==l11111_fd_ (u"ࠪ࡫ࡪࡺࡋࡢࡶࡨ࡫ࡴࡸࡩࡦ࡚ࠩ"):l11ll11_fd_=l11l11l_fd_.l1ll11_fd_
    elif l1llllll_fd_==l11111_fd_ (u"ࠫ࡬࡫ࡴࡂࡴࡦ࡬࡮ࡽࡵ࡮࡛ࠩ"):l11ll11_fd_=l11l11l_fd_.l1l1l_fd_
    elif l1llllll_fd_==l11111_fd_ (u"ࠬ࡭ࡥࡵࡕࡨࡶࡼ࡫ࡲࡺࠩ࡜"):l11ll11_fd_=l11l11l_fd_.l1lll1ll_fd_
    items = l11ll11_fd_()
    for f in items:
        l1ll111_fd_(name=f.get(l11111_fd_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ࡝")), url=f.get(l11111_fd_ (u"ࠧࡶࡴ࡯ࠫ࡞"),l11111_fd_ (u"ࠨࠩ࡟")), mode=l11111_fd_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰࡷࠬࡠ"), l1l11_fd_=f.get(l11111_fd_ (u"ࠪ࡭ࡲ࡭ࠧࡡ")), infoLabels=f, isFolder=True, IsPlayable=True,l1llll1_fd_=len(items))
def l1lll1_fd_(l11llll_fd_):
    l1l1ll1_fd_.run()
    l1l1111_fd_=l11111_fd_ (u"ࠫࠬࡢ")
    l1l1111_fd_=l11l1_fd_.__mysolver__.go(l11llll_fd_)
    if False:
        if l11111_fd_ (u"ࠬࡩࡤࡢ࠰ࡳࡰࠬࡣ") in l11llll_fd_:
            import resources.lib.l111l11_fd_ as l111l11_fd_
            l1l1111_fd_ = l111l11_fd_.l11l1l1_fd_(l11llll_fd_)
            if type(l1l1111_fd_) is list:
                l111l1l_fd_ = [x[0] for x in l1l1111_fd_]
                l1l_fd_ = xbmcgui.Dialog().select(l11111_fd_ (u"ࠨࡄࡰࡵࡷझࡵࡴࡥࠡ࡬ࡤ࡯ࡴॡࡣࡪࠢࡶࡸࡷࡻ࡭ࡪࡧࡱ࡭ࡦࠦࡶࡪࡦࡨࡳࠧࡤ"), l111l1l_fd_)
                if l1l_fd_>-1:
                    l1l1111_fd_ = l111l11_fd_.l11l1l1_fd_(l1l1111_fd_[l1l_fd_][1])
                else:
                    l1l1111_fd_=l11111_fd_ (u"ࠧࠨࡥ")
    if not l1l1111_fd_ and l11111_fd_ (u"ࠨࡣࡱࡽ࡫࡯࡬ࡦࡵ࠱ࡴࡱ࠭ࡦ") in l11llll_fd_:
        l1l1111_fd_= l11l11l_fd_.l1llll11_fd_(l11llll_fd_)
    if not l1l1111_fd_:
        try:
            import urlresolver
            l1l1111_fd_ = urlresolver.resolve(l11llll_fd_)
        except Exception,e:
            l1l1111_fd_=l11111_fd_ (u"ࠩࠪࡧ")
    return l1l1111_fd_
def l1l1l1l_fd_(ex_link):
    l11llll_fd_ = l11l11l_fd_.l1111l1_fd_(ex_link)
    l1l1111_fd_ = l1lll1_fd_(l11llll_fd_)
    if l1l1111_fd_:
        xbmcplugin.setResolvedUrl(l1l1l11_fd_, True, xbmcgui.ListItem(path=l1l1111_fd_))
    else:
        xbmcplugin.setResolvedUrl(l1l1l11_fd_, False, xbmcgui.ListItem(path=l11111_fd_ (u"ࠪࠫࡨ")))
mode = args.get(l11111_fd_ (u"ࠫࡲࡵࡤࡦࠩࡩ"), None)
fname = args.get(l11111_fd_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࡳࡧ࡭ࡦࠩࡪ"),[l11111_fd_ (u"࠭ࠧ࡫")])[0]
ex_link = args.get(l11111_fd_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨ࡬"),[l11111_fd_ (u"ࠨࠩ࡭")])[0]
params = args.get(l11111_fd_ (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩ࡮"),[{}])[0]
if mode is None:
    l11l11_fd_(name=l11111_fd_ (u"ࠪࡍࡳ࡬࡯ࡳ࡯ࡤࡧ࡯ࡧࠧ࡯"),mode=l11111_fd_ (u"ࠫࡤ࡯࡮ࡧࡱࡢࠫࡰ"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l11111_fd_ (u"ࠬࡶࡡࡵࡪࠪࡱ")))+l11111_fd_ (u"࠭࠯ࡪࡥࡲࡲ࠳ࡶ࡮ࡨࠩࡲ"),infoLabels={})
    l11l11_fd_(name=l11111_fd_ (u"ࠢࡑࡱ࡯ࡩࡨࡧ࡮ࡦࠤࡳ"),ex_link=l11111_fd_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡬ࡩ࡭࡯ࡼࡨࡴࡱࡵ࡮ࡧࡱࡸࡦࡲ࡮ࡦ࠰ࡨࡹ࠴ࡶ࡯࡭ࡧࡦࡥࡳ࡫࠯ࠨࡴ"),params={}, mode=l11111_fd_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰࡷࠬࡵ"),iconImage=l11111_fd_ (u"ࠪࠫࡶ"))
    l11l11_fd_(name=l11111_fd_ (u"ࠦࡓࡧࡪ࡯ࡱࡺࡷࡿ࡫ࠢࡷ"),ex_link=l11111_fd_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡩ࡭ࡱࡳࡹࡥࡱ࡮ࡹࡲ࡫࡮ࡵࡣ࡯ࡲࡪ࠴ࡥࡶ࠱ࡱࡥ࡯ࡴ࡯ࡸࡵࡽࡩ࠲࡬ࡩ࡭࡯ࡼ࠳ࠬࡸ"),params={}, mode=l11111_fd_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭ࡴࠩࡹ"),iconImage=l11111_fd_ (u"ࠧࠨࡺ"))
    l11l11_fd_(name=l11111_fd_ (u"ࠣࡔࡤࡲࡰ࡯࡮ࡨ࡫ࠥࡻ"),ex_link=l11111_fd_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡦࡪ࡮ࡰࡽࡩࡵ࡫ࡶ࡯ࡨࡲࡹࡧ࡬࡯ࡧ࠱ࡩࡺ࠵ࡲࡢࡰ࡮࡭ࡳ࡭࠯ࠨࡼ"),params={}, mode=l11111_fd_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱࡸ࠭ࡽ"),iconImage=l11111_fd_ (u"ࠫࠬࡾ"))
    l11l11_fd_(name=l11111_fd_ (u"ࠧࡡࡃࡐࡎࡒࡖࠥࡨ࡬ࡶࡧࡠࡏࡦࡴࡡृࡻ࡞࠳ࡈࡕࡌࡐࡔࡠࠦࡿ"),ex_link=l11111_fd_ (u"࠭ࡧࡦࡶࡎࡥࡳࡧ࡬ࡺࠩࢀ"),params={}, mode=l11111_fd_ (u"ࠧࡍ࡫ࡶࡸࡋࡵ࡬ࡥࡧࡵࡷࠬࢁ"),iconImage=l11111_fd_ (u"ࠨࠩࢂ"))
    l11l11_fd_(name=l11111_fd_ (u"ࠤ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࡌࡣࡷࡩ࡬ࡵࡲࡪࡧ࡞࠳ࡈࡕࡌࡐࡔࡠࠦࢃ"),ex_link=l11111_fd_ (u"ࠪ࡫ࡪࡺࡋࡢࡶࡨ࡫ࡴࡸࡩࡦࠩࢄ"),params={}, mode=l11111_fd_ (u"ࠫࡑ࡯ࡳࡵࡈࡲࡰࡩ࡫ࡲࡴࠩࢅ"),iconImage=l11111_fd_ (u"ࠬ࠭ࢆ"))
    l11l11_fd_(name=l11111_fd_ (u"ࠨ࡛ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࡆࡸࡣࡩ࡫ࡺࡹࡲࡡ࠯ࡄࡑࡏࡓࡗࡣࠢࢇ"),ex_link=l11111_fd_ (u"ࠧࡨࡧࡷࡅࡷࡩࡨࡪࡹࡸࡱࠬ࢈"),params={}, mode=l11111_fd_ (u"ࠨࡎ࡬ࡷࡹࡌ࡯࡭ࡦࡨࡶࡸ࠭ࢉ"),iconImage=l11111_fd_ (u"ࠩࠪࢊ"))
    l11l11_fd_(name=l11111_fd_ (u"ࠥ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞ࡕࡨࡶࡼ࡫ࡲࡺ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠥࢋ"),ex_link=l11111_fd_ (u"ࠫ࡬࡫ࡴࡔࡧࡵࡻࡪࡸࡹࠨࢌ"),params={}, mode=l11111_fd_ (u"ࠬࡒࡩࡴࡶࡉࡳࡱࡪࡥࡳࡵࠪࢍ"),iconImage=l11111_fd_ (u"࠭ࠧࢎ"))
    l11l11_fd_(name=l11111_fd_ (u"ࠢࡔࡲ࡬ࡷࠥࡵࡤࠡࡃࠣࡨࡴ࡚ࠦࠣ࢏"),ex_link=l11111_fd_ (u"ࠨࠩ࢐"),params={}, mode=l11111_fd_ (u"ࠩࡏ࡭ࡸࡺࡓࡱ࡫ࡶࠫ࢑"),iconImage=l11111_fd_ (u"ࠪࠫ࢒"))
elif mode[0].startswith(l11111_fd_ (u"ࠫࡤ࡯࡮ࡧࡱࡢࠫ࢓")):l11l1_fd_.__myinfo__.go(sys.argv)
elif mode[0].startswith(l11111_fd_ (u"ࠬࡶࡡࡨࡧࠪ࢔")):
    l1111_fd_,l1lllll_fd_ = mode[0].split(l11111_fd_ (u"࠭࠺ࠨ࢕"))
    url = l11l_fd_({l11111_fd_ (u"ࠧ࡮ࡱࡧࡩࠬ࢖"): l1lllll_fd_, l11111_fd_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬࢗ"): l11111_fd_ (u"ࠩࠪ࢘"), l11111_fd_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮࢙ࠫ") : ex_link, l11111_fd_ (u"ࠫࡵࡧࡲࡢ࡯ࡶ࢚ࠫ"):params})
    xbmc.executebuiltin(l11111_fd_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠨࠦࡵ࢛ࠬࠫ")% url)
elif mode[0] == l11111_fd_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭ࡴࠩ࢜"):    l1l111l_fd_(ex_link)
elif mode[0] == l11111_fd_ (u"ࠧࡍ࡫ࡶࡸࡋࡵ࡬ࡥࡧࡵࡷࠬ࢝"):  l1111l_fd_(ex_link)
elif mode[0] == l11111_fd_ (u"ࠨࡎ࡬ࡷࡹ࡙ࡰࡪࡵࠪ࢞"):
    items = l11l11l_fd_.l11l111_fd_()
    for f in items:
        l1ll111_fd_(name=f.get(l11111_fd_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ࢟")), url=f.get(l11111_fd_ (u"ࠪࡹࡷࡲࠧࢠ"),l11111_fd_ (u"ࠫࠬࢡ")), mode=l11111_fd_ (u"ࠬ࡭ࡥࡵࡎ࡬ࡲࡰࡹࠧࢢ"), l1l11_fd_=f.get(l11111_fd_ (u"࠭ࡩ࡮ࡩࠪࢣ"),l11111_fd_ (u"ࠧࠨࢤ")), infoLabels=f, isFolder=False, IsPlayable=True,l1llll1_fd_=len(items))
    xbmcplugin.setContent(l1l1l11_fd_, l11111_fd_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨࢥ"))
elif mode[0] ==l11111_fd_ (u"ࠩࡪࡩࡹࡒࡩ࡯࡭ࡶࠫࢦ"):
    l1l1l1l_fd_(ex_link)
else:
    xbmcplugin.setResolvedUrl(l1l1l11_fd_, False, xbmcgui.ListItem(path=l11111_fd_ (u"ࠪࠫࢧ")))
xbmcplugin.endOfDirectory(l1l1l11_fd_)
