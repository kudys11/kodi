# -*- coding: utf-8 -*-
import sys
l1l11111_pbs_ = sys.version_info [0] == 2
l1ll11111_pbs_ = 2048
l11ll111_pbs_ = 7
def l1l111_pbs_ (keyedStringLiteral):
	global l11l1l111_pbs_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l11111_pbs_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1ll11111_pbs_ - (charIndex + stringNr) % l11ll111_pbs_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1ll11111_pbs_ - (charIndex + stringNr) % l11ll111_pbs_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os,json,base64
import cookielib
from urlparse import urlparse,urljoin
l1l1ll1111_pbs_ = 15
l1l11lll111_pbs_=l1l111_pbs_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠻࠴࠱࠼࡚ࠢ࡭ࡳ࠼࠴࠼ࠢࡻ࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠻࠷࠮࠱࠰࠶࠵࠻࠹࠮࠲࠲࠳ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫ৵")
try:
    from xbmc import translatePath
    from xbmcaddon import Addon
    l1ll1l1111_pbs_    = translatePath(Addon().getAddonInfo(l1l111_pbs_ (u"ࠩࡳࡶࡴ࡬ࡩ࡭ࡧࠪ৶"))).decode(l1l111_pbs_ (u"ࠪࡹࡹ࡬࠭࠹ࠩ৷"))
    l1lll11l111_pbs_=os.path.join(l1ll1l1111_pbs_,l1l111_pbs_ (u"ࠫࡨࡵ࡯࡬࡫ࡨࠫ৸"))
except:
    l1lll11l111_pbs_=l1l111_pbs_ (u"ࡷ࠭ࡣࡰࡱ࡮࡭ࡪ࠭৹")
    l1ll1l1111_pbs_ = os.getcwd()
l1ll11ll111_pbs_ = l1l111_pbs_ (u"࠭ࠧ৺")
class l1l1ll1l111_pbs_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
def l11111l111_pbs_(url,data=None):
    l1lllll111_pbs_ = cookielib.LWPCookieJar()
    if data:
        opener = urllib2.build_opener(l1l1ll1l111_pbs_, urllib2.HTTPCookieProcessor(l1lllll111_pbs_))
    else:
        opener = urllib2.build_opener( urllib2.HTTPCookieProcessor(l1lllll111_pbs_))
    opener.addheaders = [(l1l111_pbs_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ৻"), l1l11lll111_pbs_),(l1l111_pbs_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫৼ"),l1l111_pbs_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ৽"))]
    try:
        response = opener.open(url,data,l1l1ll1111_pbs_)
        result= response.read()
        response.close()
    except:
        result=l1l111_pbs_ (u"ࠪࠫ৾")
    return result
def l111ll1111_pbs_(l1l11ll111_pbs_):
    if isinstance(l1l11ll111_pbs_, unicode):
        l1l11ll111_pbs_ = l1l11ll111_pbs_.encode(l1l111_pbs_ (u"ࠫࡺࡺࡦ࠮࠺ࠪ৿"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠬࠬ࡬ࡵ࠽ࡥࡶ࠴ࠬࡧࡵ࠽ࠪ਀"),l1l111_pbs_ (u"࠭ࠠࠨਁ"))
    s=l1l111_pbs_ (u"ࠧࡋ࡫ࡑࡧ࡟ࡉࡳ࠸ࠩਂ")
    l1l11ll111_pbs_ = re.sub(s.decode(l1l111_pbs_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨਃ")),l1l111_pbs_ (u"ࠩࠪ਄"),l1l11ll111_pbs_)
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠪࡠࡳ࠭ਅ"),l1l111_pbs_ (u"ࠫࠬਆ")).replace(l1l111_pbs_ (u"ࠬࡢࡲࠨਇ"),l1l111_pbs_ (u"࠭ࠧਈ"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠧࠧࡰࡥࡷࡵࡁࠧਉ"),l1l111_pbs_ (u"ࠨࠩਊ"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠩࠩࡵࡺࡵࡴ࠼ࠩ਋"),l1l111_pbs_ (u"ࠪࠦࠬ਌")).replace(l1l111_pbs_ (u"ࠫࠫࡧ࡭ࡱ࠽ࡴࡹࡴࡺ࠻ࠨ਍"),l1l111_pbs_ (u"ࠬࠨࠧ਎"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"࠭ࠦࡰࡣࡦࡹࡹ࡫࠻ࠨਏ"),l1l111_pbs_ (u"ࠧࣴࠩਐ")).replace(l1l111_pbs_ (u"ࠨࠨࡒࡥࡨࡻࡴࡦ࠽ࠪ਑"),l1l111_pbs_ (u"ࠩࣖࠫ਒"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠪࠪࡦࡳࡰ࠼ࡱࡤࡧࡺࡺࡥ࠼ࠩਓ"),l1l111_pbs_ (u"ࠫࣸ࠭ਔ")).replace(l1l111_pbs_ (u"ࠬࠬࡡ࡮ࡲ࠾ࡓࡦࡩࡵࡵࡧ࠾ࠫਕ"),l1l111_pbs_ (u"࣓࠭ࠨਖ"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠧࠧࡣࡰࡴࡀ࠭ਗ"),l1l111_pbs_ (u"ࠨࠨࠪਘ"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠩ࡟ࡹ࠵࠷࠰࠶ࠩਙ"),l1l111_pbs_ (u"ࠪउࠬਚ")).replace(l1l111_pbs_ (u"ࠫࡡࡻ࠰࠲࠲࠷ࠫਛ"),l1l111_pbs_ (u"ࠬऊࠧਜ"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"࠭࡜ࡶ࠲࠴࠴࠼࠭ਝ"),l1l111_pbs_ (u"ࠧईࠩਞ")).replace(l1l111_pbs_ (u"ࠨ࡞ࡸ࠴࠶࠶࠶ࠨਟ"),l1l111_pbs_ (u"ࠩउࠫਠ"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠪࡠࡺ࠶࠱࠲࠻ࠪਡ"),l1l111_pbs_ (u"ࠫञ࠭ਢ")).replace(l1l111_pbs_ (u"ࠬࡢࡵ࠱࠳࠴࠼ࠬਣ"),l1l111_pbs_ (u"࠭घࠨਤ"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠧ࡝ࡷ࠳࠵࠹࠸ࠧਥ"),l1l111_pbs_ (u"ࠨॄࠪਦ")).replace(l1l111_pbs_ (u"ࠩ࡟ࡹ࠵࠷࠴࠲ࠩਧ"),l1l111_pbs_ (u"ࠪॅࠬਨ"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠫࡡࡻ࠰࠲࠶࠷ࠫ਩"),l1l111_pbs_ (u"ࠬॊࠧਪ")).replace(l1l111_pbs_ (u"࠭࡜ࡶ࠲࠴࠸࠹࠭ਫ"),l1l111_pbs_ (u"ࠧॄࠩਬ"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠨ࡞ࡸ࠴࠵࡬࠳ࠨਭ"),l1l111_pbs_ (u"ࣶࠩࠫਮ")).replace(l1l111_pbs_ (u"ࠪࡠࡺ࠶࠰ࡥ࠵ࠪਯ"),l1l111_pbs_ (u"ࠫࣘ࠭ਰ"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠬࡢࡵ࠱࠳࠸ࡦࠬ਱"),l1l111_pbs_ (u"࠭ज़ࠨਲ")).replace(l1l111_pbs_ (u"ࠧ࡝ࡷ࠳࠵࠺ࡧࠧਲ਼"),l1l111_pbs_ (u"ࠨड़ࠪ਴"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠩ࡟ࡹ࠵࠷࠷ࡢࠩਵ"),l1l111_pbs_ (u"ࠪॾࠬਸ਼")).replace(l1l111_pbs_ (u"ࠫࡡࡻ࠰࠲࠹࠼ࠫ਷"),l1l111_pbs_ (u"ࠬॿࠧਸ"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"࠭࡜ࡶ࠲࠴࠻ࡨ࠭ਹ"),l1l111_pbs_ (u"ࠧॽࠩ਺")).replace(l1l111_pbs_ (u"ࠨ࡞ࡸ࠴࠶࠽ࡢࠨ਻"),l1l111_pbs_ (u"ࠩॾ਼ࠫ"))
    return l1l11ll111_pbs_
class l1ll1l11111_pbs_:
    @staticmethod
    def l1lllll1111_pbs_(url=l1l111_pbs_ (u"ࠪࠫ਽")):
        url = l1l111_pbs_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡲࡥࡷ࠳ࡵࡲࡨ࠱ࡶ࡬ࡴࡽࡳ࠮ࡲࡤ࡫ࡪ࠵࠰࠰ࡁࡪࡩࡳࡸࡥ࠾ࠨࡷ࡭ࡹࡲࡥ࠾ࠨࡦࡥࡱࡲࡳࡪࡩࡱࡁࠫࡧ࡬ࡱࡪࡤࡦࡪࡺࡩࡤࡣ࡯ࡰࡾࡃࡴࡳࡷࡨࠫਾ")
        content = l11111l111_pbs_(url)
        out=[]
        a = json.loads(content)
        return a[l1l111_pbs_ (u"ࠬ࡭ࡥ࡯ࡴࡨࡷࠬਿ")][1:]
    @staticmethod
    def l1llll11111_pbs_(l1lll1ll111_pbs_=l1l111_pbs_ (u"࠭ࡳࡤ࡫ࡨࡲࡨ࡫࡟ࡢࡰࡧࡣࡳࡧࡴࡶࡴࡨࠫੀ"),l11l11111_pbs_=1,l111111111_pbs_=l1l111_pbs_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭ੁ")):
        l11l11111_pbs_ = int(l11l11111_pbs_)
        url = l1l111_pbs_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡶࡢࡴ࠰ࡲࡶ࡬࠵ࡳࡩࡱࡺࡷ࠲ࡶࡡࡨࡧ࠲ࡿࢂ࠵࠿ࡨࡧࡱࡶࡪࡃࡻࡾࠨࡷ࡭ࡹࡲࡥ࠾ࠨࡦࡥࡱࡲࡳࡪࡩࡱࡁࠫࡧ࡬ࡱࡪࡤࡦࡪࡺࡩࡤࡣ࡯ࡰࡾࡃࡻࡾࠩੂ").format(l11l11111_pbs_,l1lll1ll111_pbs_,l111111111_pbs_)
        html = l11111l111_pbs_(url)
        res = json.loads(html)
        l1lll11111_pbs_ = res.get(l1l111_pbs_ (u"ࠩࡵࡩࡸࡻ࡬ࡵࡵࠪ੃"),{})
        l111l11111_pbs_ = int(l1lll11111_pbs_.get(l1l111_pbs_ (u"ࠪࡴࡦ࡭ࡥࡏࡷࡰࡦࡪࡸࠧ੄")))
        l1ll1lll111_pbs_ = int(l1lll11111_pbs_.get(l1l111_pbs_ (u"ࠫࡹࡵࡴࡢ࡮ࡕࡩࡸࡻ࡬ࡵࡵࠪ੅")))
        l1l1l1l1111_pbs_ = int(l1lll11111_pbs_.get(l1l111_pbs_ (u"ࠬࡺ࡯ࡵࡣ࡯ࡔࡦ࡭ࡥࡴࠩ੆")))
        content = l1lll11111_pbs_.get(l1l111_pbs_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧੇ"),[])
        out=[]
        for l1ll1ll111_pbs_ in content:
            out.append({
                l1l111_pbs_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ੈ"):l1ll1ll111_pbs_.get(l1l111_pbs_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ੉"),l1l111_pbs_ (u"ࠩࠪ੊")),
                l1l111_pbs_ (u"ࠪ࡭ࡲ࡭ࠧੋ"):l1ll1ll111_pbs_.get(l1l111_pbs_ (u"ࠫ࡮ࡳࡡࡨࡧࠪੌ"),l1l111_pbs_ (u"੍ࠬ࠭")),
                l1l111_pbs_ (u"࠭ࡰ࡭ࡱࡷࠫ੎"):l1ll1ll111_pbs_.get(l1l111_pbs_ (u"ࠧࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠬ੏"),l1l111_pbs_ (u"ࠨࠩ੐")),
                l1l111_pbs_ (u"ࠩ࡫ࡶࡪ࡬ࠧੑ"):l1ll1ll111_pbs_.get(l1l111_pbs_ (u"ࠪࡹࡷࡲࠧ੒")),
                })
        l1ll1ll1111_pbs_ = int(l11l11111_pbs_)+1 if l1l1l1l1111_pbs_>l11l11111_pbs_ else -1
        l1ll11l111_pbs_ = int(l11l11111_pbs_)-1 if l111l11111_pbs_>0 else -1
        return out,(l1ll11l111_pbs_,l1ll1ll1111_pbs_)
    @staticmethod
    def l1llll111111_pbs_(l1ll11ll1111_pbs_=l1l111_pbs_ (u"ࠫࡸࡩࡩࡦࡰࡦࡩࡤࡧ࡮ࡥࡡࡱࡥࡹࡻࡲࡦࠩ੓"),l11l11111_pbs_=1,l111111111_pbs_=l1l111_pbs_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫ੔")):
        l11l11111_pbs_ = int(l11l11111_pbs_)
        url = l1l111_pbs_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡴࡧࡹ࠮ࡰࡴࡪ࠳ࡸ࡮࡯ࡸࡵ࠰ࡴࡦ࡭ࡥ࠰ࡽࢀ࠳ࡄ࡭ࡥ࡯ࡴࡨࡁࠫࡺࡩࡵ࡮ࡨࡁࢀࢃࠦࡤࡣ࡯ࡰࡸ࡯ࡧ࡯࠿ࠩࡥࡱࡶࡨࡢࡤࡨࡸ࡮ࡩࡡ࡭࡮ࡼࡁࢀࢃࠧ੕").format(l11l11111_pbs_,l1ll11ll1111_pbs_,l111111111_pbs_)
        html = l11111l111_pbs_(url)
        res = json.loads(html)
        l1lll11111_pbs_ = res.get(l1l111_pbs_ (u"ࠧࡳࡧࡶࡹࡱࡺࡳࠨ੖"),{})
        l111l11111_pbs_ = int(l1lll11111_pbs_.get(l1l111_pbs_ (u"ࠨࡲࡤ࡫ࡪࡔࡵ࡮ࡤࡨࡶࠬ੗")))
        l1ll1lll111_pbs_ = int(l1lll11111_pbs_.get(l1l111_pbs_ (u"ࠩࡷࡳࡹࡧ࡬ࡓࡧࡶࡹࡱࡺࡳࠨ੘")))
        l1l1l1l1111_pbs_ = int(l1lll11111_pbs_.get(l1l111_pbs_ (u"ࠪࡸࡴࡺࡡ࡭ࡒࡤ࡫ࡪࡹࠧਖ਼")))
        content = l1lll11111_pbs_.get(l1l111_pbs_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬਗ਼"),[])
        out=[]
        for l1ll1ll111_pbs_ in content:
            out.append({
                l1l111_pbs_ (u"ࠬࡺࡩࡵ࡮ࡨࠫਜ਼"):l1ll1ll111_pbs_.get(l1l111_pbs_ (u"࠭ࡴࡪࡶ࡯ࡩࠬੜ"),l1l111_pbs_ (u"ࠧࠨ੝")),
                l1l111_pbs_ (u"ࠨ࡫ࡰ࡫ࠬਫ਼"):l1ll1ll111_pbs_.get(l1l111_pbs_ (u"ࠩ࡬ࡱࡦ࡭ࡥࠨ੟"),l1l111_pbs_ (u"ࠪࠫ੠")),
                l1l111_pbs_ (u"ࠫࡵࡲ࡯ࡵࠩ੡"):l1ll1ll111_pbs_.get(l1l111_pbs_ (u"ࠬࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠪ੢"),l1l111_pbs_ (u"࠭ࠧ੣")),
                l1l111_pbs_ (u"ࠧࡩࡴࡨࡪࠬ੤"):l1ll1ll111_pbs_.get(l1l111_pbs_ (u"ࠨࡷࡵࡰࠬ੥")),
                })
        l1ll1ll1111_pbs_ = int(l11l11111_pbs_)+1 if l1l1l1l1111_pbs_>l11l11111_pbs_ else -1
        l1ll11l111_pbs_ = int(l11l11111_pbs_)-1 if l111l11111_pbs_>0 else -1
        return out,(l1ll11l111_pbs_,l1ll1ll1111_pbs_)
    @staticmethod
    def l1l1lll111_pbs_(url=l1l111_pbs_ (u"ࠩ࠲ࡷ࡭ࡵࡷ࠰ࡰࡲࡺࡦ࠵ࠧ੦"),l11l11111_pbs_=l1l111_pbs_ (u"ࠪࡒࡴࡴࡥࠨ੧")):
        l1111ll111_pbs_ = l1l111_pbs_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࠭੨")+l1l111_pbs_ (u"ࠬࡽࡷࡸ࠰ࡳࡦࡸ࠴࡯ࡳࡩ࠲ࡿࢂ࠵ࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠰ࠩ੩").format(url).replace(l1l111_pbs_ (u"࠭࠯࠰ࠩ੪"),l1l111_pbs_ (u"ࠧ࠰ࠩ੫"))
        try:
            l1111ll111_pbs_ += l1l111_pbs_ (u"ࠨࡵࡨࡥࡸࡵ࡮࠰ࡽࢀ࠳ࠬ੬").format(int(l11l11111_pbs_))
        except:
            pass
        l1lll111111_pbs_ = l11111l111_pbs_(l1111ll111_pbs_)
        l1l1ll111_pbs_ = re.compile(l1l111_pbs_ (u"ࠩ࠿ࡳࡵࡺࡩࡰࡰ࠱࠯ࡄࡼࡡ࡭ࡷࡨࡁࠧ࠮࡜ࡥ࠭ࠬࠦࡠࡢࡳ࡝ࡰࡠ࠮ࡃ࠮࠮ࠬࡁࠬࡀ࠴ࡵࡰࡵ࡫ࡲࡲࡃ࠭੭"),re.DOTALL).findall(l1lll111111_pbs_)
        out=[]
        l1lll1l111_pbs_=[]
        l1111_pbs_ = re.compile(l1l111_pbs_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡺ࡮ࡪࡥࡰ࠯ࡶࡹࡲࡳࡡࡳࡻࠥ࠲࠰ࡅࡤࡢࡶࡤ࠱ࡸࡸࡣࡴࡧࡷࡁࠧ࠮࠮ࠬࡁࠬࠦ࠳࠱࠿ࡤ࡮ࡤࡷࡸࡃࠢࡱࡱࡳࡳࡻ࡫ࡲࡠࡡࡷ࡭ࡹࡲࡥࠣࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠫࡀࠫࠥࡠࡸ࠰࠾ࠩ࠰࠮ࡃ࠮ࡂ࠮ࠬࡁࡦࡰࡦࡹࡳ࠾ࠤࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠢ࠿ࠪ࠱࠯ࡄ࠯࠼࠯࠭ࡂࡧࡱࡧࡳࡴ࠿ࠥࡴࡴࡶ࡯ࡷࡧࡵࡣࡤࡳࡥࡵࡣ࠰ࡨࡦࡺࡡࠣࡀࠫ࠲࠰ࡅࠩ࠽ࠩ੮"),re.DOTALL).findall(l1lll111111_pbs_)
        for l11ll1l111_pbs_,l1l11ll1111_pbs_,title,l1l1111111_pbs_,l1ll111111_pbs_ in l1111_pbs_:
            title = title.strip()
            l11ll1l111_pbs_ = l11ll1l111_pbs_.split(l1l111_pbs_ (u"ࠫ࠱࠭੯"))
            l11ll11111_pbs_ = l1l111_pbs_ (u"ࠬࠫࡳ࠯࡬ࡳ࡫ࠬੰ") % (l11ll1l111_pbs_[2].split(l1l111_pbs_ (u"࠭࠮࡫ࡲࡪࠫੱ"),1)[0].strip())
            fanart = l1l111_pbs_ (u"ࠧࠦࡵ࠱࡮ࡵ࡭ࠧੲ") % (l11ll1l111_pbs_[len(l11ll1l111_pbs_)-1].split(l1l111_pbs_ (u"ࠨ࠰࡭ࡴ࡬࠭ੳ"),1)[0].strip())
            l1ll111111_pbs_ = [m.strip() for m in l1ll111111_pbs_.split(l1l111_pbs_ (u"ࠩࡿࠫੴ"))]
            if len(l1ll111111_pbs_)==2:
                title = l1l111_pbs_ (u"ࠪ࡟ࡇࡣࡻࡾ࡝࠲ࡆࡢࠦࡻࡾࠩੵ").format(l1ll111111_pbs_[0],title)
                code = l1ll111111_pbs_[1]
            else:
                code = l1ll111111_pbs_[0]
            out.append( {l1l111_pbs_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ੶"): l111ll1111_pbs_(title).strip(), l1l111_pbs_ (u"ࠬ࡮ࡲࡦࡨࠪ੷"):l1l11ll1111_pbs_, l1l111_pbs_ (u"࠭ࡰ࡭ࡱࡷࠫ੸"):l111ll1111_pbs_(l1l1111111_pbs_).strip(), l1l111_pbs_ (u"ࠧࡵࡪࡸࡱࡧ࠭੹"):l11ll11111_pbs_,l1l111_pbs_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨ੺"):fanart,l1l111_pbs_ (u"ࠩࡦࡳࡩ࡫ࠧ੻"):code})
        for l111lll111_pbs_,name in l1l1ll111_pbs_:
            title = l1l111_pbs_ (u"ࠪࠤࠬ੼").join([n.strip() for n in name.split(l1l111_pbs_ (u"ࠫࡡࡴࠧ੽"))])
            l1lll1l111_pbs_.append( {l1l111_pbs_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ੾"): title.strip(), l1l111_pbs_ (u"࠭ࡰࡢࡩࡨࠫ੿"):int(l111lll111_pbs_), l1l111_pbs_ (u"ࠧ࡭࡫ࡱ࡯ࠬ઀"):url})
        if not out:
            out=[{l1l111_pbs_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧઁ"):l1l111_pbs_ (u"࡚ࠩࡩ⠞ࡸࡥࠡࡵࡲࡶࡷࡿࠬࠡࡤࡸࡸࠥࡺࡨࡦࡴࡨࠤࡦࡸࡥࠡࡰࡲࠤࡪࡶࡩࡴࡱࡧࡩࡸࠦࡡࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠢࡩࡳࡷࠦࡴࡩ࡫ࡶࠤࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࠮ࠡࡒ࡯ࡩࡦࡹࡥࠡࡶࡵࡽࠥࡧ࡮ࡰࡶ࡫ࡩࡷࠦࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯࠰ࠪં"),l1l111_pbs_ (u"ࠪࡹࡷࡲࠧઃ"):l1l111_pbs_ (u"ࠫࠬ઄")}]
        return out,l1lll1l111_pbs_
    @staticmethod
    def l1l1lll1111_pbs_(l1l1ll11l111_pbs_,res=l1l111_pbs_ (u"ࠬ࠷ࠧઅ")):
        l11lll1111_pbs_={}
        try:
            l1ll1l1l1111_pbs_ = urljoin(l1l111_pbs_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡴࡧࡹ࠮ࡰࡴࡪ࠳ࠬઆ"),l1l1ll11l111_pbs_)
            content = l11111l111_pbs_(l1ll1l1l1111_pbs_)
            l1l1llll1111_pbs_ = re.compile(l1l111_pbs_ (u"ࠧ࡝ࡵ࠮࡭ࡩࡢࡳࠫ࠼࡟ࡷ࠯ࡡ࡜ࠨࠤࡠࠬ࠳࠱࠿ࠪ࡝࡟ࠫࠧࡣࠧઇ")).search(content)
            if l1l1llll1111_pbs_:
                l1l1llll1111_pbs_ = l1l1llll1111_pbs_.group(1)
                l1ll1lll1111_pbs_ = l1l111_pbs_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡳࡰࡦࡿࡥࡳ࠰ࡳࡦࡸ࠴࡯ࡳࡩ࠲ࡴࡴࡸࡴࡢ࡮ࡳࡰࡦࡿࡥࡳ࠱ࡾࢁ࠴ࡅࡵࡪࡦࡀࠫઈ").format(l1l1llll1111_pbs_)
                l1ll11lll111_pbs_ = l11111l111_pbs_(l1ll1lll1111_pbs_)
                l1l1ll1l1111_pbs_ = re.compile(l1l111_pbs_ (u"ࠤࡓࡆࡘ࠴ࡶࡪࡦࡨࡳࡉࡧࡴࡢࠢࡀ࠲࠰ࡅࡲࡦࡥࡲࡱࡲ࡫࡮ࡥࡧࡧࡣࡪࡴࡣࡰࡦ࡬ࡲ࡬࠴ࠫࡀࠩࡸࡶࡱ࠭࠮ࠬࡁࠪࠬ࠳࠱࠿ࠪࠩ࠱࠯ࡄ࠭ࡣ࡭ࡱࡶࡩࡩࡥࡣࡢࡲࡷ࡭ࡴࡴࡳࡠࡷࡵࡰࠬ࠴ࠫࡀࠩࠫ࠲࠰ࡅࠩࠨࠤઉ"), re.DOTALL).search(l1ll11lll111_pbs_)
                if l1l1ll1l1111_pbs_ is not None:
                    l1l1ll111111_pbs_,l1ll11111111_pbs_ = l1l1ll1l1111_pbs_.groups()
                    if l1ll11111111_pbs_:
                        l11lll1111_pbs_[l1l111_pbs_ (u"ࠪࡷࡺࡨࠧઊ")]=l1ll11111111_pbs_
                    l1ll111l1111_pbs_=l1l111_pbs_ (u"ࠫࢀࢃ࠿ࡧࡱࡵࡱࡦࡺ࠽࡫ࡵࡲࡲࠬઋ").format(l1l1ll111111_pbs_)
                    l1ll11lll111_pbs_ = l11111l111_pbs_(l1ll111l1111_pbs_)
                    url = json.loads(l1ll11lll111_pbs_)[l1l111_pbs_ (u"ࠬࡻࡲ࡭ࠩઌ")]
                    if not url:
                        l1ll111l1111_pbs_=l1l111_pbs_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡣࡧࡱࡩ࡫࡯ࡴࡴ࡯ࡤ࠲ࡦࡶࡰࡴࡲࡲࡸ࠳ࡩ࡯࡮࠱ࡸࡃࡵࡻࡲ࡭࠿ࠪઍ")+l1ll1ll1l111_pbs_(l1l111_pbs_ (u"ࠧࡼࡿࡂࡪࡴࡸ࡭ࡢࡶࡀ࡮ࡸࡵ࡮ࠨ઎").format(l1l1ll111111_pbs_))
                        l1ll11lll111_pbs_ = l11111l111_pbs_(l1ll111l1111_pbs_)
                        url = json.loads(l1ll11lll111_pbs_).get(l1l111_pbs_ (u"ࠨࡷࡵࡰࠬએ"),None)
                    if url:
                        if l1l111_pbs_ (u"ࠩࡰࡴ࠹ࡀࠧઐ") in url:
                            url = l1l111_pbs_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡫ࡦ࠴ࡶࡪࡦࡨࡳ࠳ࡩࡤ࡯࠰ࡳࡦࡸ࠴࡯ࡳࡩ࠲ࠩࡸ࠭ઑ") % url.split(l1l111_pbs_ (u"ࠫࡲࡶ࠴࠻ࠩ઒"),1)[1]
                        elif (l1l111_pbs_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫઓ") in url) and res >= l1l111_pbs_ (u"࠭࠱ࠨઔ"):
                            url = url.replace(l1l111_pbs_ (u"ࠧ࠹࠲࠳࡯ࠬક"),l1l111_pbs_ (u"ࠨ࠴࠸࠴࠵ࡱࠧખ"))
                            if (l1l111_pbs_ (u"ࠩ࡫ࡨ࠲࠷࠰࠹࠲ࡳࠫગ") in url) and res == l1l111_pbs_ (u"ࠪ࠶ࠬઘ"):
                                url = url.split(l1l111_pbs_ (u"ࠫ࠲࡮࡬ࡴ࠯ࠪઙ"),1)[0]
                                url = url+l1l111_pbs_ (u"ࠬ࠳ࡨ࡭ࡵ࠰࠺࠺࠶࠰࡬࠰ࡰ࠷ࡺ࠾ࠧચ")
                        l11lll1111_pbs_[l1l111_pbs_ (u"࠭ࡵࡳ࡮ࠪછ")] = url
        except:
            pass
        return l11lll1111_pbs_
    @staticmethod
    def l11ll1ll111_pbs_(l1ll11111111_pbs_):
        l1ll111ll111_pbs_ = l1l111_pbs_ (u"ࠢࠣજ")
        l1ll11lll111_pbs_ = l11111l111_pbs_(l1ll11111111_pbs_)
        l1ll1111l111_pbs_ = l1l111_pbs_ (u"ࠨࠩઝ")
        if l1ll11lll111_pbs_ != l1l111_pbs_ (u"ࠤࠥઞ"):
            try:
                l1ll1ll11111_pbs_ = re.compile(l1l111_pbs_ (u"ࠪࡀࡵࠦࡢࡦࡩ࡬ࡲࡂࠨࠨ࠯࠭ࡂ࠭ࠧࠦࡥ࡯ࡦࡀࠦ࠭࠴ࠫࡀࠫࠥࡂ࠭࠴ࠫࡀࠫ࠿࠳ࡵࡄࠧટ"),re.DOTALL).findall(l1ll11lll111_pbs_)
                for idx, (l1ll1l111111_pbs_, l1ll11l1l111_pbs_, l1ll1l11l111_pbs_) in list(enumerate(l1ll1ll11111_pbs_, start=1)):
                    l1ll1l111111_pbs_ = l1ll1l111111_pbs_.replace(l1l111_pbs_ (u"ࠫ࠳࠭ઠ"),l1l111_pbs_ (u"ࠬ࠲ࠧડ"))
                    l1ll11l1l111_pbs_   = l1ll11l1l111_pbs_.replace(l1l111_pbs_ (u"࠭࠮ࠨઢ"),l1l111_pbs_ (u"ࠧ࠭ࠩણ")).split(l1l111_pbs_ (u"ࠨࠤࠪત"),1)[0]
                    l1ll1l11l111_pbs_ = l1ll1l11l111_pbs_.replace(l1l111_pbs_ (u"ࠩ࠿ࡦࡷ࠵࠾ࠨથ"),l1l111_pbs_ (u"ࠪࡠࡳ࠭દ")).strip()
                    l1ll1l11l111_pbs_ = l1ll1l11l111_pbs_.replace(l1l111_pbs_ (u"ࠫࠫࡧࡰࡰࡵ࠾ࠫધ"), l1l111_pbs_ (u"ࠧ࠭ࠢન")).replace(l1l111_pbs_ (u"࠭࡜࡯࡞ࡱࠫ઩"),l1l111_pbs_ (u"ࠧ࡝ࡰࠪપ"))
                    l1ll1111l111_pbs_ += l1l111_pbs_ (u"ࠨࠧࡶࡠࡳࠫࡳࠡ࠯࠰ࡂࠥࠫࡳ࡝ࡰࠨࡷࡡࡴ࡜࡯ࠩફ") % (idx, l1ll1l111111_pbs_, l1ll11l1l111_pbs_, l1ll1l11l111_pbs_)
            except: l1ll1111l111_pbs_ = l1l111_pbs_ (u"ࠤࠥબ")
        if l1ll1111l111_pbs_:
            try:
                l1ll111ll111_pbs_ = os.path.join(l1ll1l1111_pbs_, l1l111_pbs_ (u"ࠪࡷࡺࡨࡴࡪࡶ࡯ࡩࡸ࠴ࡳࡳࡶࠪભ"))
                l1ll1l1ll111_pbs_ = open(l1ll111ll111_pbs_, l1l111_pbs_ (u"ࠫࡼ࠱ࠧમ"))
                l1ll1l1ll111_pbs_.write(l1ll1111l111_pbs_)
                l1ll1l1ll111_pbs_.close()
            except: pass
        return l1ll111ll111_pbs_
def l1ll1ll1l111_pbs_(src=l1l111_pbs_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡰ࠯ࡲ࡯ࠫય")):
    l1ll11l11111_pbs_=l1l111_pbs_ (u"࠭ࡁࡃࡅࡇࡉࡋࡍࡈࡊࡌࡎࡐࡒࡔࡏࡑࡓࡕࡗ࡙࡛ࡖࡘ࡚࡜࡞ࡦࡨࡣࡥࡧࡩ࡫࡭࡯ࡪ࡬࡮ࡰࡲࡴࡶࡱࡳࡵࡷࡹࡻࡽࡸࡺࡼ࠳࠵࠷࠹࠴࠶࠸࠺࠼࠾࠱࠯ࠨર")
    src=src[::-1]
    pos = 0
    l1l1lllll111_pbs_ =l1l111_pbs_ (u"ࠧࠨ઱")
    while (pos + 3 <= len(src)-1):
        l1l1lll1l111_pbs_ = ord(src[pos]);pos +=1;
        l1l1lll11111_pbs_ = ord(src[pos]);pos +=1;
        l1l1ll1ll111_pbs_ = ord(src[pos]);pos +=1
        l1l1lllll111_pbs_ += l1ll11l11111_pbs_[l1l1lll1l111_pbs_>>2] + l1ll11l11111_pbs_[((l1l1lll1l111_pbs_ << 4) + (l1l1lll11111_pbs_ >> 4) & 0x3f)]
        l1l1lllll111_pbs_ += l1ll11l11111_pbs_[((l1l1lll11111_pbs_ << 2) + (l1l1ll1ll111_pbs_ >> 6) & 0x3f)] +  l1ll11l11111_pbs_[(l1l1ll1ll111_pbs_ & 0x3f)]
    if pos < len(src):
        l1l1lll1l111_pbs_ = ord(src[pos]);pos +=1;
        l1l1lllll111_pbs_ += l1ll11l11111_pbs_[l1l1lll1l111_pbs_>>2]
        if pos < len(src):
            l1l1lll11111_pbs_ =  ord(src[pos])
            l1l1lllll111_pbs_ += l1ll11l11111_pbs_[ (l1l1lll1l111_pbs_ << 4) + (l1l1lll11111_pbs_ >> 4) & 0x3f]
            l1l1lllll111_pbs_ += l1ll11l11111_pbs_[ (l1l1lll11111_pbs_ << 2 & 0x3f)] +l1l111_pbs_ (u"ࠨ࠿ࠪલ")
        else:
            l1l1lllll111_pbs_ += l1ll11l11111_pbs_[l1l1lll1l111_pbs_ << 4 & 0x3f] +l1l111_pbs_ (u"ࠩࡀࡁࠬળ")
    return l1l1lllll111_pbs_
