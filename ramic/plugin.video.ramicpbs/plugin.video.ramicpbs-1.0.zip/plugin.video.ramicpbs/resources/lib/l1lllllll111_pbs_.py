# -*- coding: utf-8 -*-
import sys
l1l11111_pbs_ = sys.version_info [0] == 2
l1ll11111_pbs_ = 2048
l11ll111_pbs_ = 7
def l1l111_pbs_ (keyedStringLiteral):
	global l11l1l111_pbs_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l11111_pbs_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1ll11111_pbs_ - (charIndex + stringNr) % l11ll111_pbs_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1ll11111_pbs_ - (charIndex + stringNr) % l11ll111_pbs_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import xbmcaddon
l1l111l1111_pbs_       = xbmcaddon.Addon().getAddonInfo(l1l111_pbs_ (u"ࠪࡲࡦࡳࡥࠨ઴"))
class l1ll1llll111_pbs_():
    def __init__(self,name=l1l111l1111_pbs_):
        try:
            import StorageServer
        except:
            import storageserverdummy as StorageServer
        self.cache = StorageServer.StorageServer(name)
    def l1l1l1lll111_pbs_(self,t):
        return t.encode(l1l111_pbs_ (u"ࠫࡺࡺࡦ࠮࠺ࠪવ")) if isinstance(t,unicode) else t
    def l111l1ll111_pbs_(self):
        return self.cache.get(l1l111_pbs_ (u"ࠬ࡮ࡩࡴࡶࡲࡶࡾ࠭શ")).split(l1l111_pbs_ (u"࠭࠻ࠨષ"))
    def l1111111111_pbs_(self,entry):
        l1l1l1ll1111_pbs_ = self.l111l1ll111_pbs_()
        if l1l1l1ll1111_pbs_ == [l1l111_pbs_ (u"ࠧࠨસ")]:
            l1l1l1ll1111_pbs_ = []
        l1l1l1ll1111_pbs_.insert(0, self.l1l1l1lll111_pbs_(entry))
        try:
            self.cache.set(l1l111_pbs_ (u"ࠨࡪ࡬ࡷࡹࡵࡲࡺࠩહ"),l1l111_pbs_ (u"ࡷࠪ࠿ࠬ઺").join(l1l1l1ll1111_pbs_[:50]))
        except:
            pass
    def l11l1l1l111_pbs_(self,entry):
        l1l1l1ll1111_pbs_ = self.l111l1ll111_pbs_()
        if l1l1l1ll1111_pbs_:
            try:
                self.cache.set(l1l111_pbs_ (u"ࠪ࡬࡮ࡹࡴࡰࡴࡼࠫ઻"),l1l111_pbs_ (u"ࠫࡀ઼࠭").join(l1l1l1ll1111_pbs_[:50]))
            except:
                pass
        else:
            self.l11llll1111_pbs_()
    def l11llll1111_pbs_(self):
        self.cache.delete(l1l111_pbs_ (u"ࠬ࡮ࡩࡴࡶࡲࡶࡾ࠭ઽ"))
