# coding: UTF-8
import sys
l1l11111_pbs_ = sys.version_info [0] == 2
l1ll11111_pbs_ = 2048
l11ll111_pbs_ = 7
def l1l111_pbs_ (keyedStringLiteral):
	global l11l1l111_pbs_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l11111_pbs_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1ll11111_pbs_ - (charIndex + stringNr) % l11ll111_pbs_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1ll11111_pbs_ - (charIndex + stringNr) % l11ll111_pbs_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import threading
import xbmc,xbmcgui
import time,re,os
try: from shutil import rmtree
except: rmtree = False
def ll111_pbs_(l111ll111_pbs_,l11l111_pbs_=[l1l111_pbs_ (u"ࠬ࠭࠹")]):
    debug=1
def l1111111_pbs_(name=l1l111_pbs_ (u"࠭ࠧ࠺")):
    debug=1
def l1lll111_pbs_(top):
    debug=1
def l111l1111_pbs_():
    l111ll111_pbs_ = os.path.join(xbmc.translatePath(l1l111_pbs_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩࡃ")),l1l111_pbs_ (u"ࠩࡤࡨࡩࡵ࡮ࡴࠩࡄ"))
    xbmc.log(l111ll111_pbs_)
    if ll111_pbs_(l111ll111_pbs_,[l1l111_pbs_ (u"ࠪࡥࡱ࡯ࡥ࡯ࡹ࡬ࡾࡦࡸࡤࠨࡅ"),l1l111_pbs_ (u"ࠫࡪࡾࡴࡦࡰࡧࡩࡷ࠴ࡡ࡭࡫ࡨࡲࠬࡆ"),l1l111_pbs_ (u"ࠬࡺࡡࡳࡩࡨࡸ࡮ࡴ࠱࠱࠺࠳ࡴࡼ࡯ࡺࡢࡴࡧࠫࡇ"),l1l111_pbs_ (u"࠭࡫ࡰࡦ࡬ࡹࡱࡺࡩ࡮ࡣࡷࡩࠬࡈ"),l1l111_pbs_ (u"ࠧ࡮ࡷ࡯ࡸ࡮ࡳࡥࡥ࡫ࡤࡱࡦࡹࡴࡦࡴࠪࡉ"),l1l111_pbs_ (u"ࠨࡲࡵࡳ࡬ࡸࡡ࡮࠰ࡦ࡬ࡪࡸࡲࡺࡶࡹࠫࡊ")])>0:
        l1111111_pbs_(l1l111_pbs_ (u"ࠩࡺ࡭ࡿࡧࡲࡥࠩࡋ"))
        return
    l1l111111_pbs_ = os.path.join(xbmc.translatePath(l1l111_pbs_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡵࡴࡧࡵࡨࡦࡺࡡࠨࡌ")),l1l111_pbs_ (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨࡍ"),l1l111_pbs_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡥࡪࡵ࡮࠯ࡰࡲࡼ࠳࠻ࠧࡎ"),l1l111_pbs_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬࡏ"))
    if os.path.exists(l1l111111_pbs_):
        data = open(l1l111111_pbs_,l1l111_pbs_ (u"ࠧࡳࠩࡐ")).read()
        data= re.sub(l1l111_pbs_ (u"ࠨ࡞࡞࠲࠯ࡢ࡝ࠨࡑ"),l1l111_pbs_ (u"ࠩࠪࡒ"),data)
        if len(re.compile(l1l111_pbs_ (u"ࠪࡂ࠳࠰ࠨࡱࡱ࡯ࡷࡰࡧ࡜ࡴࠬࡷࡠࡸ࠰ࡶࠪࠩࡓ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1111111_pbs_(l1l111_pbs_ (u"ࠫࡸࡱࡩ࡯࠰ࡤࡩࡴࡴ࠮࡯ࡱࡻ࠲࠺࠭ࡔ"))
            return
        if len(re.compile(l1l111_pbs_ (u"ࠬࡄ࠮ࠫࠪࡧࡥࡷࡳ࡯ࡸࡣ࡟ࡷ࠯ࡺ࡜ࡴࠬࡹ࠭ࠬࡕ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1111111_pbs_(l1l111_pbs_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡦ࡫࡯࡯࠰ࡱࡳࡽ࠴࠵ࠨࡖ"))
            return
    l1l111111_pbs_ = os.path.join(xbmc.translatePath(l1l111_pbs_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡹࡸ࡫ࡲࡥࡣࡷࡥࠬࡗ")),l1l111_pbs_ (u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬࡘ"),l1l111_pbs_ (u"ࠩࡶ࡯࡮ࡴ࠮ࡹࡱࡱࡪࡱࡻࡥ࡯ࡥࡨ࡙ࠫ"),l1l111_pbs_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭࡚ࠩ"))
    if os.path.exists(l1l111111_pbs_):
        data = open(l1l111111_pbs_,l1l111_pbs_ (u"ࠫࡷ࡛࠭")).read()
        data= re.sub(l1l111_pbs_ (u"ࠬࡢ࡛࠯ࠬ࡟ࡡࠬ࡜"),l1l111_pbs_ (u"࠭ࠧ࡝"),data)
        if len(re.compile(l1l111_pbs_ (u"ࠧ࠿࠰࠭ࠬࡵࡵ࡬ࡴ࡭ࡤࡠࡸ࠰ࡴ࡝ࡵ࠭ࡺ࠮࠭࡞"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1111111_pbs_(l1l111_pbs_ (u"ࠨࡵ࡮࡭ࡳ࠴ࡸࡰࡰࡩࡰࡺ࡫࡮ࡤࡧࠪ࡟"))
            return
    l11111_pbs_ = xbmc.translatePath(l1l111_pbs_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴࡮࡯࡮ࡧࠪࡠ"))
    for f in os.listdir(l11111_pbs_):
        if f.startswith(l1l111_pbs_ (u"ࠪࡑࡒࡋࡓࠨࡡ")):
            l1111111_pbs_()
            return
try:
    debug=1
except: pass
