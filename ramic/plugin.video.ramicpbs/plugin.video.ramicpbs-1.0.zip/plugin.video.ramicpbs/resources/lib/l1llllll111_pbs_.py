# -*- coding: utf-8 -*-
import sys
l1l11111_pbs_ = sys.version_info [0] == 2
l1ll11111_pbs_ = 2048
l11ll111_pbs_ = 7
def l1l111_pbs_ (keyedStringLiteral):
	global l11l1l111_pbs_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l11111_pbs_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1ll11111_pbs_ - (charIndex + stringNr) % l11ll111_pbs_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1ll11111_pbs_ - (charIndex + stringNr) % l11ll111_pbs_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os,json,base64
import cookielib
from urlparse import urlparse,urljoin
l1l1ll1111_pbs_ = 15
l1l11lll111_pbs_=l1l111_pbs_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠸࠱࠵ࡀࠦࡗࡪࡰ࠹࠸ࡀࠦࡸ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠸࠴࠲࠵࠴࠳࠲࠸࠶࠲࠶࠶࠰ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨࡣ")
try:
    from xbmc import translatePath
    from xbmcaddon import Addon
    l1ll1l1111_pbs_    = translatePath(Addon().getAddonInfo(l1l111_pbs_ (u"࠭ࡰࡳࡱࡩ࡭ࡱ࡫ࠧࡤ"))).decode(l1l111_pbs_ (u"ࠧࡶࡶࡩ࠱࠽࠭ࡥ"))
    l1lll11l111_pbs_=os.path.join(l1ll1l1111_pbs_,l1l111_pbs_ (u"ࠨࡥࡲࡳࡰ࡯ࡥࠨࡦ"))
except:
    l1lll11l111_pbs_=l1l111_pbs_ (u"ࡴࠪࡧࡴࡵ࡫ࡪࡧࠪࡧ")
l1ll11ll111_pbs_ = l1l111_pbs_ (u"ࠪࠫࡨ")
class l1l1ll1l111_pbs_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
def l11111l111_pbs_(url,data=None):
    l1lllll111_pbs_ = cookielib.LWPCookieJar()
    if data:
        opener = urllib2.build_opener(l1l1ll1l111_pbs_, urllib2.HTTPCookieProcessor(l1lllll111_pbs_))
    else:
        opener = urllib2.build_opener( urllib2.HTTPCookieProcessor(l1lllll111_pbs_))
    opener.addheaders = [(l1l111_pbs_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨࡩ"), l1l11lll111_pbs_),(l1l111_pbs_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨࡪ"),l1l111_pbs_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ࡫"))]
    try:
        response = opener.open(url,data,l1l1ll1111_pbs_)
        result= response.read()
        response.close()
    except:
        result=l1l111_pbs_ (u"ࠧࠨ࡬")
    return result
def l111ll1111_pbs_(l1l11ll111_pbs_):
    if isinstance(l1l11ll111_pbs_, unicode):
        l1l11ll111_pbs_ = l1l11ll111_pbs_.encode(l1l111_pbs_ (u"ࠨࡷࡷࡪ࠲࠾ࠧ࡭"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠩࠩࡰࡹࡁࡢࡳ࠱ࠩ࡫ࡹࡁࠧ࡮"),l1l111_pbs_ (u"ࠪࠤࠬ࡯"))
    s=l1l111_pbs_ (u"ࠫࡏ࡯ࡎࡤ࡜ࡆࡷ࠼࠭ࡰ")
    l1l11ll111_pbs_ = re.sub(s.decode(l1l111_pbs_ (u"ࠬࡨࡡࡴࡧ࠹࠸ࠬࡱ")),l1l111_pbs_ (u"࠭ࠧࡲ"),l1l11ll111_pbs_)
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠧ࡝ࡰࠪࡳ"),l1l111_pbs_ (u"ࠨࠩࡴ")).replace(l1l111_pbs_ (u"ࠩ࡟ࡶࠬࡵ"),l1l111_pbs_ (u"ࠪࠫࡶ"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠫࠫࡴࡢࡴࡲ࠾ࠫࡷ"),l1l111_pbs_ (u"ࠬ࠭ࡸ"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"࠭ࠦࡲࡷࡲࡸࡀ࠭ࡹ"),l1l111_pbs_ (u"ࠧࠣࠩࡺ")).replace(l1l111_pbs_ (u"ࠨࠨࡤࡱࡵࡁࡱࡶࡱࡷ࠿ࠬࡻ"),l1l111_pbs_ (u"ࠩࠥࠫࡼ"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠪࠪࡴࡧࡣࡶࡶࡨ࠿ࠬࡽ"),l1l111_pbs_ (u"ࠫࣸ࠭ࡾ")).replace(l1l111_pbs_ (u"ࠬࠬࡏࡢࡥࡸࡸࡪࡁࠧࡿ"),l1l111_pbs_ (u"࣓࠭ࠨࢀ"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠧࠧࡣࡰࡴࡀࡵࡡࡤࡷࡷࡩࡀ࠭ࢁ"),l1l111_pbs_ (u"ࠨࣵࠪࢂ")).replace(l1l111_pbs_ (u"ࠩࠩࡥࡲࡶ࠻ࡐࡣࡦࡹࡹ࡫࠻ࠨࢃ"),l1l111_pbs_ (u"ࠪࣗࠬࢄ"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠫࠫࡧ࡭ࡱ࠽ࠪࢅ"),l1l111_pbs_ (u"ࠬࠬࠧࢆ"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"࠭࡜ࡶ࠲࠴࠴࠺࠭ࢇ"),l1l111_pbs_ (u"ࠧआࠩ࢈")).replace(l1l111_pbs_ (u"ࠨ࡞ࡸ࠴࠶࠶࠴ࠨࢉ"),l1l111_pbs_ (u"ࠩइࠫࢊ"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠪࡠࡺ࠶࠱࠱࠹ࠪࢋ"),l1l111_pbs_ (u"ࠫऌ࠭ࢌ")).replace(l1l111_pbs_ (u"ࠬࡢࡵ࠱࠳࠳࠺ࠬࢍ"),l1l111_pbs_ (u"࠭आࠨࢎ"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠧ࡝ࡷ࠳࠵࠶࠿ࠧ࢏"),l1l111_pbs_ (u"ࠨछࠪ࢐")).replace(l1l111_pbs_ (u"ࠩ࡟ࡹ࠵࠷࠱࠹ࠩ࢑"),l1l111_pbs_ (u"ࠪजࠬ࢒"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠫࡡࡻ࠰࠲࠶࠵ࠫ࢓"),l1l111_pbs_ (u"ࠬैࠧ࢔")).replace(l1l111_pbs_ (u"࠭࡜ࡶ࠲࠴࠸࠶࠭࢕"),l1l111_pbs_ (u"ࠧूࠩ࢖"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠨ࡞ࡸ࠴࠶࠺࠴ࠨࢗ"),l1l111_pbs_ (u"ࠩेࠫ࢘")).replace(l1l111_pbs_ (u"ࠪࡠࡺ࠶࠱࠵࠶࢙ࠪ"),l1l111_pbs_ (u"ࠫै࢚࠭"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠬࡢࡵ࠱࠲ࡩ࠷࢛ࠬ"),l1l111_pbs_ (u"࠭ࣳࠨ࢜")).replace(l1l111_pbs_ (u"ࠧ࡝ࡷ࠳࠴ࡩ࠹ࠧ࢝"),l1l111_pbs_ (u"ࠨࣕࠪ࢞"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠩ࡟ࡹ࠵࠷࠵ࡣࠩ࢟"),l1l111_pbs_ (u"ࠪय़ࠬࢠ")).replace(l1l111_pbs_ (u"ࠫࡡࡻ࠰࠲࠷ࡤࠫࢡ"),l1l111_pbs_ (u"ࠬॠࠧࢢ"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"࠭࡜ࡶ࠲࠴࠻ࡦ࠭ࢣ"),l1l111_pbs_ (u"ࠧॻࠩࢤ")).replace(l1l111_pbs_ (u"ࠨ࡞ࡸ࠴࠶࠽࠹ࠨࢥ"),l1l111_pbs_ (u"ࠩॼࠫࢦ"))
    l1l11ll111_pbs_ = l1l11ll111_pbs_.replace(l1l111_pbs_ (u"ࠪࡠࡺ࠶࠱࠸ࡥࠪࢧ"),l1l111_pbs_ (u"ࠫঁ࠭ࢨ")).replace(l1l111_pbs_ (u"ࠬࡢࡵ࠱࠳࠺ࡦࠬࢩ"),l1l111_pbs_ (u"࠭ॻࠨࢪ"))
    return l1l11ll111_pbs_
class l1ll1l11111_pbs_:
    @staticmethod
    def l1lllll1111_pbs_(url=l1l111_pbs_ (u"ࠧࠨࢫ")):
        url = l1l111_pbs_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡶࡢࡴ࠰ࡲࡶ࡬࠵ࡳࡩࡱࡺࡷ࠲ࡶࡡࡨࡧ࠲࠴࠴ࡅࡧࡦࡰࡵࡩࡂࠬࡴࡪࡶ࡯ࡩࡂࠬࡣࡢ࡮࡯ࡷ࡮࡭࡮࠾ࠨࡤࡰࡵ࡮ࡡࡣࡧࡷ࡭ࡨࡧ࡬࡭ࡻࡀࡸࡷࡻࡥࠨࢬ")
        content = l11111l111_pbs_(url)
        out=[]
        a = json.loads(content)
        return a[l1l111_pbs_ (u"ࠩࡪࡩࡳࡸࡥࡴࠩࢭ")][1:]
    @staticmethod
    def l1llll11111_pbs_(l1lll1ll111_pbs_=l1l111_pbs_ (u"ࠪࡷࡨ࡯ࡥ࡯ࡥࡨࡣࡦࡴࡤࡠࡰࡤࡸࡺࡸࡥࠨࢮ"),l11l11111_pbs_=1,l111111111_pbs_=l1l111_pbs_ (u"ࠫࡹࡸࡵࡦࠩࢯ")):
        url = l1l111_pbs_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡳࡦࡸ࠴࡯ࡳࡩ࠲ࡷ࡭ࡵࡷࡴ࠯ࡳࡥ࡬࡫࠯ࡼࡿ࠲ࡃ࡬࡫࡮ࡳࡧࡀࡿࢂࠬࡴࡪࡶ࡯ࡩࡂࠬࡣࡢ࡮࡯ࡷ࡮࡭࡮࠾ࠨࡤࡰࡵ࡮ࡡࡣࡧࡷ࡭ࡨࡧ࡬࡭ࡻࡀࡿࢂ࠭ࢰ").format(l11l11111_pbs_,l1lll1ll111_pbs_,l111111111_pbs_)
        html = l11111l111_pbs_(url)
        res = json.loads(html)
        l1lll11111_pbs_ = res.get(l1l111_pbs_ (u"࠭ࡲࡦࡵࡸࡰࡹࡹࠧࢱ"),{})
        l111l11111_pbs_ = l1lll11111_pbs_.get(l1l111_pbs_ (u"ࠧࡱࡣࡪࡩࡓࡻ࡭ࡣࡧࡵࠫࢲ"))
        l1ll1lll111_pbs_ = l1lll11111_pbs_.get(l1l111_pbs_ (u"ࠨࡶࡲࡸࡦࡲࡒࡦࡵࡸࡰࡹࡹࠧࢳ"))
        l1l1l1l1111_pbs_ = l1lll11111_pbs_.get(l1l111_pbs_ (u"ࠩࡷࡳࡹࡧ࡬ࡑࡣࡪࡩࡸ࠭ࢴ"))
        content = l1lll11111_pbs_.get(l1l111_pbs_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࠫࢵ"),[])
        l1ll1ll1111_pbs_ = l11l11111_pbs_+1 if l1l1l1l1111_pbs_>l11l11111_pbs_ else False
        l11llll111_pbs_ = l11l11111_pbs_-1 if l111l11111_pbs_>0 else False
        return content,(l11llll111_pbs_,l1ll1ll1111_pbs_)
    @staticmethod
    def l1l1lll111_pbs_(url=l1l111_pbs_ (u"ࠫ࠴ࡹࡨࡰࡹ࠲ࡲࡴࡼࡡ࠰ࠩࢶ"),l11l11111_pbs_=None):
        l1111ll111_pbs_ = l1l111_pbs_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࠧࢷ")+l1l111_pbs_ (u"࠭ࡷࡸࡹ࠱ࡴࡧࡹ࠮ࡰࡴࡪ࠳ࢀࢃ࠯ࡦࡲ࡬ࡷࡴࡪࡥࡴ࠱ࠪࢸ").format(url).replace(l1l111_pbs_ (u"ࠧ࠰࠱ࠪࢹ"),l1l111_pbs_ (u"ࠨ࠱ࠪࢺ"))
        if l11l11111_pbs_:
            l1111ll111_pbs_ += l1l111_pbs_ (u"ࠩࡶࡩࡦࡹ࡯࡯࠱ࡾࢁ࠴࠭ࢻ").format(l11l11111_pbs_)
        l1lll111111_pbs_ = l11111l111_pbs_(l1111ll111_pbs_)
        l1l1ll111_pbs_ = re.compile(l1l111_pbs_ (u"ࠪࡀࡴࡶࡴࡪࡱࡱ࠲࠰ࡅࡶࡢ࡮ࡸࡩࡂࠨࠨ࡝ࡦ࠮࠭ࠧࡡ࡜ࡴ࡞ࡱࡡ࠯ࡄࠨ࠯࠭ࡂ࠭ࡁ࠵࡯ࡱࡶ࡬ࡳࡳࡄࠧࢼ"),re.DOTALL).findall(l1lll111111_pbs_)
        out=[]
        l1lll1l111_pbs_=[]
        l1111_pbs_ = re.compile(l1l111_pbs_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡻ࡯ࡤࡦࡱ࠰ࡷࡺࡳ࡭ࡢࡴࡼࠦ࠳࠱࠿ࡥࡣࡷࡥ࠲ࡹࡲࡤࡵࡨࡸࡂࠨࠨ࠯࠭ࡂ࠭ࠧ࠴ࠫࡀࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡲࡴࡴࡼࡥࡳࡡࡢࡸ࡮ࡺ࡬ࡦࠤࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠬࡁࠬࠦࡡࡹࠪ࠿ࠪ࠱࠯ࡄ࠯࠼࠯࠭ࡂࡧࡱࡧࡳࡴ࠿ࠥࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠣࡀࠫ࠲࠰ࡅࠩ࠽࠰࠮ࡃࡨࡲࡡࡴࡵࡀࠦࡵࡵࡰࡰࡸࡨࡶࡤࡥ࡭ࡦࡶࡤ࠱ࡩࡧࡴࡢࠤࡁࠬ࠳࠱࠿ࠪ࠾ࠪࢽ"),re.DOTALL).findall(l1lll111111_pbs_)
        for l11ll1l111_pbs_,l1l11ll1111_pbs_,title,l1l1111111_pbs_,l1ll111111_pbs_ in l1111_pbs_:
            title = title.strip()
            l11ll1l111_pbs_ = l11ll1l111_pbs_.split(l1l111_pbs_ (u"ࠬ࠲ࠧࢾ"))
            l11ll11111_pbs_ = l1l111_pbs_ (u"࠭ࠥࡴ࠰࡭ࡴ࡬࠭ࢿ") % (l11ll1l111_pbs_[2].split(l1l111_pbs_ (u"ࠧ࠯࡬ࡳ࡫ࠬࣀ"),1)[0].strip())
            fanart = l1l111_pbs_ (u"ࠨࠧࡶ࠲࡯ࡶࡧࠨࣁ") % (l11ll1l111_pbs_[len(l11ll1l111_pbs_)-1].split(l1l111_pbs_ (u"ࠩ࠱࡮ࡵ࡭ࠧࣂ"),1)[0].strip())
            l1ll111111_pbs_ = [m.strip() for m in l1ll111111_pbs_.split(l1l111_pbs_ (u"ࠪࢀࠬࣃ"))]
            if len(l1ll111111_pbs_)==2:
                title = l1l111_pbs_ (u"ࠫࡠࡈ࡝ࡼࡿ࡞࠳ࡇࡣࠠࡼࡿࠪࣄ").format(l1ll111111_pbs_[0],title)
                code = l1ll111111_pbs_[1]
            else:
                code = l1ll111111_pbs_[0]
            out.append( {l1l111_pbs_ (u"ࠬࡺࡩࡵ࡮ࡨࠫࣅ"): title.strip(), l1l111_pbs_ (u"࠭ࡵࡳ࡮ࠪࣆ"):l1l11ll1111_pbs_, l1l111_pbs_ (u"ࠧࡱ࡮ࡲࡸࠬࣇ"):l1l1111111_pbs_.strip(), l1l111_pbs_ (u"ࠨࡶ࡫ࡹࡲࡨࠧࣈ"):l11ll11111_pbs_,l1l111_pbs_ (u"ࠩࡩࡥࡳࡧࡲࡵࠩࣉ"):fanart,l1l111_pbs_ (u"ࠪࡧࡴࡪࡥࠨ࣊"):code})
        for l111lll111_pbs_,name in l1l1ll111_pbs_:
            title = l1l111_pbs_ (u"ࠫࠥ࠭࣋").join([n.strip() for n in name.split(l1l111_pbs_ (u"ࠬࡢ࡮ࠨ࣌"))])
            l1lll1l111_pbs_.append( {l1l111_pbs_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ࣍"): title.strip(), l1l111_pbs_ (u"ࠧࡱࡣࡪࡩࠬ࣎"):int(l111lll111_pbs_), l1l111_pbs_ (u"ࠨࡷࡵࡰ࣏ࠬ"):url})
        return out,l1lll1l111_pbs_
    @staticmethod
    def l1llll1l111_pbs_(url=l1l111_pbs_ (u"࣐ࠩࠪ")):
        if not url:
            url = l1l111_pbs_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡱࡤࡶ࠲ࡴࡸࡧ࠰ࡵ࡫ࡳࡼࡹ࠭ࡱࡣࡪࡩ࠴࠶࠯ࡀࡩࡨࡲࡷ࡫࠽ࠧࡶ࡬ࡸࡱ࡫࠽ࠧࡥࡤࡰࡱࡹࡩࡨࡰࡀࠪࡦࡲࡰࡩࡣࡥࡩࡹ࡯ࡣࡢ࡮࡯ࡽࡂࡺࡲࡶࡧ࣑ࠪ")
        content = l11111l111_pbs_(url)
        out=[]
        l1111l1111_pbs_ = re.compile(l1l111_pbs_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶ࠰࡫ࡷ࡯ࡤࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࣒ࠧ"),re.DOTALL).findall(content)
        for show in l1111l1111_pbs_:
            l11l1l1111_pbs_ = re.findall(l1l111_pbs_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠱ࡶࡩࡷ࡯ࡡ࡭ࡧ࠲࠲࠯࠯ࠢ࠿࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀ࣓ࠫࠥࠫ"),show)
            if l11l1l1111_pbs_:
                l11l1ll111_pbs_ = l11l1l1111_pbs_[0][1]
                l11l1ll111_pbs_ = urljoin(l1l111_pbs_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡪࡣࡱࡩ࡭ࡱࡳ࠮ࡱ࡮࠲ࠫࣔ"),l11l1ll111_pbs_) if not l11l1ll111_pbs_.startswith(l1l111_pbs_ (u"ࠧࡩࡶࡷࡴࠬࣕ")) else l11l1ll111_pbs_
                title = l11l1l1111_pbs_[0][0].replace(l1l111_pbs_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡡ࡭ࡧ࠲ࠫࣖ"),l1l111_pbs_ (u"ࠩࠪࣗ")).replace(l1l111_pbs_ (u"ࠪ࠱ࠬࣘ"),l1l111_pbs_ (u"ࠫࠥ࠭ࣙ")).replace(l1l111_pbs_ (u"ࠬ࠵ࠧࣚ"),l1l111_pbs_ (u"࠭ࠧࣛ")).title()
                out.append({l1l111_pbs_ (u"ࠧࡩࡴࡨࡪࠬࣜ"):l11l1l1111_pbs_[0][0],l1l111_pbs_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࣝ"):title,l1l111_pbs_ (u"ࠩ࡬ࡱ࡬࠭ࣞ"):l11l1ll111_pbs_})
        idx = content.find(l1l111_pbs_ (u"ࠪ࡬࠸ࡄࡓࡦࡴ࡬ࡥࡱ࡫࠼࠰ࡪ࠶ࡂࠬࣟ"))
        if idx:
            l1ll1111111_pbs_ = re.compile(l1l111_pbs_ (u"ࠫࡁࡻ࡬࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ࣠"),re.DOTALL).search(content[idx:-1])
            l1ll1111111_pbs_ = l1ll1111111_pbs_.group(1) if l1ll1111111_pbs_ else l1l111_pbs_ (u"ࠬ࠭࣡")
            l1ll1111111_pbs_ = re.sub(l1l111_pbs_ (u"ࡸࠢ࠽ࠣ࠰࠱࠭࠴ࡼ࡝ࡵࡿࡠࡳ࠯ࠪࡀ࠯࠰ࡂࠧ࣢"), l1l111_pbs_ (u"ࣣࠢࠣ"), l1ll1111111_pbs_)
            l1l1llll111_pbs_ = re.compile(l1l111_pbs_ (u"ࠨ࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠱ࡶࡩࡷ࡯ࡡ࡭ࡧ࠲࠲࠯ࡅࠩࠣࡀࠫ࡟ࡣࡄ࡝ࠫࠫ࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠬࣤ")).findall(l1ll1111111_pbs_)
            for href,title in l1l1llll111_pbs_:
                out.append({l1l111_pbs_ (u"ࠩ࡫ࡶࡪ࡬ࠧࣥ"):href,l1l111_pbs_ (u"ࠪࡸ࡮ࡺ࡬ࡦࣦࠩ"):title})
        return out
    @staticmethod
    def l1l1l11l111_pbs_(url=l1l111_pbs_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࡵࡨࡶ࡮ࡧ࡬ࡦ࠱ࡧࡩࡹ࡫࡫ࡵࡻࡺ࠳ࠬࣧ")):
        if not url:
            url = l1l111_pbs_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡰࡢࡰࡨ࡬ࡰࡲ࠴ࡰ࡭࠱ࠪࣨ")
        if url.startswith(l1l111_pbs_ (u"࠭࠯࠰ࣩࠩ")):
            url = l1l111_pbs_ (u"ࠧࡩࡶࡷࡴࠬ࣪")+url
        if url.startswith(l1l111_pbs_ (u"ࠨ࠱ࠪ࣫")):
            url = urljoin(l1l111_pbs_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡭ࡦࡴ࡬ࡩ࡭࡯࠱ࡴࡱ࠵ࠧ࣬"),url)
        url += l1l111_pbs_ (u"ࠪ࠳࣭ࠬ") if not url.endswith(l1l111_pbs_ (u"ࠫ࠴࣮࠭")) else l1l111_pbs_ (u"࣯ࠬ࠭")
        content = l11111l111_pbs_(url)
        out=[]
        l1111_pbs_ = re.compile(l1l111_pbs_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡮ࡵࡧࡱࡸ࠲࡭ࡲࡪࡦࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࣰࠩ"),re.DOTALL).findall(content)
        for l1l11l1111_pbs_ in l1111_pbs_:
            l1ll1l1l111_pbs_ = re.findall(l1l111_pbs_ (u"ࠧࡴࡧࡽࡳࡳࡢࡳࠫࠪ࡟ࡨ࠰࠯ࣱࠧ"),l1l11l1111_pbs_,re.I)
            l1ll1l1l111_pbs_ = l1ll1l1l111_pbs_[0] if l1ll1l1l111_pbs_ else l1l111_pbs_ (u"ࠨࣲࠩ")
            l1l1l111111_pbs_ = re.findall(l1l111_pbs_ (u"ࠩࡒࡨࡨ࡯࡮ࡦ࡭࡟ࡷ࠯࠮࡜ࡥ࠭ࠬࠫࣳ"),l1l11l1111_pbs_,re.I)
            l1l1l111111_pbs_ = l1l1l111111_pbs_[0] if l1l1l111111_pbs_ else l1l111_pbs_ (u"ࠪࠫࣴ")
            href = re.compile(l1l111_pbs_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨࡴ࡫ࡱ࡫ࡱ࡫ࡰࡢࡩࡨ࠲ࡵ࡮ࡰ࡝ࡁ࡬ࡨࡂࡢࡤࠬࠫࠥࠫࣵ")).findall(l1l11l1111_pbs_)
            l11l1ll111_pbs_ = re.findall(l1l111_pbs_ (u"ࠬࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࣶ"),l1l11l1111_pbs_)
            if href and l1ll1l1l111_pbs_ and l1l1l111111_pbs_:
                l11l1ll111_pbs_ = urljoin(l1l111_pbs_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡪࡣࡱࡩ࡭ࡱࡳ࠮ࡱ࡮࠲ࠫࣷ"),l11l1ll111_pbs_[0]) if not l11l1ll111_pbs_[0].startswith(l1l111_pbs_ (u"ࠧࡩࡶࡷࡴࠬࣸ")) else l1l111_pbs_ (u"ࠨࣹࠩ")
                out.append({l1l111_pbs_ (u"ࠩ࡫ࡶࡪ࡬ࣺࠧ"):url+href[0],l1l111_pbs_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩࣻ"):l1l111_pbs_ (u"ࠫࡘ࡫ࡺࡰࡰࠣࠩࡸ࠲ࠠࡆࡲ࡬ࡾࡴࡪࠠࠦࡵࠪࣼ")%(l1ll1l1l111_pbs_,l1l1l111111_pbs_),l1l111_pbs_ (u"ࠬ࡯࡭ࡨࠩࣽ"):l11l1ll111_pbs_,
                l1l111_pbs_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭ࣾ"):int(l1ll1l1l111_pbs_),l1l111_pbs_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࠨࣿ"):int(l1l1l111111_pbs_)})
        return out
    @staticmethod
    def l1lll1l1111_pbs_(out):
        l1l1l1l111_pbs_={}
        l1l1ll111_pbs_ = [x.get(l1l111_pbs_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࠨऀ")) for x in out]
        for s in set(l1l1ll111_pbs_):
            l1l1l1l111_pbs_[l1l111_pbs_ (u"ࠩࡖࡩࡿࡵ࡮ࠡࠧ࠳࠶ࡩ࠭ँ")%s]=[out[i] for i, j in enumerate(l1l1ll111_pbs_) if j == s]
        return l1l1l1l111_pbs_
    @staticmethod
    def l1l1lll1111_pbs_(url):
        content = l11111l111_pbs_(url)
        l11lll1111_pbs_=l1l111_pbs_ (u"ࠪࠫं")
        l1llll1111_pbs_ = re.compile(l1l111_pbs_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠭࠴ࠪࡀࠫ࠿࠳࡮࡬ࡲࡢ࡯ࡨࡂࠬः"),re.DOTALL).findall(content)
        if l1llll1111_pbs_:
            src = re.compile(l1l111_pbs_ (u"ࠬࡹࡲࡤ࠿࡞ࡠࠬࠨ࡝ࠩ࠰࠭ࡃ࠮ࡡ࡜ࠨࠤࡠࠫऄ"),re.DOTALL).findall(l1llll1111_pbs_[0])
            l11lll1111_pbs_ = src[0] if src else l1l111_pbs_ (u"࠭ࠧअ")
        return l11lll1111_pbs_
class l1ll111l111_pbs_:
    @staticmethod
    def l1llll1l111_pbs_(url,l11l111111_pbs_=None):
        if l11l111111_pbs_:
            l11l111111_pbs_ = l1l111_pbs_ (u"ࠧࡴࡼࡸ࡯ࡦࡰ࠽ࠨआ")+l11l111111_pbs_.replace(l1l111_pbs_ (u"ࠨࠢࠪइ"),l1l111_pbs_ (u"ࠩ࠮ࠫई"))
            url= l1l111_pbs_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡣࡱࡻࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࡸࢀࡵ࡬ࡣ࡭ࠫउ")
        if not url:
            url = l1l111_pbs_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡲࡼ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭ऊ")
        elif url.startswith(l1l111_pbs_ (u"ࠬ࠵ࠧऋ")):
            url = urljoin(l1l111_pbs_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡦࡴࡾࡦࡪ࡮ࡰ࠲ࡵࡲ࠯ࠨऌ"),url)
        content = l11111l111_pbs_(url,l11l111111_pbs_)
        ids = [(a.start(), a.end()) for a in re.finditer(l1l111_pbs_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡼࡩࡥࡧࡲࡣ࡮ࡴࡦࡰࠤࡁࠫऍ"), content,re.IGNORECASE)]
        ids.append( (-1,-1) )
        out=[]
        for i in range(len(ids[:-1])):
            l11111111_pbs_ = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile(l1l111_pbs_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪऎ"),re.DOTALL).search(l11111111_pbs_)
            title = re.compile(l1l111_pbs_ (u"ࠩ࠿࡬࠶ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠲ࡀࠪए"),re.DOTALL).search(l11111111_pbs_)
            l11l1ll111_pbs_ = re.compile(l1l111_pbs_ (u"ࠪࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ऐ"),re.DOTALL).search(l11111111_pbs_)
            l1l1ll11111_pbs_ = re.findall(l1l111_pbs_ (u"ࠫࡑ࡫࡫ࡵࡱࡵ࠾ࡡࡹࠪ࠽ࡵࡳࡥࡳࠦࡳࡵࡻ࡯ࡩࡂࠨ࡛࡟ࡀࡠ࠮ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬऑ"),l11111111_pbs_)
            l1ll11l1111_pbs_ = re.findall(l1l111_pbs_ (u"ࠬࡊ࡯ࡥࡣࡱࡽ࠿ࡢࡳࠫ࠾ࡶࡴࡦࡴࠠࡴࡶࡼࡰࡪࡃࠢ࡜ࡠࡁࡡ࠯ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭ऒ"),l11111111_pbs_)
            l1l1l1ll111_pbs_ = re.findall(l1l111_pbs_ (u"࠭ࡇࡢࡶࡸࡲࡪࡱ࠺࡝ࡵ࠭ࡀࡸࡶࡡ࡯ࠢࡶࡸࡾࡲࡥ࠾ࠤ࡞ࡢࡃࡣࠪࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨओ"),l11111111_pbs_)
            l1l1ll11111_pbs_ = l1l1ll11111_pbs_[0] if l1l1ll11111_pbs_ else l1l111_pbs_ (u"ࠧࠨऔ")
            l1ll11l1111_pbs_ = l1ll11l1111_pbs_[0] if l1ll11l1111_pbs_ else l1l111_pbs_ (u"ࠨࠩक")
            l1l1l1ll111_pbs_ = l1l1l1ll111_pbs_[0] if l1l1l1ll111_pbs_ else l1l111_pbs_ (u"ࠩࠪख")
            code = l1l1ll11111_pbs_
            l1l1111111_pbs_ = l1l111_pbs_ (u"ࠥࡐࡪࡱࡴࡰࡴ࠽ࠤࠪࡹࠠ࡝ࡰࡇࡳࡩࡧ࡮ࡺ࠼ࠣࠩࡸࠦ࡜࡯ࡉࡤࡸࡺࡴࡥ࡬࠼ࠣࠩࡸࠦ࡜࡯ࠤग") %(l1l1ll11111_pbs_,l1ll11l1111_pbs_,l1l1l1ll111_pbs_)
            if href and title:
                l11l1ll111_pbs_ = urljoin(l1l111_pbs_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡲࡼ࡫࡯࡬࡮࠰ࡳࡰࠬघ"),l11l1ll111_pbs_.group(1)) if l11l1ll111_pbs_ else l1l111_pbs_ (u"ࠬ࠭ङ")
                title = title.group(1)
                year =  re.findall(l1l111_pbs_ (u"࠭࡜ࠩࠪ࡟ࡨࢀ࠺ࡽࠪ࡞ࠬࠫच"),title)
                l1ll1ll111_pbs_ = {l1l111_pbs_ (u"ࠧࡩࡴࡨࡪࠬछ")   : href.group(1),
                       l1l111_pbs_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧज")  : l111ll1111_pbs_(title),
                       l1l111_pbs_ (u"ࠩ࡬ࡱ࡬࠭झ")    : l11l1ll111_pbs_,
                       l1l111_pbs_ (u"ࠪࡴࡱࡵࡴࠨञ")   : l111ll1111_pbs_(l1l1111111_pbs_),
                       l1l111_pbs_ (u"ࠫࡾ࡫ࡡࡳࠩट")   : year[0] if year else l1l111_pbs_ (u"ࠬ࠭ठ"),
                       l1l111_pbs_ (u"࠭ࡣࡰࡦࡨࠫड")   : code,
                        }
                out.append(l1ll1ll111_pbs_)
        l1ll1ll1111_pbs_=False
        l1ll11l111_pbs_ = re.findall(l1l111_pbs_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡟ࡣࠨ࡝ࠫࠫࠥࡂࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡱࡩࡽࡺ࡟ࡴ࡫ࡷࡩࠧࡄࡐࡰࡲࡵࡾࡪࡪ࡮ࡪࡣ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡥࡃ࠭ढ"),content)
        l1ll11l111_pbs_ = l1ll11l111_pbs_[0] if l1ll11l111_pbs_ else False
        l1ll1ll1111_pbs_ = re.findall(l1l111_pbs_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬࡠࡤࠢ࡞ࠬࠬࠦࡃࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡲࡪࡾࡴࡠࡵ࡬ࡸࡪࠨ࠾ࡏࡣࡶࡸ࠳࠱ࡰ࡯ࡣ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡥࡃ࠭ण"),content)
        l1ll1ll1111_pbs_ = l1ll1ll1111_pbs_[0] if l1ll1ll1111_pbs_ else False
        return (out, (l1ll11l111_pbs_,l1ll1ll1111_pbs_))
    @staticmethod
    def l1l111l111_pbs_():
        content = l11111l111_pbs_(l1l111_pbs_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡰࡺࡩ࡭ࡱࡳ࠮ࡱ࡮࠲࡯ࡴࡴࡴࡢ࡭ࡷࠫत"))
        l111l1l111_pbs_=re.findall(l1l111_pbs_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠯࡬ࡣࡷࡥࡱࡵࡧ࠰࠰࠭࠭ࠧࠦࡣ࡭ࡣࡶࡷࡂࠨ࡮ࡢࡸࡢࡰ࡮ࡴ࡫ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬथ"),content)
        out=[]
        for href,name in l111l1l111_pbs_:
            out.append({l1l111_pbs_ (u"ࠫ࡭ࡸࡥࡧࠩद"):href,l1l111_pbs_ (u"ࠬࡺࡩࡵ࡮ࡨࠫध"):name})
        return out
    @staticmethod
    def l11l11l111_pbs_(url):
        url = urljoin(l1l111_pbs_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡦࡴࡾࡦࡪ࡮ࡰ࠲ࡵࡲ࠯ࠨन"),url)
        content = l11111l111_pbs_(url)
        l1l11ll1111_pbs_=l1l111_pbs_ (u"ࠧࠨऩ")
        l1l1l11111_pbs_=re.findall(l1l111_pbs_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠪ࠱࠮ࡄ࠯࠼࠰࡫ࡩࡶࡦࡳࡥ࠿ࠩप"),content,re.DOTALL|re.IGNORECASE)
        if l1l1l11111_pbs_:
            l1l11ll1111_pbs_ = re.findall(l1l111_pbs_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧफ"),l1l1l11111_pbs_[0],re.DOTALL|re.IGNORECASE)
            l1l11ll1111_pbs_ = l1l11ll1111_pbs_[0] if l1l11ll1111_pbs_ else l1l111_pbs_ (u"ࠪࠫब")
        return l1l11ll1111_pbs_
