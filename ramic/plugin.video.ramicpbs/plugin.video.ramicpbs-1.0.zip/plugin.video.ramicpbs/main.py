# -*- coding: utf-8 -*-
import sys
l1l11111_pbs_ = sys.version_info [0] == 2
l1ll11111_pbs_ = 2048
l11ll111_pbs_ = 7
def l1l111_pbs_ (keyedStringLiteral):
	global l11l1l111_pbs_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l11111_pbs_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1ll11111_pbs_ - (charIndex + stringNr) % l11ll111_pbs_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1ll11111_pbs_ - (charIndex + stringNr) % l11ll111_pbs_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urlparse,sys,urllib
params = dict(urlparse.parse_qsl(sys.argv[2].replace(l1l111_pbs_ (u"ࠫࡄ࠭ࠀ"),l1l111_pbs_ (u"ࠬ࠭ࠁ"))))
mode = params.get(l1l111_pbs_ (u"࠭࡭ࡰࡦࡨࠫࠂ"))
fname = params.get(l1l111_pbs_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫࠃ"))
ex_link = params.get(l1l111_pbs_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩࠄ"))
l11l11111_pbs_ = params.get(l1l111_pbs_ (u"ࠩࡳࡥ࡬࡫ࠧࠅ"))
import xbmcgui,xbmc
import time,os
l1lll1111_pbs_ = xbmcgui.Dialog()
import time,threading
try: from shutil import rmtree
except: rmtree = False
def ll111_pbs_(l111ll111_pbs_,l11l111_pbs_=[l1l111_pbs_ (u"ࠪࠫࠆ")]):
    debug=1
def l1111111_pbs_(name=l1l111_pbs_ (u"ࠫࠬࠇ")):
    debug=1
def l1lll111_pbs_(top):
    debug=1
def l11lll111_pbs_():
    l111ll111_pbs_ = os.path.join(xbmc.translatePath(l1l111_pbs_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭ࠏ")),l1l111_pbs_ (u"࠭ࡡࡥࡦࡲࡲࡸ࠭ࠐ"))
    xbmc.log(l111ll111_pbs_)
    if ll111_pbs_(l111ll111_pbs_,[l1l111_pbs_ (u"ࠧࡢ࡮࡬ࡩࡳࡽࡩࡻࡣࡵࡨࠬࠑ"),l1l111_pbs_ (u"ࠨࡧࡻࡸࡪࡴࡤࡦࡴ࠱ࡥࡱ࡯ࡥ࡯ࠩࠒ")])>0:
        l1111111_pbs_(l1l111_pbs_ (u"ࠩࡺ࡭ࡿࡧࡲࡥࠩࠓ"))
        return
    l1l111111_pbs_ = os.path.join(xbmc.translatePath(l1l111_pbs_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡵࡴࡧࡵࡨࡦࡺࡡࠨࠔ")),l1l111_pbs_ (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨࠕ"),l1l111_pbs_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡥࡪࡵ࡮࠯ࡰࡲࡼ࠳࠻ࠧࠖ"),l1l111_pbs_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬࠗ"))
    if os.path.exists(l1l111111_pbs_):
        data = open(l1l111111_pbs_,l1l111_pbs_ (u"ࠧࡳࠩ࠘")).read()
        data= re.sub(l1l111_pbs_ (u"ࠨ࡞࡞࠲࠯ࡢ࡝ࠨ࠙"),l1l111_pbs_ (u"ࠩࠪࠚ"),data)
        if len(re.compile(l1l111_pbs_ (u"ࠪࡂ࠳࠰ࠨࡱࡱ࡯ࡷࡰࡧ࡜ࡴࠬࡷࡠࡸ࠰ࡶࠪࠩࠛ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1111111_pbs_(l1l111_pbs_ (u"ࠫࡸࡱࡩ࡯࠰ࡤࡩࡴࡴ࠮࡯ࡱࡻ࠲࠺࠭ࠜ"))
            return
        if len(re.compile(l1l111_pbs_ (u"ࠬࡄ࠮ࠫࠪࡧࡥࡷࡳ࡯ࡸࡣ࡟ࡷ࠯ࡺ࡜ࡴࠬࡹ࠭ࠬࠝ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1111111_pbs_(l1l111_pbs_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡦ࡫࡯࡯࠰ࡱࡳࡽ࠴࠵ࠨࠞ"))
            return
    l1l111111_pbs_ = os.path.join(xbmc.translatePath(l1l111_pbs_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡹࡸ࡫ࡲࡥࡣࡷࡥࠬࠟ")),l1l111_pbs_ (u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬࠠ"),l1l111_pbs_ (u"ࠩࡶ࡯࡮ࡴ࠮ࡹࡱࡱࡪࡱࡻࡥ࡯ࡥࡨࠫࠡ"),l1l111_pbs_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩࠢ"))
    if os.path.exists(l1l111111_pbs_):
        data = open(l1l111111_pbs_,l1l111_pbs_ (u"ࠫࡷ࠭ࠣ")).read()
        data= re.sub(l1l111_pbs_ (u"ࠬࡢ࡛࠯ࠬ࡟ࡡࠬࠤ"),l1l111_pbs_ (u"࠭ࠧࠥ"),data)
        if len(re.compile(l1l111_pbs_ (u"ࠧ࠿࠰࠭ࠬࡵࡵ࡬ࡴ࡭ࡤࡠࡸ࠰ࡴ࡝ࡵ࠭ࡺ࠮࠭ࠦ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1111111_pbs_(l1l111_pbs_ (u"ࠨࡵ࡮࡭ࡳ࠴ࡸࡰࡰࡩࡰࡺ࡫࡮ࡤࡧࠪࠧ"))
            return
    l111ll111_pbs_ = os.path.join(xbmc.translatePath(l1l111_pbs_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡻࡳࡦࡴࡧࡥࡹࡧࠧࠨ")),l1l111_pbs_ (u"ࠪࡴࡷࡵࡦࡪ࡮ࡨࡷࠬࠩ"))
    if os.path.exists(l111ll111_pbs_):
        if ll111_pbs_(l111ll111_pbs_,[l1l111_pbs_ (u"ࠫࡰ࡯ࡤࡴࠩࠪ")])>0:
            l1111111_pbs_(l1l111_pbs_ (u"ࠬࡽࡩࡻࡣࡵࡨࠬࠫ"))
            return
    l11111_pbs_ = xbmc.translatePath(l1l111_pbs_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧࠬ"))
    for f in os.listdir(l11111_pbs_):
        if f.startswith(l1l111_pbs_ (u"ࠧࡎࡏࡈࡗࠬ࠭")):
            l1111111_pbs_()
            return
def l111111_pbs_():
    try:
        debug=1
    except: pass
import resources.lib.l1ll1l111_pbs_
if mode is None:
    from resources.lib import l1ll111_pbs_
    l1ll111_pbs_.l1ll111_pbs_().root()
elif mode == l1l111_pbs_ (u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶࠫ࠯"):
    from resources.lib import l1ll111_pbs_
    l1ll111_pbs_.l1ll111_pbs_().l1l111111_pbs_()
elif mode.startswith(l1l111_pbs_ (u"ࠪࡣ࡮ࡴࡦࡰࡡࠪ࠰"))  :
    from resources.lib import l1ll111_pbs_
    l1ll111_pbs_.l1ll111_pbs_().info()
elif mode == l1l111_pbs_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬ࠱"):
    from resources.lib import l1ll111_pbs_
    l1ll111_pbs_.l1ll111_pbs_().content(ex_link,l11l11111_pbs_)
elif mode.startswith(l1l111_pbs_ (u"ࠬࡥ࡟ࡱࡣࡪࡩࡤࡥࠧ࠲")):
    from resources.lib import l1ll111_pbs_
    l1ll111_pbs_.l1ll111_pbs_().l11l1111_pbs_(mode,ex_link,l11l11111_pbs_)
elif mode.startswith(l1l111_pbs_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ࠳")):
    from resources.lib import l1ll111_pbs_
    l1ll111_pbs_.l1ll111_pbs_().l1111_pbs_(ex_link,l11l11111_pbs_)
elif mode.startswith(l1l111_pbs_ (u"ࠧࡴࡧࡤࡷࡴࡴࡳࠨ࠴")):
    from resources.lib import l1ll111_pbs_
    l11ll1111_pbs_ = params.get(l1l111_pbs_ (u"ࠨ࡯࡬ࡲ࡫ࡵࠧ࠵"))
    l1ll111_pbs_.l1ll111_pbs_().l1l1ll111_pbs_(l11ll1111_pbs_)
elif mode.startswith(l1l111_pbs_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ࠶")):
    from resources.lib import l1ll111_pbs_
    l1ll111_pbs_.l1ll111_pbs_().l1111_pbs_(ex_link,l11l11111_pbs_)
elif mode.startswith(l1l111_pbs_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ࠷")):
    from resources.lib import l1ll111_pbs_
    l1ll111_pbs_.l1ll111_pbs_().l1llll111_pbs_(mode,ex_link,l11l11111_pbs_)
elif mode.startswith(l1l111_pbs_ (u"ࠫࡵࡲࡡࡺ࡯ࡨࠫ࠸")):
    from resources.lib import l1ll111_pbs_
    l1ll111_pbs_.l1ll111_pbs_().l1l1111_pbs_(ex_link)
