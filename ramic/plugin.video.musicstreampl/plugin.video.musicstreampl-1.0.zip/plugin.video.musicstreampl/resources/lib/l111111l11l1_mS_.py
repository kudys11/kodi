# -*- coding: utf-8 -*-
import sys
l111l11l1_mS_ = sys.version_info [0] == 2
l111ll11l1_mS_ = 2048
l1l1ll11l1_mS_ = 7
def l1l11l11l1_mS_ (keyedStringLiteral):
	global l1llll11l1_mS_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l11l1_mS_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll11l1_mS_ - (charIndex + stringNr) % l1l1ll11l1_mS_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll11l1_mS_ - (charIndex + stringNr) % l1l1ll11l1_mS_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os,json,base64
import cookielib
from urlparse import urlparse,urljoin
l1l11lll11l1_mS_ = 15
l1l1ll11l11l1_mS_=l1l11l11l1_mS_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠻࠴࠱࠼࡚ࠢ࡭ࡳ࠼࠴࠼ࠢࡻ࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠻࠷࠮࠱࠰࠶࠵࠻࠹࠮࠲࠲࠳ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫ࢐")
try:
    from xbmc import translatePath
    from xbmcaddon import Addon
    l1l1ll1l11l1_mS_    = translatePath(Addon().getAddonInfo(l1l11l11l1_mS_ (u"ࠩࡳࡶࡴ࡬ࡩ࡭ࡧࠪ࢑"))).decode(l1l11l11l1_mS_ (u"ࠪࡹࡹ࡬࠭࠹ࠩ࢒"))
    l1llll11l11l1_mS_=os.path.join(l1l1ll1l11l1_mS_,l1l11l11l1_mS_ (u"ࠫࡨࡵ࡯࡬࡫ࡨࠫ࢓"))
except:
    l1llll11l11l1_mS_=l1l11l11l1_mS_ (u"ࡷ࠭ࡢࡰࡺࡩ࡭ࡱࡳ࠮ࡤࡱࡲ࡯࡮࡫ࠧ࢔")
l1ll1llll11l1_mS_ = l1l11l11l1_mS_ (u"࠭ࠧ࢕")
class l1ll111ll11l1_mS_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
def l1111l1l11l1_mS_(url,data=None):
    l1ll111l11l1_mS_ = cookielib.LWPCookieJar()
    if data:
        opener = urllib2.build_opener(l1ll111ll11l1_mS_, urllib2.HTTPCookieProcessor(l1ll111l11l1_mS_))
    else:
        opener = urllib2.build_opener( urllib2.HTTPCookieProcessor(l1ll111l11l1_mS_))
    opener.addheaders = [(l1l11l11l1_mS_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ࢖"), l1l1ll11l11l1_mS_)]
    try:
        response = opener.open(url,data,l1l11lll11l1_mS_)
        result= response.read()
        response.close()
    except:
        result=l1lll1lll11l1_mS_ = e.read()
    return result
def l111ll1l11l1_mS_(l1l1111l11l1_mS_):
    if isinstance(l1l1111l11l1_mS_, unicode):
        l1l1111l11l1_mS_ = l1l1111l11l1_mS_.encode(l1l11l11l1_mS_ (u"ࠨࡷࡷࡪ࠲࠾ࠧࢗ"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠩࠩࡰࡹࡁࡢࡳ࠱ࠩ࡫ࡹࡁࠧ࢘"),l1l11l11l1_mS_ (u"ࠪࠤ࢙ࠬ"))
    s=l1l11l11l1_mS_ (u"ࠫࡏ࡯ࡎࡤ࡜ࡆࡷ࠼࢚࠭")
    l1l1111l11l1_mS_ = re.sub(s.decode(l1l11l11l1_mS_ (u"ࠬࡨࡡࡴࡧ࠹࠸࢛ࠬ")),l1l11l11l1_mS_ (u"࠭ࠧ࢜"),l1l1111l11l1_mS_)
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠧ࡝ࡰࠪ࢝"),l1l11l11l1_mS_ (u"ࠨࠩ࢞")).replace(l1l11l11l1_mS_ (u"ࠩ࡟ࡶࠬ࢟"),l1l11l11l1_mS_ (u"ࠪࠫࢠ"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠫࠫࡴࡢࡴࡲ࠾ࠫࢡ"),l1l11l11l1_mS_ (u"ࠬ࠭ࢢ"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"࠭ࠦࡲࡷࡲࡸࡀ࠭ࢣ"),l1l11l11l1_mS_ (u"ࠧࠣࠩࢤ")).replace(l1l11l11l1_mS_ (u"ࠨࠨࡤࡱࡵࡁࡱࡶࡱࡷ࠿ࠬࢥ"),l1l11l11l1_mS_ (u"ࠩࠥࠫࢦ"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠪࠪࡴࡧࡣࡶࡶࡨ࠿ࠬࢧ"),l1l11l11l1_mS_ (u"ࠫࣸ࠭ࢨ")).replace(l1l11l11l1_mS_ (u"ࠬࠬࡏࡢࡥࡸࡸࡪࡁࠧࢩ"),l1l11l11l1_mS_ (u"࣓࠭ࠨࢪ"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠧࠧࡣࡰࡴࡀࡵࡡࡤࡷࡷࡩࡀ࠭ࢫ"),l1l11l11l1_mS_ (u"ࠨࣵࠪࢬ")).replace(l1l11l11l1_mS_ (u"ࠩࠩࡥࡲࡶ࠻ࡐࡣࡦࡹࡹ࡫࠻ࠨࢭ"),l1l11l11l1_mS_ (u"ࠪࣗࠬࢮ"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠫࠫࡧ࡭ࡱ࠽ࠪࢯ"),l1l11l11l1_mS_ (u"ࠬࠬࠧࢰ"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"࠭࡜ࡶ࠲࠴࠴࠺࠭ࢱ"),l1l11l11l1_mS_ (u"ࠧआࠩࢲ")).replace(l1l11l11l1_mS_ (u"ࠨ࡞ࡸ࠴࠶࠶࠴ࠨࢳ"),l1l11l11l1_mS_ (u"ࠩइࠫࢴ"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠪࡠࡺ࠶࠱࠱࠹ࠪࢵ"),l1l11l11l1_mS_ (u"ࠫऌ࠭ࢶ")).replace(l1l11l11l1_mS_ (u"ࠬࡢࡵ࠱࠳࠳࠺ࠬࢷ"),l1l11l11l1_mS_ (u"࠭आࠨࢸ"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠧ࡝ࡷ࠳࠵࠶࠿ࠧࢹ"),l1l11l11l1_mS_ (u"ࠨछࠪࢺ")).replace(l1l11l11l1_mS_ (u"ࠩ࡟ࡹ࠵࠷࠱࠹ࠩࢻ"),l1l11l11l1_mS_ (u"ࠪजࠬࢼ"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠫࡡࡻ࠰࠲࠶࠵ࠫࢽ"),l1l11l11l1_mS_ (u"ࠬैࠧࢾ")).replace(l1l11l11l1_mS_ (u"࠭࡜ࡶ࠲࠴࠸࠶࠭ࢿ"),l1l11l11l1_mS_ (u"ࠧूࠩࣀ"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠨ࡞ࡸ࠴࠶࠺࠴ࠨࣁ"),l1l11l11l1_mS_ (u"ࠩेࠫࣂ")).replace(l1l11l11l1_mS_ (u"ࠪࡠࡺ࠶࠱࠵࠶ࠪࣃ"),l1l11l11l1_mS_ (u"ࠫै࠭ࣄ"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠬࡢࡵ࠱࠲ࡩ࠷ࠬࣅ"),l1l11l11l1_mS_ (u"࠭ࣳࠨࣆ")).replace(l1l11l11l1_mS_ (u"ࠧ࡝ࡷ࠳࠴ࡩ࠹ࠧࣇ"),l1l11l11l1_mS_ (u"ࠨࣕࠪࣈ"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠩ࡟ࡹ࠵࠷࠵ࡣࠩࣉ"),l1l11l11l1_mS_ (u"ࠪय़ࠬ࣊")).replace(l1l11l11l1_mS_ (u"ࠫࡡࡻ࠰࠲࠷ࡤࠫ࣋"),l1l11l11l1_mS_ (u"ࠬॠࠧ࣌"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"࠭࡜ࡶ࠲࠴࠻ࡦ࠭࣍"),l1l11l11l1_mS_ (u"ࠧॻࠩ࣎")).replace(l1l11l11l1_mS_ (u"ࠨ࡞ࡸ࠴࠶࠽࠹ࠨ࣏"),l1l11l11l1_mS_ (u"ࠩॼ࣐ࠫ"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠪࡠࡺ࠶࠱࠸ࡥ࣑ࠪ"),l1l11l11l1_mS_ (u"ࠫঁ࣒࠭")).replace(l1l11l11l1_mS_ (u"ࠬࡢࡵ࠱࠳࠺ࡦ࣓ࠬ"),l1l11l11l1_mS_ (u"࠭ॻࠨࣔ"))
    return l1l1111l11l1_mS_
class l1lllllll11l1_mS_:
    def l11ll1ll11l1_mS_(self,url):
        if not url:
            url = l1l11l11l1_mS_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡫ࡤࡲࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࠬࣕ")
        elif url.startswith(l1l11l11l1_mS_ (u"ࠨ࠱࠲ࠫࣖ")):
            url = l1l11l11l1_mS_ (u"ࠩ࡫ࡸࡹࡶࠧࣗ")+url
        elif url.startswith(l1l11l11l1_mS_ (u"ࠪ࠳ࠬࣘ")):
            url = urljoin(l1l11l11l1_mS_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩࣙ"),url)
        return url
    @staticmethod
    def l1llll1ll11l1_mS_(url=l1l11l11l1_mS_ (u"ࠬ࠭ࣚ")):
        if not url:
            url = l1l11l11l1_mS_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡪࡣࡱࡩ࡭ࡱࡳ࠮ࡱ࡮࠲ࠫࣛ")
        elif url.startswith(l1l11l11l1_mS_ (u"ࠧ࠰ࠩࣜ")):
            url = urljoin(l1l11l11l1_mS_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡬ࡥࡳ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭ࣝ"),url)
        content = l1111l1l11l1_mS_(url)
        out=[]
        l1111lll11l1_mS_ = re.compile(l1l11l11l1_mS_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡪࡴࡴ࠮ࡩࡵ࡭ࡩࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬࣞ"),re.DOTALL).findall(content)
        for show in l1111lll11l1_mS_:
            l11l11ll11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠯ࡴࡧࡵ࡭ࡦࡲࡥ࠰࠰࠭࠭ࠧࡄ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࣟ"),show)
            if l11l11ll11l1_mS_:
                l11l1l1l11l1_mS_ = l11l11ll11l1_mS_[0][1]
                l11l1l1l11l1_mS_ = urljoin(l1l11l11l1_mS_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩ࣠"),l11l1l1l11l1_mS_) if not l11l1l1l11l1_mS_.startswith(l1l11l11l1_mS_ (u"ࠬ࡮ࡴࡵࡲࠪ࣡")) else l11l1l1l11l1_mS_
                title = l11l11ll11l1_mS_[0][0].replace(l1l11l11l1_mS_ (u"࠭࠯ࡴࡧࡵ࡭ࡦࡲࡥ࠰ࠩ࣢"),l1l11l11l1_mS_ (u"ࠧࠨࣣ")).replace(l1l11l11l1_mS_ (u"ࠨ࠯ࠪࣤ"),l1l11l11l1_mS_ (u"ࠩࠣࠫࣥ")).replace(l1l11l11l1_mS_ (u"ࠪ࠳ࣦࠬ"),l1l11l11l1_mS_ (u"ࠫࠬࣧ")).title()
                out.append({l1l11l11l1_mS_ (u"ࠬ࡮ࡲࡦࡨࠪࣨ"):l11l11ll11l1_mS_[0][0],l1l11l11l1_mS_ (u"࠭ࡴࡪࡶ࡯ࡩࣩࠬ"):title,l1l11l11l1_mS_ (u"ࠧࡪ࡯ࡪࠫ࣪"):l11l1l1l11l1_mS_})
        idx = content.find(l1l11l11l1_mS_ (u"ࠨࡪ࠶ࡂࡘ࡫ࡲࡪࡣ࡯ࡩࡁ࠵ࡨ࠴ࡀࠪ࣫"))
        if idx:
            l1ll11lll11l1_mS_ = re.compile(l1l11l11l1_mS_ (u"ࠩ࠿ࡹࡱࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪ࣬"),re.DOTALL).search(content[idx:-1])
            l1ll11lll11l1_mS_ = l1ll11lll11l1_mS_.group(1) if l1ll11lll11l1_mS_ else l1l11l11l1_mS_ (u"࣭ࠪࠫ")
            l1ll11lll11l1_mS_ = re.sub(l1l11l11l1_mS_ (u"ࡶࠧࡂࠡ࠮࠯ࠫ࠲ࢁࡢࡳࡽ࡞ࡱ࠭࠯ࡅ࠭࠮ࡀ࣮ࠥ"), l1l11l11l1_mS_ (u"ࠧࠨ࣯"), l1ll11lll11l1_mS_)
            l1ll11l1l11l1_mS_ = re.compile(l1l11l11l1_mS_ (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠯ࡴࡧࡵ࡭ࡦࡲࡥ࠰࠰࠭ࡃ࠮ࠨ࠾ࠩ࡝ࡡࡂࡢ࠰ࠩ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࣰࠪ")).findall(l1ll11lll11l1_mS_)
            for href,title in l1ll11l1l11l1_mS_:
                out.append({l1l11l11l1_mS_ (u"ࠧࡩࡴࡨࡪࣱࠬ"):href,l1l11l11l1_mS_ (u"ࠨࡶ࡬ࡸࡱ࡫ࣲࠧ"):title})
        return out
    @staticmethod
    def l1l1lll1l11l1_mS_(url=l1l11l11l1_mS_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡭ࡦࡴ࡬ࡩ࡭࡯࠱ࡴࡱ࠵ࡳࡦࡴ࡬ࡥࡱ࡫࠯ࡥࡧࡷࡩࡰࡺࡹࡸ࠱ࠪࣳ")):
        if not url:
            url = l1l11l11l1_mS_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡮ࡧࡵࡦࡪ࡮ࡰ࠲ࡵࡲ࠯ࠨࣴ")
        if url.startswith(l1l11l11l1_mS_ (u"ࠫ࠴࠵ࠧࣵ")):
            url = l1l11l11l1_mS_ (u"ࠬ࡮ࡴࡵࡲࣶࠪ")+url
        if url.startswith(l1l11l11l1_mS_ (u"࠭࠯ࠨࣷ")):
            url = urljoin(l1l11l11l1_mS_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡫ࡤࡲࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࠬࣸ"),url)
        url += l1l11l11l1_mS_ (u"ࠨ࠱ࣹࠪ") if not url.endswith(l1l11l11l1_mS_ (u"ࠩ࠲ࣺࠫ")) else l1l11l11l1_mS_ (u"ࠪࠫࣻ")
        content = l1111l1l11l1_mS_(url)
        out=[]
        l1ll1l1ll11l1_mS_ = re.compile(l1l11l11l1_mS_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶ࠰࡫ࡷ࡯ࡤࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧࣼ"),re.DOTALL).findall(content)
        for l11lllll11l1_mS_ in l1ll1l1ll11l1_mS_:
            l1lll11ll11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠬࡹࡥࡻࡱࡱࡠࡸ࠰ࠨ࡝ࡦ࠮࠭ࠬࣽ"),l11lllll11l1_mS_,re.I)
            l1lll11ll11l1_mS_ = l1lll11ll11l1_mS_[0] if l1lll11ll11l1_mS_ else l1l11l11l1_mS_ (u"࠭ࠧࣾ")
            l1l1ll1ll11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠧࡐࡦࡦ࡭ࡳ࡫࡫࡝ࡵ࠭ࠬࡡࡪࠫࠪࠩࣿ"),l11lllll11l1_mS_,re.I)
            l1l1ll1ll11l1_mS_ = l1l1ll1ll11l1_mS_[0] if l1l1ll1ll11l1_mS_ else l1l11l11l1_mS_ (u"ࠨࠩऀ")
            href = re.compile(l1l11l11l1_mS_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭ࡹࡩ࡯ࡩ࡯ࡩࡵࡧࡧࡦ࠰ࡳ࡬ࡵࡢ࠿ࡪࡦࡀࡠࡩ࠱ࠩࠣࠩँ")).findall(l11lllll11l1_mS_)
            l11l1l1l11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠪࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ं"),l11lllll11l1_mS_)
            if href and l1lll11ll11l1_mS_ and l1l1ll1ll11l1_mS_:
                l11l1l1l11l1_mS_ = urljoin(l1l11l11l1_mS_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩः"),l11l1l1l11l1_mS_[0]) if not l11l1l1l11l1_mS_[0].startswith(l1l11l11l1_mS_ (u"ࠬ࡮ࡴࡵࡲࠪऄ")) else l1l11l11l1_mS_ (u"࠭ࠧअ")
                out.append({l1l11l11l1_mS_ (u"ࠧࡩࡴࡨࡪࠬआ"):url+href[0],l1l11l11l1_mS_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧइ"):l1l11l11l1_mS_ (u"ࠩࡖࡩࡿࡵ࡮ࠡࠧࡶ࠰ࠥࡋࡰࡪࡼࡲࡨࠥࠫࡳࠨई")%(l1lll11ll11l1_mS_,l1l1ll1ll11l1_mS_),l1l11l11l1_mS_ (u"ࠪ࡭ࡲ࡭ࠧउ"):l11l1l1l11l1_mS_,
                l1l11l11l1_mS_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࠫऊ"):int(l1lll11ll11l1_mS_),l1l11l11l1_mS_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪ࠭ऋ"):int(l1l1ll1ll11l1_mS_)})
        return out
    @staticmethod
    def l1lll111l11l1_mS_(out):
        l1l11l1l11l1_mS_={}
        l1lllll1l11l1_mS_ = [x.get(l1l11l11l1_mS_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭ऌ")) for x in out]
        for s in set(l1lllll1l11l1_mS_):
            l1l11l1l11l1_mS_[l1l11l11l1_mS_ (u"ࠧࡔࡧࡽࡳࡳࠦࠥ࠱࠴ࡧࠫऍ")%s]=[out[i] for i, j in enumerate(l1lllll1l11l1_mS_) if j == s]
        return l1l11l1l11l1_mS_
    @staticmethod
    def l1l1l11l11l1_mS_(url):
        content = l1111l1l11l1_mS_(url)
        l11ll11l11l1_mS_=l1l11l11l1_mS_ (u"ࠨࠩऎ")
        l11l1lll11l1_mS_ = re.compile(l1l11l11l1_mS_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠫ࠲࠯ࡅࠩ࠽࠱࡬ࡪࡷࡧ࡭ࡦࡀࠪए"),re.DOTALL).findall(content)
        if l11l1lll11l1_mS_:
            src = re.compile(l1l11l11l1_mS_ (u"ࠪࡷࡷࡩ࠽࡜࡞ࠪࠦࡢ࠮࠮ࠫࡁࠬ࡟ࡡ࠭ࠢ࡞ࠩऐ"),re.DOTALL).findall(l11l1lll11l1_mS_[0])
            l11ll11l11l1_mS_ = src[0] if src else l1l11l11l1_mS_ (u"ࠫࠬऑ")
        return l11ll11l11l1_mS_
class l1ll1l11l11l1_mS_:
    @staticmethod
    def l1llll1ll11l1_mS_(url,l111llll11l1_mS_=None):
        if l111llll11l1_mS_:
            l111llll11l1_mS_ = l1l11l11l1_mS_ (u"ࠬࡹࡺࡶ࡭ࡤ࡮ࡂ࠭ऒ")+l111llll11l1_mS_.replace(l1l11l11l1_mS_ (u"࠭ࠠࠨओ"),l1l11l11l1_mS_ (u"ࠧࠬࠩऔ"))
            url= l1l11l11l1_mS_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡨ࡯ࡹࡨ࡬ࡰࡲ࠴ࡰ࡭࠱ࡶࡾࡺࡱࡡ࡫ࠩक")
        if not url:
            url = l1l11l11l1_mS_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡰࡺࡩ࡭ࡱࡳ࠮ࡱ࡮࠲ࠫख")
        elif url.startswith(l1l11l11l1_mS_ (u"ࠪ࠳ࠬग")):
            url = urljoin(l1l11l11l1_mS_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡲࡼ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭घ"),url)
        content = l1111l1l11l1_mS_(url,l111llll11l1_mS_)
        ids = [(a.start(), a.end()) for a in re.finditer(l1l11l11l1_mS_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡺ࡮ࡪࡥࡰࡡ࡬ࡲ࡫ࡵࠢ࠿ࠩङ"), content,re.IGNORECASE)]
        ids.append( (-1,-1) )
        out=[]
        for i in range(len(ids[:-1])):
            l1ll11ll11l1_mS_ = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile(l1l11l11l1_mS_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨच"),re.DOTALL).search(l1ll11ll11l1_mS_)
            title = re.compile(l1l11l11l1_mS_ (u"ࠧ࠽ࡪ࠴ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠷࠾ࠨछ"),re.DOTALL).search(l1ll11ll11l1_mS_)
            l11l1l1l11l1_mS_ = re.compile(l1l11l11l1_mS_ (u"ࠨ࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫज"),re.DOTALL).search(l1ll11ll11l1_mS_)
            l1ll1111l11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠩࡏࡩࡰࡺ࡯ࡳ࠼࡟ࡷ࠯ࡂࡳࡱࡣࡱࠤࡸࡺࡹ࡭ࡧࡀࠦࡠࡤ࠾࡞ࠬࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪझ"),l1ll11ll11l1_mS_)
            l1ll1ll1l11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠪࡈࡴࡪࡡ࡯ࡻ࠽ࡠࡸ࠰࠼ࡴࡲࡤࡲࠥࡹࡴࡺ࡮ࡨࡁࠧࡡ࡞࠿࡟࠭ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫञ"),l1ll11ll11l1_mS_)
            l1l1lllll11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠫࡌࡧࡴࡶࡰࡨ࡯࠿ࡢࡳࠫ࠾ࡶࡴࡦࡴࠠࡴࡶࡼࡰࡪࡃࠢ࡜ࡠࡁࡡ࠯ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭ट"),l1ll11ll11l1_mS_)
            l1ll1111l11l1_mS_ = l1ll1111l11l1_mS_[0] if l1ll1111l11l1_mS_ else l1l11l11l1_mS_ (u"ࠬ࠭ठ")
            l1ll1ll1l11l1_mS_ = l1ll1ll1l11l1_mS_[0] if l1ll1ll1l11l1_mS_ else l1l11l11l1_mS_ (u"࠭ࠧड")
            l1l1lllll11l1_mS_ = l1l1lllll11l1_mS_[0] if l1l1lllll11l1_mS_ else l1l11l11l1_mS_ (u"ࠧࠨढ")
            code = l1ll1111l11l1_mS_
            l11lll1l11l1_mS_ = l1l11l11l1_mS_ (u"ࠣࡎࡨ࡯ࡹࡵࡲ࠻ࠢࠨࡷࠥࡢ࡮ࡅࡱࡧࡥࡳࡿ࠺ࠡࠧࡶࠤࡡࡴࡇࡢࡶࡸࡲࡪࡱ࠺ࠡࠧࡶࠤࡡࡴࠢण") %(l1ll1111l11l1_mS_,l1ll1ll1l11l1_mS_,l1l1lllll11l1_mS_)
            if href and title:
                l11l1l1l11l1_mS_ = urljoin(l1l11l11l1_mS_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡰࡺࡩ࡭ࡱࡳ࠮ࡱ࡮ࠪत"),l11l1l1l11l1_mS_.group(1)) if l11l1l1l11l1_mS_ else l1l11l11l1_mS_ (u"ࠪࠫथ")
                title = title.group(1)
                year =  re.findall(l1l11l11l1_mS_ (u"ࠫࡡ࠮ࠨ࡝ࡦࡾ࠸ࢂ࠯࡜ࠪࠩद"),title)
                l1l1llll11l1_mS_ = {l1l11l11l1_mS_ (u"ࠬ࡮ࡲࡦࡨࠪध")   : href.group(1),
                       l1l11l11l1_mS_ (u"࠭ࡴࡪࡶ࡯ࡩࠬन")  : l111ll1l11l1_mS_(title),
                       l1l11l11l1_mS_ (u"ࠧࡪ࡯ࡪࠫऩ")    : l11l1l1l11l1_mS_,
                       l1l11l11l1_mS_ (u"ࠨࡲ࡯ࡳࡹ࠭प")   : l111ll1l11l1_mS_(l11lll1l11l1_mS_),
                       l1l11l11l1_mS_ (u"ࠩࡼࡩࡦࡸࠧफ")   : year[0] if year else l1l11l11l1_mS_ (u"ࠪࠫब"),
                       l1l11l11l1_mS_ (u"ࠫࡨࡵࡤࡦࠩभ")   : code,
                        }
                out.append(l1l1llll11l1_mS_)
        l1lll1l1l11l1_mS_=False
        l1l1l1ll11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࡝ࡡࠦࡢ࠰ࠩࠣࡀ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢ࡯ࡧࡻࡸࡤࡹࡩࡵࡧࠥࡂࡕࡵࡰࡳࡼࡨࡨࡳ࡯ࡡ࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡣࡁࠫम"),content)
        l1l1l1ll11l1_mS_ = l1l1l1ll11l1_mS_[0] if l1l1l1ll11l1_mS_ else False
        l1lll1l1l11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࡞ࡢࠧࡣࠪࠪࠤࡁࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡰࡨࡼࡹࡥࡳࡪࡶࡨࠦࡃࡔࡡࡴࡶ࠱࠯ࡵࡴࡡ࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡣࡁࠫय"),content)
        l1lll1l1l11l1_mS_ = l1lll1l1l11l1_mS_[0] if l1lll1l1l11l1_mS_ else False
        return (out, (l1l1l1ll11l1_mS_,l1lll1l1l11l1_mS_))
    @staticmethod
    def l11111ll11l1_mS_():
        content = l1111l1l11l1_mS_(l1l11l11l1_mS_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡧࡵࡸࡧ࡫࡯ࡱ࠳ࡶ࡬࠰࡭ࡲࡲࡹࡧ࡫ࡵࠩर"))
        l111l1ll11l1_mS_=re.findall(l1l11l11l1_mS_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠴ࡱࡡࡵࡣ࡯ࡳ࡬࠵࠮ࠫࠫࠥࠤࡨࡲࡡࡴࡵࡀࠦࡳࡧࡶࡠ࡮࡬ࡲࡰࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪऱ"),content)
        out=[]
        for href,name in l111l1ll11l1_mS_:
            out.append({l1l11l11l1_mS_ (u"ࠩ࡫ࡶࡪ࡬ࠧल"):href,l1l11l11l1_mS_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩळ"):name})
        return out
    @staticmethod
    def l11l111l11l1_mS_(url):
        url = urljoin(l1l11l11l1_mS_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡲࡼ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭ऴ"),url)
        content = l1111l1l11l1_mS_(url)
        l111l11l11l1_mS_=l1l11l11l1_mS_ (u"ࠬ࠭व")
        l1l111ll11l1_mS_=re.findall(l1l11l11l1_mS_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡩࡧࡴࡤࡱࡪࡄࠧश"),content,re.DOTALL|re.IGNORECASE)
        if l1l111ll11l1_mS_:
            l111l11l11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬष"),l1l111ll11l1_mS_[0],re.DOTALL|re.IGNORECASE)
            l111l11l11l1_mS_ = l111l11l11l1_mS_[0] if l111l11l11l1_mS_ else l1l11l11l1_mS_ (u"ࠨࠩस")
        return l111l11l11l1_mS_
