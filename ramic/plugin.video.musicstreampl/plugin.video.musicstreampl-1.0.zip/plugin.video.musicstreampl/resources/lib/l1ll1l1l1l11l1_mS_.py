# -*- coding: utf-8 -*-
import sys
l111l11l1_mS_ = sys.version_info [0] == 2
l111ll11l1_mS_ = 2048
l1l1ll11l1_mS_ = 7
def l1l11l11l1_mS_ (keyedStringLiteral):
	global l1llll11l1_mS_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l11l1_mS_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll11l1_mS_ - (charIndex + stringNr) % l1l1ll11l1_mS_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll11l1_mS_ - (charIndex + stringNr) % l1l1ll11l1_mS_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os,json,base64
import cookielib
from urlparse import urlparse,urljoin
def l1ll1l111l11l1_mS_(l1l1111l11l1_mS_):
    pass
l1l11lll11l1_mS_ = 15
l1l1ll11l11l1_mS_=l1l11l11l1_mS_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠺࠳࠷࠻࡙ࠡ࡬ࡲ࠻࠺࠻ࠡࡺ࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠺࠶࠴࠰࠯࠵࠴࠺࠸࠴࠱࠱࠲ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪਲ਼")
try:
    from xbmc import translatePath
    from xbmcaddon import Addon
    l1l1ll1l11l1_mS_    = translatePath(Addon().getAddonInfo(l1l11l11l1_mS_ (u"ࠨࡲࡵࡳ࡫࡯࡬ࡦࠩ਴"))).decode(l1l11l11l1_mS_ (u"ࠩࡸࡸ࡫࠳࠸ࠨਵ"))
    l1llll11l11l1_mS_=os.path.join(l1l1ll1l11l1_mS_,l1l11l11l1_mS_ (u"ࠪࡧࡴࡵ࡫ࡪࡧࠪਸ਼"))
except:
    l1llll11l11l1_mS_=l1l11l11l1_mS_ (u"ࡶࠬࡪࡵࡱࡣ࠱ࡧࡴࡵ࡫ࡪࡧࠪ਷")
l1ll1llll11l1_mS_ = l1l11l11l1_mS_ (u"ࠬ࠭ਸ")
class l1ll111ll11l1_mS_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
def l1111l1l11l1_mS_(url,data=None):
    l1ll111l11l1_mS_ = cookielib.LWPCookieJar()
    if data:
        opener = urllib2.build_opener(l1ll111ll11l1_mS_, urllib2.HTTPCookieProcessor(l1ll111l11l1_mS_))
    else:
        opener = urllib2.build_opener( urllib2.HTTPCookieProcessor(l1ll111l11l1_mS_))
    opener.addheaders = [(l1l11l11l1_mS_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪਹ"), l1l1ll11l11l1_mS_)]
    try:
        response = opener.open(url,data,l1l11lll11l1_mS_)
        result= response.read()
        response.close()
    except:
        result=l1lll1lll11l1_mS_ = e.read()
    return result
def l111ll1l11l1_mS_(l1l1111l11l1_mS_):
    if isinstance(l1l1111l11l1_mS_, unicode):
        l1l1111l11l1_mS_ = l1l1111l11l1_mS_.encode(l1l11l11l1_mS_ (u"ࠧࡶࡶࡩ࠱࠽࠭਺"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠨࠨ࡯ࡸࡀࡨࡲ࠰ࠨࡪࡸࡀ࠭਻"),l1l11l11l1_mS_ (u"਼ࠩࠣࠫ"))
    s=l1l11l11l1_mS_ (u"ࠪࡎ࡮ࡔࡣ࡛ࡅࡶ࠻ࠬ਽")
    l1l1111l11l1_mS_ = re.sub(s.decode(l1l11l11l1_mS_ (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫਾ")),l1l11l11l1_mS_ (u"ࠬ࠭ਿ"),l1l1111l11l1_mS_)
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"࠭࡜࡯ࠩੀ"),l1l11l11l1_mS_ (u"ࠧࠨੁ")).replace(l1l11l11l1_mS_ (u"ࠨ࡞ࡵࠫੂ"),l1l11l11l1_mS_ (u"ࠩࠪ੃"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠪࠪࡳࡨࡳࡱ࠽ࠪ੄"),l1l11l11l1_mS_ (u"ࠫࠬ੅"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠬࠬࡱࡶࡱࡷ࠿ࠬ੆"),l1l11l11l1_mS_ (u"࠭ࠢࠨੇ")).replace(l1l11l11l1_mS_ (u"ࠧࠧࡣࡰࡴࡀࡷࡵࡰࡶ࠾ࠫੈ"),l1l11l11l1_mS_ (u"ࠨࠤࠪ੉"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠩࠩࡳࡦࡩࡵࡵࡧ࠾ࠫ੊"),l1l11l11l1_mS_ (u"ࠪࣷࠬੋ")).replace(l1l11l11l1_mS_ (u"ࠫࠫࡕࡡࡤࡷࡷࡩࡀ࠭ੌ"),l1l11l11l1_mS_ (u"੍ࠬࣙࠧ"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"࠭ࠦࡢ࡯ࡳ࠿ࡴࡧࡣࡶࡶࡨ࠿ࠬ੎"),l1l11l11l1_mS_ (u"ࠧࣴࠩ੏")).replace(l1l11l11l1_mS_ (u"ࠨࠨࡤࡱࡵࡁࡏࡢࡥࡸࡸࡪࡁࠧ੐"),l1l11l11l1_mS_ (u"ࠩࣖࠫੑ"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠪࠪࡦࡳࡰ࠼ࠩ੒"),l1l11l11l1_mS_ (u"ࠫࠫ࠭੓"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠬࡢࡵ࠱࠳࠳࠹ࠬ੔"),l1l11l11l1_mS_ (u"࠭अࠨ੕")).replace(l1l11l11l1_mS_ (u"ࠧ࡝ࡷ࠳࠵࠵࠺ࠧ੖"),l1l11l11l1_mS_ (u"ࠨआࠪ੗"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠩ࡟ࡹ࠵࠷࠰࠸ࠩ੘"),l1l11l11l1_mS_ (u"ࠪऋࠬਖ਼")).replace(l1l11l11l1_mS_ (u"ࠫࡡࡻ࠰࠲࠲࠹ࠫਗ਼"),l1l11l11l1_mS_ (u"ࠬऌࠧਜ਼"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"࠭࡜ࡶ࠲࠴࠵࠾࠭ੜ"),l1l11l11l1_mS_ (u"ࠧचࠩ੝")).replace(l1l11l11l1_mS_ (u"ࠨ࡞ࡸ࠴࠶࠷࠸ࠨਫ਼"),l1l11l11l1_mS_ (u"ࠩछࠫ੟"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠪࡠࡺ࠶࠱࠵࠴ࠪ੠"),l1l11l11l1_mS_ (u"ࠫे࠭੡")).replace(l1l11l11l1_mS_ (u"ࠬࡢࡵ࠱࠳࠷࠵ࠬ੢"),l1l11l11l1_mS_ (u"࠭ुࠨ੣"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠧ࡝ࡷ࠳࠵࠹࠺ࠧ੤"),l1l11l11l1_mS_ (u"ࠨॆࠪ੥")).replace(l1l11l11l1_mS_ (u"ࠩ࡟ࡹ࠵࠷࠴࠵ࠩ੦"),l1l11l11l1_mS_ (u"ࠪेࠬ੧"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠫࡡࡻ࠰࠱ࡨ࠶ࠫ੨"),l1l11l11l1_mS_ (u"ࣹࠬࠧ੩")).replace(l1l11l11l1_mS_ (u"࠭࡜ࡶ࠲࠳ࡨ࠸࠭੪"),l1l11l11l1_mS_ (u"ࠧࣔࠩ੫"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠨ࡞ࡸ࠴࠶࠻ࡢࠨ੬"),l1l11l11l1_mS_ (u"ࠩफ़ࠫ੭")).replace(l1l11l11l1_mS_ (u"ࠪࡠࡺ࠶࠱࠶ࡣࠪ੮"),l1l11l11l1_mS_ (u"ࠫय़࠭੯"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠬࡢࡵ࠱࠳࠺ࡥࠬੰ"),l1l11l11l1_mS_ (u"࠭ॺࠨੱ")).replace(l1l11l11l1_mS_ (u"ࠧ࡝ࡷ࠳࠵࠼࠿ࠧੲ"),l1l11l11l1_mS_ (u"ࠨॻࠪੳ"))
    l1l1111l11l1_mS_ = l1l1111l11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠩ࡟ࡹ࠵࠷࠷ࡤࠩੴ"),l1l11l11l1_mS_ (u"ࠪঀࠬੵ")).replace(l1l11l11l1_mS_ (u"ࠫࡡࡻ࠰࠲࠹ࡥࠫ੶"),l1l11l11l1_mS_ (u"ࠬঁࠧ੷"))
    return l1l1111l11l1_mS_
def l11111l1l11l1_mS_(l1lll1111l11l1_mS_):
    l111l11ll11l1_mS_ = {}
    for k, v in l1lll1111l11l1_mS_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l1l11l11l1_mS_ (u"࠭ࡵࡵࡨ࠻ࠫ੸"))
        elif isinstance(v, str):
            v.decode(l1l11l11l1_mS_ (u"ࠧࡶࡶࡩ࠼ࠬ੹"))
        l111l11ll11l1_mS_[k] = v
    return l111l11ll11l1_mS_
_1llll1lll11l1_mS_=l1l11l11l1_mS_ (u"ࠨࠩࠪࠑࠏࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦࠨࡨ࡬ࡶࡧࡶࠦࡃࡈ࡬ࡶࡧࡶࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃࠓࠊࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠤࡧ࡯ࡩࡨࡺࡲࡰࡰ࡬ࡧࠧࡄࡅ࡭ࡧࡦࡸࡷࡵ࡮ࡪࡥ࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠒࠐࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠣࡴ࡫ࡱ࡫ࡪࡸ࠯ࡴࡱࡱ࡫ࡼࡸࡩࡵࡧࡵࠦࡃ࡙ࡩ࡯ࡩࡨࡶ࠴࡙࡯࡯ࡩࡺࡶ࡮ࡺࡥࡳ࠾࠲ࡥࡃࡂ࠯࡭࡫ࡁࠑࠏࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧࠩࡲࠧࡤ࠲ࡷࡴࡻ࡬ࠣࡀࡕࠪࡇ࠵ࡓࡰࡷ࡯ࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃࠓࠊࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠤࡦࡤࡲࡨ࡫ࠢ࠿ࡆࡤࡲࡨ࡫࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠏࠍࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠧ࡭࡯ࡰࠡࡪࡲࡴ࠴ࡸࡡࡱࠤࡁࡌ࡮ࡶࠠࡉࡱࡳ࠳ࡗࡧࡰ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠐࠎࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦࠨࡧ࡬ࡵࡧࡵࡲࡦࡺࡩࡷࡧࠥࡂࡆࡲࡴࡦࡴࡱࡥࡹ࡯ࡶࡦ࠾࠲ࡥࡃࡂ࠯࡭࡫ࡁࠑࠏࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧࠩࡲࡰࡥ࡮ࠦࡃࡘ࡯ࡤ࡭࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠒࠐࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠣࡳࡧࡪ࡫ࡦ࡫ࠢ࠿ࡔࡨ࡫࡬ࡧࡥ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠐࠎࠬ࠭ࠧ੺")
def l1111l11l11l1_mS_():
    out=[{l1l11l11l1_mS_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ੻"):l1l11l11l1_mS_ (u"ࠪ࡟ࡇࡣࡁ࡭࡮࡞࠳ࡇࡣࠧ੼"),l1l11l11l1_mS_ (u"ࠫ࡭ࡸࡥࡧࠩ੽"):l1l11l11l1_mS_ (u"ࠬ࠭੾")}]
    for key,title in re.findall(l1l11l11l1_mS_ (u"࠭ࠢࠤࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࠩ੿"),_1llll1lll11l1_mS_):
        out.append({l1l11l11l1_mS_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭઀"):title,l1l11l11l1_mS_ (u"ࠨࡪࡵࡩ࡫࠭ઁ"):key})
    return out
def l1llllllll11l1_mS_(key=l1l11l11l1_mS_ (u"ࠩࡨࡰࡪࡩࡴࡳࡱࡱ࡭ࡨ࠭ં")):
    l11l11lll11l1_mS_=l1l11l11l1_mS_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮࡮ࡷࡶ࡭ࡽ࡮ࡵࡣ࠰ࡦࡳࡲ࠵ࡧࡦࡰࡵࡩࡸ࠴ࡰࡩࡲࠪઃ")
    content=l1111l1l11l1_mS_(l11l11lll11l1_mS_)
    data=content
    out=[]
    if key:
        ids = [(a.start(), a.end()) for a in re.finditer(l1l11l11l1_mS_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡶࡩࡨࡺࡩࡰࡰࠣ࡫ࡷࡵࡵࡱࠢࡪࡩࡳࡸࡥ࠮ࡥࡲࡲࡹࡧࡩ࡯ࡧࡵࠦࠥ࡯ࡤ࠾ࠩ઄"), content)]
        ids.append( (-1,-1) )
        for i in range(len(ids[:-1])):
            l1ll11ll11l1_mS_ = content[ ids[i][1]:ids[i+1][0] ]
            if key in l1ll11ll11l1_mS_[:20]:
                data=l1ll11ll11l1_mS_
                break
    if data:
        ids = [(a.start(), a.end()) for a in re.finditer(l1l11l11l1_mS_ (u"ࠬࡂࡤࡪࡸࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࡐ࡮ࡹࡴࡦࡰࠣࡸࡴࠦࡴࡩࡧࠣࡥࡱࡨࡵ࡮ࠢࠪઅ"), data)]
        ids.append( (-1,-1) )
        for i in range(len(ids[:-1])):
            l1ll11ll11l1_mS_ = data[ ids[i][1]:ids[i+1][0] ]
            artist = re.findall(l1l11l11l1_mS_ (u"࠭ࡢࡺࠢࠫ࠲࠯ࡅࠩࠣࠩઆ"),l1ll11ll11l1_mS_)
            l1ll1ll1ll11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠲ࡨࡪࡺࡡࡪ࡮ࡶ࠲ࡵ࡮ࡰ࡝ࡁࡷࡁࡦࠬࡩࡵ࠿ࠫ࠲࠯ࡅࠩࠣࡀࠪઇ"),l1ll11ll11l1_mS_)
            l11l1l1l11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡦ࡬ࡺ࡙ࡳࡢࡊ࡯ࡪࠦࠥࡹࡲࡤ࠿ࠥࠬ࡭࠴ࠪࡀࠫࠥࠫઈ"),l1ll11ll11l1_mS_)
            l11ll111l11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠩࠫࡠࡩ࠱ࠠࡵࡴࡤࡧࡰࡹࠩࠨઉ"),l1ll11ll11l1_mS_)
            name = re.findall(l1l11l11l1_mS_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡨ࡮ࡼࡔ࡮ࡤࡑࡥࡲ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠶ࡂࠬઊ"),l1ll11ll11l1_mS_)
            if l1ll1ll1ll11l1_mS_ and name and artist:
                artist = artist[0].strip()
                name =  name[0].strip()
                l11ll111l11l1_mS_ = l11ll111l11l1_mS_[0] if l11ll111l11l1_mS_ else l1l11l11l1_mS_ (u"ࠫࠬઋ")
                title = l1l11l11l1_mS_ (u"ࠬࠫࡳࠡ࠯ࠣࠩࡸࠦࠠࠡ࡝ࠨࡷࡢ࠭ઌ")%(artist,name,l11ll111l11l1_mS_)
                href=urllib.urlencode(l11111l1l11l1_mS_({l1l11l11l1_mS_ (u"࠭ࡡ࡭ࡤࡸࡱࡎࡺࡉࡥࠩઍ"):l1ll1ll1ll11l1_mS_[0],l1l11l11l1_mS_ (u"ࠧࡢࡴࡷ࡭ࡸࡺࠧ઎"):artist,l1l11l11l1_mS_ (u"ࠨࡰࡤࡱࡪ࠭એ"):name}))
                out.append({l1l11l11l1_mS_ (u"ࠩࡷ࡭ࡹࡲࡥࠨઐ"):title,l1l11l11l1_mS_ (u"ࠪ࡬ࡷ࡫ࡦࠨઑ"):href,l1l11l11l1_mS_ (u"ࠫ࡮ࡳࡧࠨ઒"):l11l1l1l11l1_mS_[0] if l11l1l1l11l1_mS_ else l1l11l11l1_mS_ (u"ࠬ࠭ઓ")})
    return out
def l1lll11l1l11l1_mS_(filename=l1l11l11l1_mS_ (u"࠭ࡡࡳࡶ࡬ࡷࡹࡹࡌࡪࡵࡷ࠲࡯ࡹ࡯࡯ࠩઔ")):
    url= l1l11l11l1_mS_ (u"ࠢࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡲࡻࡳࡪࡺ࡫ࡹࡧ࠴ࡣࡰ࡯࠲ࡧࡦࡩࡨࡦ࠱ࠥક")+filename
    data = l11ll11ll11l1_mS_(url)
    l1lll11lll11l1_mS_=[]
    l1l1l11ll11l1_mS_ = data.get(l1l11l11l1_mS_ (u"ࠨࡣࡵࡸ࡮ࡹࡴࡴࠩખ"),{}).get(l1l11l11l1_mS_ (u"ࠩࡤࡶࡹ࡯ࡳࡵࠩગ"),[])
    for obj in l1l1l11ll11l1_mS_:
        l1lll1l1ll11l1_mS_={}
        l1lll1l1ll11l1_mS_[l1l11l11l1_mS_ (u"ࠪࡲࡦࡳࡥࠨઘ")] = obj.get(l1l11l11l1_mS_ (u"ࠫࡳࡧ࡭ࡦࠩઙ"),l1l11l11l1_mS_ (u"ࠬ࠭ચ"));
        l1lll1l1ll11l1_mS_[l1l11l11l1_mS_ (u"࠭ࡡࡳࡶ࡬ࡷࡹࡔࡡ࡮ࡧࠪછ")] = obj.get(l1l11l11l1_mS_ (u"ࠧ࡯ࡣࡰࡩࠬજ"),l1l11l11l1_mS_ (u"ࠨࠩઝ"))
        l1lll1l1ll11l1_mS_[l1l11l11l1_mS_ (u"ࠩࡷ࡭ࡹࡲࡥࠨઞ")] = obj.get(l1l11l11l1_mS_ (u"ࠪࡲࡦࡳࡥࠨટ"),l1l11l11l1_mS_ (u"ࠫࠬઠ"))
        l1lll1l1ll11l1_mS_[l1l11l11l1_mS_ (u"ࠬ࡮ࡲࡦࡨࠪડ")] = obj.get(l1l11l11l1_mS_ (u"࠭࡮ࡢ࡯ࡨࠫઢ"),l1l11l11l1_mS_ (u"ࠧࠨણ"))
        l1lll1l1ll11l1_mS_[l1l11l11l1_mS_ (u"ࠨ࡫ࡰ࡫ࠬત")] = obj.get(l1l11l11l1_mS_ (u"ࠩ࡬ࡱࡦ࡭ࡥࠨથ"),[{}])[-1].get(l1l11l11l1_mS_ (u"ࠪࡍ࠸ࡘ࡬ࡦࡊࡔࡁࡂ࠭દ").decode(l1l11l11l1_mS_ (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫધ")),l1l11l11l1_mS_ (u"ࠬ࠭ન"))
        l1lll11lll11l1_mS_.append(l1lll1l1ll11l1_mS_)
    return l1lll11lll11l1_mS_
def l1ll11ll1l11l1_mS_(artist):
    url=l1l11l11l1_mS_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡶࡸࡲࡪࡹ࠮ࡢࡲࡳࡰࡪ࠴ࡣࡰ࡯࠲ࡷࡪࡧࡲࡤࡪࡂࡸࡪࡸ࡭࠾ࠧࡶࠪࡪࡴࡴࡪࡶࡼࡁࡦࡲࡢࡶ࡯ࠩࡰ࡮ࡳࡩࡵ࠿࠵࠴ࠬ઩")%urllib.quote(artist)
    data = l11ll11ll11l1_mS_(url)
    l11l1ll1l11l1_mS_=[]
    for val in data.get(l1l11l11l1_mS_ (u"ࠧࡳࡧࡶࡹࡱࡺࡳࠨપ")):
        l1lll111ll11l1_mS_={}
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠨࡰࡤࡱࡪ࠭ફ")] = val.get(l1l11l11l1_mS_ (u"ࠩࡦࡳࡱࡲࡥࡤࡶ࡬ࡳࡳࡉࡥ࡯ࡵࡲࡶࡪࡪࡎࡢ࡯ࡨࠫબ"),l1l11l11l1_mS_ (u"ࠪࠫભ"))
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠫ࡮ࡳࡧࠨમ")] = val.get(l1l11l11l1_mS_ (u"ࠬࡧࡲࡵࡹࡲࡶࡰ࡛ࡲ࡭࠳࠳࠴ࠬય"));
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"࠭ࡡࡳࡶ࡬ࡷࡹࡔࡡ࡮ࡧࠪર")] = val.get(l1l11l11l1_mS_ (u"ࠧࡢࡴࡷ࡭ࡸࡺࡎࡢ࡯ࡨࠫ઱"),l1l11l11l1_mS_ (u"ࠨࠩલ")).replace(l1l11l11l1_mS_ (u"ࠤ࡙ࡥࡷ࡯࡯ࡶࡵࠣࡅࡷࡺࡩࡴࡶࡶࠦળ"), l1l11l11l1_mS_ (u"ࠥࠦ઴"));
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠫ࡮ࡪࠧવ")] = val.get(l1l11l11l1_mS_ (u"ࠬࡩ࡯࡭࡮ࡨࡧࡹ࡯࡯࡯ࡋࡧࠫશ"));
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"࠭ࡡࡳࡶ࡬ࡷࡹࡏࡤࠨષ")] = val.get(l1l11l11l1_mS_ (u"ࠧࡢࡴࡷ࡭ࡸࡺࡉࡥࠩસ"));
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠨࡲࡸࡦࡱ࡯ࡳࡩࡧࡧࠫહ")] = val.get(l1l11l11l1_mS_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧࡇࡥࡹ࡫ࠧ઺"),l1l11l11l1_mS_ (u"ࠪࠫ઻")).split(l1l11l11l1_mS_ (u"࡙ࠦࠨ઼"))[0];
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠬࡺࡲࡢࡥ࡮ࡇࡴࡻ࡮ࡵࠩઽ")] = val.get(l1l11l11l1_mS_ (u"࠭ࡴࡳࡣࡦ࡯ࡈࡵࡵ࡯ࡶࠪા"))
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠧࡱ࡮ࡲࡸࠬિ")] = l1lll111ll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠨࡰࡤࡱࡪ࠭ી"),l1l11l11l1_mS_ (u"ࠩࠪુ")) + l1l11l11l1_mS_ (u"ࠥࠤࡧࡿࠠࠣૂ") + l1lll111ll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠫࡦࡸࡴࡪࡵࡷࡒࡦࡳࡥࠨૃ"),l1l11l11l1_mS_ (u"ࠬ࠭ૄ")) +l1l11l11l1_mS_ (u"࠭࡜࡯ࡲࡸࡦࡱ࡯ࡳࡩࡧࡧࠤ࠿࠭ૅ")+l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠧࡱࡷࡥࡰ࡮ࡹࡨࡦࡦࠪ૆")]
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠨࡲ࡯ࡳࡹ࠭ે")] += l1l11l11l1_mS_ (u"ࠩ࡟ࡲ࡙ࡸࡡࡤ࡭ࡶ࠾ࠥࠫࡤࠨૈ") %val.get(l1l11l11l1_mS_ (u"ࠪࡸࡷࡧࡣ࡬ࡅࡲࡹࡳࡺࠧૉ")) if val.get(l1l11l11l1_mS_ (u"ࠫࡹࡸࡡࡤ࡭ࡆࡳࡺࡴࡴࠨ૊")) else l1l11l11l1_mS_ (u"ࠬ࠭ો")
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"࠭ࡰ࡭ࡱࡷࠫૌ")] += l1l11l11l1_mS_ (u"ࠧ࡝ࡰࡦࡳࡵࡿࡲࡪࡩ࡫ࡸ࠿ࠦࠥࡴ્ࠩ") %val.get(l1l11l11l1_mS_ (u"ࠨࡥࡲࡴࡾࡸࡩࡨࡪࡷࠫ૎")) if val.get(l1l11l11l1_mS_ (u"ࠩࡦࡳࡵࡿࡲࡪࡩ࡫ࡸࠬ૏")) else l1l11l11l1_mS_ (u"ࠪࠫૐ")
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠫࡵࡲ࡯ࡵࠩ૑")] += l1l11l11l1_mS_ (u"ࠬࡢ࡮ࡳࡧ࡯ࡩࡦࡹࡥࡅࡣࡷࡩ࠿ࠦࠥࡴࠩ૒") %val.get(l1l11l11l1_mS_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫ࡄࡢࡶࡨࠫ૓")) if val.get(l1l11l11l1_mS_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥࡅࡣࡷࡩࠬ૔")) else l1l11l11l1_mS_ (u"ࠨࠩ૕")
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ૖")] = l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠪࡲࡦࡳࡥࠨ૗")]
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠫࡨࡵࡤࡦࠩ૘")]=l1l11l11l1_mS_ (u"ࠬࢁࡽࠡࡶࡵࡥࡨࡱࡳࠨ૙").format( l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"࠭ࡴࡳࡣࡦ࡯ࡈࡵࡵ࡯ࡶࠪ૚")] )
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠧࡩࡴࡨࡪࠬ૛")]=urllib.urlencode(l11111l1l11l1_mS_({l1l11l11l1_mS_ (u"ࠨࡣ࡯ࡦࡺࡳࡉࡵࡋࡧࠫ૜"):l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠩ࡬ࡨࠬ૝")],l1l11l11l1_mS_ (u"ࠪࡥࡷࡺࡩࡴࡶࠪ૞"):l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠫࡦࡸࡴࡪࡵࡷࡒࡦࡳࡥࠨ૟")],l1l11l11l1_mS_ (u"ࠬࡴࡡ࡮ࡧࠪૠ"):l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"࠭࡮ࡢ࡯ࡨࠫૡ")]}))
        if val.get(l1l11l11l1_mS_ (u"ࠧࡸࡴࡤࡴࡵ࡫ࡲࡕࡻࡳࡩࠬૢ"))==l1l11l11l1_mS_ (u"ࠨࡥࡲࡰࡱ࡫ࡣࡵ࡫ࡲࡲࠬૣ"):
            l11l1ll1l11l1_mS_.append(l1lll111ll11l1_mS_)
    return l11l1ll1l11l1_mS_
def l111l1l1l11l1_mS_(filename=l1l11l11l1_mS_ (u"ࠩࡤࡰࡧࡻ࡭ࡴࡎ࡬ࡷࡹ࠴ࡪࡴࡱࡱࠫ૤"),l1ll1l1lll11l1_mS_=True):
    url= l1l11l11l1_mS_ (u"ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮࡮ࡷࡶ࡭ࡽ࡮ࡵࡣ࠰ࡦࡳࡲ࠵ࡣࡢࡥ࡫ࡩ࠴ࠨ૥")+filename
    data = l1111l1l11l1_mS_(url)
    out=[]
    if (data):
        data=json.loads(data)
        for k,v in data.items():
            for l1lll1l1ll11l1_mS_ in v.get(l1l11l11l1_mS_ (u"ࠫࡪࡴࡴࡳࡻࠪ૦"),[]):
                name = l1lll1l1ll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠬ࡯࡭࠻ࡰࡤࡱࡪ࠭૧"),l1l11l11l1_mS_ (u"࠭ࠧ૨")).get(l1l11l11l1_mS_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭૩"),l1l11l11l1_mS_ (u"ࠨࠩ૪"))
                artist = l1lll1l1ll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠩ࡬ࡱ࠿ࡧࡲࡵ࡫ࡶࡸࠬ૫"),l1l11l11l1_mS_ (u"ࠪࠫ૬")).get(l1l11l11l1_mS_ (u"ࠫࡱࡧࡢࡦ࡮ࠪ૭"),l1l11l11l1_mS_ (u"ࠬ࠭૮"))
                l1111111l11l1_mS_ =  l1lll1l1ll11l1_mS_.get(l1l11l11l1_mS_ (u"࠭ࡩ࡮࠼࡬ࡸࡪࡳࡃࡰࡷࡱࡸࠬ૯"),l1l11l11l1_mS_ (u"ࠧࠨ૰")).get(l1l11l11l1_mS_ (u"ࠨ࡮ࡤࡦࡪࡲࠧ૱"),l1l11l11l1_mS_ (u"ࠩࠪ૲"))
                l111l111l11l1_mS_  =  l1lll1l1ll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠪ࡭ࡲࡀࡲࡦ࡮ࡨࡥࡸ࡫ࡄࡢࡶࡨࠫ૳"),l1l11l11l1_mS_ (u"ࠫࠬ૴")).get(l1l11l11l1_mS_ (u"ࠬࡲࡡࡣࡧ࡯ࠫ૵"),l1l11l11l1_mS_ (u"࠭ࠧ૶")).split(l1l11l11l1_mS_ (u"ࠢࡕࠤ૷"))[0]
                l111ll11l11l1_mS_ = 		l1lll1l1ll11l1_mS_[l1l11l11l1_mS_ (u"ࠣ࡫ࡰ࠾࡮ࡳࡡࡨࡧࠥ૸")][-1].get(l1l11l11l1_mS_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨૹ"),l1l11l11l1_mS_ (u"ࠪࠫૺ"))
                l1ll1ll1ll11l1_mS_ = l1lll1l1ll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠦ࡮ࡪࠢૻ"),{}).get(l1l11l11l1_mS_ (u"ࠬࡧࡴࡵࡴ࡬ࡦࡺࡺࡥࡴࠩૼ"),{}).get(l1l11l11l1_mS_ (u"ࠨࡩ࡮࠼࡬ࡨࠧ૽"),l1l11l11l1_mS_ (u"ࠧࠨ૾"))
                href=urllib.urlencode(l11111l1l11l1_mS_({l1l11l11l1_mS_ (u"ࠨࡣ࡯ࡦࡺࡳࡉࡵࡋࡧࠫ૿"):l1ll1ll1ll11l1_mS_,l1l11l11l1_mS_ (u"ࠩࡤࡶࡹ࡯ࡳࡵࠩ଀"):artist,l1l11l11l1_mS_ (u"ࠪࡲࡦࡳࡥࠨଁ"):name}))
                l11lll1l11l1_mS_=l1l11l11l1_mS_ (u"ࠫࡆࡸࡴࡪࡵࡷ࠾ࠥࡡࡂ࡞ࠧࡶ࡟࠴ࡈ࡝࡝ࡰࡑࡥࡲ࡫࠺ࠡ࡝ࡅࡡࠪࡹ࡛࠰ࡄࡠࡠࡳ࡚ࡲࡢࡥ࡮ࡷ࠿࡛ࠦࡃ࡟ࠨࡷࡠ࠵ࡂ࡞࡞ࡱࠫଂ")%(artist,name,l1111111l11l1_mS_)
                out.append({l1l11l11l1_mS_ (u"ࠬࡺࡩࡵ࡮ࡨࠫଃ"):name,l1l11l11l1_mS_ (u"࠭ࡩ࡮ࡩࠪ଄"):l111ll11l11l1_mS_,l1l11l11l1_mS_ (u"ࠧࡱ࡮ࡲࡸࠬଅ"):l11lll1l11l1_mS_,l1l11l11l1_mS_ (u"ࠨࡪࡵࡩ࡫࠭ଆ"):href})
    return out
def l1ll1ll11l11l1_mS_(albumItId,artist,name):
    if albumItId:
        return l111l1lll11l1_mS_(albumItId)
def l111lll1l11l1_mS_(l1111llll11l1_mS_):
    try:
        m, s = divmod(l1111llll11l1_mS_, 60)
        h, m = divmod(m, 60)
        if h>0:
            l1lll1llll11l1_mS_= l1l11l11l1_mS_ (u"ࠤࠨࡨ࠿ࠫ࠰࠳ࡦ࠽ࠩ࠵࠸ࡤࠣଇ") % (h, m, s)
        else:
            l1lll1llll11l1_mS_= l1l11l11l1_mS_ (u"ࠥࠩ࠵࠸ࡤ࠻ࠧ࠳࠶ࡩࠨଈ") % ( m, s)
    except:
        l1lll1llll11l1_mS_=l1l11l11l1_mS_ (u"ࠫࠬଉ")
    return l1lll1llll11l1_mS_
def l111l1lll11l1_mS_(albumItId=l1l11l11l1_mS_ (u"ࠬ࠷࠱࠹࠺࠷࠼࠾࠾࠱࠸ࠩଊ")):
    url = l1l11l11l1_mS_ (u"ࠨࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡶࡸࡲࡪࡹ࠮ࡢࡲࡳࡰࡪ࠴ࡣࡰ࡯࠲ࡰࡴࡵ࡫ࡶࡲࡂ࡭ࡩࡃࠢଋ") + albumItId + l1l11l11l1_mS_ (u"ࠢࠧࡧࡱࡸ࡮ࡺࡹ࠾ࡵࡲࡲ࡬ࠨଌ");
    data = l1111l1l11l1_mS_(url)
    l11ll111l11l1_mS_ = []
    data = json.loads(data)
    for val in data.get(l1l11l11l1_mS_ (u"ࠨࡴࡨࡷࡺࡲࡴࡴࠩ଍")):
        l1lll111ll11l1_mS_={}
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠩࡱࡥࡲ࡫ࠧ଎")] = val.get(l1l11l11l1_mS_ (u"ࠪࡸࡷࡧࡣ࡬ࡐࡤࡱࡪ࠭ଏ"),l1l11l11l1_mS_ (u"ࠫࠬଐ"))
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠬ࡯࡭ࡨࠩ଑")] = val.get(l1l11l11l1_mS_ (u"࠭ࡡࡳࡶࡺࡳࡷࡱࡕࡳ࡮࠴࠴࠵࠭଒"));
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠧࡢࡴࡷ࡭ࡸࡺࡎࡢ࡯ࡨࠫଓ")] = val.get(l1l11l11l1_mS_ (u"ࠨࡣࡵࡸ࡮ࡹࡴࡏࡣࡰࡩࠬଔ"),l1l11l11l1_mS_ (u"ࠩࠪକ")).replace(l1l11l11l1_mS_ (u"࡚ࠥࡦࡸࡩࡰࡷࡶࠤࡆࡸࡴࡪࡵࡷࡷࠧଖ"), l1l11l11l1_mS_ (u"ࠦࠧଗ"));
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠬࡺࡲࡢࡥ࡮ࡒࡺࡳࡢࡦࡴࠪଘ")]=val.get(l1l11l11l1_mS_ (u"࠭ࡴࡳࡣࡦ࡯ࡓࡻ࡭ࡣࡧࡵࠫଙ"),0)
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩଚ")]=int(val.get(l1l11l11l1_mS_ (u"ࠨࡶࡵࡥࡨࡱࡔࡪ࡯ࡨࡑ࡮ࡲ࡬ࡪࡵࠪଛ"),l1l11l11l1_mS_ (u"ࠩ࠳ࠫଜ"))) / 1000
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠪ࡭ࡩ࠭ଝ")] = albumItId;
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠫࡵࡻࡢ࡭࡫ࡶ࡬ࡪࡪࠧଞ")] = val.get(l1l11l11l1_mS_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪࡊࡡࡵࡧࠪଟ"),l1l11l11l1_mS_ (u"࠭ࠧଠ")).split(l1l11l11l1_mS_ (u"ࠢࡕࠤଡ"))[0];
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠨࡶࡵࡥࡨࡱࡃࡰࡷࡱࡸࠬଢ")] = val.get(l1l11l11l1_mS_ (u"ࠩࡷࡶࡦࡩ࡫ࡄࡱࡸࡲࡹ࠭ଣ"))
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠪࡴࡱࡵࡴࠨତ")] = l1lll111ll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠫࡳࡧ࡭ࡦࠩଥ"),l1l11l11l1_mS_ (u"ࠬ࠭ଦ")) + l1l11l11l1_mS_ (u"ࠨࠠࡣࡻࠣࠦଧ") + l1lll111ll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠧࡢࡴࡷ࡭ࡸࡺࡎࡢ࡯ࡨࠫନ"),l1l11l11l1_mS_ (u"ࠨࠩ଩")) +l1l11l11l1_mS_ (u"ࠩ࡟ࡲࡵࡻࡢ࡭࡫ࡶ࡬ࡪࡪ࠺ࠨପ")+l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠪࡴࡺࡨ࡬ࡪࡵ࡫ࡩࡩ࠭ଫ")]
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠫࡹࡿࡰࡦࠩବ")] = l1l11l11l1_mS_ (u"ࠧࡧࠢଭ");
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"࠭ࡴࡪࡶ࡯ࡩࠬମ")] = l1l11l11l1_mS_ (u"ࠧࠦ࠰࠵ࡨࠥ࠳ࠠࠦࡵࠪଯ")%( l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠨࡶࡵࡥࡨࡱࡎࡶ࡯ࡥࡩࡷ࠭ର")],l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠩࡱࡥࡲ࡫ࠧ଱")] )
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠪࡧࡴࡪࡥࠨଲ")]=l111lll1l11l1_mS_(l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭ଳ")])
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠬ࡮ࡲࡦࡨࠪ଴")]=urllib.urlencode(l11111l1l11l1_mS_({l1l11l11l1_mS_ (u"࠭ࡡ࡭ࡤࡸࡱࡎࡺࡉࡥࠩଵ"):albumItId,l1l11l11l1_mS_ (u"ࠧࡢࡴࡷ࡭ࡸࡺࠧଶ"):l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠨࡣࡵࡸ࡮ࡹࡴࡏࡣࡰࡩࠬଷ")],l1l11l11l1_mS_ (u"ࠩࡱࡥࡲ࡫ࠧସ"):l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠪࡲࡦࡳࡥࠨହ")]}))
        if val.get(l1l11l11l1_mS_ (u"ࠫࡼࡸࡡࡱࡲࡨࡶ࡙ࡿࡰࡦࠩ଺"))==l1l11l11l1_mS_ (u"ࠬࡺࡲࡢࡥ࡮ࠫ଻"):
            l11ll111l11l1_mS_.append(l1lll111ll11l1_mS_)
    return l11ll111l11l1_mS_
l1llll111l11l1_mS_=l1l11l11l1_mS_ (u"ࠨࡁࡊࡼࡤࡗࡾࡈࡢࡘࡊ࡙࡫ࡕࡩ࠸ࡶࡺࡏࡴࡩࡋࡴࡴࡤࡖࡖࡊࡶࡨࡆࡗࡌ࡫ࡈ࠺ࡢࡉࡅ࠷଼ࠦ")
def l11ll11ll11l1_mS_(u):
    headers = { l1l11l11l1_mS_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫଽ"): l1l1ll11l11l1_mS_, l1l11l11l1_mS_ (u"ࠨࡴࡨࡪࡪࡸࡥࡳࠩା"): l1l11l11l1_mS_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴࡭ࡶࡵ࡬ࡼ࡭ࡻࡢ࠯ࡥࡲࡱ࠴࠭ି") }
    try:
        l1l11111l11l1_mS_ = urllib2.Request(u, None, headers)
        l11lll11l11l1_mS_ = urllib2.urlopen(l1l11111l11l1_mS_)
        data = json.load(l11lll11l11l1_mS_)
    except:
        data={}
    return data
def l111ll1ll11l1_mS_(l1ll11l11l11l1_mS_=l1l11l11l1_mS_ (u"ࠪࡔ࡙࠺ࡍ࠲࠺ࡖࠫୀ")):
    res = 0;
    l1lll1l11l11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠫ࠭ࡢࡤࠬࠫࡋࠫୁ"),l1ll11l11l11l1_mS_)
    mm = re.findall(l1l11l11l1_mS_ (u"ࠬ࠮࡜ࡥ࠭ࠬࡑࠬୂ"),l1ll11l11l11l1_mS_)
    l1ll1l11ll11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"࠭ࠨ࡝ࡦ࠮࠭ࡘ࠭ୃ"),l1ll11l11l11l1_mS_)
    res += int(l1lll1l11l11l1_mS_[0])*3600 if l1lll1l11l11l1_mS_ else 0
    res += int(mm[0])*60 if mm else 0
    res += int(l1ll1l11ll11l1_mS_[0]) if l1ll1l11ll11l1_mS_ else 0
    return res;
def l1llll1l1l11l1_mS_(name,artist,**args):
    l1ll1l111l11l1_mS_((l1l11l11l1_mS_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡖࡪࡦࡨࡳࠬୄ"),name,artist))
    l1lllll11l11l1_mS_ = []
    u = l1l11l11l1_mS_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡧࡰࡱࡪࡰࡪࡧࡰࡪࡵ࠱ࡧࡴࡳ࠯ࡺࡱࡸࡸࡺࡨࡥ࠰ࡸ࠶࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡵࡧࡲࡵ࠿࡬ࡨࠫࡷ࠽ࠨ୅") + urllib.quote(name + l1l11l11l1_mS_ (u"ࠤࠣࡦࡾࠦࠢ୆") + artist) + l1l11l11l1_mS_ (u"ࠪࠪࡲࡧࡸࡓࡧࡶࡹࡱࡺࡳ࠾࠳࠳ࠪࡹࡿࡰࡦ࠿ࡹ࡭ࡩ࡫࡯ࠧ࡭ࡨࡽࡂ࠭େ") + l1llll111l11l1_mS_;
    data=l11ll11ll11l1_mS_(u)
    if data.has_key(l1l11l11l1_mS_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠪୈ")):
        l1ll1lllll11l1_mS_ = l1l11l11l1_mS_ (u"ࠬ࠲ࠧ୉").join([d.get(l1l11l11l1_mS_ (u"࠭ࡩࡥࠩ୊"),{}).get(l1l11l11l1_mS_ (u"ࠧࡷ࡫ࡧࡩࡴࡏࡤࠨୋ"),l1l11l11l1_mS_ (u"ࠨࠩୌ")) for d in data[l1l11l11l1_mS_ (u"ࠩ࡬ࡸࡪࡳࡳࠨ୍")]])
        u2 = l1l11l11l1_mS_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡲࡳ࡬ࡲࡥࡢࡲ࡬ࡷ࠳ࡩ࡯࡮࠱ࡼࡳࡺࡺࡵࡣࡧ࠲ࡺ࠸࠵ࡶࡪࡦࡨࡳࡸࡅࡰࡢࡴࡷࡁࡨࡵ࡮ࡵࡧࡱࡸࡉ࡫ࡴࡢ࡫࡯ࡷ࠱ࡹࡴࡢࡶ࡬ࡷࡹ࡯ࡣࡴ࠮ࡶࡲ࡮ࡶࡰࡦࡶࠩ࡭ࡩࡃࠧ୎") + l1ll1lllll11l1_mS_ + l1l11l11l1_mS_ (u"ࠫࠫࡱࡥࡺ࠿ࠪ୏") + l1llll111l11l1_mS_;
        items = l11ll11ll11l1_mS_(u2)
        for l1l1llll11l1_mS_ in items.get(l1l11l11l1_mS_ (u"ࠬ࡯ࡴࡦ࡯ࡶࠫ୐"),[]):
            l1lll1ll1l11l1_mS_ = l111ll1ll11l1_mS_(l1l1llll11l1_mS_[l1l11l11l1_mS_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡄࡦࡶࡤ࡭ࡱࡹࠧ୑")][l1l11l11l1_mS_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ୒")]);
            l11l1l1l11l1_mS_ = l1l1llll11l1_mS_[l1l11l11l1_mS_ (u"ࠨࡵࡱ࡭ࡵࡶࡥࡵࠩ୓")][l1l11l11l1_mS_ (u"ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡸ࠭୔")].get(l1l11l11l1_mS_ (u"ࠪ࡬࡮࡭ࡨࠨ୕")).get(l1l11l11l1_mS_ (u"ࠫࡺࡸ࡬ࠨୖ"))
            if (l1lll1ll1l11l1_mS_ < 900 and l1lll1ll1l11l1_mS_ > 60):
                l1111l1ll11l1_mS_={l1l11l11l1_mS_ (u"ࠬ࡯ࡤࠨୗ"):l1l1llll11l1_mS_[l1l11l11l1_mS_ (u"࠭ࡩࡥࠩ୘")],l1l11l11l1_mS_ (u"ࠧࡪ࡯ࡪࠫ୙"):l11l1l1l11l1_mS_, l1l11l11l1_mS_ (u"ࠣࡶ࡬ࡸࡱ࡫ࠢ୚"): l1l1llll11l1_mS_[l1l11l11l1_mS_ (u"ࠩࡶࡲ࡮ࡶࡰࡦࡶࠪ୛")][l1l11l11l1_mS_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩଡ଼")],l1l11l11l1_mS_ (u"ࠫࡵࡲ࡯ࡵࠩଢ଼"):l1l1llll11l1_mS_[l1l11l11l1_mS_ (u"ࠬࡹ࡮ࡪࡲࡳࡩࡹ࠭୞")][l1l11l11l1_mS_ (u"࠭ࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠫୟ")],l1l11l11l1_mS_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩୠ"):l1lll1ll1l11l1_mS_}
                l1111l1ll11l1_mS_.update(l1l1llll11l1_mS_[l1l11l11l1_mS_ (u"ࠨࡵࡷࡥࡹ࡯ࡳࡵ࡫ࡦࡷࠬୡ")])
                l1lllll11l11l1_mS_.append(l1111l1ll11l1_mS_)
    return l1lllll11l11l1_mS_
def l11111lll11l1_mS_(l1llll11ll11l1_mS_=l1l11l11l1_mS_ (u"ࠩࠪୢ")):
    if l1llll11ll11l1_mS_==l1l11l11l1_mS_ (u"ࠪࡸࡷࡵࡪ࡬ࡣࠪୣ"):
        return l111111ll11l1_mS_()
    elif l1llll11ll11l1_mS_==l1l11l11l1_mS_ (u"ࠫࡷࡳࡦࡧ࡯ࠪ୤"):
        return l1lllll1ll11l1_mS_()
    return ([],l1l11l11l1_mS_ (u"ࠬ࠭୥"))
def l111111ll11l1_mS_():
    l11l11lll11l1_mS_=l1l11l11l1_mS_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡬ࡱ࠵࠱ࡴࡴࡲࡳ࡬࡫ࡨࡶࡦࡪࡩࡰ࠰ࡳࡰ࠴ࡴ࡯ࡵࡱࡺࡥࡳ࡯ࡡ࠰ࠩ୦")
    content = l1111l1l11l1_mS_(l11l11lll11l1_mS_)
    ids = [(a.start(), a.end()) for a in re.finditer(l1l11l11l1_mS_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡨ࡯ࡹࡐࡲࡸࡴࡽࡡ࡯࡫ࡨࠦࡃ࠭୧"), content)]
    ids.append( (-1,-1) )
    l11ll111l11l1_mS_=[]
    i=0
    l1ll1lll1l11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨ࡮ࡶ࡯ࡨࡶࡌࡲ࡯ࡴࡱࡺࡥࡳ࡯ࡡࠣࡀ࡞ࡠࡸࡢ࡮࡞ࠬ࠿ࡷࡵࡧ࡮ࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡶࡨࡼࡹࠨ࠾ࠩ࠰࠮ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃࡂࡳࡱࡣࡱࠤࡨࡲࡡࡴࡵࡀࠦࡳࡻ࡭ࡣࡧࡵࠦࡃ࠮࡜ࡥ࠭ࠬࡀ࠴ࡹࡰࡢࡰࡁ࡟ࡡࡹ࡜࡯࡟࠭ࡀࡸࡶࡡ࡯ࠢࡦࡰࡦࡹࡳ࠾ࠤࡽࡈࡳ࡯ࡡࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ୨"),content)
    l1ll1lll1l11l1_mS_ = l1l11l11l1_mS_ (u"ࠩࠣࠫ୩").join(l1ll1lll1l11l1_mS_[0]) if l1ll1lll1l11l1_mS_ else l1l11l11l1_mS_ (u"ࠪࡒࡴࡺ࡯ࡸࡣࡱ࡭ࡪࠦࡰࡳࡱࡪࡶࡦࡳࡵࠡ࠵ࠪ୪")
    l1111ll1l11l1_mS_ = content[ ids[i][1]:ids[i+1][0] ]
    l1ll11l1ll11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠫࡁࡺࡲ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡵࡂࠬ୫"),l1111ll1l11l1_mS_,re.DOTALL)
    for idx,l1ll1l11l1_mS_ in enumerate(l1ll11l1ll11l1_mS_[1:]):
        l1ll11llll11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢ࠰ࡹࡼ࡯ࡴࡴࡡࡸࡥࡤ࠳࠳࠱࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ୬"),l1ll1l11l1_mS_)
        l1llllll1l11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣ࠱ࡸࡸࡼࡵࡲ࠰࠰࠮ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ୭"),l1ll1l11l1_mS_)
        l11l1l1l11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ୮"),l1ll1l11l1_mS_)
        if l1ll11llll11l1_mS_ and l1llllll1l11l1_mS_:
            l1lll111ll11l1_mS_={l1l11l11l1_mS_ (u"ࠨࡣࡵࡸ࡮ࡹࡴࡏࡣࡰࡩࠬ୯"):l1ll11llll11l1_mS_[0].strip(),l1l11l11l1_mS_ (u"ࠩࡱࡥࡲ࡫ࠧ୰"):l1llllll1l11l1_mS_[0].strip()}
            l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩୱ")] = l1l11l11l1_mS_ (u"ࠫࠪ࠴࠲ࡥ࠰ࠣࠩࡸࠦ࠭ࠡࠧࡶࠫ୲")%(idx+1,l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠬࡧࡲࡵ࡫ࡶࡸࡓࡧ࡭ࡦࠩ୳")],l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"࠭࡮ࡢ࡯ࡨࠫ୴")])
            l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠧࡩࡴࡨࡪࠬ୵")]=urllib.urlencode(l11111l1l11l1_mS_({l1l11l11l1_mS_ (u"ࠨࡣ࡯ࡦࡺࡳࡉࡵࡋࡧࠫ୶"):None,l1l11l11l1_mS_ (u"ࠩࡤࡶࡹ࡯ࡳࡵࠩ୷"):l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠪࡥࡷࡺࡩࡴࡶࡑࡥࡲ࡫ࠧ୸")],l1l11l11l1_mS_ (u"ࠫࡳࡧ࡭ࡦࠩ୹"):l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠬࡴࡡ࡮ࡧࠪ୺")]}))
            l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"࠭ࡩ࡮ࡩࠪ୻")]=l11l1l1l11l1_mS_[0] if l11l1l1l11l1_mS_ else l1l11l11l1_mS_ (u"ࠧࠨ୼")
            l11ll111l11l1_mS_.append(l1lll111ll11l1_mS_)
    return l11ll111l11l1_mS_,l1ll1lll1l11l1_mS_
def l1lllll1ll11l1_mS_():
    l11l11lll11l1_mS_=l1l11l11l1_mS_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡸ࡭ࡧ࠰ࡩࡱ࠴ࡧࡵ࠰ࡲࡲࡴࡱ࡯ࡳࡵࡣ࠱࡬ࡹࡳ࡬ࠨ୽")
    content = l1111l1l11l1_mS_(l11l11lll11l1_mS_)
    content = content.decode(l1l11l11l1_mS_ (u"ࠩ࡬ࡷࡴ࠳࠸࠹࠷࠼࠱࠷࠭୾")).encode(l1l11l11l1_mS_ (u"ࠪࡹࡹ࡬࠭࠹ࠩ୿"))
    l11ll111l11l1_mS_=[]
    l1ll1lll1l11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡳࡳࡵࡲࡩࡴࡶࡤ࠱ࡳࡵࡴࡰࡹࡤࡲ࡮࡫࠭࡯ࡷࡰࡩࡷࠨ࠾࡜࡞ࡶࡠࡳࡣࠪࠩ࠰࠮ࡃ࠮ࡂࡳࡱࡣࡱࠤࡨࡲࡡࡴࡵࡀࠦࡵࡵࡰ࡭࡫ࡶࡸࡦ࠳ࡺࡥࡰ࡬ࡥࠧࡄࠨ࠯࠭ࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ஀"),content)
    l1ll1lll1l11l1_mS_ = l1l11l11l1_mS_ (u"ࠬ࠭஁").join(l1ll1lll1l11l1_mS_[0]) if l1ll1lll1l11l1_mS_ else l1l11l11l1_mS_ (u"࠭ࡎࡰࡶࡲࡻࡦࡴࡩࡦࠢࡕࡑࡋࠦࡆࡎࠩஂ")
    l111ll11l11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡶ࡯ࡱ࡮࡬ࡷࡹࡧ࠭ࡪ࡯ࡤ࡫ࡪࠨ࠾࠽ࡣ࠱࠯ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪஃ"),content,re.DOTALL|re.I)
    title = re.findall(l1l11l11l1_mS_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡰࡰࡲ࡯࡭ࡸࡺࡡ࠮ࡣࡵࡸ࡮ࡹࡴ࠮ࡶ࡬ࡸࡱ࡫ࠢ࠿࠾ࡤ࡟ࡣࡄ࡝ࠫࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂ࠳࠱࠿࠽ࡣ࡞ࡢࡃࡣࠪ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࠩ஄"),content,re.DOTALL|re.I)
    idx=0
    for artist,name in title:
        l1ll11llll11l1_mS_ = artist.strip()
        l1llllll1l11l1_mS_ = name.strip()
        l11l1l1l11l1_mS_ = l111ll11l11l1_mS_[idx].split(l1l11l11l1_mS_ (u"ࠩࡂࠫஅ"))[0] if idx<len(l111ll11l11l1_mS_) else l1l11l11l1_mS_ (u"ࠪࠫஆ")
        l1lll111ll11l1_mS_={l1l11l11l1_mS_ (u"ࠫࡦࡸࡴࡪࡵࡷࡒࡦࡳࡥࠨஇ"):l1ll11llll11l1_mS_,l1l11l11l1_mS_ (u"ࠬࡴࡡ࡮ࡧࠪஈ"):l1llllll1l11l1_mS_}
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"࠭ࡴࡪࡶ࡯ࡩࠬஉ")] = l1l11l11l1_mS_ (u"ࠧࠦ࠰࠵ࡨ࠳ࠦࠥࡴࠢ࠰ࠤࠪࡹࠧஊ")%(idx+1,l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠨࡣࡵࡸ࡮ࡹࡴࡏࡣࡰࡩࠬ஋")],l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠩࡱࡥࡲ࡫ࠧ஌")])
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠪ࡬ࡷ࡫ࡦࠨ஍")]=urllib.urlencode(l11111l1l11l1_mS_({l1l11l11l1_mS_ (u"ࠫࡦࡲࡢࡶ࡯ࡌࡸࡎࡪࠧஎ"):None,l1l11l11l1_mS_ (u"ࠬࡧࡲࡵ࡫ࡶࡸࠬஏ"):l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"࠭ࡡࡳࡶ࡬ࡷࡹࡔࡡ࡮ࡧࠪஐ")],l1l11l11l1_mS_ (u"ࠧ࡯ࡣࡰࡩࠬ஑"):l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠨࡰࡤࡱࡪ࠭ஒ")]}))
        l1lll111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠩ࡬ࡱ࡬࠭ஓ")]=l11l1l1l11l1_mS_
        l11ll111l11l1_mS_.append(l1lll111ll11l1_mS_)
        idx+=1
    return l11ll111l11l1_mS_,l1ll1lll1l11l1_mS_
class l1lllllll11l1_mS_:
    def l11ll1ll11l1_mS_(self,url):
        if not url:
            url = l1l11l11l1_mS_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡮ࡧࡵࡦࡪ࡮ࡰ࠲ࡵࡲ࠯ࠨஔ")
        elif url.startswith(l1l11l11l1_mS_ (u"ࠫ࠴࠵ࠧக")):
            url = l1l11l11l1_mS_ (u"ࠬ࡮ࡴࡵࡲࠪ஖")+url
        elif url.startswith(l1l11l11l1_mS_ (u"࠭࠯ࠨ஗")):
            url = urljoin(l1l11l11l1_mS_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡫ࡤࡲࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࠬ஘"),url)
        return url
    @staticmethod
    def l1llll1ll11l1_mS_(url=l1l11l11l1_mS_ (u"ࠨࠩங")):
        if not url:
            url = l1l11l11l1_mS_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡭ࡦࡴ࡬ࡩ࡭࡯࠱ࡴࡱ࠵ࠧச")
        elif url.startswith(l1l11l11l1_mS_ (u"ࠪ࠳ࠬ஛")):
            url = urljoin(l1l11l11l1_mS_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩஜ"),url)
        content = l1111l1l11l1_mS_(url)
        out=[]
        l1111lll11l1_mS_ = re.compile(l1l11l11l1_mS_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡦࡰࡷ࠱࡬ࡸࡩࡥࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ஝"),re.DOTALL).findall(content)
        for show in l1111lll11l1_mS_:
            l11l11ll11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠲ࡷࡪࡸࡩࡢ࡮ࡨ࠳࠳࠰ࠩࠣࡀ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬஞ"),show)
            if l11l11ll11l1_mS_:
                l11l1l1l11l1_mS_ = l11l11ll11l1_mS_[0][1]
                l11l1l1l11l1_mS_ = urljoin(l1l11l11l1_mS_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡫ࡤࡲࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࠬட"),l11l1l1l11l1_mS_) if not l11l1l1l11l1_mS_.startswith(l1l11l11l1_mS_ (u"ࠨࡪࡷࡸࡵ࠭஠")) else l11l1l1l11l1_mS_
                title = l11l11ll11l1_mS_[0][0].replace(l1l11l11l1_mS_ (u"ࠩ࠲ࡷࡪࡸࡩࡢ࡮ࡨ࠳ࠬ஡"),l1l11l11l1_mS_ (u"ࠪࠫ஢")).replace(l1l11l11l1_mS_ (u"ࠫ࠲࠭ண"),l1l11l11l1_mS_ (u"ࠬࠦࠧத")).replace(l1l11l11l1_mS_ (u"࠭࠯ࠨ஥"),l1l11l11l1_mS_ (u"ࠧࠨ஦")).title()
                out.append({l1l11l11l1_mS_ (u"ࠨࡪࡵࡩ࡫࠭஧"):l11l11ll11l1_mS_[0][0],l1l11l11l1_mS_ (u"ࠩࡷ࡭ࡹࡲࡥࠨந"):title,l1l11l11l1_mS_ (u"ࠪ࡭ࡲ࡭ࠧன"):l11l1l1l11l1_mS_})
        idx = content.find(l1l11l11l1_mS_ (u"ࠫ࡭࠹࠾ࡔࡧࡵ࡭ࡦࡲࡥ࠽࠱࡫࠷ࡃ࠭ப"))
        if idx:
            l1ll11lll11l1_mS_ = re.compile(l1l11l11l1_mS_ (u"ࠬࡂࡵ࡭ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭஫"),re.DOTALL).search(content[idx:-1])
            l1ll11lll11l1_mS_ = l1ll11lll11l1_mS_.group(1) if l1ll11lll11l1_mS_ else l1l11l11l1_mS_ (u"࠭ࠧ஬")
            l1ll11lll11l1_mS_ = re.sub(l1l11l11l1_mS_ (u"ࡲࠣ࠾ࠤ࠱࠲࠮࠮ࡽ࡞ࡶࢀࡡࡴࠩࠫࡁ࠰࠱ࡃࠨ஭"), l1l11l11l1_mS_ (u"ࠣࠤம"), l1ll11lll11l1_mS_)
            l1ll11l1l11l1_mS_ = re.compile(l1l11l11l1_mS_ (u"ࠩ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠲ࡷࡪࡸࡩࡢ࡮ࡨ࠳࠳࠰࠿ࠪࠤࡁࠬࡠࡤ࠾࡞ࠬࠬࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃ࠭ய")).findall(l1ll11lll11l1_mS_)
            for href,title in l1ll11l1l11l1_mS_:
                out.append({l1l11l11l1_mS_ (u"ࠪ࡬ࡷ࡫ࡦࠨர"):href,l1l11l11l1_mS_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪற"):title})
        return out
    @staticmethod
    def l1l1lll1l11l1_mS_(url=l1l11l11l1_mS_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡰࡢࡰࡨ࡬ࡰࡲ࠴ࡰ࡭࠱ࡶࡩࡷ࡯ࡡ࡭ࡧ࠲ࡨࡪࡺࡥ࡬ࡶࡼࡻ࠴࠭ல")):
        if not url:
            url = l1l11l11l1_mS_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡪࡣࡱࡩ࡭ࡱࡳ࠮ࡱ࡮࠲ࠫள")
        if url.startswith(l1l11l11l1_mS_ (u"ࠧ࠰࠱ࠪழ")):
            url = l1l11l11l1_mS_ (u"ࠨࡪࡷࡸࡵ࠭வ")+url
        if url.startswith(l1l11l11l1_mS_ (u"ࠩ࠲ࠫஶ")):
            url = urljoin(l1l11l11l1_mS_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡮ࡧࡵࡦࡪ࡮ࡰ࠲ࡵࡲ࠯ࠨஷ"),url)
        url += l1l11l11l1_mS_ (u"ࠫ࠴࠭ஸ") if not url.endswith(l1l11l11l1_mS_ (u"ࠬ࠵ࠧஹ")) else l1l11l11l1_mS_ (u"࠭ࠧ஺")
        content = l1111l1l11l1_mS_(url)
        out=[]
        l1ll1l1ll11l1_mS_ = re.compile(l1l11l11l1_mS_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡨࡲࡹ࠳ࡧࡳ࡫ࡧࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ஻"),re.DOTALL).findall(content)
        for l11lllll11l1_mS_ in l1ll1l1ll11l1_mS_:
            l1lll11ll11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠨࡵࡨࡾࡴࡴ࡜ࡴࠬࠫࡠࡩ࠱ࠩࠨ஼"),l11lllll11l1_mS_,re.I)
            l1lll11ll11l1_mS_ = l1lll11ll11l1_mS_[0] if l1lll11ll11l1_mS_ else l1l11l11l1_mS_ (u"ࠩࠪ஽")
            l1l1ll1ll11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠪࡓࡩࡩࡩ࡯ࡧ࡮ࡠࡸ࠰ࠨ࡝ࡦ࠮࠭ࠬா"),l11lllll11l1_mS_,re.I)
            l1l1ll1ll11l1_mS_ = l1l1ll1ll11l1_mS_[0] if l1l1ll1ll11l1_mS_ else l1l11l11l1_mS_ (u"ࠫࠬி")
            href = re.compile(l1l11l11l1_mS_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩࡵ࡬ࡲ࡬ࡲࡥࡱࡣࡪࡩ࠳ࡶࡨࡱ࡞ࡂ࡭ࡩࡃ࡜ࡥ࠭ࠬࠦࠬீ")).findall(l11lllll11l1_mS_)
            l11l1l1l11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"࠭࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩு"),l11lllll11l1_mS_)
            if href and l1lll11ll11l1_mS_ and l1l1ll1ll11l1_mS_:
                l11l1l1l11l1_mS_ = urljoin(l1l11l11l1_mS_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡫ࡤࡲࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࠬூ"),l11l1l1l11l1_mS_[0]) if not l11l1l1l11l1_mS_[0].startswith(l1l11l11l1_mS_ (u"ࠨࡪࡷࡸࡵ࠭௃")) else l1l11l11l1_mS_ (u"ࠩࠪ௄")
                out.append({l1l11l11l1_mS_ (u"ࠪ࡬ࡷ࡫ࡦࠨ௅"):url+href[0],l1l11l11l1_mS_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪெ"):l1l11l11l1_mS_ (u"࡙ࠬࡥࡻࡱࡱࠤࠪࡹࠬࠡࡇࡳ࡭ࡿࡵࡤࠡࠧࡶࠫே")%(l1lll11ll11l1_mS_,l1l1ll1ll11l1_mS_),l1l11l11l1_mS_ (u"࠭ࡩ࡮ࡩࠪை"):l11l1l1l11l1_mS_,
                l1l11l11l1_mS_ (u"ࠧࡴࡧࡤࡷࡴࡴࠧ௉"):int(l1lll11ll11l1_mS_),l1l11l11l1_mS_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࠩொ"):int(l1l1ll1ll11l1_mS_)})
        return out
    @staticmethod
    def l1lll111l11l1_mS_(out):
        l1l11l1l11l1_mS_={}
        l1lllll1l11l1_mS_ = [x.get(l1l11l11l1_mS_ (u"ࠩࡶࡩࡦࡹ࡯࡯ࠩோ")) for x in out]
        for s in set(l1lllll1l11l1_mS_):
            l1l11l1l11l1_mS_[l1l11l11l1_mS_ (u"ࠪࡗࡪࢀ࡯࡯ࠢࠨ࠴࠷ࡪࠧௌ")%s]=[out[i] for i, j in enumerate(l1lllll1l11l1_mS_) if j == s]
        return l1l11l1l11l1_mS_
    @staticmethod
    def l1l1l11l11l1_mS_(url):
        content = l1111l1l11l1_mS_(url)
        l11ll11l11l1_mS_=l1l11l11l1_mS_ (u"்ࠫࠬ")
        l11l1lll11l1_mS_ = re.compile(l1l11l11l1_mS_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠮࠮ࠫࡁࠬࡀ࠴࡯ࡦࡳࡣࡰࡩࡃ࠭௎"),re.DOTALL).findall(content)
        if l11l1lll11l1_mS_:
            src = re.compile(l1l11l11l1_mS_ (u"࠭ࡳࡳࡥࡀ࡟ࡡ࠭ࠢ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠩࠥࡡࠬ௏"),re.DOTALL).findall(l11l1lll11l1_mS_[0])
            l11ll11l11l1_mS_ = src[0] if src else l1l11l11l1_mS_ (u"ࠧࠨௐ")
        return l11ll11l11l1_mS_
class l1ll1l11l11l1_mS_:
    @staticmethod
    def l1llll1ll11l1_mS_(url,l111llll11l1_mS_=None):
        if l111llll11l1_mS_:
            l111llll11l1_mS_ = l1l11l11l1_mS_ (u"ࠨࡵࡽࡹࡰࡧࡪ࠾ࠩ௑")+l111llll11l1_mS_.replace(l1l11l11l1_mS_ (u"ࠩࠣࠫ௒"),l1l11l11l1_mS_ (u"ࠪ࠯ࠬ௓"))
            url= l1l11l11l1_mS_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡲࡼ࡫࡯࡬࡮࠰ࡳࡰ࠴ࡹࡺࡶ࡭ࡤ࡮ࠬ௔")
        if not url:
            url = l1l11l11l1_mS_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡥࡳࡽ࡬ࡩ࡭࡯࠱ࡴࡱ࠵ࠧ௕")
        elif url.startswith(l1l11l11l1_mS_ (u"࠭࠯ࠨ௖")):
            url = urljoin(l1l11l11l1_mS_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡧࡵࡸࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩௗ"),url)
        content = l1111l1l11l1_mS_(url,l111llll11l1_mS_)
        ids = [(a.start(), a.end()) for a in re.finditer(l1l11l11l1_mS_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡶࡪࡦࡨࡳࡤ࡯࡮ࡧࡱࠥࡂࠬ௘"), content,re.IGNORECASE)]
        ids.append( (-1,-1) )
        out=[]
        for i in range(len(ids[:-1])):
            l1ll11ll11l1_mS_ = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile(l1l11l11l1_mS_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ௙"),re.DOTALL).search(l1ll11ll11l1_mS_)
            title = re.compile(l1l11l11l1_mS_ (u"ࠪࡀ࡭࠷࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠳ࡁࠫ௚"),re.DOTALL).search(l1ll11ll11l1_mS_)
            l11l1l1l11l1_mS_ = re.compile(l1l11l11l1_mS_ (u"ࠫࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ௛"),re.DOTALL).search(l1ll11ll11l1_mS_)
            l1ll1111l11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠬࡒࡥ࡬ࡶࡲࡶ࠿ࡢࡳࠫ࠾ࡶࡴࡦࡴࠠࡴࡶࡼࡰࡪࡃࠢ࡜ࡠࡁࡡ࠯ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭௜"),l1ll11ll11l1_mS_)
            l1ll1ll1l11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"࠭ࡄࡰࡦࡤࡲࡾࡀ࡜ࡴࠬ࠿ࡷࡵࡧ࡮ࠡࡵࡷࡽࡱ࡫࠽ࠣ࡝ࡡࡂࡢ࠰ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ௝"),l1ll11ll11l1_mS_)
            l1l1lllll11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠧࡈࡣࡷࡹࡳ࡫࡫࠻࡞ࡶ࠮ࡁࡹࡰࡢࡰࠣࡷࡹࡿ࡬ࡦ࠿ࠥ࡟ࡣࡄ࡝ࠫࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ௞"),l1ll11ll11l1_mS_)
            l1ll1111l11l1_mS_ = l1ll1111l11l1_mS_[0] if l1ll1111l11l1_mS_ else l1l11l11l1_mS_ (u"ࠨࠩ௟")
            l1ll1ll1l11l1_mS_ = l1ll1ll1l11l1_mS_[0] if l1ll1ll1l11l1_mS_ else l1l11l11l1_mS_ (u"ࠩࠪ௠")
            l1l1lllll11l1_mS_ = l1l1lllll11l1_mS_[0] if l1l1lllll11l1_mS_ else l1l11l11l1_mS_ (u"ࠪࠫ௡")
            code = l1ll1111l11l1_mS_
            l11lll1l11l1_mS_ = l1l11l11l1_mS_ (u"ࠦࡑ࡫࡫ࡵࡱࡵ࠾ࠥࠫࡳࠡ࡞ࡱࡈࡴࡪࡡ࡯ࡻ࠽ࠤࠪࡹࠠ࡝ࡰࡊࡥࡹࡻ࡮ࡦ࡭࠽ࠤࠪࡹࠠ࡝ࡰࠥ௢") %(l1ll1111l11l1_mS_,l1ll1ll1l11l1_mS_,l1l1lllll11l1_mS_)
            if href and title:
                l11l1l1l11l1_mS_ = urljoin(l1l11l11l1_mS_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡥࡳࡽ࡬ࡩ࡭࡯࠱ࡴࡱ࠭௣"),l11l1l1l11l1_mS_.group(1)) if l11l1l1l11l1_mS_ else l1l11l11l1_mS_ (u"࠭ࠧ௤")
                title = title.group(1)
                year =  re.findall(l1l11l11l1_mS_ (u"ࠧ࡝ࠪࠫࡠࡩࢁ࠴ࡾࠫ࡟࠭ࠬ௥"),title)
                l1l1llll11l1_mS_ = {l1l11l11l1_mS_ (u"ࠨࡪࡵࡩ࡫࠭௦")   : href.group(1),
                       l1l11l11l1_mS_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ௧")  : l111ll1l11l1_mS_(title),
                       l1l11l11l1_mS_ (u"ࠪ࡭ࡲ࡭ࠧ௨")    : l11l1l1l11l1_mS_,
                       l1l11l11l1_mS_ (u"ࠫࡵࡲ࡯ࡵࠩ௩")   : l111ll1l11l1_mS_(l11lll1l11l1_mS_),
                       l1l11l11l1_mS_ (u"ࠬࡿࡥࡢࡴࠪ௪")   : year[0] if year else l1l11l11l1_mS_ (u"࠭ࠧ௫"),
                       l1l11l11l1_mS_ (u"ࠧࡤࡱࡧࡩࠬ௬")   : code,
                        }
                out.append(l1l1llll11l1_mS_)
        l1lll1l1l11l1_mS_=False
        l1l1l1ll11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬࡠࡤࠢ࡞ࠬࠬࠦࡃࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡲࡪࡾࡴࡠࡵ࡬ࡸࡪࠨ࠾ࡑࡱࡳࡶࡿ࡫ࡤ࡯࡫ࡤࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡦࡄࠧ௭"),content)
        l1l1l1ll11l1_mS_ = l1l1l1ll11l1_mS_[0] if l1l1l1ll11l1_mS_ else False
        l1lll1l1l11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭ࡡ࡞ࠣ࡟࠭࠭ࠧࡄ࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡳ࡫ࡸࡵࡡࡶ࡭ࡹ࡫ࠢ࠿ࡐࡤࡷࡹ࠴ࠫࡱࡰࡤࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡦࡄࠧ௮"),content)
        l1lll1l1l11l1_mS_ = l1lll1l1l11l1_mS_[0] if l1lll1l1l11l1_mS_ else False
        return (out, (l1l1l1ll11l1_mS_,l1lll1l1l11l1_mS_))
    @staticmethod
    def l11111ll11l1_mS_():
        content = l1111l1l11l1_mS_(l1l11l11l1_mS_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡣࡱࡻࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࡰࡵ࡮ࡵࡣ࡮ࡸࠬ௯"))
        l111l1ll11l1_mS_=re.findall(l1l11l11l1_mS_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠰࡭ࡤࡸࡦࡲ࡯ࡨ࠱࠱࠮࠮ࠨࠠࡤ࡮ࡤࡷࡸࡃࠢ࡯ࡣࡹࡣࡱ࡯࡮࡬ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭௰"),content)
        out=[]
        for href,name in l111l1ll11l1_mS_:
            out.append({l1l11l11l1_mS_ (u"ࠬ࡮ࡲࡦࡨࠪ௱"):href,l1l11l11l1_mS_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ௲"):name})
        return out
    @staticmethod
    def l11l111l11l1_mS_(url):
        url = urljoin(l1l11l11l1_mS_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡧࡵࡸࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩ௳"),url)
        content = l1111l1l11l1_mS_(url)
        l111l11l11l1_mS_=l1l11l11l1_mS_ (u"ࠨࠩ௴")
        l1l111ll11l1_mS_=re.findall(l1l11l11l1_mS_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠫ࠲࠯ࡅࠩ࠽࠱࡬ࡪࡷࡧ࡭ࡦࡀࠪ௵"),content,re.DOTALL|re.IGNORECASE)
        if l1l111ll11l1_mS_:
            l111l11l11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ௶"),l1l111ll11l1_mS_[0],re.DOTALL|re.IGNORECASE)
            l111l11l11l1_mS_ = l111l11l11l1_mS_[0] if l111l11l11l1_mS_ else l1l11l11l1_mS_ (u"ࠫࠬ௷")
        return l111l11l11l1_mS_
