# -*- coding: utf-8 -*-
import sys
l111l11l1_mS_ = sys.version_info [0] == 2
l111ll11l1_mS_ = 2048
l1l1ll11l1_mS_ = 7
def l1l11l11l1_mS_ (keyedStringLiteral):
	global l1llll11l1_mS_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l11l1_mS_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll11l1_mS_ - (charIndex + stringNr) % l1l1ll11l1_mS_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll11l1_mS_ - (charIndex + stringNr) % l1l1ll11l1_mS_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import sys
from Queue import Queue
from threading import Thread
class l11l111l1l11l1_mS_(Thread):
    l1l11l11l1_mS_ (u"ࠤ࡚ࠥࠦࠥࡨࡳࡧࡤࡨࠥ࡫ࡸࡦࡥࡸࡸ࡮ࡴࡧࠡࡶࡤࡷࡰࡹࠠࡧࡴࡲࡱࠥࡧࠠࡨ࡫ࡹࡩࡳࠦࡴࡢࡵ࡮ࡷࠥࡷࡵࡦࡷࡨࠤࠧࠨࠢഩ")
    def __init__(self, l11l111lll11l1_mS_):
        Thread.__init__(self)
        self.l11l111lll11l1_mS_ = l11l111lll11l1_mS_
        self.daemon = True
        self.start()
    def run(self):
        while True:
            func, args, kargs = self.l11l111lll11l1_mS_.get()
            try:
                func(*args, **kargs)
            except Exception as e:
                print(e)
            finally:
                self.l11l111lll11l1_mS_.task_done()
class ThreadPool:
    l1l11l11l1_mS_ (u"ࠥࠦࠧࠦࡐࡰࡱ࡯ࠤࡴ࡬ࠠࡵࡪࡵࡩࡦࡪࡳࠡࡥࡲࡲࡸࡻ࡭ࡪࡰࡪࠤࡹࡧࡳ࡬ࡵࠣࡪࡷࡵ࡭ࠡࡣࠣࡵࡺ࡫ࡵࡦࠢࠥࠦࠧപ")
    def __init__(self, l11l11l11l11l1_mS_):
        self.l11l111lll11l1_mS_ = Queue(l11l11l11l11l1_mS_)
        for _ in range(l11l11l11l11l1_mS_):
            l11l111l1l11l1_mS_(self.l11l111lll11l1_mS_)
    def l11l11111l11l1_mS_(self, func, *args, **kargs):
        l1l11l11l1_mS_ (u"ࠦࠧࠨࠠࡂࡦࡧࠤࡦࠦࡴࡢࡵ࡮ࠤࡹࡵࠠࡵࡪࡨࠤࡶࡻࡥࡶࡧࠣࠦࠧࠨഫ")
        self.l11l111lll11l1_mS_.put((func, args, kargs))
    def map(self, func, l11l1111ll11l1_mS_):
        l1l11l11l1_mS_ (u"ࠧࠨࠢࠡࡃࡧࡨࠥࡧࠠ࡭࡫ࡶࡸࠥࡵࡦࠡࡶࡤࡷࡰࡹࠠࡵࡱࠣࡸ࡭࡫ࠠࡲࡷࡨࡹࡪࠦࠢࠣࠤബ")
        for args in l11l1111ll11l1_mS_:
            self.l11l11111l11l1_mS_(func, args)
    def l111llllll11l1_mS_(self):
        l1l11l11l1_mS_ (u"ࠨ࡚ࠢࠣࠢࡥ࡮ࡺࠠࡧࡱࡵࠤࡨࡵ࡭ࡱ࡮ࡨࡸ࡮ࡵ࡮ࠡࡱࡩࠤࡦࡲ࡬ࠡࡶ࡫ࡩࠥࡺࡡࡴ࡭ࡶࠤ࡮ࡴࠠࡵࡪࡨࠤࡶࡻࡥࡶࡧࠣࠦࠧࠨഭ")
        self.l11l111lll11l1_mS_.join()
