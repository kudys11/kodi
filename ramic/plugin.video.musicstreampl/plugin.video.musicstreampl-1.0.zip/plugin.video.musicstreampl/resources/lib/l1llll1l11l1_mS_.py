# -*- coding: utf-8 -*-
import sys
l111l11l1_mS_ = sys.version_info [0] == 2
l111ll11l1_mS_ = 2048
l1l1ll11l1_mS_ = 7
def l1l11l11l1_mS_ (keyedStringLiteral):
	global l1llll11l1_mS_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l11l1_mS_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll11l1_mS_ - (charIndex + stringNr) % l1l1ll11l1_mS_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll11l1_mS_ - (charIndex + stringNr) % l1l1ll11l1_mS_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import ramic as l1l1l1ll1l11l1_mS_
l1l11lll1l11l1_mS_        = sys.argv[0]
l1l111l11l11l1_mS_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l11l1l1lll11l1_mS_        = xbmcaddon.Addon()
l1l1llllll11l1_mS_     = l11l1l1lll11l1_mS_.getAddonInfo(l1l11l11l1_mS_ (u"ࠬ࡯ࡤࠨ௸"))
l1l1llll1l11l1_mS_       = l11l1l1lll11l1_mS_.getAddonInfo(l1l11l11l1_mS_ (u"࠭࡮ࡢ࡯ࡨࠫ௹"))
PATH        = l11l1l1lll11l1_mS_.getAddonInfo(l1l11l11l1_mS_ (u"ࠧࡱࡣࡷ࡬ࠬ௺")).decode(l1l11l11l1_mS_ (u"ࠨࡷࡷࡪ࠲࠾ࠧ௻"))
l1l1ll1l11l1_mS_    = xbmc.translatePath(l11l1l1lll11l1_mS_.getAddonInfo(l1l11l11l1_mS_ (u"ࠩࡳࡶࡴ࡬ࡩ࡭ࡧࠪ௼"))).decode(l1l11l11l1_mS_ (u"ࠪࡹࡹ࡬࠭࠹ࠩ௽"))
l11l1l111l11l1_mS_   = PATH+l1l11l11l1_mS_ (u"ࠫ࠴ࡸࡥࡴࡱࡸࡶࡨ࡫ࡳ࠰ࠩ௾")
l11ll1llll11l1_mS_       = PATH+l1l11l11l1_mS_ (u"ࠬ࠵ࡩࡤࡱࡱ࠲ࡵࡴࡧࠨ௿")
l1l111llll11l1_mS_        = l11l1l111l11l1_mS_+l1l11l11l1_mS_ (u"࠭࡭ࡩ࠰ࡳࡲ࡬࠭ఀ")
l1l1ll1lll11l1_mS_=l11l1l111l11l1_mS_+l1l11l11l1_mS_ (u"ࠧࡧࡣࡱࡥࡷࡺ࠮ࡱࡰࡪࠫఁ")
sys.path.append(l11l1l111l11l1_mS_+l1l11l11l1_mS_ (u"ࠨ࡮࡬ࡦ࠴࠭ం"))
l11l1ll1ll11l1_mS_ = urllib2.urlopen
l1l11l1l1l11l1_mS_ = urllib2.Request
l1l1lll11l1_mS_ = xbmcgui.Dialog()
import time
l1l1ll11ll11l1_mS_ = lambda x,y: ord(x)+12*y if ord(x)%2 else ord(x)
l11l11llll11l1_mS_ = lambda l1l1l1llll11l1_mS_: l1l11l11l1_mS_ (u"ࠩࠪః").join([chr(l1l1ll11ll11l1_mS_(x,1) ) for x in l1l1l1llll11l1_mS_.encode(l1l11l11l1_mS_ (u"ࠪࡦࡦࡹࡥ࠷࠶ࠪఄ")).strip()])
l1l1lll1ll11l1_mS_ = lambda l1l1l1llll11l1_mS_: l11l11llll11l1_mS_(l1l1l1llll11l1_mS_).encode(l1l11l11l1_mS_ (u"ࠫ࡭࡫ࡸࠨఅ"))
l1l11l11ll11l1_mS_ = lambda l1l1l1llll11l1_mS_: l1l11l11l1_mS_ (u"ࠬ࠭ఆ").join([chr(l1l1ll11ll11l1_mS_(x,-1) ) for x in l1l1l1llll11l1_mS_]).decode(l1l11l11l1_mS_ (u"࠭ࡢࡢࡵࡨ࠺࠹࠭ఇ"))
l11ll1l1ll11l1_mS_ = lambda l1l1l1llll11l1_mS_: l1l11l11ll11l1_mS_(l1l1l1llll11l1_mS_.decode(l1l11l11l1_mS_ (u"ࠧࡩࡧࡻࠫఈ")))
if not os.path.exists(l1l11l11l1_mS_ (u"ࠨ࠱࡫ࡳࡲ࡫࠯ࡰࡵࡰࡧࠬఉ")):
    tm=time.gmtime()
    try:    l1l11ll1ll11l1_mS_,l11lll111l11l1_mS_,l1ll1111ll11l1_mS_ = l11ll1l1ll11l1_mS_(l11l1l1lll11l1_mS_.getSetting(l1l11l11l1_mS_ (u"ࠩ࡮ࡳࡩ࠭ఊ"))).split(l1l11l11l1_mS_ (u"ࠪ࠾ࠬఋ"))
    except: l1l11ll1ll11l1_mS_,l11lll111l11l1_mS_,l1ll1111ll11l1_mS_ =  [l1l11l11l1_mS_ (u"ࠫ࠲࠷ࠧఌ"),l1l11l11l1_mS_ (u"ࠬ࠭఍"),l1l11l11l1_mS_ (u"࠭࠭࠲ࠩఎ")]
    if int(l1l11ll1ll11l1_mS_) != tm.tm_hour:
        try:    l1l1111lll11l1_mS_ = re.findall(l1l11l11l1_mS_ (u"ࠧࡌࡑࡇ࠾ࠥ࠮࠮ࠫࡁࠬࡠࡳ࠭ఏ"),l11l1ll1ll11l1_mS_(l1l11l11l1_mS_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡹࡧࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳ࠯ࡳࡣࡰ࡭ࡨࡹࡰࡢ࠱࡮ࡳࡩ࡯࠯࡮ࡣࡶࡸࡪࡸ࠯ࡓࡇࡄࡈࡒࡋ࠮࡮ࡦࠪఐ")).read())[0].strip(l1l11l11l1_mS_ (u"ࠩ࠭ࠫ఑"))
        except: l1l1111lll11l1_mS_ = l1l11l11l1_mS_ (u"ࠪࠫఒ")
        l1l1l1l1ll11l1_mS_ = l1l1lll1ll11l1_mS_(l1l11l11l1_mS_ (u"ࠬࠫࡤ࠻ࠧࡶ࠾ࠪࡪࠧఛ")%(tm.tm_hour,l1l1111lll11l1_mS_,tm.tm_min))
        l11l1l1lll11l1_mS_.setSetting(l1l11l11l1_mS_ (u"࠭࡫ࡰࡦࠪజ"),l1l1l1l1ll11l1_mS_)
def l11ll1111l11l1_mS_(name, url, mode, l1ll1lll11l1_mS_=1, l1l1ll111l11l1_mS_=l1l11l11l1_mS_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫఝ"), infoLabels={}, IsPlayable=True, isFolder=False, fanart=l1l1ll1lll11l1_mS_,l1l111ll1l11l1_mS_=1):
    u = l1l1ll1l1l11l1_mS_({l1l11l11l1_mS_ (u"ࠨ࡯ࡲࡨࡪ࠭ఞ"): mode, l1l11l11l1_mS_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭ట"): name, l1l11l11l1_mS_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫఠ") : url, l1l11l11l1_mS_ (u"ࠫࡵࡧࡧࡦࠩడ"):l1ll1lll11l1_mS_,l1l11l11l1_mS_ (u"ࠬࡳࡩ࡯ࡨࡲࠫఢ"):str(infoLabels)})
    isFolder = infoLabels.get(l1l11l11l1_mS_ (u"࠭ࡩࡴࡈࡲࡰࡩ࡫ࡲࠨణ"),isFolder)
    if isFolder and infoLabels.get(l1l11l11l1_mS_ (u"ࠧࡺࡧࡤࡶࠬత"),False):
        name += l1l11l11l1_mS_ (u"ࠨࠢࠫࠩࡸ࠯ࠧథ")%infoLabels.get(l1l11l11l1_mS_ (u"ࠩࡼࡩࡦࡸࠧద"))
    l1l111l1ll11l1_mS_ = xbmcgui.ListItem(name)
    l1l11111ll11l1_mS_=[l1l11l11l1_mS_ (u"ࠪࡸ࡭ࡻ࡭ࡣࠩధ"),l1l11l11l1_mS_ (u"ࠫࡵࡵࡳࡵࡧࡵࠫన"),l1l11l11l1_mS_ (u"ࠬࡨࡡ࡯ࡰࡨࡶࠬ఩"),l1l11l11l1_mS_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠭ప"),l1l11l11l1_mS_ (u"ࠧࡤ࡮ࡨࡥࡷࡧࡲࡵࠩఫ"),l1l11l11l1_mS_ (u"ࠨࡥ࡯ࡩࡦࡸ࡬ࡰࡩࡲࠫబ"),l1l11l11l1_mS_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬభ"),l1l11l11l1_mS_ (u"ࠪ࡭ࡨࡵ࡮ࠨమ")]
    l1ll11111l11l1_mS_ = dict(zip(l1l11111ll11l1_mS_,[infoLabels.get(x,l1l1ll111l11l1_mS_) for x in l1l11111ll11l1_mS_]))
    l1ll11111l11l1_mS_[l1l11l11l1_mS_ (u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫ࠧయ")] = fanart if fanart else l1ll11111l11l1_mS_[l1l11l11l1_mS_ (u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨర")]
    l1l111l1ll11l1_mS_.setArt(l1ll11111l11l1_mS_)
    id = infoLabels.pop(l1l11l11l1_mS_ (u"࠭ࡩࡥࠩఱ")) if infoLabels.has_key(l1l11l11l1_mS_ (u"ࠧࡪࡦࠪల")) else False
    l1l111l1ll11l1_mS_.setInfo(type=l1l11l11l1_mS_ (u"ࠣࡸ࡬ࡨࡪࡵࠢళ"), infoLabels=infoLabels)
    if IsPlayable and not isFolder:
        l1l111l1ll11l1_mS_.setProperty(l1l11l11l1_mS_ (u"ࠩࡌࡷࡕࡲࡡࡺࡣࡥࡰࡪ࠭ఴ"), l1l11l11l1_mS_ (u"ࠪࡸࡷࡻࡥࠨవ"))
    ok = xbmcplugin.addDirectoryItem(handle=l1l111l11l11l1_mS_, url=u, listitem=l1l111l1ll11l1_mS_,isFolder=isFolder,totalItems=l1l111ll1l11l1_mS_)
    xbmcplugin.addSortMethod(l1l111l11l11l1_mS_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1l11l11l1_mS_ (u"ࠦࠪࡘࠬࠡࠧ࡜࠰ࠥࠫࡐࠣశ"))
    return ok
def l1l11l1lll11l1_mS_(name,ex_link=None, l1ll1lll11l1_mS_=1, mode=l1l11l11l1_mS_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬష"),iconImage=l1l11l11l1_mS_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࠪస"), infoLabels={}, fanart=l1l1ll1lll11l1_mS_,contextmenu=None):
    url = l1l1ll1l1l11l1_mS_({l1l11l11l1_mS_ (u"ࠧ࡮ࡱࡧࡩࠬహ"): mode, l1l11l11l1_mS_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬ఺"): name, l1l11l11l1_mS_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪ఻") : ex_link, l1l11l11l1_mS_ (u"ࠪࡴࡦ࡭ࡥࠨ఼") : l1ll1lll11l1_mS_})
    l1l11ll11l11l1_mS_ = xbmcgui.ListItem(name)
    if infoLabels:
        l1l11ll11l11l1_mS_.setInfo(type=l1l11l11l1_mS_ (u"ࠦࡻ࡯ࡤࡦࡱࠥఽ"), infoLabels=infoLabels)
    l1l11111ll11l1_mS_=[l1l11l11l1_mS_ (u"ࠬࡺࡨࡶ࡯ࡥࠫా"),l1l11l11l1_mS_ (u"࠭ࡰࡰࡵࡷࡩࡷ࠭ి"),l1l11l11l1_mS_ (u"ࠧࡣࡣࡱࡲࡪࡸࠧీ"),l1l11l11l1_mS_ (u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶࠪు"),l1l11l11l1_mS_ (u"ࠩࡦࡰࡪࡧࡲ࡭ࡱࡪࡳࠬూ"),l1l11l11l1_mS_ (u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭ృ"),l1l11l11l1_mS_ (u"ࠫ࡮ࡩ࡯࡯ࠩౄ")]
    l1ll11111l11l1_mS_ = dict(zip(l1l11111ll11l1_mS_,[infoLabels.get(x,iconImage) for x in l1l11111ll11l1_mS_]))
    l1ll11111l11l1_mS_[l1l11l11l1_mS_ (u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨ౅")] = fanart if fanart else l1ll11111l11l1_mS_[l1l11l11l1_mS_ (u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦࠩె")]
    l1l11ll11l11l1_mS_.setArt(l1ll11111l11l1_mS_)
    if contextmenu:
        l11l1lllll11l1_mS_=contextmenu
        l1l11ll11l11l1_mS_.addContextMenuItems(l11l1lllll11l1_mS_, replaceItems=True)
    else:
        l11l1lllll11l1_mS_ = []
        l11l1lllll11l1_mS_.append((l1l11l11l1_mS_ (u"ࠧࡊࡰࡩࡳࡷࡳࡡࡤ࡬ࡤࠫే"), l1l11l11l1_mS_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡁࡤࡶ࡬ࡳࡳ࠮ࡉ࡯ࡨࡲ࠭ࠬై")),)
        l1l11ll11l11l1_mS_.addContextMenuItems(l11l1lllll11l1_mS_, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=l1l111l11l11l1_mS_, url=url,listitem=l1l11ll11l11l1_mS_, isFolder=True)
    xbmcplugin.addSortMethod(l1l111l11l11l1_mS_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1l11l11l1_mS_ (u"ࠤࠨࡖ࠱࡚ࠦࠥ࠮ࠣࠩࡕࠨ౉"))
def l1l1111l1l11l1_mS_(name, url=l1l11l11l1_mS_ (u"ࠪࠫొ"), mode=l1l11l11l1_mS_ (u"ࠫࠬో"), l1l1ll111l11l1_mS_=None, fanart=l1l1ll1lll11l1_mS_):
    u = l1l1ll1l1l11l1_mS_({l1l11l11l1_mS_ (u"ࠬࡳ࡯ࡥࡧࠪౌ"): mode, l1l11l11l1_mS_ (u"࠭ࡦࡰ࡮ࡧࡩࡷࡴࡡ࡮ࡧ్ࠪ"): name, l1l11l11l1_mS_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨ౎") : url, l1l11l11l1_mS_ (u"ࠨࡲࡤ࡫ࡪ࠭౏"):1})
    l1l111l1ll11l1_mS_ = xbmcgui.ListItem(name, iconImage=l1l1ll111l11l1_mS_, thumbnailImage=l1l1ll111l11l1_mS_)
    l1l111l1ll11l1_mS_.setProperty(l1l11l11l1_mS_ (u"ࠩࡌࡷࡕࡲࡡࡺࡣࡥࡰࡪ࠭౐"), l1l11l11l1_mS_ (u"ࠪࡪࡦࡲࡳࡦࠩ౑"))
    if fanart:
        l1l111l1ll11l1_mS_.setProperty(l1l11l11l1_mS_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࡣ࡮ࡳࡡࡨࡧࠪ౒"),fanart)
    ok = xbmcplugin.addDirectoryItem(handle=l1l111l11l11l1_mS_, url=u, listitem=l1l111l1ll11l1_mS_,isFolder=False)
    return ok
def l11111l1l11l1_mS_(l1lll1111l11l1_mS_):
    l111l11ll11l1_mS_ = {}
    for k, v in l1lll1111l11l1_mS_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l1l11l11l1_mS_ (u"ࠬࡻࡴࡧ࠺ࠪ౓"))
        elif isinstance(v, str):
            v.decode(l1l11l11l1_mS_ (u"࠭ࡵࡵࡨ࠻ࠫ౔"))
        l111l11ll11l1_mS_[k] = v
    return l111l11ll11l1_mS_
def l1l1ll1l1l11l1_mS_(query):
    return l1l11lll1l11l1_mS_ + l1l11l11l1_mS_ (u"ࠧࡀౕࠩ") + urllib.urlencode(l11111l1l11l1_mS_(query))
def l1ll111lll11l1_mS_(l1l1l111l11l1_mS_,l11llll1ll11l1_mS_=[],index=False):
    l11lllllll11l1_mS_ = _1l1l11lll11l1_mS_()
    out = l11lllllll11l1_mS_.l1l111lll11l1_mS_(l1l1l111l11l1_mS_)
    l1l1l1111l11l1_mS_ = {}
    if out and isinstance(out,list):
        l1l1l1111l11l1_mS_ = out[0]
        l1l1l111l11l1_mS_=l1l11l11l1_mS_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡲ࠵ࡷࡢࡶࡦ࡬ࡄࡼ࠽ࠦࡵౖࠪ") %l1l1l1111l11l1_mS_.get(l1l11l11l1_mS_ (u"ࠩ࡬ࡨࠬ౗"))
        try:
            import urlresolver
            l1l1l1111l11l1_mS_[l1l11l11l1_mS_ (u"ࠪࡹࡷࡲࠧౘ")] = urlresolver.resolve(l1l1l111l11l1_mS_)
        except:
            pass
    if index:
        l11llll1ll11l1_mS_[index]=l1l1l1111l11l1_mS_
    return l1l1l1111l11l1_mS_
def l11lll11ll11l1_mS_(l11l1ll11l11l1_mS_,passwd):
    l11lllllll11l1_mS_ = _1l1l11lll11l1_mS_()
    status=l11lllllll11l1_mS_.l11l1l1ll11l1_mS_(l11l1ll11l11l1_mS_,passwd)
    if status.get(l1l11l11l1_mS_ (u"ࠫࡸࡺࡡࡵࡷࡶࠫౙ")):
        xbmcgui.Dialog().notification(l1l11l11l1_mS_ (u"ࠬࡖ࡯࡮ࡻफ़ࡰࡳ࡫ࠠ࡭ࡱࡪࡳࡼࡧ࡮ࡪࡧࠪౚ"),l1l11l11l1_mS_ (u"࡛࠭ࡃ࡟ࡗࡻࡴࡰࡡࠡࡏࡸࡾࡾࡱࡡ࡜࠱ࡅࡡࠥࡰࡥࡴࡶࠣ࡮ࡺংࠠࡥࡱࡶࡸञࡶ࡮ࡢࠩ౛"), l11ll1llll11l1_mS_, 2000, False)
    else:
        xbmcgui.Dialog().notification(l1l11l11l1_mS_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࡕࡸ࡯ࡣ࡮ࡨࡱࠥࢀࠠ࡭ࡱࡪࡳࡼࡧ࡮ࡪࡧࡰ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ౜"),l1l11l11l1_mS_ (u"ࠨࡕࡳࡶࡦࡽࡤॻࠢࡧࡥࡳ࡫ࠠࡶॾࡼࡸࡰࡵࡷ࡯࡫࡮ࡥࠥࡽࠠࡰࡲࡦ࡮ࡦࡩࡨࠡࡹࡷࡽࡨࢀ࡫ࡪࠩౝ") ,l11ll1llll11l1_mS_, 5000)
def _1l1l11lll11l1_mS_():
    import l1l11l11l11l1_mS_ as l11lllllll11l1_mS_
    l11lllllll11l1_mS_.l1llll11l11l1_mS_=os.path.join(l1l1ll1l11l1_mS_,l1l11l11l1_mS_ (u"ࠩࡦࡳࡴࡱࡩࡦ࠰ࡧࡥࠬ౞"))
    return l11lllllll11l1_mS_
class l1llll1l11l1_mS_():
    @staticmethod
    def root():
        l1l11l1lll11l1_mS_(name=l1l11l11l1_mS_ (u"ࠪࡍࡳ࡬࡯ࡳ࡯ࡤࡧ࡯ࡧࠧ౟"),mode=l1l11l11l1_mS_ (u"ࠫࡤ࡯࡮ࡧࡱࡢࠫౠ"),ex_link=None,iconImage=l11ll1llll11l1_mS_,infoLabels={})
        l1l11l1lll11l1_mS_(name=l1l11l11l1_mS_ (u"ࠬࡖ࡯ࡱࡷ࡯ࡥࡷࡴࡹࠡࡃ࡯ࡦࡺࡳࠧౡ"),mode=l1l11l11l1_mS_ (u"࠭ࡰࡰࡲࡸࡰࡦࡸ࡟ࡢ࡮ࡥࡹࡲࡹࠧౢ"),ex_link=l1l11l11l1_mS_ (u"ࠧࠨౣ"),iconImage=l11l1l111l11l1_mS_+l1l11l11l1_mS_ (u"ࠨࡣ࡯ࡦࡺࡳ࠮ࡱࡰࡪࠫ౤"),infoLabels={})
        l1l11l1lll11l1_mS_(name=l1l11l11l1_mS_ (u"ࠩࡓࡳࡵࡻ࡬ࡢࡴࡱࡽࠥࡍࡡࡵࡷࡱࡩࡰ࠭౥"),mode=l1l11l11l1_mS_ (u"ࠪࡴࡴࡶࡵ࡭ࡣࡵࡣ࡬࡫࡮ࡳࡧࡶࠫ౦"),ex_link=l1l11l11l1_mS_ (u"ࠫࠬ౧"),iconImage=l11l1l111l11l1_mS_+l1l11l11l1_mS_ (u"ࠬ࡭ࡡࡵࡷࡱࡩࡰ࠴ࡰ࡯ࡩࠪ౨"),infoLabels={})
        l1l11l1lll11l1_mS_(name=l1l11l11l1_mS_ (u"࠭ࡔࡰࡲࠣ࠹࠵࠭౩"),mode=l1l11l11l1_mS_ (u"ࠧࡵࡱࡳࡣ࠺࠶ࠧ౪"),ex_link=l1l11l11l1_mS_ (u"ࠨࠩ౫"),iconImage=l11l1l111l11l1_mS_+l1l11l11l1_mS_ (u"ࠩࡷࡳࡵ࠴ࡰ࡯ࡩࠪ౬"),infoLabels={})
        l1l11l1lll11l1_mS_(name=l1l11l11l1_mS_ (u"ࠪࡒࡴࡽࡥࠡࡹࡼࡨࡦࡴࡩࡢࠩ౭"),mode=l1l11l11l1_mS_ (u"ࠫࡳ࡫ࡷࡠࡴࡨࡰࡪࡧࡳࡦࡵࠪ౮"),ex_link=l1l11l11l1_mS_ (u"ࠬ࠭౯"),iconImage=l11l1l111l11l1_mS_+l1l11l11l1_mS_ (u"࠭࡮ࡰࡹࡨ࠲ࡵࡴࡧࠨ౰"),infoLabels={})
        l11l1l11ll11l1_mS_={l1l11l11l1_mS_ (u"ࠧࡱ࡮ࡲࡸࠬ౱"):l1l11l11l1_mS_ (u"ࠨࡖࡺࡳ࡯ࡧࠠࡎࡷࡽࡽࡰࡧࠠ࠮ࠢࡽࡥࡼࡧࡲࡵࡱफ़ऋࠥࡹࡹ࡯ࡥ࡫ࡶࡴࡴࡩࡻࡣࡲࡻࡦࡴࡡࠡࡼࠣࡷࡪࡸࡷࡪࡵࡨࡱ࠳࠭౲")}
        l1l11l1lll11l1_mS_(name=l1l11l11l1_mS_ (u"ࠩࠣ࡟ࡇࡣࡐࡪࡱࡶࡩࡳࡱࡩ࡜࠱ࡅࡡࠬ౳"),mode=l1l11l11l1_mS_ (u"ࠪࡹࡸ࡫ࡲࡠࡥࡲࡲࡹ࡫࡮ࡵࠩ౴"),ex_link=l1l11l11l1_mS_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯࡯ࡸࡷ࡮ࡩࡳࡵࡴࡨࡥࡲ࠴ࡰ࡭࠱ࡶࡩࡨࡻࡲࡦ࠱ࡸࡷࡪࡸ࠯࡭࡫ࡥࡶࡦࡸࡹ࠰ࡶࡵࡥࡨࡱࡳࠨ౵"),iconImage=l11l1l111l11l1_mS_+l1l11l11l1_mS_ (u"ࠬࡺࡷࡠࡲ࡬ࡳࡸ࡫࡮࡬࡫࠱ࡴࡳ࡭ࠧ౶"),infoLabels=l11l1l11ll11l1_mS_)
        l1l11l1lll11l1_mS_(name=l1l11l11l1_mS_ (u"࠭ࠠ࡜ࡄࡠࡅࡱࡨࡵ࡮ࡻ࡞࠳ࡇࡣࠧ౷"),mode=l1l11l11l1_mS_ (u"ࠧࡶࡵࡨࡶࡤࡩ࡯࡯ࡶࡨࡲࡹ࠭౸"),ex_link=l1l11l11l1_mS_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡳࡵࡴ࡫ࡦࡷࡹࡸࡥࡢ࡯࠱ࡴࡱ࠵ࡳࡦࡥࡸࡶࡪ࠵ࡵࡴࡧࡵ࠳ࡱ࡯ࡢࡳࡣࡵࡽ࠴ࡧ࡬ࡣࡷࡰࡷࠬ౹"),iconImage=l11l1l111l11l1_mS_+l1l11l11l1_mS_ (u"ࠩࡤࡰࡧࡻ࡭࠯ࡲࡱ࡫ࠬ౺"),infoLabels=l11l1l11ll11l1_mS_)
        l1l11l1lll11l1_mS_(name=l1l11l11l1_mS_ (u"ࠪࠤࡠࡈ࡝ࡂࡴࡷࡽॠࡩࡩ࡜࠱ࡅࡡࠬ౻"),mode=l1l11l11l1_mS_ (u"ࠫࡺࡹࡥࡳࡡࡦࡳࡳࡺࡥ࡯ࡶࠪ౼"),ex_link=l1l11l11l1_mS_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡰࡹࡸ࡯ࡣࡴࡶࡵࡩࡦࡳ࠮ࡱ࡮࠲ࡷࡪࡩࡵࡳࡧ࠲ࡹࡸ࡫ࡲ࠰࡮࡬ࡦࡷࡧࡲࡺ࠱ࡤࡶࡹ࡯ࡳࡵࡵࠪ౽"),iconImage=l11l1l111l11l1_mS_+l1l11l11l1_mS_ (u"࠭ࡴࡸࡡࡤࡶࡹࡿࡳࡤ࡫࠱ࡴࡳ࡭ࠧ౾"),infoLabels=l11l1l11ll11l1_mS_)
        l1l11l1lll11l1_mS_(name=l1l11l11l1_mS_ (u"ࠧࡔࡼࡸ࡯ࡦࡰࠧ౿"),mode=l1l11l11l1_mS_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨಀ"),ex_link=None, iconImage=l11l1l111l11l1_mS_+l1l11l11l1_mS_ (u"ࠩࡶࡾࡺࡱࡡ࡫࠰ࡳࡲ࡬࠭ಁ"))
        xbmcplugin.endOfDirectory(l1l111l11l11l1_mS_)
    @staticmethod
    def l1llllll11l1_mS_():
        l11lllllll11l1_mS_ = _1l1l11lll11l1_mS_()
        out = l11lllllll11l1_mS_.l11llllll11l1_mS_()
        for f in out:
            l11ll1111l11l1_mS_(name=f.get(l1l11l11l1_mS_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩಂ")), url=f.get(l1l11l11l1_mS_ (u"ࠫ࡭ࡸࡥࡧࠩಃ")), mode=l1l11l11l1_mS_ (u"ࠬ࡭ࡥ࡯ࡴࡨࡷࡤࡧࡲࡵ࡫ࡶࡸࡸ࠭಄"), l1l1ll111l11l1_mS_=f.get(l1l11l11l1_mS_ (u"࠭ࡩ࡮ࡩࠪಅ")), infoLabels=f, isFolder=True, IsPlayable=False)
        xbmcplugin.endOfDirectory(l1l111l11l11l1_mS_)
    @staticmethod
    def l1lll1ll11l1_mS_(l11l11lll11l1_mS_):
        l11lllllll11l1_mS_ = _1l1l11lll11l1_mS_()
        out,l11ll1ll1l11l1_mS_ = l11lllllll11l1_mS_.l1lll1ll11l1_mS_(l11l11lll11l1_mS_)
        l11lll1l1l11l1_mS_=l1l11l11l1_mS_ (u"ࠧࡠࡡࡳࡥ࡬࡫࡟ࡠ࠼ࡪࡩࡳࡸࡥࡴࡡࡤࡶࡹ࡯ࡳࡵࡵࠪಆ")
        if l11ll1ll1l11l1_mS_[0]:
            l11ll1111l11l1_mS_(name=l1l11l11l1_mS_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬࡫࡭ࡺࡢ࡭ࡷࡨࡡࡁࡂࠠࡱࡱࡳࡶࡿ࡫ࡤ࡯࡫ࡤࠤࡸࡺࡲࡰࡰࡤࠤࡁࡂ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨಇ"), url=l11ll1ll1l11l1_mS_[0], mode=l11lll1l1l11l1_mS_, IsPlayable=False)
        for f in out:
            l11ll1111l11l1_mS_(name=f.get(l1l11l11l1_mS_ (u"ࠩࡷ࡭ࡹࡲࡥࠨಈ")), url=f.get(l1l11l11l1_mS_ (u"ࠪ࡬ࡷ࡫ࡦࠨಉ")), mode=l1l11l11l1_mS_ (u"ࠫࡦࡸࡴࡪࡵࡷࡣࡨࡵ࡮ࡵࡧࡱࡸࠬಊ"), l1l1ll111l11l1_mS_=f.get(l1l11l11l1_mS_ (u"ࠬ࡯࡭ࡨࠩಋ")), infoLabels=f, isFolder=True, IsPlayable=False)
        if l11ll1ll1l11l1_mS_[1]:
            l11ll1111l11l1_mS_(name=l1l11l11l1_mS_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸࡧࡲࡵࡦ࡟ࡁࡂࠥࡴࡡࡴࡶजࡴࡳࡧࠠࡴࡶࡵࡳࡳࡧࠠ࠿ࡀ࡞࠳ࡈࡕࡌࡐࡔࡠࠫಌ"), url=l11ll1ll1l11l1_mS_[1], mode=l11lll1l1l11l1_mS_, IsPlayable=False)
        xbmcplugin.endOfDirectory(l1l111l11l11l1_mS_)
    @staticmethod
    def l1l1l1l11l1_mS_(l11l11lll11l1_mS_):
        l11lllllll11l1_mS_ = _1l1l11lll11l1_mS_()
        out = l11lllllll11l1_mS_.l1l1l1l11l1_mS_(l11l11lll11l1_mS_)
        l11ll1ll1l11l1_mS_ = out.get(l1l11l11l1_mS_ (u"ࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ಍"),(False,False))
        l11l1111l11l1_mS_ = out.get(l1l11l11l1_mS_ (u"ࠨࡶࡲࡴࡤࡺࡲࡢࡥ࡮ࡷࠬಎ"),[])
        l11l1ll1l11l1_mS_ = out.get(l1l11l11l1_mS_ (u"ࠩࡤࡰࡧࡻ࡭ࡴࠩಏ"),[])
        if len(l11l1111l11l1_mS_)>1: l11ll1111l11l1_mS_(l1l11l11l1_mS_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡰ࡮࡭ࡨࡵࡤ࡯ࡹࡪࡣ࡛ࡃ࡟ࡓࡰࡦࡿࠠࡕࡱࡳࠤ࡙ࡸࡡࡤ࡭ࡶ࡟࠴ࡈ࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩಐ"), url=urllib.quote(str(l11l1111l11l1_mS_)), mode=l1l11l11l1_mS_ (u"ࠫࡵࡲࡡࡺ࡛ࡗࡅࡱࡲࠧ಑"), infoLabels={l1l11l11l1_mS_ (u"ࠬࡶ࡬ࡰࡶࠪಒ"):l1l11l11l1_mS_ (u"࠭ࡔࡸࡱࡵࡾࡾࠦࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡦࠢࡽࡩࠥࡽࡳࡻࡻࡶࡸࡰ࡯࡭ࡪࠢࡸࡸࡼࡵࡲࡢ࡯࡬ࠤࡼࠦ࡫ࡢࡶࡤࡰࡴ࡭ࡵࠨಓ")}, l1l1ll111l11l1_mS_=l11ll1llll11l1_mS_, IsPlayable=True)
        for f in l11l1111l11l1_mS_: l11ll1111l11l1_mS_(name=f.get(l1l11l11l1_mS_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ಔ")), url=f.get(l1l11l11l1_mS_ (u"ࠨࡪࡵࡩ࡫࠭ಕ")), mode=l1l11l11l1_mS_ (u"ࠩࡳࡰࡦࡿ࡙ࡕࠩಖ"), l1l1ll111l11l1_mS_=f.get(l1l11l11l1_mS_ (u"ࠪ࡭ࡲ࡭ࠧಗ")), infoLabels=f, isFolder=False, IsPlayable=True)
        l11lll1l1l11l1_mS_=l1l11l11l1_mS_ (u"ࠫࡤࡥࡰࡢࡩࡨࡣࡤࡀࡡࡳࡶ࡬ࡷࡹࡥࡣࡰࡰࡷࡩࡳࡺࠧಘ")
        for f in l11l1ll1l11l1_mS_:
            l11ll1111l11l1_mS_(name=f.get(l1l11l11l1_mS_ (u"ࠬࡺࡩࡵ࡮ࡨࠫಙ")), url=f.get(l1l11l11l1_mS_ (u"࠭ࡨࡳࡧࡩࠫಚ")), mode=l1l11l11l1_mS_ (u"ࠧࡱࡱࡳࡹࡱࡧࡲࡠࡣ࡯ࡦࡺࡳࡳࡠࡶࡵࡥࡨࡱࡳࠨಛ"), l1l1ll111l11l1_mS_=f.get(l1l11l11l1_mS_ (u"ࠨ࡫ࡰ࡫ࠬಜ")), infoLabels=f, isFolder=True, IsPlayable=False)
        if l11ll1ll1l11l1_mS_[1]:
            l11ll1111l11l1_mS_(name=l1l11l11l1_mS_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢ࡯࡭࡬࡮ࡴࡣ࡮ࡸࡩࡢࡄ࠾ࠡࡰࡤࡷࡹटࡰ࡯ࡣࠣࡷࡹࡸ࡯࡯ࡣࠣࡂࡃࡡ࠯ࡄࡑࡏࡓࡗࡣࠧಝ"), url=l11ll1ll1l11l1_mS_[1], mode=l11lll1l1l11l1_mS_, IsPlayable=False)
        xbmcplugin.endOfDirectory(l1l111l11l11l1_mS_)
    @staticmethod
    def l1l111l11l1_mS_(ex_link):
        l11lllllll11l1_mS_ = _1l1l11lll11l1_mS_()
        l11ll1l11l11l1_mS_ = eval(ex_link)
        status = l11lllllll11l1_mS_.l11ll1l1l11l1_mS_(l11ll1l11l11l1_mS_,l1l11l11l1_mS_ (u"ࠪࡥࡩࡪࠧಞ"))
        if status.get(l1l11l11l1_mS_ (u"ࠫࡸࡺࡡࡵࡷࡶࠫಟ")):
            xbmc.executebuiltin(l1l11l11l1_mS_ (u"ࠬࡔ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࠬࡠࡉࡏࡍࡑࡕࠤ࡬ࡸࡥࡦࡰࡠࡓࡐࡡ࠯ࡄࡑࡏࡓࡗࡣࠬࠨಠ")+status.get(l1l11l11l1_mS_ (u"࠭࡭ࡴࡩࠪಡ"))+l1l11l11l1_mS_ (u"ࠧࠡ࠮ࠣ࠶࠵࠶࠰ࠪࠩಢ"))
        else:
            xbmc.executebuiltin(l1l11l11l1_mS_ (u"ࠨࡐࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠨ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࡕࡸ࡯ࡣ࡮ࡨࡱࡠ࠵ࡃࡐࡎࡒࡖࡢ࠲ࠧಣ")+status.get(l1l11l11l1_mS_ (u"ࠩࡰࡷ࡬࠭ತ"))+l1l11l11l1_mS_ (u"ࠪ࠰࠷࠶࠰࠱ࠫࠪಥ"))
    @staticmethod
    def l11111l11l1_mS_(l11l11lll11l1_mS_):
        l11l1ll11l11l1_mS_ = l11l1l1lll11l1_mS_.getSetting(l1l11l11l1_mS_ (u"ࠫࡺࡹࡥࡳࠩದ"))
        passwd = l11l1l1lll11l1_mS_.getSetting(l1l11l11l1_mS_ (u"ࠬࡶࡡࡴࡵࠪಧ"))
        if not l11l1ll11l11l1_mS_ or not passwd:
            if xbmcgui.Dialog().yesno(l1l11l11l1_mS_ (u"ࠨࡔࡸࡱ࡭ࡥࠥࡓࡵࡻࡻ࡮ࡥࠧನ"),l1l11l11l1_mS_ (u"࡛ࠢࡣࡺࡥࡷࡺ࡯ड़उࠣࡸࡪ࡭࡯ࠡࡨࡲࡰࡩ࡫ࡲࡶࠢ࡭ࡩࡸࡺࠠࡥࡱࡶࡸञࡶ࡮ࡢࠢࡳࡳࠥࢀࡡ࡭ࡱࡪࡳࡼࡧ࡮ࡪࡷࠥ಩"),l1l11l11l1_mS_ (u"ࠣ࡝ࡅࡡ࡜ࡶࡲࡰࡹࡤࡨࡿ࡯इࠡࡦࡤࡲࡪࠦࡵॽࡻࡷ࡯ࡴࡽ࡮ࡪ࡭ࡤࡃࡠ࠵ࡂ࡞ࠤಪ")):
                l11l1l1lll11l1_mS_.openSettings()
                l11l1ll11l11l1_mS_ = l11l1l1lll11l1_mS_.getSetting(l1l11l11l1_mS_ (u"ࠩࡸࡷࡪࡸࠧಫ"))
                passwd = l11l1l1lll11l1_mS_.getSetting(l1l11l11l1_mS_ (u"ࠪࡴࡦࡹࡳࠨಬ"))
        l11lllllll11l1_mS_ = _1l1l11lll11l1_mS_()
        out = l11lllllll11l1_mS_.l11111l11l1_mS_(l11l11lll11l1_mS_)
        if not out and (l11l1ll11l11l1_mS_ and passwd):
            l11lll11ll11l1_mS_(l11l1ll11l11l1_mS_,passwd)
            out = l11lllllll11l1_mS_.l11111l11l1_mS_(l11l11lll11l1_mS_)
        l11ll1ll1l11l1_mS_ = out.get(l1l11l11l1_mS_ (u"ࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨಭ"),(False,False))
        l11ll111l11l1_mS_  = out.get(l1l11l11l1_mS_ (u"ࠬࡺࡲࡢࡥ࡮ࡷࠬಮ"),[])
        l11l1ll1l11l1_mS_  = out.get(l1l11l11l1_mS_ (u"࠭ࡡ࡭ࡤࡸࡱࡸ࠭ಯ"),[])
        l1l1l11ll11l1_mS_ = out.get(l1l11l11l1_mS_ (u"ࠧࡢࡴࡷ࡭ࡸࡺࡳࠨರ"),[])
        if len(l11ll111l11l1_mS_):
            if len(l11ll111l11l1_mS_)>1: l11ll1111l11l1_mS_(l1l11l11l1_mS_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬࡫࡭ࡺࡢ࡭ࡷࡨࡡࡠࡈ࡝ࡑ࡮ࡤࡽࠥࡇ࡬࡭࡝࠲ࡆࡢࡡ࠯ࡄࡑࡏࡓࡗࡣࠧಱ"), url=urllib.quote(str(l11ll111l11l1_mS_)), mode=l1l11l11l1_mS_ (u"ࠩࡳࡰࡦࡿ࡙ࡕࡃ࡯ࡰࠬಲ"), infoLabels={l1l11l11l1_mS_ (u"ࠪࡴࡱࡵࡴࠨಳ"):l1l11l11l1_mS_ (u"࡙ࠫࡽ࡯ࡳࡼࡼࠤࡵࡲࡡࡺ࡮࡬ࡷࡹ࡫ࠠࡻࡧࠣࡻࡸࢀࡹࡴࡶ࡮࡭ࡲ࡯ࠠࡶࡶࡺࡳࡷࡧ࡭ࡪࠢࡺࠤࡰࡧࡴࡢ࡮ࡲ࡫ࡺ࠭಴")}, l1l1ll111l11l1_mS_=l11ll1llll11l1_mS_, IsPlayable=True)
            for f in l11ll111l11l1_mS_: l11ll1111l11l1_mS_(name=f.get(l1l11l11l1_mS_ (u"ࠬࡺࡩࡵ࡮ࡨࠫವ")), url=f.get(l1l11l11l1_mS_ (u"࠭ࡨࡳࡧࡩࠫಶ")), mode=l1l11l11l1_mS_ (u"ࠧࡱ࡮ࡤࡽ࡞࡚ࠧಷ"), l1l1ll111l11l1_mS_=f.get(l1l11l11l1_mS_ (u"ࠨ࡫ࡰ࡫ࠬಸ")), infoLabels=f, isFolder=False, IsPlayable=True)
        l11lll1l1l11l1_mS_=l1l11l11l1_mS_ (u"ࠩࡢࡣࡵࡧࡧࡦࡡࡢ࠾ࡦࡸࡴࡪࡵࡷࡣࡨࡵ࡮ࡵࡧࡱࡸࠬಹ")
        for f in l11l1ll1l11l1_mS_:
            l11ll1111l11l1_mS_(name=f.get(l1l11l11l1_mS_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ಺")), url=f.get(l1l11l11l1_mS_ (u"ࠫ࡭ࡸࡥࡧࠩ಻")), mode=l1l11l11l1_mS_ (u"ࠬࡶ࡯ࡱࡷ࡯ࡥࡷࡥࡡ࡭ࡤࡸࡱࡸࡥࡴࡳࡣࡦ࡯ࡸ಼࠭"), l1l1ll111l11l1_mS_=f.get(l1l11l11l1_mS_ (u"࠭ࡩ࡮ࡩࠪಽ")), infoLabels=f, isFolder=True, IsPlayable=False)
        for f in l1l1l11ll11l1_mS_:
            l11ll1111l11l1_mS_(name=f.get(l1l11l11l1_mS_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ಾ")), url=f.get(l1l11l11l1_mS_ (u"ࠨࡪࡵࡩ࡫࠭ಿ")), mode=l1l11l11l1_mS_ (u"ࠩࡤࡶࡹ࡯ࡳࡵࡡࡦࡳࡳࡺࡥ࡯ࡶࠪೀ"), l1l1ll111l11l1_mS_=f.get(l1l11l11l1_mS_ (u"ࠪ࡭ࡲ࡭ࠧು")), infoLabels=f, isFolder=True, IsPlayable=False)
        if l11ll1ll1l11l1_mS_[1]:
            l11ll1111l11l1_mS_(name=l1l11l11l1_mS_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡱ࡯ࡧࡩࡶࡥࡰࡺ࡫࡝࠿ࡀࠣࡲࡦࡹࡴचࡲࡱࡥࠥࡹࡴࡳࡱࡱࡥࠥࡄ࠾࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩೂ"), url=l11ll1ll1l11l1_mS_[1], mode=l11lll1l1l11l1_mS_, IsPlayable=False)
        xbmcplugin.endOfDirectory(l1l111l11l11l1_mS_)
    @staticmethod
    def l11l11l11l1_mS_():
        l11lllllll11l1_mS_ = _1l1l11lll11l1_mS_()
        out = l11lllllll11l1_mS_.l11l11l11l1_mS_()
        for f in out: l11ll1111l11l1_mS_(name=f.get(l1l11l11l1_mS_ (u"ࠬࡺࡩࡵ࡮ࡨࠫೃ")), url=f.get(l1l11l11l1_mS_ (u"࠭ࡨࡳࡧࡩࠫೄ")), mode=l1l11l11l1_mS_ (u"ࠧࡱࡱࡳࡹࡱࡧࡲࡠࡣ࡯ࡦࡺࡳࡳࡠࡶࡵࡥࡨࡱࡳࠨ೅"), l1l1ll111l11l1_mS_=f.get(l1l11l11l1_mS_ (u"ࠨ࡫ࡰ࡫ࠬೆ")), infoLabels=f, isFolder=True, IsPlayable=False)
        xbmcplugin.endOfDirectory(l1l111l11l11l1_mS_)
    @staticmethod
    def l1lll1l11l1_mS_(mode,ex_link):
        _1l11lllll11l1_mS_=mode.split(l1l11l11l1_mS_ (u"ࠤ࠽ࠦೇ"))[-1]
        url = l1l1ll1l1l11l1_mS_({l1l11l11l1_mS_ (u"ࠪࡱࡴࡪࡥࠨೈ"): _1l11lllll11l1_mS_, l1l11l11l1_mS_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨ೉"): l1l11l11l1_mS_ (u"ࠬ࠭ೊ"), l1l11l11l1_mS_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧೋ") : ex_link })
        xbmc.executebuiltin(l1l11l11l1_mS_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠧࡶ࠭ࠬೌ")% url)
    @staticmethod
    def l111lll11l1_mS_():
        l11lllllll11l1_mS_ = _1l1l11lll11l1_mS_()
        out = l11lllllll11l1_mS_.l111lll11l1_mS_()
        for f in out:
            l11ll1111l11l1_mS_(name=f.get(l1l11l11l1_mS_ (u"ࠨࡶ࡬ࡸࡱ࡫್ࠧ")), url=f.get(l1l11l11l1_mS_ (u"ࠩ࡫ࡶࡪ࡬ࠧ೎")), mode=l1l11l11l1_mS_ (u"ࠪࡴࡴࡶࡵ࡭ࡣࡵࡣࡦࡲࡢࡶ࡯ࡶࡣࡹࡸࡡࡤ࡭ࡶࠫ೏"), l1l1ll111l11l1_mS_=f.get(l1l11l11l1_mS_ (u"ࠫ࡮ࡳࡧࠨ೐")), infoLabels=f, isFolder=True, IsPlayable=False)
        xbmcplugin.endOfDirectory(l1l111l11l11l1_mS_)
    @staticmethod
    def l1ll1ll11l1_mS_(l11l1ll11l1_mS_):
        l11lllllll11l1_mS_ = _1l1l11lll11l1_mS_()
        out = l11lllllll11l1_mS_.l1ll1ll11l1_mS_(l11l1ll11l1_mS_)
        if len(out)>1: l11ll1111l11l1_mS_(l1l11l11l1_mS_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡲࡩࡨࡪࡷࡦࡱࡻࡥ࡞࡝ࡅࡡࡕࡲࡡࡺࠢࡄࡰࡧࡻ࡭࡜࠱ࡅࡡࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭೑"), url=urllib.quote(str(out)), mode=l1l11l11l1_mS_ (u"࠭ࡰ࡭ࡣࡼ࡝࡙ࡇ࡬࡭ࠩ೒"), infoLabels={l1l11l11l1_mS_ (u"ࠧࡱ࡮ࡲࡸࠬ೓"):l1l11l11l1_mS_ (u"ࠨࡖࡺࡳࡷࢀࡹࠡࡲ࡯ࡥࡾࡲࡩࡴࡶࡨࠤࡐࡕࡄࡊࠢࡽࡩࠥࡽࡳࡻࡻࡶࡸࡰ࡯࡭ࡪࠢࡸࡸࡼࡵࡲࡢ࡯࡬ࠤࡼࠦ࡫ࡢࡶࡤࡰࡴ࡭ࡵࠨ೔")}, l1l1ll111l11l1_mS_=l11ll1llll11l1_mS_, IsPlayable=True)
        for f in out:
            l11ll1111l11l1_mS_(name=f.get(l1l11l11l1_mS_ (u"ࠩࡷ࡭ࡹࡲࡥࠨೕ")), url=f.get(l1l11l11l1_mS_ (u"ࠪ࡬ࡷ࡫ࡦࠨೖ")), mode=l1l11l11l1_mS_ (u"ࠫࡵࡲࡡࡺ࡛ࡗࠫ೗"), l1l1ll111l11l1_mS_=f.get(l1l11l11l1_mS_ (u"ࠬ࡯࡭ࡨࠩ೘")), infoLabels=f, isFolder=False, IsPlayable=True)
        xbmcplugin.endOfDirectory(l1l111l11l11l1_mS_)
    @staticmethod
    def l1lll11l11l1_mS_():
        l11lllllll11l1_mS_ = _1l1l11lll11l1_mS_()
        out = l11lllllll11l1_mS_.l1lll11l11l1_mS_()
        if len(out)>1: l11ll1111l11l1_mS_(l1l11l11l1_mS_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸࡧࡲࡵࡦ࡟࡞ࡆࡢࡖ࡬ࡢࡻࠣࡅࡱࡲ࡛࠰ࡄࡠ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ೙"), url=urllib.quote(str(out)), mode=l1l11l11l1_mS_ (u"ࠧࡱ࡮ࡤࡽ࡞࡚ࡁ࡭࡮ࠪ೚"), infoLabels={l1l11l11l1_mS_ (u"ࠨࡲ࡯ࡳࡹ࠭೛"):l1l11l11l1_mS_ (u"ࠩࡗࡻࡴࡸࡺࡺࠢࡳࡰࡦࡿ࡬ࡪࡵࡷࡩࠥࢀࡥࠡࡹࡶࡾࡾࡹࡴ࡬࡫ࡰ࡭ࠥࡻࡴࡸࡱࡵࡥࡲ࡯ࠠࡸࠢ࡮ࡥࡹࡧ࡬ࡰࡩࡸࠫ೜")}, l1l1ll111l11l1_mS_=l11ll1llll11l1_mS_, IsPlayable=True)
        for f in out:
            l11ll1111l11l1_mS_(name=f.get(l1l11l11l1_mS_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩೝ")), url=f.get(l1l11l11l1_mS_ (u"ࠫ࡭ࡸࡥࡧࠩೞ")), mode=l1l11l11l1_mS_ (u"ࠬࡶ࡬ࡢࡻ࡜ࡘࠬ೟"), l1l1ll111l11l1_mS_=f.get(l1l11l11l1_mS_ (u"࠭ࡩ࡮ࡩࠪೠ")), infoLabels=f, isFolder=False, IsPlayable=True)
        xbmcplugin.endOfDirectory(l1l111l11l11l1_mS_)
    @staticmethod
    def l1111ll11l1_mS_(ex_link):
        l11lllllll11l1_mS_ = _1l1l11lll11l1_mS_()
        out = l11lllllll11l1_mS_.l1l111lll11l1_mS_(ex_link)
        if out and isinstance(out,list):
            l1l1l111l11l1_mS_=l1l11l11l1_mS_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡺࡱࡸࡸࡺࡨࡥ࠯ࡥࡲࡱ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࠥࡴࠩೡ") %out[0].get(l1l11l11l1_mS_ (u"ࠨ࡫ࡧࠫೢ"))
            try:
                import urlresolver
                l11l1l1l1l11l1_mS_ = urlresolver.resolve(l1l1l111l11l1_mS_)
            except Exception,e:
                l11l1l1l1l11l1_mS_=l1l11l11l1_mS_ (u"ࠩࠪೣ")
            if l11l1l1l1l11l1_mS_:
                xbmcplugin.setResolvedUrl(l1l111l11l11l1_mS_, True, xbmcgui.ListItem(path=l11l1l1l1l11l1_mS_))
            else:
                xbmcplugin.setResolvedUrl(l1l111l11l11l1_mS_, False, xbmcgui.ListItem(path=l1l11l11l1_mS_ (u"ࠪࠫ೤")))
    @staticmethod
    def l11ll1l11l1_mS_(l1ll111l1l11l1_mS_):
        data = eval(urllib.unquote(l1ll111l1l11l1_mS_))
        l1l1l1l11l11l1_mS_ = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        l1l1l1l11l11l1_mS_.clear()
        l11ll11lll11l1_mS_ = data[0].get(l1l11l11l1_mS_ (u"ࠫ࡭ࡸࡥࡧࠩ೥"))
        first = l1ll111lll11l1_mS_(l11ll11lll11l1_mS_)
        l1l111l1ll11l1_mS_ = xbmcgui.ListItem(first.get(l1l11l11l1_mS_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ೦")) )
        l1l111l1ll11l1_mS_.setArt( {l1l11l11l1_mS_ (u"࠭ࡴࡩࡷࡰࡦࠬ೧"):first.get(l1l11l11l1_mS_ (u"ࠧࡪ࡯ࡪࠫ೨")) } )
        l1l111l1ll11l1_mS_.setInfo(type=l1l11l11l1_mS_ (u"ࠣࡸ࡬ࡨࡪࡵࠢ೩"), infoLabels=first)
        l1l1l1l11l11l1_mS_.add(url=first.get(l1l11l11l1_mS_ (u"ࠩࡸࡶࡱ࠭೪")),listitem=l1l111l1ll11l1_mS_)
        l1l1l1l11l11l1_mS_.add(url=first.get(l1l11l11l1_mS_ (u"ࠪࡹࡷࡲࠧ೫")),listitem=l1l111l1ll11l1_mS_)
        if l1l1l1l11l11l1_mS_:
            xbmcplugin.setResolvedUrl(l1l111l11l11l1_mS_, True, xbmcgui.ListItem(path=l1l11l11l1_mS_ (u"ࠫࠬ೬")))
            for d in data[1:]:
                l11ll11lll11l1_mS_ = d.get(l1l11l11l1_mS_ (u"ࠬ࡮ࡲࡦࡨࠪ೭"),l1l11l11l1_mS_ (u"࠭ࠧ೮"))
                first = l1ll111lll11l1_mS_(l11ll11lll11l1_mS_)
                l1l111l1ll11l1_mS_ = xbmcgui.ListItem(first.get(l1l11l11l1_mS_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭೯")) )
                l1l111l1ll11l1_mS_.setArt( {l1l11l11l1_mS_ (u"ࠨࡶ࡫ࡹࡲࡨࠧ೰"):first.get(l1l11l11l1_mS_ (u"ࠩ࡬ࡱ࡬࠭ೱ")) } )
                l1l111l1ll11l1_mS_.setInfo(type=l1l11l11l1_mS_ (u"ࠥࡺ࡮ࡪࡥࡰࠤೲ"), infoLabels=first)
                l1l1l1l11l11l1_mS_.add(url=first.get(l1l11l11l1_mS_ (u"ࠫࡺࡸ࡬ࠨೳ")),listitem=l1l111l1ll11l1_mS_)
    @staticmethod
    def info():
        l1l1l1ll1l11l1_mS_.__myinfo__.go(sys.argv)
        xbmcplugin.endOfDirectory(l1l111l11l11l1_mS_)
    @staticmethod
    def l1ll11l11l1_mS_(mode,ex_link):
        from l11lll1lll11l1_mS_ import l11ll11l1l11l1_mS_
        l11l1lll1l11l1_mS_=mode.split(l1l11l11l1_mS_ (u"ࠧࡀࠢ೴"))[-1] if l1l11l11l1_mS_ (u"࠭࠺ࠨ೵") in mode else l1l11l11l1_mS_ (u"ࠧࠨ೶")
        if l11l1lll1l11l1_mS_ == l1l11l11l1_mS_ (u"ࠨࠩ೷"):
            l1l11l1lll11l1_mS_(l1l11l11l1_mS_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢ࡯࡭࡬࡮ࡴࡨࡴࡨࡩࡳࡣࡎࡰࡹࡨࠤࡸࢀࡵ࡬ࡣࡱ࡭ࡪࠦ࠮࠯࠰࡞࠳ࡈࡕࡌࡐࡔࡠࠫ೸"),ex_link=l1l11l11l1_mS_ (u"ࠪࠫ೹"),mode=l1l11l11l1_mS_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫࠾ࡳ࡫ࡷࠨ೺"))
            l11lllll1l11l1_mS_ = l11ll11l1l11l1_mS_().l1l11l111l11l1_mS_()
            if not l11lllll1l11l1_mS_ == [l1l11l11l1_mS_ (u"ࠬ࠭೻")]:
                for entry in l11lllll1l11l1_mS_:
                    contextmenu = []
                    contextmenu.append((l1l11l11l1_mS_ (u"ࡻࠧࡓࡧࡰࡳࡻ࡫ࠧ೼"), l1l11l11l1_mS_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠧࡶ࠭ࠬ೽")% l1l1ll1l1l11l1_mS_({l1l11l11l1_mS_ (u"ࠨ࡯ࡲࡨࡪ࠭೾"): l1l11l11l1_mS_ (u"ࠩࡶࡩࡦࡸࡣࡩ࠼ࡧࡩࡱࡕ࡮ࡦࠩ೿"), l1l11l11l1_mS_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫഀ") : entry})),)
                    contextmenu.append((l1l11l11l1_mS_ (u"ࡹࠬࡘࡥ࡮ࡱࡹࡩࠥࡇ࡬࡭ࠩഁ"), l1l11l11l1_mS_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠥࡴࠫࠪം") % l1l1ll1l1l11l1_mS_({l1l11l11l1_mS_ (u"࠭࡭ࡰࡦࡨࠫഃ"): l1l11l11l1_mS_ (u"ࠧࡴࡧࡤࡶࡨ࡮࠺ࡥࡧ࡯ࡅࡱࡲࠧഄ")})),)
                    l1l11l1lll11l1_mS_(name=entry, ex_link=entry, mode=l1l11l11l1_mS_ (u"ࠨࡵࡨࡥࡷࡩࡨ࠻ࡰࡨࡻࠬഅ"), fanart=None, contextmenu=contextmenu)
            xbmcplugin.endOfDirectory(l1l111l11l11l1_mS_)
        elif l11l1lll1l11l1_mS_ ==l1l11l11l1_mS_ (u"ࠩࡱࡩࡼ࠭ആ"):
            if not ex_link:
                l11ll111ll11l1_mS_ = l1l1lll11l1_mS_.input(l1l11l11l1_mS_ (u"ࡸࠫࡼࡿ࡫ࡰࡰࡤࡻࡨࡧ࠯ࡢ࡮ࡥࡹࡲ࠵ࡵࡵࡹࣶࡶࠬഇ"), type=xbmcgui.INPUT_ALPHANUM)
                if l11ll111ll11l1_mS_: l11ll11l1l11l1_mS_().l11llll11l11l1_mS_(l11ll111ll11l1_mS_)
            else:
                l11ll111ll11l1_mS_ = ex_link
            if l11ll111ll11l1_mS_:
                l11lllllll11l1_mS_ = _1l1l11lll11l1_mS_()
                out = l11lllllll11l1_mS_.search(l11ll111ll11l1_mS_)
                l11ll111l11l1_mS_  = out.get(l1l11l11l1_mS_ (u"ࠫࡹࡸࡡࡤ࡭ࡶࠫഈ"),[])
                l11l1ll1l11l1_mS_  = out.get(l1l11l11l1_mS_ (u"ࠬࡧ࡬ࡣࡷࡰࡷࠬഉ"),[])
                l1l1l11ll11l1_mS_ = out.get(l1l11l11l1_mS_ (u"࠭ࡡࡳࡶ࡬ࡷࡹࡹࠧഊ"),[])
                for f in l11ll111l11l1_mS_: l11ll1111l11l1_mS_(name=f.get(l1l11l11l1_mS_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ഋ")), url=f.get(l1l11l11l1_mS_ (u"ࠨࡪࡵࡩ࡫࠭ഌ")), mode=l1l11l11l1_mS_ (u"ࠩࡳࡰࡦࡿ࡙ࡕࠩ഍"), l1l1ll111l11l1_mS_=f.get(l1l11l11l1_mS_ (u"ࠪ࡭ࡲ࡭ࠧഎ")), infoLabels=f, isFolder=False, IsPlayable=True)
                for f in l11l1ll1l11l1_mS_: l11ll1111l11l1_mS_(name=f.get(l1l11l11l1_mS_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪഏ")), url=f.get(l1l11l11l1_mS_ (u"ࠬ࡮ࡲࡦࡨࠪഐ")), mode=l1l11l11l1_mS_ (u"࠭ࡰࡰࡲࡸࡰࡦࡸ࡟ࡢ࡮ࡥࡹࡲࡹ࡟ࡵࡴࡤࡧࡰࡹࠧ഑"), l1l1ll111l11l1_mS_=f.get(l1l11l11l1_mS_ (u"ࠧࡪ࡯ࡪࠫഒ")), infoLabels=f, isFolder=True, IsPlayable=False)
                for f in l1l1l11ll11l1_mS_:l11ll1111l11l1_mS_(name=f.get(l1l11l11l1_mS_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧഓ")), url=f.get(l1l11l11l1_mS_ (u"ࠩ࡫ࡶࡪ࡬ࠧഔ")), mode=l1l11l11l1_mS_ (u"ࠪࡥࡷࡺࡩࡴࡶࡢࡧࡴࡴࡴࡦࡰࡷࠫക"), l1l1ll111l11l1_mS_=f.get(l1l11l11l1_mS_ (u"ࠫ࡮ࡳࡧࠨഖ")), infoLabels=f, isFolder=True, IsPlayable=False)
            xbmcplugin.endOfDirectory(l1l111l11l11l1_mS_)
        elif l11l1lll1l11l1_mS_ ==l1l11l11l1_mS_ (u"ࠬࡪࡥ࡭ࡑࡱࡩࠬഗ"):
            l11ll11l1l11l1_mS_().l1l1l11l1l11l1_mS_(ex_link)
            xbmc.executebuiltin(l1l11l11l1_mS_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࠦࡵࠬࠫഘ")%  l1l1ll1l1l11l1_mS_({l1l11l11l1_mS_ (u"ࠧ࡮ࡱࡧࡩࠬങ"): l1l11l11l1_mS_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨച")}))
        elif l11l1lll1l11l1_mS_ ==l1l11l11l1_mS_ (u"ࠩࡧࡩࡱࡇ࡬࡭ࠩഛ"):
            l11ll11l1l11l1_mS_().l1l111111l11l1_mS_()
            xbmc.executebuiltin(l1l11l11l1_mS_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࠪࡹࠩࠨജ")%  l1l1ll1l1l11l1_mS_({l1l11l11l1_mS_ (u"ࠫࡲࡵࡤࡦࠩഝ"): l1l11l11l1_mS_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬഞ")}))
