# -*- coding: utf-8 -*-
import sys
l111l11l1_mS_ = sys.version_info [0] == 2
l111ll11l1_mS_ = 2048
l1l1ll11l1_mS_ = 7
def l1l11l11l1_mS_ (keyedStringLiteral):
	global l1llll11l1_mS_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l11l1_mS_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll11l1_mS_ - (charIndex + stringNr) % l1l1ll11l1_mS_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll11l1_mS_ - (charIndex + stringNr) % l1l1ll11l1_mS_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os,json,base64
from random import choice
import cookielib
from urlparse import urlparse,urljoin
l1l11lll11l1_mS_ = 15
l1l1ll11l11l1_mS_=l1l11l11l1_mS_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠼࠮࠲࠽࡛ࠣ࡮ࡴ࠶࠵࠽ࠣࡼ࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠼࠱࠯࠲࠱࠷࠶࠼࠳࠯࠳࠳࠴࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬह")
l1llll11l11l1_mS_=os.path.join(os.getcwd(),l1l11l11l1_mS_ (u"ࠪࡧࡴࡵ࡫ࡪࡧࠪऺ"))
def l11ll11ll11l1_mS_(u):
    l11lll1ll11l1_mS_ = l1l11l1ll11l1_mS_()
    headers = { l1l11l11l1_mS_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨऻ"): l1l1ll11l11l1_mS_, l1l11l11l1_mS_ (u"ࠬࡸࡥࡧࡧࡵࡩࡷ़࠭"): l1l11l11l1_mS_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡱࡺࡹࡩࡤࡵࡷࡶࡪࡧ࡭࠯ࡲ࡯࠳ࠬऽ"), l1l11l11l1_mS_ (u"ࠧࡤࡱࡲ࡯࡮࡫ࠧा"):l11lll1ll11l1_mS_}
    try:
        l1l11111l11l1_mS_ = urllib2.Request(u, None, headers)
        l11lll11l11l1_mS_ = urllib2.urlopen(l1l11111l11l1_mS_)
        data = json.load(l11lll11l11l1_mS_)
    except:
        data={}
    return data
def l11111l11l1_mS_(url):
    dd = l11ll11ll11l1_mS_(url)
    if not dd: return {}
    out={}
    if l1l11l11l1_mS_ (u"ࠨ࠱࡯࡭ࡧࡸࡡࡳࡻ࠲ࡸࡷࡧࡣ࡬ࡵࠪि")in url:
        l11ll111l11l1_mS_ = dd.get(l1l11l11l1_mS_ (u"ࠩࡧࡥࡹࡧࠧी"),[])
        l1lll1l1l11l1_mS_=dd.get(l1l11l11l1_mS_ (u"ࠪࡲࡪࡾࡴࡠࡲࡤ࡫ࡪࡥࡵࡳ࡮ࠪु"),False)
        l1l1l1ll11l1_mS_=dd.get(l1l11l11l1_mS_ (u"ࠫࡵࡸࡥࡷࡡࡳࡥ࡬࡫࡟ࡶࡴ࡯ࠫू"),False)
        out[l1l11l11l1_mS_ (u"ࠬࡺࡲࡢࡥ࡮ࡷࠬृ")] = l1ll1ll11l1_mS_(l11ll111l11l1_mS_)
        out[l1l11l11l1_mS_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪॄ")]=(l1l1l1ll11l1_mS_,l1lll1l1l11l1_mS_)
    elif l1l11l11l1_mS_ (u"ࠧ࠰࡮࡬ࡦࡷࡧࡲࡺ࠱ࡤࡰࡧࡻ࡭ࡴࠩॅ")in url:
        out[l1l11l11l1_mS_ (u"ࠨࡣ࡯ࡦࡺࡳࡳࠨॆ")]= _11l11l1l11l1_mS_(dd)
    elif l1l11l11l1_mS_ (u"ࠩ࡯࡭ࡧࡸࡡࡳࡻ࠲ࡥࡷࡺࡩࡴࡶࡶࠫे") in url:
        out[l1l11l11l1_mS_ (u"ࠪࡥࡷࡺࡩࡴࡶࡶࠫै")] = _1l1l1lll11l1_mS_(dd)
    return out
from ramic import go as l11llll1l11l1_mS_
l11l1llll11l1_mS_ = l11llll1l11l1_mS_.get(l1l11l11l1_mS_ (u"ࠫࡩ࡫ࡣࡰࡦࡨࡌ࡙ࡓࡌࡦࡰࡷࡶ࡮࡫ࡳࠨॉ"),False)
l11ll1lll11l1_mS_ = l11llll1l11l1_mS_.get(l1l11l11l1_mS_ (u"ࠬࡨࡵࡪ࡮ࡧࡧ࡭࡫ࡣ࡬ࠩॊ"),False)
class l1ll111ll11l1_mS_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
def l11ll1l1l11l1_mS_(ids=[25498],action=l1l11l11l1_mS_ (u"࠭ࡡࡥࡦࠪो")):
    if not ids:
        status = {l1l11l11l1_mS_ (u"ࠧ࡮ࡵࡪࠫौ"):l1l11l11l1_mS_ (u"ࠨࡄࡵࡥࡰࠦࡩࡥࡧࡱࡸࡾ࡬ࡩ࡬ࡣࡷࡳࡷࡧࠠࡱࡱࡽࡽࡨࡰࡩࠨ्"),l1l11l11l1_mS_ (u"ࠩࡶࡸࡦࡺࡵࡴࠩॎ"):False}
    else:
        url = l1l11l11l1_mS_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮࡮ࡷࡶ࡭ࡨࡹࡴࡳࡧࡤࡱ࠳ࡶ࡬࠰ࡵࡨࡧࡺࡸࡥ࠰ࡷࡶࡩࡷ࠵࡬ࡪࡤࡵࡥࡷࡿ࠯ࡵࡴࡤࡧࡰࡹ࠯ࠨॏ")+action
        l1l11llll11l1_mS_ = {l1l11l11l1_mS_ (u"ࠦ࡮ࡪࡳࠣॐ"):ids}
        params = urllib.urlencode(l1l11llll11l1_mS_)
        l1ll111l11l1_mS_ = cookielib.LWPCookieJar()
        try: l1ll111l11l1_mS_.load(l1llll11l11l1_mS_,True,True)
        except: l1ll111l11l1_mS_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1ll111l11l1_mS_),urllib2.HTTPRedirectHandler())
        urllib2.install_opener(opener)
        l11l111ll11l1_mS_ = l1l11l1ll11l1_mS_()
        token = re.findall(l1l11l11l1_mS_ (u"ࠬ࡞ࡓࡓࡈ࠰ࡘࡔࡑࡅࡏ࠿ࠫ࠲࠯ࡅࠩ࠼ࠩ॑"),l11l111ll11l1_mS_)
        if not token:
            status = {l1l11l11l1_mS_ (u"࠭࡭ࡴࡩ॒ࠪ"):l1l11l11l1_mS_ (u"ࠧ࡯࡫ࡨࠤ࡯࡫ࡳࡵࡧࡶࡸࡪॡࠠࡻࡣ࡯ࡳ࡬ࡵࡷࡢࡰࡼࠫ॓"),l1l11l11l1_mS_ (u"ࠨࡵࡷࡥࡹࡻࡳࠨ॔"):False}
            return status
        l11l111ll11l1_mS_+=l1l11l11l1_mS_ (u"ࠩࡶ࡭ࡲࡶ࡬ࡦࡥࡲࡳࡰ࡯ࡥ࡯ࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳࡥࡶ࠱࠳ࡀ࠵ࡀ࠭ॕ")
        header = { l1l11l11l1_mS_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧॖ"): l1l1ll11l11l1_mS_, l1l11l11l1_mS_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫॗ"):l11l111ll11l1_mS_,l1l11l11l1_mS_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭क़"):l1l11l11l1_mS_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡱࡺࡹࡩࡤࡵࡷࡶࡪࡧ࡭࠯ࡲ࡯ࠫख़"),l1l11l11l1_mS_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭ग़"):l1l11l11l1_mS_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫज़"),l1l11l11l1_mS_ (u"࡛ࠩ࠱࡝࡙ࡒࡇ࠯ࡗࡓࡐࡋࡎࠨड़"):token[0],
                   l1l11l11l1_mS_ (u"ࠪࡌࡴࡹࡴࠨढ़"):l1l11l11l1_mS_ (u"ࠫࡼࡽࡷ࠯࡯ࡸࡷ࡮ࡩࡳࡵࡴࡨࡥࡲ࠴ࡰ࡭ࠩफ़"),l1l11l11l1_mS_ (u"ࠬࡕࡲࡪࡩ࡬ࡲࠬय़"):l1l11l11l1_mS_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡱࡺࡹࡩࡤࡵࡷࡶࡪࡧ࡭࠯ࡲ࡯ࠫॠ"),l1l11l11l1_mS_ (u"ࠧࡄࡱࡱࡲࡪࡩࡴࡪࡱࡱࠫॡ"):l1l11l11l1_mS_ (u"ࠨ࡭ࡨࡩࡵ࠳ࡡ࡭࡫ࡹࡩࠬॢ"),l1l11l11l1_mS_ (u"ࠩࡄࡧࡨ࡫ࡰࡵࠩॣ"):l1l11l11l1_mS_ (u"ࠪ࠮࠴࠰ࠧ।"),l1l11l11l1_mS_ (u"ࠫࡕࡸࡡࡨ࡯ࡤࠫ॥"):l1l11l11l1_mS_ (u"ࠬࡴ࡯࠮ࡥࡤࡧ࡭࡫ࠧ०")}
        try:
            req = urllib2.Request(url, params ,header)
            response = urllib2.urlopen(req)
            content = response.read()
            response.close()
            status = {l1l11l11l1_mS_ (u"࠭࡭ࡴࡩࠪ१"):l1l11l11l1_mS_ (u"ࠧࡂ࡭ࡦ࡮ࡦࠦࡺࡢ࡭ࡲैࡨࢀ࡯࡯ࡣࠣࡴࡴࡳࡹड़࡮ࡱ࡭ࡪࠧࠧ२"),l1l11l11l1_mS_ (u"ࠨࡵࡷࡥࡹࡻࡳࠨ३"):True}
        except:
            status = {l1l11l11l1_mS_ (u"ࠩࡰࡷ࡬࠭४"):l1l11l11l1_mS_ (u"ࠪࡗࡪࡸࡷࡪࡵࠣࡾࡼࡸࣳࡤ࡫ॅࠤࡧैࡡࡥࠩ५"),l1l11l11l1_mS_ (u"ࠫࡸࡺࡡࡵࡷࡶࠫ६"):False}
    return status
def l1l11l1ll11l1_mS_():
    l1ll111l11l1_mS_ = cookielib.LWPCookieJar()
    try:
        l1ll111l11l1_mS_.load(l1llll11l11l1_mS_,True,True)
        l11l111ll11l1_mS_ = l1l11l11l1_mS_ (u"ࠬࡁࠧ७").join([l1l11l11l1_mS_ (u"࠭ࠥࡴ࠿ࠨࡷࠬ८")%(c.name,c.value) for c in l1ll111l11l1_mS_])
    except:
        l11l111ll11l1_mS_=l1l11l11l1_mS_ (u"ࠧࠨ९")
    return l11l111ll11l1_mS_
def l11l1l1ll11l1_mS_(u,p):
    url = l1l11l11l1_mS_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡳࡵࡴ࡫ࡦࡷࡹࡸࡥࡢ࡯࠱ࡴࡱ࠵ࡳࡦࡥࡸࡶࡪ࠵ࡡࡶࡶ࡫࠳ࡱࡵࡧࡪࡰࠪ॰")
    l1l11llll11l1_mS_ = {l1l11l11l1_mS_ (u"ࠤࡵࡩࡲ࡫࡭ࡣࡧࡵࠦॱ"):True,l1l11l11l1_mS_ (u"ࠥࡩࡲࡧࡩ࡭ࠤॲ"):u,l1l11l11l1_mS_ (u"ࠦࡵࡧࡳࡴࡹࡲࡶࡩࠨॳ"):p}
    l1ll111l11l1_mS_ = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1ll111l11l1_mS_))
    urllib2.install_opener(opener)
    params=urllib.urlencode(l1l11llll11l1_mS_)
    status={l1l11l11l1_mS_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬॴ"):False}
    try:
        req = urllib2.Request(url, params,{ l1l11l11l1_mS_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪॵ"): l1l1ll11l11l1_mS_, l1l11l11l1_mS_ (u"ࠧࡳࡧࡩࡩࡷ࡫ࡲࠨॶ"): l1l11l11l1_mS_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡳࡵࡴ࡫ࡦࡷࡹࡸࡥࡢ࡯࠱ࡴࡱ࠵ࠧॷ") })
        response = urllib2.urlopen(req)
        l1l11ll1l11l1_mS_ = response.read()
        response.close()
        r=json.loads(l1l11ll1l11l1_mS_)
        a=r[l1l11l11l1_mS_ (u"ࠩࡧࡥࡹࡧࠧॸ")].decode(l1l11l11l1_mS_ (u"ࠪࡦࡦࡹࡥ࠷࠶ࠪॹ"))
        user = re.findall(l1l11l11l1_mS_ (u"ࠫࠧࡻࡳࡦࡴࠥ࠾࠭ࢁ࠮ࠫࡁ࡟ࡡࢂ࠯ࠧॺ"),a)
        user = json.loads(user[0]) if user else {}
        status[l1l11l11l1_mS_ (u"ࠬࡪࡩࡴࡲ࡯ࡥࡾࡥ࡮ࡢ࡯ࡨࠫॻ")]=user.get(l1l11l11l1_mS_ (u"࠭ࡤࡪࡵࡳࡰࡦࡿ࡟࡯ࡣࡰࡩࠬॼ"),l1l11l11l1_mS_ (u"ࠧ࡜ࡄࡠ࡞ࡦࡲ࡯ࡨࡷ࡭࡟࠴ࡈ࡝ࠨॽ"))
        status[l1l11l11l1_mS_ (u"ࠨࡣࡹࡥࡹࡧࡲࠨॾ")]=user.get(l1l11l11l1_mS_ (u"ࠩࡤࡺࡦࡺࡡࡳࠩॿ"),l1l11l11l1_mS_ (u"ࠪࠫঀ"))
        if l1l11l11l1_mS_ (u"ࠫࡸࡻࡣࡤࡧࡶࡷࠬঁ") in r[l1l11l11l1_mS_ (u"ࠧࡹࡴࡢࡶࡸࡷࠧং")]:
            status[l1l11l11l1_mS_ (u"࠭ࡣࡰࡱ࡮࡭ࡪ࠭ঃ")]=l1l11l11l1_mS_ (u"ࠧ࠼ࠩ঄").join([l1l11l11l1_mS_ (u"ࠨࠧࡶࡁࠪࡹࠧঅ")%(c.name,c.value) for c in l1ll111l11l1_mS_])
            l1ll111l11l1_mS_.save(l1llll11l11l1_mS_, ignore_discard = True)
            status[l1l11l11l1_mS_ (u"ࠩࡶࡸࡦࡺࡵࡴࠩআ")]=True
    except:
        pass
    return status
def search(text=l1l11l11l1_mS_ (u"ࠪ࡭ࡷࡧࠧই"),l1l111l1l11l1_mS_=10):
    try:
        l11l11lll11l1_mS_ = l1l11l11l1_mS_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯࡯ࡸࡷ࡮ࡩࡳࡵࡴࡨࡥࡲ࠴ࡰ࡭࠱ࡶࡩࡨࡻࡲࡦ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠨࡷࡄࡲࡩ࡮࡫ࡷࡁࠪࡪࠧঈ")%(urllib.quote(text),l1l111l1l11l1_mS_)
        dd = l11ll11ll11l1_mS_(l11l11lll11l1_mS_)
    except:
        dd = {}
    out={}
    l11ll111l11l1_mS_ = dd.get(l1l11l11l1_mS_ (u"ࠬࡺࡲࡢࡥ࡮ࡷࠬউ"),[])
    l11l1ll1l11l1_mS_ = dd.get(l1l11l11l1_mS_ (u"࠭ࡡ࡭ࡤࡸࡱࡸ࠭ঊ"),[])
    l1l1l11ll11l1_mS_ = dd.get(l1l11l11l1_mS_ (u"ࠧࡢࡴࡷ࡭ࡸࡺࡳࠨঋ"),[])
    if l11ll111l11l1_mS_:  out[l1l11l11l1_mS_ (u"ࠨࡶࡵࡥࡨࡱࡳࠨঌ")] = l1ll1ll11l1_mS_(l11ll111l11l1_mS_)
    if l11l1ll1l11l1_mS_:  out[l1l11l11l1_mS_ (u"ࠩࡤࡰࡧࡻ࡭ࡴࠩ঍")] = _11l11l1l11l1_mS_(l11l1ll1l11l1_mS_)
    if l1l1l11ll11l1_mS_: out[l1l11l11l1_mS_ (u"ࠪࡥࡷࡺࡩࡴࡶࡶࠫ঎")] = _1l1l1lll11l1_mS_(l1l1l11ll11l1_mS_)
    return out
def l11llllll11l1_mS_():
    u=l1l11l11l1_mS_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯࡯ࡸࡷ࡮ࡩࡳࡵࡴࡨࡥࡲ࠴ࡰ࡭࠱ࡶࡩࡨࡻࡲࡦ࠱ࡪࡩࡳࡸࡥࡴ࠱ࡳࡳࡵࡻ࡬ࡢࡴࠪএ")
    l11l1l11l11l1_mS_= l1l11l11l1_mS_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡰࡹࡸ࡯ࡣࡴࡶࡵࡩࡦࡳ࠮ࡱ࡮࠲ࡷࡪࡩࡵࡳࡧ࠲࡫ࡪࡴࡲࡦࡵ࠲ࠩࡸ࠵ࡡࡳࡶ࡬ࡷࡹࡹࠧঐ")
    dd = l11ll11ll11l1_mS_(u)
    for l1l1llll11l1_mS_ in dd:
        l1l1llll11l1_mS_[l1l11l11l1_mS_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ঑")]=l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠧ࡯ࡣࡰࡩࠬ঒"))
        l1l1llll11l1_mS_[l1l11l11l1_mS_ (u"ࠨ࡫ࡰ࡫ࠬও")]=l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠩ࡬ࡱࡦ࡭ࡥࠨঔ"))
        l1l1llll11l1_mS_[l1l11l11l1_mS_ (u"ࠪ࡬ࡷ࡫ࡦࠨক")]=l11l1l11l11l1_mS_%urllib.quote(l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠫࡳࡧ࡭ࡦࠩখ")))
    return dd
def l1lll1ll11l1_mS_(url):
    l1l1l1l1l11l1_mS_ = l11ll11ll11l1_mS_(url)
    l1lll1l1l11l1_mS_=l1l1l1l1l11l1_mS_.get(l1l11l11l1_mS_ (u"ࠬࡧࡲࡵ࡫ࡶࡸࡸࡖࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠩগ"),{}).get(l1l11l11l1_mS_ (u"࠭࡮ࡦࡺࡷࡣࡵࡧࡧࡦࡡࡸࡶࡱ࠭ঘ"),False)
    l1l1l1ll11l1_mS_=l1l1l1l1l11l1_mS_.get(l1l11l11l1_mS_ (u"ࠧࡢࡴࡷ࡭ࡸࡺࡳࡑࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫঙ"),{}).get(l1l11l11l1_mS_ (u"ࠨࡲࡵࡩࡻࡥࡰࡢࡩࡨࡣࡺࡸ࡬ࠨচ"),False)
    dd = l1l1l1l1l11l1_mS_.get(l1l11l11l1_mS_ (u"ࠩࡤࡶࡹ࡯ࡳࡵࡵࡓࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭ছ"),{}).get(l1l11l11l1_mS_ (u"ࠪࡨࡦࡺࡡࠨজ"),[])
    out = _1l1l1lll11l1_mS_(dd)
    return out,(l1l1l1ll11l1_mS_,l1lll1l1l11l1_mS_)
def _1l1l1lll11l1_mS_(dd):
    out=[]
    l11l1l11l11l1_mS_= l1l11l11l1_mS_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯࡯ࡸࡷ࡮ࡩࡳࡵࡴࡨࡥࡲ࠴ࡰ࡭࠱ࡶࡩࡨࡻࡲࡦ࠱ࡤࡶࡹ࡯ࡳࡵࡵ࠲ࡿࢂࡅࡴࡰࡲࡢࡸࡷࡧࡣ࡬ࡵࡀࡸࡷࡻࡥࠨঝ")
    for l1l1llll11l1_mS_ in dd:
        l111lllll11l1_mS_={}
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠬࡺࡩࡵ࡮ࡨࠫঞ")]=l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"࠭࡮ࡢ࡯ࡨࠫট"))
        if l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠧࡣ࡫ࡲࠫঠ"),{}):
            l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠨࡲ࡯ࡳࡹ࠭ড")]=l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠩࡥ࡭ࡴ࠭ঢ"),{}).get(l1l11l11l1_mS_ (u"ࠪࡦ࡮ࡵࠧণ"),l1l11l11l1_mS_ (u"ࠫࠬত"))
            try:
                fanart = l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠬࡨࡩࡰࠩথ"),{}).get(l1l11l11l1_mS_ (u"࠭ࡩ࡮ࡣࡪࡩࡸ࠭দ"),[])
                l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠧࡧࡣࡱࡥࡷࡺࠧধ")] = choice(fanart).get(l1l11l11l1_mS_ (u"ࠨࡷࡵࡰࠬন"),l1l11l11l1_mS_ (u"ࠩࠪ঩"))
            except:
                pass
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠪ࡭ࡲ࡭ࠧপ")]=l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠫ࡮ࡳࡡࡨࡧࡢࡰࡦࡸࡧࡦࠩফ"))
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠬ࡮ࡲࡦࡨࠪব")]=l11l1l11l11l1_mS_.format(l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"࠭ࡩࡥࠩভ")))
        out.append(l111lllll11l1_mS_)
    return out
def l1l1l1l11l1_mS_(url):
    l1l1l1l1l11l1_mS_ = l11ll11ll11l1_mS_(url)
    out={}
    l11l1111l11l1_mS_ = l1l1l1l1l11l1_mS_.get(l1l11l11l1_mS_ (u"ࠧࡵࡱࡳࡣࡹࡸࡡࡤ࡭ࡶࠫম"),[])
    if len(l11l1111l11l1_mS_)>1: out[l1l11l11l1_mS_ (u"ࠨࡶࡲࡴࡤࡺࡲࡢࡥ࡮ࡷࠬয")] = l1ll1ll11l1_mS_(l11l1111l11l1_mS_)
    if l1l1l1l1l11l1_mS_.get(l1l11l11l1_mS_ (u"ࠩࡤࡰࡧࡻ࡭ࡴࠩর")):
        dd=l1l1l1l1l11l1_mS_.get(l1l11l11l1_mS_ (u"ࠪࡥࡱࡨࡵ࡮ࡵࠪ঱"))
        out[l1l11l11l1_mS_ (u"ࠫࡦࡲࡢࡶ࡯ࡶࠫল")]= _11l11l1l11l1_mS_(dd.get(l1l11l11l1_mS_ (u"ࠬࡪࡡࡵࡣࠪ঳")))
        l1lll1l1l11l1_mS_=dd.get(l1l11l11l1_mS_ (u"࠭࡮ࡦࡺࡷࡣࡵࡧࡧࡦࡡࡸࡶࡱ࠭঴"),False)
        l1l1l1ll11l1_mS_=dd.get(l1l11l11l1_mS_ (u"ࠧࡱࡴࡨࡺࡤࡶࡡࡨࡧࡢࡹࡷࡲࠧ঵"),False)
        out[l1l11l11l1_mS_ (u"ࠨࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠬশ")]=(l1l1l1ll11l1_mS_,l1lll1l1l11l1_mS_)
    return out
def l11l11l11l1_mS_():
    u=l1l11l11l1_mS_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴࡭ࡶࡵ࡬ࡧࡸࡺࡲࡦࡣࡰ࠲ࡵࡲ࠯ࡴࡧࡦࡹࡷ࡫࠯ࡢ࡮ࡥࡹࡲࡹ࠯࡯ࡧࡺ࠱ࡷ࡫࡬ࡦࡣࡶࡩࡸ࠭ষ")
    dd = l11ll11ll11l1_mS_(u)
    out = _11l11l1l11l1_mS_(dd)
    return out
def l111lll11l1_mS_():
    u=l1l11l11l1_mS_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮࡮ࡷࡶ࡭ࡨࡹࡴࡳࡧࡤࡱ࠳ࡶ࡬࠰ࡵࡨࡧࡺࡸࡥ࠰ࡣ࡯ࡦࡺࡳࡳ࠰ࡲࡲࡴࡺࡲࡡࡳࠩস")
    dd = l11ll11ll11l1_mS_(u)
    return _11l11l1l11l1_mS_(dd)
def _11l11l1l11l1_mS_(dd):
    out=[]
    for l1l1llll11l1_mS_ in dd:
        l111lllll11l1_mS_={}
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠫࡦࡸࡴࡪࡵࡷࡣࠬহ")] = l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠬࡧࡲࡵ࡫ࡶࡸࠬ঺"),{}).get(l1l11l11l1_mS_ (u"࠭࡮ࡢ࡯ࡨࠫ঻"),l1l11l11l1_mS_ (u"ࠧࠨ়"))
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧঽ")]=l1l11l11l1_mS_ (u"ࠩ࡞ࡆࡢ࠭া")+ l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠪࡥࡷࡺࡩࡴࡶࡢࠫি")] +l1l11l11l1_mS_ (u"ࠫࡠ࠵ࡂ࡞ࠢ࠰ࠤࠬী") if l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠬࡧࡲࡵ࡫ࡶࡸࡤ࠭ু")] else l1l11l11l1_mS_ (u"࠭ࠧূ")
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ৃ")]+= l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠨࡰࡤࡱࡪ࠭ৄ"))
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠩ࡬ࡱ࡬࠭৅")]=l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠪ࡭ࡲࡧࡧࡦࠩ৆"))
        l11ll111l11l1_mS_= l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠫࡹࡸࡡࡤ࡭ࡶࠫে"),[])
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠬࡶ࡬ࡰࡶࠪৈ")] =l1l11l11l1_mS_ (u"࠭ࠧ৉")
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠧࡱ࡮ࡲࡸࠬ৊")]+=l1l11l11l1_mS_ (u"ࠨࡃࡵࡸࡾࡹࡴࡢ࠼ࠣࠩࡸࡢ࡮ࠨো")%l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠩࡤࡶࡹ࡯ࡳࡵࡡࠪৌ")] if l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠪࡥࡷࡺࡩࡴࡶࡢ্ࠫ")] else l1l11l11l1_mS_ (u"ࠫࠬৎ")
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠬࡶ࡬ࡰࡶࠪ৏")]+=l1l11l11l1_mS_ (u"࠭ࡁ࡭ࡤࡸࡱ࠿ࠦࠥࡴ࡞ࡱࠫ৐")%l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠧ࡯ࡣࡰࡩࠬ৑")) if l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠨࡰࡤࡱࡪ࠭৒")) else l1l11l11l1_mS_ (u"ࠩࠪ৓")
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠪࡴࡱࡵࡴࠨ৔")]+=l1l11l11l1_mS_ (u"ࠫࠪࡪ࠺ࠡࡶࡵࡥࡨࡱࡳ࡝ࡰࠪ৕")%(len(l11ll111l11l1_mS_))
        for l1l1111ll11l1_mS_ in l11ll111l11l1_mS_:
            l1l1111ll11l1_mS_[l1l11l11l1_mS_ (u"ࠬ࡯࡭ࡢࡩࡨࠫ৖")] = l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"࠭ࡩ࡮ࡣࡪࡩࠬৗ"))
        if l11ll111l11l1_mS_: l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠧࡩࡴࡨࡪࠬ৘")]=json.dumps(l11ll111l11l1_mS_)
        else: l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠨࡪࡵࡩ࡫࠭৙")]=l1l11l11l1_mS_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴࡭ࡶࡵ࡬ࡧࡸࡺࡲࡦࡣࡰ࠲ࡵࡲ࠯ࡴࡧࡦࡹࡷ࡫࠯ࡢ࡮ࡥࡹࡲࡹ࠯ࠦࡦࠪ৚")%l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠪ࡭ࡩ࠭৛"))
        out.append(l111lllll11l1_mS_)
    return out
def l1ll1ll11l1_mS_(l11ll111l11l1_mS_):
    import datetime
    if not isinstance(l11ll111l11l1_mS_,list) and l11ll111l11l1_mS_.startswith(l1l11l11l1_mS_ (u"ࠫ࡭ࡺࡴࡱࠩড়")):
        dd = l11ll11ll11l1_mS_(l11ll111l11l1_mS_)
        l11ll111l11l1_mS_ = dd.get(l1l11l11l1_mS_ (u"ࠬࡺࡲࡢࡥ࡮ࡷࠬঢ়"))
    out=[]
    l11l1l11l11l1_mS_= l1l11l11l1_mS_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡱࡺࡹࡩࡤࡵࡷࡶࡪࡧ࡭࠯ࡲ࡯࠳ࡸ࡫ࡣࡶࡴࡨ࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡦࡻࡤࡪࡱ࠲ࠩࡸ࠵ࠥࡴࠩ৞")
    for l1l1llll11l1_mS_ in l11ll111l11l1_mS_:
        l111lllll11l1_mS_={}
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠧࡢࡴࡷ࡭ࡸࡺ࡟ࠨয়")] = l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠨࡣࡵࡸ࡮ࡹࡴࡴࠩৠ"),[l1l11l11l1_mS_ (u"ࠩࠪৡ")])[0]
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠪࡥࡱࡨࡵ࡮ࡡࠪৢ")]=l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠫࡦࡲࡢࡶ࡯ࡢࡲࡦࡳࡥࠨৣ"),l1l11l11l1_mS_ (u"ࠬ࠭৤"))
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ৥")]=l1l11l11l1_mS_ (u"ࠧࠦ࠲࠵ࡨ࠳ࠦࠥࡴࠩ০")%(l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠨࡰࡸࡱࡧ࡫ࡲࠨ১"),1),l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠩࡱࡥࡲ࡫ࠧ২")),)
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠪ࡭ࡲ࡭ࠧ৩")] = l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠫ࡮ࡳࡡࡨࡧࠪ৪")) if l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠬ࡯࡭ࡢࡩࡨࠫ৫")) else l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"࠭ࡡ࡭ࡤࡸࡱࠬ৬"),{}).get(l1l11l11l1_mS_ (u"ࠧࡪ࡯ࡤ࡫ࡪ࠭৭"))
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠨࡲ࡯ࡳࡹ࠭৮")] =l1l11l11l1_mS_ (u"ࠩࠪ৯")
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠪ࡭ࡩ࠭ৰ")] =l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠫ࡮ࡪࠧৱ"),False)
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠬࡩ࡯ࡥࡧࠪ৲")]=str(datetime.timedelta(seconds=int(l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ৳")))/1000))
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ৴")]=l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪ৵"))
        if l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧࡢ࡭ࡩ࠭৶")):
            l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠪ࡬ࡷ࡫ࡦࠨ৷")]=l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩࡤ࡯ࡤࠨ৸"))
        else:
            l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠬ࡮ࡲࡦࡨࠪ৹")]=l11l1l11l11l1_mS_%( urllib.quote(l111lllll11l1_mS_[l1l11l11l1_mS_ (u"࠭ࡡࡳࡶ࡬ࡷࡹࡥࠧ৺")].encode(l1l11l11l1_mS_ (u"ࠧࡶࡶࡩ࠱࠽࠭৻"))) , urllib.quote(l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠨࡰࡤࡱࡪ࠭ৼ"),l1l11l11l1_mS_ (u"ࠩࠪ৽")).encode(l1l11l11l1_mS_ (u"ࠪࡹࡹ࡬࠭࠹ࠩ৾"))) )
        out.append(l111lllll11l1_mS_)
    return out
def l1lll11l11l1_mS_():
    import datetime
    l11ll1lll11l1_mS_()
    l11l1l11l11l1_mS_= l1l11l11l1_mS_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯࡯ࡸࡷ࡮ࡩࡳࡵࡴࡨࡥࡲ࠴ࡰ࡭࠱ࡶࡩࡨࡻࡲࡦ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡤࡹࡩ࡯࡯࠰ࠧࡶ࠳ࠪࡹࠧ৿")
    u=l1l11l11l1_mS_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡰࡹࡸ࡯ࡣࡴࡶࡵࡩࡦࡳ࠮ࡱ࡮࠲ࡷࡪࡩࡵࡳࡧ࠲ࡸࡷࡧࡣ࡬ࡵ࠲ࡸࡴࡶࠧ਀")
    dd = l11ll11ll11l1_mS_(u)
    out=[]
    for l1l1llll11l1_mS_ in dd:
        l111lllll11l1_mS_={}
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"࠭ࡡࡳࡶ࡬ࡷࡹࡥࠧਁ")] = l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠧࡢࡴࡷ࡭ࡸࡺࡳࠨਂ"),[l1l11l11l1_mS_ (u"ࠨࠩਃ")])[0]
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠩࡤࡰࡧࡻ࡭ࡠࠩ਄")]=l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠪࡥࡱࡨࡵ࡮ࡡࡱࡥࡲ࡫ࠧਅ"),l1l11l11l1_mS_ (u"ࠫࠬਆ"))
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠬࡺࡩࡵ࡮ࡨࠫਇ")]=l1l11l11l1_mS_ (u"࡛࠭ࡃ࡟ࠨࡷࡠ࠵ࡂ࡞ࠢ࠰ࠤࠪࡹࠧਈ")%(l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠧࡢ࡮ࡥࡹࡲࡥࠧਉ")],l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠨࡰࡤࡱࡪ࠭ਊ")))
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠩ࡬ࡱ࡬࠭਋")] = l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠪࡥࡱࡨࡵ࡮ࠩ਌"),{}).get(l1l11l11l1_mS_ (u"ࠫ࡮ࡳࡡࡨࡧࠪ਍"),l1l11l11l1_mS_ (u"ࠬ࠭਎")) if l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"࠭ࡡ࡭ࡤࡸࡱࠬਏ")) else l1l11l11l1_mS_ (u"ࠧࠨਐ")
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠨ࡫ࡧࠫ਑")] =l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠩ࡬ࡨࠬ਒"),False)
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠪࡴࡱࡵࡴࠨਓ")] =l1l11l11l1_mS_ (u"ࠫࠬਔ")
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠬࡶ࡬ࡰࡶࠪਕ")]+=l1l11l11l1_mS_ (u"࠭ࡁࡳࡶࡼࡷࡹࡧ࠺ࠡࠧࡶࡠࡳ࠭ਖ")%l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠧࡢࡴࡷ࡭ࡸࡺ࡟ࠨਗ")] if l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠨࡣࡵࡸ࡮ࡹࡴࡠࠩਘ")] else l1l11l11l1_mS_ (u"ࠩࠪਙ")
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠪࡴࡱࡵࡴࠨਚ")]+=l1l11l11l1_mS_ (u"ࠫࡆࡲࡢࡶ࡯࠽ࠤࠪࡹ࡜࡯ࠩਛ")%l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠬࡴࡡ࡮ࡧࠪਜ")) if l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"࠭࡮ࡢ࡯ࡨࠫਝ")) else l1l11l11l1_mS_ (u"ࠧࠨਞ")
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠨࡥࡲࡨࡪ࠭ਟ")]=str(datetime.timedelta(seconds=int(l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫਠ")))/1000))
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬਡ")]=l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭ਢ"))
        l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪࡥࡩࡥࠩਣ")]=l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"࠭ࡹࡰࡷࡷࡹࡧ࡫࡟ࡪࡦࠪਤ"),l1l11l11l1_mS_ (u"ࠧࠨਥ"))
        if l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠨࡻࡲࡹࡹࡻࡢࡦࡡ࡬ࡨࠬਦ"),l1l11l11l1_mS_ (u"ࠩࠪਧ")):
            l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠪ࡬ࡷ࡫ࡦࠨਨ")]=l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩࡤ࡯ࡤࠨ਩"),l1l11l11l1_mS_ (u"ࠬ࠭ਪ"))
        else:
            l111lllll11l1_mS_[l1l11l11l1_mS_ (u"࠭ࡨࡳࡧࡩࠫਫ")]=l11l1l11l11l1_mS_%( urllib.quote(l111lllll11l1_mS_[l1l11l11l1_mS_ (u"ࠧࡢࡴࡷ࡭ࡸࡺ࡟ࠨਬ")].encode(l1l11l11l1_mS_ (u"ࠨࡷࡷࡪ࠲࠾ࠧਭ"))) , urllib.quote(l1l1llll11l1_mS_.get(l1l11l11l1_mS_ (u"ࠩࡱࡥࡲ࡫ࠧਮ"),l1l11l11l1_mS_ (u"ࠪࠫਯ")).encode(l1l11l11l1_mS_ (u"ࠫࡺࡺࡦ࠮࠺ࠪਰ"))) )
        out.append(l111lllll11l1_mS_)
    return out
def l1l111lll11l1_mS_(l1l1l111l11l1_mS_):
    if l1l1l111l11l1_mS_.startswith(l1l11l11l1_mS_ (u"ࠬ࡮ࡴࡵࡲࠪ਱")):
        dd = l11ll11ll11l1_mS_(l1l1l111l11l1_mS_)
    else:
        dd=[{l1l11l11l1_mS_ (u"࠭ࡩࡥࠩਲ"):l1l1l111l11l1_mS_}]
    return dd
