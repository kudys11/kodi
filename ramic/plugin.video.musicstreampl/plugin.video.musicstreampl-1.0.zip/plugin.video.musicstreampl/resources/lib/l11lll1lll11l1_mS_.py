# -*- coding: utf-8 -*-
import sys
l111l11l1_mS_ = sys.version_info [0] == 2
l111ll11l1_mS_ = 2048
l1l1ll11l1_mS_ = 7
def l1l11l11l1_mS_ (keyedStringLiteral):
	global l1llll11l1_mS_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l11l1_mS_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll11l1_mS_ - (charIndex + stringNr) % l1l1ll11l1_mS_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll11l1_mS_ - (charIndex + stringNr) % l1l1ll11l1_mS_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import xbmcaddon
l1l1llll1l11l1_mS_       = xbmcaddon.Addon().getAddonInfo(l1l11l11l1_mS_ (u"࠭࡮ࡢ࡯ࡨࠫട"))
class l11ll11l1l11l1_mS_():
    def __init__(self,name=l1l1llll1l11l1_mS_):
        try:
            import StorageServer
        except:
            import storageserverdummy as StorageServer
        self.cache = StorageServer.StorageServer(name)
    def l11l11ll1l11l1_mS_(self,t):
        return t.encode(l1l11l11l1_mS_ (u"ࠧࡶࡶࡩ࠱࠽࠭ഠ")) if isinstance(t,unicode) else t
    def l1l11l111l11l1_mS_(self):
        return self.cache.get(l1l11l11l1_mS_ (u"ࠨࡪ࡬ࡷࡹࡵࡲࡺࠩഡ")).split(l1l11l11l1_mS_ (u"ࠩ࠾ࠫഢ"))
    def l11llll11l11l1_mS_(self,entry):
        l11l11l1ll11l1_mS_ = self.l1l11l111l11l1_mS_()
        if l11l11l1ll11l1_mS_ == [l1l11l11l1_mS_ (u"ࠪࠫണ")]:
            l11l11l1ll11l1_mS_ = []
        l11l11l1ll11l1_mS_.insert(0, self.l11l11ll1l11l1_mS_(entry))
        try:
            self.cache.set(l1l11l11l1_mS_ (u"ࠫ࡭࡯ࡳࡵࡱࡵࡽࠬത"),l1l11l11l1_mS_ (u"ࡺ࠭࠻ࠨഥ").join(l11l11l1ll11l1_mS_[:50]))
        except:
            pass
    def l1l1l11l1l11l1_mS_(self,entry):
        l11l11l1ll11l1_mS_ = self.l1l11l111l11l1_mS_()
        if l11l11l1ll11l1_mS_:
            try:
                self.cache.set(l1l11l11l1_mS_ (u"࠭ࡨࡪࡵࡷࡳࡷࡿࠧദ"),l1l11l11l1_mS_ (u"ࠧ࠼ࠩധ").join(l11l11l1ll11l1_mS_[:50]))
            except:
                pass
        else:
            self.l1l111111l11l1_mS_()
    def l1l111111l11l1_mS_(self):
        self.cache.delete(l1l11l11l1_mS_ (u"ࠨࡪ࡬ࡷࡹࡵࡲࡺࠩന"))
