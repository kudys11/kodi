# -*- coding: utf-8 -*-
import sys
l111l11l1_mS_ = sys.version_info [0] == 2
l111ll11l1_mS_ = 2048
l1l1ll11l1_mS_ = 7
def l1l11l11l1_mS_ (keyedStringLiteral):
	global l1llll11l1_mS_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l11l1_mS_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll11l1_mS_ - (charIndex + stringNr) % l1l1ll11l1_mS_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll11l1_mS_ - (charIndex + stringNr) % l1l1ll11l1_mS_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urlparse,sys,urllib
params = dict(urlparse.parse_qsl(sys.argv[2].replace(l1l11l11l1_mS_ (u"࠭࠿ࠨࠬ"),l1l11l11l1_mS_ (u"ࠧࠨ࠭"))))
mode = params.get(l1l11l11l1_mS_ (u"ࠨ࡯ࡲࡨࡪ࠭࠮"))
fname = params.get(l1l11l11l1_mS_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭࠯"))
ex_link = params.get(l1l11l11l1_mS_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫ࠰"))
l1ll1lll11l1_mS_ = params.get(l1l11l11l1_mS_ (u"ࠫࡵࡧࡧࡦࠩ࠱"))
import xbmcgui,xbmc
import time,os
l1l1lll11l1_mS_ = xbmcgui.Dialog()
import time,threading
try: from shutil import rmtree
except: rmtree = False
def l1ll11l1_mS_(l1111l11l1_mS_,l1lllll11l1_mS_=[l1l11l11l1_mS_ (u"ࠬ࠭࠲")]):
    debug=1
def l1l11l1_mS_(name=l1l11l11l1_mS_ (u"࠭ࠧ࠳")):
    debug=1
def l1lll11l1_mS_(top):
    debug=1
def l11llll11l1_mS_():
    l1111l11l1_mS_ = os.path.join(xbmc.translatePath(l1l11l11l1_mS_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨ࠻")),l1l11l11l1_mS_ (u"ࠨࡣࡧࡨࡴࡴࡳࠨ࠼"))
    xbmc.log(l1111l11l1_mS_)
    if l1ll11l1_mS_(l1111l11l1_mS_,[l1l11l11l1_mS_ (u"ࠩࡤࡰ࡮࡫࡮ࡸ࡫ࡽࡥࡷࡪࠧ࠽"),l1l11l11l1_mS_ (u"ࠪࡩࡽࡺࡥ࡯ࡦࡨࡶ࠳ࡧ࡬ࡪࡧࡱࠫ࠾")])>0:
        l1l11l1_mS_(l1l11l11l1_mS_ (u"ࠫࡼ࡯ࡺࡢࡴࡧࠫ࠿"))
        return
    l1l1l11l1_mS_ = os.path.join(xbmc.translatePath(l1l11l11l1_mS_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡷࡶࡩࡷࡪࡡࡵࡣࠪࡀ")),l1l11l11l1_mS_ (u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪࡁ"),l1l11l11l1_mS_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡧࡥࡰࡰ࠱ࡲࡴࡾ࠮࠶ࠩࡂ"),l1l11l11l1_mS_ (u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧࡃ"))
    if os.path.exists(l1l1l11l1_mS_):
        data = open(l1l1l11l1_mS_,l1l11l11l1_mS_ (u"ࠩࡵࠫࡄ")).read()
        data= re.sub(l1l11l11l1_mS_ (u"ࠪࡠࡠ࠴ࠪ࡝࡟ࠪࡅ"),l1l11l11l1_mS_ (u"ࠫࠬࡆ"),data)
        if len(re.compile(l1l11l11l1_mS_ (u"ࠬࡄ࠮ࠫࠪࡳࡳࡱࡹ࡫ࡢ࡞ࡶ࠮ࡹࡢࡳࠫࡸࠬࠫࡇ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1l11l1_mS_(l1l11l11l1_mS_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡦ࡫࡯࡯࠰ࡱࡳࡽ࠴࠵ࠨࡈ"))
            return
        if len(re.compile(l1l11l11l1_mS_ (u"ࠧ࠿࠰࠭ࠬࡩࡧࡲ࡮ࡱࡺࡥࡡࡹࠪࡵ࡞ࡶ࠮ࡻ࠯ࠧࡉ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1l11l1_mS_(l1l11l11l1_mS_ (u"ࠨࡵ࡮࡭ࡳ࠴ࡡࡦࡱࡱ࠲ࡳࡵࡸ࠯࠷ࠪࡊ"))
            return
    l1l1l11l1_mS_ = os.path.join(xbmc.translatePath(l1l11l11l1_mS_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡻࡳࡦࡴࡧࡥࡹࡧࠧࡋ")),l1l11l11l1_mS_ (u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧࡌ"),l1l11l11l1_mS_ (u"ࠫࡸࡱࡩ࡯࠰ࡻࡳࡳ࡬࡬ࡶࡧࡱࡧࡪ࠭ࡍ"),l1l11l11l1_mS_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫࡎ"))
    if os.path.exists(l1l1l11l1_mS_):
        data = open(l1l1l11l1_mS_,l1l11l11l1_mS_ (u"࠭ࡲࠨࡏ")).read()
        data= re.sub(l1l11l11l1_mS_ (u"ࠧ࡝࡝࠱࠮ࡡࡣࠧࡐ"),l1l11l11l1_mS_ (u"ࠨࠩࡑ"),data)
        if len(re.compile(l1l11l11l1_mS_ (u"ࠩࡁ࠲࠯࠮ࡰࡰ࡮ࡶ࡯ࡦࡢࡳࠫࡶ࡟ࡷ࠯ࡼࠩࠨࡒ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1l11l1_mS_(l1l11l11l1_mS_ (u"ࠪࡷࡰ࡯࡮࠯ࡺࡲࡲ࡫ࡲࡵࡦࡰࡦࡩࠬࡓ"))
            return
    l1111l11l1_mS_ = os.path.join(xbmc.translatePath(l1l11l11l1_mS_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡶࡵࡨࡶࡩࡧࡴࡢࠩࡔ")),l1l11l11l1_mS_ (u"ࠬࡶࡲࡰࡨ࡬ࡰࡪࡹࠧࡕ"))
    if os.path.exists(l1111l11l1_mS_):
        if l1ll11l1_mS_(l1111l11l1_mS_,[l1l11l11l1_mS_ (u"࠭࡫ࡪࡦࡶࠫࡖ")])>0:
            l1l11l1_mS_(l1l11l11l1_mS_ (u"ࠧࡸ࡫ࡽࡥࡷࡪࠧࡗ"))
            return
    l11lll11l1_mS_ = xbmc.translatePath(l1l11l11l1_mS_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩࡘ"))
    for f in os.listdir(l11lll11l1_mS_):
        if f.startswith(l1l11l11l1_mS_ (u"ࠩࡐࡑࡊ࡙࡙ࠧ")):
            l1l11l1_mS_()
            return
def l111l1l11l1_mS_():
    try:
        debug=1
    except: pass
import resources.lib.l1l11ll11l1_mS_
if mode is None:
    from resources.lib import l1llll1l11l1_mS_
    l1llll1l11l1_mS_.l1llll1l11l1_mS_().root()
elif mode.startswith(l1l11l11l1_mS_ (u"ࠫࡤ࡯࡮ࡧࡱࡢ࡛ࠫ"))  :
    from resources.lib import l1llll1l11l1_mS_
    l1llll1l11l1_mS_.l1llll1l11l1_mS_().info()
elif mode == l1l11l11l1_mS_ (u"ࠬࡶ࡯ࡱࡷ࡯ࡥࡷࡥࡧࡦࡰࡵࡩࡸ࠭࡜"):
    from resources.lib import l1llll1l11l1_mS_
    l1llll1l11l1_mS_.l1llll1l11l1_mS_().l1llllll11l1_mS_()
elif mode == l1l11l11l1_mS_ (u"࠭ࡧࡦࡰࡵࡩࡸࡥࡡࡳࡶ࡬ࡷࡹࡹࠧ࡝"):
    from resources.lib import l1llll1l11l1_mS_
    l1llll1l11l1_mS_.l1llll1l11l1_mS_().l1lll1ll11l1_mS_(ex_link)
elif mode == l1l11l11l1_mS_ (u"ࠧࡢࡴࡷ࡭ࡸࡺ࡟ࡤࡱࡱࡸࡪࡴࡴࠨ࡞"):
    from resources.lib import l1llll1l11l1_mS_
    l1llll1l11l1_mS_.l1llll1l11l1_mS_().l1l1l1l11l1_mS_(ex_link)
elif mode.startswith(l1l11l11l1_mS_ (u"ࠨࡡࡢࡴࡦ࡭ࡥࡠࡡ࠽ࠫ࡟")):
    from resources.lib import l1llll1l11l1_mS_
    l1llll1l11l1_mS_.l1llll1l11l1_mS_().l1lll1l11l1_mS_(mode,ex_link)
elif mode == l1l11l11l1_mS_ (u"ࠩࡳࡳࡵࡻ࡬ࡢࡴࡢࡥࡱࡨࡵ࡮ࡵࠪࡠ"):
    from resources.lib import l1llll1l11l1_mS_
    l1llll1l11l1_mS_.l1llll1l11l1_mS_().l111lll11l1_mS_()
elif mode == l1l11l11l1_mS_ (u"ࠪࡸࡴࡶ࡟࠶࠲ࠪࡡ"):
    from resources.lib import l1llll1l11l1_mS_
    l1llll1l11l1_mS_.l1llll1l11l1_mS_().l1lll11l11l1_mS_()
elif mode == l1l11l11l1_mS_ (u"ࠫࡳ࡫ࡷࡠࡴࡨࡰࡪࡧࡳࡦࡵࠪࡢ"):
    from resources.lib import l1llll1l11l1_mS_
    l1llll1l11l1_mS_.l1llll1l11l1_mS_().l11l11l11l1_mS_()
elif mode == l1l11l11l1_mS_ (u"ࠬࡶ࡯ࡱࡷ࡯ࡥࡷࡥࡡ࡭ࡤࡸࡱࡸࡥࡴࡳࡣࡦ࡯ࡸ࠭ࡣ"):
    from resources.lib import l1llll1l11l1_mS_
    if ex_link.startswith(l1l11l11l1_mS_ (u"࠭ࡨࡵࡶࡳࠫࡤ")):
        l11l1ll11l1_mS_=ex_link
    else:
        from json import loads
        l11l1ll11l1_mS_ = loads(ex_link)
    l1llll1l11l1_mS_.l1llll1l11l1_mS_().l1ll1ll11l1_mS_(l11l1ll11l1_mS_)
elif mode == l1l11l11l1_mS_ (u"ࠧࡶࡵࡨࡶࡤࡩ࡯࡯ࡶࡨࡲࡹ࠭ࡥ"):
    from resources.lib import l1llll1l11l1_mS_
    l1llll1l11l1_mS_.l1llll1l11l1_mS_().l11111l11l1_mS_(ex_link)
elif mode == l1l11l11l1_mS_ (u"ࠨࡃࡧࡨ࡙ࡵࡌࡪࡤࡵࡥࡷࡿࠧࡦ"):
    from resources.lib import l1llll1l11l1_mS_
    l1llll1l11l1_mS_.l1llll1l11l1_mS_().l1l111l11l1_mS_(ex_link)
elif mode == l1l11l11l1_mS_ (u"ࠩࡳࡰࡦࡿ࡙ࡕࠩࡧ"):
    from resources.lib import l1llll1l11l1_mS_
    l1llll1l11l1_mS_.l1llll1l11l1_mS_().l1111ll11l1_mS_(ex_link)
elif mode == l1l11l11l1_mS_ (u"ࠪࡴࡱࡧࡹ࡚ࡖࡄࡰࡱ࠭ࡨ"):
    from resources.lib import l1llll1l11l1_mS_
    l1llll1l11l1_mS_.l1llll1l11l1_mS_().l11ll1l11l1_mS_(ex_link)
elif mode.startswith(l1l11l11l1_mS_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫࡩ")):
    from resources.lib import l1llll1l11l1_mS_
    l1llll1l11l1_mS_.l1llll1l11l1_mS_().l1ll11l11l1_mS_(mode,ex_link)
