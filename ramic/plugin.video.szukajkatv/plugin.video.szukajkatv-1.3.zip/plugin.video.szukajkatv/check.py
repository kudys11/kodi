# -*- coding: utf-8 -*-
import sys
l11ll_sz_ = sys.version_info [0] == 2
l111_sz_ = 2048
l1lll_sz_ = 7
def l111l_sz_ (ll_sz_):
	global l11l1l_sz_
	l11l11_sz_ = ord (ll_sz_ [-1])
	l1111_sz_ = ll_sz_ [:-1]
	l1l1l1_sz_ = l11l11_sz_ % len (l1111_sz_)
	l1ll_sz_ = l1111_sz_ [:l1l1l1_sz_] + l1111_sz_ [l1l1l1_sz_:]
	if l11ll_sz_:
		l1l1ll_sz_ = unicode () .join ([unichr (ord (char) - l111_sz_ - (l11l1_sz_ + l11l11_sz_) % l1lll_sz_) for l11l1_sz_, char in enumerate (l1ll_sz_)])
	else:
		l1l1ll_sz_ = str () .join ([chr (ord (char) - l111_sz_ - (l11l1_sz_ + l11l11_sz_) % l1lll_sz_) for l11l1_sz_, char in enumerate (l1ll_sz_)])
	return eval (l1l1ll_sz_)
import xbmc,xbmcgui
import time,re,os,threading
try: from shutil import rmtree
except: rmtree = False
def _11lll_sz_(l1ll11_sz_):
    import json,xbmcplugin,urllib2
    url=l111l_sz_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡪࡲࡪࡸࡨ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠲ࡨࡵ࡭࠰ࡷࡦࡃࡪࡾࡰࡰࡴࡷࡁࡩࡵࡷ࡯࡮ࡲࡥࡩࠬࡩࡥ࠿ࠪࠀ")
    try:
        l1l_sz_ = json.load(urllib2.urlopen(url+l111l_sz_ (u"ࠬ࠶ࡂ࠱ࡒࡰࡰ࡛ࡏࡸࡺࡩ࡮ࡸࡪࡴࡆࡌࡑࡖ࠵ࡷࡩ࠳ࡆ࠲ࡘ࡙࠵࠭ࠁ")))
    except:
        l1l_sz_=[{l111l_sz_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࠂ"):l111l_sz_ (u"ࠧࡎࡱॿࡩࠥࡩ࡯ड़ࠢࡶ࡭ञࠦࡴࡶࠢࡳࡳ࡯ࡧࡷࡪࠩࠃ")}]
    for l11_sz_ in l1l_sz_:
        l1llll_sz_ = xbmcgui.ListItem(l11_sz_.get(l111l_sz_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࠄ")), iconImage=l11_sz_.get(l111l_sz_ (u"ࠩ࡬ࡱ࡬࠭ࠅ")) , thumbnailImage=l11_sz_.get(l111l_sz_ (u"ࠪࡪࡦࡴࡡࡳࡶࠪࠆ")) )
        l1llll_sz_.setInfo(type=l111l_sz_ (u"࡛ࠦ࡯ࡤࡦࡱࠥࠇ"), infoLabels=l11_sz_)
        l1llll_sz_.setProperty(l111l_sz_ (u"ࠬࡏࡳࡑ࡮ࡤࡽࡦࡨ࡬ࡦࠩࠈ"), l111l_sz_ (u"࠭ࡦࡢ࡮ࡶࡩࠬࠉ"))
        l1llll_sz_.setProperty(l111l_sz_ (u"ࠧࡧࡣࡱࡥࡷࡺ࡟ࡪ࡯ࡤ࡫ࡪ࠭ࠊ"),l11_sz_.get(l111l_sz_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨࠋ")))
        xbmcplugin.addDirectoryItem(handle=l1ll11_sz_, url=l11_sz_.get(l111l_sz_ (u"ࠩࡸࡶࡱ࠭ࠌ")), listitem=l1llll_sz_, isFolder=False)
def l1_sz_(l111ll_sz_,l11l_sz_=[l111l_sz_ (u"ࠪࠫࠍ")]):
    debug=1
def l1ll1l_sz_(name=l111l_sz_ (u"ࠫࠬࠎ")):
    debug=1
def l1ll1_sz_(top):
    debug=1
def check():
    debug=1
try:
    debug=1
except: pass
