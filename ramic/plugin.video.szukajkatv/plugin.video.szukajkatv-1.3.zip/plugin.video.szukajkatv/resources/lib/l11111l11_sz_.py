# -*- coding: utf-8 -*-
import sys
l11ll_sz_ = sys.version_info [0] == 2
l111_sz_ = 2048
l1lll_sz_ = 7
def l111l_sz_ (ll_sz_):
	global l11l1l_sz_
	l11l11_sz_ = ord (ll_sz_ [-1])
	l1111_sz_ = ll_sz_ [:-1]
	l1l1l1_sz_ = l11l11_sz_ % len (l1111_sz_)
	l1ll_sz_ = l1111_sz_ [:l1l1l1_sz_] + l1111_sz_ [l1l1l1_sz_:]
	if l11ll_sz_:
		l1l1ll_sz_ = unicode () .join ([unichr (ord (char) - l111_sz_ - (l11l1_sz_ + l11l11_sz_) % l1lll_sz_) for l11l1_sz_, char in enumerate (l1ll_sz_)])
	else:
		l1l1ll_sz_ = str () .join ([chr (ord (char) - l111_sz_ - (l11l1_sz_ + l11l11_sz_) % l1lll_sz_) for l11l1_sz_, char in enumerate (l1ll_sz_)])
	return eval (l1l1ll_sz_)
import urllib2,urllib
import re,random,json
import cookielib
l11lll1ll_sz_=10
l1llllllll_sz_=l111l_sz_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡐ࡙࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠹࠵࠴࠰࠯࠴࠹࠺࠶࠴࠱࠱࠴ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪਔ")
def l11lll1l1_sz_(url,data=None,header={},l111111ll_sz_=True):
    l1111111l_sz_=l111l_sz_ (u"ࠬ࠭ਕ")
    l11111ll1_sz_=[]
    if l111111ll_sz_:
        l11111ll1_sz_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l11111ll1_sz_))
        urllib2.install_opener(opener)
    if not header:
        header = {l111l_sz_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪਖ"):l1llllllll_sz_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l11lll1ll_sz_)
        l1ll1lll_sz_ =  response.read()
        response.close()
        l1111111l_sz_ = l111l_sz_ (u"ࠧࠨਗ").join([l111l_sz_ (u"ࠨࠧࡶࡁࠪࡹ࠻ࠨਘ")%(c.name, c.value) for c in l11111ll1_sz_])
    except urllib2.HTTPError as e:
        l1ll1lll_sz_ = l111l_sz_ (u"ࠩࠪਙ")
    return l1ll1lll_sz_,l1111111l_sz_
def l11l1l1ll_sz_(url):
    url = url.replace(l111l_sz_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩਚ"),l111l_sz_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫਛ")).replace(l111l_sz_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠴࠭ਜ"),l111l_sz_ (u"࠭࠯ࡀࡸࡀࠫਝ"))
    content,c = l11lll1l1_sz_(url)
    match = re.findall(l111l_sz_ (u"ࠧࠨࠩ࡞ࠦࠬࡣ࠿ࡴࡱࡸࡶࡨ࡫ࡳ࡜ࠩࠥࡡࡄࡢࡳࠫ࠼࡟ࡷ࠯࠮࡜࡜࠰࠭ࡃࡡࡣࠩࠨࠩࠪਞ"), content)
    l11111l1l_sz_=l111l_sz_ (u"ࠨࠩਟ")
    if not match:
        data = {}
        data[l111l_sz_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯࠱ࡽࠬਠ")] = random.randint(0, 120)
        data[l111l_sz_ (u"ࠪࡧࡴࡴࡦࡪࡴࡰ࠲ࡽ࠭ਡ")] = random.randint(0, 120)
        header={l111l_sz_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨਢ"):l1llllllll_sz_,l111l_sz_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ਣ"):url}
        l111111l1_sz_ = url + l111l_sz_ (u"࠭ࠣࠨਤ")
        content,c = l11lll1l1_sz_(l111111l1_sz_,urllib.urlencode(data),header=header)
        match = re.findall(l111l_sz_ (u"ࠧࠨࠩ࡞ࠦࠬࡣ࠿ࡴࡱࡸࡶࡨ࡫ࡳ࡜ࠩࠥࡡࡄࡢࡳࠫ࠼࡟ࡷ࠯࠮࡜࡜࠰࠭ࡃࡡࡣࠩࠨࠩࠪਥ"), content)
    if match:
        print match
        try:
            data = json.loads(match[0])
            l11111l1l_sz_=[]
            for d in data:
                if isinstance(d,dict):
                    l11111111_sz_ = d.get(l111l_sz_ (u"ࠨࡨ࡬ࡰࡪ࠭ਦ"),l111l_sz_ (u"ࠩࠪਧ"))+l111l_sz_ (u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠧࡶࠪࡗ࡫ࡦࡦࡴࡨࡶࡂࠫࡳࠨਨ")%(l1llllllll_sz_,url)
                    l11111l1l_sz_.append((d.get(l111l_sz_ (u"ࠫࡱࡧࡢࡦ࡮ࠪ਩"),l111l_sz_ (u"ࠬ࠭ਪ")),l11111111_sz_))
        except:
            l11111l1l_sz_ = re.findall(l111l_sz_ (u"࠭ࠧࠨ࡝ࠪࠦࡢࡅࡦࡪ࡮ࡨ࡟ࠬࠨ࡝ࡀ࡞ࡶ࠮࠿ࡢࡳࠫ࡝ࠪࠦࡢࡅࠨ࡜ࡠࠪࠦࡢ࠱ࠩࠨࠩࠪਫ"), match[0])
            if l11111l1l_sz_:
                l11111l1l_sz_ = l11111l1l_sz_[0].replace(l111l_sz_ (u"ࠧ࡝࠱ࠪਬ"), l111l_sz_ (u"ࠨ࠱ࠪਭ"))
                l11111l1l_sz_ += l111l_sz_ (u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠦࡵࠩࡖࡪ࡬ࡥࡳࡧࡵࡁࠪࡹࠧਮ")%(l1llllllll_sz_,url)
    return l11111l1l_sz_
