# -*- coding: utf-8 -*-
import sys
l11ll_sz_ = sys.version_info [0] == 2
l111_sz_ = 2048
l1lll_sz_ = 7
def l111l_sz_ (ll_sz_):
	global l11l1l_sz_
	l11l11_sz_ = ord (ll_sz_ [-1])
	l1111_sz_ = ll_sz_ [:-1]
	l1l1l1_sz_ = l11l11_sz_ % len (l1111_sz_)
	l1ll_sz_ = l1111_sz_ [:l1l1l1_sz_] + l1111_sz_ [l1l1l1_sz_:]
	if l11ll_sz_:
		l1l1ll_sz_ = unicode () .join ([unichr (ord (char) - l111_sz_ - (l11l1_sz_ + l11l11_sz_) % l1lll_sz_) for l11l1_sz_, char in enumerate (l1ll_sz_)])
	else:
		l1l1ll_sz_ = str () .join ([chr (ord (char) - l111_sz_ - (l11l1_sz_ + l11l11_sz_) % l1lll_sz_) for l11l1_sz_, char in enumerate (l1ll_sz_)])
	return eval (l1l1ll_sz_)
def abc(l11l1l111_sz_):
    def l11l11lll_sz_(a):
        l111lll11_sz_ = l111l_sz_ (u"ࠬ࠶࠱࠳࠵࠷࠹࠻࠽࠸࠺ࡣࡥࡧࡩ࡫ࡦࠨ৲")
        l11l111ll_sz_ = l111l_sz_ (u"࠭ࠧ৳")
        for i in range(4):
            l11l111ll_sz_ += l111lll11_sz_[(a >> (i * 8 + 4)) & 0x0F] + l111lll11_sz_[(a >> (i * 8)) & 0x0F]
        return l11l111ll_sz_
    def hex(text):
        l11l111ll_sz_ = l111l_sz_ (u"ࠧࠨ৴")
        for i in range(len(text)):
            l11l111ll_sz_ += l11l11lll_sz_(text[i])
        return l11l111ll_sz_
    def l11l1111l_sz_(a, b):
        return (a + b) & 0xFFFFFFFF
    def l11l11l11_sz_(a, b, c, d, e, f):
        b = l11l1111l_sz_(l11l1111l_sz_(b, a), l11l1111l_sz_(d, f));
        return l11l1111l_sz_((b << e) | (b >> (32 - e)), c)
    def l111lll1l_sz_(a, b, c, d, e, f, g):
        return l11l11l11_sz_((b & c) | ((~b) & d), a, b, e, f, g)
    def l11l111l1_sz_(a, b, c, d, e, f, g):
        return l11l11l11_sz_((b & d) | (c & (~d)), a, b, e, f, g)
    def l11l11111_sz_(a, b, c, d, e, f, g):
        return l11l11l11_sz_(b ^ c ^ d, a, b, e, f, g)
    def l11l1l1l1_sz_(a, b, c, d, e, f, g):
        return l11l11l11_sz_(c ^ (b | (~d)), a, b, e, f, g)
    def l11l1l11l_sz_(l111ll1l1_sz_, l111ll1ll_sz_):
        a = l111ll1l1_sz_[0]
        b = l111ll1l1_sz_[1]
        c = l111ll1l1_sz_[2]
        d = l111ll1l1_sz_[3]
        a = l111lll1l_sz_(a, b, c, d, l111ll1ll_sz_[0], 7, -680876936);
        d = l111lll1l_sz_(d, a, b, c, l111ll1ll_sz_[1], 12, -389564586);
        c = l111lll1l_sz_(c, d, a, b, l111ll1ll_sz_[2], 17, 606105819);
        b = l111lll1l_sz_(b, c, d, a, l111ll1ll_sz_[3], 22, -1044525330);
        a = l111lll1l_sz_(a, b, c, d, l111ll1ll_sz_[4], 7, -176418897);
        d = l111lll1l_sz_(d, a, b, c, l111ll1ll_sz_[5], 12, 1200080426);
        c = l111lll1l_sz_(c, d, a, b, l111ll1ll_sz_[6], 17, -1473231341);
        b = l111lll1l_sz_(b, c, d, a, l111ll1ll_sz_[7], 22, -45705983);
        a = l111lll1l_sz_(a, b, c, d, l111ll1ll_sz_[8], 7, 1770035416);
        d = l111lll1l_sz_(d, a, b, c, l111ll1ll_sz_[9], 12, -1958414417);
        c = l111lll1l_sz_(c, d, a, b, l111ll1ll_sz_[10], 17, -42063);
        b = l111lll1l_sz_(b, c, d, a, l111ll1ll_sz_[11], 22, -1990404162);
        a = l111lll1l_sz_(a, b, c, d, l111ll1ll_sz_[12], 7, 1804603682);
        d = l111lll1l_sz_(d, a, b, c, l111ll1ll_sz_[13], 12, -40341101);
        c = l111lll1l_sz_(c, d, a, b, l111ll1ll_sz_[14], 17, -1502002290);
        b = l111lll1l_sz_(b, c, d, a, l111ll1ll_sz_[15], 22, 1236535329);
        a = l11l111l1_sz_(a, b, c, d, l111ll1ll_sz_[1], 5, -165796510);
        d = l11l111l1_sz_(d, a, b, c, l111ll1ll_sz_[6], 9, -1069501632);
        c = l11l111l1_sz_(c, d, a, b, l111ll1ll_sz_[11], 14, 643717713);
        b = l11l111l1_sz_(b, c, d, a, l111ll1ll_sz_[0], 20, -373897302);
        a = l11l111l1_sz_(a, b, c, d, l111ll1ll_sz_[5], 5, -701558691);
        d = l11l111l1_sz_(d, a, b, c, l111ll1ll_sz_[10], 9, 38016083);
        c = l11l111l1_sz_(c, d, a, b, l111ll1ll_sz_[15], 14, -660478335);
        b = l11l111l1_sz_(b, c, d, a, l111ll1ll_sz_[4], 20, -405537848);
        a = l11l111l1_sz_(a, b, c, d, l111ll1ll_sz_[9], 5, 568446438);
        d = l11l111l1_sz_(d, a, b, c, l111ll1ll_sz_[14], 9, -1019803690);
        c = l11l111l1_sz_(c, d, a, b, l111ll1ll_sz_[3], 14, -187363961);
        b = l11l111l1_sz_(b, c, d, a, l111ll1ll_sz_[8], 20, 1163531501);
        a = l11l111l1_sz_(a, b, c, d, l111ll1ll_sz_[13], 5, -1444681467);
        d = l11l111l1_sz_(d, a, b, c, l111ll1ll_sz_[2], 9, -51403784);
        c = l11l111l1_sz_(c, d, a, b, l111ll1ll_sz_[7], 14, 1735328473);
        b = l11l111l1_sz_(b, c, d, a, l111ll1ll_sz_[12], 20, -1926607734);
        a = l11l11111_sz_(a, b, c, d, l111ll1ll_sz_[5], 4, -378558);
        d = l11l11111_sz_(d, a, b, c, l111ll1ll_sz_[8], 11, -2022574463);
        c = l11l11111_sz_(c, d, a, b, l111ll1ll_sz_[11], 16, 1839030562);
        b = l11l11111_sz_(b, c, d, a, l111ll1ll_sz_[14], 23, -35309556);
        a = l11l11111_sz_(a, b, c, d, l111ll1ll_sz_[1], 4, -1530992060);
        d = l11l11111_sz_(d, a, b, c, l111ll1ll_sz_[4], 11, 1272893353);
        c = l11l11111_sz_(c, d, a, b, l111ll1ll_sz_[7], 16, -155497632);
        b = l11l11111_sz_(b, c, d, a, l111ll1ll_sz_[10], 23, -1094730640);
        a = l11l11111_sz_(a, b, c, d, l111ll1ll_sz_[13], 4, 681279174);
        d = l11l11111_sz_(d, a, b, c, l111ll1ll_sz_[0], 11, -358537222);
        c = l11l11111_sz_(c, d, a, b, l111ll1ll_sz_[3], 16, -722521979);
        b = l11l11111_sz_(b, c, d, a, l111ll1ll_sz_[6], 23, 76029189);
        a = l11l11111_sz_(a, b, c, d, l111ll1ll_sz_[9], 4, -640364487);
        d = l11l11111_sz_(d, a, b, c, l111ll1ll_sz_[12], 11, -421815835);
        c = l11l11111_sz_(c, d, a, b, l111ll1ll_sz_[15], 16, 530742520);
        b = l11l11111_sz_(b, c, d, a, l111ll1ll_sz_[2], 23, -995338651);
        a = l11l1l1l1_sz_(a, b, c, d, l111ll1ll_sz_[0], 6, -198630844);
        d = l11l1l1l1_sz_(d, a, b, c, l111ll1ll_sz_[7], 10, 1126891415);
        c = l11l1l1l1_sz_(c, d, a, b, l111ll1ll_sz_[14], 15, -1416354905);
        b = l11l1l1l1_sz_(b, c, d, a, l111ll1ll_sz_[5], 21, -57434055);
        a = l11l1l1l1_sz_(a, b, c, d, l111ll1ll_sz_[12], 6, 1700485571);
        d = l11l1l1l1_sz_(d, a, b, c, l111ll1ll_sz_[3], 10, -1894986606);
        c = l11l1l1l1_sz_(c, d, a, b, l111ll1ll_sz_[10], 15, -1051523);
        b = l11l1l1l1_sz_(b, c, d, a, l111ll1ll_sz_[1], 21, -2054922799);
        a = l11l1l1l1_sz_(a, b, c, d, l111ll1ll_sz_[8], 6, 1873313359);
        d = l11l1l1l1_sz_(d, a, b, c, l111ll1ll_sz_[15], 10, -30611744);
        c = l11l1l1l1_sz_(c, d, a, b, l111ll1ll_sz_[6], 15, -1560198380);
        b = l11l1l1l1_sz_(b, c, d, a, l111ll1ll_sz_[13], 21, 1309151649);
        a = l11l1l1l1_sz_(a, b, c, d, l111ll1ll_sz_[4], 6, -145523070);
        d = l11l1l1l1_sz_(d, a, b, c, l111ll1ll_sz_[11], 10, -1120210379);
        c = l11l1l1l1_sz_(c, d, a, b, l111ll1ll_sz_[2], 15, 718787259);
        b = l11l1l1l1_sz_(b, c, d, a, l111ll1ll_sz_[9], 21, -343485551);
        l111ll1l1_sz_[0] = l11l1111l_sz_(a, l111ll1l1_sz_[0]);
        l111ll1l1_sz_[1] = l11l1111l_sz_(b, l111ll1l1_sz_[1]);
        l111ll1l1_sz_[2] = l11l1111l_sz_(c, l111ll1l1_sz_[2]);
        l111ll1l1_sz_[3] = l11l1111l_sz_(d, l111ll1l1_sz_[3])
    def l111llll1_sz_(text):
        l11l111ll_sz_ = []
        for i in range(0, 64, 4):
            l11l111ll_sz_.append(ord(text[i]) + (ord(text[i+1]) << 8) + (ord(text[i+2]) << 16) + (ord(text[i+3]) << 24))
        return l11l111ll_sz_
    def l11l11ll1_sz_(text):
        l111ll11l_sz_ = l111l_sz_ (u"ࠨࠩ৵");
        l111lllll_sz_ = len(text)
        l11l111ll_sz_ = [1732584193, -271733879, -1732584194, 271733878]
        i = 64
        while i <= len(text):
            l11l1l11l_sz_(l11l111ll_sz_, l111llll1_sz_(text[l111l_sz_ (u"ࠩࡶࡹࡧࡹࡴࡳ࡫ࡱ࡫ࠬ৶")](i - 64, i)))
            i += 64
        text = text[i - 64:]
        l1l11l1_sz_ = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        i = 0
        while i < len(text):
            l1l11l1_sz_[i >> 2] |= ord(text[i]) << ((i % 4) << 3)
            i += 1
        l1l11l1_sz_[i >> 2] |= 0x80 << ((i % 4) << 3)
        if i > 55:
            l11l1l11l_sz_(l11l111ll_sz_, l1l11l1_sz_);
            for i in range(16):
                l1l11l1_sz_[i] = 0
        l1l11l1_sz_[14] = l111lllll_sz_ * 8;
        l11l1l11l_sz_(l11l111ll_sz_, l1l11l1_sz_);
        return l11l111ll_sz_
    def l11l11l1l_sz_(text):
        return hex(l11l11ll1_sz_(text))
    return l11l11l1l_sz_(l11l1l111_sz_)
