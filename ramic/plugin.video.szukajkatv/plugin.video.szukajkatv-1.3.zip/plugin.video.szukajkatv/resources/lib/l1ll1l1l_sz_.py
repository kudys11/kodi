# -*- coding: utf-8 -*-
import sys
l11ll_sz_ = sys.version_info [0] == 2
l111_sz_ = 2048
l1lll_sz_ = 7
def l111l_sz_ (ll_sz_):
	global l11l1l_sz_
	l11l11_sz_ = ord (ll_sz_ [-1])
	l1111_sz_ = ll_sz_ [:-1]
	l1l1l1_sz_ = l11l11_sz_ % len (l1111_sz_)
	l1ll_sz_ = l1111_sz_ [:l1l1l1_sz_] + l1111_sz_ [l1l1l1_sz_:]
	if l11ll_sz_:
		l1l1ll_sz_ = unicode () .join ([unichr (ord (char) - l111_sz_ - (l11l1_sz_ + l11l11_sz_) % l1lll_sz_) for l11l1_sz_, char in enumerate (l1ll_sz_)])
	else:
		l1l1ll_sz_ = str () .join ([chr (ord (char) - l111_sz_ - (l11l1_sz_ + l11l11_sz_) % l1lll_sz_) for l11l1_sz_, char in enumerate (l1ll_sz_)])
	return eval (l1l1ll_sz_)
import urllib2,urllib
import re,os
import json
import cookielib
from urlparse import urlparse,urljoin
l11ll1ll1_sz_=l111l_sz_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡿࡻ࡫ࡢ࡬࡮ࡥ࠳ࡺࡶ࠰ࠩਯ")
l11lll1ll_sz_ = 10
l1llllllll_sz_=l111l_sz_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡐ࡙࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠸࠽࠴࠰࠯࠴࠸࠺࠹࠴࠹࠸ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩਰ")
l1l1llll_sz_=l111l_sz_ (u"ࡷ࠭ࡄ࠻࡞ࡦࡳࡴࡱࡩࡦ࠰ࡶࡾࡺࡱࡡ࡫࡭ࡤࠫ਱")
def l11lll1l1_sz_(url,data=None,header={},l1llll1l1l_sz_=True,l1lllll11l_sz_=True):
    if l1l1llll_sz_ and l1llll1l1l_sz_:
        l11111ll1_sz_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l11111ll1_sz_),urllib2.HTTPRedirectHandler())
        urllib2.install_opener(opener)
    if not header:
        header = {l111l_sz_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪਲ"):l1llllllll_sz_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l11lll1ll_sz_)
        l1ll1lll_sz_ =  response.read()
        response.close()
        if l1l1llll_sz_ and l1lllll11l_sz_ and l1llll1l1l_sz_:
            l1llll1lll_sz_=os.path.dirname(l1l1llll_sz_)
            if not os.path.exists(l1llll1lll_sz_): os.makedirs(l1llll1lll_sz_)
            if l11111ll1_sz_: l11111ll1_sz_.save(l1l1llll_sz_, True, True)
    except urllib2.HTTPError as e:
        l1ll1lll_sz_ = l111l_sz_ (u"ࠧࠨਲ਼")
    return l1ll1lll_sz_
def l1l1l1ll_sz_(l1l1ll11_sz_):
    l1ll1ll_sz_ = {}
    for k, v in l1l1ll11_sz_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l111l_sz_ (u"ࠨࡷࡷࡪ࠽࠭਴"))
        elif isinstance(v, str):
            v.decode(l111l_sz_ (u"ࠩࡸࡸ࡫࠾ࠧਵ"))
        l1ll1ll_sz_[k] = v
    return l1ll1ll_sz_
def l1111l1_sz_(url=l111l_sz_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡿࡻ࡫ࡢ࡬࡮ࡥ࠳ࡺࡶ࠰ࡵࡽࡹࡰࡧࡪࠨਸ਼"),data=l111l_sz_ (u"ࠫࡶࡃࠦࡴ࠿࠴ࠪ࡭ࡃ࠰ࠧࡸࡀ࠴ࠫࡧ࠽ࠨ਷")):
    if isinstance(data,dict):
        data = urllib.urlencode(l1l1l1ll_sz_(data)).replace(l111l_sz_ (u"ࠬ࠱ࠧਸ"),l111l_sz_ (u"࠭ࠥ࠳࠲ࠪਹ"))
    content = l11lll1l1_sz_(url,data=data,l1llll1l1l_sz_=True)
    items = re.compile(l111l_sz_ (u"ࠧ࠽ࡣࠣࡧࡱࡧࡳࡴ࠿ࠥࡰ࡮ࡴ࡫ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ਺"),re.DOTALL).findall(content)
    out=[]
    for l1llll11l1_sz_ in items:
        href = re.compile(l111l_sz_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵࡣࡵ࡫ࡪࡺ࠽ࠣࡡࡥࡰࡦࡴ࡫ࠣࡀࠪ਻"),re.DOTALL).search(l1llll11l1_sz_)
        href = href.group(1).strip() if href else l111l_sz_ (u"਼ࠩࠪ")
        l1lllll1l1_sz_ = re.compile(l111l_sz_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ਽"),re.DOTALL).search(l1llll11l1_sz_)
        l1lllll1l1_sz_ = l1lllll1l1_sz_.group(1).strip() if l1lllll1l1_sz_ else l111l_sz_ (u"ࠫࠬਾ")
        title = re.compile(l111l_sz_ (u"ࠬࡂࠨࡀ࠼ࡶࡴࡦࡴࡼࡥ࡫ࡹ࠭ࠥࡩ࡬ࡢࡵࡶࡁࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴࠮࠿࠻ࡵࡳࡥࡳࢂࡤࡪࡸࠬࡂࠬਿ"),re.DOTALL).search(l1llll11l1_sz_)
        title = title.group(1) if title else l111l_sz_ (u"࠭ࠧੀ")
        l1lllll111_sz_ = re.compile(l111l_sz_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡨ࡯ࡵࡶࡲࡱࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫੁ"),re.DOTALL).findall(l1llll11l1_sz_)
        l1lllll111_sz_ = l1lllll111_sz_[0] if l1lllll111_sz_ else l111l_sz_ (u"ࠨࠩੂ")
        version = re.compile(l111l_sz_ (u"ࠩ࠿ࡷࡵࡧ࡮ࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡸࡨࡶࡸ࡯࡯࡯ࠤࡁࡀ࡮ࠦࡣ࡭ࡣࡶࡷࡂ࠴ࠪ࠿࠾࠲࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ੃")).findall(l1lllll111_sz_)
        version = version[0].strip() if version else l111l_sz_ (u"ࠪࠫ੄")
        l1llll11ll_sz_ = re.compile(l111l_sz_ (u"ࠫࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥࡨࡺࡸࡡࡵ࡫ࡲࡲࠧࡄ࠼ࡪࠢࡦࡰࡦࡹࡳ࠾࠰࠭ࡂࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ੅")).findall(l1lllll111_sz_)
        l1llll11ll_sz_ = l1llll11ll_sz_[0].strip() if l1llll11ll_sz_ else l111l_sz_ (u"ࠬ࠭੆")
        size = re.compile(l111l_sz_ (u"࠭࠼ࡴࡲࡤࡲࠥࡩ࡬ࡢࡵࡶࡁࠧࡹࡩࡻࡧࠥࡂࡁ࡯ࠠࡤ࡮ࡤࡷࡸࡃࠢࡧࡣࠣࡪࡦ࠳ࡤࡢࡶࡤࡦࡦࡹࡥࠣࠢࡤࡶ࡮ࡧ࠭ࡩ࡫ࡧࡨࡪࡴ࠽ࠣࡶࡵࡹࡪࠨ࠾࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪੇ")).findall(l1lllll111_sz_)
        size = size[0].strip() if size else l111l_sz_ (u"ࠧࠨੈ")
        host = re.search(l111l_sz_ (u"ࠨ࠾ࡶࡴࡦࡴࠠࡤ࡮ࡤࡷࡸࡃࠢࡩࡱࡶࡸࠧࡄ࠮ࠫࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠵࠾ࠨ੉"),l1lllll111_sz_)
        host = l111l_sz_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࠦࡵ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ੊")%host.group(1) if host else l111l_sz_ (u"ࠪࠫੋ")
        l1llllll1l_sz_ = l111l_sz_ (u"ࠫࡍࡵࡳࡵ࠼ࠨࡷࡡࡴࡗࡦࡴࡶ࡮ࡦࡀࠥࡴ࡞ࡱࡇࡿࡧࡳ࠻ࠧࡶࡠࡳࡘ࡯ࡻ࡯࡬ࡥࡷࡀࠥࡴ࡞ࡱࠫੌ")%(host,version,l1llll11ll_sz_,size)
        if href and title:
            l11_sz_ = {
                l111l_sz_ (u"ࠬࡻࡲ࡭੍ࠩ")   : href,
                l111l_sz_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ੎")  : l1llll1ll1_sz_(title),
                l111l_sz_ (u"ࠧࡱ࡮ࡲࡸࠬ੏")   : l1llllll1l_sz_,
                l111l_sz_ (u"ࠨ࡫ࡰ࡫ࠬ੐")    : l1lllll1l1_sz_,
                l111l_sz_ (u"ࠩࡦࡳࡩ࡫ࠧੑ")   : host+l111l_sz_ (u"ࠪ࠰ࠬ੒")+version}
            out.append(l11_sz_)
    return out
def l1llll1l11_sz_(url):
    l1lllllll1_sz_=l111l_sz_ (u"ࠫࠬ੓")
    if l1l1llll_sz_:
        import l111ll111_sz_
        l11111ll1_sz_ = cookielib.LWPCookieJar()
        l11111ll1_sz_.load(l1l1llll_sz_,True,True)
        l1111111l_sz_ = l111l_sz_ (u"ࠬࡁࠧ੔").join([l111l_sz_ (u"࠭ࠥࡴ࠿ࠨࡷࠬ੕")%(c.name,c.value) for c in l11111ll1_sz_])
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l11111ll1_sz_))
        urllib2.install_opener(opener)
        header = {l111l_sz_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ੖"):l1llllllll_sz_,l111l_sz_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ੗"):l111l_sz_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ੘"),l111l_sz_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪਖ਼"):l1111111l_sz_,l111l_sz_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬਗ਼"):url}
        req = urllib2.Request(l111l_sz_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡺࡶ࡭ࡤ࡮ࡰࡧ࠮ࡵࡸ࠲࡮ࡸࡼࡥࡳ࡫ࡩࡽ࠳ࡶࡨࡱࡁࡲࡴࡂࡺࡡࡨࠩਜ਼"),None,headers=header)
        try:
            response = urllib2.urlopen(req,timeout=l11lll1ll_sz_)
            data =  json.loads(response.read())
            response.close()
            d = {}
            for i in range(len(data[l111l_sz_ (u"࠭࡫ࡦࡻࠪੜ")])):
                d[data[l111l_sz_ (u"ࠧ࡬ࡧࡼࠫ੝")][i]] = data[l111l_sz_ (u"ࠨࡪࡤࡷ࡭࠭ਫ਼")][i]
            l1l11l1_sz_ = l111l_sz_ (u"ࠩࠪ੟")
            for k in sorted(d.keys()):
                l1l11l1_sz_ += d[k]
            l1lllllll1_sz_ = l111l_sz_ (u"ࠪࡸࡲࡼࡨ࠾ࠧࡶ࠿ࠪࡹࠧ੠") % (l111ll111_sz_.abc(l1l11l1_sz_), l1111111l_sz_)
        except:
            pass
    return l1lllllll1_sz_
def l1ll11l_sz_(url):
    l1ll1lll_sz_=l111l_sz_ (u"ࠫࠬ੡")
    l1llll111l_sz_ = url.split(l111l_sz_ (u"ࠬ࠳ࠧ੢"))[0].split(l111l_sz_ (u"࠭࠯ࠨ੣"))[-1]
    l1111111l_sz_ = l1llll1l11_sz_(url)
    if l1111111l_sz_:
        header={l111l_sz_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ੤"):l1llllllll_sz_,
            l111l_sz_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ੥"):url,
            l111l_sz_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ੦"):l1111111l_sz_,
            }
        content = l11lll1l1_sz_(l111l_sz_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡿࡻ࡫ࡢ࡬࡮ࡥ࠳ࡺࡶ࠰࡮࡬ࡲࡰ࠵ࠧ੧")+l1llll111l_sz_,header=header,l1llll1l1l_sz_=False,l1lllll11l_sz_=False)
        l1lllll1ll_sz_ = re.compile(l111l_sz_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠭࠴ࠪࡀࠫ࠿࠳࡮࡬ࡲࡢ࡯ࡨࡂࠬ੨"),re.DOTALL).findall(content)
        if l1lllll1ll_sz_:
            l1ll1lll_sz_ = re.compile(l111l_sz_ (u"ࠬࡹࡲࡤ࠿࡞ࡠࠬࠨ࡝ࠩ࠰࠭ࡃ࠮ࡡ࡜ࠨࠤࡠࠫ੩")).findall(l1lllll1ll_sz_[0])
            l1ll1lll_sz_ = l1ll1lll_sz_[0] if l1ll1lll_sz_ else l111l_sz_ (u"࠭ࠧ੪")
            if l111l_sz_ (u"ࠧࡤࡦࡤ࠲ࡵࡲࠧ੫") in l1ll1lll_sz_: l1ll1lll_sz_ = l1ll1lll_sz_.replace(l111l_sz_ (u"ࠨ࡝ࡺ࡭ࡩࡺࡨ࡞ࡺ࡞࡬ࡪ࡯ࡧࡩࡶࡠࠫ੬"),l111l_sz_ (u"ࠩ࠺࠴࠵ࡾ࠴࠱࠲ࠪ੭"))
    return l1ll1lll_sz_
def l1lll1l1_sz_(url):
    content = l11lll1l1_sz_(url,l1llll1l1l_sz_=True,l1lllll11l_sz_=False)
    element= re.compile(l111l_sz_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡧ࡯ࡩࡲ࡫࡮ࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ੮"),re.DOTALL).findall(content)
    out=[]
    for e in element:
        href = re.search(l111l_sz_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ੯"),e)
        title = re.compile(l111l_sz_ (u"ࠬࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ੰ"),re.DOTALL).findall(e)
        title = l111l_sz_ (u"࠭ࠧੱ").join([l111l_sz_ (u"ࠧࠡࠩੲ")+x.strip() for x in title if x.strip()]).strip()
        l1lllll1l1_sz_ = re.compile(l111l_sz_ (u"ࠨ࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫੳ")).findall(e)
        host = l111l_sz_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࠦࡵ࡞࠳ࡈࡕࡌࡐࡔࡠࠫੴ")%l1lllll1l1_sz_[0].split(l111l_sz_ (u"ࠪ࠳ࠬੵ"))[-1].split(l111l_sz_ (u"ࠫ࠳࠭੶"))[0] if l1lllll1l1_sz_ else l111l_sz_ (u"ࠬ࠭੷")
        if href and title:
            l11_sz_ = {
            l111l_sz_ (u"࠭ࡵࡳ࡮ࠪ੸")   : href.group(1),
            l111l_sz_ (u"ࠧࡪ࡯ࡪࠫ੹") : l111l_sz_ (u"ࠨ࡫ࡰ࡫ࠬ੺"),
            l111l_sz_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ੻") : l111l_sz_ (u"ࠪ࡟ࡎࡣࠧ੼")+l1llll1ll1_sz_(title)+l111l_sz_ (u"ࠫࡠ࠵ࡉ࡞ࠩ੽"),
            l111l_sz_ (u"ࠬࡩ࡯ࡥࡧࠪ੾")  : host}
            out.append(l11_sz_)
    return out
def l111lll_sz_(l1llllll11_sz_=l111l_sz_ (u"࠭ࡨࡰࡵࡷࠫ੿")):
    content = l11lll1l1_sz_(l111l_sz_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡼࡸ࡯ࡦࡰ࡫ࡢ࠰ࡷࡺ࠴ࡅࡱ࠾ࠩ઀"))
    value=[]
    label=[]
    select=re.compile(l111l_sz_ (u"ࠨ࠾ࡶࡩࡱ࡫ࡣࡵࠢࡱࡥࡲ࡫࠽ࠣࠧࡶࠦࠥ࡯ࡤ࠾ࠤࠨࡷࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡦ࡮ࡨࡧࡹࡄࠧઁ")%(l1llllll11_sz_,l1llllll11_sz_),re.DOTALL).findall(content)
    if select:
        out = re.compile(l111l_sz_ (u"ࠩ࠿ࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡳࡵࡺࡩࡰࡰࡁࠫં")).findall(select[0])
        value = [x[0] for x in out]
        label= [l1llll1ll1_sz_(x[1]) for x in out]
    return (value,label)
def l1llll1ll1_sz_(l111ll11l_sz_):
    l111ll11l_sz_ = l111ll11l_sz_.replace(l111l_sz_ (u"ࠪࠫࠬࠬࡱࡶࡱࡷ࠿ࠬ࠭ࠧઃ"),l111l_sz_ (u"ࠫࠧ࠭઄")).replace(l111l_sz_ (u"ࠬ࠭ࠧࠧࡣࡰࡴࡀࡷࡵࡰࡶ࠾ࠫࠬ࠭અ"),l111l_sz_ (u"࠭ࠢࠨઆ"))
    l111ll11l_sz_ = l111ll11l_sz_.replace(l111l_sz_ (u"ࠧࠨࠩࠩࡳࡦࡩࡵࡵࡧ࠾ࠫࠬ࠭ઇ"),l111l_sz_ (u"ࠨࣵࠪઈ")).replace(l111l_sz_ (u"ࠩࠪࠫࠫࡕࡡࡤࡷࡷࡩࡀ࠭ࠧࠨઉ"),l111l_sz_ (u"ࠪࣗࠬઊ"))
    l111ll11l_sz_ = l111ll11l_sz_.replace(l111l_sz_ (u"ࠫࠬ࠭ࠦࡢ࡯ࡳ࠿ࡴࡧࡣࡶࡶࡨ࠿ࠬ࠭ࠧઋ"),l111l_sz_ (u"ࣹࠬࠧઌ")).replace(l111l_sz_ (u"࠭ࠦࡢ࡯ࡳ࠿ࡔࡧࡣࡶࡶࡨ࠿ࠬઍ"),l111l_sz_ (u"ࠧࣔࠩ઎"))
    l111ll11l_sz_ = l111ll11l_sz_.replace(l111l_sz_ (u"ࠨࠨࡤࡱࡵࡁࠧએ"),l111l_sz_ (u"ࠩࠩࠫઐ"))
    l111ll11l_sz_ = l111ll11l_sz_.replace(l111l_sz_ (u"ࠪࡠࡺ࠶࠱࠱࠷ࠪઑ"),l111l_sz_ (u"ࠫऊ࠭઒")).replace(l111l_sz_ (u"ࠬࡢࡵ࠱࠳࠳࠸ࠬઓ"),l111l_sz_ (u"࠭ऄࠨઔ"))
    l111ll11l_sz_ = l111ll11l_sz_.replace(l111l_sz_ (u"ࠧ࡝ࡷ࠳࠵࠵࠽ࠧક"),l111l_sz_ (u"ࠨउࠪખ")).replace(l111l_sz_ (u"ࠩ࡟ࡹ࠵࠷࠰࠷ࠩગ"),l111l_sz_ (u"ࠪऊࠬઘ"))
    l111ll11l_sz_ = l111ll11l_sz_.replace(l111l_sz_ (u"ࠫࡡࡻ࠰࠲࠳࠼ࠫઙ"),l111l_sz_ (u"ࠬटࠧચ")).replace(l111l_sz_ (u"࠭࡜ࡶ࠲࠴࠵࠽࠭છ"),l111l_sz_ (u"ࠧङࠩજ"))
    l111ll11l_sz_ = l111ll11l_sz_.replace(l111l_sz_ (u"ࠨ࡞ࡸ࠴࠶࠺࠲ࠨઝ"),l111l_sz_ (u"ࠩॅࠫઞ")).replace(l111l_sz_ (u"ࠪࡠࡺ࠶࠱࠵࠳ࠪટ"),l111l_sz_ (u"ࠫॆ࠭ઠ"))
    l111ll11l_sz_ = l111ll11l_sz_.replace(l111l_sz_ (u"ࠬࡢࡵ࠱࠳࠷࠸ࠬડ"),l111l_sz_ (u"࠭ॄࠨઢ")).replace(l111l_sz_ (u"ࠧ࡝ࡷ࠳࠵࠹࠺ࠧણ"),l111l_sz_ (u"ࠨॅࠪત"))
    l111ll11l_sz_ = l111ll11l_sz_.replace(l111l_sz_ (u"ࠩ࡟ࡹ࠵࠶ࡦ࠴ࠩથ"),l111l_sz_ (u"ࠪࣷࠬદ")).replace(l111l_sz_ (u"ࠫࡡࡻ࠰࠱ࡦ࠶ࠫધ"),l111l_sz_ (u"ࠬࣙࠧન"))
    l111ll11l_sz_ = l111ll11l_sz_.replace(l111l_sz_ (u"࠭࡜ࡶ࠲࠴࠹ࡧ࠭઩"),l111l_sz_ (u"ࠧड़ࠩપ")).replace(l111l_sz_ (u"ࠨ࡞ࡸ࠴࠶࠻ࡡࠨફ"),l111l_sz_ (u"ࠩढ़ࠫબ"))
    l111ll11l_sz_ = l111ll11l_sz_.replace(l111l_sz_ (u"ࠪࡠࡺ࠶࠱࠸ࡣࠪભ"),l111l_sz_ (u"ࠫॿ࠭મ")).replace(l111l_sz_ (u"ࠬࡢࡵ࠱࠳࠺࠽ࠬય"),l111l_sz_ (u"࠭ॹࠨર"))
    l111ll11l_sz_ = l111ll11l_sz_.replace(l111l_sz_ (u"ࠧ࡝ࡷ࠳࠵࠼ࡩࠧ઱"),l111l_sz_ (u"ࠨॾࠪલ")).replace(l111l_sz_ (u"ࠩ࡟ࡹ࠵࠷࠷ࡣࠩળ"),l111l_sz_ (u"ࠪॿࠬ઴"))
    return l111ll11l_sz_
