# -*- coding: utf-8 -*-
import sys
l11ll_sz_ = sys.version_info [0] == 2
l111_sz_ = 2048
l1lll_sz_ = 7
def l111l_sz_ (ll_sz_):
	global l11l1l_sz_
	l11l11_sz_ = ord (ll_sz_ [-1])
	l1111_sz_ = ll_sz_ [:-1]
	l1l1l1_sz_ = l11l11_sz_ % len (l1111_sz_)
	l1ll_sz_ = l1111_sz_ [:l1l1l1_sz_] + l1111_sz_ [l1l1l1_sz_:]
	if l11ll_sz_:
		l1l1ll_sz_ = unicode () .join ([unichr (ord (char) - l111_sz_ - (l11l1_sz_ + l11l11_sz_) % l1lll_sz_) for l11l1_sz_, char in enumerate (l1ll_sz_)])
	else:
		l1l1ll_sz_ = str () .join ([chr (ord (char) - l111_sz_ - (l11l1_sz_ + l11l11_sz_) % l1lll_sz_) for l11l1_sz_, char in enumerate (l1ll_sz_)])
	return eval (l1l1ll_sz_)
l111l_sz_ (u"ࠨࠢࠣࠏࠍࡇࡷ࡫ࡡࡵࡧࡧࠤࡴࡴࠠࡕࡪࡸࠤࡋ࡫ࡢࠡ࠳࠴ࠤ࠶࠾࠺࠵࠹࠽࠸࠸ࠦ࠲࠱࠳࠹ࠑࠏࠓࠊࡁࡣࡸࡸ࡭ࡵࡲ࠻ࠢࡵࡥࡲ࡯ࡣࠎࠌࠥࠦࠧ৐")
import urllib2
import re
import l11lll111_sz_ as l11lll111_sz_
l11ll1ll1_sz_=l111l_sz_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡨࡪࡡ࠯ࡲ࡯ࠫ৑")
l11lll1ll_sz_ = 5
def l11lll1l1_sz_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l111l_sz_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ৒"), l111l_sz_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠶࠻࠲࠵࠴࠲࠶࠸࠷࠲࠾࠽ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧ৓"))
    if cookies:
        req.add_header(l111l_sz_ (u"ࠥࡇࡴࡵ࡫ࡪࡧࠥ৔"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11lll1ll_sz_)
        l1ll1lll_sz_ =  response.read()
        response.close()
    except:
        l1ll1lll_sz_=l111l_sz_ (u"ࠫࠬ৕")
    return l1ll1lll_sz_
def _11llll1l_sz_(content):
    src =l111l_sz_ (u"ࠬ࠭৖")
    l11ll111l_sz_ = re.compile(l111l_sz_ (u"ࠨࡥࡷࡣ࡯ࠬ࠳࠰࠿ࠪ࡞ࡾࡠࢂࡢࠩ࡝ࠫࠥৗ"),re.DOTALL).findall(content)
    for l11ll1111_sz_ in l11ll111l_sz_:
        l11ll1111_sz_=re.sub(l111l_sz_ (u"ࠧࠡࠢࠪ৘"),l111l_sz_ (u"ࠨࠢࠪ৙"),l11ll1111_sz_)
        l11ll1111_sz_=re.sub(l111l_sz_ (u"ࠩ࡟ࡲࠬ৚"),l111l_sz_ (u"ࠪࠫ৛"),l11ll1111_sz_)
        try:
            l11l1ll1l_sz_ = l11lll111_sz_.unpack(l11ll1111_sz_)
        except:
            l11l1ll1l_sz_=l111l_sz_ (u"ࠫࠬড়")
        if l11l1ll1l_sz_:
            l11l1ll1l_sz_=re.sub(l111l_sz_ (u"ࡷ࠭࡜࡝ࠩঢ়"),l111l_sz_ (u"ࡸࠧࠨ৞"),l11l1ll1l_sz_)
            l11ll11l1_sz_ = re.compile(l111l_sz_ (u"ࠧ࡜ࠤ࡟ࠫࡢ࠰ࡦࡪ࡮ࡨ࡟ࠧࡢࠧ࡞ࠬ࡟ࡷ࠯ࡀ࡜ࡴࠬ࡞ࠦࡡ࠭࡝ࠩ࠰࠮ࡃ࠮ࡡࠢ࡝ࠩࡠ࠰ࠬয়"),  re.DOTALL).search(content)
            l11ll1l1l_sz_ = re.compile(l111l_sz_ (u"ࠨ࡝ࠥࡠࠬࡣࡦࡪ࡮ࡨ࡟ࠧࡢࠧ࡞࠼࡞ࠦࡡ࠭࡝ࠩ࠰࠭ࡃࡡ࠴࡭ࡱ࠶ࠬ࡟ࠧࡢࠧ࡞ࠩৠ"),  re.DOTALL).search(content)
            l11ll1l11_sz_ = re.compile(l111l_sz_ (u"ࠩ࡞ࠦࡡ࠭࡝ࠫࠪ࠱࠮ࡄࡢ࠮࡮ࡲ࠷࠭ࡠࠨ࡜ࠨ࡟࠭ࠫৡ"),  re.DOTALL).search(content)
            if l11ll11l1_sz_:   src = l11ll11l1_sz_.group(1)
            elif l11ll1l1l_sz_: src = l11ll1l1l_sz_.group(1)
            elif l11ll1l11_sz_: src = l11ll1l11_sz_.group(1)
            if src:
                break
    return src
def l11lll11l_sz_(content):
    l111l_sz_ (u"ࠥࠦࠧࠓࠊࠡࠢࠣࠤࡘࡩࡡ࡯ࡵࠣࡪࡴࡸࠠࡷ࡫ࡧࡩࡴࠦ࡬ࡪࡰ࡮ࠤ࡮ࡴࡣ࡭ࡷࡧࡩࡩࠦࡥ࡯ࡥࡲࡨࡪࡪࠠࡰࡰࡨࠑࠏࠦࠠࠡࠢࠥࠦࠧৢ")
    l11l1llll_sz_=l111l_sz_ (u"ࠫࠬৣ")
    l11ll11l1_sz_ = re.compile(l111l_sz_ (u"ࠬࡡࠢ࡝ࠩࡠ࠮࡫࡯࡬ࡦ࡝ࠥࡠࠬࡣࠪ࡝ࡵ࠭࠾ࡡࡹࠪ࡜ࠤ࡟ࠫࡢ࠮࠮ࠬࡁࠬ࡟ࠧࡢࠧ࡞࠮ࠪ৤"),  re.DOTALL).search(content)
    l11ll1l1l_sz_ = re.compile(l111l_sz_ (u"࡛࠭ࠣ࡞ࠪࡡ࡫࡯࡬ࡦ࡝ࠥࡠࠬࡣ࠺࡜ࠤ࡟ࠫࡢ࠮࠮ࠫࡁ࡟࠲ࡲࡶ࠴ࠪ࡝ࠥࡠࠬࡣࠧ৥"),  re.DOTALL).search(content)
    l11ll1l11_sz_ = re.compile(l111l_sz_ (u"ࠧ࡜ࠤ࡟ࠫࡢ࠰ࠨ࠯ࠬࡂࡠ࠳ࡳࡰ࠵ࠫ࡞ࠦࡡ࠭࡝ࠫࠩ০"),  re.DOTALL).search(content)
    if l11ll11l1_sz_:
        print l111l_sz_ (u"ࠨࡨࡲࡹࡳࡪࠠࡓࡇࠣ࡟࡫࡯࡬ࡦ࠼ࡠࠫ১")
        l11l1llll_sz_ = l11ll11l1_sz_.group(1)
    elif l11ll1l1l_sz_:
        print l111l_sz_ (u"ࠩࡩࡳࡺࡴࡤࠡࡔࡈࠤࡠࡻࡲ࡭࠼ࡠࠫ২")
        l11l1llll_sz_ = l11ll1l1l_sz_.group(1)
    elif l11ll1l11_sz_:
        print l111l_sz_ (u"ࠪࡪࡴࡻ࡮ࡥࠢࡕࡉࠥࡡࡵࡳ࡮࠽ࡡࠬ৩")
        l11l1llll_sz_ = l11ll1l11_sz_.group(1)
    else:
        print l111l_sz_ (u"ࠫࡪࡴࡣࡰࡦࡨࡨࠥࡀࠠࡶࡰࡳࡥࡨࡱࡥࡳࠩ৪")
        l11l1llll_sz_ = _11llll1l_sz_(content)
    return l11l1llll_sz_
def l11l1l1ll_sz_(url):
    l111l_sz_ (u"ࠧࠨࠢࠎࠌࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࡹࠠࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠱ࠥࡻ࡬ࡳࠢ࡫ࡸࡹࡶ࠺࠰࠱࠱࠲࠳࠴ࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠰ࠤࡴࡸࠠ࡭࡫ࡶࡸࠥࡵࡦࠡ࡝ࠫࠫ࠼࠸࠰ࡱࠩ࠯ࠤࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡦࡨࡦ࠴ࡰ࡭࠱ࡹ࡭ࡩ࡫࡯࠰࠳࠼࠸࠻࠿࠹࠲ࡨࡂࡻࡪࡸࡳ࡫ࡣࡀ࠻࠷࠶ࡰࠨࠫ࠯࠲࠳࠴࡝ࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠒࠐࠠࠡࠢࠣࠦࠧࠨ৫")
    l11ll11ll_sz_=l111l_sz_ (u"࠭ࡼࡄࡱࡲ࡯࡮࡫࠽ࡑࡊࡓࡗࡊ࡙ࡓࡊࡆࡀ࠵ࠫࡘࡥࡧࡧࡵࡩࡷࡃࡨࡵࡶࡳ࠾࠴࠵ࡳࡵࡣࡷ࡭ࡨ࠴ࡣࡥࡣ࠱ࡴࡱ࠵ࡦ࡭ࡱࡺࡴࡱࡧࡹࡦࡴ࠲ࡪࡱࡧࡳࡩ࠱ࡩࡰࡴࡽࡰ࡭ࡣࡼࡩࡷ࠴ࡣࡰ࡯ࡰࡩࡷࡩࡩࡢ࡮࠰࠷࠳࠸࠮࠲࠺࠱ࡷࡼ࡬ࠧ৬")
    content = l11lll1l1_sz_(url)
    src=[]
    if not l111l_sz_ (u"ࠧࡀࡹࡨࡶࡸࡰࡡࠨ৭") in url:
         l11l1lll1_sz_ = re.compile(l111l_sz_ (u"ࠨ࠾ࡤࠤࡩࡧࡴࡢ࠯ࡴࡹࡦࡲࡩࡵࡻࡀࠦ࠭࠴ࠪࡀࠫࠥࠤ࠭ࡅࡐ࠽ࡊࡁ࠲࠯ࡅࠩ࠿ࠪࡂࡔࡁࡗ࠾࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ৮"), re.DOTALL).findall(content)
         for quality in l11l1lll1_sz_:
             l1ll1lll_sz_ = re.search(l111l_sz_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ৯"),quality[1])
             l11l1ll11_sz_ = quality[2]
             src.insert(0,(l11l1ll11_sz_,l11ll1ll1_sz_+l1ll1lll_sz_.group(1)))
    if not src:
        src = l11lll11l_sz_(content)
        if src:
            src+=l11ll11ll_sz_
    return src
def l11ll1lll_sz_(url,quality=0):
    l111l_sz_ (u"ࠥࠦࠧࠓࠊࠡࠢࠣࠤࡷ࡫ࡴࡶࡴࡱࡷࠥࡻࡲ࡭ࠢࡷࡳࠥࡼࡩࡥࡧࡲࠑࠏࠦࠠࠡࠢࠥࠦࠧৰ")
    src = l11l1l1ll_sz_(url)
    if type(src)==list:
        selected=src[quality]
        print l111l_sz_ (u"ࠫࡖࡻࡡ࡭࡫ࡷࡽࠥࡀࠧৱ"),selected[0]
        src = l11l1l1ll_sz_(selected[1])
    return src
