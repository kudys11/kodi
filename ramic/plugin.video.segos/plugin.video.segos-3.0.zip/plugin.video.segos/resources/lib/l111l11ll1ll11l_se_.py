# -*- coding: utf-8 -*-
import sys
l1ll1ll11l_se_ = sys.version_info [0] == 2
l1ll11ll1ll11l_se_ = 2048
l11l1ll1ll11l_se_ = 7
def l11llll1ll11l_se_ (llll1ll11l_se_):
	global l1ll1lll1ll11l_se_
	l111llll1ll11l_se_ = ord (llll1ll11l_se_ [-1])
	l1111ll1ll11l_se_ = llll1ll11l_se_ [:-1]
	l1l111ll1ll11l_se_ = l111llll1ll11l_se_ % len (l1111ll1ll11l_se_)
	l1l1ll1ll11l_se_ = l1111ll1ll11l_se_ [:l1l111ll1ll11l_se_] + l1111ll1ll11l_se_ [l1l111ll1ll11l_se_:]
	if l1ll1ll11l_se_:
		l1l1l1ll1ll11l_se_ = unicode () .join ([unichr (ord (char) - l1ll11ll1ll11l_se_ - (l1l11ll1ll11l_se_ + l111llll1ll11l_se_) % l11l1ll1ll11l_se_) for l1l11ll1ll11l_se_, char in enumerate (l1l1ll1ll11l_se_)])
	else:
		l1l1l1ll1ll11l_se_ = str () .join ([chr (ord (char) - l1ll11ll1ll11l_se_ - (l1l11ll1ll11l_se_ + l111llll1ll11l_se_) % l11l1ll1ll11l_se_) for l1l11ll1ll11l_se_, char in enumerate (l1l1ll1ll11l_se_)])
	return eval (l1l1l1ll1ll11l_se_)
import urllib2,urllib
import os,re
import urlparse
import cookielib
l11l1l1llll1ll11l_se_=l11llll1ll11l_se_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡧࡪࡳࡸ࠴ࡥࡴ࠱ࠪਏ")
l11ll1111ll1ll11l_se_ = 10
l1111l111ll1ll11l_se_=l11llll1ll11l_se_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ਐ")
l1ll11llll1ll11l_se_=l11llll1ll11l_se_ (u"ࡳࠩࠪ਑")
def l11l1llllll1ll11l_se_(url,data=None,header={},l1llll1111ll1ll11l_se_=True,l11111ll1ll1ll11l_se_=False):
    if l1ll11llll1ll11l_se_ and os.path.isfile(l1ll11llll1ll11l_se_) and l1llll1111ll1ll11l_se_:
        l1111lll1ll1ll11l_se_ = cookielib.LWPCookieJar()
        l1111lll1ll1ll11l_se_.load(l1ll11llll1ll11l_se_)
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1111lll1ll1ll11l_se_))
        urllib2.install_opener(opener)
    req = urllib2.Request(url,data)
    if not header:
        header = {l11llll1ll11l_se_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭਒"):l1111l111ll1ll11l_se_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l11ll1111ll1ll11l_se_)
        l1ll1l1lll1ll11l_se_ =  response.read()
        response.close()
        if l1ll11llll1ll11l_se_ and os.path.isfile(l1ll11llll1ll11l_se_) and l11111ll1ll1ll11l_se_ and l1llll1111ll1ll11l_se_:
             l1111lll1ll1ll11l_se_.save(l1ll11llll1ll11l_se_, ignore_discard = True)
    except urllib2.HTTPError as e:
        l1ll1l1lll1ll11l_se_ = l11llll1ll11l_se_ (u"ࠪࠫਓ")
    return l1ll1l1lll1ll11l_se_
def l11lll1lll1ll11l_se_(u=l11llll1ll11l_se_ (u"ࠫࠬਔ"),p=l11llll1ll11l_se_ (u"ࠬ࠭ਕ")):
    try:
        url=l11llll1ll11l_se_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡧࡪࡳࡸ࠴ࡥࡴ࠱ࡂࡴࡦ࡭ࡥ࠾࡮ࡲ࡫࡮ࡴࠧਖ")
        data=l11llll1ll11l_se_ (u"ࠧ࡭ࡱࡪ࡭ࡳࡃࠥࡴࠨࡳࡥࡸࡹࡷࡰࡴࡧࡁࠪࡹࠦ࡭ࡱࡪࡹ࡯ࡃࠧਗ")%(u,p)
        l1111lll1ll1ll11l_se_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1111lll1ll1ll11l_se_))
        urllib2.install_opener(opener)
        req = urllib2.Request(url,data,headers={l11llll1ll11l_se_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬਘ"):l1111l111ll1ll11l_se_})
        response = urllib2.urlopen(req,timeout=l11ll1111ll1ll11l_se_)
        l1111lll1ll1ll11l_se_.save(l1ll11llll1ll11l_se_, ignore_discard = True)
        response.close()
        content = l11l1llllll1ll11l_se_(l11l1l1llll1ll11l_se_,header = {l11llll1ll11l_se_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ਙ"):l1111l111ll1ll11l_se_,l11llll1ll11l_se_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫਚ"):l11llll1ll11l_se_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡥࡨࡱࡶ࠲ࡪࡹ࠯ࡀࡲࡤ࡫ࡪࡃ࡬ࡰࡩ࡬ࡲࠬਛ")})
    except:
        content=l11llll1ll11l_se_ (u"ࠬ࠭ਜ")
    out = True if content.find(l11llll1ll11l_se_ (u"࠭ࡗࡺ࡮ࡲ࡫ࡺࡰࠧਝ"))>0 else False
    return out
def l11ll1l1ll1ll11l_se_(top=l11llll1ll11l_se_ (u"ࠧࡕࡱࡳࠤ࠶࠶ࠠࡰࡦࡺ࡭ࡪࡪࡺࡢࡰࡼࡧ࡭࠭ਞ")):
    content = l11l1llllll1ll11l_se_(l11l1l1llll1ll11l_se_)
    ids = [(a.start(), a.end()) for a in re.finditer(l11llll1ll11l_se_ (u"ࠨ࠾࡫࠷ࠥࡹࡴࡺ࡮ࡨࡁࠧ࡬࡯࡯ࡶ࠰ࡪࡦࡳࡩ࡭ࡻ࠽ࠤ࠳࠰ࠢ࠿ࠩਟ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11111lllll1ll11l_se_ = content[ ids[i][1]:ids[i+1][0] ]
        if top in l11111lllll1ll11l_se_:
            items = re.compile(l11llll1ll11l_se_ (u"ࠩ࠿ࡥࠥࡪࡡࡵࡣ࠰ࡸࡴ࡭ࡧ࡭ࡧࡀࠦࡹࡵ࡯࡭ࡶ࡬ࡴࠧ࠮࠮ࠫࡁ࠿࠳ࡦࡄࠩࠨਠ"),re.DOTALL).findall(l11111lllll1ll11l_se_)
            for item in items:
                href = re.compile(l11llll1ll11l_se_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩਡ")).findall(item)
                l1llll111lll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"ࠫࡁ࡯࡭ࡨࠢࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡱ࡬࠳ࡲࡦࡵࡳࡳࡳࡹࡩࡷࡧࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩਢ")).findall(item)
                l1llll11llll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"ࠬࡺࡩࡵ࡮ࡨࡁࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠧਣ")).findall(item)
                title = re.compile(l11llll1ll11l_se_ (u"࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧਤ")).findall(item)
                l1llll11l1ll1ll11l_se_ =  re.compile(l11llll1ll11l_se_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡩ࡮ࡣࡪࡩࡸ࠵࡬ࡢࡰࡪࡷ࠴࠮࠮ࠫࡁࠬ࠲ࡵࡴࡧࠣࠩਥ")).findall(item)
                quality = l11llll1ll11l_se_ (u"ࠨࠢࡋࡈࠬਦ") if l11111lllll1ll11l_se_.find(l11llll1ll11l_se_ (u"ࠩࡶࡶࡨࡃࠢ࠰࡫ࡰࡥ࡬࡫ࡳ࠰ࡪࡧ࠲ࠬਧ"))>-1 else l11llll1ll11l_se_ (u"ࠪࠫਨ")
                l1lll1l1llll1ll11l_se_ = l11llll1ll11l_se_ (u"ࠫࠬ਩")
                l1llll111lll1ll11l_se_ = l1llll111lll1ll11l_se_[0] if l1llll111lll1ll11l_se_ else l11llll1ll11l_se_ (u"ࠬ࠭ਪ")
                if l1llll111lll1ll11l_se_.startswith(l11llll1ll11l_se_ (u"࠭࠯ࠨਫ")):
                    l1llll111lll1ll11l_se_=l11l1l1llll1ll11l_se_[:-1]+l1llll111lll1ll11l_se_
                elif l1llll111lll1ll11l_se_.startswith(l11llll1ll11l_se_ (u"ࠧ࠯࠰࠲ࠫਬ")):
                    l1llll111lll1ll11l_se_=l1llll111lll1ll11l_se_.replace(l11llll1ll11l_se_ (u"ࠨ࠰࠱ࠫਭ"),l11l1l1llll1ll11l_se_)
                elif l1llll111lll1ll11l_se_.startswith(l11llll1ll11l_se_ (u"ࠩࡲࡦࡷࡧࡺ࡬࡫ࠪਮ")):
                    l1llll111lll1ll11l_se_=l11l1l1llll1ll11l_se_+l11llll1ll11l_se_ (u"ࠪ࠳ࠬਯ")+l1llll111lll1ll11l_se_
                code = l1llll11l1ll1ll11l_se_[0] if l1llll11l1ll1ll11l_se_ else l11llll1ll11l_se_ (u"ࠫࠬਰ")
                code += quality if quality else l11llll1ll11l_se_ (u"ࠬ࠭਱")
                title = l11llll1ll11l_se_ (u"࠭ࠧਲ").join(title).strip()
                if href and title:
                    year = re.search(l11llll1ll11l_se_ (u"ࠧ࡝ࠪࠫࡠࡩࢁ࠴ࡾࠫ࡟࠭ࠬਲ਼"),title)
                    year = re.search(l11llll1ll11l_se_ (u"ࠨ࡞ࠫࠬࡡࡪࡻ࠵ࡿࠬࡠ࠮࠭਴"),l1llll11llll1ll11l_se_[0]) if not year and l1llll11llll1ll11l_se_ else year
                    l1llll1ll11l_se_ = {l11llll1ll11l_se_ (u"ࠩࡸࡶࡱ࠭ਵ")   : urlparse.urljoin(l11l1l1llll1ll11l_se_,href[0]),
                        l11llll1ll11l_se_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩਸ਼")  : l1lllll1l1ll1ll11l_se_(title),
                        l11llll1ll11l_se_ (u"ࠫࡵࡲ࡯ࡵࠩ਷")   : l1lllll1l1ll1ll11l_se_(l1llll11llll1ll11l_se_[0].strip(l11llll1ll11l_se_ (u"ࠬࡀࠠࠨਸ"))) if l1llll11llll1ll11l_se_ else l11llll1ll11l_se_ (u"࠭ࠧਹ"),
                        l11llll1ll11l_se_ (u"ࠧࡪ࡯ࡪࠫ਺")    : l1llll111lll1ll11l_se_,
                        l11llll1ll11l_se_ (u"ࠨࡴࡤࡸ࡮ࡴࡧࠨ਻") : l11llll1ll11l_se_ (u"਼ࠩࠪ"),
                        l11llll1ll11l_se_ (u"ࠪ࡫ࡪࡴࡲࡦࠩ਽") : l11llll1ll11l_se_ (u"ࠫࠬਾ"),
                        l11llll1ll11l_se_ (u"ࠬࡿࡥࡢࡴࠪਿ")   : year.group(1) if year else l11llll1ll11l_se_ (u"࠭ࠧੀ"),
                        l11llll1ll11l_se_ (u"ࠧࡤࡱࡧࡩࠬੁ")  : code.strip(),
                        l11llll1ll11l_se_ (u"ࠨࡶࡵࡥ࡮ࡲࡥࡳࠩੂ") : l11llll1ll11l_se_ (u"ࠩࠪ੃"),
                        l11llll1ll11l_se_ (u"ࠪࡱࡪࡪࡩࡢࡶࡼࡴࡪ࠭੄"): l11llll1ll11l_se_ (u"ࠫࡲࡵࡶࡪࡧࠪ੅")
                            }
                    print l1llll1ll11l_se_[l11llll1ll11l_se_ (u"ࠬࡺࡲࡢ࡫࡯ࡩࡷ࠭੆")]
                    out.append(l1llll1ll11l_se_)
    return out
def l1lllll1ll1ll11l_se_(url,l11ll1llll1ll11l_se_=1):
    if l11llll1ll11l_se_ (u"࠭࡮ࡳ࠿ࠪੇ") in url:
        url = re.sub(l11llll1ll11l_se_ (u"ࠧ࡯ࡴࡀࡠࡩ࠱ࠧੈ"),l11llll1ll11l_se_ (u"ࠨࡰࡵࡁࠪࡪࠧ੉")%int(l11ll1llll1ll11l_se_),url)
    else:
        url = url + l11llll1ll11l_se_ (u"ࠩࠩࡲࡷࡃࠥࡥࠩ੊") %l11ll1llll1ll11l_se_
    content = l11l1llllll1ll11l_se_(url)
    l1llll1l11ll1ll11l_se_=False
    l111111l1ll1ll11l_se_=url.replace(l11l1l1llll1ll11l_se_,l11llll1ll11l_se_ (u"ࠪࠫੋ")).replace(l11llll1ll11l_se_ (u"ࠫࡳࡸ࠽ࠦࡦࠪੌ")%l11ll1llll1ll11l_se_,l11llll1ll11l_se_ (u"ࠬࡴࡲ࠾ࠧࡧ੍ࠫ") %(l11ll1llll1ll11l_se_+1))
    if content.find(l111111l1ll1ll11l_se_.split(l11llll1ll11l_se_ (u"࠭࠯ࠨ੎"))[-1])>-1:
        l1llll1l11ll1ll11l_se_ = l11ll1llll1ll11l_se_+1
    ids = [(a.start(), a.end()) for a in re.finditer(l11llll1ll11l_se_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡭࠯࡯࡫࠲ࡢࡤࠬࠢࡦࡳࡱ࠳࡭ࡥ࠯࡟ࡨ࠰࠭੏"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11111lllll1ll11l_se_ = content[ ids[i][1]:ids[i+1][0] ]
        l1llll1lllll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࡷ࡫ࡨࡻ࠳࠰࠿ࠪࠤ࡟ࡷ࠯ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ੐")).findall(l11111lllll1ll11l_se_)
        l1llll111lll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"ࠩ࠿࡭ࡲ࡭ࠠࡤ࡮ࡤࡷࡸࡃࠢࡪ࡯ࡪ࠱ࡷ࡫ࡳࡱࡱࡱࡷ࡮ࡼࡥࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧੑ")).findall(l11111lllll1ll11l_se_)
        l11111l1lll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࡂࡡ࡞ࠣ࡟࠮ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ੒")).findall(l11111lllll1ll11l_se_)
        l1llll11llll1ll11l_se_= re.compile(l11llll1ll11l_se_ (u"ࠫࡁࡨ࠾ࡐࡲ࡬ࡷࡁ࠵ࡢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ੓"),re.DOTALL).findall(l11111lllll1ll11l_se_)
        l1llll11l1ll1ll11l_se_ =  re.compile(l11llll1ll11l_se_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳࡮ࡳࡡࡨࡧࡶ࠳ࡱࡧ࡮ࡨࡵ࠲ࠬ࠳࠰࠿ࠪ࠰ࡳࡲ࡬ࠨ࠾ࠨ੔")).findall(l11111lllll1ll11l_se_)
        quality = l11llll1ll11l_se_ (u"࠭ࠠࡉࡆࠪ੕") if l11111lllll1ll11l_se_.find(l11llll1ll11l_se_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡩ࡮ࡣࡪࡩࡸ࠵ࡨࡥ࠰ࠪ੖"))>-1 else l11llll1ll11l_se_ (u"ࠨࠩ੗")
        l1lll1l1llll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡨࡱࡧ࡫ࡤ࠮ࡴࡨࡷࡵࡵ࡮ࡴ࡫ࡹࡩ࠲࡯ࡴࡦ࡯ࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ੘")).findall(l11111lllll1ll11l_se_)
        l1llll111lll1ll11l_se_ = l1llll111lll1ll11l_se_[0] if l1llll111lll1ll11l_se_ else l11llll1ll11l_se_ (u"ࠪࠫਖ਼")
        if l1llll111lll1ll11l_se_.startswith(l11llll1ll11l_se_ (u"ࠫ࠴࠭ਗ਼")):
            l1llll111lll1ll11l_se_=l11l1l1llll1ll11l_se_[:-1]+l1llll111lll1ll11l_se_
        elif l1llll111lll1ll11l_se_.startswith(l11llll1ll11l_se_ (u"ࠬ࠴࠮࠰ࠩਜ਼")):
            l1llll111lll1ll11l_se_=l1llll111lll1ll11l_se_.replace(l11llll1ll11l_se_ (u"࠭࠮࠯ࠩੜ"),l11l1l1llll1ll11l_se_)
        elif l1llll111lll1ll11l_se_.startswith(l11llll1ll11l_se_ (u"ࠧࡰࡤࡵࡥࡿࡱࡩࠨ੝")):
            l1llll111lll1ll11l_se_=l11l1l1llll1ll11l_se_+l11llll1ll11l_se_ (u"ࠨ࠱ࠪਫ਼")+l1llll111lll1ll11l_se_
        code = l1llll11l1ll1ll11l_se_[0] if l1llll11l1ll1ll11l_se_ else l11llll1ll11l_se_ (u"ࠩࠪ੟")
        code += quality if quality else l11llll1ll11l_se_ (u"ࠪࠫ੠")
        if l1llll1lllll1ll11l_se_ and l1llll111lll1ll11l_se_:
            title = l1llll1lllll1ll11l_se_[0][1]
            year = re.search(l11llll1ll11l_se_ (u"ࠫࡡ࠮ࠨ࡝ࡦࡾ࠸ࢂ࠯࡜ࠪࠩ੡"),title)
            l1llll1ll11l_se_ = {l11llll1ll11l_se_ (u"ࠬࡻࡲ࡭ࠩ੢")   : l11l1l1llll1ll11l_se_+l1llll1lllll1ll11l_se_[0][0],
                l11llll1ll11l_se_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ੣")  : l1lllll1l1ll1ll11l_se_(title),
                l11llll1ll11l_se_ (u"ࠧࡱ࡮ࡲࡸࠬ੤")   : l1lllll1l1ll1ll11l_se_(l1llll11llll1ll11l_se_[0].strip(l11llll1ll11l_se_ (u"ࠨ࠼ࠣࠫ੥"))) if l1llll11llll1ll11l_se_ else l11llll1ll11l_se_ (u"ࠩࠪ੦"),
                l11llll1ll11l_se_ (u"ࠪ࡭ࡲ࡭ࠧ੧")    : l1llll111lll1ll11l_se_,
                l11llll1ll11l_se_ (u"ࠫࡷࡧࡴࡪࡰࡪࠫ੨") : l11llll1ll11l_se_ (u"ࠬ࠭੩"),
                l11llll1ll11l_se_ (u"࠭ࡧࡦࡰࡵࡩࠬ੪") : l11llll1ll11l_se_ (u"ࠧ࠭ࠩ੫").join(l11111l1lll1ll11l_se_) if l11111l1lll1ll11l_se_ else l11llll1ll11l_se_ (u"ࠨࠩ੬"),
                l11llll1ll11l_se_ (u"ࠩࡼࡩࡦࡸࠧ੭")   : year.group(1) if year else l11llll1ll11l_se_ (u"ࠪࠫ੮"),
                l11llll1ll11l_se_ (u"ࠫࡨࡵࡤࡦࠩ੯")  : code.strip(),
                l11llll1ll11l_se_ (u"ࠬࡺࡲࡢ࡫࡯ࡩࡷ࠭ੰ") : l1lll1l1llll1ll11l_se_[0] if l1lll1l1llll1ll11l_se_ else l11llll1ll11l_se_ (u"࠭ࠧੱ"),
                l11llll1ll11l_se_ (u"ࠧ࡮ࡧࡧ࡭ࡦࡺࡹࡱࡧࠪੲ"): l11llll1ll11l_se_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧੳ")
                    }
            out.append(l1llll1ll11l_se_)
    l11111l11ll1ll11l_se_ = l11ll1llll1ll11l_se_-1 if l11ll1llll1ll11l_se_>1 else False
    return (out, (l11111l11ll1ll11l_se_,l1llll1l11ll1ll11l_se_))
def l1llll1l1lll1ll11l_se_(url=l11llll1ll11l_se_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡪ࡭࡯ࡴ࠰ࡨࡷ࠴ࡸࡥࡤࡱࡰࡩࡳࡪ࡟࡭࡫ࡶࡸ࠳ࡶࡨࡱࠩੴ")):
    l1lllllll1ll1ll11l_se_=[]
    l1llllll11ll1ll11l_se_=[]
    content = l11l1llllll1ll11l_se_(url)
    l1lll1ll1lll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"ࠪࡀࡹࡸ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡴࡁࠫੵ"),re.DOTALL).findall(content)
    for l1l1lll1ll11l_se_ in l1lll1ll1lll1ll11l_se_:
        l1llll1lllll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"ࠫࡁࡶ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࡁ࠵ࡰ࠿ࠩ੶")).findall(l1l1lll1ll11l_se_)
        l1llll111lll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"ࠬࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ੷")).findall(l1l1lll1ll11l_se_)
        if l1llll1lllll1ll11l_se_:
            l1llll1ll11l_se_ = {l11llll1ll11l_se_ (u"࠭ࡵࡳ࡮ࠪ੸")   : l11l1l1llll1ll11l_se_+l1llll1lllll1ll11l_se_[0][0],
                l11llll1ll11l_se_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭੹")  : l1lllll1l1ll1ll11l_se_(l1llll1lllll1ll11l_se_[0][1]),
                l11llll1ll11l_se_ (u"ࠨࡲ࡯ࡳࡹ࠭੺")   : l11llll1ll11l_se_ (u"ࠩࠪ੻"),
                l11llll1ll11l_se_ (u"ࠪ࡭ࡲ࡭ࠧ੼")    : l11l1l1llll1ll11l_se_+l1llll111lll1ll11l_se_[0] if l1llll111lll1ll11l_se_ else l11llll1ll11l_se_ (u"ࠫࠬ੽"),
                l11llll1ll11l_se_ (u"ࠬࡸࡡࡵ࡫ࡱ࡫ࠬ੾") : l11llll1ll11l_se_ (u"࠭ࠧ੿"),
                l11llll1ll11l_se_ (u"ࠧࡺࡧࡤࡶࠬ઀")   : l11llll1ll11l_se_ (u"ࠨࠩઁ"),
                l11llll1ll11l_se_ (u"ࠩࡦࡳࡩ࡫ࠧં")  : l11llll1ll11l_se_ (u"ࠪࠫઃ"),
                    }
            if   l11llll1ll11l_se_ (u"ࠫ࠴ࡨࡡ࡫࡭࡬࠳ࠬ઄") in l1llll1lllll1ll11l_se_[0][0]:
                l1llllll11ll1ll11l_se_.append(l1llll1ll11l_se_)
            elif l11llll1ll11l_se_ (u"ࠬ࠵ࡦࡪ࡮ࡰࡽ࠴࠭અ") in l1llll1lllll1ll11l_se_[0][0]:
                l1lllllll1ll1ll11l_se_.append(l1llll1ll11l_se_)
    return (l1lllllll1ll1ll11l_se_,l1llllll11ll1ll11l_se_)
def l1l1ll1ll1ll11l_se_(url,l1llllllll1ll11l_se_=True):
    info={}
    if l1llllllll1ll11l_se_:
        content = l11l1llllll1ll11l_se_(url)
        l1lll1lll1ll1ll11l_se_ = content.find(l11llll1ll11l_se_ (u"࠭࠼ࡥ࡫ࡹࠤ࡮ࡪ࠽ࠣ࡯ࡼࡘࡦࡨࡃࡰࡰࡷࡩࡳࡺࠢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡶࡤࡦ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨ࠾ࠨઆ"))
        if l1lll1lll1ll1ll11l_se_:
            l11111lllll1ll11l_se_=content[l1lll1lll1ll1ll11l_se_:-1]
            year = re.search(l11llll1ll11l_se_ (u"ࠧ࠽ࡤࡁࡖࡴࡱࠠࡱࡴࡲࡨࡺࡱࡣ࡫࡫࠿࠳ࡧࡄ࠺ࠩ࠰࠭ࡃ࠮ࡂࠧઇ"),l11111lllll1ll11l_se_,flags=re.MULTILINE|re.I)
            l11111l1lll1ll11l_se_ = re.search(l11llll1ll11l_se_ (u"ࠨ࠾ࡥࡂࡌࡧࡴࡶࡰࡨ࡯ࡁ࠵ࡢ࠿࠼ࠫ࠲࠯ࡅࠩ࠽ࠩઈ"),l11111lllll1ll11l_se_,flags=re.DOTALL)
            quality = re.search(l11llll1ll11l_se_ (u"ࠩ࠿ࡦࡃࡐࡡ࡬ࡱफ़ऋࡁ࠵ࡢ࠿࠼ࠫ࠲࠯ࡅࠩ࠽ࠩઉ"),l11111lllll1ll11l_se_,flags=re.MULTILINE|re.I)
            l1lll1ll11ll1ll11l_se_ = re.search(l11llll1ll11l_se_ (u"ࠪࡀࡧࡄࡁࡶࡦ࡬ࡳࡁ࠵ࡢ࠿࠼ࠫ࠲࠯ࡅࠩ࠽ࠩઊ"),l11111lllll1ll11l_se_,flags=re.MULTILINE|re.I)
            l1llll11l1ll1ll11l_se_ = re.search(l11llll1ll11l_se_ (u"ࠫࡁࡨ࠾ࡋछࡽࡽࡰࡂ࠯ࡣࡀ࠽ࠬ࠳࠰࠿ࠪ࠾ࠪઋ"),l11111lllll1ll11l_se_,flags=re.MULTILINE|re.I)
            l1llllllllll1ll11l_se_ = re.search(l11llll1ll11l_se_ (u"ࠬࡂࡢ࠿ࡑࡳ࡭ࡸࡂ࠯ࡣࡀ࠽ࠬ࠳࠰࠿ࠪ࠾ࠪઌ"),l11111lllll1ll11l_se_,flags=re.MULTILINE|re.I)
            if year:    info[l11llll1ll11l_se_ (u"࠭ࡹࡦࡣࡵࠫઍ")]=year.group(1).strip().strip(l11llll1ll11l_se_ (u"ࠧࠩࠩ઎")).strip(l11llll1ll11l_se_ (u"ࠨࠫࠪએ"))
            if l11111l1lll1ll11l_se_:   info[l11llll1ll11l_se_ (u"ࠩࡪࡩࡳࡸࡥࠨઐ")]=l11111l1lll1ll11l_se_.group(1).strip()
            if quality: info[l11llll1ll11l_se_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫઑ")]=quality.group(1).strip()
            if l1lll1ll11ll1ll11l_se_:   info[l11llll1ll11l_se_ (u"ࠫࡦࡻࡤࡪࡱࠪ઒")]=l1lll1ll11ll1ll11l_se_.group(1).strip()
            if l1llll11l1ll1ll11l_se_:    info[l11llll1ll11l_se_ (u"ࠬࡲࡡ࡯ࡩࠪઓ")]=l1llll11l1ll1ll11l_se_.group(1).strip()
            if l1llllllllll1ll11l_se_:    info[l11llll1ll11l_se_ (u"࠭ࡰ࡭ࡱࡷࠫઔ")]=l1lllll1l1ll1ll11l_se_(l1llllllllll1ll11l_se_.group(1).strip())
            info[l11llll1ll11l_se_ (u"ࠧࡤࡱࡧࡩࠬક")]= l11llll1ll11l_se_ (u"ࠨ࠮ࠪખ").join([info.get(l11llll1ll11l_se_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪગ"),l11llll1ll11l_se_ (u"ࠪࠫઘ")),info.get(l11llll1ll11l_se_ (u"ࠫࡱࡧ࡮ࡨࠩઙ"),l11llll1ll11l_se_ (u"ࠬ࠭ચ")),info.get(l11llll1ll11l_se_ (u"࠭ࡡࡶࡦ࡬ࡳࠬછ"),l11llll1ll11l_se_ (u"ࠧࠨજ"))])
    return info
def l1l1ll11ll1ll11l_se_(url):
    l11111111ll1ll11l_se_=[]
    content = l11l1llllll1ll11l_se_(url)
    l1llllll1lll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠪ࠱࠮ࡄ࠯࠼࠰࡫ࡩࡶࡦࡳࡥ࠿ࠩઝ"),re.DOTALL).findall(content)
    for l1lll1llllll1ll11l_se_ in l1llllll1lll1ll11l_se_:
        href = re.compile(l11llll1ll11l_se_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧઞ")).findall(l1lll1llllll1ll11l_se_)
        if href:
            l1ll1l1lll1ll11l_se_ = href[0]
            l1ll1l1lll1ll11l_se_ = l11llll1ll11l_se_ (u"ࠪ࡬ࡹࡺࡰࠨટ")+l1ll1l1lll1ll11l_se_.split(l11llll1ll11l_se_ (u"ࠫ࡭ࡺࡴࡱࠩઠ"))[-1]
            host = urlparse.urlparse(l1ll1l1lll1ll11l_se_).netloc
            if l11llll1ll11l_se_ (u"ࠬ࡭ࡲࡦࡧࡹ࡭ࡩ࠴ࡣࡰ࡯ࠪડ") in host:
                l1ll1l1lll1ll11l_se_ = l1lllll11lll1ll11l_se_(l1ll1l1lll1ll11l_se_)
                host += l11llll1ll11l_se_ (u"࠭ࠠ࠮ࠢࠪઢ") + urlparse.urlparse(l1ll1l1lll1ll11l_se_).netloc
            if l11llll1ll11l_se_ (u"ࠧࡦࡤࡧ࠲ࡨࡪࡡ࠯ࡲ࡯ࠫણ") in host:
                l1ll1l1lll1ll11l_se_ = l11llll1ll11l_se_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡩࡤࡢ࠰ࡳࡰ࠴ࡼࡩࡥࡧࡲ࠳ࠬત")+l1ll1l1lll1ll11l_se_.split(l11llll1ll11l_se_ (u"ࠩ࠲ࠫથ"))[-1]
                host = urlparse.urlparse(l1ll1l1lll1ll11l_se_).netloc
            if l1ll1l1lll1ll11l_se_ and host: l11111111ll1ll11l_se_.append({l11llll1ll11l_se_ (u"ࠪ࡬ࡷ࡫ࡦࠨદ"):l1ll1l1lll1ll11l_se_,l11llll1ll11l_se_ (u"ࠫ࡭ࡵࡳࡵࠩધ"):host})
    l1lllll1llll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"ࠬࡂࡴࡣࡱࡧࡽࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡢࡰࡦࡼࡂࠬન"),re.DOTALL).findall(content)
    if l1lllll1llll1ll11l_se_:
        l1lll1ll1lll1ll11l_se_=re.compile(l11llll1ll11l_se_ (u"࠭࠼ࡵࡴࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡶࡃ࠭઩"),re.DOTALL).findall(l1lllll1llll1ll11l_se_[0])
        for l1l1lll1ll11l_se_ in l1lll1ll1lll1ll11l_se_:
            l1llll1ll1ll1ll11l_se_=re.compile(l11llll1ll11l_se_ (u"ࠧ࠽ࡶࡧࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡩࡄࠧપ"),re.DOTALL).findall(l1l1lll1ll11l_se_)
            if len(l1llll1ll1ll1ll11l_se_)>5:
                l1llll11l1ll1ll11l_se_ = re.search(l11llll1ll11l_se_ (u"ࠨ࠱࡬ࡱࡦ࡭ࡥࡴ࠱࡯ࡥࡳ࡭ࡳ࠰ࠪ࠱࠮ࡄ࠯࠮ࡱࡰࡪࠦࡃ࠭ફ"),l1llll1ll1ll1ll11l_se_[0])
                l1llll11l1ll1ll11l_se_ = l1llll11l1ll1ll11l_se_.group(1) if l1llll11l1ll1ll11l_se_ else l11llll1ll11l_se_ (u"ࠩࠪબ")
                quality = l1llll1ll1ll1ll11l_se_[1].split(l11llll1ll11l_se_ (u"ࠪࡂࠬભ"))[-1]
                l111111llll1ll11l_se_ = re.search(l11llll1ll11l_se_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲࡭ࡲࡧࡧࡦࡵ࠲ࡷࡪࡸࡶࡦࡴࡶ࠳࠭࠴ࠪࡀࠫࠥࠫમ"),l1llll1ll1ll1ll11l_se_[2])
                l111111llll1ll11l_se_ = l111111llll1ll11l_se_.group(1).split(l11llll1ll11l_se_ (u"ࠬ࠴ࠧય"))[0] if l111111llll1ll11l_se_ else l11llll1ll11l_se_ (u"࠭࠿ࠨર")
                access = l1llll1ll1ll1ll11l_se_[4].split(l11llll1ll11l_se_ (u"ࠧ࠿ࠩ઱"))[-1].strip()
                l1ll1l1lll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠽ࠩલ")).findall(l1l1lll1ll11l_se_)
                if l1ll1l1lll1ll11l_se_:
                    l1ll1l1lll1ll11l_se_=urlparse.urljoin(l11l1l1llll1ll11l_se_,l1ll1l1lll1ll11l_se_[0])
                    host = l11llll1ll11l_se_ (u"ࠩ࡞ࠩࡸࡣࠠࠦࡵ࠯ࠤࠪࡹࠬࠡࠧࡶࠫળ")%(l111111llll1ll11l_se_,l1llll11l1ll1ll11l_se_,quality, access)
                    l11111111ll1ll11l_se_.append({l11llll1ll11l_se_ (u"ࠪ࡬ࡷ࡫ࡦࠨ઴"):l1ll1l1lll1ll11l_se_,l11llll1ll11l_se_ (u"ࠫ࡭ࡵࡳࡵࠩવ"):host})
    return l11111111ll1ll11l_se_
def l1l111llll1ll11l_se_(url):
    l1ll1l1lll1ll11l_se_=l11llll1ll11l_se_ (u"ࠬ࠭શ")
    content = l11l1llllll1ll11l_se_(url)
    l1llllll1lll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡩࡧࡴࡤࡱࡪࡄࠧષ"),re.DOTALL).findall(content)
    for l1lll1llllll1ll11l_se_ in l1llllll1lll1ll11l_se_:
        href = re.compile(l11llll1ll11l_se_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬસ")).findall(l1lll1llllll1ll11l_se_)
        if href:
            l1ll1l1lll1ll11l_se_=href[0]
            l1ll1l1lll1ll11l_se_ = l11llll1ll11l_se_ (u"ࠨࡪࡷࡸࡵ࠭હ")+l1ll1l1lll1ll11l_se_.split(l11llll1ll11l_se_ (u"ࠩ࡫ࡸࡹࡶࠧ઺"))[-1]
            if l11llll1ll11l_se_ (u"ࠪ࡫ࡷ࡫ࡥࡷ࡫ࡧ࠲ࡨࡵ࡭ࠨ઻") in l1ll1l1lll1ll11l_se_: l1ll1l1lll1ll11l_se_ = l1lllll11lll1ll11l_se_(l1ll1l1lll1ll11l_se_)
            if l11llll1ll11l_se_ (u"ࠫࡪࡨࡤ࠯ࡥࡧࡥ࠳ࡶ࡬ࠨ઼") in l1ll1l1lll1ll11l_se_: l1ll1l1lll1ll11l_se_ = l11llll1ll11l_se_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡦࡨࡦ࠴ࡰ࡭࠱ࡹ࡭ࡩ࡫࡯࠰ࠩઽ")+l1ll1l1lll1ll11l_se_.split(l11llll1ll11l_se_ (u"࠭࠯ࠨા"))[-1]
    if not l1ll1l1lll1ll11l_se_:
        l1ll1l1lll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"ࠧ࠽ࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡺࡲࡨࡁࡠࡢࠧࠣ࡟࠮ࡺ࡮ࡪࡥࡰ࠱ࡰࡴ࠹ࡡ࡜ࠨࠤࡠ࠯ࡃ࠭િ")).findall(content)
        l1ll1l1lll1ll11l_se_ = l1ll1l1lll1ll11l_se_[0] if l1ll1l1lll1ll11l_se_ else l11llll1ll11l_se_ (u"ࠨࠩી")
    return l1ll1l1lll1ll11l_se_
def l1lllll11lll1ll11l_se_(url):
    content = l11l1llllll1ll11l_se_(url)
    l1llllll1lll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠫ࠲࠯ࡅࠩ࠽࠱࡬ࡪࡷࡧ࡭ࡦࡀࠪુ"),re.DOTALL).findall(content)
    if l1llllll1lll1ll11l_se_:
        href = re.compile(l11llll1ll11l_se_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨૂ")).findall(l1llllll1lll1ll11l_se_[0])
        if href:
            href = l11llll1ll11l_se_ (u"ࠫ࡭ࡺࡴࡱࠩૃ")+href[0].split(l11llll1ll11l_se_ (u"ࠬ࡮ࡴࡵࡲࠪૄ"))[-1]
            return href
    return l11llll1ll11l_se_ (u"࠭ࠧૅ")
def l1l111l1ll1ll11l_se_(url=l11llll1ll11l_se_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵࡨ࡫ࡴࡹ࠮ࡦࡵ࠲ࡃࡵࡧࡧࡦ࠿ࡩ࡭ࡱࡳࡹࠨ૆")):
    cat=[]
    content = l11l1llllll1ll11l_se_(url)
    idx=content.find(l11llll1ll11l_se_ (u"ࠨ࠾࡫࠸ࡃࡑࡡࡵࡧࡪࡳࡷ࡯ࡥ࠽࠱࡫࠸ࡃ࠭ે"))
    if idx:
        cat = re.compile(l11llll1ll11l_se_ (u"ࠩ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠩૈ")).findall(content[idx:-1])
        if cat:
            cat = [(l11l1l1llll1ll11l_se_+x[0],x[1].strip()) for x in cat]
    return cat
def l1lllll111ll1ll11l_se_(url,l11ll1llll1ll11l_se_=1):
    content = l11l1llllll1ll11l_se_(url)
    ids = [(a.start(), a.end()) for a in re.finditer(l11llll1ll11l_se_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡰ࠲ࡲࡧ࠮࠳࠵ࠦࠥࡹࡴࡺ࡮ࡨࡁࠧࡶࡡࡥࡦ࡬ࡲ࡬ࡀ࠰ࠡ࠲ࠣ࠹ࡵࡾࠠ࠱࠽ࠥࡂࠬૉ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11111lllll1ll11l_se_ = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile(l11llll1ll11l_se_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࡷ࡫ࡨࡻ࠳࠰࠿ࠪࠤࠪ૊")).findall(l11111lllll1ll11l_se_)
        title = re.compile(l11llll1ll11l_se_ (u"ࠬࠨ࠾ࠩ࡞ࡺ࠯࠳࠰࠿ࠪ࠾࠲ࠫો")).findall(l11111lllll1ll11l_se_)
        l1llll111lll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"࠭࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩૌ")).findall(l11111lllll1ll11l_se_)
        l1llll111lll1ll11l_se_ = l1llll111lll1ll11l_se_[0] if l1llll111lll1ll11l_se_ else l11llll1ll11l_se_ (u"ࠧࠨ્")
        if l1llll111lll1ll11l_se_.startswith(l11llll1ll11l_se_ (u"ࠨࡪࡷࡸࡵ࠭૎")):
            l1llll111lll1ll11l_se_=l1llll111lll1ll11l_se_
        elif l1llll111lll1ll11l_se_.startswith(l11llll1ll11l_se_ (u"ࠩ࠱࠲࠴࠭૏")):
            l1llll111lll1ll11l_se_=l1llll111lll1ll11l_se_.replace(l11llll1ll11l_se_ (u"ࠪ࠲࠳࠭ૐ"),l11l1l1llll1ll11l_se_)
        elif l1llll111lll1ll11l_se_.startswith(l11llll1ll11l_se_ (u"ࠫࡴࡨࡲࡢࡼ࡮࡭ࠬ૑")):
            l1llll111lll1ll11l_se_=l11l1l1llll1ll11l_se_+l11llll1ll11l_se_ (u"ࠬ࠵ࠧ૒")+l1llll111lll1ll11l_se_
        elif l1llll111lll1ll11l_se_.startswith(l11llll1ll11l_se_ (u"࠭࠯ࡰࡤࡵࡥࡿࡱࡩࠨ૓")):
            l1llll111lll1ll11l_se_=l11l1l1llll1ll11l_se_+l1llll111lll1ll11l_se_
        if href and title and l1llll111lll1ll11l_se_:
            l1llll1ll11l_se_ = {l11llll1ll11l_se_ (u"ࠧࡶࡴ࡯ࠫ૔")   : l11l1l1llll1ll11l_se_+href[0],
                l11llll1ll11l_se_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ૕")  : l1lllll1l1ll1ll11l_se_(title[0]),
                l11llll1ll11l_se_ (u"ࠩࡳࡰࡴࡺࠧ૖")   : l11llll1ll11l_se_ (u"ࠪࠫ૗"),
                l11llll1ll11l_se_ (u"ࠫ࡮ࡳࡧࠨ૘")    : l1llll111lll1ll11l_se_,
                l11llll1ll11l_se_ (u"ࠬࡸࡡࡵ࡫ࡱ࡫ࠬ૙") : l11llll1ll11l_se_ (u"࠭ࠧ૚"),
                l11llll1ll11l_se_ (u"ࠧࡺࡧࡤࡶࠬ૛")   : l11llll1ll11l_se_ (u"ࠨࠩ૜"),
                l11llll1ll11l_se_ (u"ࠩࡦࡳࡩ࡫ࠧ૝")  : l11llll1ll11l_se_ (u"ࠪࠫ૞")
                    }
            out.append(l1llll1ll11l_se_)
    return out
def l1lllll1l1ll1ll11l_se_(l1111111lll1ll11l_se_):
    if type(l1111111lll1ll11l_se_) is not str:
        l1111111lll1ll11l_se_=l1111111lll1ll11l_se_.encode(l11llll1ll11l_se_ (u"ࠫࡺࡺࡦ࠮࠺ࠪ૟"))
    # txt = txt.replace('#038;','')
    # txt = txt.replace('&lt;br/&gt;',' ')
    # txt = txt.replace('&#34;','"')
    # txt = txt.replace('&#39;','\'').replace('&#039;','\'')
    # txt = txt.replace('&#8221;','"')
    # txt = txt.replace('&#8222;','"')
    # txt = txt.replace('&#8211;','-').replace('&ndash;','-')
    # txt = txt.replace('&quot;','"').replace('&amp;quot;','"')
    # txt = txt.replace('&oacute;','ó').replace('&Oacute;','Ó')
    # txt = txt.replace('&amp;oacute;','ó').replace('&amp;Oacute;','Ó')
    # txt = txt.replace('&amp;','&')
    l1111111lll1ll11l_se_ = l1111111lll1ll11l_se_.replace(l11llll1ll11l_se_ (u"ࠬࡢࡵ࠱࠳࠳࠹ࠬૠ"),l11llll1ll11l_se_ (u"࠭अࠨૡ")).replace(l11llll1ll11l_se_ (u"ࠧ࡝ࡷ࠳࠵࠵࠺ࠧૢ"),l11llll1ll11l_se_ (u"ࠨआࠪૣ"))
    l1111111lll1ll11l_se_ = l1111111lll1ll11l_se_.replace(l11llll1ll11l_se_ (u"ࠩ࡟ࡹ࠵࠷࠰࠸ࠩ૤"),l11llll1ll11l_se_ (u"ࠪऋࠬ૥")).replace(l11llll1ll11l_se_ (u"ࠫࡡࡻ࠰࠲࠲࠹ࠫ૦"),l11llll1ll11l_se_ (u"ࠬऌࠧ૧"))
    l1111111lll1ll11l_se_ = l1111111lll1ll11l_se_.replace(l11llll1ll11l_se_ (u"࠭࡜ࡶ࠲࠴࠵࠾࠭૨"),l11llll1ll11l_se_ (u"ࠧचࠩ૩")).replace(l11llll1ll11l_se_ (u"ࠨ࡞ࡸ࠴࠶࠷࠸ࠨ૪"),l11llll1ll11l_se_ (u"ࠩछࠫ૫"))
    l1111111lll1ll11l_se_ = l1111111lll1ll11l_se_.replace(l11llll1ll11l_se_ (u"ࠪࡠࡺ࠶࠱࠵࠴ࠪ૬"),l11llll1ll11l_se_ (u"ࠫे࠭૭")).replace(l11llll1ll11l_se_ (u"ࠬࡢࡵ࠱࠳࠷࠵ࠬ૮"),l11llll1ll11l_se_ (u"࠭ुࠨ૯"))
    l1111111lll1ll11l_se_ = l1111111lll1ll11l_se_.replace(l11llll1ll11l_se_ (u"ࠧ࡝ࡷ࠳࠵࠹࠺ࠧ૰"),l11llll1ll11l_se_ (u"ࠨॆࠪ૱")).replace(l11llll1ll11l_se_ (u"ࠩ࡟ࡹ࠵࠷࠴࠵ࠩ૲"),l11llll1ll11l_se_ (u"ࠪेࠬ૳"))
    l1111111lll1ll11l_se_ = l1111111lll1ll11l_se_.replace(l11llll1ll11l_se_ (u"ࠫࡡࡻ࠰࠱ࡨ࠶ࠫ૴"),l11llll1ll11l_se_ (u"ࣹࠬࠧ૵")).replace(l11llll1ll11l_se_ (u"࠭࡜ࡶ࠲࠳ࡨ࠸࠭૶"),l11llll1ll11l_se_ (u"ࠧࣔࠩ૷"))
    l1111111lll1ll11l_se_ = l1111111lll1ll11l_se_.replace(l11llll1ll11l_se_ (u"ࠨ࡞ࡸ࠴࠶࠻ࡢࠨ૸"),l11llll1ll11l_se_ (u"ࠩफ़ࠫૹ")).replace(l11llll1ll11l_se_ (u"ࠪࡠࡺ࠶࠱࠶ࡣࠪૺ"),l11llll1ll11l_se_ (u"ࠫय़࠭ૻ"))
    l1111111lll1ll11l_se_ = l1111111lll1ll11l_se_.replace(l11llll1ll11l_se_ (u"ࠬࡢࡵ࠱࠳࠺ࡥࠬૼ"),l11llll1ll11l_se_ (u"࠭ॺࠨ૽")).replace(l11llll1ll11l_se_ (u"ࠧ࡝ࡷ࠳࠵࠼࠿ࠧ૾"),l11llll1ll11l_se_ (u"ࠨॻࠪ૿"))
    l1111111lll1ll11l_se_ = l1111111lll1ll11l_se_.replace(l11llll1ll11l_se_ (u"ࠩ࡟ࡹ࠵࠷࠷ࡤࠩ଀"),l11llll1ll11l_se_ (u"ࠪঀࠬଁ")).replace(l11llll1ll11l_se_ (u"ࠫࡡࡻ࠰࠲࠹ࡥࠫଂ"),l11llll1ll11l_se_ (u"ࠬঁࠧଃ"))
    return l1111111lll1ll11l_se_
