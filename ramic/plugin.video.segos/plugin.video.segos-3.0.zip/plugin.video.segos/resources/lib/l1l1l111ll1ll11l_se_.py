# -*- coding: utf-8 -*-
import sys
l1ll1ll11l_se_ = sys.version_info [0] == 2
l1ll11ll1ll11l_se_ = 2048
l11l1ll1ll11l_se_ = 7
def l11llll1ll11l_se_ (llll1ll11l_se_):
	global l1ll1lll1ll11l_se_
	l111llll1ll11l_se_ = ord (llll1ll11l_se_ [-1])
	l1111ll1ll11l_se_ = llll1ll11l_se_ [:-1]
	l1l111ll1ll11l_se_ = l111llll1ll11l_se_ % len (l1111ll1ll11l_se_)
	l1l1ll1ll11l_se_ = l1111ll1ll11l_se_ [:l1l111ll1ll11l_se_] + l1111ll1ll11l_se_ [l1l111ll1ll11l_se_:]
	if l1ll1ll11l_se_:
		l1l1l1ll1ll11l_se_ = unicode () .join ([unichr (ord (char) - l1ll11ll1ll11l_se_ - (l1l11ll1ll11l_se_ + l111llll1ll11l_se_) % l11l1ll1ll11l_se_) for l1l11ll1ll11l_se_, char in enumerate (l1l1ll1ll11l_se_)])
	else:
		l1l1l1ll1ll11l_se_ = str () .join ([chr (ord (char) - l1ll11ll1ll11l_se_ - (l1l11ll1ll11l_se_ + l111llll1ll11l_se_) % l11l1ll1ll11l_se_) for l1l11ll1ll11l_se_, char in enumerate (l1l1ll1ll11l_se_)])
	return eval (l1l1l1ll1ll11l_se_)
import urllib2,urllib
import re,random,json
import cookielib
l11ll1111ll1ll11l_se_=10
l1111l111ll1ll11l_se_=l11llll1ll11l_se_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭৴")
def l11l1llllll1ll11l_se_(url,data=None,header={},l1111ll11ll1ll11l_se_=True):
    l1111l1l1ll1ll11l_se_=l11llll1ll11l_se_ (u"ࠨࠩ৵")
    l1111lll1ll1ll11l_se_=[]
    if l1111ll11ll1ll11l_se_:
        l1111lll1ll1ll11l_se_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1111lll1ll1ll11l_se_))
        urllib2.install_opener(opener)
    if not header:
        header = {l11llll1ll11l_se_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭৶"):l1111l111ll1ll11l_se_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l11ll1111ll1ll11l_se_)
        l1ll1l1lll1ll11l_se_ =  response.read()
        response.close()
        l1111l1l1ll1ll11l_se_ = l11llll1ll11l_se_ (u"ࠪࠫ৷").join([l11llll1ll11l_se_ (u"ࠫࠪࡹ࠽ࠦࡵ࠾ࠫ৸")%(c.name, c.value) for c in l1111lll1ll1ll11l_se_])
    except urllib2.HTTPError as e:
        l1ll1l1lll1ll11l_se_ = l11llll1ll11l_se_ (u"ࠬ࠭৹")
    return l1ll1l1lll1ll11l_se_,l1111l1l1ll1ll11l_se_
def l1ll1111ll1ll11l_se_(url):
    url = url.replace(l11llll1ll11l_se_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ৺"),l11llll1ll11l_se_ (u"ࠧࡩࡶࡷࡴࡸࡀࠧ৻")).replace(l11llll1ll11l_se_ (u"ࠨ࠱ࡨࡱࡧ࡫ࡤ࠰ࠩৼ"),l11llll1ll11l_se_ (u"ࠩ࠲ࡃࡻࡃࠧ৽"))
    content,c = l11l1llllll1ll11l_se_(url)
    match = re.findall(l11llll1ll11l_se_ (u"ࠪࠫࠬࡡࠢࠨ࡟ࡂࡷࡴࡻࡲࡤࡧࡶ࡟ࠬࠨ࡝ࡀ࡞ࡶ࠮࠿ࡢࡳࠫࠪ࡟࡟࠳࠰࠿࡝࡟ࠬࠫࠬ࠭৾"), content)
    l1111ll1lll1ll11l_se_=l11llll1ll11l_se_ (u"ࠫࠬ৿")
    if not match:
        data = {}
        data[l11llll1ll11l_se_ (u"ࠬࡩ࡯࡯ࡨ࡬ࡶࡲ࠴ࡹࠨ਀")] = random.randint(0, 120)
        data[l11llll1ll11l_se_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࠮ࡹࠩਁ")] = random.randint(0, 120)
        header={l11llll1ll11l_se_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫਂ"):l1111l111ll1ll11l_se_,l11llll1ll11l_se_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩਃ"):url}
        l1111l1llll1ll11l_se_ = url + l11llll1ll11l_se_ (u"ࠩࠦࠫ਄")
        content,c = l11l1llllll1ll11l_se_(l1111l1llll1ll11l_se_,urllib.urlencode(data),header=header)
        match = re.findall(l11llll1ll11l_se_ (u"ࠪࠫࠬࡡࠢࠨ࡟ࡂࡷࡴࡻࡲࡤࡧࡶ࡟ࠬࠨ࡝ࡀ࡞ࡶ࠮࠿ࡢࡳࠫࠪ࡟࡟࠳࠰࠿࡝࡟ࠬࠫࠬ࠭ਅ"), content)
    if match:
        print match
        try:
            data = json.loads(match[0])
            l1111ll1lll1ll11l_se_=[]
            for d in data:
                if isinstance(d,dict):
                    l1111l11lll1ll11l_se_ = d.get(l11llll1ll11l_se_ (u"ࠫ࡫࡯࡬ࡦࠩਆ"),l11llll1ll11l_se_ (u"ࠬ࠭ਇ"))+l11llll1ll11l_se_ (u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠪࡹࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠧࡶࠫਈ")%(l1111l111ll1ll11l_se_,url)
                    l1111ll1lll1ll11l_se_.append((d.get(l11llll1ll11l_se_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭ਉ"),l11llll1ll11l_se_ (u"ࠨࠩਊ")),l1111l11lll1ll11l_se_))
        except:
            l1111ll1lll1ll11l_se_ = re.findall(l11llll1ll11l_se_ (u"ࠩࠪࠫࡠ࠭ࠢ࡞ࡁࡩ࡭ࡱ࡫࡛ࠨࠤࡠࡃࡡࡹࠪ࠻࡞ࡶ࠮ࡠ࠭ࠢ࡞ࡁࠫ࡟ࡣ࠭ࠢ࡞࠭ࠬࠫࠬ࠭਋"), match[0])
            if l1111ll1lll1ll11l_se_:
                l1111ll1lll1ll11l_se_ = l1111ll1lll1ll11l_se_[0].replace(l11llll1ll11l_se_ (u"ࠪࡠ࠴࠭਌"), l11llll1ll11l_se_ (u"ࠫ࠴࠭਍"))
                l1111ll1lll1ll11l_se_ += l11llll1ll11l_se_ (u"ࠬࢂࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠩࡸࠬࡒࡦࡨࡨࡶࡪࡸ࠽ࠦࡵࠪ਎")%(l1111l111ll1ll11l_se_,url)
    return l1111ll1lll1ll11l_se_
