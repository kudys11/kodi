# -*- coding: utf-8 -*-
import sys
l1ll1ll11l_se_ = sys.version_info [0] == 2
l1ll11ll1ll11l_se_ = 2048
l11l1ll1ll11l_se_ = 7
def l11llll1ll11l_se_ (llll1ll11l_se_):
	global l1ll1lll1ll11l_se_
	l111llll1ll11l_se_ = ord (llll1ll11l_se_ [-1])
	l1111ll1ll11l_se_ = llll1ll11l_se_ [:-1]
	l1l111ll1ll11l_se_ = l111llll1ll11l_se_ % len (l1111ll1ll11l_se_)
	l1l1ll1ll11l_se_ = l1111ll1ll11l_se_ [:l1l111ll1ll11l_se_] + l1111ll1ll11l_se_ [l1l111ll1ll11l_se_:]
	if l1ll1ll11l_se_:
		l1l1l1ll1ll11l_se_ = unicode () .join ([unichr (ord (char) - l1ll11ll1ll11l_se_ - (l1l11ll1ll11l_se_ + l111llll1ll11l_se_) % l11l1ll1ll11l_se_) for l1l11ll1ll11l_se_, char in enumerate (l1l1ll1ll11l_se_)])
	else:
		l1l1l1ll1ll11l_se_ = str () .join ([chr (ord (char) - l1ll11ll1ll11l_se_ - (l1l11ll1ll11l_se_ + l111llll1ll11l_se_) % l11l1ll1ll11l_se_) for l1l11ll1ll11l_se_, char in enumerate (l1l1ll1ll11l_se_)])
	return eval (l1l1l1ll1ll11l_se_)
l11llll1ll11l_se_ (u"ࠢࠣࠤࠐࠎࡈࡸࡥࡢࡶࡨࡨࠥࡵ࡮ࠡࡖ࡫ࡹࠥࡌࡥࡣࠢ࠴࠵ࠥ࠷࠸࠻࠶࠺࠾࠹࠹ࠠ࠳࠲࠴࠺ࠒࠐࠍࠋࡂࡤࡹࡹ࡮࡯ࡳ࠼ࠣࡶࡦࡳࡩࡤࠏࠍࠦࠧࠨ঵")
import urllib2
import re
import l11l1ll1lll1ll11l_se_ as l11l1ll1lll1ll11l_se_
l11l1l1llll1ll11l_se_=l11llll1ll11l_se_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡩࡤࡢ࠰ࡳࡰࠬশ")
l11ll1111ll1ll11l_se_ = 5
def l11l1llllll1ll11l_se_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l11llll1ll11l_se_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ষ"), l11llll1ll11l_se_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡏࡘ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠷࠼࠳࠶࠮࠳࠷࠹࠸࠳࠿࠷ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨস"))
    if cookies:
        req.add_header(l11llll1ll11l_se_ (u"ࠦࡈࡵ࡯࡬࡫ࡨࠦহ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11ll1111ll1ll11l_se_)
        l1ll1l1lll1ll11l_se_ =  response.read()
        response.close()
    except:
        l1ll1l1lll1ll11l_se_=l11llll1ll11l_se_ (u"ࠬ࠭঺")
    return l1ll1l1lll1ll11l_se_
def _11ll111lll1ll11l_se_(content):
    src =l11llll1ll11l_se_ (u"࠭ࠧ঻")
    l11l11ll1ll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"ࠢࡦࡸࡤࡰ࠭࠴ࠪࡀࠫ࡟ࡿࡡࢃ࡜ࠪ࡞়ࠬࠦ"),re.DOTALL).findall(content)
    for l11l11l1lll1ll11l_se_ in l11l11ll1ll1ll11l_se_:
        l11l11l1lll1ll11l_se_=re.sub(l11llll1ll11l_se_ (u"ࠨࠢࠣࠫঽ"),l11llll1ll11l_se_ (u"ࠩࠣࠫা"),l11l11l1lll1ll11l_se_)
        l11l11l1lll1ll11l_se_=re.sub(l11llll1ll11l_se_ (u"ࠪࡠࡳ࠭ি"),l11llll1ll11l_se_ (u"ࠫࠬী"),l11l11l1lll1ll11l_se_)
        try:
            l11l111l1ll1ll11l_se_ = l11l1ll1lll1ll11l_se_.unpack(l11l11l1lll1ll11l_se_)
        except:
            l11l111l1ll1ll11l_se_=l11llll1ll11l_se_ (u"ࠬ࠭ু")
        if l11l111l1ll1ll11l_se_:
            l11l111l1ll1ll11l_se_=re.sub(l11llll1ll11l_se_ (u"ࡸࠧ࡝࡞ࠪূ"),l11llll1ll11l_se_ (u"ࡲࠨࠩৃ"),l11l111l1ll1ll11l_se_)
            l11l11lllll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"ࠨ࡝ࠥࡠࠬࡣࠪࡧ࡫࡯ࡩࡠࠨ࡜ࠨ࡟࠭ࡠࡸ࠰࠺࡝ࡵ࠭࡟ࠧࡢࠧ࡞ࠪ࠱࠯ࡄ࠯࡛ࠣ࡞ࠪࡡ࠱࠭ৄ"),  re.DOTALL).search(content)
            l11l1l1l1ll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"ࠩ࡞ࠦࡡ࠭࡝ࡧ࡫࡯ࡩࡠࠨ࡜ࠨ࡟࠽࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄࡢ࠮࡮ࡲ࠷࠭ࡠࠨ࡜ࠨ࡟ࠪ৅"),  re.DOTALL).search(content)
            l11l1l11lll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"ࠪ࡟ࠧࡢࠧ࡞ࠬࠫ࠲࠯ࡅ࡜࠯࡯ࡳ࠸࠮ࡡࠢ࡝ࠩࡠ࠮ࠬ৆"),  re.DOTALL).search(content)
            if l11l11lllll1ll11l_se_:   src = l11l11lllll1ll11l_se_.group(1)
            elif l11l1l1l1ll1ll11l_se_: src = l11l1l1l1ll1ll11l_se_.group(1)
            elif l11l1l11lll1ll11l_se_: src = l11l1l11lll1ll11l_se_.group(1)
            if src:
                break
    return src
def l11l1lll1ll1ll11l_se_(content):
    l11llll1ll11l_se_ (u"ࠦࠧࠨࠍࠋࠢࠣࠤ࡙ࠥࡣࡢࡰࡶࠤ࡫ࡵࡲࠡࡸ࡬ࡨࡪࡵࠠ࡭࡫ࡱ࡯ࠥ࡯࡮ࡤ࡮ࡸࡨࡪࡪࠠࡦࡰࡦࡳࡩ࡫ࡤࠡࡱࡱࡩࠒࠐࠠࠡࠢࠣࠦࠧࠨে")
    l11l11l11ll1ll11l_se_=l11llll1ll11l_se_ (u"ࠬ࠭ৈ")
    l11l11lllll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"࡛࠭ࠣ࡞ࠪࡡ࠯࡬ࡩ࡭ࡧ࡞ࠦࡡ࠭࡝ࠫ࡞ࡶ࠮࠿ࡢࡳࠫ࡝ࠥࡠࠬࡣࠨ࠯࠭ࡂ࠭ࡠࠨ࡜ࠨ࡟࠯ࠫ৉"),  re.DOTALL).search(content)
    l11l1l1l1ll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"ࠧ࡜ࠤ࡟ࠫࡢ࡬ࡩ࡭ࡧ࡞ࠦࡡ࠭࡝࠻࡝ࠥࡠࠬࡣࠨ࠯ࠬࡂࡠ࠳ࡳࡰ࠵ࠫ࡞ࠦࡡ࠭࡝ࠨ৊"),  re.DOTALL).search(content)
    l11l1l11lll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"ࠨ࡝ࠥࡠࠬࡣࠪࠩ࠰࠭ࡃࡡ࠴࡭ࡱ࠶ࠬ࡟ࠧࡢࠧ࡞ࠬࠪো"),  re.DOTALL).search(content)
    if l11l11lllll1ll11l_se_:
        print l11llll1ll11l_se_ (u"ࠩࡩࡳࡺࡴࡤࠡࡔࡈࠤࡠ࡬ࡩ࡭ࡧ࠽ࡡࠬৌ")
        l11l11l11ll1ll11l_se_ = l11l11lllll1ll11l_se_.group(1)
    elif l11l1l1l1ll1ll11l_se_:
        print l11llll1ll11l_se_ (u"ࠪࡪࡴࡻ࡮ࡥࠢࡕࡉࠥࡡࡵࡳ࡮࠽ࡡ্ࠬ")
        l11l11l11ll1ll11l_se_ = l11l1l1l1ll1ll11l_se_.group(1)
    elif l11l1l11lll1ll11l_se_:
        print l11llll1ll11l_se_ (u"ࠫ࡫ࡵࡵ࡯ࡦࠣࡖࡊ࡛ࠦࡶࡴ࡯࠾ࡢ࠭ৎ")
        l11l11l11ll1ll11l_se_ = l11l1l11lll1ll11l_se_.group(1)
    else:
        print l11llll1ll11l_se_ (u"ࠬ࡫࡮ࡤࡱࡧࡩࡩࠦ࠺ࠡࡷࡱࡴࡦࡩ࡫ࡦࡴࠪ৏")
        l11l11l11ll1ll11l_se_ = _11ll111lll1ll11l_se_(content)
    return l11l11l11ll1ll11l_se_
def l1ll1111ll1ll11l_se_(url):
    l11llll1ll11l_se_ (u"ࠨࠢࠣࠏࠍࠤࠥࠦࠠࡳࡧࡷࡹࡷࡴࡳࠡࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠲ࠦࡵ࡭ࡴࠣ࡬ࡹࡺࡰ࠻࠱࠲࠲࠳࠴࠮ࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠱ࠥࡵࡲࠡ࡮࡬ࡷࡹࠦ࡯ࡧࠢ࡞ࠬࠬ࠽࠲࠱ࡲࠪ࠰ࠥ࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡧࡩࡧ࠮ࡱ࡮࠲ࡺ࡮ࡪࡥࡰ࠱࠴࠽࠹࠼࠹࠺࠳ࡩࡃࡼ࡫ࡲࡴ࡬ࡤࡁ࠼࠸࠰ࡱࠩࠬ࠰࠳࠴࠮࡞ࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠓࠊࠡࠢࠣࠤࠧࠨࠢ৐")
    l11l1l111ll1ll11l_se_=l11llll1ll11l_se_ (u"ࠧࡽࡅࡲࡳࡰ࡯ࡥ࠾ࡒࡋࡔࡘࡋࡓࡔࡋࡇࡁ࠶ࠬࡒࡦࡨࡨࡶࡪࡸ࠽ࡩࡶࡷࡴ࠿࠵࠯ࡴࡶࡤࡸ࡮ࡩ࠮ࡤࡦࡤ࠲ࡵࡲ࠯ࡧ࡮ࡲࡻࡵࡲࡡࡺࡧࡵ࠳࡫ࡲࡡࡴࡪ࠲ࡪࡱࡵࡷࡱ࡮ࡤࡽࡪࡸ࠮ࡤࡱࡰࡱࡪࡸࡣࡪࡣ࡯࠱࠸࠴࠲࠯࠳࠻࠲ࡸࡽࡦࠨ৑")
    content = l11l1llllll1ll11l_se_(url)
    src=[]
    if not l11llll1ll11l_se_ (u"ࠨࡁࡺࡩࡷࡹࡪࡢࠩ৒") in url:
         l11l111llll1ll11l_se_ = re.compile(l11llll1ll11l_se_ (u"ࠩ࠿ࡥࠥࡪࡡࡵࡣ࠰ࡵࡺࡧ࡬ࡪࡶࡼࡁࠧ࠮࠮ࠫࡁࠬࠦࠥ࠮࠿ࡑ࠾ࡋࡂ࠳࠰࠿ࠪࡀࠫࡃࡕࡂࡑ࠿࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ৓"), re.DOTALL).findall(content)
         for quality in l11l111llll1ll11l_se_:
             l1ll1l1lll1ll11l_se_ = re.search(l11llll1ll11l_se_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ৔"),quality[1])
             l11l1111lll1ll11l_se_ = quality[2]
             src.insert(0,(l11l1111lll1ll11l_se_,l11l1l1llll1ll11l_se_+l1ll1l1lll1ll11l_se_.group(1)))
    if not src:
        src = l11l1lll1ll1ll11l_se_(content)
        if src:
            src+=l11l1l111ll1ll11l_se_
    return src
def l11l1ll11ll1ll11l_se_(url,quality=0):
    l11llll1ll11l_se_ (u"ࠦࠧࠨࠍࠋࠢࠣࠤࠥࡸࡥࡵࡷࡵࡲࡸࠦࡵࡳ࡮ࠣࡸࡴࠦࡶࡪࡦࡨࡳࠒࠐࠠࠡࠢࠣࠦࠧࠨ৕")
    src = l1ll1111ll1ll11l_se_(url)
    if type(src)==list:
        selected=src[quality]
        print l11llll1ll11l_se_ (u"ࠬࡗࡵࡢ࡮࡬ࡸࡾࠦ࠺ࠨ৖"),selected[0]
        src = l1ll1111ll1ll11l_se_(selected[1])
    return src
