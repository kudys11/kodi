# -*- coding: utf-8 -*-
import sys
l1ll1ll11l_se_ = sys.version_info [0] == 2
l1ll11ll1ll11l_se_ = 2048
l11l1ll1ll11l_se_ = 7
def l11llll1ll11l_se_ (llll1ll11l_se_):
	global l1ll1lll1ll11l_se_
	l111llll1ll11l_se_ = ord (llll1ll11l_se_ [-1])
	l1111ll1ll11l_se_ = llll1ll11l_se_ [:-1]
	l1l111ll1ll11l_se_ = l111llll1ll11l_se_ % len (l1111ll1ll11l_se_)
	l1l1ll1ll11l_se_ = l1111ll1ll11l_se_ [:l1l111ll1ll11l_se_] + l1111ll1ll11l_se_ [l1l111ll1ll11l_se_:]
	if l1ll1ll11l_se_:
		l1l1l1ll1ll11l_se_ = unicode () .join ([unichr (ord (char) - l1ll11ll1ll11l_se_ - (l1l11ll1ll11l_se_ + l111llll1ll11l_se_) % l11l1ll1ll11l_se_) for l1l11ll1ll11l_se_, char in enumerate (l1l1ll1ll11l_se_)])
	else:
		l1l1l1ll1ll11l_se_ = str () .join ([chr (ord (char) - l1ll11ll1ll11l_se_ - (l1l11ll1ll11l_se_ + l111llll1ll11l_se_) % l11l1ll1ll11l_se_) for l1l11ll1ll11l_se_, char in enumerate (l1l1ll1ll11l_se_)])
	return eval (l1l1l1ll1ll11l_se_)
import xbmc,xbmcgui
import time,re,os,threading
try: from shutil import rmtree
except: rmtree = False
def _11l1lll1ll11l_se_(l1l1llll1ll11l_se_):
    debug=1
def l1lll1ll11l_se_(l1111lll1ll11l_se_,l111ll1ll11l_se_=[l11llll1ll11l_se_ (u"ࠪࠫࠍ")]):
    debug=1
def l1lll1ll1ll11l_se_(name=l11llll1ll11l_se_ (u"ࠫࠬࠎ")):
    debug=1
def l1lllll1ll11l_se_(top):
    debug=1
def l111l1ll1ll11l_se_():
    debug=1
try:
    debug=1
except: pass
