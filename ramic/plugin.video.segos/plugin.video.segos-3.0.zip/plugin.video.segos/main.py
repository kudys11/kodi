# -*- coding: utf-8 -*-
import sys
l1ll1ll11l_se_ = sys.version_info [0] == 2
l1ll11ll1ll11l_se_ = 2048
l11l1ll1ll11l_se_ = 7
def l11llll1ll11l_se_ (llll1ll11l_se_):
	global l1ll1lll1ll11l_se_
	l111llll1ll11l_se_ = ord (llll1ll11l_se_ [-1])
	l1111ll1ll11l_se_ = llll1ll11l_se_ [:-1]
	l1l111ll1ll11l_se_ = l111llll1ll11l_se_ % len (l1111ll1ll11l_se_)
	l1l1ll1ll11l_se_ = l1111ll1ll11l_se_ [:l1l111ll1ll11l_se_] + l1111ll1ll11l_se_ [l1l111ll1ll11l_se_:]
	if l1ll1ll11l_se_:
		l1l1l1ll1ll11l_se_ = unicode () .join ([unichr (ord (char) - l1ll11ll1ll11l_se_ - (l1l11ll1ll11l_se_ + l111llll1ll11l_se_) % l11l1ll1ll11l_se_) for l1l11ll1ll11l_se_, char in enumerate (l1l1ll1ll11l_se_)])
	else:
		l1l1l1ll1ll11l_se_ = str () .join ([chr (ord (char) - l1ll11ll1ll11l_se_ - (l1l11ll1ll11l_se_ + l111llll1ll11l_se_) % l11l1ll1ll11l_se_) for l1l11ll1ll11l_se_, char in enumerate (l1l1ll1ll11l_se_)])
	return eval (l1l1l1ll1ll11l_se_)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import check as check
import urlresolver
try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
cache = StorageServer.StorageServer(l11llll1ll11l_se_ (u"ࠤࡶࡩ࡬ࡵࡳࠣ࠶"))
import resources.lib.l111l11ll1ll11l_se_ as l111l11ll1ll11l_se_
import resources.lib.l1llll11ll1ll11l_se_ as l1llll11ll1ll11l_se_
import resources.lib.l1llll1ll1ll11l_se_ as l11ll1lll1ll11l_se_
import ramic as l1l11l1ll1ll11l_se_
l11l11lll1ll11l_se_        = sys.argv[0]
l1l1llll1ll11l_se_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l1l11111ll1ll11l_se_        = xbmcaddon.Addon()
l1ll1lllll1ll11l_se_     = l1l11111ll1ll11l_se_.getAddonInfo(l11llll1ll11l_se_ (u"ࠪ࡭ࡩ࠭࠷"))
l1l1l1lll1ll11l_se_       = l1l11111ll1ll11l_se_.getAddonInfo(l11llll1ll11l_se_ (u"ࠫࡳࡧ࡭ࡦࠩ࠸"))
PATH        = l1l11111ll1ll11l_se_.getAddonInfo(l11llll1ll11l_se_ (u"ࠬࡶࡡࡵࡪࠪ࠹"))
l1ll111ll1ll11l_se_    = xbmc.translatePath(l1l11111ll1ll11l_se_.getAddonInfo(l11llll1ll11l_se_ (u"࠭ࡰࡳࡱࡩ࡭ࡱ࡫ࠧ࠺"))).decode(l11llll1ll11l_se_ (u"ࠧࡶࡶࡩ࠱࠽࠭࠻"))
l1111llll1ll11l_se_   = PATH+l11llll1ll11l_se_ (u"ࠨ࠱ࡵࡩࡸࡵࡵࡳࡥࡨࡷ࠴࠭࠼")
l1l1l1l1ll1ll11l_se_      = None

def l1l11lllll1ll11l_se_(name, url, mode, l11ll1llll1ll11l_se_=1, l11llllll1ll11l_se_=None, infoLabels=False, IsPlayable=True,fanart=l1l1l1l1ll1ll11l_se_,l111111ll1ll11l_se_=1):
    u = l1ll11l1ll1ll11l_se_({l11llll1ll11l_se_ (u"ࠪࡱࡴࡪࡥࠨࡅ"): mode, l11llll1ll11l_se_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨࡆ"): name, l11llll1ll11l_se_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭ࡇ") : url, l11llll1ll11l_se_ (u"࠭ࡰࡢࡩࡨࠫࡈ"):l11ll1llll1ll11l_se_})
    if l11llllll1ll11l_se_==None:
        l11llllll1ll11l_se_=l11llll1ll11l_se_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫࡉ")
    l111lll1ll11l_se_ = xbmcgui.ListItem(name, iconImage=l11llllll1ll11l_se_, thumbnailImage=l11llllll1ll11l_se_)
    l111lll1ll11l_se_.setArt({ l11llll1ll11l_se_ (u"ࠨࡲࡲࡷࡹ࡫ࡲࠨࡊ"): l11llllll1ll11l_se_, l11llll1ll11l_se_ (u"ࠩࡷ࡬ࡺࡳࡢࠨࡋ") : l11llllll1ll11l_se_, l11llll1ll11l_se_ (u"ࠪ࡭ࡨࡵ࡮ࠨࡌ") : l11llllll1ll11l_se_ ,l11llll1ll11l_se_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫࡍ"):fanart,l11llll1ll11l_se_ (u"ࠬࡨࡡ࡯ࡰࡨࡶࠬࡎ"):l11llllll1ll11l_se_})
    if not infoLabels:
        infoLabels={l11llll1ll11l_se_ (u"ࠨࡴࡪࡶ࡯ࡩࠧࡏ"): name}
    l111lll1ll11l_se_.setInfo(type=l11llll1ll11l_se_ (u"ࠢࡷ࡫ࡧࡩࡴࠨࡐ"), infoLabels=infoLabels)
    if IsPlayable:
        l111lll1ll11l_se_.setProperty(l11llll1ll11l_se_ (u"ࠨࡋࡶࡔࡱࡧࡹࡢࡤ࡯ࡩࠬࡑ"), l11llll1ll11l_se_ (u"ࠩࡷࡶࡺ࡫ࠧࡒ"))
    if fanart:
        l111lll1ll11l_se_.setProperty(l11llll1ll11l_se_ (u"ࠪࡪࡦࡴࡡࡳࡶࡢ࡭ࡲࡧࡧࡦࠩࡓ"),fanart)
    l1l11ll1ll1ll11l_se_ = []
    if infoLabels.get(l11llll1ll11l_se_ (u"ࠫࡹࡸࡡࡪ࡮ࡨࡶࠬࡔ"),l11llll1ll11l_se_ (u"ࠬ࠭ࡕ")):
        l1l11ll1ll1ll11l_se_.append((l11llll1ll11l_se_ (u"࡚࠭ࡸ࡫ࡤࡷࡹࡻ࡮ࠨࡖ"), l11llll1ll11l_se_ (u"ࠧࡓࡷࡱࡔࡱࡻࡧࡪࡰࠫࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳࡀ࡯ࡲࡨࡪࡃࡺࡸ࡫ࡤࡷࡹࡻ࡮ࠧࡧࡻࡣࡱ࡯࡮࡬࠿ࠨࡷ࠮࠭ࡗ")%(l1ll1lllll1ll11l_se_,infoLabels.get(l11llll1ll11l_se_ (u"ࠨࡶࡵࡥ࡮ࡲࡥࡳࠩࡘ")))))
    l111lll1ll11l_se_.addContextMenuItems(l1l11ll1ll1ll11l_se_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l1l1llll1ll11l_se_, url=u, listitem=l111lll1ll11l_se_,isFolder=False,totalItems=l111111ll1ll11l_se_)
    xbmcplugin.addSortMethod(l1l1llll1ll11l_se_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l11llll1ll11l_se_ (u"ࠤࠨࡖ࠱࡚ࠦࠥ࠮ࠣࠩࡕࠨ࡙"))
    return ok
def l111ll1ll1ll11l_se_(name,ex_link=None, l11ll1llll1ll11l_se_=0, mode=l11llll1ll11l_se_ (u"ࠪࡪࡴࡲࡤࡦࡴ࡚ࠪ"),iconImage=l11llll1ll11l_se_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠨ࡛"), infoLabels=None, fanart=l1l1l1l1ll1ll11l_se_,contextmenu=None,l111111ll1ll11l_se_=1):
    url = l1ll11l1ll1ll11l_se_({l11llll1ll11l_se_ (u"ࠬࡳ࡯ࡥࡧࠪ࡜"): mode, l11llll1ll11l_se_ (u"࠭ࡦࡰ࡮ࡧࡩࡷࡴࡡ࡮ࡧࠪ࡝"): name, l11llll1ll11l_se_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨ࡞") : ex_link, l11llll1ll11l_se_ (u"ࠨࡲࡤ࡫ࡪ࠭࡟") : l11ll1llll1ll11l_se_})
    l111lllll1ll11l_se_ = xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconImage)
    if infoLabels:
        l111lllll1ll11l_se_.setInfo(type=l11llll1ll11l_se_ (u"ࠤࡰࡳࡻ࡯ࡥࠣࡠ"), infoLabels=infoLabels)
    if fanart:
        l111lllll1ll11l_se_.setProperty(l11llll1ll11l_se_ (u"ࠪࡪࡦࡴࡡࡳࡶࡢ࡭ࡲࡧࡧࡦࠩࡡ"), fanart )
    if contextmenu:
        l1l11ll1ll1ll11l_se_=contextmenu
        l111lllll1ll11l_se_.addContextMenuItems(l1l11ll1ll1ll11l_se_, replaceItems=True)
    else:
        l1l11ll1ll1ll11l_se_ = []
        l1l11ll1ll1ll11l_se_.append((l11llll1ll11l_se_ (u"ࠫࡎࡴࡦࡰࡴࡰࡥࡨࡰࡡࠨࡢ"), l11llll1ll11l_se_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡅࡨࡺࡩࡰࡰࠫࡍࡳ࡬࡯ࠪࠩࡣ")),)
        l111lllll1ll11l_se_.addContextMenuItems(l1l11ll1ll1ll11l_se_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l1l1llll1ll11l_se_, url=url,listitem=l111lllll1ll11l_se_, isFolder=True,totalItems=l111111ll1ll11l_se_)
    xbmcplugin.addSortMethod(l1l1llll1ll11l_se_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l11llll1ll11l_se_ (u"ࠨࠥࡑࠤࡤ"))
    return ok
import time,threading
try: from shutil import rmtree
except: rmtree = False
def l1lll1ll11l_se_(l1111lll1ll11l_se_,l111ll1ll11l_se_=[l11llll1ll11l_se_ (u"ࠧࠨࡥ")]):
    debug=1
def l1lll1ll1ll11l_se_(name=l11llll1ll11l_se_ (u"ࠨࠩࡦ")):
    debug=1
def l1lllll1ll11l_se_(top):
    debug=1
def l111l1ll1ll11l_se_():
    l1111lll1ll11l_se_ = os.path.join(xbmc.translatePath(l11llll1ll11l_se_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭ࡱ")),l11llll1ll11l_se_ (u"࠭ࡡࡥࡦࡲࡲࡸ࠭ࡲ"))
    xbmc.log(l1111lll1ll11l_se_)
    if l1lll1ll11l_se_(l1111lll1ll11l_se_,[l11llll1ll11l_se_ (u"ࠧࡢ࡮࡬ࡩࡳࡽࡩࡻࡣࡵࡨࠬࡳ"),l11llll1ll11l_se_ (u"ࠨࡧࡻࡸࡪࡴࡤࡦࡴ࠱ࡥࡱ࡯ࡥ࡯ࠩࡴ")])>0:
        l1lll1ll1ll11l_se_(l11llll1ll11l_se_ (u"ࠩࡺ࡭ࡿࡧࡲࡥࠩࡵ"))
        return
    l11l11ll1ll11l_se_ = os.path.join(xbmc.translatePath(l11llll1ll11l_se_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡵࡴࡧࡵࡨࡦࡺࡡࠨࡶ")),l11llll1ll11l_se_ (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨࡷ"),l11llll1ll11l_se_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡥࡪࡵ࡮࠯ࡰࡲࡼ࠳࠻ࠧࡸ"),l11llll1ll11l_se_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬࡹ"))
    if os.path.exists(l11l11ll1ll11l_se_):
        data = open(l11l11ll1ll11l_se_,l11llll1ll11l_se_ (u"ࠧࡳࠩࡺ")).read()
        data= re.sub(l11llll1ll11l_se_ (u"ࠨ࡞࡞࠲࠯ࡢ࡝ࠨࡻ"),l11llll1ll11l_se_ (u"ࠩࠪࡼ"),data)
        if len(re.compile(l11llll1ll11l_se_ (u"ࠪࡂ࠳࠰ࠨࡱࡱ࡯ࡷࡰࡧ࡜ࡴࠬࡷࡠࡸ࠰ࡶࠪࠩࡽ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1lll1ll1ll11l_se_(l11llll1ll11l_se_ (u"ࠫࡸࡱࡩ࡯࠰ࡤࡩࡴࡴ࠮࡯ࡱࡻ࠲࠺࠭ࡾ"))
            return
        if len(re.compile(l11llll1ll11l_se_ (u"ࠬࡄ࠮ࠫࠪࡧࡥࡷࡳ࡯ࡸࡣ࡟ࡷ࠯ࡺ࡜ࡴࠬࡹ࠭ࠬࡿ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1lll1ll1ll11l_se_(l11llll1ll11l_se_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡦ࡫࡯࡯࠰ࡱࡳࡽ࠴࠵ࠨࢀ"))
            return
    l11l11ll1ll11l_se_ = os.path.join(xbmc.translatePath(l11llll1ll11l_se_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡹࡸ࡫ࡲࡥࡣࡷࡥࠬࢁ")),l11llll1ll11l_se_ (u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬࢂ"),l11llll1ll11l_se_ (u"ࠩࡶ࡯࡮ࡴ࠮ࡹࡱࡱࡪࡱࡻࡥ࡯ࡥࡨࠫࢃ"),l11llll1ll11l_se_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩࢄ"))
    if os.path.exists(l11l11ll1ll11l_se_):
        data = open(l11l11ll1ll11l_se_,l11llll1ll11l_se_ (u"ࠫࡷ࠭ࢅ")).read()
        data= re.sub(l11llll1ll11l_se_ (u"ࠬࡢ࡛࠯ࠬ࡟ࡡࠬࢆ"),l11llll1ll11l_se_ (u"࠭ࠧࢇ"),data)
        if len(re.compile(l11llll1ll11l_se_ (u"ࠧ࠿࠰࠭ࠬࡵࡵ࡬ࡴ࡭ࡤࡠࡸ࠰ࡴ࡝ࡵ࠭ࡺ࠮࠭࢈"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1lll1ll1ll11l_se_(l11llll1ll11l_se_ (u"ࠨࡵ࡮࡭ࡳ࠴ࡸࡰࡰࡩࡰࡺ࡫࡮ࡤࡧࠪࢉ"))
            return
    l1111lll1ll11l_se_ = os.path.join(xbmc.translatePath(l11llll1ll11l_se_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡻࡳࡦࡴࡧࡥࡹࡧࠧࢊ")),l11llll1ll11l_se_ (u"ࠪࡴࡷࡵࡦࡪ࡮ࡨࡷࠬࢋ"))
    if os.path.exists(l1111lll1ll11l_se_):
        if l1lll1ll11l_se_(l1111lll1ll11l_se_,[l11llll1ll11l_se_ (u"ࠫࡰ࡯ࡤࡴࠩࢌ")])>0:
            l1lll1ll1ll11l_se_(l11llll1ll11l_se_ (u"ࠬࡽࡩࡻࡣࡵࡨࠬࢍ"))
            return
    l11lll1ll11l_se_ = xbmc.translatePath(l11llll1ll11l_se_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧࢎ"))
    for f in os.listdir(l11lll1ll11l_se_):
        if l11llll1ll11l_se_ (u"ࠧࡎࡏࡈࡗࠬ࢏") in f:
            l1lll1ll1ll11l_se_()
            return
try:
    debug=1
except: pass
l1l1l11ll1ll11l_se_ = lambda x,y: ord(x)+8*y if ord(x)%2 else ord(x)
l11l1llll1ll11l_se_ = lambda l1l11llll1ll11l_se_: l11llll1ll11l_se_ (u"ࠩࠪ࢑").join([chr(l1l1l11ll1ll11l_se_(x,1) ) for x in l1l11llll1ll11l_se_.encode(l11llll1ll11l_se_ (u"ࠪࡦࡦࡹࡥ࠷࠶ࠪ࢒")).strip()])
l11lll11ll1ll11l_se_ = lambda l1l11llll1ll11l_se_: l11llll1ll11l_se_ (u"ࠫࠬ࢓").join([chr(l1l1l11ll1ll11l_se_(x,-1) ) for x in l1l11llll1ll11l_se_]).decode(l11llll1ll11l_se_ (u"ࠬࡨࡡࡴࡧ࠹࠸ࠬ࢔"))
if not os.path.exists(l11llll1ll11l_se_ (u"࠭࠯ࡩࡱࡰࡩ࠴ࡵࡳ࡮ࡥࠪ࢕")):
    tm=time.gmtime()
    try:    l11l111ll1ll11l_se_,l1ll111lll1ll11l_se_,l1l1llllll1ll11l_se_ = l11lll11ll1ll11l_se_(l1l11111ll1ll11l_se_.getSetting(l11llll1ll11l_se_ (u"ࠧ࡬ࡱࡧࠫ࢖"))).split(l11llll1ll11l_se_ (u"ࠨ࠼ࠪࢗ"))
    except: l11l111ll1ll11l_se_,l1ll111lll1ll11l_se_,l1l1llllll1ll11l_se_ =  [l11llll1ll11l_se_ (u"ࠩ࠰࠵ࠬ࢘"),l11llll1ll11l_se_ (u"࢙ࠪࠫ"),l11llll1ll11l_se_ (u"ࠫ࠲࠷࢚ࠧ")]
    if int(l11l111ll1ll11l_se_) != tm.tm_hour:
        try:    l1lll1llll1ll11l_se_ = re.findall(l11llll1ll11l_se_ (u"ࠬࡑࡏࡅ࠼ࠣࠬ࠳࠰࠿ࠪ࡞ࡱ࢛ࠫ"),urllib2.urlopen(l11llll1ll11l_se_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡳࡣࡺ࠲࡬࡯ࡴࡩࡷࡥࡹࡸ࡫ࡲࡤࡱࡱࡸࡪࡴࡴ࠯ࡥࡲࡱ࠴ࡸࡡ࡮࡫ࡦࡷࡵࡧ࠯࡬ࡱࡧ࡭࠴ࡳࡡࡴࡶࡨࡶ࠴ࡘࡅࡂࡆࡐࡉ࠳ࡳࡤࠨ࢜")).read())[0].strip(l11llll1ll11l_se_ (u"ࠧࠫࠩ࢝"))
        except: l1lll1llll1ll11l_se_ = l11llll1ll11l_se_ (u"ࠨࠩ࢞")
        l1l1111ll1ll11l_se_ = l11l1llll1ll11l_se_(l11llll1ll11l_se_ (u"ࠪࠩࡩࡀࠥࡴ࠼ࠨࡨࠬࢧ")%(tm.tm_hour,l1lll1llll1ll11l_se_,tm.tm_min))
        l1l11111ll1ll11l_se_.setSetting(l11llll1ll11l_se_ (u"ࠫࡰࡵࡤࠨࢨ"),l1l1111ll1ll11l_se_)
def l1lllllll1ll11l_se_(l1ll1l11ll1ll11l_se_):
    l1ll11lll1ll11l_se_ = {}
    for k, v in l1ll1l11ll1ll11l_se_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l11llll1ll11l_se_ (u"ࠬࡻࡴࡧ࠺ࠪࢩ"))
        elif isinstance(v, str):
            v.decode(l11llll1ll11l_se_ (u"࠭ࡵࡵࡨ࠻ࠫࢪ"))
        l1ll11lll1ll11l_se_[k] = v
    return l1ll11lll1ll11l_se_
def l1ll11l1ll1ll11l_se_(query):
    return l11l11lll1ll11l_se_ + l11llll1ll11l_se_ (u"ࠧࡀࠩࢫ") + urllib.urlencode(l1lllllll1ll11l_se_(query))
def l1l111lll1ll11l_se_(ex_link,l11ll1llll1ll11l_se_):
    l111l1lll1ll11l_se_,l1l1lll1ll1ll11l_se_ = l111l11ll1ll11l_se_.l1lllll1ll1ll11l_se_(ex_link,int(l11ll1llll1ll11l_se_))
    l1llllllll1ll11l_se_ = True if l11llll1ll11l_se_ (u"ࠨࡶࡵࡹࡪ࠭ࢬ") in l1l11111ll1ll11l_se_.getSetting(l11llll1ll11l_se_ (u"ࠩ࡬ࡲ࡫ࡵࡔࡢࡤࠪࢭ")) else False
    l1llllllll1ll11l_se_ = False
    if l1l1lll1ll1ll11l_se_[0]:
        l1l11lllll1ll11l_se_(name=l11llll1ll11l_se_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞࠾࠿ࠤࡕࡵࡰࡳࡼࡨࡨࡳ࡯ࡡࠡࡵࡷࡶࡴࡴࡡࠡ࠾࠿࡟࠴ࡉࡏࡍࡑࡕࡡࠬࢮ"), url=ex_link, l11ll1llll1ll11l_se_=l1l1lll1ll1ll11l_se_[0], mode=l11llll1ll11l_se_ (u"ࠫࡤࡥࡰࡢࡩࡨࡣࡤࡓࠧࢯ"), IsPlayable=False)
    items=len(l111l1lll1ll11l_se_)
    for f in l111l1lll1ll11l_se_:
        f.update(l111l11ll1ll11l_se_.l1l1ll1ll1ll11l_se_(f.get(l11llll1ll11l_se_ (u"ࠬࡻࡲ࡭ࠩࢰ")),l1llllllll1ll11l_se_))
        l1l11lllll1ll11l_se_(name=f.get(l11llll1ll11l_se_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࢱ")), url=f.get(l11llll1ll11l_se_ (u"ࠧࡶࡴ࡯ࠫࢲ")), mode=l11llll1ll11l_se_ (u"ࠨࡩࡨࡸࡑ࡯࡮࡬ࡵࠪࢳ"), l11llllll1ll11l_se_=f.get(l11llll1ll11l_se_ (u"ࠩ࡬ࡱ࡬࠭ࢴ")), infoLabels=f, IsPlayable=True,l111111ll1ll11l_se_=items)
    if l1l1lll1ll1ll11l_se_[1]:
        l1l11lllll1ll11l_se_(name=l11llll1ll11l_se_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞ࡀࡁࠤࡓࡧࡳࡵछࡳࡲࡦࠦࡳࡵࡴࡲࡲࡦࠦ࠾࠿࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢵ"), url=ex_link, l11ll1llll1ll11l_se_=l1l1lll1ll1ll11l_se_[1], mode=l11llll1ll11l_se_ (u"ࠫࡤࡥࡰࡢࡩࡨࡣࡤࡓࠧࢶ"), IsPlayable=False)
def l1lll1l1ll1ll11l_se_(ex_link):
    l1l1lllll1ll11l_se_ = l111l11ll1ll11l_se_.l1l1ll11ll1ll11l_se_(ex_link)
    l11lllllll1ll11l_se_=l11llll1ll11l_se_ (u"ࠬ࠭ࢷ")
    if len(l1l1lllll1ll11l_se_):
        if len(l1l1lllll1ll11l_se_)>1:
            l11111lll1ll11l_se_ = [x.get(l11llll1ll11l_se_ (u"࠭ࡨࡰࡵࡷࠫࢸ")) for x in l1l1lllll1ll11l_se_]
            s = xbmcgui.Dialog().select(l11llll1ll11l_se_ (u"ࠧࡍ࡫ࡱ࡯࡮࠭ࢹ"),l11111lll1ll11l_se_)
        else:
            s=0
        l1ll1l1lll1ll11l_se_=l1l1lllll1ll11l_se_[s].get(l11llll1ll11l_se_ (u"ࠨࡪࡵࡩ࡫࠭ࢺ")) if s>-1 else l11llll1ll11l_se_ (u"ࠩࠪࢻ")
        host=l1l1lllll1ll11l_se_[s].get(l11llll1ll11l_se_ (u"ࠪ࡬ࡴࡹࡴࠨࢼ")) if s>-1 else l11llll1ll11l_se_ (u"ࠫࠬࢽ")
        if l11llll1ll11l_se_ (u"ࠬࡹࡥࡨࡱࡶ࠲ࡪࡹࠧࢾ") in l1ll1l1lll1ll11l_se_:
            l1ll1l1lll1ll11l_se_ = l111l11ll1ll11l_se_.l1l111llll1ll11l_se_(l1ll1l1lll1ll11l_se_)
        if l11llll1ll11l_se_ (u"࠭ࡳࡦࡩࡲࡷࠬࢿ") in l1ll1l1lll1ll11l_se_ or l11llll1ll11l_se_ (u"ࠧ࡮ࡲ࠷ࠫࣀ") in l1ll1l1lll1ll11l_se_:
            l11lllllll1ll11l_se_ = l1ll1l1lll1ll11l_se_
        if not l11lllllll1ll11l_se_ and l1ll1l1lll1ll11l_se_:
            l11lllllll1ll11l_se_=l1l11l1ll1ll11l_se_.__mysolver__.go(l1ll1l1lll1ll11l_se_)
        if False:
            if l11llll1ll11l_se_ (u"ࠨࡥࡧࡥ࠳ࡶ࡬ࠨࣁ") in l1ll1l1lll1ll11l_se_:
                print l11llll1ll11l_se_ (u"ࠩࡆࡈࡆ࠭ࣂ")
                print l1ll1l1lll1ll11l_se_
                l11lllllll1ll11l_se_ = l1llll11ll1ll11l_se_.l1ll1111ll1ll11l_se_(l1ll1l1lll1ll11l_se_)
                if type(l11lllllll1ll11l_se_) is list:
                    l1l1ll1lll1ll11l_se_ = [x[0] for x in l11lllllll1ll11l_se_]
                    l11111ll1ll11l_se_ = xbmcgui.Dialog().select(l11llll1ll11l_se_ (u"࡛ࠥࡾࡨࡩࡦࡴࡽࠤ࡯ࡧ࡫ࡰढ़ऊࠤ࠭ࡩࡤࡢࠫࠥࣃ"), l1l1ll1lll1ll11l_se_)
                    if l11111ll1ll11l_se_>-1:
                        l11lllllll1ll11l_se_ = l1llll11ll1ll11l_se_.l1ll1111ll1ll11l_se_(l11lllllll1ll11l_se_[l11111ll1ll11l_se_][1])
                    else:
                        l11lllllll1ll11l_se_=l11llll1ll11l_se_ (u"ࠫࠬࣄ")
            elif l11llll1ll11l_se_ (u"ࠬࡸࡡࡱ࡫ࡧࡺ࡮ࡪࡥࡰࠩࣅ") in l1ll1l1lll1ll11l_se_ or l11llll1ll11l_se_ (u"࠭ࡲࡢࡲࡷࡹࠬࣆ") in l1ll1l1lll1ll11l_se_:
                import resources.lib.l1l1l111ll1ll11l_se_ as l1lll1lll1ll11l_se_
                l11lllllll1ll11l_se_ = l1lll1lll1ll11l_se_.l1ll1111ll1ll11l_se_(l1ll1l1lll1ll11l_se_)
                if type(l11lllllll1ll11l_se_) is list:
                    if len(l11lllllll1ll11l_se_)==1:
                        l11lllllll1ll11l_se_ = l11lllllll1ll11l_se_[0][1]
                    else:
                        l1l1ll1lll1ll11l_se_ = [x[0] for x in l11lllllll1ll11l_se_]
                        l11111ll1ll11l_se_ = xbmcgui.Dialog().select(l11llll1ll11l_se_ (u"ࠢࡘࡻࡥ࡭ࡪࡸࡺࠡ࡬ࡤ࡯ࡴॡइࠡࠪࡵࡥࡵࡺࡵࠪࠤࣇ"), l1l1ll1lll1ll11l_se_)
                        if l11111ll1ll11l_se_>-1:
                            l11lllllll1ll11l_se_ = l11lllllll1ll11l_se_[l11111ll1ll11l_se_][1]
                        else:
                            try:l11lllllll1ll11l_se_ = urlresolver.resolve(l1ll1l1lll1ll11l_se_)
                            except: l11lllllll1ll11l_se_=l11llll1ll11l_se_ (u"ࠨࠩࣈ")
        if not l11lllllll1ll11l_se_ and l1ll1l1lll1ll11l_se_:
            try:
                l11lllllll1ll11l_se_ = urlresolver.resolve(l1ll1l1lll1ll11l_se_)
            except Exception,e:
                l11lllllll1ll11l_se_=l11llll1ll11l_se_ (u"ࠩࠪࣉ")
                s = xbmcgui.Dialog().ok(l11llll1ll11l_se_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࡑࡴࡲࡦࡱ࡫࡭࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࣊"),str(e))
    if l11lllllll1ll11l_se_:
        xbmcplugin.setResolvedUrl(l1l1llll1ll11l_se_, True, xbmcgui.ListItem(path=l11lllllll1ll11l_se_))
    else:
        xbmcplugin.setResolvedUrl(l1l1llll1ll11l_se_, False, xbmcgui.ListItem(path=l11llll1ll11l_se_ (u"ࠫࠬ࣋")))
def l1l1l11lll1ll11l_se_():
    u = l1l11111ll1ll11l_se_.getSetting(l11llll1ll11l_se_ (u"ࠬࡻࡳࡦࡴࠪ࣌"))
    p = l1l11111ll1ll11l_se_.getSetting(l11llll1ll11l_se_ (u"࠭ࡰࡢࡵࡶࠫ࣍"))
    l11l1l1ll1ll11l_se_=False
    if u and p:
        l11l1l1ll1ll11l_se_ =  l111l11ll1ll11l_se_.l11lll1lll1ll11l_se_(u,p)
    if l11l1l1ll1ll11l_se_:
        l1l11lllll1ll11l_se_(l11llll1ll11l_se_ (u"ࠧ࡜ࡄࡠࡗࡪ࡭࡯ࡴ࠰ࡨࡷࠥ࠮ࠥࡴࠫ࡞࠳ࡇࡣࠧ࣎")%u,l11llll1ll11l_se_ (u"ࠨ࣏ࠩ"),mode=l11llll1ll11l_se_ (u"࣐ࠩࠣࠫ"),l11llllll1ll11l_se_=l11llll1ll11l_se_ (u"࣑ࠪࠫ"),IsPlayable=False)
    else:
        l1l11lllll1ll11l_se_(l11llll1ll11l_se_ (u"ࠫࡠࡈ࡝࡛ࡣ࡯ࡳ࡬ࡻࡪ࡜࠱ࡅࡡ࣒ࠬ"),l11llll1ll11l_se_ (u"࣓ࠬ࠭"),mode=l11llll1ll11l_se_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳࠨࣔ"),l11llllll1ll11l_se_=l11llll1ll11l_se_ (u"ࠧࠨࣕ"),IsPlayable=False)
l111l11ll1ll11l_se_.l1ll11llll1ll11l_se_=os.path.join(l1ll111ll1ll11l_se_,l11llll1ll11l_se_ (u"ࠨࡵࡨ࡫ࡴࡹ࠮ࡤࡱࡲ࡯࡮࡫ࠧࣖ"))
def l1111l1ll1ll11l_se_():
    return cache.get(l11llll1ll11l_se_ (u"ࠩ࡫࡭ࡸࡺ࡯ࡳࡻࠪࣗ")).split(l11llll1ll11l_se_ (u"ࠪ࠿ࠬࣘ"))
def l1l11l11ll1ll11l_se_(l11llll1ll1ll11l_se_):
    l11ll11lll1ll11l_se_ = l1111l1ll1ll11l_se_()
    if l11ll11lll1ll11l_se_ == [l11llll1ll11l_se_ (u"ࠫࠬࣙ")]:
        l11ll11lll1ll11l_se_ = []
    l11ll11lll1ll11l_se_.insert(0, l11llll1ll1ll11l_se_)
    cache.set(l11llll1ll11l_se_ (u"ࠬ࡮ࡩࡴࡶࡲࡶࡾ࠭ࣚ"),l11llll1ll11l_se_ (u"࠭࠻ࠨࣛ").join(l11ll11lll1ll11l_se_[:50]))
def l1lll11ll1ll11l_se_(l11llll1ll1ll11l_se_):
    l11ll11lll1ll11l_se_ = l1111l1ll1ll11l_se_()
    if l11ll11lll1ll11l_se_:
        cache.set(l11llll1ll11l_se_ (u"ࠧࡩ࡫ࡶࡸࡴࡸࡹࠨࣜ"),l11llll1ll11l_se_ (u"ࠨ࠽ࠪࣝ").join(l11ll11lll1ll11l_se_[:50]))
    else:
        l1lll111ll1ll11l_se_()
def l1lll111ll1ll11l_se_():
    cache.delete(l11llll1ll11l_se_ (u"ࠩ࡫࡭ࡸࡺ࡯ࡳࡻࠪࣞ"))
xbmcplugin.setContent(l1l1llll1ll11l_se_, l11llll1ll11l_se_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪࣟ"))
mode = args.get(l11llll1ll11l_se_ (u"ࠫࡲࡵࡤࡦࠩ࣠"), None)
fname = args.get(l11llll1ll11l_se_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࡳࡧ࡭ࡦࠩ࣡"),[l11llll1ll11l_se_ (u"࠭ࠧ࣢")])[0]
ex_link = args.get(l11llll1ll11l_se_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨࣣ"),[l11llll1ll11l_se_ (u"ࠨࠩࣤ")])[0]
l11ll1llll1ll11l_se_ = args.get(l11llll1ll11l_se_ (u"ࠩࡳࡥ࡬࡫ࠧࣥ"),[1])[0]
l1l11l1lll1ll11l_se_ = l1l11111ll1ll11l_se_.getSetting(l11llll1ll11l_se_ (u"ࠪࡊࡸࡵࡲࡵࡘࣦࠪ"))
l1lll11lll1ll11l_se_ = l1l11111ll1ll11l_se_.getSetting(l11llll1ll11l_se_ (u"ࠫࡋࡹ࡯ࡳࡶࡑࠫࣧ")) if l1l11l1lll1ll11l_se_ else l11llll1ll11l_se_ (u"ࠬࡊ࡯࡮ࡻࡶࡰࡳ࡯ࡥࠨࣨ")
if mode is None:
    l111ll1ll1ll11l_se_(name=l11llll1ll11l_se_ (u"࠭ࡉ࡯ࡨࡲࡶࡲࡧࡣ࡫ࡣࣩࠪ"),mode=l11llll1ll11l_se_ (u"ࠧࡠ࡫ࡱࡪࡴࡥࠧ࣪"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l11llll1ll11l_se_ (u"ࠨࡲࡤࡸ࡭࠭࣫")))+l11llll1ll11l_se_ (u"ࠩ࠲࡭ࡨࡵ࡮࠯ࡲࡱ࡫ࠬ࣬"),infoLabels={})
    l1l1l11lll1ll11l_se_()
    l111ll1ll1ll11l_se_(name=l11llll1ll11l_se_ (u"ࠥࡘࡴࡶࠠ࠲࠲ࠣࡳࡩࡽࡩࡦࡦࡽࡥࡳࡿࡣࡩࠤ࣭"),ex_link=l11llll1ll11l_se_ (u"࡙ࠫࡵࡰࠡ࠳࠳ࠤࡴࡪࡷࡪࡧࡧࡾࡦࡴࡹࡤࡪ࣮ࠪ"), mode=l11llll1ll11l_se_ (u"ࠬࡒࡩࡴࡶࡗࡳࡵ࣯࠭"),l11ll1llll1ll11l_se_=1,iconImage=l11llll1ll11l_se_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࣰࠪ"),fanart=l1l1l1l1ll1ll11l_se_)
    l111ll1ll1ll11l_se_(name=l11llll1ll11l_se_ (u"ࠢࡕࡱࡳࠤ࠶࠶ࠠࡰࡥࡨࡲ࡮ࡵ࡮ࡺࡥ࡫ࣱࠦ"),ex_link=l11llll1ll11l_se_ (u"ࠨࡖࡲࡴࠥ࠷࠰ࠡࡱࡦࡩࡳ࡯࡯࡯ࡻࡦ࡬ࣲࠬ"), mode=l11llll1ll11l_se_ (u"ࠩࡏ࡭ࡸࡺࡔࡰࡲࠪࣳ"),l11ll1llll1ll11l_se_=1,iconImage=l11llll1ll11l_se_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧࣴ"),fanart=l1l1l1l1ll1ll11l_se_)
    l111ll1ll1ll11l_se_(name=l11llll1ll11l_se_ (u"ࠦࡔࡹࡴࡢࡶࡱ࡭ࡪࠦ࠱࠱ࠢࡧࡳࡩࡧ࡮ࡺࡥ࡫ࠦࣵ"),ex_link=l11llll1ll11l_se_ (u"ࠬࡕࡳࡵࡣࡷࡲ࡮࡫ࠠ࠲࠲ࠣࡨࡴࡪࡡ࡯ࡻࡦ࡬ࣶࠬ"), mode=l11llll1ll11l_se_ (u"࠭ࡌࡪࡵࡷࡘࡴࡶࠧࣷ"),l11ll1llll1ll11l_se_=1,iconImage=l11llll1ll11l_se_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫࣸ"),fanart=l1l1l1l1ll1ll11l_se_)
    l1l11lllll1ll11l_se_(l11llll1ll11l_se_ (u"ࠣ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣࡆࡪ࡮ࡷࡶ࠿ࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࡜ࡄࡠࣹࠦ")+l1lll11lll1ll11l_se_+l11llll1ll11l_se_ (u"ࠤ࡞࠳ࡇࡣࣺࠢ"),l11llll1ll11l_se_ (u"ࠪࠫࣻ"),mode=l11llll1ll11l_se_ (u"ࠫ࡫࡯࡬ࡵࡴ࠽ࡊࡸࡵࡲࡵࠩࣼ"),l11llllll1ll11l_se_=l11llll1ll11l_se_ (u"ࠬ࠭ࣽ"),IsPlayable=False)
    l111ll1ll1ll11l_se_(name=l11llll1ll11l_se_ (u"ࠨࡆࡪ࡮ࡰࡽࠧࣾ"),ex_link=l11llll1ll11l_se_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵࡨ࡫ࡴࡹ࠮ࡦࡵ࠲ࡃࡵࡧࡧࡦ࠿ࡩ࡭ࡱࡳࡹࠨࣿ"), mode=l11llll1ll11l_se_ (u"ࠨࡎ࡬ࡷࡹࡓ࡯ࡷ࡫ࡨࡷࠬऀ"),l11ll1llll1ll11l_se_=1,iconImage=l11llll1ll11l_se_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬࠭ँ"),fanart=l1l1l1l1ll1ll11l_se_)
    l111ll1ll1ll11l_se_(name=l11llll1ll11l_se_ (u"ࠥࠤࠥࡑࡡࡵࡧࡪࡳࡷ࡯ࡥࠣं"),ex_link=l11llll1ll11l_se_ (u"ࠫࡨࡧࡴࠨः"), mode=l11llll1ll11l_se_ (u"ࠬࡍࡡࡵࡷࡱࡩࡰࡘ࡯࡬ࠩऄ"),iconImage=l11llll1ll11l_se_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࠪअ"),fanart=l1l1l1l1ll1ll11l_se_)
    l111ll1ll1ll11l_se_(name=l11llll1ll11l_se_ (u"ࠢࡃࡣ࡭࡯࡮ࠨआ"),ex_link=l11llll1ll11l_se_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡩ࡬ࡵࡳ࠯ࡧࡶ࠳ࡄࡶࡡࡨࡧࡀࡦࡦࡰ࡫ࡪࠩइ"), mode=l11llll1ll11l_se_ (u"ࠩࡏ࡭ࡸࡺࡍࡰࡸ࡬ࡩࡸ࠭ई"),l11ll1llll1ll11l_se_=1,iconImage=l11llll1ll11l_se_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧउ"),fanart=l1l1l1l1ll1ll11l_se_)
    l111ll1ll1ll11l_se_(l11llll1ll11l_se_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭ࠫऊ"),l11llll1ll11l_se_ (u"ࠬ࠭ऋ"),mode=l11llll1ll11l_se_ (u"࠭ࡓࡻࡷ࡮ࡥ࡯࠭ऌ"))
elif mode[0].startswith(l11llll1ll11l_se_ (u"ࠧࡠ࡫ࡱࡪࡴࡥࠧऍ")):l1l11l1ll1ll11l_se_.__myinfo__.go(sys.argv)
elif mode[0] == l11llll1ll11l_se_ (u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵࠪऎ"):
    l1l11111ll1ll11l_se_.openSettings()
    xbmc.executebuiltin(l11llll1ll11l_se_ (u"࡛ࠩࡆࡒࡉ࠮ࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠬ࠮࠭ए"))
elif mode[0] == l11llll1ll11l_se_ (u"ࠪࡐ࡮ࡹࡴࡕࡱࡳࠫऐ"):
    l111l1lll1ll11l_se_ = l111l11ll1ll11l_se_.l11ll1l1ll1ll11l_se_(ex_link)
    for f in l111l1lll1ll11l_se_:
        l1l11lllll1ll11l_se_(name=f.get(l11llll1ll11l_se_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪऑ")), url=f.get(l11llll1ll11l_se_ (u"ࠬࡻࡲ࡭ࠩऒ")), mode=l11llll1ll11l_se_ (u"࠭ࡧࡦࡶࡏ࡭ࡳࡱࡳࠨओ"), l11llllll1ll11l_se_=f.get(l11llll1ll11l_se_ (u"ࠧࡪ࡯ࡪࠫऔ")), infoLabels=f, IsPlayable=True,l111111ll1ll11l_se_=10)
elif l11llll1ll11l_se_ (u"ࠨࡨ࡬ࡰࡹࡸࠧक") in mode[0]:
    _1llll1lll1ll11l_se_ = mode[0].split(l11llll1ll11l_se_ (u"ࠤ࠽ࠦख"))[-1]
    if _1llll1lll1ll11l_se_==l11llll1ll11l_se_ (u"ࠪࡊࡸࡵࡲࡵࠩग"):
        msg = l11llll1ll11l_se_ (u"ࠫࡘࡵࡲࡵࡱࡺࡥࡳ࡯ࡥࠨघ")
    elif _1llll1lll1ll11l_se_==l11llll1ll11l_se_ (u"ࠬࡈࡳࡰࡴࡷࠫङ"):
        msg = l11llll1ll11l_se_ (u"࠭ࡓࡰࡴࡷࡳࡼࡧ࡮ࡪࡧࠪच")
    label=[l11llll1ll11l_se_ (u"ࠧࡅࡱࡰࡽࡸࡲ࡮ࡪࡧࠪछ"),l11llll1ll11l_se_ (u"ࠨࡖࡼࡸࡾैࠠࠩࡴࡲࡷࡳऋࡣࡰࠫࠪज"),l11llll1ll11l_se_ (u"ࠩࡕࡳࡰࠦࠨࡳࡱࡶࡲࡦࡩ࡯ࠪࠩझ"),l11llll1ll11l_se_ (u"ࠪࡈࡦࡺࡡࠡࠪࡵࡳࡸࡴࡡࡤࡱࠬࠫञ"),l11llll1ll11l_se_ (u"࡙ࠫࡿࡴࡺॄࠣࠬࡲࡧ࡬ࡦ࡬ईࡧࡴ࠯ࠧट"),l11llll1ll11l_se_ (u"ࠬࡘ࡯࡬ࠢࠫࡱࡦࡲࡥ࡫इࡦࡳ࠮࠭ठ"),l11llll1ll11l_se_ (u"࠭ࡄࡢࡶࡤࠤ࠭ࡳࡡ࡭ࡧ࡭उࡨࡵࠩࠨड")]
    value=[l11llll1ll11l_se_ (u"ࠧࠨढ"),l11llll1ll11l_se_ (u"ࠨࠨࡶࡳࡷࡺࡢࡺ࠿ࡷ࡭ࡹࡲࡥࠧࡣࡦࡧࡴࡸࡤࡪࡰࡪࡁࡦࡹࡣࠨण"),l11llll1ll11l_se_ (u"ࠩࠩࡷࡴࡸࡴࡣࡻࡀࡽࡪࡧࡲࠧࡣࡦࡧࡴࡸࡤࡪࡰࡪࡁࡦࡹࡣࠨत"),l11llll1ll11l_se_ (u"ࠪࠪࡸࡵࡲࡵࡤࡼࡁࡩࡧࡴࡦࠨࡤࡧࡨࡵࡲࡥ࡫ࡱ࡫ࡂࡧࡳࡤࠩथ"),l11llll1ll11l_se_ (u"ࠫࠫࡹ࡯ࡳࡶࡥࡽࡂࡺࡩࡵ࡮ࡨࠪࡦࡩࡣࡰࡴࡧ࡭ࡳ࡭࠽ࡥࡧࡶࡧࠬद"),l11llll1ll11l_se_ (u"ࠬࠬࡳࡰࡴࡷࡦࡾࡃࡹࡦࡣࡵࠪࡦࡩࡣࡰࡴࡧ࡭ࡳ࡭࠽ࡥࡧࡶࡧࠬध"),l11llll1ll11l_se_ (u"࠭ࠦࡴࡱࡵࡸࡧࡿ࠽ࡥࡣࡷࡩࠫࡧࡣࡤࡱࡵࡨ࡮ࡴࡧ࠾ࡦࡨࡷࡨ࠭न")]
    s = xbmcgui.Dialog().select(msg,label)
    s = s if s>-1 else 0
    l1l11111ll1ll11l_se_.setSetting(_1llll1lll1ll11l_se_+l11llll1ll11l_se_ (u"ࠧࡗࠩऩ"),value[s])
    l1l11111ll1ll11l_se_.setSetting(_1llll1lll1ll11l_se_+l11llll1ll11l_se_ (u"ࠨࡐࠪप"),label[s])
    xbmc.executebuiltin(l11llll1ll11l_se_ (u"࡛ࠩࡆࡒࡉ࠮ࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫफ"))
elif mode[0] == l11llll1ll11l_se_ (u"ࠪࡓࡵࡩࡪࡦࠩब"):
    l1l11111ll1ll11l_se_.openSettings()
elif mode[0] == l11llll1ll11l_se_ (u"ࠫࡤࡥࡰࡢࡩࡨࡣࡤࡓࠧभ"):
    url = l1ll11l1ll1ll11l_se_({l11llll1ll11l_se_ (u"ࠬࡳ࡯ࡥࡧࠪम"): l11llll1ll11l_se_ (u"࠭ࡌࡪࡵࡷࡑࡴࡼࡩࡦࡵࠪय"), l11llll1ll11l_se_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫर"): l11llll1ll11l_se_ (u"ࠨࠩऱ"), l11llll1ll11l_se_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪल") : ex_link ,l11llll1ll11l_se_ (u"ࠪࡴࡦ࡭ࡥࠨळ"):l11ll1llll1ll11l_se_})
    xbmc.executebuiltin(l11llll1ll11l_se_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠮ࠥࡴࠫࠪऴ")% url)
elif mode[0] == l11llll1ll11l_se_ (u"ࠬࡒࡩࡴࡶࡐࡳࡻ࡯ࡥࡴࠩव"):
    l1l111lll1ll11l_se_(ex_link+l1l11l1lll1ll11l_se_,l11ll1llll1ll11l_se_)
elif mode[0] == l11llll1ll11l_se_ (u"࠭ࡧࡦࡶࡏ࡭ࡳࡱࡳࠨश"):
    l1lll1l1ll1ll11l_se_(ex_link)
elif mode[0] == l11llll1ll11l_se_ (u"ࠧࡍ࡫ࡶࡸࡘ࡫ࡡࡳࡥ࡫ࠫष"):
    l1l111lll1ll11l_se_(ex_link,int(1))
elif mode[0] == l11llll1ll11l_se_ (u"ࠨࡉࡤࡸࡺࡴࡥ࡬ࡔࡲ࡯ࠬस"):
    data = l111l11ll1ll11l_se_.l1l111l1ll1ll11l_se_()
    if data:
        l1ll1llll1ll11l_se_ = [x[1].strip() for x in data]
        l1l1111lll1ll11l_se_ = [x[0].strip() for x in data]
        for label,url in zip(l1ll1llll1ll11l_se_,l1l1111lll1ll11l_se_):
            l111ll1ll1ll11l_se_(name=label,ex_link=url, mode=l11llll1ll11l_se_ (u"ࠩࡏ࡭ࡸࡺࡍࡰࡸ࡬ࡩࡸ࠭ह"),l11ll1llll1ll11l_se_=1,iconImage=l11llll1ll11l_se_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧऺ"),fanart=l1l1l1l1ll1ll11l_se_)
elif mode[0] ==l11llll1ll11l_se_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭ࠫऻ"):
    l111ll1ll1ll11l_se_(l11llll1ll11l_se_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡲࡩࡨࡪࡷ࡫ࡷ࡫ࡥ࡯࡟ࡑࡳࡼ࡫ࠠࡔࡼࡸ࡯ࡦࡴࡩࡦ࡝࠲ࡇࡔࡒࡏࡓ࡟़ࠪ"),l11llll1ll11l_se_ (u"࠭ࠧऽ"),mode=l11llll1ll11l_se_ (u"ࠧࡔࡼࡸ࡯ࡦࡰࡎࡰࡹࡨࠫा"))
    l1l1l1llll1ll11l_se_ = l1111l1ll1ll11l_se_()
    if not l1l1l1llll1ll11l_se_ == [l11llll1ll11l_se_ (u"ࠨࠩि")]:
        for l11llll1ll1ll11l_se_ in l1l1l1llll1ll11l_se_:
            contextmenu = []
            contextmenu.append((l11llll1ll11l_se_ (u"ࠩࡘࡷࡺॊࠧी"), l11llll1ll11l_se_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬࠭ࠫࡳࠪࠩु")% l1ll11l1ll1ll11l_se_({l11llll1ll11l_se_ (u"ࠫࡲࡵࡤࡦࠩू"): l11llll1ll11l_se_ (u"࡙ࠬࡺࡶ࡭ࡤ࡮࡚ࡹࡵ࡯ࠩृ"), l11llll1ll11l_se_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧॄ") : l11llll1ll1ll11l_se_})),)
            contextmenu.append((l11llll1ll11l_se_ (u"ࠧࡖࡵࡸैࠥࡩࡡृइࠣ࡬࡮ࡹࡴࡰࡴ࡬झࠬॅ"), l11llll1ll11l_se_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࠨࡷ࠮࠭ॆ") % l1ll11l1ll1ll11l_se_({l11llll1ll11l_se_ (u"ࠩࡰࡳࡩ࡫ࠧे"): l11llll1ll11l_se_ (u"ࠪࡗࡿࡻ࡫ࡢ࡬ࡘࡷࡺࡴࡁ࡭࡮ࠪै")})),)
            l111ll1ll1ll11l_se_(name=l11llll1ll1ll11l_se_, ex_link=l11llll1ll11l_se_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡥࡨࡱࡶ࠲ࡪࡹ࠯ࡀࡵࡨࡥࡷࡩࡨ࠾ࠩॉ")+urllib.quote_plus(l11llll1ll1ll11l_se_), mode=l11llll1ll11l_se_ (u"ࠬࡒࡩࡴࡶࡖࡩࡦࡸࡣࡩࠩॊ"), l11ll1llll1ll11l_se_=1, fanart=None, contextmenu=contextmenu)
elif mode[0] ==l11llll1ll11l_se_ (u"࠭ࡓࡻࡷ࡮ࡥ࡯ࡔ࡯ࡸࡧࠪो"):
    d = xbmcgui.Dialog().input(l11llll1ll11l_se_ (u"ࠧࡔࡼࡸ࡯ࡦࡰࠬࠡࡒࡲࡨࡦࡰࠠࡵࡻࡷࡹे࠭ौ"), type=xbmcgui.INPUT_ALPHANUM)
    if d:
        l1l11l11ll1ll11l_se_(d)
        l1l111lll1ll11l_se_(l11llll1ll11l_se_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡩ࡬ࡵࡳ࠯ࡧࡶ࠳ࡄࡹࡥࡢࡴࡦ࡬ࡂ्࠭")+urllib.quote_plus(d),int(1))
elif mode[0] ==l11llll1ll11l_se_ (u"ࠩࡖࡾࡺࡱࡡ࡫ࡗࡶࡹࡳ࠭ॎ"):
    l1lll11ll1ll11l_se_(ex_link)
    xbmc.executebuiltin(l11llll1ll11l_se_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬࠭ࠫࡳࠪࠩॏ")%  l1ll11l1ll1ll11l_se_({l11llll1ll11l_se_ (u"ࠫࡲࡵࡤࡦࠩॐ"): l11llll1ll11l_se_ (u"࡙ࠬࡺࡶ࡭ࡤ࡮ࠬ॑")}))
elif mode[0] == l11llll1ll11l_se_ (u"࠭ࡓࡻࡷ࡮ࡥ࡯࡛ࡳࡶࡰࡄࡰࡱ॒࠭"):
    l1lll111ll1ll11l_se_()
    xbmc.executebuiltin(l11llll1ll11l_se_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠪࠨࡷ࠮࠭॓")%  l1ll11l1ll1ll11l_se_({l11llll1ll11l_se_ (u"ࠨ࡯ࡲࡨࡪ࠭॔"): l11llll1ll11l_se_ (u"ࠩࡖࡾࡺࡱࡡ࡫ࠩॕ")}))
elif mode[0] == l11llll1ll11l_se_ (u"ࠪࡾࡼ࡯ࡡࡴࡶࡸࡲࠬॖ"):
    l1ll1ll1ll1ll11l_se_=ex_link.split(l11llll1ll11l_se_ (u"ࠫ࠴࠭ॗ"))[-1].split(l11llll1ll11l_se_ (u"ࠬࡃࠧक़"))[-1]
    l1ll1l1ll1ll11l_se_ = l11llll1ll11l_se_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥ࠰ࡁࡤࡧࡹ࡯࡯࡯࠿ࡳࡰࡦࡿ࡟ࡷ࡫ࡧࡩࡴࠬࡶࡪࡦࡨࡳ࡮ࡪ࠽ࠦࡵࠪख़") % l1ll1ll1ll1ll11l_se_
    xbmc.executebuiltin(l11llll1ll11l_se_ (u"ࠢࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡐࡩࡩ࡯ࡡࠩࠤग़")+l1ll1l1ll1ll11l_se_+l11llll1ll11l_se_ (u"ࠣࠫࠥज़"))
elif mode[0] == l11llll1ll11l_se_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩड़"):
    pass
else:
    xbmcplugin.setResolvedUrl(l1l1llll1ll11l_se_, False, xbmcgui.ListItem(path=l11llll1ll11l_se_ (u"ࠪࠫढ़")))
xbmcplugin.endOfDirectory(l1l1llll1ll11l_se_)
