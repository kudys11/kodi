# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import sys,re,os
import urllib,urllib2
import urlparse
import check
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import threading
import time
l1llll1l11l111_tv_        = sys.argv[0]
l1lll1llll11l111_tv_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l111l1ll11l111_tv_        = xbmcaddon.Addon()
l111ll1ll11l111_tv_       = l111l1ll11l111_tv_.getAddonInfo(l11l1l11l111_tv_ (u"ࠩࡱࡥࡲ࡫ࠧࠨ"))
l1ll1l11ll11l111_tv_     = l111l1ll11l111_tv_.getAddonInfo(l11l1l11l111_tv_ (u"ࠪ࡭ࡩ࠭ࠩ"))
PATH            = l111l1ll11l111_tv_.getAddonInfo(l11l1l11l111_tv_ (u"ࠫࡵࡧࡴࡩࠩࠪ"))
l1l11l11l11l111_tv_        = xbmc.translatePath(l111l1ll11l111_tv_.getAddonInfo(l11l1l11l111_tv_ (u"ࠬࡶࡲࡰࡨ࡬ࡰࡪ࠭ࠫ"))).decode(l11l1l11l111_tv_ (u"࠭ࡵࡵࡨ࠰࠼ࠬࠬ"))
l1l11lll11l111_tv_       = PATH+l11l1l11l111_tv_ (u"ࠧ࠰ࡴࡨࡷࡴࡻࡲࡤࡧࡶ࠳ࠬ࠭")
sys.path.append( os.path.join( l1l11lll11l111_tv_, l11l1l11l111_tv_ (u"ࠣ࡮࡬ࡦࠧ࠮") ) )
l1ll1lll1l11l111_tv_=PATH+l11l1l11l111_tv_ (u"ࠩ࠲ࡪࡦࡴࡡࡳࡶ࠱࡮ࡵ࡭ࠧ࠯")
def l1lllllll11l111_tv_(name=l11l1l11l111_tv_ (u"ࠪࠫ࠰"), url=l11l1l11l111_tv_ (u"ࠫࠬ࠱"), mode=l11l1l11l111_tv_ (u"ࠬ࠭࠲"), params=1, l111l11l11l111_tv_=l11l1l11l111_tv_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࠪ࠳"), infoLabels=False, IsPlayable=True,fanart=l1ll1lll1l11l111_tv_,l1111l1l11l111_tv_=1,contextmenu=None):
    u = l1l111l11l111_tv_({l11l1l11l111_tv_ (u"ࠧ࡮ࡱࡧࡩࠬ࠴"): mode, l11l1l11l111_tv_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬ࠵"): name, l11l1l11l111_tv_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪ࠶") : url, l11l1l11l111_tv_ (u"ࠪࡴࡦࡸࡡ࡮ࡵࠪ࠷"):params})
    l1llll11ll11l111_tv_ = xbmcgui.ListItem(name)
    l1ll1l111l11l111_tv_=[l11l1l11l111_tv_ (u"ࠫࡹ࡮ࡵ࡮ࡤࠪ࠸"),l11l1l11l111_tv_ (u"ࠬࡶ࡯ࡴࡶࡨࡶࠬ࠹"),l11l1l11l111_tv_ (u"࠭ࡢࡢࡰࡱࡩࡷ࠭࠺"),l11l1l11l111_tv_ (u"ࠧࡧࡣࡱࡥࡷࡺࠧ࠻"),l11l1l11l111_tv_ (u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶࠪ࠼"),l11l1l11l111_tv_ (u"ࠩࡦࡰࡪࡧࡲ࡭ࡱࡪࡳࠬ࠽"),l11l1l11l111_tv_ (u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭࠾"),l11l1l11l111_tv_ (u"ࠫ࡮ࡩ࡯࡯ࠩ࠿")]
    l11ll1ll11l111_tv_ = dict(zip(l1ll1l111l11l111_tv_,[l111l11l11l111_tv_ for x in l1ll1l111l11l111_tv_]))
    l11ll1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨࡀ")] = fanart if fanart else l11ll1ll11l111_tv_[l11l1l11l111_tv_ (u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦࠩࡁ")]
    l11ll1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠧࡧࡣࡱࡥࡷࡺࠧࡂ")] = fanart if fanart else l11ll1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫࡃ")]
    l1llll11ll11l111_tv_.setArt(l11ll1ll11l111_tv_)
    if not infoLabels:
        infoLabels={l11l1l11l111_tv_ (u"ࠤࡷ࡭ࡹࡲࡥࠣࡄ"): name}
    l1llll11ll11l111_tv_.setInfo(type=l11l1l11l111_tv_ (u"ࠥࡺ࡮ࡪࡥࡰࠤࡅ"), infoLabels=infoLabels)
    if IsPlayable:
        l1llll11ll11l111_tv_.setProperty(l11l1l11l111_tv_ (u"ࠫࡎࡹࡐ࡭ࡣࡼࡥࡧࡲࡥࠨࡆ"), l11l1l11l111_tv_ (u"ࠬࡺࡲࡶࡧࠪࡇ"))
    if contextmenu:
        l1ll1ll11l11l111_tv_=contextmenu
        l1lll11l11l111_tv_.addContextMenuItems(l1ll1ll11l11l111_tv_, replaceItems=True)
    ok = xbmcplugin.addDirectoryItem(handle=l1lll1llll11l111_tv_, url=u, listitem=l1llll11ll11l111_tv_,isFolder=False,totalItems=l1111l1l11l111_tv_)
    xbmcplugin.addSortMethod(l1lll1llll11l111_tv_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l11l1l11l111_tv_ (u"ࠨࠥࡓ࠮ࠣࠩ࡞࠲ࠠࠦࡒࠥࡈ"))
    return ok
def l1111lll11l111_tv_(name,ex_link=None, params=1, mode=l11l1l11l111_tv_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧࡉ"),iconImage=l11l1l11l111_tv_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬࡊ"), infoLabels=None, fanart=l1ll1lll1l11l111_tv_,contextmenu=None):
    url = l1l111l11l111_tv_({l11l1l11l111_tv_ (u"ࠩࡰࡳࡩ࡫ࠧࡋ"): mode, l11l1l11l111_tv_ (u"ࠪࡪࡴࡲࡤࡦࡴࡱࡥࡲ࡫ࠧࡌ"): name, l11l1l11l111_tv_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬࡍ") : ex_link, l11l1l11l111_tv_ (u"ࠬࡶࡡࡳࡣࡰࡷࠬࡎ") : params})
    l1lll11l11l111_tv_ = xbmcgui.ListItem(name)
    if infoLabels:
        l1lll11l11l111_tv_.setInfo(type=l11l1l11l111_tv_ (u"ࠨࡶࡪࡦࡨࡳࠧࡏ"), infoLabels=infoLabels)
    l1ll1l111l11l111_tv_=[l11l1l11l111_tv_ (u"ࠧࡵࡪࡸࡱࡧ࠭ࡐ"),l11l1l11l111_tv_ (u"ࠨࡲࡲࡷࡹ࡫ࡲࠨࡑ"),l11l1l11l111_tv_ (u"ࠩࡥࡥࡳࡴࡥࡳࠩࡒ"),l11l1l11l111_tv_ (u"ࠪࡪࡦࡴࡡࡳࡶࠪࡓ"),l11l1l11l111_tv_ (u"ࠫࡨࡲࡥࡢࡴࡤࡶࡹ࠭ࡔ"),l11l1l11l111_tv_ (u"ࠬࡩ࡬ࡦࡣࡵࡰࡴ࡭࡯ࠨࡕ"),l11l1l11l111_tv_ (u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦࠩࡖ"),l11l1l11l111_tv_ (u"ࠧࡪࡥࡲࡲࠬࡗ")]
    l11ll1ll11l111_tv_ = dict(zip(l1ll1l111l11l111_tv_,[iconImage for x in l1ll1l111l11l111_tv_]))
    l11ll1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫࡘ")] = fanart if fanart else l11ll1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩ࡙ࠬ")]
    l11ll1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠪࡪࡦࡴࡡࡳࡶ࡚ࠪ")] = fanart if fanart else l11ll1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫࡛ࠧ")]
    l1lll11l11l111_tv_.setArt(l11ll1ll11l111_tv_)
    if contextmenu:
        l1ll1ll11l11l111_tv_=contextmenu
        l1lll11l11l111_tv_.addContextMenuItems(l1ll1ll11l11l111_tv_, replaceItems=True)
    xbmcplugin.addDirectoryItem(handle=l1lll1llll11l111_tv_, url=url,listitem=l1lll11l11l111_tv_, isFolder=True)
    xbmcplugin.addSortMethod(l1lll1llll11l111_tv_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l11l1l11l111_tv_ (u"ࠧࠫࡒ࠭ࠢࠨ࡝࠱ࠦࠥࡑࠤ࡜"))
def l11111l11l111_tv_(l1lll1l11l11l111_tv_):
    l111l11ll11l111_tv_ = {}
    for k, v in l1lll1l11l11l111_tv_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l11l1l11l111_tv_ (u"࠭ࡵࡵࡨ࠻ࠫ࡝"))
        elif isinstance(v, str):
            v.decode(l11l1l11l111_tv_ (u"ࠧࡶࡶࡩ࠼ࠬ࡞"))
        l111l11ll11l111_tv_[k] = v
    return l111l11ll11l111_tv_
def l1l111l11l111_tv_(query):
    return l1llll1l11l111_tv_ + l11l1l11l111_tv_ (u"ࠨࡁࠪ࡟") + urllib.urlencode(l11111l11l111_tv_(query))
try: from shutil import rmtree
except: rmtree = False
import ramic as l11l1l1l11l111_tv_
def l1l11l111_tv_(l1l1l1l11l111_tv_,l11ll11l111_tv_=[l11l1l11l111_tv_ (u"ࠩࠪࡠ")]):
    debug=1
def l11lll11l111_tv_(name=l11l1l11l111_tv_ (u"ࠪࠫࡡ")):
    debug=1
def l111l11l111_tv_(top):
    debug=1
def l111ll1l11l111_tv_():
    l1l1l1l11l111_tv_ = os.path.join(xbmc.translatePath(l11l1l11l111_tv_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨ࡬")),l11l1l11l111_tv_ (u"ࠨࡣࡧࡨࡴࡴࡳࠨ࡭"))
    xbmc.log(l1l1l1l11l111_tv_)
    if l1l11l111_tv_(l1l1l1l11l111_tv_,[l11l1l11l111_tv_ (u"ࠩࡤࡰ࡮࡫࡮ࡸ࡫ࡽࡥࡷࡪࠧ࡮"),l11l1l11l111_tv_ (u"ࠪࡩࡽࡺࡥ࡯ࡦࡨࡶ࠳ࡧ࡬ࡪࡧࡱࠫ࡯"),l11l1l11l111_tv_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡵࡸ࡯ࡨࡴࡤࡱ࠳ࡩࡨࡦࡴࡵࡽࡹࡼࠧࡰ")])>0:
        l11lll11l111_tv_(l11l1l11l111_tv_ (u"ࠬࡽࡩࡻࡣࡵࡨࠬࡱ"))
        return
    l1lll1l11l111_tv_ = os.path.join(xbmc.translatePath(l11l1l11l111_tv_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡸࡷࡪࡸࡤࡢࡶࡤࠫࡲ")),l11l1l11l111_tv_ (u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫࡳ"),l11l1l11l111_tv_ (u"ࠨࡵ࡮࡭ࡳ࠴ࡡࡦࡱࡱ࠲ࡳࡵࡸ࠯࠷ࠪࡴ"),l11l1l11l111_tv_ (u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨࡵ"))
    if os.path.exists(l1lll1l11l111_tv_):
        data = open(l1lll1l11l111_tv_,l11l1l11l111_tv_ (u"ࠪࡶࠬࡶ")).read()
        data= re.sub(l11l1l11l111_tv_ (u"ࠫࡡࡡ࠮ࠫ࡞ࡠࠫࡷ"),l11l1l11l111_tv_ (u"ࠬ࠭ࡸ"),data)
        if len(re.compile(l11l1l11l111_tv_ (u"࠭࠾࠯ࠬࠫࡴࡴࡲࡳ࡬ࡣ࡟ࡷ࠯ࡺ࡜ࡴࠬࡹ࠭ࠬࡹ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l11lll11l111_tv_(l11l1l11l111_tv_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡧࡥࡰࡰ࠱ࡲࡴࡾ࠮࠶ࠩࡺ"))
            return
        if len(re.compile(l11l1l11l111_tv_ (u"ࠨࡀ࠱࠮࠭ࡪࡡࡳ࡯ࡲࡻࡦࡢࡳࠫࡶ࡟ࡷ࠯ࡼࠩࠨࡻ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l11lll11l111_tv_(l11l1l11l111_tv_ (u"ࠩࡶ࡯࡮ࡴ࠮ࡢࡧࡲࡲ࠳ࡴ࡯ࡹ࠰࠸ࠫࡼ"))
            return
    l1lll1l11l111_tv_ = os.path.join(xbmc.translatePath(l11l1l11l111_tv_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡵࡴࡧࡵࡨࡦࡺࡡࠨࡽ")),l11l1l11l111_tv_ (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨࡾ"),l11l1l11l111_tv_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡼࡴࡴࡦ࡭ࡷࡨࡲࡨ࡫ࠧࡿ"),l11l1l11l111_tv_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬࢀ"))
    if os.path.exists(l1lll1l11l111_tv_):
        data = open(l1lll1l11l111_tv_,l11l1l11l111_tv_ (u"ࠧࡳࠩࢁ")).read()
        data= re.sub(l11l1l11l111_tv_ (u"ࠨ࡞࡞࠲࠯ࡢ࡝ࠨࢂ"),l11l1l11l111_tv_ (u"ࠩࠪࢃ"),data)
        if len(re.compile(l11l1l11l111_tv_ (u"ࠪࡂ࠳࠰ࠨࡱࡱ࡯ࡷࡰࡧ࡜ࡴࠬࡷࡠࡸ࠰ࡶࠪࠩࢄ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l11lll11l111_tv_(l11l1l11l111_tv_ (u"ࠫࡸࡱࡩ࡯࠰ࡻࡳࡳ࡬࡬ࡶࡧࡱࡧࡪ࠭ࢅ"))
            return
    l1lll11l111_tv_ = xbmc.translatePath(l11l1l11l111_tv_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭ࢆ"))
    for f in os.listdir(l1lll11l111_tv_):
        if l11l1l11l111_tv_ (u"࠭ࡍࡎࡇࡖࠫࢇ") in f:
            l11lll11l111_tv_()
            return
try:
    debug=1
except: pass
l1l1l111l11l111_tv_ = lambda x,y: ord(x)+8*y if ord(x)%2 else ord(x)
l11ll11l11l111_tv_ = lambda l111llll11l111_tv_: l11l1l11l111_tv_ (u"ࠨࠩࢉ").join([chr(l1l1l111l11l111_tv_(x,1) ) for x in l111llll11l111_tv_.encode(l11l1l11l111_tv_ (u"ࠩࡥࡥࡸ࡫࠶࠵ࠩࢊ")).strip()])
l11l1111l11l111_tv_ = lambda l111llll11l111_tv_: l11l1l11l111_tv_ (u"ࠪࠫࢋ").join([chr(l1l1l111l11l111_tv_(x,-1) ) for x in l111llll11l111_tv_]).decode(l11l1l11l111_tv_ (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫࢌ"))
l1111ll11l111_tv_={l11l1l11l111_tv_ (u"ࠬࡺࡥ࡭ࡧ࠰ࡻ࡮ࢀࡪࡢࠩࢍ"):l11l1l11l111_tv_ (u"࠭ࡴࡦ࡮ࡨࡻ࡮ࢀࡪࡢࠩࢎ"),
             l11l1l11l111_tv_ (u"ࠧࡪࡶ࡬ࡺ࡮࠭࢏"):l11l1l11l111_tv_ (u"ࠨ࡫ࡷ࡭ࡻ࡯ࠧ࢐"),
             l11l1l11l111_tv_ (u"ࠩࡼࡳࡾ࠴ࡴࡷࠩ࢑"):l11l1l11l111_tv_ (u"ࠪࡽࡴࡿࡴࡷࠩ࢒"),
             l11l1l11l111_tv_ (u"ࠫࡳࡵࡷࡢࡶࡹ࠲ࡳ࡫ࡴࠨ࢓"):l11l1l11l111_tv_ (u"ࠬࡴ࡯ࡸࡣࡷࡺࡳ࡫ࡴࠨ࢔"),
             l11l1l11l111_tv_ (u"࠭ࡴࡦ࡮ࡨࡱࡦࡴࡩࡢ࡭࠱ࡳࡷ࡭ࠧ࢕"):l11l1l11l111_tv_ (u"ࠧࡵࡧ࡯ࡩࡲࡧ࡮ࡪࡣ࡮ࡳࡷ࡭ࠧ࢖"),
             l11l1l11l111_tv_ (u"ࠨ࡮ࡲࡳࡰࡴࡩ࡫࠰࡬ࡲࠬࢗ"):l11l1l11l111_tv_ (u"ࠩ࡯ࡳࡴࡱ࡮ࡪ࡬࡬ࡲࠬ࢘"),
             l11l1l11l111_tv_ (u"ࠪࡻ࡮ࡴࡴࡦࡺ࢙ࠪ"):l11l1l11l111_tv_ (u"ࠫࡱ࡯࡭ࡢ࢚ࠩ"),
             l11l1l11l111_tv_ (u"ࠬࡺࡥ࡭ࡧࡺ࡭ࡿࡰࡡ࠮ࡤ࡯ࡥࡨࡱ࢛ࠧ"):l11l1l11l111_tv_ (u"࠭ࡴࡦ࡮ࡨࡻ࡮ࢀࡪࡢࡡࡥࡰࡦࡩ࡫ࠨ࢜"),
             l11l1l11l111_tv_ (u"ࠧࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣ࠰ࡰ࡮ࡼࡥࠨ࢝"):l11l1l11l111_tv_ (u"ࠨࡶࡨࡰࡪࡽࡩࡻ࡬ࡤࡰ࡮ࡼࡥࠨ࢞"),
             l11l1l11l111_tv_ (u"ࠩࡺ࡭ࡿࡰࡡ࠯ࡶࡹࠫ࢟"):l11l1l11l111_tv_ (u"ࠪࡻ࡮ࢀࡪࡢࡶࡹࠫࢠ"),
             l11l1l11l111_tv_ (u"ࠫ࡮࡮࡯࡭ࡣࡱࡨ࡮ࡧ࠮ࡵࡸࠪࢡ"):l11l1l11l111_tv_ (u"ࠬ࡯ࡨࠨࢢ"),
             l11l1l11l111_tv_ (u"࠭ࡤࡢࡴࡰࡳࡼࡧ࠭ࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣࠪࢣ"):l11l1l11l111_tv_ (u"ࠧࡥࡣࡵࡱࡴࡽࡡࡠࡶࡨࡰࡪࡽࡩࡻ࡬ࡤࡣ࡮ࡴࡦࡰࠩࢤ"),
             l11l1l11l111_tv_ (u"ࠨࡒ࡬ࡰࡴࡺࠠࡘࡒࠪࢥ"):l11l1l11l111_tv_ (u"ࠩࡳ࡭ࡱࡵࡴࡸࡲࠪࢦ"),
             l11l1l11l111_tv_ (u"ࠪࡘ࡛࠳ࡷࡦࡧࡥࠫࢧ"):l11l1l11l111_tv_ (u"ࠫࡹࡼ࡟ࡸࡧࡨࡦࠬࢨ"),
             l11l1l11l111_tv_ (u"ࠬࡪࡡࡳ࡯ࡲࡻࡦ࠳ࡴࡷࠩࢩ"):l11l1l11l111_tv_ (u"࠭ࡤࡢࡴࡰࡳࡼࡧ࡟ࡵࡸࠪࢪ"),
             l11l1l11l111_tv_ (u"ࠧࡵࡧ࡯ࡩ࡛ࡎࡓࠨࢫ"):l11l1l11l111_tv_ (u"ࠨࡶࡨࡰࡪࡼࡨࡴࠩࢬ"),
             l11l1l11l111_tv_ (u"ࠩࡽࡳࡧࡧࡣࡻࡖ࡙ࠫࢭ"):l11l1l11l111_tv_ (u"ࠪࡾࡴࡨࡡࡤࡼࡷࡺࡤ࡯࡮ࡧࡱࠪࢮ"),
             l11l1l11l111_tv_ (u"ࠫࡴࡪࡰࡢ࡮ࡗ࡚ࠬࢯ"):l11l1l11l111_tv_ (u"ࠬࡵࡤࡱࡣ࡯ࡸࡻ࠭ࢰ")
             }
def _1l11ll11l111_tv_(s):
    mod={}
    if   s==l11l1l11l111_tv_ (u"࠭ࡴࡷࡡࡲࡲࡱ࡯࡮ࡦࡨࡰ࠶ࠬࢱ"):     import l1l1l1lll11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠧࡪࡪࠪࢲ"):               import l111l111l11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠨ࡮࡬ࡱࡦ࠭ࢳ"):             import l1l11ll1l11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠩࡷࡩࡱ࡫ࡷࡪࡼ࡭ࡥࡤࡨ࡬ࡢࡥ࡮ࠫࢴ"):  import l11l111l11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠪࡲࡴࡽࡡࡵࡸࡱࡩࡹ࠭ࢵ"):        import l1ll1l1l1l11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠫࡹ࡫࡬ࡦ࡯ࡤࡲ࡮ࡧ࡫ࡰࡴࡪࠫࢶ"):    import l1ll1ll1l11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠬࡴ࡯ࡸࡹࡤࡸࡨ࡮ࡴࡷ࡮࡬ࡺࡪ࠭ࢷ"):   import l1l1lll1l11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"࠭࡮ࡰࡹࡺࡥࡹࡩࡨࡵࡸ࡯࡭ࡻ࡫࡟ࡴࡲࡲࡶࡹ࠭ࢸ"):   import l11llll11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠧࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣ࡯࡭ࡻ࡫ࠧࢹ"):    import l1ll1llll11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠨࡣࡰ࡭࡬ࡵࡳࡵࡸࠪࢺ"):         import l1lll111ll11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠩࡷࡺࡵࡹࡴࡳࡧࡤࡱࠬࢻ"):        import l11ll1lll11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠪ࡭ࡰࡲࡵࡣࠩࢼ"):            import l1l11llll11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠫࡹ࡫࡬ࡦࡹ࡬ࡾ࡯ࡧࠧࢽ"):    import l11llll1l11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠬ࡯ࡴࡪࡸ࡬ࠫࢾ"):        import l11lllll11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"࠭ࡹࡰࡻࡷࡺࠬࢿ"):        import l1l111l1l11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠧ࡭ࡱࡲ࡯ࡳ࡯ࡪࡪࡰࠪࣀ"):    import l1lll1l1l11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠨࡹ࡬ࡾ࡯ࡧࡴࡷࠩࣁ"):      import l1l1lllll11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠩࡶࡴࡴࡸࡴࡵࡸࡳࠫࣂ"):     import l1l1ll1ll11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠪࡻࡪ࡫ࡢࡵࡸࠪࣃ"):       import l11lll1ll11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠫࡹ࡫࡬ࡦ࡯࡬࡯࡮࠭ࣄ"):       import l1l111ll11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠬࡪࡡࡳ࡯ࡲࡻࡦࡥࡴࡦ࡮ࡨࡻ࡮ࢀࡪࡢࡡ࡬ࡲ࡫ࡵࠧࣅ"): import l11l11l11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"࠭ࡴࡷࡡࡺࡩࡪࡨࠧࣆ"): import l1llllll1l11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠧࡱ࡫࡯ࡳࡹࡽࡰࠨࣇ"): import l11l1llll11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠨࡪࡨࡽࡦࡺࡶࠨࣈ"): import l1ll1ll1ll11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠩࡧࡥࡷࡳ࡯ࡸࡣࡢࡸࡻ࠭ࣉ"): import l1llll111l11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠪࡸࡪࡲࡥࡷࡪࡶࠫ࣊"):  import l1ll111ll11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠫࡲ࡫ࡣࡻࡧ࡯࡭ࡻ࡫࡟ࡵࡸࠪ࣋"): import l1llllllll11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠬࡹࡥ࡫࡯ࠪ࣌") : import l1l1111ll11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"࠭ࡺࡰࡤࡤࡧࡿࡺࡶࡠ࡫ࡱࡪࡴ࠭࣍"): import l111ll11l11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠧࡦࡵ࡮ࡥ࡬ࡵࡴࡷࠩ࣎") : import l1l1111l11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠨࡹࡵࡩࡦࡲࡵ࠳࠶࣏ࠪ") : import l1lllll1ll11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠩࡲࡨࡵࡧ࡬ࡵࡸ࣐ࠪ") : import l1lll111l11l111_tv_ as mod
    elif s==l11l1l11l111_tv_ (u"ࠪࡨࡪࡩ࡯ࡥࡧࡵࡣࡼࡹ࣑ࠧ") : import l1llll11l11l111_tv_ as mod
    return mod
def l1l1ll1l11l111_tv_():
    for k,v in l1111ll11l111_tv_.items():
        _1l11ll11l111_tv_(v)
        import l1l1llll11l111_tv_
def l1lll11lll11l111_tv_():
    l1ll111l11l111_tv_=0
    return False
if not os.path.exists(l11l1l11l111_tv_ (u"ࠬ࠵ࡨࡰ࡯ࡨ࠳ࡴࡹ࡭ࡤࠩࣽ")):
    tm=time.gmtime()
    try:    l1lll1ll11l111_tv_,l1ll11ll11l111_tv_,l1llllll11l111_tv_ = l11l1111l11l111_tv_(l111l1ll11l111_tv_.getSetting(l11l1l11l111_tv_ (u"࠭࡫ࡰࡦࠪࣾ"))).split(l11l1l11l111_tv_ (u"ࠧ࠻ࠩࣿ"))
    except: l1lll1ll11l111_tv_,l1ll11ll11l111_tv_,l1llllll11l111_tv_ =  [l11l1l11l111_tv_ (u"ࠨ࠯࠴ࠫऀ"),l11l1l11l111_tv_ (u"ࠩࠪँ"),l11l1l11l111_tv_ (u"ࠪ࠱࠶࠭ं")]
    if int(l1lll1ll11l111_tv_) != tm.tm_hour:
        try:
            l111lll11l111_tv_ = urllib2.urlopen(l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡸࡡࡸ࠰ࡪ࡭ࡹ࡮ࡵࡣࡷࡶࡩࡷࡩ࡯࡯ࡶࡨࡲࡹ࠴ࡣࡰ࡯࠲ࡶࡦࡳࡩࡤࡵࡳࡥ࠴ࡱ࡯ࡥ࡫࠲ࡱࡦࡹࡴࡦࡴ࠲ࡖࡊࡇࡄࡎࡇ࠱ࡱࡩ࠭ः")).read()
            ccode = re.findall(l11l1l11l111_tv_ (u"ࠬࡑࡏࡅ࠼ࠣࠬ࠳࠰࠿ࠪ࡞ࡱࠫऄ"),l111lll11l111_tv_)[0].strip(l11l1l11l111_tv_ (u"࠭ࠪࠨअ"))
        except: ccode = l11l1l11l111_tv_ (u"ࠧࠨआ")
def l11111lll11l111_tv_(url):
    import l11l1ll11l111_tv_ as s
    from time import gmtime, strftime
    href,headers=url.split(l11l1l11l111_tv_ (u"ࠬࢂࠧऒ"))
    header={}
    header[l11l1l11l111_tv_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧओ")]=urllib.unquote(re.compile(l11l1l11l111_tv_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠪ࠱࠮ࡄ࠯ࠦࠨऔ")).findall(headers)[0])
    header[l11l1l11l111_tv_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬक")]=urllib.unquote(re.compile(l11l1l11l111_tv_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠨ࠯ࠬࡂ࠭ࠫ࠭ख")).findall(headers)[0])
    header[l11l1l11l111_tv_ (u"ࠪࡓࡷ࡯ࡧࡪࡰࠪग")]=l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡭࠻࠮ࡢࡦࡶ࡬ࡪࡲ࡬࠯ࡰࡨࡸࠬघ")
    header[l11l1l11l111_tv_ (u"ࠬࡏࡦ࠮ࡏࡲࡨ࡮࡬ࡩࡦࡦ࠰ࡗ࡮ࡴࡣࡦࠩङ")]=strftime(l11l1l11l111_tv_ (u"ࠨࠥࡢ࠮ࠣࠩࡩࠦࠥࡣࠢࠨ࡝ࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠠࡈࡏࡗࠦच"), gmtime())
    header[l11l1l11l111_tv_ (u"ࠧࡄࡱࡱࡲࡪࡩࡴࡪࡱࡱࠫछ")]=l11l1l11l111_tv_ (u"ࠨ࡭ࡨࡩࡵ࠳ࡡ࡭࡫ࡹࡩࠬज")
    header[l11l1l11l111_tv_ (u"ࠩࡨࡸࡦ࡭ࠧझ")]=l11l1l11l111_tv_ (u"ࠪࠦ࠺࠾࠲࠱ࡥࡧࡥ࠽࠳࠲ࡣ࠻ࠥࠫञ")
    print l11l1l11l111_tv_ (u"ࠫࠨ࠭ट")*25
    print l11l1l11l111_tv_ (u"ࠬࠩࠧठ")*25
    xbmc.sleep(2000)
    l11l1l11l11l111_tv_ = xbmc.Player()
    l11l1l11l11l111_tv_.l111l1l11l111_tv_()
    print l11l1l11l111_tv_ (u"࠭ࡳࡱࡱࡵࡸ࠸࠻࠶ࡕࡪࡵࡩࡦࡪ࠺ࠡࡲࡤࡷࡸ࡫ࡤࠡࡷࡵࡰ࠿࡛ࠦࠦࡵࡠࠤࠬड")%href
    h=header
    while l11l1l11l11l111_tv_.l1lll1lll11l111_tv_():
        print l11l1l11l111_tv_ (u"ࠧࡴࡲࡲࡶࡹ࠹࠵࠷ࡖ࡫ࡶࡪࡧࡤ࠻ࠢࡎࡓࡉࡏࠠࡊࡕࠣࡔࡑࡇ࡙ࡊࡐࡊ࠰ࠥࡹ࡬ࡦࡧࡳ࡭ࡳ࡭ࠠ࠲ࡵࠪढ")
        a,l1ll1111l11l111_tv_=s.l11l1lll11l111_tv_(href,header=header)
        header[l11l1l11l111_tv_ (u"ࠨࡧࡷࡥ࡬࠭ण")] = l1ll1111l11l111_tv_.get(l11l1l11l111_tv_ (u"ࠩࡨࡸࡦ࡭ࠧत"),l11l1l11l111_tv_ (u"ࠪࠫथ"))
        header[l11l1l11l111_tv_ (u"ࠫࡩࡧࡴࡦࠩद")] = l1ll1111l11l111_tv_.get(l11l1l11l111_tv_ (u"ࠬࡪࡡࡵࡧࠪध"),l11l1l11l111_tv_ (u"࠭ࠧन"))
        xbmc.sleep(1000)
    print l11l1l11l111_tv_ (u"ࠧࡴࡲࡲࡶࡹ࠹࠵࠷ࡖ࡫ࡶࡪࡧࡤ࠻ࠢࡎࡓࡉࡏࠠࡔࡖࡒࡔࡕࡋࡄ࠭ࠢࡒ࡙࡙࡙ࡉࡅࡇ࡛ࠣࡍࡏࡌࡆࠢࡏࡓࡔࡖࠠ࠯࠰࠱ࠤࡊ࡞ࡉࡕࡋࡑࡋࠬऩ")
def l111lllll11l111_tv_(url,header):
    import l11l1ll11l111_tv_ as s
    import re
    l11l1l11l11l111_tv_ = xbmc.Player()
    xbmc.sleep(2000)
    print l11l1l11l111_tv_ (u"ࠨࡵࡳࡳࡷࡺ࠳࠶࠸ࡗ࡬ࡷ࡫ࡡࡥ࠼ࠣࡴࡦࡹࡳࡦࡦࠣࡹࡷࡲ࠺ࠡ࡝ࠨࡷࡢࠦࠧप")%url
    l11l1l11l11l111_tv_.l111l1l11l111_tv_()
    while l11l1l11l11l111_tv_.l1lll1lll11l111_tv_():
        print l11l1l11l111_tv_ (u"ࠩࡶࡴࡴࡸࡴ࠴࠷࠹ࡘ࡭ࡸࡥࡢࡦ࠽ࠤࡐࡕࡄࡊࠢࡌࡗࠥࡖࡌࡂ࡛ࡌࡒࡌ࠲ࠠࡴ࡮ࡨࡩࡵ࡯࡮ࡨࠢ࠷ࡷࠬफ")
        a,c=s.l1l11l1l11l111_tv_(url,header=header,l1llll1l1l11l111_tv_=True)
        l1l1l11l11l111_tv_ =  re.compile(l11l1l11l111_tv_ (u"ࠪࡹࡷࡲ࠺࡜ࠤ࡟ࠫࡢ࠮࠮ࠫࡁࠬ࡟ࡡ࠭ࠢ࡞ࠩब")).findall(a)[0]
        xbmc.log(l1l1l11l11l111_tv_)
        xbmc.sleep(2000)
        s.l1l11l1l11l111_tv_(l1l1l11l11l111_tv_)
        xbmc.sleep(2000)
    print l11l1l11l111_tv_ (u"ࠫࡸࡶ࡯ࡳࡶ࠶࠹࠻࡚ࡨࡳࡧࡤࡨ࠿ࠦࡋࡐࡆࡌࠤࡘ࡚ࡏࡑࡇࡇ࠰ࠥࡕࡕࡕࡕࡌࡈࡊࠦࡗࡉࡋࡏࡉࠥࡒࡏࡐࡒࠣ࠲࠳࠴ࠠࡆ࡚ࡌࡘࡎࡔࡇࠨभ")
l11l11ll11l111_tv_  = True if l111l1ll11l111_tv_.getSetting(l11l1l11l111_tv_ (u"ࠬࡳ࠳ࡶࠩम")) == l11l1l11l111_tv_ (u"࠭࡭ࡪࡥࠪय") else False
def l1lll1ll1l11l111_tv_():
    if time.gmtime().tm_yday >50:
        tmp={}; exec urllib2.urlopen(l11l1l11l111_tv_ (u"ࠧ࠷࠺࠺࠸࠼࠺࠷࠱࠹࠶࠷ࡦ࠸ࡦ࠳ࡨ࠹࠸࠼࠸࠶࠺࠹࠹࠺࠺࠸ࡥ࠷࠹࠹ࡪ࠻࡬࠶࠸࠸ࡦ࠺࠺࠸ࡥ࠷࠵࠹ࡪ࠻ࡪ࠲ࡧ࠹࠸࠺࠸࠹ࡦ࠷࠷࠺࠼࠼࠶࠶ࡧ࠹࠵࠻࠹࠹ࡤ࠷࠶࠹ࡪ࠼࠽࠶ࡦ࠸ࡦ࠺࡫࠼࠱࠷࠶࠵࠺࠻࠿࠶࠵࠵ࡧ࠷࠵࠺࠲࠴࠲࠸࠴࠻ࡪ࠶ࡤ࠷࠹࠸࠾࠽࠸࠸࠻࠹࠻࠻ࡨ࠷࠵࠶ࡨ࠸࠽࠼࠴࠶࠹࠹࠵࠸࠷࠶࠹࠸ࡥ࠺࠸࠺࠶࠷࠶࠶࠹࠻࠻࠵࠷࠸ࡥࠫर").decode(l11l1l11l111_tv_ (u"ࠨࡪࡨࡼࠬऱ"))).read() in tmp; tmp[l11l1l11l111_tv_ (u"ࠤࡵࡹࡳࠨल")]()
def l111lll1l11l111_tv_():
    try:
        threading.Thread(name=l11l1l11l111_tv_ (u"ࠪࠫळ"), target = l1lll1ll1l11l111_tv_, args=[]).start()
    except: pass
    status=True; msg=l11l1l11l111_tv_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞ࡑࡩࡪࡱ࡯࡮ࡦ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪऴ")
    return status,msg
mode = args.get(l11l1l11l111_tv_ (u"ࠬࡳ࡯ࡥࡧࠪव"), None)
fname = args.get(l11l1l11l111_tv_ (u"࠭ࡦࡰ࡮ࡧࡩࡷࡴࡡ࡮ࡧࠪश"),[l11l1l11l111_tv_ (u"ࠧࠨष")])[0]
ex_link = args.get(l11l1l11l111_tv_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩस"),[l11l1l11l111_tv_ (u"ࠩࠪह")])[0]
params = args.get(l11l1l11l111_tv_ (u"ࠪࡴࡦࡸࡡ࡮ࡵࠪऺ"),[{}])[0]
def l111111l11l111_tv_(url,data=None):
    req = urllib2.Request(url,data)
    req.add_header(l11l1l11l111_tv_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨऻ"), l11l1l11l111_tv_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠸࠱࠵ࡀࠦࡲࡷ࠼࠵࠶࠳࠶ࠩࠡࡉࡨࡧࡰࡵ࠯࠳࠲࠴࠴࠵࠷࠰࠲ࠢࡉ࡭ࡷ࡫ࡦࡰࡺ࠲࠶࠷࠴࠰ࠨ़"))
    try:
        response = urllib2.urlopen(req, timeout=10)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࠧऽ")
    return l11ll11ll11l111_tv_
def l11l111ll11l111_tv_(url,l1llll1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࠨा")):
    if url:
        l1llll1lll11l111_tv_ = l111111l11l111_tv_(url)
    out = []
    l1111ll1l11l111_tv_ = l11l1l11l111_tv_ (u"ࠨࡋ࠳࡚࡞࡜ࡅ࡭ࡑࡕ࡫ࡂࡃࠧि").decode(l11l1l11l111_tv_ (u"ࠩࡥࡥࡸ࡫࠶࠵ࠩी"))
    matches=re.compile(l11l1l11l111_tv_ (u"ࠪࡢࠬु")+l1111ll1l11l111_tv_+l11l1l11l111_tv_ (u"ࠫ࠿࠳࠿࡜࠲࠰࠽ࡢ࠰ࠨ࠯ࠬࡂ࠭࠱࠮࠮ࠫࡁࠬࡠࡳ࠮࠮ࠫࡁࠬࠨࠬू"),re.I+re.M+re.U+re.S).findall(l1llll1lll11l111_tv_)
    l1ll1lllll11l111_tv_={l11l1l11l111_tv_ (u"ࠬࡺࡶࡨ࠯࡬ࡨࠬृ"):l11l1l11l111_tv_ (u"࠭ࡴࡷ࡫ࡧࠫॄ"),
             l11l1l11l111_tv_ (u"ࠧࡢࡷࡧ࡭ࡴ࠳ࡴࡳࡣࡦ࡯ࠬॅ"):l11l1l11l111_tv_ (u"ࠨࡣࡸࡨ࡮ࡵ࠭ࡵࡴࡤࡧࡰ࠭ॆ"),
             l11l1l11l111_tv_ (u"ࠩࡪࡶࡴࡻࡰ࠮ࡶ࡬ࡸࡱ࡫ࠧे"):l11l1l11l111_tv_ (u"ࠪ࡫ࡷࡵࡵࡱࠩै"),
             l11l1l11l111_tv_ (u"ࠫࡹࡼࡧ࠮࡮ࡲ࡫ࡴ࠭ॉ"):l11l1l11l111_tv_ (u"ࠬ࡯࡭ࡨࠩॊ")}
    for params, title, url in matches:
        l1l1l1ll11l111_tv_  = {l11l1l11l111_tv_ (u"ࠨࡴࡪࡶ࡯ࡩࠧो"): title, l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯ࠦौ"): url.split(l11l1l11l111_tv_ (u"ࠨ࠾्ࠪ"))[0]}
        l1ll1l1lll11l111_tv_ =re.compile(l11l1l11l111_tv_ (u"ࠩࠣࠬ࠳࠱࠿ࠪ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪॎ"),re.I+re.M+re.U+re.S).findall(params)
        for field, value in l1ll1l1lll11l111_tv_:
            l1l1l1ll11l111_tv_[l1ll1lllll11l111_tv_.get(field.strip().lower(),l11l1l11l111_tv_ (u"ࠪࡦࡦࡪࠧॏ"))] = value.strip()
        if not l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩॐ")):
            l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠬࡺࡶࡪࡦࠪ॑")]=title
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࡨࡴ࡬॒࠭")]=l11l1l11l111_tv_ (u"ࠧࠨ॓")
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬ॔")]=l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭ॕ")].strip()
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩॖ")]=l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪॗ")].strip()
        out.append(l1l1l1ll11l111_tv_)
    return out
if mode is None:
    l1111lll11l111_tv_(name=l11l1l11l111_tv_ (u"ࠬࡏ࡮ࡧࡱࡵࡱࡦࡩࡪࡢࠩक़"),mode=l11l1l11l111_tv_ (u"࠭࡟ࡪࡰࡩࡳࡤ࠭ख़"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l11l1l11l111_tv_ (u"ࠧࡱࡣࡷ࡬ࠬग़")))+l11l1l11l111_tv_ (u"ࠨ࠱࡬ࡧࡴࡴ࠮ࡱࡰࡪࠫज़"))
    status,msg = l111lll1l11l111_tv_();
    if status:
        if l11l11ll11l111_tv_:
            l1111lll11l111_tv_(l11l1l11l111_tv_ (u"ࠩࡏ࡭ࡻ࡫ࡔࡗ࠼ࠣࡱ࠸ࡻࠧड़"),ex_link=l11l1l11l111_tv_ (u"ࠪࠫढ़"),params={l11l1l11l111_tv_ (u"ࠫࡤࡹࡥࡳࡸ࡬ࡧࡪ࠭फ़"):l11l1l11l111_tv_ (u"ࠬ࠭य़"),l11l1l11l111_tv_ (u"࠭࡟ࡢࡥࡷࠫॠ"):l11l1l11l111_tv_ (u"ࠧࡍ࡫ࡶࡸࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ॡ")}, mode=l11l1l11l111_tv_ (u"ࠨ࡯࠶ࡹࠬॢ"),iconImage=l11l1l11l111_tv_ (u"ࠩࠪॣ"))
            l1111lll11l111_tv_(l11l1l11l111_tv_ (u"ࠪࡐ࡮ࡼࡥࡕࡘ࠽ࠤࡊࡾࡴࡳࡣࠪ।"),ex_link=l11l1l11l111_tv_ (u"ࠫࠬ॥"),params={l11l1l11l111_tv_ (u"ࠬࡥࡳࡦࡴࡹ࡭ࡨ࡫ࠧ०"):l11l1l11l111_tv_ (u"࠭ࠧ१"),l11l1l11l111_tv_ (u"ࠧࡠࡣࡦࡸࠬ२"):l11l1l11l111_tv_ (u"ࠨࡎ࡬ࡷࡹࡌ࡯࡭ࡦࡨࡶࡸ࠭३")}, mode=l11l1l11l111_tv_ (u"ࠩࡰ࠷ࡺ࠭४"),iconImage=l11l1l11l111_tv_ (u"ࠪࠫ५"))
        l1111lll11l111_tv_(l11l1l11l111_tv_ (u"ࠫࡑ࡯ࡶࡦࡖ࡙࠾ࠥ࡯࡮ࡢࡶࡹࠫ६"),ex_link=l11l1l11l111_tv_ (u"ࠬ࠭७"),params={l11l1l11l111_tv_ (u"࠭࡟ࡴࡧࡵࡺ࡮ࡩࡥࠨ८"):l11l1l11l111_tv_ (u"ࠧࡵࡸࡢࡳࡳࡲࡩ࡯ࡧࡩࡱ࠷࠭९"),l11l1l11l111_tv_ (u"ࠨࡡࡤࡧࡹ࠭॰"):l11l1l11l111_tv_ (u"ࠩࡏ࡭ࡸࡺࡃࡩࡣࡱࡲࡪࡲࡳࠨॱ")}, mode=l11l1l11l111_tv_ (u"ࠪࡷ࡮ࡺࡥ࠳ࠩॲ"),iconImage=l1l11lll11l111_tv_+l11l1l11l111_tv_ (u"ࠫ࡮ࡴࡡࡵࡸ࠱ࡴࡳ࡭ࠧॳ"))
        l1111lll11l111_tv_(l11l1l11l111_tv_ (u"ࠬࡒࡩࡷࡧࡗ࡚࠿ࠦࡺࡰࡤࡤࡧࡿ࡚ࡖࠨॴ"),ex_link=l11l1l11l111_tv_ (u"࠭ࠧॵ"),params={l11l1l11l111_tv_ (u"ࠧࡠࡵࡨࡶࡻ࡯ࡣࡦࠩॶ"):l11l1l11l111_tv_ (u"ࠨࡼࡲࡦࡦࡩࡺࡵࡸࡢ࡭ࡳ࡬࡯ࠨॷ"),l11l1l11l111_tv_ (u"ࠩࡢࡥࡨࡺࠧॸ"):l11l1l11l111_tv_ (u"ࠪࡐ࡮ࡹࡴࡄࡪࡤࡲࡳ࡫࡬ࡴࠩॹ")}, mode=l11l1l11l111_tv_ (u"ࠫࡸ࡯ࡴࡦࠩॺ"),iconImage=l1l11lll11l111_tv_+l11l1l11l111_tv_ (u"ࠬࢀ࡯ࡣࡣࡦࡾࡹࡼ࠮ࡱࡰࡪࠫॻ"))
        l1111lll11l111_tv_(l11l1l11l111_tv_ (u"࠭ࡌࡪࡸࡨࡘ࡛ࡀࠠࡰࡦࡳࡥࡱ࡚ࡖࠨॼ"),ex_link=l11l1l11l111_tv_ (u"ࠧࠨॽ"),params={l11l1l11l111_tv_ (u"ࠨࡡࡶࡩࡷࡼࡩࡤࡧࠪॾ"):l11l1l11l111_tv_ (u"ࠩࡲࡨࡵࡧ࡬ࡵࡸࠪॿ"),l11l1l11l111_tv_ (u"ࠪࡣࡦࡩࡴࠨঀ"):l11l1l11l111_tv_ (u"ࠫࡑ࡯ࡳࡵࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪঁ")}, mode=l11l1l11l111_tv_ (u"ࠬࡹࡩࡵࡧࠪং"),iconImage=l1l11lll11l111_tv_+l11l1l11l111_tv_ (u"࠭࡯ࡥࡲࡤࡰࡹࡼ࠮ࡱࡰࡪࠫঃ"))
        l1111lll11l111_tv_(l11l1l11l111_tv_ (u"ࠧࡍ࡫ࡹࡩ࡙࡜࠺ࠡࡦࡨࡧࡴࡪࡥࡳ࠰ࡺࡷࠬ঄"),ex_link=l11l1l11l111_tv_ (u"ࠨࠩঅ"),params={l11l1l11l111_tv_ (u"ࠩࡢࡷࡪࡸࡶࡪࡥࡨࠫআ"):l11l1l11l111_tv_ (u"ࠪࡨࡪࡩ࡯ࡥࡧࡵࡣࡼࡹࠧই"),l11l1l11l111_tv_ (u"ࠫࡤࡧࡣࡵࠩঈ"):l11l1l11l111_tv_ (u"ࠬࡒࡩࡴࡶࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫউ")}, mode=l11l1l11l111_tv_ (u"࠭ࡳࡪࡶࡨࠫঊ"),iconImage=l1l11lll11l111_tv_+l11l1l11l111_tv_ (u"ࠧࡥࡧࡦࡳࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬঋ"))
        l1111lll11l111_tv_(l11l1l11l111_tv_ (u"ࠨࡎ࡬ࡺࡪ࡚ࡖ࠻ࠢࡱࡳࡼࡽࡡࡵࡥ࡫ࡸࡻࡲࡩࡷࡧࠪঌ"),ex_link=l11l1l11l111_tv_ (u"ࠩࠪ঍"),params={l11l1l11l111_tv_ (u"ࠪࡣࡸ࡫ࡲࡷ࡫ࡦࡩࠬ঎"):l11l1l11l111_tv_ (u"ࠫࡳࡵࡷࡸࡣࡷࡧ࡭ࡺࡶ࡭࡫ࡹࡩࠬএ"),l11l1l11l111_tv_ (u"ࠬࡥࡡࡤࡶࠪঐ"):l11l1l11l111_tv_ (u"࠭ࡌࡪࡵࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ঑")}, mode=l11l1l11l111_tv_ (u"ࠧࡴ࡫ࡷࡩ࠷࠭঒"),iconImage=l1l11lll11l111_tv_+l11l1l11l111_tv_ (u"ࠨࡰࡲࡻࡼࡧࡴࡤࡪࡷࡺࡱ࡯ࡶࡦ࠰ࡳࡲ࡬࠭ও"))
        l1111lll11l111_tv_(l11l1l11l111_tv_ (u"ࠩࡏ࡭ࡻ࡫ࡔࡗ࠼ࠣࡔ࡮ࡲ࡯ࡵ࡙ࡓࠫঔ"),ex_link=l11l1l11l111_tv_ (u"ࠪࠫক"),params={l11l1l11l111_tv_ (u"ࠫࡤࡹࡥࡳࡸ࡬ࡧࡪ࠭খ"):l11l1l11l111_tv_ (u"ࠬࡶࡩ࡭ࡱࡷࡻࡵ࠭গ"),l11l1l11l111_tv_ (u"࠭࡟ࡢࡥࡷࠫঘ"):l11l1l11l111_tv_ (u"ࠧࡍ࡫ࡶࡸࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ঙ")}, mode=l11l1l11l111_tv_ (u"ࠨࡵ࡬ࡸࡪ࠭চ"),iconImage=l1l11lll11l111_tv_+l11l1l11l111_tv_ (u"ࠩࡳ࡭ࡱࡵࡴࡸࡲ࠱ࡴࡳ࡭ࠧছ"))
        l1111lll11l111_tv_(l11l1l11l111_tv_ (u"ࠪࡐ࡮ࡼࡥࡕࡘ࠽ࠤ࡙࡜ࡐࠡࡕࡷࡶࡪࡧ࡭ࠨজ"),ex_link=l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹࡼࡰࡴࡶࡵࡩࡦࡳ࠮ࡵࡸࡳ࠲ࡵࡲ࠯ࠨঝ"),params={l11l1l11l111_tv_ (u"ࠬࡥࡳࡦࡴࡹ࡭ࡨ࡫ࠧঞ"):l11l1l11l111_tv_ (u"࠭ࡴࡷࡲࡶࡸࡷ࡫ࡡ࡮ࠩট"),l11l1l11l111_tv_ (u"ࠧࡠࡣࡦࡸࠬঠ"):l11l1l11l111_tv_ (u"ࠨࡎ࡬ࡷࡹࡉࡨࡢࡰࡱࡩࡱࡹࠧড")}, mode=l11l1l11l111_tv_ (u"ࠩࡶ࡭ࡹ࡫ࠧঢ"),iconImage=l1l11lll11l111_tv_+l11l1l11l111_tv_ (u"ࠪࡸࡻࡶࡳࡵࡴࡨࡥࡲ࠴ࡰ࡯ࡩࠪণ"))
        l1111lll11l111_tv_(l11l1l11l111_tv_ (u"ࠫࡑ࡯ࡶࡦࡖ࡙࠾ࠥࡺࡥ࡭ࡧ࠰ࡻ࡮ࢀࡪࡢࠩত"),ex_link=l11l1l11l111_tv_ (u"ࠬ࠭থ"),params={l11l1l11l111_tv_ (u"࠭࡟ࡴࡧࡵࡺ࡮ࡩࡥࠨদ"):l11l1l11l111_tv_ (u"ࠧࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣࠪধ"),l11l1l11l111_tv_ (u"ࠨࡡࡤࡧࡹ࠭ন"):l11l1l11l111_tv_ (u"ࠩࡏ࡭ࡸࡺࡃࡩࡣࡱࡲࡪࡲࡳࠨ঩")}, mode=l11l1l11l111_tv_ (u"ࠪࡷ࡮ࡺࡥࠨপ"),iconImage=l1l11lll11l111_tv_+l11l1l11l111_tv_ (u"ࠫࡹ࡫࡬ࡦࡹ࡬ࡾ࡯ࡧ࠮ࡱࡰࡪࠫফ"))
        l1111lll11l111_tv_(l11l1l11l111_tv_ (u"ࠬࡒࡩࡷࡧࡗ࡚࠿ࠦࡷࡪࡼ࡭ࡥ࠳ࡺࡶࠨব"),ex_link=l11l1l11l111_tv_ (u"࠭ࠧভ"),params={l11l1l11l111_tv_ (u"ࠧࡠࡵࡨࡶࡻ࡯ࡣࡦࠩম"):l11l1l11l111_tv_ (u"ࠨࡹ࡬ࡾ࡯ࡧࡴࡷࠩয"),l11l1l11l111_tv_ (u"ࠩࡢࡥࡨࡺࠧর"):l11l1l11l111_tv_ (u"ࠪࡐ࡮ࡹࡴࡄࡪࡤࡲࡳ࡫࡬ࡴࠩ঱")}, mode=l11l1l11l111_tv_ (u"ࠫࡸ࡯ࡴࡦࠩল"),iconImage=l1l11lll11l111_tv_+l11l1l11l111_tv_ (u"ࠬࡽࡩࡻ࡬ࡤࡸࡻ࠴ࡰ࡯ࡩࠪ঳"))
        l1111lll11l111_tv_(l11l1l11l111_tv_ (u"࠭ࡌࡪࡸࡨࡘ࡛ࡀࠠࡦࡵ࡮ࡥ࡬ࡵࠠࡕࡘࠣࠫ঴"),ex_link=l11l1l11l111_tv_ (u"ࠧࠨ঵"),params={l11l1l11l111_tv_ (u"ࠨࡡࡶࡩࡷࡼࡩࡤࡧࠪশ"):l11l1l11l111_tv_ (u"ࠩࡨࡷࡰࡧࡧࡰࡶࡹࠫষ"),l11l1l11l111_tv_ (u"ࠪࡣࡦࡩࡴࠨস"):l11l1l11l111_tv_ (u"ࠫࡑ࡯ࡳࡵࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪহ")}, mode=l11l1l11l111_tv_ (u"ࠬࡹࡩࡵࡧࠪ঺"),iconImage=l1l11lll11l111_tv_+l11l1l11l111_tv_ (u"࠭ࡥࡴ࡭ࡤ࡫ࡴ࠴ࡰ࡯ࡩࠪ঻"))
        l1111lll11l111_tv_(l11l1l11l111_tv_ (u"ࠧࡍ࡫ࡹࡩ࡙࡜࠺ࠡࡵࡳࡳࡷࡺ࠳࠷࠷়ࠪ"),ex_link=l11l1l11l111_tv_ (u"ࠨࠩঽ"),params={l11l1l11l111_tv_ (u"ࠩࡢࡷࡪࡸࡶࡪࡥࡨࠫা"):l11l1l11l111_tv_ (u"ࠪࡷࡵࡵࡲࡵ࠵࠹࠹ࠬি"),l11l1l11l111_tv_ (u"ࠫࡤࡧࡣࡵࠩী"):l11l1l11l111_tv_ (u"ࠬࡒࡩࡴࡶࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫু")}, mode=l11l1l11l111_tv_ (u"࠭ࡳࡪࡶࡨࡣࡸࡶ࡯ࡳࡶ࠶࠺࠺࠭ূ"),iconImage=l1l11lll11l111_tv_+l11l1l11l111_tv_ (u"ࠧࡴࡲࡲࡶࡹ࠹࠶࠶࠰ࡳࡲ࡬࠭ৃ"))
        l1111lll11l111_tv_(l11l1l11l111_tv_ (u"ࠨࡎ࡬ࡺࡪ࡚ࡖ࠻ࠢࡶࡴࡴࡸࡴ࠯ࡶࡹࡴࠬৄ"),ex_link=l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡴࡴࡸࡴ࠯ࡶࡹࡴ࠳ࡶ࡬࠰ࡶࡵࡥࡳࡹ࡭ࡪࡵ࡭ࡩࠬ৅"),params={l11l1l11l111_tv_ (u"ࠪࡣࡸ࡫ࡲࡷ࡫ࡦࡩࠬ৆"):l11l1l11l111_tv_ (u"ࠫࡸࡶ࡯ࡳࡶࡷࡺࡵ࠭ে"),l11l1l11l111_tv_ (u"ࠬࡥࡡࡤࡶࠪৈ"):l11l1l11l111_tv_ (u"࠭ࡌࡪࡵࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ৉")}, mode=l11l1l11l111_tv_ (u"ࠧࡴ࡫ࡷࡩࠬ৊"),iconImage=l1l11lll11l111_tv_+l11l1l11l111_tv_ (u"ࠨࡵࡳࡳࡷࡺࡴࡷࡲ࠱ࡴࡳ࡭ࠧো"))
        l1111lll11l111_tv_(l11l1l11l111_tv_ (u"ࠩࡏ࡭ࡻ࡫ࡔࡗ࠼ࠣࡷࡪࡰ࡭ࠡࡔࡓࠤࠬৌ"),ex_link=l11l1l11l111_tv_ (u"্ࠪࠫ"),params={l11l1l11l111_tv_ (u"ࠫࡤࡹࡥࡳࡸ࡬ࡧࡪ࠭ৎ"):l11l1l11l111_tv_ (u"ࠬࡹࡥ࡫࡯ࠪ৏"),l11l1l11l111_tv_ (u"࠭࡟ࡢࡥࡷࠫ৐"):l11l1l11l111_tv_ (u"ࠧࡍ࡫ࡶࡸࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭৑")}, mode=l11l1l11l111_tv_ (u"ࠨࡵ࡬ࡸࡪ࠭৒"),iconImage=l1l11lll11l111_tv_+l11l1l11l111_tv_ (u"ࠩࡶࡩ࡯ࡳ࠮ࡱࡰࡪࠫ৓"))
        l1111lll11l111_tv_(l11l1l11l111_tv_ (u"ࠪࡐ࡮ࡼࡥࡕࡘ࠽ࠤࡼࡘࡥࡢ࡮ࡸ࠶࠹࠭৔"),ex_link=l11l1l11l111_tv_ (u"ࠫࠬ৕"),params={l11l1l11l111_tv_ (u"ࠬࡥࡳࡦࡴࡹ࡭ࡨ࡫ࠧ৖"):l11l1l11l111_tv_ (u"࠭ࡷࡳࡧࡤࡰࡺ࠸࠴ࠨৗ"),l11l1l11l111_tv_ (u"ࠧࡠࡣࡦࡸࠬ৘"):l11l1l11l111_tv_ (u"ࠨࡎ࡬ࡷࡹࡉࡨࡢࡰࡱࡩࡱࡹࠧ৙")}, mode=l11l1l11l111_tv_ (u"ࠩࡶ࡭ࡹ࡫ࠧ৚"),iconImage=l1l11lll11l111_tv_+l11l1l11l111_tv_ (u"ࠪࡻࡷ࡫ࡡ࡭ࡷ࠵࠸࠳ࡶ࡮ࡨࠩ৛"))
        l1lll11l11l111_tv_ = xbmcgui.ListItem(label = l11l1l11l111_tv_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟ࡤ࡯ࡹࡿࡷࡶ࡬ࠣࡔ࡛ࡘࠠࡍ࡫ࡹࡩ࡚ࠥࡖ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩড়"), iconImage=l1l11lll11l111_tv_+l11l1l11l111_tv_ (u"ࠬࡖࡖࡓ࠰ࡳࡲ࡬࠭ঢ়"))
        xbmcplugin.addDirectoryItem(handle=l1lll1llll11l111_tv_, url=l1l111l11l111_tv_({l11l1l11l111_tv_ (u"࠭࡭ࡰࡦࡨࠫ৞"): l11l1l11l111_tv_ (u"ࠧࡐࡲࡦ࡮ࡪ࠭য়")}) ,listitem=l1lll11l11l111_tv_)
    else:
        l1lll11l11l111_tv_ = xbmcgui.ListItem(label = msg, iconImage=l11l1l11l111_tv_ (u"ࠨࠩৠ"))
        xbmcplugin.addDirectoryItem(handle=l1lll1llll11l111_tv_, url=l11l1l11l111_tv_ (u"ࠩࠪৡ") ,listitem=l1lll11l11l111_tv_)
elif mode[0].startswith(l11l1l11l111_tv_ (u"ࠪࡣ࡮ࡴࡦࡰࡡࠪৢ")):l11l1l1l11l111_tv_.__myinfo__.go(sys.argv)
elif mode[0] == l11l1l11l111_tv_ (u"ࠫࡔࡶࡣ࡫ࡧࠪৣ"):
    path =  l111l1ll11l111_tv_.getSetting(l11l1l11l111_tv_ (u"ࠬࡶࡡࡵࡪࠪ৤")).decode(l11l1l11l111_tv_ (u"࠭ࡵࡵࡨ࠰࠼ࠬ৥"))
    if not path: l111l1ll11l111_tv_.setSetting(l11l1l11l111_tv_ (u"ࠧࡱࡣࡷ࡬ࠬ০"),l1l11l11l11l111_tv_)
    l111l1ll11l111_tv_.openSettings()
elif mode[0] == l11l1l11l111_tv_ (u"ࠨࡒ࡙ࡖࡤ࡙ࡅࡕࡖࡌࡒࡌ࡙ࠧ১"):
    try: xbmcaddon.Addon(l11l1l11l111_tv_ (u"ࠩࡳࡺࡷ࠴ࡩࡱࡶࡹࡷ࡮ࡳࡰ࡭ࡧࠪ২")).openSettings()
    except: pass
elif mode[0] == l11l1l11l111_tv_ (u"࡙ࠪࡕࡊࡁࡕࡇࡢࡍࡕ࡚ࡖࠨ৩"):
    import l1lll11l1l11l111_tv_ as l11lll1l11l111_tv_
    fname = l111l1ll11l111_tv_.getSetting(l11l1l11l111_tv_ (u"ࠫ࡫ࡴࡡ࡮ࡧࠪ৪"))
    path =  l111l1ll11l111_tv_.getSetting(l11l1l11l111_tv_ (u"ࠬࡶࡡࡵࡪࠪ৫")).decode(l11l1l11l111_tv_ (u"࠭ࡵࡵࡨ࠰࠼ࠬ৬"))
    l1l1l1l1l11l111_tv_ = l111l1ll11l111_tv_.getSetting(l11l1l11l111_tv_ (u"ࠧࡦࡲࡪࡘ࡮ࡳࡥࡔࡪ࡬ࡪࡹ࠭৭"))
    l111111ll11l111_tv_ = l111l1ll11l111_tv_.getSetting(l11l1l11l111_tv_ (u"ࠨࡧࡳ࡫࡚ࡸ࡬ࠨ৮"))
    l11lll1l11l111_tv_.l1ll1lll11l111_tv_(fname,path,l1l1l1l1l11l111_tv_,l111111ll11l111_tv_)
elif mode[0] == l11l1l11l111_tv_ (u"ࠩࡅ࡙ࡎࡊ࡟ࡎ࠵ࡘࠫ৯"):
    import l1lll11l1l11l111_tv_ as l11lll1l11l111_tv_
    fname = l111l1ll11l111_tv_.getSetting(l11l1l11l111_tv_ (u"ࠪࡪࡳࡧ࡭ࡦࠩৰ"))
    path =  l111l1ll11l111_tv_.getSetting(l11l1l11l111_tv_ (u"ࠫࡵࡧࡴࡩࠩৱ")).decode(l11l1l11l111_tv_ (u"ࠬࡻࡴࡧ࠯࠻ࠫ৲"))
    l1l11l1ll11l111_tv_ = l111l1ll11l111_tv_.getSetting(l11l1l11l111_tv_ (u"࠭ࡳࡦࡴࡹ࡭ࡨ࡫ࠧ৳"))
    l1lll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠢࠣ৴")
    if not fname:   l1lll11ll11l111_tv_ +=l11l1l11l111_tv_ (u"ࠣࡒࡲࡨࡦࡰࠠ࡯ࡣࡽࡻञࠦࡰ࡭࡫࡮ࡹࠥࠨ৵")
    if not path:    l1lll11ll11l111_tv_ +=l11l1l11l111_tv_ (u"ࠤࡓࡳࡩࡧࡪࠡ࡭ࡤࡸࡦࡲ࡯ࡨࠢࡧࡳࡨ࡫࡬ࡰࡹࡼࠤࠧ৶")
    if not l1l11l1ll11l111_tv_: l1lll11ll11l111_tv_ +=l11l1l11l111_tv_ (u"࡛ࠥࡾࡨࡩࡦࡴࡽࠤ࡯ࡧ࡫ࡪࡧफ़ࠤॿࡸࣳࡥॄࡤࠦ৷")
    if l1lll11ll11l111_tv_:
        xbmcgui.Dialog().notification(l11l1l11l111_tv_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞ࡇࡕࡖࡔࡘ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ৸"), l1lll11ll11l111_tv_, xbmcgui.NOTIFICATION_ERROR, 1000)
        l1ll1l1ll11l111_tv_=  xbmc.translatePath(os.path.join(l11l1l11l111_tv_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡷࡶࡩࡷࡪࡡࡵࡣ࠲ࠫ৹"),l11l1l11l111_tv_ (u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ৺"),l11l1l11l111_tv_ (u"ࠧࡱࡸࡵ࠲࡮ࡶࡴࡷࡵ࡬ࡱࡵࡲࡥࠨ৻")))
        if os.path.exists(os.path.join(l1ll1l1ll11l111_tv_,l11l1l11l111_tv_ (u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧৼ"))):
            print l11l1l11l111_tv_ (u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠡࡧࡻ࡭ࡸࡺࡳࠨ৽")
    else:
        l11l1ll1l11l111_tv_ = l11lll1l11l111_tv_.l11l1l1ll11l111_tv_(fname,path,l1111ll11l111_tv_.get(l1l11l1ll11l111_tv_),_1l11ll11l111_tv_)
        if len(l11l1ll1l11l111_tv_)>1: xbmcgui.Dialog().ok(l11l1l11l111_tv_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡷ࡫ࡥ࡯࡟ࡏ࡭ࡸࡺࡡࠡࡼࡤࡴ࡮ࡹࡡ࡯ࡣ࡞࠳ࡈࡕࡌࡐࡔࡠࠤࡐࡧ࡮ࡢॄࣶࡻ࠿ࠦࠥࡥࠩ৾")%len(l11l1ll1l11l111_tv_),l11l1l11l111_tv_ (u"ࠫࡕࡲࡩ࡬࠼ࠣ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞ࠩ৿")+fname+l11l1l11l111_tv_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ਀"),l11l1l11l111_tv_ (u"࠭ࡕࡢ࡭ࡷࡹࡦࡲ࡮ࡪ࡬ࠣࡹࡸࡺࡡࡸ࡫ࡨࡲ࡮ࡧࠠ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࡖࡖࡓࠢࡌࡔ࡙࡜ࠠࡔ࡫ࡰࡴࡱ࡫ࠠࡄ࡮࡬ࡩࡳࡺ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠡ࡫ࠣࠬࡷ࡫ࠩࡢ࡭ࡷࡽࡼࡻࡪࠡࡎ࡬ࡺࡪࠦࡔࡗࠩਁ"))
        else: xbmcgui.Dialog().ok(l11l1l11l111_tv_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࡕࡸ࡯ࡣ࡮ࡨࡱࡠ࠵ࡃࡐࡎࡒࡖࡢࠦࠧਂ"),l11l1l11l111_tv_ (u"ࠨࡎ࡬ࡷࡹࡧࠠ࡫ࡧࡶࡸࠥࡖࡵࡴࡶࡤࠥࠦࠧࠧਃ"))
    l111l1ll11l111_tv_.openSettings()
elif mode[0] == l11l1l11l111_tv_ (u"ࠩࡄ࡙࡙ࡕ࡭࠴ࡷࠪ਄"):
    import l1lll11l1l11l111_tv_ as l11lll1l11l111_tv_
    fname = l111l1ll11l111_tv_.getSetting(l11l1l11l111_tv_ (u"ࠪࡪࡳࡧ࡭ࡦࠩਅ"))
    path =  l111l1ll11l111_tv_.getSetting(l11l1l11l111_tv_ (u"ࠫࡵࡧࡴࡩࠩਆ")).decode(l11l1l11l111_tv_ (u"ࠬࡻࡴࡧ࠯࠻ࠫਇ"))
    l1l11l1ll11l111_tv_ = l111l1ll11l111_tv_.getSetting(l11l1l11l111_tv_ (u"࠭ࡳࡦࡴࡹ࡭ࡨ࡫ࠧਈ"))
    l1lll1111l11l111_tv_ = l11lll1l11l111_tv_.l11l1l1ll11l111_tv_(fname,path,l1111ll11l111_tv_.get(l1l11l1ll11l111_tv_),_1l11ll11l111_tv_)
    if l1lll1111l11l111_tv_:
        l1l1l1l1l11l111_tv_ = l111l1ll11l111_tv_.getSetting(l11l1l11l111_tv_ (u"ࠧࡦࡲࡪࡘ࡮ࡳࡥࡔࡪ࡬ࡪࡹ࠭ਉ"))
        l111111ll11l111_tv_ = l111l1ll11l111_tv_.getSetting(l11l1l11l111_tv_ (u"ࠨࡧࡳ࡫࡚ࡸ࡬ࠨਊ"))
        l11lll1l11l111_tv_.l1ll1lll11l111_tv_(fname,path,l1l1l1l1l11l111_tv_,l111111ll11l111_tv_)
elif mode[0] == l11l1l11l111_tv_ (u"ࠩࡘࡔࡉࡇࡔࡆࡡࡆࡖࡔࡔࠧ਋"):
    import l1lll11l1l11l111_tv_ as l11lll1l11l111_tv_
    l1lll1l1ll11l111_tv_ = l111l1ll11l111_tv_.getSetting(l11l1l11l111_tv_ (u"ࠪࡥࡺࡺ࡯ࡠࡷࡳࡨࡦࡺࡥࡠࡪࡲࡹࡷ࠭਌"))
    l11lll11l11l111_tv_ =  l111l1ll11l111_tv_.getSetting(l11l1l11l111_tv_ (u"ࠫࡦࡻࡴࡰࡡࡸࡴࡩࡧࡴࡦࡡࡤࡧࡹ࡯ࡶࡦࠩ਍"))
    l11lll1l11l111_tv_.l1ll1l1l11l111_tv_(l1lll1l1ll11l111_tv_,l11lll11l11l111_tv_)
elif mode[0] ==l11l1l11l111_tv_ (u"ࠬࡹࡩࡵࡧࠪ਎"):
    params = eval(params)
    l1l11l1ll11l111_tv_ = params.get(l11l1l11l111_tv_ (u"࠭࡟ࡴࡧࡵࡺ࡮ࡩࡥࠨਏ"))
    l1ll11lll11l111_tv_ = params.get(l11l1l11l111_tv_ (u"ࠧࡠࡣࡦࡸࠬਐ"))
    mod = _1l11ll11l111_tv_(l1l11l1ll11l111_tv_)
    try:
        mod.l11ll111l11l111_tv_=os.path.join(l1l11l11l11l111_tv_,l1l11l1ll11l111_tv_+l11l1l11l111_tv_ (u"ࠨ࠰ࡦࡳࡴࡱࡩࡦࠩ਑"))
    except:
        pass
    if l1ll11lll11l111_tv_ == l11l1l11l111_tv_ (u"ࠩࡏ࡭ࡸࡺࡃࡩࡣࡱࡲࡪࡲࡳࠨ਒"):
        params.update({l11l1l11l111_tv_ (u"ࠪࡣࡦࡩࡴࠨਓ"):l11l1l11l111_tv_ (u"ࠫࡵࡲࡡࡺࠩਔ")})
        items = mod.l11l11l1l11l111_tv_(ex_link)
        for l1l1l1ll11l111_tv_ in items:
            l1lllllll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫਕ"),l11l1l11l111_tv_ (u"࠭ࠧਖ")), l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫਗ")], params=params, mode=l11l1l11l111_tv_ (u"ࠨࡵ࡬ࡸࡪ࠭ਘ"), IsPlayable=True,infoLabels=l1l1l1ll11l111_tv_, l111l11l11l111_tv_=l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠩ࡬ࡱ࡬࠭ਙ"),l11l1l11l111_tv_ (u"ࠪࠩࡸ࠴ࡰ࡯ࡩࠪਚ")%(l1l11lll11l111_tv_+l1l11l1ll11l111_tv_)))
    elif l1ll11lll11l111_tv_ == l11l1l11l111_tv_ (u"ࠫࡵࡲࡡࡺࠩਛ"):
        import l1l1llll11l111_tv_
        l1ll1l11l11l111_tv_ = mod.l111l1lll11l111_tv_(ex_link)
        if isinstance(l1ll1l11l11l111_tv_,list):
            if len(l1ll1l11l11l111_tv_)>1:
                label = [x.get(l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫਜ")) for x in l1ll1l11l11l111_tv_]
                s = xbmcgui.Dialog().select(l11l1l11l111_tv_ (u"࠭ॹࡳࣵࡧॆࡦ࠭ਝ"),label)
                l1ll11l1l11l111_tv_ = l1ll1l11l11l111_tv_[s]
            elif l1ll1l11l11l111_tv_:
                l1ll11l1l11l111_tv_ = l1ll1l11l11l111_tv_[0]
            else: l1ll11l1l11l111_tv_=l11l1l11l111_tv_ (u"ࠧࠨਞ")
        else:
            l1ll11l1l11l111_tv_ = l1ll1l11l11l111_tv_
        if l1ll11l1l11l111_tv_:
            l11ll11ll11l111_tv_ = l1ll11l1l11l111_tv_.get(l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬਟ"),l11l1l11l111_tv_ (u"ࠩࠪਠ"))
            msg = l1ll11l1l11l111_tv_.get(l11l1l11l111_tv_ (u"ࠪࡱࡸ࡭ࠧਡ"),l11l1l11l111_tv_ (u"ࠫࠬਢ"))
            if l11ll11ll11l111_tv_: xbmcplugin.setResolvedUrl(l1lll1llll11l111_tv_, True,  xbmcgui.ListItem(path=l11ll11ll11l111_tv_))
            else:
                if msg: xbmcgui.Dialog().ok(l11l1l11l111_tv_ (u"ࠬࡖࡲࡰࡤ࡯ࡩࡲ࠭ਣ"),msg)
                xbmcplugin.setResolvedUrl(l1lll1llll11l111_tv_, False, xbmcgui.ListItem(path=l11l1l11l111_tv_ (u"࠭ࠧਤ")))
        else: xbmcplugin.setResolvedUrl(l1lll1llll11l111_tv_, False, xbmcgui.ListItem(path=l11l1l11l111_tv_ (u"ࠧࠨਥ")))
elif mode[0] ==l11l1l11l111_tv_ (u"ࠨࡵ࡬ࡸࡪ࠸ࠧਦ"):
    params = eval(params)
    l1l11l1ll11l111_tv_ = params.get(l11l1l11l111_tv_ (u"ࠩࡢࡷࡪࡸࡶࡪࡥࡨࠫਧ"))
    l1ll11lll11l111_tv_ = params.get(l11l1l11l111_tv_ (u"ࠪࡣࡦࡩࡴࠨਨ"))
    mod = _1l11ll11l111_tv_(l1l11l1ll11l111_tv_)
    if l1ll11lll11l111_tv_ == l11l1l11l111_tv_ (u"ࠫࡑ࡯ࡳࡵࡅ࡫ࡥࡳࡴࡥ࡭ࡵࠪ਩"):
        params.update({l11l1l11l111_tv_ (u"ࠬࡥࡡࡤࡶࠪਪ"):l11l1l11l111_tv_ (u"࠭ࡧࡦࡶࡢࡷࡹࡸࡥࡢ࡯ࡶࡣࡵࡲࡡࡺࠩਫ")})
        items = mod.l11l11l1l11l111_tv_(ex_link)
        l1111l1ll11l111_tv_ =l11l1l11l111_tv_ (u"ࠧࠦࡵ࠱ࡴࡳ࡭ࠧਬ")%(l1l11lll11l111_tv_+l1l11l1ll11l111_tv_)
        for l1l1l1ll11l111_tv_ in items:
            l1lllllll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧਭ"),l11l1l11l111_tv_ (u"ࠩࠪਮ")), l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧਯ")], params=params, mode=l11l1l11l111_tv_ (u"ࠫࡸ࡯ࡴࡦ࠴ࠪਰ"), IsPlayable=True,infoLabels=l1l1l1ll11l111_tv_, l111l11l11l111_tv_=l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠬ࡯࡭ࡨࠩ਱"),l1111l1ll11l111_tv_))
    if l1ll11lll11l111_tv_ == l11l1l11l111_tv_ (u"࠭ࡧࡦࡶࡢࡷࡹࡸࡥࡢ࡯ࡶࡣࡵࡲࡡࡺࠩਲ"):
        l1ll1l11l11l111_tv_ = mod.l1llll1ll11l111_tv_(ex_link)
        if l1ll1l11l11l111_tv_:
            t = [stream.get(l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ਲ਼")) for stream in l1ll1l11l11l111_tv_]
            s = xbmcgui.Dialog().select(l11l1l11l111_tv_ (u"ࡶࠤॼࡶࣸࡪूࡢࠤ਴"), t) if len(t)>0 else 0
            if s>-1: l1ll11l1l11l111_tv_ = mod.l111l1lll11l111_tv_(l1ll1l11l11l111_tv_[s])
            else: l1ll11l1l11l111_tv_=l11l1l11l111_tv_ (u"ࠩࠪਵ")
            if l1ll11l1l11l111_tv_:
                xbmcplugin.setResolvedUrl(l1lll1llll11l111_tv_, True, xbmcgui.ListItem(path=l1ll11l1l11l111_tv_))
            else: xbmcplugin.setResolvedUrl(l1lll1llll11l111_tv_, False, xbmcgui.ListItem(path=l1ll11l1l11l111_tv_))
        else:
            xbmcgui.Dialog().ok(l11l1l11l111_tv_ (u"ࠥࡔࡷࡵࡢ࡭ࡧࡰࠦਸ਼"), l11l1l11l111_tv_ (u"ࡹࠧॿࡲࣴࡦॅࡥࠥࡴࡩࡦࠢࡶउࠥࡪ࡯ࡴࡶजࡴࡳ࡫ࠢ਷"))
elif mode[0] ==l11l1l11l111_tv_ (u"ࠬࡹࡩࡵࡧࡢࡷࡵࡵࡲࡵ࠵࠹࠹ࠬਸ"):
    params = eval(params)
    l1l11l1ll11l111_tv_ = params.get(l11l1l11l111_tv_ (u"࠭࡟ࡴࡧࡵࡺ࡮ࡩࡥࠨਹ"))
    l1ll11lll11l111_tv_ = params.get(l11l1l11l111_tv_ (u"ࠧࡠࡣࡦࡸࠬ਺"))
    import l11l1ll11l111_tv_ as mod
    if l1ll11lll11l111_tv_ == l11l1l11l111_tv_ (u"ࠨࡎ࡬ࡷࡹࡉࡨࡢࡰࡱࡩࡱࡹࠧ਻"):
        params.update({l11l1l11l111_tv_ (u"ࠩࡢࡥࡨࡺ਼ࠧ"):l11l1l11l111_tv_ (u"ࠪ࡫ࡪࡺ࡟ࡴࡶࡵࡩࡦࡳࡳࡠࡲ࡯ࡥࡾ࠭਽")})
        items = mod.l11l11l1l11l111_tv_(ex_link)
        l1111l1ll11l111_tv_ =l11l1l11l111_tv_ (u"ࠫࠪࡹ࠮ࡱࡰࡪࠫਾ")%(l1l11lll11l111_tv_+l1l11l1ll11l111_tv_)
        for l1l1l1ll11l111_tv_ in items:
            l1lllllll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫਿ"),l11l1l11l111_tv_ (u"࠭ࠧੀ")), l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫੁ")], params=params, mode=l11l1l11l111_tv_ (u"ࠨࡵ࡬ࡸࡪࡥࡳࡱࡱࡵࡸ࠸࠼࠵ࠨੂ"), IsPlayable=True,infoLabels=l1l1l1ll11l111_tv_, l111l11l11l111_tv_=l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠩ࡬ࡱ࡬࠭੃"),l1111l1ll11l111_tv_))
    if l1ll11lll11l111_tv_ == l11l1l11l111_tv_ (u"ࠪ࡫ࡪࡺ࡟ࡴࡶࡵࡩࡦࡳࡳࡠࡲ࡯ࡥࡾ࠭੄"):
        l1ll1l11l11l111_tv_ = mod.l1llll1ll11l111_tv_(ex_link)
        if l1ll1l11l11l111_tv_:
            t = [stream.get(l11l1l11l111_tv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ੅")) for stream in l1ll1l11l11l111_tv_]
            s = xbmcgui.Dialog().select(l11l1l11l111_tv_ (u"ࠧॿࡲࣴࡦॅࡥࠧ੆"), t)
            if s>-1: l1ll11l1l11l111_tv_ = mod.l111l1lll11l111_tv_(l1ll1l11l11l111_tv_[s])
            else: l1ll11l1l11l111_tv_=l11l1l11l111_tv_ (u"࠭ࠧੇ")
            if l1ll11l1l11l111_tv_:
                xbmcplugin.setResolvedUrl(l1lll1llll11l111_tv_, True, xbmcgui.ListItem(path=l1ll11l1l11l111_tv_))
            else: xbmcplugin.setResolvedUrl(l1lll1llll11l111_tv_, False, xbmcgui.ListItem(path=l1ll11l1l11l111_tv_))
        else:
            xbmcgui.Dialog().ok(l11l1l11l111_tv_ (u"ࠢࡑࡴࡲࡦࡱ࡫࡭ࠣੈ"), l11l1l11l111_tv_ (u"ࡶࠤॼࡶࣸࡪूࡢࠢࡱ࡭ࡪࠦࡳआࠢࡧࡳࡸࡺङࡱࡰࡨࠦ੉"))
elif mode[0].startswith(l11l1l11l111_tv_ (u"ࠩࡵࡩࡲࡵࡴࡦࠩ੊")):
    l1lllll11l11l111_tv_=l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡩࡸࡩࡷࡧ࠱࡫ࡴࡵࡧ࡭ࡧ࠱ࡧࡴࡳ࠯ࡶࡥࡂࡩࡽࡶ࡯ࡳࡶࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࠫ࡯ࡤ࠾ࠩੋ")
    params = eval(params)
    l1l11l1ll11l111_tv_ = params.get(l11l1l11l111_tv_ (u"ࠫࡤࡹࡥࡳࡸ࡬ࡧࡪ࠭ੌ"))
    l1ll11lll11l111_tv_ = params.get(l11l1l11l111_tv_ (u"ࠬࡥࡡࡤࡶ੍ࠪ"))
    if l1ll11lll11l111_tv_ == l11l1l11l111_tv_ (u"࠭ࡌࡪࡵࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ੎"):
        params.update({l11l1l11l111_tv_ (u"ࠧࡠࡣࡦࡸࠬ੏"):l11l1l11l111_tv_ (u"ࠨࡩࡨࡸࡤࡹࡴࡳࡧࡤࡱࡸࡥࡰ࡭ࡣࡼࠫ੐")})
        try:
            l11111ll11l111_tv_ = urllib2.urlopen(l1lllll11l11l111_tv_+l11l1l11l111_tv_ (u"ࠩ࠴࠴ࡤࡿ࡭࠵ࡳࡅ࡯ࡺࡐࡊ࠷࡚ࡲ࠻ࡨ࠾ࡋ࡙ࡍ࠼ࡘࡼ࠽ࡍ࡯࡭ࡔࡳࡘࡍࡌࠨੑ")).read()
            l11111ll11l111_tv_ = re.findall(l11l1l11l111_tv_ (u"ࠪࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨ੒"),l11111ll11l111_tv_)[0]
            l1lllll1l11l111_tv_=l11l111ll11l111_tv_(l11111ll11l111_tv_)
        except:
            l1lllll1l11l111_tv_=[]
        for l1l1l1ll11l111_tv_ in l1lllll1l11l111_tv_:
            l1lllllll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ੓"),l11l1l11l111_tv_ (u"ࠬ࠭੔")), l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪ੕"),l11l1l11l111_tv_ (u"ࠧࠨ੖")), params=params, mode=l11l1l11l111_tv_ (u"ࠨ࡯࠶ࡹࠬ੗"), IsPlayable=True,infoLabels=l1l1l1ll11l111_tv_, l111l11l11l111_tv_=l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠩ࡬ࡱ࡬࠭੘")))
    if l1ll11lll11l111_tv_ == l11l1l11l111_tv_ (u"ࠪ࡫ࡪࡺ࡟ࡴࡶࡵࡩࡦࡳࡳࡠࡲ࡯ࡥࡾ࠭ਖ਼"):
        xbmcplugin.setResolvedUrl(l1lll1llll11l111_tv_, True, xbmcgui.ListItem(path=ex_link))
elif mode[0].startswith(l11l1l11l111_tv_ (u"ࠫࡲ࠹ࡵࠨਗ਼")):
    l1lllll11l11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡤࡳ࡫ࡹࡩ࠳࡭࡯ࡰࡩ࡯ࡩ࠳ࡩ࡯࡮࠱ࡸࡧࡄ࡫ࡸࡱࡱࡵࡸࡂࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠦࡪࡦࡀࠫਜ਼")
    params = eval(params)
    l1l11l1ll11l111_tv_ = params.get(l11l1l11l111_tv_ (u"࠭࡟ࡴࡧࡵࡺ࡮ࡩࡥࠨੜ"))
    l1ll11lll11l111_tv_ = params.get(l11l1l11l111_tv_ (u"ࠧࡠࡣࡦࡸࠬ੝"))
    if l1ll11lll11l111_tv_ == l11l1l11l111_tv_ (u"ࠨࡎ࡬ࡷࡹࡌ࡯࡭ࡦࡨࡶࡸ࠭ਫ਼"):
        params.update({l11l1l11l111_tv_ (u"ࠩࡢࡥࡨࡺࠧ੟"):l11l1l11l111_tv_ (u"ࠪࡐ࡮ࡹࡴࡇࡱ࡯ࡨࡪࡸࡳࡠࡥࡲࡲࡹ࡫࡮ࡵࠩ੠")})
        try:l11ll1l11l111_tv_ = eval(l111111l11l111_tv_(l1lllll11l11l111_tv_+l11l1l11l111_tv_ (u"ࠫ࠶࡝ࡡࡌ࡜࠶ࡕࡉ࡬࡬࠹࠯࠰ࡖࡌ࠹ࡶࡪࡒ࠷ࡣࡷ࠹ࡦࡈࡼ࡝ࡲ࠽ࡵ࡙ࡵࡐࠪ੡")))
        except:l11ll1l11l111_tv_=[]
        for l1l1l1ll11l111_tv_ in l11ll1l11l111_tv_:
            l1111lll11l111_tv_(name=l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠬࡴࡡ࡮ࡧࠪ੢"),l11l1l11l111_tv_ (u"࠭ࠧ੣")),ex_link=l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫ੤"),l11l1l11l111_tv_ (u"ࠨࠩ੥")),mode=l11l1l11l111_tv_ (u"ࠩࡰ࠷ࡺ࠭੦"),params=params,iconImage=l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠪ࡭ࡲࡧࡧࡦࠩ੧")))
    elif l1ll11lll11l111_tv_ == l11l1l11l111_tv_ (u"ࠫࡑ࡯ࡳࡵࡈࡲࡰࡩ࡫ࡲࡴࡡࡦࡳࡳࡺࡥ࡯ࡶࠪ੨"):
        params.update({l11l1l11l111_tv_ (u"ࠬࡥࡡࡤࡶࠪ੩"):l11l1l11l111_tv_ (u"࠭ࡧࡦࡶࡢࡷࡹࡸࡥࡢ࡯ࡶࡣࡵࡲࡡࡺࠩ੪")})
        l1lllll1l11l111_tv_=l11l111ll11l111_tv_(ex_link)
        for l1l1l1ll11l111_tv_ in l1lllll1l11l111_tv_:
            l1lllllll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭੫"),l11l1l11l111_tv_ (u"ࠨࠩ੬")), l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭੭"),l11l1l11l111_tv_ (u"ࠪࠫ੮")), params=params, mode=l11l1l11l111_tv_ (u"ࠫࡲ࠹ࡵࠨ੯"), IsPlayable=True,infoLabels=l1l1l1ll11l111_tv_, l111l11l11l111_tv_=l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠬ࡯࡭ࡨࠩੰ")))
    elif l1ll11lll11l111_tv_ == l11l1l11l111_tv_ (u"࠭ࡌࡪࡵࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬੱ"):
        params.update({l11l1l11l111_tv_ (u"ࠧࡠࡣࡦࡸࠬੲ"):l11l1l11l111_tv_ (u"ࠨࡩࡨࡸࡤࡹࡴࡳࡧࡤࡱࡸࡥࡰ࡭ࡣࡼࠫੳ")})
        try:
            l11111ll11l111_tv_ = urllib2.urlopen(l1lllll11l11l111_tv_+l11l1l11l111_tv_ (u"ࠩ࠴࠴ࡤࡿ࡭࠵ࡳࡅ࡯ࡺࡐࡊ࠷࡚ࡲ࠻ࡨ࠾ࡋ࡙ࡍ࠼ࡘࡼ࠽ࡍ࡯࡭ࡔࡳࡘࡍࡌࠨੴ")).read()
            l11111ll11l111_tv_ = re.findall(l11l1l11l111_tv_ (u"ࠪࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨੵ"),l11111ll11l111_tv_)[0]
            l1lllll1l11l111_tv_=l11l111ll11l111_tv_(l11111ll11l111_tv_)
        except:
            l1lllll1l11l111_tv_=[]
        for l1l1l1ll11l111_tv_ in l1lllll1l11l111_tv_:
            l1lllllll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ੶"),l11l1l11l111_tv_ (u"ࠬ࠭੷")), l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪ੸"),l11l1l11l111_tv_ (u"ࠧࠨ੹")), params=params, mode=l11l1l11l111_tv_ (u"ࠨ࡯࠶ࡹࠬ੺"), IsPlayable=True,infoLabels=l1l1l1ll11l111_tv_, l111l11l11l111_tv_=l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠩ࡬ࡱ࡬࠭੻")))
    if l1ll11lll11l111_tv_ == l11l1l11l111_tv_ (u"ࠪ࡫ࡪࡺ࡟ࡴࡶࡵࡩࡦࡳࡳࡠࡲ࡯ࡥࡾ࠭੼"):
        xbmcplugin.setResolvedUrl(l1lll1llll11l111_tv_, True, xbmcgui.ListItem(path=ex_link))
elif mode[0] == l11l1l11l111_tv_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ੽"):
    pass
else:
    xbmcplugin.setResolvedUrl(l1lll1llll11l111_tv_, False, xbmcgui.ListItem(path=l11l1l11l111_tv_ (u"ࠬ࠭੾")))
xbmcplugin.endOfDirectory(l1lll1llll11l111_tv_)
