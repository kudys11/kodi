# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re
import cookielib
import urlparse
import l1ll11ll1ll11l111_tv_
import l1ll1ll111l11l111_tv_
import time
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡺࡰࡤࡤࡧࡿࡺࡶ࠯࡫ࡱࡪࡴ࠵ࠧ⁑")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭⁒")
local={l11l1l11l111_tv_ (u"ࠣࡆ࡬ࡷࡨࡵࡶࡦࡴࡼࠤ࡙ࡻࡲࡣࡱࠣ࡜ࡹࡸࡡࠣ⁓") 						:l11l1l11l111_tv_ (u"ࠤࡇ࡭ࡸࡩ࡯ࡷࡧࡵࡽࠥࡾࡴࡳࡣࠥ⁔"),}
def l111111l11l111_tv_(url,data=None,header={}):
    l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
    urllib2.install_opener(opener)
    if not header:
        header = {l11l1l11l111_tv_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ⁕"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except: l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠫࠬ⁖")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    names=[]
    l11llll11ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠮ࡃ࠮ࡂ࠯ࡢࡀ࠿࠳ࡱ࡯࠾ࠨ⁗")).findall(content)
    for href,t in l11llll11ll11l111_tv_:
        if t not in names:
            out.append({l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ⁘"):t,l11l1l11l111_tv_ (u"ࠧࡵࡸ࡬ࡨࠬ⁙"):t,l11l1l11l111_tv_ (u"ࠨ࡫ࡰ࡫ࠬ⁚"):l11l1l11l111_tv_ (u"ࠩࠪ⁛"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧ⁜"):href,l11l1l11l111_tv_ (u"ࠫ࡬ࡸ࡯ࡶࡲࠪ⁝"):l11l1l11l111_tv_ (u"ࠬ࠭⁞"),l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࡨࡴ࡬࠭ "):l11l1l11l111_tv_ (u"ࠧࠨ⁠"),l11l1l11l111_tv_ (u"ࠨࡲ࡯ࡳࡹ࠭⁡"):l11l1l11l111_tv_ (u"ࠩࠪ⁢"),l11l1l11l111_tv_ (u"ࠪࡧࡴࡪࡥࠨ⁣"):l11l1l11l111_tv_ (u"ࠫࠬ⁤")})
            names.append(t)
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡿࡥ࡭࡮ࡲࡻࡢ࡛ࡰࡥࡣࡷࡩࡩࡀࠠࠦࡵࠣࠬࡿࡵࡢࡢࡥࡽࡸࡻ࠯࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⁥") %time.strftime(l11l1l11l111_tv_ (u"ࠨࠥࡥ࠱ࠨࡱ࠴࡙ࠫ࠻ࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦ⁦"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭⁧"):t,l11l1l11l111_tv_ (u"ࠨࡶࡹ࡭ࡩ࠭⁨"):l11l1l11l111_tv_ (u"ࠩࠪ⁩"),l11l1l11l111_tv_ (u"ࠪ࡭ࡲ࡭ࠧ⁪"):l11l1l11l111_tv_ (u"ࠫࠬ⁫"),l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩ⁬"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"࠭ࡧࡳࡱࡸࡴࠬ⁭"):l11l1l11l111_tv_ (u"ࠧࠨ⁮"),l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࡪࡶࡧࠨ⁯"):l11l1l11l111_tv_ (u"ࠩࠪ⁰")})
    return l1ll1ll111l11l111_tv_.l1ll1ll1l1l11l111_tv_(out,local)
def l1l1111lllll11l111_tv_():
    out= l11l11l1l11l111_tv_()
    l1l1111ll1ll11l111_tv_= l1ll1ll111l11l111_tv_.l1ll1ll1l1l11l111_tv_(out,local)
    for l1l1l1ll11l111_tv_,l1l1111lll1l11l111_tv_ in zip(out,l1l1111ll1ll11l111_tv_):
        print l11l1l11l111_tv_ (u"ࠪࠩࡸࠦࠠࠡࠧࡶࠫⁱ")%(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ⁲")),l1l1111lll1l11l111_tv_.get(l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ⁳")))
def l111l1lll11l111_tv_(url=l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡺࡰࡤࡤࡧࡿࡺࡶ࠯࡫ࡱࡪࡴ࠵ࡲࡦࡲࡸࡦࡱ࡯࡫ࡢ࠱ࠪ⁴")):
    l1lll1ll11l11l111_tv_=[]
    content = l111111l11l111_tv_(url)
    src = re.compile(l11l1l11l111_tv_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯ࡦࡳࡣࡰࡩࠬ⁵"),re.DOTALL|re.I).findall(content)
    if src:
        data = l111111l11l111_tv_(src[0])
        l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src[0],data)
        if l1ll11lll1l11l111_tv_:
            l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬ⁶"):l1ll11lll1l11l111_tv_,l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ⁷"):l11l1l11l111_tv_ (u"ࠪࡐ࡮ࡼࡥࠡࠩ⁸")+urlparse.urlparse(l1ll11lll1l11l111_tv_).netloc,l11l1l11l111_tv_ (u"ࠫࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭⁹"):1})
        else:
            l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠬࡳࡳࡨࠩ⁺"):l11l1l11l111_tv_ (u"࠭ࡐࡳࡱࡥࡰࡪࡳࠠࡻࠢࡺࡽࡸࢀࡵ࡬ࡣࡱ࡭ࡪࡳࠠॻࡴࣶࡨेࡧࠧ⁻")}]
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        print l11l1l11l111_tv_ (u"ࠧ࡝ࡰࠪ⁼"),l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ⁽"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭⁾")))
        print l1lll1ll11l11l111_tv_
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧⁿ")))
        print l1lll1ll11l11l111_tv_
