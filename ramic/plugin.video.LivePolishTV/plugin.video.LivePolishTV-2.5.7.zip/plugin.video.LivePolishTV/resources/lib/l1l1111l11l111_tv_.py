# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib,cookielib
import re,json
from ramic import go as l1l1lllllll11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡨࡷࡰࡧࡧࡰ࠰ࡳࡰ࠴ࡺࡶࠨ෾")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠰࠯࠲࠱࠶࠻࠼࠱࠯࠳࠳࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬ෿")
l1lll1ll1ll11l111_tv_=10
class l1lll1111ll11l111_tv_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
def l111111l11l111_tv_(url,data=None,header={},l1llll1111l11l111_tv_=True):
    l1llll1l11l11l111_tv_=l11l1l11l111_tv_ (u"ࠧࠨ฀")
    l1llll1ll1l11l111_tv_=[]
    if l1llll1111l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_),l1lll1111ll11l111_tv_())
        urllib2.install_opener(opener)
    if not header:
        header = {l11l1l11l111_tv_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬก"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_ =  response.read()
        response.close()
        l1llll1l11l11l111_tv_ = l11l1l11l111_tv_ (u"ࠩࠪข").join([l11l1l11l111_tv_ (u"ࠪࠩࡸࡃࠥࡴ࠽ࠪฃ")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
    except:
        l11ll11ll11l111_tv_ = l11l1l11l111_tv_ (u"ࠫࠬค")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠬࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡨࡷࡰࡧࡧࡰ࠰ࡳࡰ࠴ࡺࡶ࠰࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠯࠭ࡂࡀ࡮ࡳࡧࠡࡣ࡯ࡸࡂࠨ࠮ࠫࡁࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠱ࡁࡀ࠴ࡧ࠾ࠨฅ")).findall(content)
    l1l1llll11l11l111_tv_=[]
    for href,l1ll111111l11l111_tv_,l1l1lllll1l11l111_tv_ in l1lll1lllll11l111_tv_:
        title = l1l1lllllll11l111_tv_[l11l1l11l111_tv_ (u"࠭ࡤࡦࡥࡲࡨࡪࡎࡔࡎࡎࡨࡲࡹࡸࡩࡦࡵࠪฆ")](l1ll111111l11l111_tv_)
        l1l1l1ll11l111_tv_ = {l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ง"):title.strip(),l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬจ"):href,l11l1l11l111_tv_ (u"ࠩ࡬ࡱ࡬࠭ฉ"):l1l1lllll1l11l111_tv_}
        l1l1llll11l11l111_tv_.append(l1l1l1ll11l111_tv_)
    if not l1l1llll11l11l111_tv_:
        l1l1llll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩช"):l11l1l11l111_tv_ (u"ࠫࡓ࡯ࡣࠡࡰ࡬ࡩࠥࢀ࡮ࡢ࡮ࡨࡾ࡮ࡵ࡮ࡰࠩซ"),l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩฌ"):l11l1l11l111_tv_ (u"࠭ࠧญ")}]
    return l1l1llll11l11l111_tv_
url=l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡪࡹ࡫ࡢࡩࡲ࠲ࡵࡲ࠯ࡵࡸ࠲ࡴࡴࡲ࡯࠮ࡲࡤࡶࡹࡿ࠭ࡵࡸࠪฎ")
def l111l1lll11l111_tv_(url):
    content = l111111l11l111_tv_(url)
    l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬฏ"):l11l1l11l111_tv_ (u"ࠩࠪฐ"),l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩฑ"):l11l1l11l111_tv_ (u"ࠫࡇࡸࡡ࡬ࠢॽࡶࣸࡪूࡢࠩฒ")}]
    found = re.findall(l11l1l11l111_tv_ (u"ࠬࡶ࡯ࡴࡶ࡟ࠬࡠࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢ࠴ࠫࡀࡵࡷࡶࡪࡧ࡭ࡖࡴ࡬࠾ࡡࡹࠪ࡜ࠤ࡟ࠫࡢ࠮࠮ࠬࡁࠬ࡟ࠧࡢࠧ࡞࡞ࡶ࠮ࢂ࠭ณ"),content)
    if found:
        l1l1llll1ll11l111_tv_ = l111111l11l111_tv_(found[0][0],l11l1l11l111_tv_ (u"࠭ࡳࡵࡴࡨࡥࡲ࡛ࡲࡪ࠿ࠪด")+urllib.quote(found[0][1]))
        if l1l1llll1ll11l111_tv_ and l1l1llll1ll11l111_tv_.startswith(l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴࠬต")):
            l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬถ"):l1l1llll1ll11l111_tv_,l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨท"):l11l1l11l111_tv_ (u"ࠪࡷࡹࡸࡥࡢ࡯ࠪธ")}]
    return l1lll1ll11l11l111_tv_
