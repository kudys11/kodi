# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re
import time
import cookielib
import threading
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡹࡰࡻ࠱ࡸࡻ࠵ࠧ὿")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ᾀ")
l1lll1ll1ll11l111_tv_ = l11l1l11l111_tv_ (u"ࠨ࠳࠳ࠫᾁ")
__all__=[l11l1l11l111_tv_ (u"ࠩࡪࡩࡹࡉࡨࡢࡰࡱࡩࡱࡹࠧᾂ"),l11l1l11l111_tv_ (u"ࠪ࡫ࡪࡺࡃࡩࡣࡱࡲࡪࡲࡖࡪࡦࡨࡳࠬᾃ")]
fix={
l11l1l11l111_tv_ (u"ࠫ࠶࡚ࡖࡑࠩᾄ"):l11l1l11l111_tv_ (u"࡚ࠬࡖࡑࠢ࠴ࠫᾅ"),
l11l1l11l111_tv_ (u"࠭࠲ࡕࡘࡓࠫᾆ"):l11l1l11l111_tv_ (u"ࠧࡕࡘࡓࠤ࠷࠭ᾇ"),
l11l1l11l111_tv_ (u"ࠨࡒࡤࠤࡘࡧࡴࠨᾈ"):l11l1l11l111_tv_ (u"ࠩࡓࡳࡱࡹࡡࡵࠩᾉ"),
l11l1l11l111_tv_ (u"ࠪࡔࡦ࠳ࡓࡢࡶࠪᾊ"):l11l1l11l111_tv_ (u"ࠫࡕࡵ࡬ࡴࡣࡷࠫᾋ"),
l11l1l11l111_tv_ (u"ࠬࡖࡡ࠮ࡕࡤࡸࠥ࠸ࠧᾌ"):l11l1l11l111_tv_ (u"࠭ࡐࡰ࡮ࡶࡥࡹࠦ࠲ࠨᾍ"),
l11l1l11l111_tv_ (u"ࠧࡄ࡫ࡱࡩࡲࡧࡸ࠳ࠩᾎ"):l11l1l11l111_tv_ (u"ࠨࡅ࡬ࡲࡪࡳࡡࡹࠢ࠵ࠫᾏ"),
l11l1l11l111_tv_ (u"ࠩࡋࡆࡔࠦ࠲ࠡࡊࡇࠫᾐ"):l11l1l11l111_tv_ (u"ࠪࡌࡇࡕ࠲ࠡࡊࡇࠫᾑ"),
l11l1l11l111_tv_ (u"ࠫࡕࡹࡡࡵࠢࡖࡴࡴࡸࡴࠡࡐࡨࡻࡸ࠭ᾒ"):l11l1l11l111_tv_ (u"ࠬࡖ࡯࡭ࡵࡤࡸ࡙ࠥࡰࡰࡴࡷࠤࡓ࡫ࡷࡴࠩᾓ"),
l11l1l11l111_tv_ (u"࠭ࡅࡹࡶࡵࡩࡲ࡫ࠠࡔࡲࡲࡶࡹࡹࠧᾔ"):l11l1l11l111_tv_ (u"ࠧࡆࡺࡷࡶࡪࡳࡥࠡࡕࡳࡳࡷࡺࠧᾕ"),
l11l1l11l111_tv_ (u"ࠨࡕࡷࡳࡵࡱ࡬ࡢࡶ࡮ࡥࠬᾖ"):l11l1l11l111_tv_ (u"ࠩࡖࡸࡴࡶ࡫࡭ࡣࡷ࡯ࡦࠦࡔࡗࠩᾗ"),
l11l1l11l111_tv_ (u"ࠪࡇࡧࡹࠠࡓࡧࡤࡰ࡮ࡺࡹࠨᾘ"):l11l1l11l111_tv_ (u"ࠫࡈࡈࡓࠡࡔࡨࡥࡱ࡯ࡴࡺࠩᾙ"),
l11l1l11l111_tv_ (u"ࠬࡈࡂࡄࠢࡈࡥࡷࡺࡨࠡࡊࡇࠫᾚ"):l11l1l11l111_tv_ (u"࠭ࡂࡃࡅࠣࡉࡦࡸࡴࡩࠩᾛ"),
l11l1l11l111_tv_ (u"ࠧࡑࡱ࡯ࡷࡦࡺࠠࡇࡱࡲࡨࠬᾜ"):l11l1l11l111_tv_ (u"ࠨࡒࡲࡰࡸࡧࡴࠡࡈࡲࡳࡩࠦࡎࡦࡶࡺࡳࡷࡱࠧᾝ"),
l11l1l11l111_tv_ (u"ࠩࡉࡳࡰࡻࡳࠡࡖ࡙ࠫᾞ"):l11l1l11l111_tv_ (u"ࠪࡊࡴࡱࡵࡴࠢࡗ࡚ࠬᾟ"),
l11l1l11l111_tv_ (u"ࠫࡊࡹ࡫ࡢࠢࡗ࡚ࠬᾠ"):l11l1l11l111_tv_ (u"ࠬࡋࡳ࡬ࡣࠣࡘ࡛࠭ᾡ"),
l11l1l11l111_tv_ (u"࠭࠴ࡇࡷࡱࠤ࡙࡜ࠧᾢ"):l11l1l11l111_tv_ (u"ࠧ࠵ࡨࡸࡲ࡚ࠥࡖࠨᾣ"),
l11l1l11l111_tv_ (u"ࠨ࠶ࡉࡹࡳࠦࡈࡪࡶࡶࠫᾤ"):l11l1l11l111_tv_ (u"ࠩ࠷ࡪࡺࡴࠠࡉ࡫ࡷࡷࠬᾥ"),
l11l1l11l111_tv_ (u"ࠪ࠸ࡋࡻ࡮ࠡࡈ࡬ࡸࠫࡇ࡭ࡱ࠽ࡇࡥࡳࡩࡥࠨᾦ"):l11l1l11l111_tv_ (u"ࠫ࠹࡬ࡵ࡯ࠢࡉ࡭ࡹࠦࡄࡢࡰࡦࡩࠬᾧ"),
l11l1l11l111_tv_ (u"࡚ࠬࡖࡑࠢࡓࡳࡱࡵ࡮ࡪ࡫ࡤࠫᾨ"):l11l1l11l111_tv_ (u"࠭ࡔࡗࡒࠣࡔࡴࡲ࡯࡯࡫ࡤࠫᾩ"),
l11l1l11l111_tv_ (u"ࠧࡕࡘࡓࠤࡕࡻ࡬ࡴࠢ࠵ࠫᾪ"):l11l1l11l111_tv_ (u"ࠨࡒࡸࡰࡸࠦ࠲ࠨᾫ"),
l11l1l11l111_tv_ (u"ࠩࡗ࡚ࡕࠦࡁࡣࡥࠪᾬ"):l11l1l11l111_tv_ (u"ࠪࡘ࡛ࡖࠠࡂࡄࡆࠫᾭ"),
l11l1l11l111_tv_ (u"ࠫࡗࡵ࡭ࡢࡰࡦࡩ࡚ࠥࡖࠡࡊࡇࠫᾮ"):l11l1l11l111_tv_ (u"ࠬࡘ࡯࡮ࡣࡱࡧࡪࠦࡔࡗࠩᾯ"),
l11l1l11l111_tv_ (u"࠭ࡔࡗ࠶ࠪᾰ"):l11l1l11l111_tv_ (u"ࠧࡕࡘࠣ࠸ࠬᾱ"),
l11l1l11l111_tv_ (u"ࠨࡖࡵࡻࡦࡳࠧᾲ"):l11l1l11l111_tv_ (u"ࠩࡗ࡚࡚ࠥࡲࡸࡣࡰࠫᾳ"),
l11l1l11l111_tv_ (u"ࠪࡉࡺࡸ࡯ࡴࡲࡲࡶࡹࠦࠠ࠳ࠩᾴ"):l11l1l11l111_tv_ (u"ࠫࡊࡻࡲࡰࡵࡳࡳࡷࡺࠠ࠳ࠩ᾵"),
l11l1l11l111_tv_ (u"ࠬࡔࡩࡤ࡭࡭ࡶࠬᾶ"):l11l1l11l111_tv_ (u"࠭ࡎࡪࡥ࡮ࠤࡏࡸࠧᾷ"),
l11l1l11l111_tv_ (u"ࠧࡂ࡮ࡨ࡯࡮ࡴ࡯ࠨᾸ"):l11l1l11l111_tv_ (u"ࠨࡣ࡯ࡩࠥࡱࡩ࡯ࡱ࠮ࠫᾹ"),
l11l1l11l111_tv_ (u"ࠩࡆࡥࡳࡧ࡬ࠨᾺ"):l11l1l11l111_tv_ (u"ࠪࡇࡦࡴࡡ࡭࠭ࠪΆ"),
l11l1l11l111_tv_ (u"ࠫࡈࡧ࡮ࡢ࡮ࠣࡗࡵࡵࡲࡵࠩᾼ"):l11l1l11l111_tv_ (u"ࠬࡉࡡ࡯ࡣ࡯࠯࡙ࠥࡰࡰࡴࡷࠫ᾽"),
l11l1l11l111_tv_ (u"࠭ࡃࡢࡰࡤࡰ࡙ࠥࡰࡰࡴࡷࠤ࠷࠭ι"):l11l1l11l111_tv_ (u"ࠧࡄࡣࡱࡥࡱ࠱ࠠࡔࡲࡲࡶࡹࠦ࠲ࠨ᾿"),
l11l1l11l111_tv_ (u"ࠨࡅࡤࡲࡦࡲࠠࡅ࡫ࡶࡧࡴࡼࡥࡳࡻࠪ῀"):l11l1l11l111_tv_ (u"ࠩࡆࡥࡳࡧ࡬ࠬࠢࡇ࡭ࡸࡩ࡯ࡷࡧࡵࡽࠥࡎࡄࠨ῁"),
l11l1l11l111_tv_ (u"ࠪࡇࡦࡴࡡ࡭ࠢ࠴ࠫῂ"):l11l1l11l111_tv_ (u"ࠫࡈࡧ࡮ࡢ࡮࠮ࠤ࠶࠭ῃ"),
l11l1l11l111_tv_ (u"ࠬࡉࡡ࡯ࡣ࡯ࠤࡘ࡫ࡲࡪࡣ࡯ࡩࠬῄ"):l11l1l11l111_tv_ (u"࠭ࡃࡢࡰࡤࡰ࠰ࠦࡓࡦࡴ࡬ࡥࡱ࡫ࠧ῅"),
l11l1l11l111_tv_ (u"ࠧࡄࡣࡱࡥࡱࠦࡆࡪ࡮ࡰࠫῆ"):l11l1l11l111_tv_ (u"ࠨࡅࡤࡲࡦࡲࠫࠡࡈ࡬ࡰࡲ࠭ῇ"),
l11l1l11l111_tv_ (u"ࠩࡑࡷࡵࡵࡲࡵࠩῈ"):l11l1l11l111_tv_ (u"ࠪࡲࡘࡶ࡯ࡳࡶࠪΈ"),
l11l1l11l111_tv_ (u"ࠫࡈࡧ࡮ࡢ࡮ࠣࡊࡦࡳࡩ࡭ࡻࠪῊ"):l11l1l11l111_tv_ (u"ࠬࡉࡡ࡯ࡣ࡯࠯ࠥࡌࡡ࡮࡫࡯ࡽࠬΉ"),
l11l1l11l111_tv_ (u"࠭ࡐ࡭ࡣࡱࡩࡹ࡫ࠧῌ"):l11l1l11l111_tv_ (u"ࠧࡑ࡮ࡤࡲࡪࡺࡥࠬࠩ῍"),
l11l1l11l111_tv_ (u"ࠨࡖࡨࡰࡪࡺ࡯ࡰࡰࠪ῎"):l11l1l11l111_tv_ (u"ࠩࡗࡩࡱ࡫ࡴࡰࡱࡱ࠯ࠬ῏"),
l11l1l11l111_tv_ (u"ࠪࡑ࡮ࡴࡩ࡮࡫ࡱ࡭ࠬῐ"):l11l1l11l111_tv_ (u"ࠫࡒ࡯࡮ࡪ࡯࡬ࡲ࡮࠱ࠧῑ"),
l11l1l11l111_tv_ (u"ࠬࡊ࡯࡮ࡱ࠮ࠫῒ"):l11l1l11l111_tv_ (u"࠭ࡄࡰ࡯ࡲ࠯ࠥࡎࡄࠨΐ"),
l11l1l11l111_tv_ (u"ࠧࡔࡶࡼࡰࡪࠦࡔࡗࡐࠪ῔"):l11l1l11l111_tv_ (u"ࠨࡖ࡙ࡒ࡙ࠥࡴࡺ࡮ࡨࠫ῕"),
l11l1l11l111_tv_ (u"ࠩࡄࡧࡹ࡯ࡶࡦࠢࡐࡩࡹ࡫࡯ࠡࡖ࡙ࡒࠬῖ"):l11l1l11l111_tv_ (u"ࠪࡘ࡛ࡔࠠࡎࡧࡷࡩࡴࠦࡁࡤࡶ࡬ࡺࡪ࠭ῗ"),
l11l1l11l111_tv_ (u"ࠫ࠷࠺ࠠࡕࡘࡑࠤࡇࡏࡓࠨῘ"):l11l1l11l111_tv_ (u"࡚ࠬࡖࡏࠢ࠵࠸ࠥࡈࡉࡔࠩῙ"),
l11l1l11l111_tv_ (u"࠭ࡔࡶࡴࡥࡳ࡚ࠥࡖࡏࠩῚ"):l11l1l11l111_tv_ (u"ࠧࡕࡘࡑࠤ࡙ࡻࡲࡣࡱࠪΊ"),
l11l1l11l111_tv_ (u"ࠨ࠴࠷ࠤ࡙࡜ࡎࠨ῜"):l11l1l11l111_tv_ (u"ࠩࡗ࡚ࡓࠦ࠲࠵ࠩ῝"),
l11l1l11l111_tv_ (u"ࠪ࠻࡚ࠥࡖࡏࠩ῞"):l11l1l11l111_tv_ (u"࡙ࠫ࡜ࡎࠡ࠹ࠪ῟"),
l11l1l11l111_tv_ (u"࡚ࠬࡖࡏ࠹ࠪῠ"):l11l1l11l111_tv_ (u"࠭ࡔࡗࡐࠣ࠻ࠬῡ"),
}
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    l1llll11l1l11l111_tv_ = fix.get(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠧࡵࡸ࡬ࡨࠬῢ")),l11l1l11l111_tv_ (u"ࠨࠩΰ"))
    if l1llll11l1l11l111_tv_:
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨῤ")]=l1llll11l1l11l111_tv_
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠪࡸࡻ࡯ࡤࠨῥ")]=l1llll11l1l11l111_tv_
    return l1l1l1ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},cookies=None,proxy={}):
    if proxy:
        urllib2.install_opener(urllib2.build_opener(urllib2.ProxyHandler(proxy)))
    if not header:
        header = {l11l1l11l111_tv_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨῦ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=10)
        if cookies==l11l1l11l111_tv_ (u"ࠬ࠭ῧ"):
            cookies=response.info()[l11l1l11l111_tv_ (u"࠭ࡓࡦࡶ࠰ࡇࡴࡵ࡫ࡪࡧࠪῨ")]
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࠨῩ")
    return l11ll11ll11l111_tv_
def l1l1lll111l11l111_tv_(l11ll1lllll11l111_tv_, l1ll111l1ll11l111_tv_, index):
    out,l1l111l1l1ll11l111_tv_ = l11lll11l1l11l111_tv_(l1l1l1llllll11l111_tv_=l11l1l11l111_tv_ (u"ࠨ࠳ࠪῪ"),l1l111l11lll11l111_tv_=l11l1l11l111_tv_ (u"ࠩ࠴࠸࠵࠭Ύ"),l11ll1lllll11l111_tv_=l11ll1lllll11l111_tv_)
    l1ll111l1ll11l111_tv_[index]=out
def l11l11l1l11l111_tv_(l1l1l1llllll11l111_tv_=l11l1l11l111_tv_ (u"ࠪ࠵ࠬῬ"),l1l111l11lll11l111_tv_=l11l1l11l111_tv_ (u"ࠫ࠶࠺࠰ࠨ῭"),addheader=False):
    out=[]
    l11lll1ll1l11l111_tv_ = range(10)
    l1l111lllll11l111_tv_ = []
    l1ll111l1ll11l111_tv_ = [[] for x in l11lll1ll1l11l111_tv_]
    for i,l11ll1lllll11l111_tv_ in enumerate(l11lll1ll1l11l111_tv_):
        thread = threading.Thread(name=l11l1l11l111_tv_ (u"࡚ࠬࡨࡳࡧࡤࡨࠪࡪࠧ΅")%i, target = l1l1lll111l11l111_tv_, args=[l11ll1lllll11l111_tv_+1,l1ll111l1ll11l111_tv_,i])
        l1l111lllll11l111_tv_.append(thread)
        thread.start()
    while any([i.isAlive() for i in l1l111lllll11l111_tv_]): time.sleep(0.1)
    del l1l111lllll11l111_tv_[:]
    for l1l1l1ll11l111_tv_ in l1ll111l1ll11l111_tv_:
        out.extend(l1l1l1ll11l111_tv_)
    if len(out)>0 and addheader:
        t=l11l1l11l111_tv_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡹࡦ࡮࡯ࡳࡼࡣࡕࡱࡦࡤࡸࡪࡪ࠺ࠡࠧࡶࠤ࠭ࡿ࡯ࡺ࠰ࡷࡺ࠮ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ`") %time.strftime(l11l1l11l111_tv_ (u"ࠢࠦࡦ࠲ࠩࡲ࠵࡚ࠥ࠼ࠣࠩࡍࡀࠥࡎ࠼ࠨࡗࠧ῰"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ῱"):t,l11l1l11l111_tv_ (u"ࠩࡷࡺ࡮ࡪࠧῲ"):l11l1l11l111_tv_ (u"ࠪࠫῳ"),l11l1l11l111_tv_ (u"ࠫ࡮ࡳࡧࠨῴ"):l11l1l11l111_tv_ (u"ࠬ࠭῵"),l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪῶ"):l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡺࡱࡼ࠲ࡹࡼ࠯ࠨῷ"),l11l1l11l111_tv_ (u"ࠨࡩࡵࡳࡺࡶࠧῸ"):l11l1l11l111_tv_ (u"ࠩࠪΌ"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࡥࡱࡩࠪῺ"):l11l1l11l111_tv_ (u"ࠫࠬΏ")})
    return out
def l11lll11l1l11l111_tv_(l1l1l1llllll11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࠷ࠧῼ"),l1l111l11lll11l111_tv_=l11l1l11l111_tv_ (u"࠭࠱࠵࠲ࠪ´"),l11ll1lllll11l111_tv_=4):
    url = l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡺࡱࡼ࠲ࡹࡼ࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࡁ࡯࡭ࡻ࡫࠽ࠦࡵࠩࡧࡴࡻ࡮ࡵࡴࡼࡁࠪࡹࠦࡱࡣࡪࡩࡂࠫࡤࠨ῾")%(l1l1l1llllll11l111_tv_,l1l111l11lll11l111_tv_,l11ll1lllll11l111_tv_)
    content = l111111l11l111_tv_(url)
    out=[]
    lists=re.compile(l11l1l11l111_tv_ (u"ࠨ࠾࡯࡭ࠥࡩ࡬ࡢࡵࡶࡁࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧ῿"),re.DOTALL).findall(content)
    for l1lll11l11l111_tv_ in lists:
        group=l11l1l11l111_tv_ (u"ࠩࠪ ")
        href = re.search(l11l1l11l111_tv_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠻࠱࠲ࡽࡴࡿ࠮ࡵࡸ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷ࠴࠴ࠪࡀࠫࠥࠫ "),l1lll11l11l111_tv_)
        src = re.search(l11l1l11l111_tv_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ "),l1lll11l11l111_tv_)
        title = re.search(l11l1l11l111_tv_ (u"ࠬࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ "),l1lll11l11l111_tv_)
        l1l111l1ll1l11l111_tv_ = l1lll11l11l111_tv_.find(l11l1l11l111_tv_ (u"࠭࠾ࡏ࡫ࡨࠤࡹࡸࡡ࡯ࡵࡰ࡭ࡹࡻࡪࡦ࠾ࠪ "))
        if href and title and src:
            t = title.group(1).replace(l11l1l11l111_tv_ (u"ࠧ࠯ࠩ "),l11l1l11l111_tv_ (u"ࠨࠩ ")).title()
            for s in [l11l1l11l111_tv_ (u"ࠩࡗ࡚ࠬ "),l11l1l11l111_tv_ (u"ࠪࡘ࡛ࡔࠧ "),l11l1l11l111_tv_ (u"ࠫࡒ࡚ࡖࠨ "),l11l1l11l111_tv_ (u"࡚ࠬࡖࡑࠩ "),l11l1l11l111_tv_ (u"࠭ࡂࡊࡕࠪ​"),l11l1l11l111_tv_ (u"ࠧࡕࡘࡕࠫ‌"),l11l1l11l111_tv_ (u"ࠨࡖ࡙ࡗࠬ‍"),l11l1l11l111_tv_ (u"ࠩࡋࡆࡔ࠭‎"),l11l1l11l111_tv_ (u"ࠪࡆࡇࡉࠧ‏"),l11l1l11l111_tv_ (u"ࠫࡆ࡞ࡎࠨ‐"),l11l1l11l111_tv_ (u"ࠬࡇࡔࡎࠩ‑"),l11l1l11l111_tv_ (u"࠭ࡁࡎࡅࠪ‒"),l11l1l11l111_tv_ (u"ࠧࡉࡆࠪ–"),l11l1l11l111_tv_ (u"ࠨࡖࡏࡇࠬ—"),l11l1l11l111_tv_ (u"ࠩࡌࡈࠬ―"),l11l1l11l111_tv_ (u"ࠪ࡜ࡉ࠭‖"),l11l1l11l111_tv_ (u"࡙ࠫ࡜ࡔࠨ‗"),l11l1l11l111_tv_ (u"ࠬࡉࡂࡔࠩ‘")]:
                t = re.sub(l11l1l11l111_tv_ (u"ࠨࠨࠩࡁ࡬࠭ࠧ’")+s+l11l1l11l111_tv_ (u"ࠢࠪࠤ‚"),s.upper(), t)
            if l1l111l1ll1l11l111_tv_>0 :
                t +=l11l1l11l111_tv_ (u"ࠨࠢ࡞ࡇࡔࡒࡏࡓࠢࡵࡩࡩࡣ࡯ࡧࡨ࡯࡭ࡳ࡫࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ‛")
            i = src.group(1)
            h = href.group(1)
            out.append(l1lll1l1l1l11l111_tv_({l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ“"):t,l11l1l11l111_tv_ (u"ࠪࡸࡻ࡯ࡤࠨ”"):t,l11l1l11l111_tv_ (u"ࠫ࡮ࡳࡧࠨ„"):i,l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩ‟"):h,l11l1l11l111_tv_ (u"࠭ࡧࡳࡱࡸࡴࠬ†"):group,l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࡩࡵ࡭ࠧ‡"):l11l1l11l111_tv_ (u"ࠨࠩ•")}))
    l1l111l1l11l11l111_tv_ = l11l1l11l111_tv_ (u"ࡴࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡽࡴࡿ࠮ࡵࡸ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࡄࡲࡩࡷࡧࡀࠩࡸࠬࡣࡰࡷࡱࡸࡷࡿ࠽ࠦࡵࠩࡴࡦ࡭ࡥ࠾ࠧࡧࠫ‣")%(l1l1l1llllll11l111_tv_,l1l111l11lll11l111_tv_,l11ll1lllll11l111_tv_+1)
    idx=content.find(l1l111l1l11l11l111_tv_)
    l1l111l1l1ll11l111_tv_ = l11ll1lllll11l111_tv_+1 if idx>-1 else None
    return out,l1l111l1l1ll11l111_tv_
l1lll1ll1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡣࡴࡤࡱࡰࡧ࠮ࡱࡴࡲࡼࡾ࠴࡮ࡦࡶ࠱ࡴࡱ࠵ࠧ․")
l1lll1llllll11l111_tv_=l11l1l11l111_tv_ (u"ࠫࠬ‥")
def l1lll1l1llll11l111_tv_(url,header={}):
    l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࠭…")
    global l1lll1llllll11l111_tv_
    if not l1lll1llllll11l111_tv_:
        req = urllib2.Request(l1lll1ll1lll11l111_tv_,data=None,headers={l11l1l11l111_tv_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ‧"): l1lll1l1lll11l111_tv_,l11l1l11l111_tv_ (u"ࠧࡖࡲࡪࡶࡦࡪࡥ࠮ࡋࡱࡷࡪࡩࡵࡳࡧ࠰ࡖࡪࡷࡵࡦࡵࡷࡷࠬ "):1})
        response = urllib2.urlopen(req)
        cookies=response.headers.get(l11l1l11l111_tv_ (u"ࠨࡵࡨࡸ࠲ࡩ࡯ࡰ࡭࡬ࡩࠬ "),l11l1l11l111_tv_ (u"ࠩࠣࠫ‪")).split(l11l1l11l111_tv_ (u"ࠪࠤࠬ‫"))[0]
        response.close()
        l1lll1llllll11l111_tv_ = cookies
    else:
        cookies=l1lll1llllll11l111_tv_
    data = l11l1l11l111_tv_ (u"ࠫࡺࡃࠥࡴࠨࡤࡰࡱࡵࡷࡄࡱࡲ࡯࡮࡫ࡳ࠾ࡱࡱࠫ‬")%urllib.quote_plus(url)
    l1lll1l1111l11l111_tv_ = l1lll1ll1lll11l111_tv_+l11l1l11l111_tv_ (u"ࠬ࠵ࡩ࡯ࡥ࡯ࡹࡩ࡫ࡳ࠰ࡲࡵࡳࡨ࡫ࡳࡴ࠰ࡳ࡬ࡵࡅࡡࡤࡶ࡬ࡳࡳࡃࡵࡱࡦࡤࡸࡪ࠭‭")
    headers={l11l1l11l111_tv_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ‮"): l1lll1l1lll11l111_tv_,l11l1l11l111_tv_ (u"ࠧࡖࡲࡪࡶࡦࡪࡥ࠮ࡋࡱࡷࡪࡩࡵࡳࡧ࠰ࡖࡪࡷࡵࡦࡵࡷࡷࠬ "):1,l11l1l11l111_tv_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ‰"):cookies}
    headers.update(header)
    req = urllib2.Request(l1lll1l1111l11l111_tv_,data,headers)
    response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
    l11ll11ll11l111_tv_=response.read()
    if l11l1l11l111_tv_ (u"ࠩࡶࡷࡱࡧࡧࡳࡧࡨࠫ‱") in l11ll11ll11l111_tv_:
        l1lll1l1111l11l111_tv_ = l1lll1ll1lll11l111_tv_+l11l1l11l111_tv_ (u"ࠪ࠳࡮ࡴࡣ࡭ࡷࡧࡩࡸ࠵ࡰࡳࡱࡦࡩࡸࡹ࠮ࡱࡪࡳࡃࡦࡩࡴࡪࡱࡱࡁࡸࡹ࡬ࡢࡩࡵࡩࡪ࠭′")
        req = urllib2.Request(l1lll1l1111l11l111_tv_,data,headers)
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_=response.read()
    response.close()
    print l11l1l11l111_tv_ (u"ࠫࡌࡇࡔࡆࠢ࡬ࡲ࡛ࠥࡓࡆࠩ″")
    return l11ll11ll11l111_tv_
def l1lll1l11l1l11l111_tv_():
    content=l111111l11l111_tv_(l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰࡬ࡨࡨࡲ࡯ࡢ࡭࠱ࡧࡴࡳ࠯ࡱࡴࡲࡼࡾࡲࡩࡴࡶ࠲ࡪࡷ࡫ࡥ࠮ࡲࡵࡳࡽࡿ࠭࡭࡫ࡶࡸ࠲ࡶ࡯࡭ࡣࡱࡨ࠳࡮ࡴ࡮࡮ࠪ‴"))
    l1lll1lll1ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭࠼ࡥ࡫ࡹࠤࡸࡺࡹ࡭ࡧࡀࠦࡼ࡯ࡤࡵࡪ࠽ࡠࡩ࠱ࠥࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫࡠࡩ࠱ࠩࠦࠤࡁࡀ࠴ࡪࡩࡷࡀࠪ‵")).findall(content)
    l1lll1l1l11l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠧ࠽ࡶࡧࡂ࠭࡮ࡴࡵࡲ࡞ࡷࡢ࠰ࠩ࠽࠱ࡷࡨࡃࡂࡴࡥࡀࠫࡠࡩ࠱ࠩ࠽࠱ࡷࡨࡃࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡨࡃ࠭‶"),re.DOTALL).findall(content)
    proxies=[{x[0]: l11l1l11l111_tv_ (u"ࠨࠧࡶ࠾ࠪࡹࠧ‷")%(x[2],x[1])} for x in l1lll1l1l11l11l111_tv_]
    return proxies
def l111l1lll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽࡴࡿ࠮ࡵࡸ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷ࠴࠼࠶࠶࠻ࠪ‸")):
    l1lll1ll11l11l111_tv_=[]
    if l11l1l11l111_tv_ (u"ࠪࡽࡴࡿ࠮ࡵࡸࠪ‹") in url:
        content = l111111l11l111_tv_(url)
        l1l111l11l1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡋࡲࡡࡴࡪ࡙ࡥࡷࡹࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ›")).findall(content)
        src = re.compile(l11l1l11l111_tv_ (u"ࠬࠨࡨࡵࡶࡳࠬ࠳࠰࠿ࠪ࠰ࡰ࠷ࡺ࠾ࠢࠨ※")).findall(content)
        if l1l111l11l1l11l111_tv_:
            l111111llll11l111_tv_ = re.search(l11l1l11l111_tv_ (u"࠭ࠨࡳࡶࡰࡴ࠿࠵࠯࠯ࠬࡂ࠭ࡡࠬࠧ‼"),l1l111l11l1l11l111_tv_[0])
            l11111lll1l11l111_tv_ = re.search(l11l1l11l111_tv_ (u"ࠧࡤ࡫ࡧࡁ࠭࠴ࠪࡀࠫ࡟ࠪࠬ‽"),l1l111l11l1l11l111_tv_[0])
            if l111111llll11l111_tv_:
                l1l111l1111l11l111_tv_ = map(int,re.compile(l11l1l11l111_tv_ (u"ࠨ࠱ࠫࡠࡩ࠱ࠩ࡝࠰ࠫࡠࡩ࠱ࠩ࡝࠰ࠫࡠࡩ࠱ࠩ࡝࠰ࠫࡠࡩ࠱ࠩ࠰ࠩ‾")).findall(l111111llll11l111_tv_.group(1))[0])
                l1l111l111ll11l111_tv_ = l11l1l11l111_tv_ (u"ࠩ࠱ࠫ‿").join([str(255-l1l111l1111l11l111_tv_[x]) for x in [3,2,0,1]])
                l1ll11lll1l11l111_tv_ = l11l1l11l111_tv_ (u"ࠪࡶࡹࡳࡰ࠻࠱࠲ࠫ⁀")+l1l111l111ll11l111_tv_+l11l1l11l111_tv_ (u"ࠫ࠴ࡿ࡯ࡺ࠱ࡢࡨࡪ࡬ࡩ࡯ࡵࡷࡣ࠴࠭⁁")+l11111lll1l11l111_tv_.group(1).strip() +l11l1l11l111_tv_ (u"ࠬࠦࡳࡸࡨࡘࡶࡱࡃࡨࡵࡶࡳ࠾࠴࠵ࡹࡰࡻ࠱ࡸࡻ࠵ࡰ࡭ࡣࡼࡩࡷࡼ࠳ࡢ࠰ࡶࡻ࡫ࠦࡳࡸࡨ࡙ࡪࡾࡃ࠱ࠡ࡮࡬ࡺࡪࡃ࠱ࠡࡶ࡬ࡱࡪࡵࡵࡵ࠿ࠪ⁂")+l1lll1ll1ll11l111_tv_+l11l1l11l111_tv_ (u"࠭ࠠࡱࡣࡪࡩ࡚ࡸ࡬࠾ࠩ⁃")+url
                l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫ⁄"):l1ll11lll1l11l111_tv_})
        elif src:
            l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬ⁅"):l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶࠧ⁆")+src[0]+l11l1l11l111_tv_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ⁇")})
        else:
            p = l1lll1l11l1l11l111_tv_()
            print
            for proxy in p:
                content = l111111l11l111_tv_(url,proxy=proxy)
                src = re.compile(l11l1l11l111_tv_ (u"ࠫࠧ࡮ࡴࡵࡲࠫ࠲࠯ࡅࠩ࠯࡯࠶ࡹ࠽ࠨࠧ⁈")).findall(content)
                print(l11l1l11l111_tv_ (u"ࠬ࡭ࡥࡵࡅ࡫ࡥࡳࡴࡥ࡭ࡘ࡬ࡨࡪࡵࠧ⁉"),url,src)
                if src:
                    v = l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳࠫ⁊")+src[0]+l11l1l11l111_tv_ (u"ࠧ࠯࡯࠶ࡹ࠽ࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠦࡵ࡙ࠩࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠦࡵࠪ⁋")&(url,l1lll1l1lll11l111_tv_)
                    print(l11l1l11l111_tv_ (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰ࡛࡯ࡤࡦࡱࠪ⁌"),url,v)
                    l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭⁍"):v})
                    break
        if not l1lll1ll11l11l111_tv_:
            l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠪࡱࡸ࡭ࠧ⁎"):l11l1l11l111_tv_ (u"࡚ࠫࡺࡷࣴࡴࡽࠤࡱ࡯ࡳࡵछࠣࡱ࠸ࡻࠠࡪࠢࡸঀࡾࡰࠠࡑࡘࡕࠤࡨࡲࡩࡦࡰࡷࠤࡧࡿࠠࡰ࡯࡬ࡲऊऍࠠࡍࡋࡐࡍ࡙ࡕࡗࡂࡐ࡜ࠤࡔࡑࡒࡆࡕࠣࡇ࡟ࡇࡓࡖࠢࡒࡋࡑऊࡄࡂࡐࡌࡅࠥ࡭ࡤࡺࠢࡷࡽࡱࡱ࡯ࠡ࡝ࡅࡡॿࡸࣳࡥ࡮ࡤࠤࡧटࡤआࠢࡽࡲࣸࡽࠠࡥࡱࡶࡸञࡶ࡮ࡦࠣࠤ࡟࠴ࡈ࡝ࠨ⁏")}]
    return l1lll1ll11l11l111_tv_
def test():
    out=l11l11l1l11l111_tv_()
    for o in out:
        print o.get(l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ⁐"))
