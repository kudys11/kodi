# coding: UTF-8
from __future__ import absolute_import
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
l11l1l11l111_tv_ (u"ࠧࠨࠢࡖࡶ࡬ࡰ࡮ࡺࡩࡦࡵࠣࡪࡴࡸࠠࡸࡴ࡬ࡸ࡮ࡴࡧࠡࡥࡲࡨࡪࠦࡴࡩࡣࡷࠤࡷࡻ࡮ࡴࠢࡲࡲࠥࡖࡹࡵࡪࡲࡲࠥ࠸ࠠࡢࡰࡧࠤ࠸ࠨࠢࠣᘈ")
import functools
import itertools
import operator
import sys
import types
__author__ = l11l1l11l111_tv_ (u"ࠨࡂࡦࡰ࡭ࡥࡲ࡯࡮ࠡࡒࡨࡸࡪࡸࡳࡰࡰࠣࡀࡧ࡫࡮࡫ࡣࡰ࡭ࡳࡆࡰࡺࡶ࡫ࡳࡳ࠴࡯ࡳࡩࡁࠦᘉ")
__version__ = l11l1l11l111_tv_ (u"ࠢ࠲࠰࠴࠴࠳࠶ࠢᘊ")
PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3
PY34 = sys.version_info[0:2] >= (3, 4)
if PY3:
    string_types = str,
    integer_types = int,
    class_types = type,
    text_type = str
    binary_type = bytes
    MAXSIZE = sys.maxsize
else:
    string_types = basestring,
    integer_types = (int, long)
    class_types = (type, types.ClassType)
    text_type = unicode
    binary_type = str
    if sys.platform.startswith(l11l1l11l111_tv_ (u"ࠣ࡬ࡤࡺࡦࠨᘋ")):
        MAXSIZE = int((1 << 31) - 1)
    else:
        class X(object):
            def __len__(self):
                return 1 << 31
        try:
            len(X())
        except OverflowError:
            MAXSIZE = int((1 << 31) - 1)
        else:
            MAXSIZE = int((1 << 63) - 1)
        del X
def _add_doc(func, doc):
    l11l1l11l111_tv_ (u"ࠤࠥࠦࡆࡪࡤࠡࡦࡲࡧࡺࡳࡥ࡯ࡶࡤࡸ࡮ࡵ࡮ࠡࡶࡲࠤࡦࠦࡦࡶࡰࡦࡸ࡮ࡵ࡮࠯ࠤࠥࠦᘌ")
    func.__doc__ = doc
def _import_module(name):
    l11l1l11l111_tv_ (u"ࠥࠦࠧࡏ࡭ࡱࡱࡵࡸࠥࡳ࡯ࡥࡷ࡯ࡩ࠱ࠦࡲࡦࡶࡸࡶࡳ࡯࡮ࡨࠢࡷ࡬ࡪࠦ࡭ࡰࡦࡸࡰࡪࠦࡡࡧࡶࡨࡶࠥࡺࡨࡦࠢ࡯ࡥࡸࡺࠠࡥࡱࡷ࠲ࠧࠨࠢᘍ")
    __import__(name)
    return sys.modules[name]
class _LazyDescr(object):
    def __init__(self, name):
        self.name = name
    def __get__(self, obj, tp):
        result = self._resolve()
        setattr(obj, self.name, result)
        try:
            delattr(obj.__class__, self.name)
        except AttributeError:
            pass
        return result
class MovedModule(_LazyDescr):
    def __init__(self, name, old, new=None):
        super(MovedModule, self).__init__(name)
        if PY3:
            if new is None:
                new = name
            self.mod = new
        else:
            self.mod = old
    def _resolve(self):
        return _import_module(self.mod)
    def __getattr__(self, attr):
        _module = self._resolve()
        value = getattr(_module, attr)
        setattr(self, attr, value)
        return value
class _LazyModule(types.ModuleType):
    def __init__(self, name):
        super(_LazyModule, self).__init__(name)
        self.__doc__ = self.__class__.__doc__
    def __dir__(self):
        attrs = [l11l1l11l111_tv_ (u"ࠦࡤࡥࡤࡰࡥࡢࡣࠧᘎ"), l11l1l11l111_tv_ (u"ࠧࡥ࡟࡯ࡣࡰࡩࡤࡥࠢᘏ")]
        attrs += [attr.name for attr in self._moved_attributes]
        return attrs
    _moved_attributes = []
class MovedAttribute(_LazyDescr):
    def __init__(self, name, old_mod, new_mod, old_attr=None, new_attr=None):
        super(MovedAttribute, self).__init__(name)
        if PY3:
            if new_mod is None:
                new_mod = name
            self.mod = new_mod
            if new_attr is None:
                if old_attr is None:
                    new_attr = name
                else:
                    new_attr = old_attr
            self.attr = new_attr
        else:
            self.mod = old_mod
            if old_attr is None:
                old_attr = name
            self.attr = old_attr
    def _resolve(self):
        module = _import_module(self.mod)
        return getattr(module, self.attr)
class _SixMetaPathImporter(object):
    l11l1l11l111_tv_ (u"ࠨࠢࠣࠌࠣࠤࠥࠦࡁࠡ࡯ࡨࡸࡦࠦࡰࡢࡶ࡫ࠤ࡮ࡳࡰࡰࡴࡷࡩࡷࠦࡴࡰࠢ࡬ࡱࡵࡵࡲࡵࠢࡶ࡭ࡽ࠴࡭ࡰࡸࡨࡷࠥࡧ࡮ࡥࠢ࡬ࡸࡸࠦࡳࡶࡤࡰࡳࡩࡻ࡬ࡦࡵ࠱ࠎࠏࠦࠠࠡࠢࡗ࡬࡮ࡹࠠࡤ࡮ࡤࡷࡸࠦࡩ࡮ࡲ࡯ࡩࡲ࡫࡮ࡵࡵࠣࡥࠥࡖࡅࡑ࠵࠳࠶ࠥ࡬ࡩ࡯ࡦࡨࡶࠥࡧ࡮ࡥࠢ࡯ࡳࡦࡪࡥࡳ࠰ࠣࡍࡹࠦࡳࡩࡱࡸࡰࡩࠦࡢࡦࠢࡦࡳࡲࡶࡡࡵ࡫ࡥࡰࡪࠐࠠࠡࠢࠣࡻ࡮ࡺࡨࠡࡒࡼࡸ࡭ࡵ࡮ࠡ࠴࠱࠹ࠥࡧ࡮ࡥࠢࡤࡰࡱࠦࡥࡹ࡫ࡶࡸ࡮ࡴࡧࠡࡸࡨࡶࡸ࡯࡯࡯ࡵࠣࡳ࡫ࠦࡐࡺࡶ࡫ࡳࡳ࠹ࠊࠡࠢࠣࠤࠧࠨࠢᘐ")
    def __init__(self, six_module_name):
        self.name = six_module_name
        self.known_modules = {}
    def _add_module(self, mod, *fullnames):
        for fullname in fullnames:
            self.known_modules[self.name + l11l1l11l111_tv_ (u"ࠢ࠯ࠤᘑ") + fullname] = mod
    def _get_module(self, fullname):
        return self.known_modules[self.name + l11l1l11l111_tv_ (u"ࠣ࠰ࠥᘒ") + fullname]
    def find_module(self, fullname, path=None):
        if fullname in self.known_modules:
            return self
        return None
    def __get_module(self, fullname):
        try:
            return self.known_modules[fullname]
        except KeyError:
            raise ImportError(l11l1l11l111_tv_ (u"ࠤࡗ࡬࡮ࡹࠠ࡭ࡱࡤࡨࡪࡸࠠࡥࡱࡨࡷࠥࡴ࡯ࡵࠢ࡮ࡲࡴࡽࠠ࡮ࡱࡧࡹࡱ࡫ࠠࠣᘓ") + fullname)
    def load_module(self, fullname):
        try:
            return sys.modules[fullname]
        except KeyError:
            pass
        mod = self.__get_module(fullname)
        if isinstance(mod, MovedModule):
            mod = mod._resolve()
        else:
            mod.__loader__ = self
        sys.modules[fullname] = mod
        return mod
    def is_package(self, fullname):
        l11l1l11l111_tv_ (u"ࠥࠦࠧࠐࠠࠡࠢࠣࠤࠥࠦࠠࡓࡧࡷࡹࡷࡴࠠࡵࡴࡸࡩ࠱ࠦࡩࡧࠢࡷ࡬ࡪࠦ࡮ࡢ࡯ࡨࡨࠥࡳ࡯ࡥࡷ࡯ࡩࠥ࡯ࡳࠡࡣࠣࡴࡦࡩ࡫ࡢࡩࡨ࠲ࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡘࡧࠣࡲࡪ࡫ࡤࠡࡶ࡫࡭ࡸࠦ࡭ࡦࡶ࡫ࡳࡩࠦࡴࡰࠢࡪࡩࡹࠦࡣࡰࡴࡵࡩࡨࡺࠠࡴࡲࡨࡧࠥࡵࡢ࡫ࡧࡦࡸࡸࠦࡷࡪࡶ࡫ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡖࡹࡵࡪࡲࡲࠥ࠹࠮࠵ࠢࠫࡷࡪ࡫ࠠࡑࡇࡓ࠸࠺࠷ࠩࠋࠢࠣࠤࠥࠦࠠࠡࠢࠥࠦࠧᘔ")
        return hasattr(self.__get_module(fullname), l11l1l11l111_tv_ (u"ࠦࡤࡥࡰࡢࡶ࡫ࡣࡤࠨᘕ"))
    def get_code(self, fullname):
        l11l1l11l111_tv_ (u"ࠧࠨࠢࡓࡧࡷࡹࡷࡴࠠࡏࡱࡱࡩࠏࠐࠠࠡࠢࠣࠤࠥࠦࠠࡓࡧࡴࡹ࡮ࡸࡥࡥ࠮ࠣ࡭࡫ࠦࡩࡴࡡࡳࡥࡨࡱࡡࡨࡧࠣ࡭ࡸࠦࡩ࡮ࡲ࡯ࡩࡲ࡫࡮ࡵࡧࡧࠦࠧࠨᘖ")
        self.__get_module(fullname)
        return None
    get_source = get_code
_importer = _SixMetaPathImporter(__name__)
class _MovedItems(_LazyModule):
    l11l1l11l111_tv_ (u"ࠨࠢࠣࡎࡤࡾࡾࠦ࡬ࡰࡣࡧ࡭ࡳ࡭ࠠࡰࡨࠣࡱࡴࡼࡥࡥࠢࡲࡦ࡯࡫ࡣࡵࡵࠥࠦࠧᘗ")
    __path__ = []
_moved_attributes = [
    MovedAttribute(l11l1l11l111_tv_ (u"ࠢࡤࡕࡷࡶ࡮ࡴࡧࡊࡑࠥᘘ"), l11l1l11l111_tv_ (u"ࠣࡥࡖࡸࡷ࡯࡮ࡨࡋࡒࠦᘙ"), l11l1l11l111_tv_ (u"ࠤ࡬ࡳࠧᘚ"), l11l1l11l111_tv_ (u"ࠥࡗࡹࡸࡩ࡯ࡩࡌࡓࠧᘛ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠦ࡫࡯࡬ࡵࡧࡵࠦᘜ"), l11l1l11l111_tv_ (u"ࠧ࡯ࡴࡦࡴࡷࡳࡴࡲࡳࠣᘝ"), l11l1l11l111_tv_ (u"ࠨࡢࡶ࡫࡯ࡸ࡮ࡴࡳࠣᘞ"), l11l1l11l111_tv_ (u"ࠢࡪࡨ࡬ࡰࡹ࡫ࡲࠣᘟ"), l11l1l11l111_tv_ (u"ࠣࡨ࡬ࡰࡹ࡫ࡲࠣᘠ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠤࡩ࡭ࡱࡺࡥࡳࡨࡤࡰࡸ࡫ࠢᘡ"), l11l1l11l111_tv_ (u"ࠥ࡭ࡹ࡫ࡲࡵࡱࡲࡰࡸࠨᘢ"), l11l1l11l111_tv_ (u"ࠦ࡮ࡺࡥࡳࡶࡲࡳࡱࡹࠢᘣ"), l11l1l11l111_tv_ (u"ࠧ࡯ࡦࡪ࡮ࡷࡩࡷ࡬ࡡ࡭ࡵࡨࠦᘤ"), l11l1l11l111_tv_ (u"ࠨࡦࡪ࡮ࡷࡩࡷ࡬ࡡ࡭ࡵࡨࠦᘥ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠢࡪࡰࡳࡹࡹࠨᘦ"), l11l1l11l111_tv_ (u"ࠣࡡࡢࡦࡺ࡯࡬ࡵ࡫ࡱࡣࡤࠨᘧ"), l11l1l11l111_tv_ (u"ࠤࡥࡹ࡮ࡲࡴࡪࡰࡶࠦᘨ"), l11l1l11l111_tv_ (u"ࠥࡶࡦࡽ࡟ࡪࡰࡳࡹࡹࠨᘩ"), l11l1l11l111_tv_ (u"ࠦ࡮ࡴࡰࡶࡶࠥᘪ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠧ࡯࡮ࡵࡧࡵࡲࠧᘫ"), l11l1l11l111_tv_ (u"ࠨ࡟ࡠࡤࡸ࡭ࡱࡺࡩ࡯ࡡࡢࠦᘬ"), l11l1l11l111_tv_ (u"ࠢࡴࡻࡶࠦᘭ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠣ࡯ࡤࡴࠧᘮ"), l11l1l11l111_tv_ (u"ࠤ࡬ࡸࡪࡸࡴࡰࡱ࡯ࡷࠧᘯ"), l11l1l11l111_tv_ (u"ࠥࡦࡺ࡯࡬ࡵ࡫ࡱࡷࠧᘰ"), l11l1l11l111_tv_ (u"ࠦ࡮ࡳࡡࡱࠤᘱ"), l11l1l11l111_tv_ (u"ࠧࡳࡡࡱࠤᘲ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠨࡧࡦࡶࡦࡻࡩࠨᘳ"), l11l1l11l111_tv_ (u"ࠢࡰࡵࠥᘴ"), l11l1l11l111_tv_ (u"ࠣࡱࡶࠦᘵ"), l11l1l11l111_tv_ (u"ࠤࡪࡩࡹࡩࡷࡥࡷࠥᘶ"), l11l1l11l111_tv_ (u"ࠥ࡫ࡪࡺࡣࡸࡦࠥᘷ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠦ࡬࡫ࡴࡤࡹࡧࡦࠧᘸ"), l11l1l11l111_tv_ (u"ࠧࡵࡳࠣᘹ"), l11l1l11l111_tv_ (u"ࠨ࡯ࡴࠤᘺ"), l11l1l11l111_tv_ (u"ࠢࡨࡧࡷࡧࡼࡪࠢᘻ"), l11l1l11l111_tv_ (u"ࠣࡩࡨࡸࡨࡽࡤࡣࠤᘼ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠤࡵࡥࡳ࡭ࡥࠣᘽ"), l11l1l11l111_tv_ (u"ࠥࡣࡤࡨࡵࡪ࡮ࡷ࡭ࡳࡥ࡟ࠣᘾ"), l11l1l11l111_tv_ (u"ࠦࡧࡻࡩ࡭ࡶ࡬ࡲࡸࠨᘿ"), l11l1l11l111_tv_ (u"ࠧࡾࡲࡢࡰࡪࡩࠧᙀ"), l11l1l11l111_tv_ (u"ࠨࡲࡢࡰࡪࡩࠧᙁ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠢࡳࡧ࡯ࡳࡦࡪ࡟࡮ࡱࡧࡹࡱ࡫ࠢᙂ"), l11l1l11l111_tv_ (u"ࠣࡡࡢࡦࡺ࡯࡬ࡵ࡫ࡱࡣࡤࠨᙃ"), l11l1l11l111_tv_ (u"ࠤ࡬ࡱࡵࡵࡲࡵ࡮࡬ࡦࠧᙄ") if PY34 else l11l1l11l111_tv_ (u"ࠥ࡭ࡲࡶࠢᙅ"), l11l1l11l111_tv_ (u"ࠦࡷ࡫࡬ࡰࡣࡧࠦᙆ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠧࡸࡥࡥࡷࡦࡩࠧᙇ"), l11l1l11l111_tv_ (u"ࠨ࡟ࡠࡤࡸ࡭ࡱࡺࡩ࡯ࡡࡢࠦᙈ"), l11l1l11l111_tv_ (u"ࠢࡧࡷࡱࡧࡹࡵ࡯࡭ࡵࠥᙉ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠣࡵ࡫ࡰࡪࡾ࡟ࡲࡷࡲࡸࡪࠨᙊ"), l11l1l11l111_tv_ (u"ࠤࡳ࡭ࡵ࡫ࡳࠣᙋ"), l11l1l11l111_tv_ (u"ࠥࡷ࡭ࡲࡥࡹࠤᙌ"), l11l1l11l111_tv_ (u"ࠦࡶࡻ࡯ࡵࡧࠥᙍ")),
    MovedAttribute(l11l1l11l111_tv_ (u"࡙ࠧࡴࡳ࡫ࡱ࡫ࡎࡕࠢᙎ"), l11l1l11l111_tv_ (u"ࠨࡓࡵࡴ࡬ࡲ࡬ࡏࡏࠣᙏ"), l11l1l11l111_tv_ (u"ࠢࡪࡱࠥᙐ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠣࡗࡶࡩࡷࡊࡩࡤࡶࠥᙑ"), l11l1l11l111_tv_ (u"ࠤࡘࡷࡪࡸࡄࡪࡥࡷࠦᙒ"), l11l1l11l111_tv_ (u"ࠥࡧࡴࡲ࡬ࡦࡥࡷ࡭ࡴࡴࡳࠣᙓ")),
    MovedAttribute(l11l1l11l111_tv_ (u"࡚ࠦࡹࡥࡳࡎ࡬ࡷࡹࠨᙔ"), l11l1l11l111_tv_ (u"࡛ࠧࡳࡦࡴࡏ࡭ࡸࡺࠢᙕ"), l11l1l11l111_tv_ (u"ࠨࡣࡰ࡮࡯ࡩࡨࡺࡩࡰࡰࡶࠦᙖ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠢࡖࡵࡨࡶࡘࡺࡲࡪࡰࡪࠦᙗ"), l11l1l11l111_tv_ (u"ࠣࡗࡶࡩࡷ࡙ࡴࡳ࡫ࡱ࡫ࠧᙘ"), l11l1l11l111_tv_ (u"ࠤࡦࡳࡱࡲࡥࡤࡶ࡬ࡳࡳࡹࠢᙙ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠥࡼࡷࡧ࡮ࡨࡧࠥᙚ"), l11l1l11l111_tv_ (u"ࠦࡤࡥࡢࡶ࡫࡯ࡸ࡮ࡴ࡟ࡠࠤᙛ"), l11l1l11l111_tv_ (u"ࠧࡨࡵࡪ࡮ࡷ࡭ࡳࡹࠢᙜ"), l11l1l11l111_tv_ (u"ࠨࡸࡳࡣࡱ࡫ࡪࠨᙝ"), l11l1l11l111_tv_ (u"ࠢࡳࡣࡱ࡫ࡪࠨᙞ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠣࡼ࡬ࡴࠧᙟ"), l11l1l11l111_tv_ (u"ࠤ࡬ࡸࡪࡸࡴࡰࡱ࡯ࡷࠧᙠ"), l11l1l11l111_tv_ (u"ࠥࡦࡺ࡯࡬ࡵ࡫ࡱࡷࠧᙡ"), l11l1l11l111_tv_ (u"ࠦ࡮ࢀࡩࡱࠤᙢ"), l11l1l11l111_tv_ (u"ࠧࢀࡩࡱࠤᙣ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠨࡺࡪࡲࡢࡰࡴࡴࡧࡦࡵࡷࠦᙤ"), l11l1l11l111_tv_ (u"ࠢࡪࡶࡨࡶࡹࡵ࡯࡭ࡵࠥᙥ"), l11l1l11l111_tv_ (u"ࠣ࡫ࡷࡩࡷࡺ࡯ࡰ࡮ࡶࠦᙦ"), l11l1l11l111_tv_ (u"ࠤ࡬ࡾ࡮ࡶ࡟࡭ࡱࡱ࡫ࡪࡹࡴࠣᙧ"), l11l1l11l111_tv_ (u"ࠥࡾ࡮ࡶ࡟࡭ࡱࡱ࡫ࡪࡹࡴࠣᙨ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠦࡧࡻࡩ࡭ࡶ࡬ࡲࡸࠨᙩ"), l11l1l11l111_tv_ (u"ࠧࡥ࡟ࡣࡷ࡬ࡰࡹ࡯࡮ࡠࡡࠥᙪ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠨࡣࡰࡰࡩ࡭࡬ࡶࡡࡳࡵࡨࡶࠧᙫ"), l11l1l11l111_tv_ (u"ࠢࡄࡱࡱࡪ࡮࡭ࡐࡢࡴࡶࡩࡷࠨᙬ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠣࡥࡲࡴࡾࡸࡥࡨࠤ᙭"), l11l1l11l111_tv_ (u"ࠤࡦࡳࡵࡿ࡟ࡳࡧࡪࠦ᙮")),
    MovedModule(l11l1l11l111_tv_ (u"ࠥࡨࡧࡳ࡟ࡨࡰࡸࠦᙯ"), l11l1l11l111_tv_ (u"ࠦ࡬ࡪࡢ࡮ࠤᙰ"), l11l1l11l111_tv_ (u"ࠧࡪࡢ࡮࠰ࡪࡲࡺࠨᙱ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠨ࡟ࡥࡷࡰࡱࡾࡥࡴࡩࡴࡨࡥࡩࠨᙲ"), l11l1l11l111_tv_ (u"ࠢࡥࡷࡰࡱࡾࡥࡴࡩࡴࡨࡥࡩࠨᙳ"), l11l1l11l111_tv_ (u"ࠣࡡࡧࡹࡲࡳࡹࡠࡶ࡫ࡶࡪࡧࡤࠣᙴ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠤ࡫ࡸࡹࡶ࡟ࡤࡱࡲ࡯࡮࡫ࡪࡢࡴࠥᙵ"), l11l1l11l111_tv_ (u"ࠥࡧࡴࡵ࡫ࡪࡧ࡯࡭ࡧࠨᙶ"), l11l1l11l111_tv_ (u"ࠦ࡭ࡺࡴࡱ࠰ࡦࡳࡴࡱࡩࡦ࡬ࡤࡶࠧᙷ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠧ࡮ࡴࡵࡲࡢࡧࡴࡵ࡫ࡪࡧࡶࠦᙸ"), l11l1l11l111_tv_ (u"ࠨࡃࡰࡱ࡮࡭ࡪࠨᙹ"), l11l1l11l111_tv_ (u"ࠢࡩࡶࡷࡴ࠳ࡩ࡯ࡰ࡭࡬ࡩࡸࠨᙺ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠣࡪࡷࡱࡱࡥࡥ࡯ࡶ࡬ࡸ࡮࡫ࡳࠣᙻ"), l11l1l11l111_tv_ (u"ࠤ࡫ࡸࡲࡲࡥ࡯ࡶ࡬ࡸࡾࡪࡥࡧࡵࠥᙼ"), l11l1l11l111_tv_ (u"ࠥ࡬ࡹࡳ࡬࠯ࡧࡱࡸ࡮ࡺࡩࡦࡵࠥᙽ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠦ࡭ࡺ࡭࡭ࡡࡳࡥࡷࡹࡥࡳࠤᙾ"), l11l1l11l111_tv_ (u"ࠧࡎࡔࡎࡎࡓࡥࡷࡹࡥࡳࠤᙿ"), l11l1l11l111_tv_ (u"ࠨࡨࡵ࡯࡯࠲ࡵࡧࡲࡴࡧࡵࠦ ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠢࡩࡶࡷࡴࡤࡩ࡬ࡪࡧࡱࡸࠧᚁ"), l11l1l11l111_tv_ (u"ࠣࡪࡷࡸࡵࡲࡩࡣࠤᚂ"), l11l1l11l111_tv_ (u"ࠤ࡫ࡸࡹࡶ࠮ࡤ࡮࡬ࡩࡳࡺࠢᚃ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠥࡩࡲࡧࡩ࡭ࡡࡰ࡭ࡲ࡫࡟࡮ࡷ࡯ࡸ࡮ࡶࡡࡳࡶࠥᚄ"), l11l1l11l111_tv_ (u"ࠦࡪࡳࡡࡪ࡮࠱ࡑࡎࡓࡅࡎࡷ࡯ࡸ࡮ࡶࡡࡳࡶࠥᚅ"), l11l1l11l111_tv_ (u"ࠧ࡫࡭ࡢ࡫࡯࠲ࡲ࡯࡭ࡦ࠰ࡰࡹࡱࡺࡩࡱࡣࡵࡸࠧᚆ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠨࡥ࡮ࡣ࡬ࡰࡤࡳࡩ࡮ࡧࡢࡲࡴࡴ࡭ࡶ࡮ࡷ࡭ࡵࡧࡲࡵࠤᚇ"), l11l1l11l111_tv_ (u"ࠢࡦ࡯ࡤ࡭ࡱ࠴ࡍࡊࡏࡈࡒࡴࡴࡍࡶ࡮ࡷ࡭ࡵࡧࡲࡵࠤᚈ"), l11l1l11l111_tv_ (u"ࠣࡧࡰࡥ࡮ࡲ࠮࡮࡫ࡰࡩ࠳ࡴ࡯࡯࡯ࡸࡰࡹ࡯ࡰࡢࡴࡷࠦᚉ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠤࡨࡱࡦ࡯࡬ࡠ࡯࡬ࡱࡪࡥࡴࡦࡺࡷࠦᚊ"), l11l1l11l111_tv_ (u"ࠥࡩࡲࡧࡩ࡭࠰ࡐࡍࡒࡋࡔࡦࡺࡷࠦᚋ"), l11l1l11l111_tv_ (u"ࠦࡪࡳࡡࡪ࡮࠱ࡱ࡮ࡳࡥ࠯ࡶࡨࡼࡹࠨᚌ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠧ࡫࡭ࡢ࡫࡯ࡣࡲ࡯࡭ࡦࡡࡥࡥࡸ࡫ࠢᚍ"), l11l1l11l111_tv_ (u"ࠨࡥ࡮ࡣ࡬ࡰ࠳ࡓࡉࡎࡇࡅࡥࡸ࡫ࠢᚎ"), l11l1l11l111_tv_ (u"ࠢࡦ࡯ࡤ࡭ࡱ࠴࡭ࡪ࡯ࡨ࠲ࡧࡧࡳࡦࠤᚏ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠣࡄࡤࡷࡪࡎࡔࡕࡒࡖࡩࡷࡼࡥࡳࠤᚐ"), l11l1l11l111_tv_ (u"ࠤࡅࡥࡸ࡫ࡈࡕࡖࡓࡗࡪࡸࡶࡦࡴࠥᚑ"), l11l1l11l111_tv_ (u"ࠥ࡬ࡹࡺࡰ࠯ࡵࡨࡶࡻ࡫ࡲࠣᚒ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠦࡈࡍࡉࡉࡖࡗࡔࡘ࡫ࡲࡷࡧࡵࠦᚓ"), l11l1l11l111_tv_ (u"ࠧࡉࡇࡊࡊࡗࡘࡕ࡙ࡥࡳࡸࡨࡶࠧᚔ"), l11l1l11l111_tv_ (u"ࠨࡨࡵࡶࡳ࠲ࡸ࡫ࡲࡷࡧࡵࠦᚕ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠢࡔ࡫ࡰࡴࡱ࡫ࡈࡕࡖࡓࡗࡪࡸࡶࡦࡴࠥᚖ"), l11l1l11l111_tv_ (u"ࠣࡕ࡬ࡱࡵࡲࡥࡉࡖࡗࡔࡘ࡫ࡲࡷࡧࡵࠦᚗ"), l11l1l11l111_tv_ (u"ࠤ࡫ࡸࡹࡶ࠮ࡴࡧࡵࡺࡪࡸࠢᚘ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠥࡧࡕ࡯ࡣ࡬࡮ࡨࠦᚙ"), l11l1l11l111_tv_ (u"ࠦࡨࡖࡩࡤ࡭࡯ࡩࠧᚚ"), l11l1l11l111_tv_ (u"ࠧࡶࡩࡤ࡭࡯ࡩࠧ᚛")),
    MovedModule(l11l1l11l111_tv_ (u"ࠨࡱࡶࡧࡸࡩࠧ᚜"), l11l1l11l111_tv_ (u"ࠢࡒࡷࡨࡹࡪࠨ᚝")),
    MovedModule(l11l1l11l111_tv_ (u"ࠣࡴࡨࡴࡷࡲࡩࡣࠤ᚞"), l11l1l11l111_tv_ (u"ࠤࡵࡩࡵࡸࠢ᚟")),
    MovedModule(l11l1l11l111_tv_ (u"ࠥࡷࡴࡩ࡫ࡦࡶࡶࡩࡷࡼࡥࡳࠤᚠ"), l11l1l11l111_tv_ (u"ࠦࡘࡵࡣ࡬ࡧࡷࡗࡪࡸࡶࡦࡴࠥᚡ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠧࡥࡴࡩࡴࡨࡥࡩࠨᚢ"), l11l1l11l111_tv_ (u"ࠨࡴࡩࡴࡨࡥࡩࠨᚣ"), l11l1l11l111_tv_ (u"ࠢࡠࡶ࡫ࡶࡪࡧࡤࠣᚤ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠣࡶ࡮࡭ࡳࡺࡥࡳࠤᚥ"), l11l1l11l111_tv_ (u"ࠤࡗ࡯࡮ࡴࡴࡦࡴࠥᚦ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠥࡸࡰ࡯࡮ࡵࡧࡵࡣࡩ࡯ࡡ࡭ࡱࡪࠦᚧ"), l11l1l11l111_tv_ (u"ࠦࡉ࡯ࡡ࡭ࡱࡪࠦᚨ"), l11l1l11l111_tv_ (u"ࠧࡺ࡫ࡪࡰࡷࡩࡷ࠴ࡤࡪࡣ࡯ࡳ࡬ࠨᚩ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠨࡴ࡬࡫ࡱࡸࡪࡸ࡟ࡧ࡫࡯ࡩࡩ࡯ࡡ࡭ࡱࡪࠦᚪ"), l11l1l11l111_tv_ (u"ࠢࡇ࡫࡯ࡩࡉ࡯ࡡ࡭ࡱࡪࠦᚫ"), l11l1l11l111_tv_ (u"ࠣࡶ࡮࡭ࡳࡺࡥࡳ࠰ࡩ࡭ࡱ࡫ࡤࡪࡣ࡯ࡳ࡬ࠨᚬ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠤࡷ࡯࡮ࡴࡴࡦࡴࡢࡷࡨࡸ࡯࡭࡮ࡨࡨࡹ࡫ࡸࡵࠤᚭ"), l11l1l11l111_tv_ (u"ࠥࡗࡨࡸ࡯࡭࡮ࡨࡨ࡙࡫ࡸࡵࠤᚮ"), l11l1l11l111_tv_ (u"ࠦࡹࡱࡩ࡯ࡶࡨࡶ࠳ࡹࡣࡳࡱ࡯ࡰࡪࡪࡴࡦࡺࡷࠦᚯ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠧࡺ࡫ࡪࡰࡷࡩࡷࡥࡳࡪ࡯ࡳࡰࡪࡪࡩࡢ࡮ࡲ࡫ࠧᚰ"), l11l1l11l111_tv_ (u"ࠨࡓࡪ࡯ࡳࡰࡪࡊࡩࡢ࡮ࡲ࡫ࠧᚱ"), l11l1l11l111_tv_ (u"ࠢࡵ࡭࡬ࡲࡹ࡫ࡲ࠯ࡵ࡬ࡱࡵࡲࡥࡥ࡫ࡤࡰࡴ࡭ࠢᚲ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠣࡶ࡮࡭ࡳࡺࡥࡳࡡࡷ࡭ࡽࠨᚳ"), l11l1l11l111_tv_ (u"ࠤࡗ࡭ࡽࠨᚴ"), l11l1l11l111_tv_ (u"ࠥࡸࡰ࡯࡮ࡵࡧࡵ࠲ࡹ࡯ࡸࠣᚵ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠦࡹࡱࡩ࡯ࡶࡨࡶࡤࡺࡴ࡬ࠤᚶ"), l11l1l11l111_tv_ (u"ࠧࡺࡴ࡬ࠤᚷ"), l11l1l11l111_tv_ (u"ࠨࡴ࡬࡫ࡱࡸࡪࡸ࠮ࡵࡶ࡮ࠦᚸ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠢࡵ࡭࡬ࡲࡹ࡫ࡲࡠࡥࡲࡲࡸࡺࡡ࡯ࡶࡶࠦᚹ"), l11l1l11l111_tv_ (u"ࠣࡖ࡮ࡧࡴࡴࡳࡵࡣࡱࡸࡸࠨᚺ"), l11l1l11l111_tv_ (u"ࠤࡷ࡯࡮ࡴࡴࡦࡴ࠱ࡧࡴࡴࡳࡵࡣࡱࡸࡸࠨᚻ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠥࡸࡰ࡯࡮ࡵࡧࡵࡣࡩࡴࡤࠣᚼ"), l11l1l11l111_tv_ (u"࡙ࠦࡱࡤ࡯ࡦࠥᚽ"), l11l1l11l111_tv_ (u"ࠧࡺ࡫ࡪࡰࡷࡩࡷ࠴ࡤ࡯ࡦࠥᚾ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠨࡴ࡬࡫ࡱࡸࡪࡸ࡟ࡤࡱ࡯ࡳࡷࡩࡨࡰࡱࡶࡩࡷࠨᚿ"), l11l1l11l111_tv_ (u"ࠢࡵ࡭ࡆࡳࡱࡵࡲࡄࡪࡲࡳࡸ࡫ࡲࠣᛀ"),
                l11l1l11l111_tv_ (u"ࠣࡶ࡮࡭ࡳࡺࡥࡳ࠰ࡦࡳࡱࡵࡲࡤࡪࡲࡳࡸ࡫ࡲࠣᛁ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠤࡷ࡯࡮ࡴࡴࡦࡴࡢࡧࡴࡳ࡭ࡰࡰࡧ࡭ࡦࡲ࡯ࡨࠤᛂ"), l11l1l11l111_tv_ (u"ࠥࡸࡰࡉ࡯࡮࡯ࡲࡲࡉ࡯ࡡ࡭ࡱࡪࠦᛃ"),
                l11l1l11l111_tv_ (u"ࠦࡹࡱࡩ࡯ࡶࡨࡶ࠳ࡩ࡯࡮࡯ࡲࡲࡩ࡯ࡡ࡭ࡱࡪࠦᛄ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠧࡺ࡫ࡪࡰࡷࡩࡷࡥࡴ࡬ࡨ࡬ࡰࡪࡪࡩࡢ࡮ࡲ࡫ࠧᛅ"), l11l1l11l111_tv_ (u"ࠨࡴ࡬ࡈ࡬ࡰࡪࡊࡩࡢ࡮ࡲ࡫ࠧᛆ"), l11l1l11l111_tv_ (u"ࠢࡵ࡭࡬ࡲࡹ࡫ࡲ࠯ࡨ࡬ࡰࡪࡪࡩࡢ࡮ࡲ࡫ࠧᛇ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠣࡶ࡮࡭ࡳࡺࡥࡳࡡࡩࡳࡳࡺࠢᛈ"), l11l1l11l111_tv_ (u"ࠤࡷ࡯ࡋࡵ࡮ࡵࠤᛉ"), l11l1l11l111_tv_ (u"ࠥࡸࡰ࡯࡮ࡵࡧࡵ࠲࡫ࡵ࡮ࡵࠤᛊ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠦࡹࡱࡩ࡯ࡶࡨࡶࡤࡳࡥࡴࡵࡤ࡫ࡪࡨ࡯ࡹࠤᛋ"), l11l1l11l111_tv_ (u"ࠧࡺ࡫ࡎࡧࡶࡷࡦ࡭ࡥࡃࡱࡻࠦᛌ"), l11l1l11l111_tv_ (u"ࠨࡴ࡬࡫ࡱࡸࡪࡸ࠮࡮ࡧࡶࡷࡦ࡭ࡥࡣࡱࡻࠦᛍ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠢࡵ࡭࡬ࡲࡹ࡫ࡲࡠࡶ࡮ࡷ࡮ࡳࡰ࡭ࡧࡧ࡭ࡦࡲ࡯ࡨࠤᛎ"), l11l1l11l111_tv_ (u"ࠣࡶ࡮ࡗ࡮ࡳࡰ࡭ࡧࡇ࡭ࡦࡲ࡯ࡨࠤᛏ"),
                l11l1l11l111_tv_ (u"ࠤࡷ࡯࡮ࡴࡴࡦࡴ࠱ࡷ࡮ࡳࡰ࡭ࡧࡧ࡭ࡦࡲ࡯ࡨࠤᛐ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠥࡹࡷࡲ࡬ࡪࡤࡢࡴࡦࡸࡳࡦࠤᛑ"), __name__ + l11l1l11l111_tv_ (u"ࠦ࠳ࡳ࡯ࡷࡧࡶ࠲ࡺࡸ࡬࡭࡫ࡥࡣࡵࡧࡲࡴࡧࠥᛒ"), l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳ࡶࡡࡳࡵࡨࠦᛓ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠨࡵࡳ࡮࡯࡭ࡧࡥࡥࡳࡴࡲࡶࠧᛔ"), __name__ + l11l1l11l111_tv_ (u"ࠢ࠯࡯ࡲࡺࡪࡹ࠮ࡶࡴ࡯ࡰ࡮ࡨ࡟ࡦࡴࡵࡳࡷࠨᛕ"), l11l1l11l111_tv_ (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠯ࡧࡵࡶࡴࡸࠢᛖ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠤࡸࡶࡱࡲࡩࡣࠤᛗ"), __name__ + l11l1l11l111_tv_ (u"ࠥ࠲ࡲࡵࡶࡦࡵ࠱ࡹࡷࡲ࡬ࡪࡤࠥᛘ"), __name__ + l11l1l11l111_tv_ (u"ࠦ࠳ࡳ࡯ࡷࡧࡶ࠲ࡺࡸ࡬࡭࡫ࡥࠦᛙ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭࡮࡬ࡦࡤࡸ࡯ࡣࡱࡷࡴࡦࡸࡳࡦࡴࠥᛚ"), l11l1l11l111_tv_ (u"ࠨࡲࡰࡤࡲࡸࡵࡧࡲࡴࡧࡵࠦᛛ"), l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠮ࡳࡱࡥࡳࡹࡶࡡࡳࡵࡨࡶࠧᛜ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠣࡺࡰࡰࡷࡶࡣࡠࡥ࡯࡭ࡪࡴࡴࠣᛝ"), l11l1l11l111_tv_ (u"ࠤࡻࡱࡱࡸࡰࡤ࡮࡬ࡦࠧᛞ"), l11l1l11l111_tv_ (u"ࠥࡼࡲࡲࡲࡱࡥ࠱ࡧࡱ࡯ࡥ࡯ࡶࠥᛟ")),
    MovedModule(l11l1l11l111_tv_ (u"ࠦࡽࡳ࡬ࡳࡲࡦࡣࡸ࡫ࡲࡷࡧࡵࠦᛠ"), l11l1l11l111_tv_ (u"࡙ࠧࡩ࡮ࡲ࡯ࡩ࡝ࡓࡌࡓࡒࡆࡗࡪࡸࡶࡦࡴࠥᛡ"), l11l1l11l111_tv_ (u"ࠨࡸ࡮࡮ࡵࡴࡨ࠴ࡳࡦࡴࡹࡩࡷࠨᛢ")),
]
if sys.platform == l11l1l11l111_tv_ (u"ࠢࡸ࡫ࡱ࠷࠷ࠨᛣ"):
    _moved_attributes += [
        MovedModule(l11l1l11l111_tv_ (u"ࠣࡹ࡬ࡲࡷ࡫ࡧࠣᛤ"), l11l1l11l111_tv_ (u"ࠤࡢࡻ࡮ࡴࡲࡦࡩࠥᛥ")),
    ]
for attr in _moved_attributes:
    setattr(_MovedItems, attr.name, attr)
    if isinstance(attr, MovedModule):
        _importer._add_module(attr, l11l1l11l111_tv_ (u"ࠥࡱࡴࡼࡥࡴ࠰ࠥᛦ") + attr.name)
del attr
_MovedItems._moved_attributes = _moved_attributes
moves = _MovedItems(__name__ + l11l1l11l111_tv_ (u"ࠦ࠳ࡳ࡯ࡷࡧࡶࠦᛧ"))
_importer._add_module(moves, l11l1l11l111_tv_ (u"ࠧࡳ࡯ࡷࡧࡶࠦᛨ"))
class Module_six_moves_urllib_parse(_LazyModule):
    l11l1l11l111_tv_ (u"ࠨࠢࠣࡎࡤࡾࡾࠦ࡬ࡰࡣࡧ࡭ࡳ࡭ࠠࡰࡨࠣࡱࡴࡼࡥࡥࠢࡲࡦ࡯࡫ࡣࡵࡵࠣ࡭ࡳࠦࡳࡪࡺ࠱ࡱࡴࡼࡥࡴ࠰ࡸࡶࡱࡲࡩࡣࡡࡳࡥࡷࡹࡥࠣࠤࠥᛩ")
_urllib_parse_moved_attributes = [
    MovedAttribute(l11l1l11l111_tv_ (u"ࠢࡑࡣࡵࡷࡪࡘࡥࡴࡷ࡯ࡸࠧᛪ"), l11l1l11l111_tv_ (u"ࠣࡷࡵࡰࡵࡧࡲࡴࡧࠥ᛫"), l11l1l11l111_tv_ (u"ࠤࡸࡶࡱࡲࡩࡣ࠰ࡳࡥࡷࡹࡥࠣ᛬")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠥࡗࡵࡲࡩࡵࡔࡨࡷࡺࡲࡴࠣ᛭"), l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬ࡱࡣࡵࡷࡪࠨᛮ"), l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳ࡶࡡࡳࡵࡨࠦᛯ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠨࡰࡢࡴࡶࡩࡤࡷࡳࠣᛰ"), l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯ࡴࡦࡸࡳࡦࠤᛱ"), l11l1l11l111_tv_ (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠯ࡲࡤࡶࡸ࡫ࠢᛲ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠤࡳࡥࡷࡹࡥࡠࡳࡶࡰࠧᛳ"), l11l1l11l111_tv_ (u"ࠥࡹࡷࡲࡰࡢࡴࡶࡩࠧᛴ"), l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡵࡧࡲࡴࡧࠥᛵ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭ࡦࡨࡪࡷࡧࡧࠣᛶ"), l11l1l11l111_tv_ (u"ࠨࡵࡳ࡮ࡳࡥࡷࡹࡥࠣᛷ"), l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠮ࡱࡣࡵࡷࡪࠨᛸ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠣࡷࡵࡰ࡯ࡵࡩ࡯ࠤ᛹"), l11l1l11l111_tv_ (u"ࠤࡸࡶࡱࡶࡡࡳࡵࡨࠦ᛺"), l11l1l11l111_tv_ (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠱ࡴࡦࡸࡳࡦࠤ᛻")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬ࡱࡣࡵࡷࡪࠨ᛼"), l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭ࡲࡤࡶࡸ࡫ࠢ᛽"), l11l1l11l111_tv_ (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠴ࡰࡢࡴࡶࡩࠧ᛾")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯ࡷࡵࡲࡩࡵࠤ᛿"), l11l1l11l111_tv_ (u"ࠣࡷࡵࡰࡵࡧࡲࡴࡧࠥᜀ"), l11l1l11l111_tv_ (u"ࠤࡸࡶࡱࡲࡩࡣ࠰ࡳࡥࡷࡹࡥࠣᜁ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠥࡹࡷࡲࡵ࡯ࡲࡤࡶࡸ࡫ࠢᜂ"), l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬ࡱࡣࡵࡷࡪࠨᜃ"), l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳ࡶࡡࡳࡵࡨࠦᜄ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠨࡵࡳ࡮ࡸࡲࡸࡶ࡬ࡪࡶࠥᜅ"), l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯ࡴࡦࡸࡳࡦࠤᜆ"), l11l1l11l111_tv_ (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠯ࡲࡤࡶࡸ࡫ࠢᜇ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠤࡴࡹࡴࡺࡥࠣᜈ"), l11l1l11l111_tv_ (u"ࠥࡹࡷࡲ࡬ࡪࡤࠥᜉ"), l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡵࡧࡲࡴࡧࠥᜊ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠧࡷࡵࡰࡶࡨࡣࡵࡲࡵࡴࠤᜋ"), l11l1l11l111_tv_ (u"ࠨࡵࡳ࡮࡯࡭ࡧࠨᜌ"), l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠮ࡱࡣࡵࡷࡪࠨᜍ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠣࡷࡱࡵࡺࡵࡴࡦࠤᜎ"), l11l1l11l111_tv_ (u"ࠤࡸࡶࡱࡲࡩࡣࠤᜏ"), l11l1l11l111_tv_ (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠱ࡴࡦࡸࡳࡦࠤᜐ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠦࡺࡴࡱࡶࡱࡷࡩࡤࡶ࡬ࡶࡵࠥᜑ"), l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭࡮࡬ࡦࠧᜒ"), l11l1l11l111_tv_ (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠴ࡰࡢࡴࡶࡩࠧᜓ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧ᜔ࠥ"), l11l1l11l111_tv_ (u"ࠣࡷࡵࡰࡱ࡯ࡢ᜕ࠣ"), l11l1l11l111_tv_ (u"ࠤࡸࡶࡱࡲࡩࡣ࠰ࡳࡥࡷࡹࡥࠣ᜖")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠥࡷࡵࡲࡩࡵࡳࡸࡩࡷࡿࠢ᜗"), l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬࡭࡫ࡥࠦ᜘"), l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳ࡶࡡࡳࡵࡨࠦ᜙")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠨࡳࡱ࡮࡬ࡸࡹࡧࡧࠣ᜚"), l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯ࡰ࡮ࡨࠢ᜛"), l11l1l11l111_tv_ (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠯ࡲࡤࡶࡸ࡫ࠢ᜜")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠤࡶࡴࡱ࡯ࡴࡶࡵࡨࡶࠧ᜝"), l11l1l11l111_tv_ (u"ࠥࡹࡷࡲ࡬ࡪࡤࠥ᜞"), l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡵࡧࡲࡴࡧࠥᜟ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠧࡻࡳࡦࡵࡢࡪࡷࡧࡧ࡮ࡧࡱࡸࠧᜠ"), l11l1l11l111_tv_ (u"ࠨࡵࡳ࡮ࡳࡥࡷࡹࡥࠣᜡ"), l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠮ࡱࡣࡵࡷࡪࠨᜢ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠣࡷࡶࡩࡸࡥ࡮ࡦࡶ࡯ࡳࡨࠨᜣ"), l11l1l11l111_tv_ (u"ࠤࡸࡶࡱࡶࡡࡳࡵࡨࠦᜤ"), l11l1l11l111_tv_ (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠱ࡴࡦࡸࡳࡦࠤᜥ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠦࡺࡹࡥࡴࡡࡳࡥࡷࡧ࡭ࡴࠤᜦ"), l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭ࡲࡤࡶࡸ࡫ࠢᜧ"), l11l1l11l111_tv_ (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠴ࡰࡢࡴࡶࡩࠧᜨ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠢࡶࡵࡨࡷࡤࡷࡵࡦࡴࡼࠦᜩ"), l11l1l11l111_tv_ (u"ࠣࡷࡵࡰࡵࡧࡲࡴࡧࠥᜪ"), l11l1l11l111_tv_ (u"ࠤࡸࡶࡱࡲࡩࡣ࠰ࡳࡥࡷࡹࡥࠣᜫ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠥࡹࡸ࡫ࡳࡠࡴࡨࡰࡦࡺࡩࡷࡧࠥᜬ"), l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬ࡱࡣࡵࡷࡪࠨᜭ"), l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳ࡶࡡࡳࡵࡨࠦᜮ")),
]
for attr in _urllib_parse_moved_attributes:
    setattr(Module_six_moves_urllib_parse, attr.name, attr)
del attr
Module_six_moves_urllib_parse._moved_attributes = _urllib_parse_moved_attributes
_importer._add_module(Module_six_moves_urllib_parse(__name__ + l11l1l11l111_tv_ (u"ࠨ࠮࡮ࡱࡹࡩࡸ࠴ࡵࡳ࡮࡯࡭ࡧࡥࡰࡢࡴࡶࡩࠧᜯ")),
                      l11l1l11l111_tv_ (u"ࠢ࡮ࡱࡹࡩࡸ࠴ࡵࡳ࡮࡯࡭ࡧࡥࡰࡢࡴࡶࡩࠧᜰ"), l11l1l11l111_tv_ (u"ࠣ࡯ࡲࡺࡪࡹ࠮ࡶࡴ࡯ࡰ࡮ࡨ࠮ࡱࡣࡵࡷࡪࠨᜱ"))
class Module_six_moves_urllib_error(_LazyModule):
    l11l1l11l111_tv_ (u"ࠤࠥࠦࡑࡧࡺࡺࠢ࡯ࡳࡦࡪࡩ࡯ࡩࠣࡳ࡫ࠦ࡭ࡰࡸࡨࡨࠥࡵࡢ࡫ࡧࡦࡸࡸࠦࡩ࡯ࠢࡶ࡭ࡽ࠴࡭ࡰࡸࡨࡷ࠳ࡻࡲ࡭࡮࡬ࡦࡤ࡫ࡲࡳࡱࡵࠦࠧࠨᜲ")
_urllib_error_moved_attributes = [
    MovedAttribute(l11l1l11l111_tv_ (u"࡙ࠥࡗࡒࡅࡳࡴࡲࡶࠧᜳ"), l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠶᜴ࠧ"), l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳࡫ࡲࡳࡱࡵࠦ᜵")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠨࡈࡕࡖࡓࡉࡷࡸ࡯ࡳࠤ᜶"), l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠲ࠣ᜷"), l11l1l11l111_tv_ (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠯ࡧࡵࡶࡴࡸࠢ᜸")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠤࡆࡳࡳࡺࡥ࡯ࡶࡗࡳࡴ࡙ࡨࡰࡴࡷࡉࡷࡸ࡯ࡳࠤ᜹"), l11l1l11l111_tv_ (u"ࠥࡹࡷࡲ࡬ࡪࡤࠥ᜺"), l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡪࡸࡲࡰࡴࠥ᜻")),
]
for attr in _urllib_error_moved_attributes:
    setattr(Module_six_moves_urllib_error, attr.name, attr)
del attr
Module_six_moves_urllib_error._moved_attributes = _urllib_error_moved_attributes
_importer._add_module(Module_six_moves_urllib_error(__name__ + l11l1l11l111_tv_ (u"ࠧ࠴࡭ࡰࡸࡨࡷ࠳ࡻࡲ࡭࡮࡬ࡦ࠳࡫ࡲࡳࡱࡵࠦ᜼")),
                      l11l1l11l111_tv_ (u"ࠨ࡭ࡰࡸࡨࡷ࠳ࡻࡲ࡭࡮࡬ࡦࡤ࡫ࡲࡳࡱࡵࠦ᜽"), l11l1l11l111_tv_ (u"ࠢ࡮ࡱࡹࡩࡸ࠴ࡵࡳ࡮࡯࡭ࡧ࠴ࡥࡳࡴࡲࡶࠧ᜾"))
class Module_six_moves_urllib_request(_LazyModule):
    l11l1l11l111_tv_ (u"ࠣࠤࠥࡐࡦࢀࡹࠡ࡮ࡲࡥࡩ࡯࡮ࡨࠢࡲࡪࠥࡳ࡯ࡷࡧࡧࠤࡴࡨࡪࡦࡥࡷࡷࠥ࡯࡮ࠡࡵ࡬ࡼ࠳ࡳ࡯ࡷࡧࡶ࠲ࡺࡸ࡬࡭࡫ࡥࡣࡷ࡫ࡱࡶࡧࡶࡸࠧࠨࠢ᜿")
_urllib_request_moved_attributes = [
    MovedAttribute(l11l1l11l111_tv_ (u"ࠤࡸࡶࡱࡵࡰࡦࡰࠥᝀ"), l11l1l11l111_tv_ (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠵ࠦᝁ"), l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡷ࡫ࡱࡶࡧࡶࡸࠧᝂ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠧ࡯࡮ࡴࡶࡤࡰࡱࡥ࡯ࡱࡧࡱࡩࡷࠨᝃ"), l11l1l11l111_tv_ (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠸ࠢᝄ"), l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠮ࡳࡧࡴࡹࡪࡹࡴࠣᝅ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡰࡲࡨࡲࡪࡸࠢᝆ"), l11l1l11l111_tv_ (u"ࠤࡸࡶࡱࡲࡩࡣ࠴ࠥᝇ"), l11l1l11l111_tv_ (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠱ࡶࡪࡷࡵࡦࡵࡷࠦᝈ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠦࡵࡧࡴࡩࡰࡤࡱࡪ࠸ࡵࡳ࡮ࠥᝉ"), l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭࡮࡬ࡦࠧᝊ"), l11l1l11l111_tv_ (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠴ࡲࡦࡳࡸࡩࡸࡺࠢᝋ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯࠶ࡵࡧࡴࡩࡰࡤࡱࡪࠨᝌ"), l11l1l11l111_tv_ (u"ࠣࡷࡵࡰࡱ࡯ࡢࠣᝍ"), l11l1l11l111_tv_ (u"ࠤࡸࡶࡱࡲࡩࡣ࠰ࡵࡩࡶࡻࡥࡴࡶࠥᝎ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠥ࡫ࡪࡺࡰࡳࡱࡻ࡭ࡪࡹࠢᝏ"), l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬࡭࡫ࡥࠦᝐ"), l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳ࡸࡥࡲࡷࡨࡷࡹࠨᝑ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠨࡒࡦࡳࡸࡩࡸࡺࠢᝒ"), l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠲ࠣᝓ"), l11l1l11l111_tv_ (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠯ࡴࡨࡵࡺ࡫ࡳࡵࠤ᝔")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠤࡒࡴࡪࡴࡥࡳࡆ࡬ࡶࡪࡩࡴࡰࡴࠥ᝕"), l11l1l11l111_tv_ (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠵ࠦ᝖"), l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡷ࡫ࡱࡶࡧࡶࡸࠧ᝗")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠧࡎࡔࡕࡒࡇࡩ࡫ࡧࡵ࡭ࡶࡈࡶࡷࡵࡲࡉࡣࡱࡨࡱ࡫ࡲࠣ᝘"), l11l1l11l111_tv_ (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠸ࠢ᝙"), l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠮ࡳࡧࡴࡹࡪࡹࡴࠣ᝚")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠣࡊࡗࡘࡕࡘࡥࡥ࡫ࡵࡩࡨࡺࡈࡢࡰࡧࡰࡪࡸࠢ᝛"), l11l1l11l111_tv_ (u"ࠤࡸࡶࡱࡲࡩࡣ࠴ࠥ᝜"), l11l1l11l111_tv_ (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠱ࡶࡪࡷࡵࡦࡵࡷࠦ᝝")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠦࡍ࡚ࡔࡑࡅࡲࡳࡰ࡯ࡥࡑࡴࡲࡧࡪࡹࡳࡰࡴࠥ᝞"), l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠷ࠨ᝟"), l11l1l11l111_tv_ (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠴ࡲࡦࡳࡸࡩࡸࡺࠢᝠ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠢࡑࡴࡲࡼࡾࡎࡡ࡯ࡦ࡯ࡩࡷࠨᝡ"), l11l1l11l111_tv_ (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠳ࠤᝢ"), l11l1l11l111_tv_ (u"ࠤࡸࡶࡱࡲࡩࡣ࠰ࡵࡩࡶࡻࡥࡴࡶࠥᝣ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠥࡆࡦࡹࡥࡉࡣࡱࡨࡱ࡫ࡲࠣᝤ"), l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠶ࠧᝥ"), l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳ࡸࡥࡲࡷࡨࡷࡹࠨᝦ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠨࡈࡕࡖࡓࡔࡦࡹࡳࡸࡱࡵࡨࡒ࡭ࡲࠣᝧ"), l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠲ࠣᝨ"), l11l1l11l111_tv_ (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠯ࡴࡨࡵࡺ࡫ࡳࡵࠤᝩ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠤࡋࡘ࡙ࡖࡐࡢࡵࡶࡻࡴࡸࡤࡎࡩࡵ࡛࡮ࡺࡨࡅࡧࡩࡥࡺࡲࡴࡓࡧࡤࡰࡲࠨᝪ"), l11l1l11l111_tv_ (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠵ࠦᝫ"), l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡷ࡫ࡱࡶࡧࡶࡸࠧᝬ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠧࡇࡢࡴࡶࡵࡥࡨࡺࡂࡢࡵ࡬ࡧࡆࡻࡴࡩࡊࡤࡲࡩࡲࡥࡳࠤ᝭"), l11l1l11l111_tv_ (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠸ࠢᝮ"), l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠮ࡳࡧࡴࡹࡪࡹࡴࠣᝯ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠣࡊࡗࡘࡕࡈࡡࡴ࡫ࡦࡅࡺࡺࡨࡉࡣࡱࡨࡱ࡫ࡲࠣᝰ"), l11l1l11l111_tv_ (u"ࠤࡸࡶࡱࡲࡩࡣ࠴ࠥ᝱"), l11l1l11l111_tv_ (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠱ࡶࡪࡷࡵࡦࡵࡷࠦᝲ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠦࡕࡸ࡯ࡹࡻࡅࡥࡸ࡯ࡣࡂࡷࡷ࡬ࡍࡧ࡮ࡥ࡮ࡨࡶࠧᝳ"), l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠷ࠨ᝴"), l11l1l11l111_tv_ (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠴ࡲࡦࡳࡸࡩࡸࡺࠢ᝵")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠢࡂࡤࡶࡸࡷࡧࡣࡵࡆ࡬࡫ࡪࡹࡴࡂࡷࡷ࡬ࡍࡧ࡮ࡥ࡮ࡨࡶࠧ᝶"), l11l1l11l111_tv_ (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠳ࠤ᝷"), l11l1l11l111_tv_ (u"ࠤࡸࡶࡱࡲࡩࡣ࠰ࡵࡩࡶࡻࡥࡴࡶࠥ᝸")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠥࡌ࡙࡚ࡐࡅ࡫ࡪࡩࡸࡺࡁࡶࡶ࡫ࡌࡦࡴࡤ࡭ࡧࡵࠦ᝹"), l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠶ࠧ᝺"), l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳ࡸࡥࡲࡷࡨࡷࡹࠨ᝻")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠨࡐࡳࡱࡻࡽࡉ࡯ࡧࡦࡵࡷࡅࡺࡺࡨࡉࡣࡱࡨࡱ࡫ࡲࠣ᝼"), l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠲ࠣ᝽"), l11l1l11l111_tv_ (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠯ࡴࡨࡵࡺ࡫ࡳࡵࠤ᝾")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠤࡋࡘ࡙ࡖࡈࡢࡰࡧࡰࡪࡸࠢ᝿"), l11l1l11l111_tv_ (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠵ࠦក"), l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡷ࡫ࡱࡶࡧࡶࡸࠧខ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠧࡎࡔࡕࡒࡖࡌࡦࡴࡤ࡭ࡧࡵࠦគ"), l11l1l11l111_tv_ (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠸ࠢឃ"), l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠮ࡳࡧࡴࡹࡪࡹࡴࠣង")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠣࡈ࡬ࡰࡪࡎࡡ࡯ࡦ࡯ࡩࡷࠨច"), l11l1l11l111_tv_ (u"ࠤࡸࡶࡱࡲࡩࡣ࠴ࠥឆ"), l11l1l11l111_tv_ (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠱ࡶࡪࡷࡵࡦࡵࡷࠦជ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠦࡋ࡚ࡐࡉࡣࡱࡨࡱ࡫ࡲࠣឈ"), l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠷ࠨញ"), l11l1l11l111_tv_ (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠴ࡲࡦࡳࡸࡩࡸࡺࠢដ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠢࡄࡣࡦ࡬ࡪࡌࡔࡑࡊࡤࡲࡩࡲࡥࡳࠤឋ"), l11l1l11l111_tv_ (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠳ࠤឌ"), l11l1l11l111_tv_ (u"ࠤࡸࡶࡱࡲࡩࡣ࠰ࡵࡩࡶࡻࡥࡴࡶࠥឍ")),
    MovedAttribute(l11l1l11l111_tv_ (u"࡙ࠥࡳࡱ࡮ࡰࡹࡱࡌࡦࡴࡤ࡭ࡧࡵࠦណ"), l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠶ࠧត"), l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳ࡸࡥࡲࡷࡨࡷࡹࠨថ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠨࡈࡕࡖࡓࡉࡷࡸ࡯ࡳࡒࡵࡳࡨ࡫ࡳࡴࡱࡵࠦទ"), l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠲ࠣធ"), l11l1l11l111_tv_ (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠯ࡴࡨࡵࡺ࡫ࡳࡵࠤន")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠤࡸࡶࡱࡸࡥࡵࡴ࡬ࡩࡻ࡫ࠢប"), l11l1l11l111_tv_ (u"ࠥࡹࡷࡲ࡬ࡪࡤࠥផ"), l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡷ࡫ࡱࡶࡧࡶࡸࠧព")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭ࡥ࡯ࡩࡦࡴࡵࡱࠤភ"), l11l1l11l111_tv_ (u"ࠨࡵࡳ࡮࡯࡭ࡧࠨម"), l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯ࡰ࡮ࡨ࠮ࡳࡧࡴࡹࡪࡹࡴࠣយ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠣࡗࡕࡐࡴࡶࡥ࡯ࡧࡵࠦរ"), l11l1l11l111_tv_ (u"ࠤࡸࡶࡱࡲࡩࡣࠤល"), l11l1l11l111_tv_ (u"ࠥࡹࡷࡲ࡬ࡪࡤ࠱ࡶࡪࡷࡵࡦࡵࡷࠦវ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠦࡋࡧ࡮ࡤࡻࡘࡖࡑࡵࡰࡦࡰࡨࡶࠧឝ"), l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭࡮࡬ࡦࠧឞ"), l11l1l11l111_tv_ (u"ࠨࡵࡳ࡮࡯࡭ࡧ࠴ࡲࡦࡳࡸࡩࡸࡺࠢស")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠢࡱࡴࡲࡼࡾࡥࡢࡺࡲࡤࡷࡸࠨហ"), l11l1l11l111_tv_ (u"ࠣࡷࡵࡰࡱ࡯ࡢࠣឡ"), l11l1l11l111_tv_ (u"ࠤࡸࡶࡱࡲࡩࡣ࠰ࡵࡩࡶࡻࡥࡴࡶࠥអ")),
]
for attr in _urllib_request_moved_attributes:
    setattr(Module_six_moves_urllib_request, attr.name, attr)
del attr
Module_six_moves_urllib_request._moved_attributes = _urllib_request_moved_attributes
_importer._add_module(Module_six_moves_urllib_request(__name__ + l11l1l11l111_tv_ (u"ࠥ࠲ࡲࡵࡶࡦࡵ࠱ࡹࡷࡲ࡬ࡪࡤ࠱ࡶࡪࡷࡵࡦࡵࡷࠦឣ")),
                      l11l1l11l111_tv_ (u"ࠦࡲࡵࡶࡦࡵ࠱ࡹࡷࡲ࡬ࡪࡤࡢࡶࡪࡷࡵࡦࡵࡷࠦឤ"), l11l1l11l111_tv_ (u"ࠧࡳ࡯ࡷࡧࡶ࠲ࡺࡸ࡬࡭࡫ࡥ࠲ࡷ࡫ࡱࡶࡧࡶࡸࠧឥ"))
class Module_six_moves_urllib_response(_LazyModule):
    l11l1l11l111_tv_ (u"ࠨࠢࠣࡎࡤࡾࡾࠦ࡬ࡰࡣࡧ࡭ࡳ࡭ࠠࡰࡨࠣࡱࡴࡼࡥࡥࠢࡲࡦ࡯࡫ࡣࡵࡵࠣ࡭ࡳࠦࡳࡪࡺ࠱ࡱࡴࡼࡥࡴ࠰ࡸࡶࡱࡲࡩࡣࡡࡵࡩࡸࡶ࡯࡯ࡵࡨࠦࠧࠨឦ")
_urllib_response_moved_attributes = [
    MovedAttribute(l11l1l11l111_tv_ (u"ࠢࡢࡦࡧࡦࡦࡹࡥࠣឧ"), l11l1l11l111_tv_ (u"ࠣࡷࡵࡰࡱ࡯ࡢࠣឨ"), l11l1l11l111_tv_ (u"ࠤࡸࡶࡱࡲࡩࡣ࠰ࡵࡩࡸࡶ࡯࡯ࡵࡨࠦឩ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠥࡥࡩࡪࡣ࡭ࡱࡶࡩ࡭ࡵ࡯࡬ࠤឪ"), l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬࡭࡫ࡥࠦឫ"), l11l1l11l111_tv_ (u"ࠧࡻࡲ࡭࡮࡬ࡦ࠳ࡸࡥࡴࡲࡲࡲࡸ࡫ࠢឬ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠨࡡࡥࡦ࡬ࡲ࡫ࡵࠢឭ"), l11l1l11l111_tv_ (u"ࠢࡶࡴ࡯ࡰ࡮ࡨࠢឮ"), l11l1l11l111_tv_ (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠯ࡴࡨࡷࡵࡵ࡮ࡴࡧࠥឯ")),
    MovedAttribute(l11l1l11l111_tv_ (u"ࠤࡤࡨࡩ࡯࡮ࡧࡱࡸࡶࡱࠨឰ"), l11l1l11l111_tv_ (u"ࠥࡹࡷࡲ࡬ࡪࡤࠥឱ"), l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡷ࡫ࡳࡱࡱࡱࡷࡪࠨឲ")),
]
for attr in _urllib_response_moved_attributes:
    setattr(Module_six_moves_urllib_response, attr.name, attr)
del attr
Module_six_moves_urllib_response._moved_attributes = _urllib_response_moved_attributes
_importer._add_module(Module_six_moves_urllib_response(__name__ + l11l1l11l111_tv_ (u"ࠧ࠴࡭ࡰࡸࡨࡷ࠳ࡻࡲ࡭࡮࡬ࡦ࠳ࡸࡥࡴࡲࡲࡲࡸ࡫ࠢឳ")),
                      l11l1l11l111_tv_ (u"ࠨ࡭ࡰࡸࡨࡷ࠳ࡻࡲ࡭࡮࡬ࡦࡤࡸࡥࡴࡲࡲࡲࡸ࡫ࠢ឴"), l11l1l11l111_tv_ (u"ࠢ࡮ࡱࡹࡩࡸ࠴ࡵࡳ࡮࡯࡭ࡧ࠴ࡲࡦࡵࡳࡳࡳࡹࡥࠣ឵"))
class Module_six_moves_urllib_robotparser(_LazyModule):
    l11l1l11l111_tv_ (u"ࠣࠤࠥࡐࡦࢀࡹࠡ࡮ࡲࡥࡩ࡯࡮ࡨࠢࡲࡪࠥࡳ࡯ࡷࡧࡧࠤࡴࡨࡪࡦࡥࡷࡷࠥ࡯࡮ࠡࡵ࡬ࡼ࠳ࡳ࡯ࡷࡧࡶ࠲ࡺࡸ࡬࡭࡫ࡥࡣࡷࡵࡢࡰࡶࡳࡥࡷࡹࡥࡳࠤࠥࠦា")
_urllib_robotparser_moved_attributes = [
    MovedAttribute(l11l1l11l111_tv_ (u"ࠤࡕࡳࡧࡵࡴࡇ࡫࡯ࡩࡕࡧࡲࡴࡧࡵࠦិ"), l11l1l11l111_tv_ (u"ࠥࡶࡴࡨ࡯ࡵࡲࡤࡶࡸ࡫ࡲࠣី"), l11l1l11l111_tv_ (u"ࠦࡺࡸ࡬࡭࡫ࡥ࠲ࡷࡵࡢࡰࡶࡳࡥࡷࡹࡥࡳࠤឹ")),
]
for attr in _urllib_robotparser_moved_attributes:
    setattr(Module_six_moves_urllib_robotparser, attr.name, attr)
del attr
Module_six_moves_urllib_robotparser._moved_attributes = _urllib_robotparser_moved_attributes
_importer._add_module(Module_six_moves_urllib_robotparser(__name__ + l11l1l11l111_tv_ (u"ࠧ࠴࡭ࡰࡸࡨࡷ࠳ࡻࡲ࡭࡮࡬ࡦ࠳ࡸ࡯ࡣࡱࡷࡴࡦࡸࡳࡦࡴࠥឺ")),
                      l11l1l11l111_tv_ (u"ࠨ࡭ࡰࡸࡨࡷ࠳ࡻࡲ࡭࡮࡬ࡦࡤࡸ࡯ࡣࡱࡷࡴࡦࡸࡳࡦࡴࠥុ"), l11l1l11l111_tv_ (u"ࠢ࡮ࡱࡹࡩࡸ࠴ࡵࡳ࡮࡯࡭ࡧ࠴ࡲࡰࡤࡲࡸࡵࡧࡲࡴࡧࡵࠦូ"))
class Module_six_moves_urllib(types.ModuleType):
    l11l1l11l111_tv_ (u"ࠣࠤࠥࡇࡷ࡫ࡡࡵࡧࠣࡥࠥࡹࡩࡹ࠰ࡰࡳࡻ࡫ࡳ࠯ࡷࡵࡰࡱ࡯ࡢࠡࡰࡤࡱࡪࡹࡰࡢࡥࡨࠤࡹ࡮ࡡࡵࠢࡵࡩࡸ࡫࡭ࡣ࡮ࡨࡷࠥࡺࡨࡦࠢࡓࡽࡹ࡮࡯࡯ࠢ࠶ࠤࡳࡧ࡭ࡦࡵࡳࡥࡨ࡫ࠢࠣࠤួ")
    __path__ = []
    parse = _importer._get_module(l11l1l11l111_tv_ (u"ࠤࡰࡳࡻ࡫ࡳ࠯ࡷࡵࡰࡱ࡯ࡢࡠࡲࡤࡶࡸ࡫ࠢើ"))
    error = _importer._get_module(l11l1l11l111_tv_ (u"ࠥࡱࡴࡼࡥࡴ࠰ࡸࡶࡱࡲࡩࡣࡡࡨࡶࡷࡵࡲࠣឿ"))
    request = _importer._get_module(l11l1l11l111_tv_ (u"ࠦࡲࡵࡶࡦࡵ࠱ࡹࡷࡲ࡬ࡪࡤࡢࡶࡪࡷࡵࡦࡵࡷࠦៀ"))
    response = _importer._get_module(l11l1l11l111_tv_ (u"ࠧࡳ࡯ࡷࡧࡶ࠲ࡺࡸ࡬࡭࡫ࡥࡣࡷ࡫ࡳࡱࡱࡱࡷࡪࠨេ"))
    robotparser = _importer._get_module(l11l1l11l111_tv_ (u"ࠨ࡭ࡰࡸࡨࡷ࠳ࡻࡲ࡭࡮࡬ࡦࡤࡸ࡯ࡣࡱࡷࡴࡦࡸࡳࡦࡴࠥែ"))
    def __dir__(self):
        return [l11l1l11l111_tv_ (u"ࠧࡱࡣࡵࡷࡪ࠭ៃ"), l11l1l11l111_tv_ (u"ࠨࡧࡵࡶࡴࡸࠧោ"), l11l1l11l111_tv_ (u"ࠩࡵࡩࡶࡻࡥࡴࡶࠪៅ"), l11l1l11l111_tv_ (u"ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬំ"), l11l1l11l111_tv_ (u"ࠫࡷࡵࡢࡰࡶࡳࡥࡷࡹࡥࡳࠩះ")]
_importer._add_module(Module_six_moves_urllib(__name__ + l11l1l11l111_tv_ (u"ࠧ࠴࡭ࡰࡸࡨࡷ࠳ࡻࡲ࡭࡮࡬ࡦࠧៈ")),
                      l11l1l11l111_tv_ (u"ࠨ࡭ࡰࡸࡨࡷ࠳ࡻࡲ࡭࡮࡬ࡦࠧ៉"))
def add_move(move):
    l11l1l11l111_tv_ (u"ࠢࠣࠤࡄࡨࡩࠦࡡ࡯ࠢ࡬ࡸࡪࡳࠠࡵࡱࠣࡷ࡮ࡾ࠮࡮ࡱࡹࡩࡸ࠴ࠢࠣࠤ៊")
    setattr(_MovedItems, move.name, move)
def remove_move(name):
    l11l1l11l111_tv_ (u"ࠣࠤࠥࡖࡪࡳ࡯ࡷࡧࠣ࡭ࡹ࡫࡭ࠡࡨࡵࡳࡲࠦࡳࡪࡺ࠱ࡱࡴࡼࡥࡴ࠰ࠥࠦࠧ់")
    try:
        delattr(_MovedItems, name)
    except AttributeError:
        try:
            del moves.__dict__[name]
        except KeyError:
            raise AttributeError(l11l1l11l111_tv_ (u"ࠤࡱࡳࠥࡹࡵࡤࡪࠣࡱࡴࡼࡥ࠭ࠢࠨࡶࠧ៌") % (name,))
if PY3:
    _meth_func = l11l1l11l111_tv_ (u"ࠥࡣࡤ࡬ࡵ࡯ࡥࡢࡣࠧ៍")
    _meth_self = l11l1l11l111_tv_ (u"ࠦࡤࡥࡳࡦ࡮ࡩࡣࡤࠨ៎")
    _func_closure = l11l1l11l111_tv_ (u"ࠧࡥ࡟ࡤ࡮ࡲࡷࡺࡸࡥࡠࡡࠥ៏")
    _func_code = l11l1l11l111_tv_ (u"ࠨ࡟ࡠࡥࡲࡨࡪࡥ࡟ࠣ័")
    _func_defaults = l11l1l11l111_tv_ (u"ࠢࡠࡡࡧࡩ࡫ࡧࡵ࡭ࡶࡶࡣࡤࠨ៑")
    _func_globals = l11l1l11l111_tv_ (u"ࠣࡡࡢ࡫ࡱࡵࡢࡢ࡮ࡶࡣࡤࠨ្")
else:
    _meth_func = l11l1l11l111_tv_ (u"ࠤ࡬ࡱࡤ࡬ࡵ࡯ࡥࠥ៓")
    _meth_self = l11l1l11l111_tv_ (u"ࠥ࡭ࡲࡥࡳࡦ࡮ࡩࠦ។")
    _func_closure = l11l1l11l111_tv_ (u"ࠦ࡫ࡻ࡮ࡤࡡࡦࡰࡴࡹࡵࡳࡧࠥ៕")
    _func_code = l11l1l11l111_tv_ (u"ࠧ࡬ࡵ࡯ࡥࡢࡧࡴࡪࡥࠣ៖")
    _func_defaults = l11l1l11l111_tv_ (u"ࠨࡦࡶࡰࡦࡣࡩ࡫ࡦࡢࡷ࡯ࡸࡸࠨៗ")
    _func_globals = l11l1l11l111_tv_ (u"ࠢࡧࡷࡱࡧࡤ࡭࡬ࡰࡤࡤࡰࡸࠨ៘")
try:
    advance_iterator = next
except NameError:
    def advance_iterator(it):
        return it.next()
next = advance_iterator
try:
    callable = callable
except NameError:
    def callable(obj):
        return any(l11l1l11l111_tv_ (u"ࠣࡡࡢࡧࡦࡲ࡬ࡠࡡࠥ៙") in klass.__dict__ for klass in type(obj).__mro__)
if PY3:
    def get_unbound_function(unbound):
        return unbound
    create_bound_method = types.MethodType
    def create_unbound_method(func, cls):
        return func
    Iterator = object
else:
    def get_unbound_function(unbound):
        return unbound.im_func
    def create_bound_method(func, obj):
        return types.MethodType(func, obj, obj.__class__)
    def create_unbound_method(func, cls):
        return types.MethodType(func, None, cls)
    class Iterator(object):
        def next(self):
            return type(self).__next__(self)
    callable = callable
_add_doc(get_unbound_function,
         l11l1l11l111_tv_ (u"ࠤࠥࠦࡌ࡫ࡴࠡࡶ࡫ࡩࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡰࡷࡷࠤࡴ࡬ࠠࡢࠢࡳࡳࡸࡹࡩࡣ࡮ࡼࠤࡺࡴࡢࡰࡷࡱࡨࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠢࠣࠤ៚"))
get_method_function = operator.attrgetter(_meth_func)
get_method_self = operator.attrgetter(_meth_self)
get_function_closure = operator.attrgetter(_func_closure)
get_function_code = operator.attrgetter(_func_code)
get_function_defaults = operator.attrgetter(_func_defaults)
get_function_globals = operator.attrgetter(_func_globals)
if PY3:
    def iterkeys(d, **kw):
        return iter(d.keys(**kw))
    def itervalues(d, **kw):
        return iter(d.values(**kw))
    def iteritems(d, **kw):
        return iter(d.items(**kw))
    def iterlists(d, **kw):
        return iter(d.lists(**kw))
    viewkeys = operator.methodcaller(l11l1l11l111_tv_ (u"ࠥ࡯ࡪࡿࡳࠣ៛"))
    viewvalues = operator.methodcaller(l11l1l11l111_tv_ (u"ࠦࡻࡧ࡬ࡶࡧࡶࠦៜ"))
    viewitems = operator.methodcaller(l11l1l11l111_tv_ (u"ࠧ࡯ࡴࡦ࡯ࡶࠦ៝"))
else:
    def iterkeys(d, **kw):
        return d.iterkeys(**kw)
    def itervalues(d, **kw):
        return d.itervalues(**kw)
    def iteritems(d, **kw):
        return d.iteritems(**kw)
    def iterlists(d, **kw):
        return d.iterlists(**kw)
    viewkeys = operator.methodcaller(l11l1l11l111_tv_ (u"ࠨࡶࡪࡧࡺ࡯ࡪࡿࡳࠣ៞"))
    viewvalues = operator.methodcaller(l11l1l11l111_tv_ (u"ࠢࡷ࡫ࡨࡻࡻࡧ࡬ࡶࡧࡶࠦ៟"))
    viewitems = operator.methodcaller(l11l1l11l111_tv_ (u"ࠣࡸ࡬ࡩࡼ࡯ࡴࡦ࡯ࡶࠦ០"))
_add_doc(iterkeys, l11l1l11l111_tv_ (u"ࠤࡕࡩࡹࡻࡲ࡯ࠢࡤࡲࠥ࡯ࡴࡦࡴࡤࡸࡴࡸࠠࡰࡸࡨࡶࠥࡺࡨࡦࠢ࡮ࡩࡾࡹࠠࡰࡨࠣࡥࠥࡪࡩࡤࡶ࡬ࡳࡳࡧࡲࡺ࠰ࠥ១"))
_add_doc(itervalues, l11l1l11l111_tv_ (u"ࠥࡖࡪࡺࡵࡳࡰࠣࡥࡳࠦࡩࡵࡧࡵࡥࡹࡵࡲࠡࡱࡹࡩࡷࠦࡴࡩࡧࠣࡺࡦࡲࡵࡦࡵࠣࡳ࡫ࠦࡡࠡࡦ࡬ࡧࡹ࡯࡯࡯ࡣࡵࡽ࠳ࠨ២"))
_add_doc(iteritems,
         l11l1l11l111_tv_ (u"ࠦࡗ࡫ࡴࡶࡴࡱࠤࡦࡴࠠࡪࡶࡨࡶࡦࡺ࡯ࡳࠢࡲࡺࡪࡸࠠࡵࡪࡨࠤ࠭ࡱࡥࡺ࠮ࠣࡺࡦࡲࡵࡦࠫࠣࡴࡦ࡯ࡲࡴࠢࡲࡪࠥࡧࠠࡥ࡫ࡦࡸ࡮ࡵ࡮ࡢࡴࡼ࠲ࠧ៣"))
_add_doc(iterlists,
         l11l1l11l111_tv_ (u"ࠧࡘࡥࡵࡷࡵࡲࠥࡧ࡮ࠡ࡫ࡷࡩࡷࡧࡴࡰࡴࠣࡳࡻ࡫ࡲࠡࡶ࡫ࡩࠥ࠮࡫ࡦࡻ࠯ࠤࡠࡼࡡ࡭ࡷࡨࡷࡢ࠯ࠠࡱࡣ࡬ࡶࡸࠦ࡯ࡧࠢࡤࠤࡩ࡯ࡣࡵ࡫ࡲࡲࡦࡸࡹ࠯ࠤ៤"))
if PY3:
    def b(s):
        return s.encode(l11l1l11l111_tv_ (u"ࠨ࡬ࡢࡶ࡬ࡲ࠲࠷ࠢ៥"))
    def u(s):
        return s
    unichr = chr
    import struct
    int2byte = struct.Struct(l11l1l11l111_tv_ (u"ࠢ࠿ࡄࠥ៦")).pack
    del struct
    byte2int = operator.itemgetter(0)
    indexbytes = operator.getitem
    iterbytes = iter
    import io
    StringIO = io.StringIO
    BytesIO = io.BytesIO
    _assertCountEqual = l11l1l11l111_tv_ (u"ࠣࡣࡶࡷࡪࡸࡴࡄࡱࡸࡲࡹࡋࡱࡶࡣ࡯ࠦ៧")
    if sys.version_info[1] <= 1:
        _assertRaisesRegex = l11l1l11l111_tv_ (u"ࠤࡤࡷࡸ࡫ࡲࡵࡔࡤ࡭ࡸ࡫ࡳࡓࡧࡪࡩࡽࡶࠢ៨")
        _assertRegex = l11l1l11l111_tv_ (u"ࠥࡥࡸࡹࡥࡳࡶࡕࡩ࡬࡫ࡸࡱࡏࡤࡸࡨ࡮ࡥࡴࠤ៩")
    else:
        _assertRaisesRegex = l11l1l11l111_tv_ (u"ࠦࡦࡹࡳࡦࡴࡷࡖࡦ࡯ࡳࡦࡵࡕࡩ࡬࡫ࡸࠣ៪")
        _assertRegex = l11l1l11l111_tv_ (u"ࠧࡧࡳࡴࡧࡵࡸࡗ࡫ࡧࡦࡺࠥ៫")
else:
    def b(s):
        return s
    def u(s):
        return unicode(s.replace(l11l1l11l111_tv_ (u"ࡸࠧ࡝࡞ࠪ៬"), l11l1l11l111_tv_ (u"ࡲࠨ࡞࡟ࡠࡡ࠭៭")), l11l1l11l111_tv_ (u"ࠣࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠤ៮"))
    unichr = unichr
    int2byte = chr
    def byte2int(bs):
        return ord(bs[0])
    def indexbytes(buf, i):
        return ord(buf[i])
    iterbytes = functools.partial(itertools.imap, ord)
    import StringIO
    StringIO = BytesIO = StringIO.StringIO
    _assertCountEqual = l11l1l11l111_tv_ (u"ࠤࡤࡷࡸ࡫ࡲࡵࡋࡷࡩࡲࡹࡅࡲࡷࡤࡰࠧ៯")
    _assertRaisesRegex = l11l1l11l111_tv_ (u"ࠥࡥࡸࡹࡥࡳࡶࡕࡥ࡮ࡹࡥࡴࡔࡨ࡫ࡪࡾࡰࠣ៰")
    _assertRegex = l11l1l11l111_tv_ (u"ࠦࡦࡹࡳࡦࡴࡷࡖࡪ࡭ࡥࡹࡲࡐࡥࡹࡩࡨࡦࡵࠥ៱")
_add_doc(b, l11l1l11l111_tv_ (u"ࠧࠨࠢࡃࡻࡷࡩࠥࡲࡩࡵࡧࡵࡥࡱࠨࠢࠣ៲"))
_add_doc(u, l11l1l11l111_tv_ (u"ࠨࠢࠣࡖࡨࡼࡹࠦ࡬ࡪࡶࡨࡶࡦࡲࠢࠣࠤ៳"))
def assertCountEqual(self, *args, **kwargs):
    return getattr(self, _assertCountEqual)(*args, **kwargs)
def assertRaisesRegex(self, *args, **kwargs):
    return getattr(self, _assertRaisesRegex)(*args, **kwargs)
def assertRegex(self, *args, **kwargs):
    return getattr(self, _assertRegex)(*args, **kwargs)
if PY3:
    exec_ = getattr(moves.builtins, l11l1l11l111_tv_ (u"ࠢࡦࡺࡨࡧࠧ៴"))
    def reraise(tp, value, tb=None):
        if value is None:
            value = tp()
        if value.__traceback__ is not tb:
            raise value.with_traceback(tb)
        raise value
else:
    def exec_(_code_, _globs_=None, _locs_=None):
        l11l1l11l111_tv_ (u"ࠣࠤࠥࡉࡽ࡫ࡣࡶࡶࡨࠤࡨࡵࡤࡦࠢ࡬ࡲࠥࡧࠠ࡯ࡣࡰࡩࡸࡶࡡࡤࡧ࠱ࠦࠧࠨ៵")
        if _globs_ is None:
            frame = sys._getframe(1)
            _globs_ = frame.f_globals
            if _locs_ is None:
                _locs_ = frame.f_locals
            del frame
        elif _locs_ is None:
            _locs_ = _globs_
        exec(l11l1l11l111_tv_ (u"ࠤࠥࠦࡪࡾࡥࡤࠢࡢࡧࡴࡪࡥࡠࠢ࡬ࡲࠥࡥࡧ࡭ࡱࡥࡷࡤ࠲ࠠࡠ࡮ࡲࡧࡸࡥࠢࠣࠤ៶"))
    exec_(l11l1l11l111_tv_ (u"ࠥࠦࠧࡪࡥࡧࠢࡵࡩࡷࡧࡩࡴࡧࠫࡸࡵ࠲ࠠࡷࡣ࡯ࡹࡪ࠲ࠠࡵࡤࡀࡒࡴࡴࡥࠪ࠼ࠍࠤࠥࠦࠠࡳࡣ࡬ࡷࡪࠦࡴࡱ࠮ࠣࡺࡦࡲࡵࡦ࠮ࠣࡸࡧࠐࠢࠣࠤ៷"))
if sys.version_info[:2] == (3, 2):
    exec_(l11l1l11l111_tv_ (u"ࠦࠧࠨࡤࡦࡨࠣࡶࡦ࡯ࡳࡦࡡࡩࡶࡴࡳࠨࡷࡣ࡯ࡹࡪ࠲ࠠࡧࡴࡲࡱࡤࡼࡡ࡭ࡷࡨ࠭࠿ࠐࠠࠡࠢࠣ࡭࡫ࠦࡦࡳࡱࡰࡣࡻࡧ࡬ࡶࡧࠣ࡭ࡸࠦࡎࡰࡰࡨ࠾ࠏࠦࠠࠡࠢࠣࠤࠥࠦࡲࡢ࡫ࡶࡩࠥࡼࡡ࡭ࡷࡨࠎࠥࠦࠠࠡࡴࡤ࡭ࡸ࡫ࠠࡷࡣ࡯ࡹࡪࠦࡦࡳࡱࡰࠤ࡫ࡸ࡯࡮ࡡࡹࡥࡱࡻࡥࠋࠤࠥࠦ៸"))
elif sys.version_info[:2] > (3, 2):
    exec_(l11l1l11l111_tv_ (u"ࠧࠨࠢࡥࡧࡩࠤࡷࡧࡩࡴࡧࡢࡪࡷࡵ࡭ࠩࡸࡤࡰࡺ࡫ࠬࠡࡨࡵࡳࡲࡥࡶࡢ࡮ࡸࡩ࠮ࡀࠊࠡࠢࠣࠤࡷࡧࡩࡴࡧࠣࡺࡦࡲࡵࡦࠢࡩࡶࡴࡳࠠࡧࡴࡲࡱࡤࡼࡡ࡭ࡷࡨࠎࠧࠨࠢ៹"))
else:
    def raise_from(value, from_value):
        raise value
print_ = getattr(moves.builtins, l11l1l11l111_tv_ (u"ࠨࡰࡳ࡫ࡱࡸࠧ៺"), None)
if print_ is None:
    def print_(*args, **kwargs):
        l11l1l11l111_tv_ (u"ࠢࠣࠤࡗ࡬ࡪࠦ࡮ࡦࡹ࠰ࡷࡹࡿ࡬ࡦࠢࡳࡶ࡮ࡴࡴࠡࡨࡸࡲࡨࡺࡩࡰࡰࠣࡪࡴࡸࠠࡑࡻࡷ࡬ࡴࡴࠠ࠳࠰࠷ࠤࡦࡴࡤࠡ࠴࠱࠹࠳ࠨࠢࠣ៻")
        fp = kwargs.pop(l11l1l11l111_tv_ (u"ࠣࡨ࡬ࡰࡪࠨ៼"), sys.stdout)
        if fp is None:
            return
        def write(data):
            if not isinstance(data, basestring):
                data = str(data)
            if (isinstance(fp, file) and
                    isinstance(data, unicode) and
                    fp.encoding is not None):
                errors = getattr(fp, l11l1l11l111_tv_ (u"ࠤࡨࡶࡷࡵࡲࡴࠤ៽"), None)
                if errors is None:
                    errors = l11l1l11l111_tv_ (u"ࠥࡷࡹࡸࡩࡤࡶࠥ៾")
                data = data.encode(fp.encoding, errors)
            fp.write(data)
        want_unicode = False
        sep = kwargs.pop(l11l1l11l111_tv_ (u"ࠦࡸ࡫ࡰࠣ៿"), None)
        if sep is not None:
            if isinstance(sep, unicode):
                want_unicode = True
            elif not isinstance(sep, str):
                raise TypeError(l11l1l11l111_tv_ (u"ࠧࡹࡥࡱࠢࡰࡹࡸࡺࠠࡣࡧࠣࡒࡴࡴࡥࠡࡱࡵࠤࡦࠦࡳࡵࡴ࡬ࡲ࡬ࠨ᠀"))
        end = kwargs.pop(l11l1l11l111_tv_ (u"ࠨࡥ࡯ࡦࠥ᠁"), None)
        if end is not None:
            if isinstance(end, unicode):
                want_unicode = True
            elif not isinstance(end, str):
                raise TypeError(l11l1l11l111_tv_ (u"ࠢࡦࡰࡧࠤࡲࡻࡳࡵࠢࡥࡩࠥࡔ࡯࡯ࡧࠣࡳࡷࠦࡡࠡࡵࡷࡶ࡮ࡴࡧࠣ᠂"))
        if kwargs:
            raise TypeError(l11l1l11l111_tv_ (u"ࠣ࡫ࡱࡺࡦࡲࡩࡥࠢ࡮ࡩࡾࡽ࡯ࡳࡦࠣࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠦࡴࡰࠢࡳࡶ࡮ࡴࡴࠩࠫࠥ᠃"))
        if not want_unicode:
            for arg in args:
                if isinstance(arg, unicode):
                    want_unicode = True
                    break
        if want_unicode:
            newline = unicode(l11l1l11l111_tv_ (u"ࠤ࡟ࡲࠧ᠄"))
            space = unicode(l11l1l11l111_tv_ (u"ࠥࠤࠧ᠅"))
        else:
            newline = l11l1l11l111_tv_ (u"ࠦࡡࡴࠢ᠆")
            space = l11l1l11l111_tv_ (u"ࠧࠦࠢ᠇")
        if sep is None:
            sep = space
        if end is None:
            end = newline
        for i, arg in enumerate(args):
            if i:
                write(sep)
            write(arg)
        write(end)
if sys.version_info[:2] < (3, 3):
    _print = print_
    def print_(*args, **kwargs):
        fp = kwargs.get(l11l1l11l111_tv_ (u"ࠨࡦࡪ࡮ࡨࠦ᠈"), sys.stdout)
        flush = kwargs.pop(l11l1l11l111_tv_ (u"ࠢࡧ࡮ࡸࡷ࡭ࠨ᠉"), False)
        _print(*args, **kwargs)
        if flush and fp is not None:
            fp.flush()
_add_doc(reraise, l11l1l11l111_tv_ (u"ࠣࠤࠥࡖࡪࡸࡡࡪࡵࡨࠤࡦࡴࠠࡦࡺࡦࡩࡵࡺࡩࡰࡰ࠱ࠦࠧࠨ᠊"))
if sys.version_info[0:2] < (3, 4):
    def wraps(wrapped, assigned=functools.WRAPPER_ASSIGNMENTS,
              updated=functools.WRAPPER_UPDATES):
        def wrapper(f):
            f = functools.wraps(wrapped, assigned, updated)(f)
            f.__wrapped__ = wrapped
            return f
        return wrapper
else:
    wraps = functools.wraps
def with_metaclass(meta, *bases):
    l11l1l11l111_tv_ (u"ࠤࠥࠦࡈࡸࡥࡢࡶࡨࠤࡦࠦࡢࡢࡵࡨࠤࡨࡲࡡࡴࡵࠣࡻ࡮ࡺࡨࠡࡣࠣࡱࡪࡺࡡࡤ࡮ࡤࡷࡸ࠴ࠢࠣࠤ᠋")
    class metaclass(meta):
        def __new__(cls, name, this_bases, d):
            return meta(name, bases, d)
    return type.__new__(metaclass, l11l1l11l111_tv_ (u"ࠪࡸࡪࡳࡰࡰࡴࡤࡶࡾࡥࡣ࡭ࡣࡶࡷࠬ᠌"), (), {})
def add_metaclass(metaclass):
    l11l1l11l111_tv_ (u"ࠦࠧࠨࡃ࡭ࡣࡶࡷࠥࡪࡥࡤࡱࡵࡥࡹࡵࡲࠡࡨࡲࡶࠥࡩࡲࡦࡣࡷ࡭ࡳ࡭ࠠࡢࠢࡦࡰࡦࡹࡳࠡࡹ࡬ࡸ࡭ࠦࡡࠡ࡯ࡨࡸࡦࡩ࡬ࡢࡵࡶ࠲ࠧࠨࠢ᠍")
    def wrapper(cls):
        orig_vars = cls.__dict__.copy()
        slots = orig_vars.get(l11l1l11l111_tv_ (u"ࠬࡥ࡟ࡴ࡮ࡲࡸࡸࡥ࡟ࠨ᠎"))
        if slots is not None:
            if isinstance(slots, str):
                slots = [slots]
            for slots_var in slots:
                orig_vars.pop(slots_var)
        orig_vars.pop(l11l1l11l111_tv_ (u"࠭࡟ࡠࡦ࡬ࡧࡹࡥ࡟ࠨ᠏"), None)
        orig_vars.pop(l11l1l11l111_tv_ (u"ࠧࡠࡡࡺࡩࡦࡱࡲࡦࡨࡢࡣࠬ᠐"), None)
        return metaclass(cls.__name__, cls.__bases__, orig_vars)
    return wrapper
def python_2_unicode_compatible(klass):
    l11l1l11l111_tv_ (u"ࠣࠤࠥࠎࠥࠦࠠࠡࡃࠣࡨࡪࡩ࡯ࡳࡣࡷࡳࡷࠦࡴࡩࡣࡷࠤࡩ࡫ࡦࡪࡰࡨࡷࠥࡥ࡟ࡶࡰ࡬ࡧࡴࡪࡥࡠࡡࠣࡥࡳࡪࠠࡠࡡࡶࡸࡷࡥ࡟ࠡ࡯ࡨࡸ࡭ࡵࡤࡴࠢࡸࡲࡩ࡫ࡲࠡࡒࡼࡸ࡭ࡵ࡮ࠡ࠴࠱ࠎࠥࠦࠠࠡࡗࡱࡨࡪࡸࠠࡑࡻࡷ࡬ࡴࡴࠠ࠴ࠢ࡬ࡸࠥࡪ࡯ࡦࡵࠣࡲࡴࡺࡨࡪࡰࡪ࠲ࠏࠐࠠࠡࠢࠣࡘࡴࠦࡳࡶࡲࡳࡳࡷࡺࠠࡑࡻࡷ࡬ࡴࡴࠠ࠳ࠢࡤࡲࡩࠦ࠳ࠡࡹ࡬ࡸ࡭ࠦࡡࠡࡵ࡬ࡲ࡬ࡲࡥࠡࡥࡲࡨࡪࠦࡢࡢࡵࡨ࠰ࠥࡪࡥࡧ࡫ࡱࡩࠥࡧࠠࡠࡡࡶࡸࡷࡥ࡟ࠡ࡯ࡨࡸ࡭ࡵࡤࠋࠢࠣࠤࠥࡸࡥࡵࡷࡵࡲ࡮ࡴࡧࠡࡶࡨࡼࡹࠦࡡ࡯ࡦࠣࡥࡵࡶ࡬ࡺࠢࡷ࡬࡮ࡹࠠࡥࡧࡦࡳࡷࡧࡴࡰࡴࠣࡸࡴࠦࡴࡩࡧࠣࡧࡱࡧࡳࡴ࠰ࠍࠤࠥࠦࠠࠣࠤࠥ᠑")
    if PY2:
        if l11l1l11l111_tv_ (u"ࠩࡢࡣࡸࡺࡲࡠࡡࠪ᠒") not in klass.__dict__:
            raise ValueError(l11l1l11l111_tv_ (u"ࠥࡄࡵࡿࡴࡩࡱࡱࡣ࠷ࡥࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡤࡱࡰࡴࡦࡺࡩࡣ࡮ࡨࠤࡨࡧ࡮࡯ࡱࡷࠤࡧ࡫ࠠࡢࡲࡳࡰ࡮࡫ࡤࠡࠤ᠓")
                             l11l1l11l111_tv_ (u"ࠦࡹࡵࠠࠦࡵࠣࡦࡪࡩࡡࡶࡵࡨࠤ࡮ࡺࠠࡥࡱࡨࡷࡳ࠭ࡴࠡࡦࡨࡪ࡮ࡴࡥࠡࡡࡢࡷࡹࡸ࡟ࡠࠪࠬ࠲ࠧ᠔") %
                             klass.__name__)
        klass.__unicode__ = klass.__str__
        klass.__str__ = lambda self: self.__unicode__().encode(l11l1l11l111_tv_ (u"ࠬࡻࡴࡧ࠯࠻ࠫ᠕"))
    return klass
__path__ = []
__package__ = __name__
if globals().get(l11l1l11l111_tv_ (u"ࠨ࡟ࡠࡵࡳࡩࡨࡥ࡟ࠣ᠖")) is not None:
    __spec__.submodule_search_locations = []
if sys.meta_path:
    for i, importer in enumerate(sys.meta_path):
        if (type(importer).__name__ == l11l1l11l111_tv_ (u"ࠢࡠࡕ࡬ࡼࡒ࡫ࡴࡢࡒࡤࡸ࡭ࡏ࡭ࡱࡱࡵࡸࡪࡸࠢ᠗") and
                importer.name == __name__):
            del sys.meta_path[i]
            break
    del i, importer
sys.meta_path.append(_importer)
