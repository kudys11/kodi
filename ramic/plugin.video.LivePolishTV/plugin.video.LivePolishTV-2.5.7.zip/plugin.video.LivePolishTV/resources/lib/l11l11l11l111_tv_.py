# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re,time,urlparse
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡨࡦࡸ࡭ࡰࡹࡤ࠱ࡹ࡫࡬ࡦࡹ࡬ࡾ࡯ࡧ࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࠨ൩")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡐ࡙࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠹࠵࠴࠰࠯࠴࠹࠺࠶࠴࠱࠱࠴ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪ൪")
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ൫"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࠧ൬")
    return l11ll11ll11l111_tv_
def l1ll1l1l1ll11l111_tv_(url):
    l1lll1lll1l11l111_tv_=url
    try:
        req = urllib2.Request(url,headers={l11l1l11l111_tv_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ൭"):l1lll1l1lll11l111_tv_})
        response = urllib2.urlopen(req, timeout=15)
        l1lll1lll1l11l111_tv_=response.geturl()
        response.close()
    except: pass
    return l1lll1lll1l11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿࡞ࠦࡢ࠮ࡨࡵࡶࡳ࠾࠴࠵ࡤࡢࡴࡰࡳࡼࡧ࠭ࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣ࠱ࡳࡳࡲࡩ࡯ࡧ࠲࡟ࡣࡂ࡝ࠫࠫ࡞ࠦࡢࡄࠨ࡜ࡠ࠿ࡡ࠯࠯࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠩ൮")).findall(content)
    l1lll1lllll11l111_tv_ = l1lll1lllll11l111_tv_[1:-2] if len(l1lll1lllll11l111_tv_)>10 else l1lll1lllll11l111_tv_
    for href,title in l1lll1lllll11l111_tv_:
        if l11l1l11l111_tv_ (u"ࠩ࠿ࠫ൯") in title:
            continue
        out.append({l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ൰"):title.strip(),l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩ൱"):title.strip(),l11l1l11l111_tv_ (u"ࠬ࡯࡭ࡨࠩ൲"):l11l1l11l111_tv_ (u"࠭ࠧ൳"),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫ൴"):href,l11l1l11l111_tv_ (u"ࠨࡩࡵࡳࡺࡶࠧ൵"):l11l1l11l111_tv_ (u"ࠩࠪ൶"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࡥࡱࡩࠪ൷"):l11l1l11l111_tv_ (u"ࠫࠬ൸")})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡿࡥ࡭࡮ࡲࡻࡢ࡛ࡰࡥࡣࡷࡩࡩࡀࠠࠦࡵࠣࠬࡩࡧࡲ࡮ࡱࡺࡥ࠲ࡺࡥ࡭ࡧࡺ࡭ࡿࡰࡡ࠯ࡱࡱࡰ࡮ࡴࡥࠪ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ൹") %time.strftime(l11l1l11l111_tv_ (u"ࠨࠥࡥ࠱ࠨࡱ࠴࡙ࠫ࠻ࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦൺ"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ൻ"):t,l11l1l11l111_tv_ (u"ࠨࡶࡹ࡭ࡩ࠭ർ"):l11l1l11l111_tv_ (u"ࠩࠪൽ"),l11l1l11l111_tv_ (u"ࠪ࡭ࡲ࡭ࠧൾ"):l11l1l11l111_tv_ (u"ࠫࠬൿ"),l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩ඀"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"࠭ࡧࡳࡱࡸࡴࠬඁ"):l11l1l11l111_tv_ (u"ࠧࠨං"),l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࡪࡶࡧࠨඃ"):l11l1l11l111_tv_ (u"ࠩࠪ඄")})
    return out
def l111l1lll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡨࡦࡸ࡭ࡰࡹࡤ࠱ࡹ࡫࡬ࡦࡹ࡬ࡾ࡯ࡧ࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࡵࡸࡳ࠱࠶࠵ࠧඅ")):
    l1lll1ll11l11l111_tv_=[]
    content = l111111l11l111_tv_(url)
    l1ll1l111ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠭࠴ࠪࡀࠫ࠿࠳࡮࡬ࡲࡢ࡯ࡨࠫආ"),re.DOTALL).findall(content)
    src = [url] if l11l1l11l111_tv_ (u"ࠬࡱࡡ࡯ࡣ࡯ࠫඇ") in url else []
    for m in l1ll1l111ll11l111_tv_:
        l11ll11ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫඈ")).findall(m)
        if l11ll11ll11l111_tv_:
            if l11ll11ll11l111_tv_[0].startswith(l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴࠬඉ")):
                src.append(urlparse.urljoin(l1llll111ll11l111_tv_,l11ll11ll11l111_tv_[0]))
            else:
                src.append(l11ll11ll11l111_tv_[0])
    if src:
        src = src[0]
        data = l111111l11l111_tv_(src)
        l1ll1l11lll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠨ࡝࡟ࠫࠧࡣࠨࡩࡶࡷࡴ࠳࠰࡜࠯࡯࠶ࡹ࠽ࡅࠩ࡜࡞ࠪࠦࡢ࠭ඊ")).findall(data)
        if l1ll1l11lll11l111_tv_:
            l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭උ"):l1ll1l11lll11l111_tv_[0]}]
        else:
            l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src,data)
            if l1ll11lll1l11l111_tv_:
                l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧඌ"):l1ll11lll1l11l111_tv_}]
            else:
                l1ll1l1111l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠭࠴ࠪࡀࠫ࠿࠳࡮࡬ࡲࡢ࡯ࡨࡂࠬඍ"),re.DOTALL).findall(data)
                l1ll1l1111l11l111_tv_ = l1ll1l1111l11l111_tv_[0] if l1ll1l1111l11l111_tv_ else l11l1l11l111_tv_ (u"ࠬ࠭ඎ")
                l1ll1l11l1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫඏ")).findall(l1ll1l1111l11l111_tv_)
                data = l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0]) if l1ll1l11l1l11l111_tv_ else l11l1l11l111_tv_ (u"ࠧࠨඐ")
                l1ll1l1l11l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠨ࡝ࠥࡠࠬࡣࠨࡩࡶࡷࡴ࠳࠰࠿࡝࠰ࡰ࠷ࡺࡡ࠸࡞ࠫ࡞ࠦࡡ࠭࡝ࠨඑ")).findall(data)
                if l1ll1l1l11l11l111_tv_:
                    l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭ඒ"):l1ll1l1l11l11l111_tv_[0],l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺࡩ࡭ࡧࠪඓ"):l11l1l11l111_tv_ (u"ࠫࡑ࡯ࡶࡦࠩඔ"),l11l1l11l111_tv_ (u"ࠬࡸࡥࡴࡱ࡯ࡺࡪࡪࠧඕ"):1})
    if not l1lll1ll11l11l111_tv_:
        l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"࠭࡭ࡴࡩࠪඖ"):l11l1l11l111_tv_ (u"ࠧࡑࡴࡲࡦࡱ࡫࡭ࠡࡼࡨࠤॿࡸࣳࡥॄࡨࡱࠬ඗")}]
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        print l11l1l11l111_tv_ (u"ࠨ࡞ࡱࠫ඘"),l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ඙"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧක")))
        print l1lll1ll11l11l111_tv_
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨඛ")))
        print l1lll1ll11l11l111_tv_
