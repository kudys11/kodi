# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re
import cookielib
from urlparse import urlparse
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷࡩࡱ࡫ࡷࡪࡼ࡭ࡥ࠲ࡨ࡬ࡢࡥ࡮࠲ࡨࡵ࡭࠰ࠩᱏ")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡏࡘ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠸࠴࠳࠶࠮࠳࠸࠹࠵࠳࠷࠰࠳ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩ᱐")
__all__=[l11l1l11l111_tv_ (u"ࠫ࡬࡫ࡴࡄࡪࡤࡲࡳ࡫࡬ࡴࠩ᱑"),l11l1l11l111_tv_ (u"ࠬ࡭ࡥࡵࡅ࡫ࡥࡳࡴࡥ࡭ࡘ࡬ࡨࡪࡵࠧ᱒")]
def l111111l11l111_tv_(url,data=None,header={}):
    l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
    urllib2.install_opener(opener)
    if not header:
        header = {l11l1l11l111_tv_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ᱓"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except: l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࠨ᱔")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l11llll11ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠨ࠾࡯࡭ࡡࡹࠪ࠿࡞ࡶ࠮ࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯࠭ࡂ࠭ࡁ࠵ࡡ࠿࠾࠲ࡰ࡮ࡄࠧ᱕")).findall(content)
    for href,t in l11llll11ll11l111_tv_:
        out.append({l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ᱖"):t,l11l1l11l111_tv_ (u"ࠪࡸࡻ࡯ࡤࠨ᱗"):t,l11l1l11l111_tv_ (u"ࠫ࡮ࡳࡧࠨ᱘"):l11l1l11l111_tv_ (u"ࠬ࠭᱙"),l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪᱚ"):href,l11l1l11l111_tv_ (u"ࠧࡨࡴࡲࡹࡵ࠭ᱛ"):l11l1l11l111_tv_ (u"ࠨࠩᱜ"),l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩᱝ"):l11l1l11l111_tv_ (u"ࠪࠫᱞ"),l11l1l11l111_tv_ (u"ࠫࡵࡲ࡯ࡵࠩᱟ"):l11l1l11l111_tv_ (u"ࠬ࠭ᱠ"),l11l1l11l111_tv_ (u"࠭ࡣࡰࡦࡨࠫᱡ"):l11l1l11l111_tv_ (u"ࠧࠨᱢ")})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡻࡨࡰࡱࡵࡷ࡞ࡗࡳࡨࡦࡺࡥࡥ࠼ࠣࠩࡸࠦࠨࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣ࠰ࡦࡱࡧࡣ࡬ࠫ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᱣ") %time.strftime(l11l1l11l111_tv_ (u"ࠤࠨࡨ࠴ࠫ࡭࠰ࠧ࡜࠾ࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢᱤ"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩᱥ"):t,l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩᱦ"):l11l1l11l111_tv_ (u"ࠬ࠭ᱧ"),l11l1l11l111_tv_ (u"࠭ࡩ࡮ࡩࠪᱨ"):l11l1l11l111_tv_ (u"ࠧࠨᱩ"),l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬᱪ"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠩࡪࡶࡴࡻࡰࠨᱫ"):l11l1l11l111_tv_ (u"ࠪࠫᱬ"),l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫᱭ"):l11l1l11l111_tv_ (u"ࠬ࠭ᱮ")})
    return out
def l111l1lll11l111_tv_(url=l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡴࡦ࡮ࡨࡻ࡮ࢀࡪࡢ࠯ࡥࡰࡦࡩ࡫࠯ࡥࡲࡱ࠴ࡺࡶ࡯࠹ࠪᱯ")):
    l1lll1ll11l11l111_tv_=[]
    content = l111111l11l111_tv_(url)
    l1ll1l111ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠩ࠰࠭ࡃ࠮ࡂ࠯ࡪࡨࡵࡥࡲ࡫ࠧᱰ"),re.DOTALL).findall(content)
    src = [url] if l11l1l11l111_tv_ (u"ࠨ࡭ࡤࡲࡦࡲࡹࠨᱱ") in url else False
    if l1ll1l111ll11l111_tv_:
        src = re.compile(l11l1l11l111_tv_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᱲ")).findall(l1ll1l111ll11l111_tv_[0])
    if src:
        src = src[0]
        data = l111111l11l111_tv_(src)
        l1ll1l11lll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠪ࡟ࡡ࠭ࠢ࡞ࠪ࡫ࡸࡹࡶ࠮ࠫ࡞࠱ࡱ࠸ࡻ࠸ࡀࠫ࡞ࡠࠬࠨ࡝ࠨᱳ")).findall(data)
        if l1ll1l11lll11l111_tv_:
            l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨᱴ"):l1ll1l11lll11l111_tv_[0]}]
        else:
            l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src,data)
            if l1ll11lll1l11l111_tv_:
                l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩᱵ"):l1ll11lll1l11l111_tv_}]
    if not l1lll1ll11l11l111_tv_:
        l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"࠭࡭ࡴࡩࠪᱶ"):l11l1l11l111_tv_ (u"ࠧࡑࡴࡲࡦࡱ࡫࡭ࠡࡼࡨࠤॿࡸࣳࡥॄࡨࡱࠬᱷ")}]
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        print l11l1l11l111_tv_ (u"ࠨ࡞ࡱࠫᱸ"),l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨᱹ"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᱺ")))
        print l1lll1ll11l11l111_tv_
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨᱻ")))
        print l1lll1ll11l11l111_tv_
