# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re,json,time
import cookielib
import l1ll11ll1ll11l111_tv_
import l1ll1ll111l11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡴ࡯ࡸࡣࡷࡺ࠳ࡴࡥࡵࠩᎵ")
l1lll1ll1ll11l111_tv_=10
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠰࠯࠲࠱࠶࠻࠼࠱࠯࠳࠳࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬᎶ")
__all__=[l11l1l11l111_tv_ (u"ࠧࡨࡧࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬᎷ"),l11l1l11l111_tv_ (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰ࡛࡯ࡤࡦࡱࠪᎸ")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭Ꮉ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠪࠫᎺ")
    return l11ll11ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},l1llll1111l11l111_tv_=True):
    l1llll1l11l11l111_tv_=l11l1l11l111_tv_ (u"ࠫࠬᎻ")
    l1llll1ll1l11l111_tv_=[]
    if l1llll1111l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {l11l1l11l111_tv_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᎼ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_ =  response.read()
        response.close()
        l1llll1l11l11l111_tv_ = l11l1l11l111_tv_ (u"࠭ࠧᎽ").join([l11l1l11l111_tv_ (u"ࠧࠦࡵࡀࠩࡸࡁࠧᎾ")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
    except urllib2.HTTPError as e:
        l11ll11ll11l111_tv_ = l11l1l11l111_tv_ (u"ࠨࠩᎿ")
    return l11ll11ll11l111_tv_,l1llll1l11l11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content,c = l111111l11l111_tv_(l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡱࡳࡼࡧࡴࡷ࠰ࡱࡩࡹ࠵ࡳࡵࡴࡨࡥࡲࡹࠧᏀ"))
    try:
        data = json.loads(content)
    except:
        data=[]
    out=[]
    for d in data:
        l1llll11lll11l111_tv_= l1llll111ll11l111_tv_+d.get(l11l1l11l111_tv_ (u"ࠪࡰࡴ࡭࡯ࠨᏁ"))
        title=d.get(l11l1l11l111_tv_ (u"ࠫࡳࡧ࡭ࡦࠩᏂ"))
        href=l1llll111ll11l111_tv_+l11l1l11l111_tv_ (u"ࠬ࠵ࡤࡢࡶࡤ࠳ࠬᏃ")+d.get(l11l1l11l111_tv_ (u"࠭ࡣࡩࡣࡱࡩࡱ࠭Ꮔ"))+l11l1l11l111_tv_ (u"ࠧࡀࠩᏅ")+c
        out.append({l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᏆ"):title.strip(),l11l1l11l111_tv_ (u"ࠩࡷࡺ࡮ࡪࠧᏇ"):title.strip(),l11l1l11l111_tv_ (u"ࠪ࡭ࡲ࡭ࠧᏈ"):l1llll11lll11l111_tv_,l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨᏉ"):href,l11l1l11l111_tv_ (u"ࠬ࡭ࡲࡰࡷࡳࠫᏊ"):l11l1l11l111_tv_ (u"࠭ࠧᏋ"),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࡩࡵ࡭ࠧᏌ"):l11l1l11l111_tv_ (u"ࠨࠩᏍ")})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡼࡩࡱࡲ࡯ࡸ࡟ࡘࡴࡩࡧࡴࡦࡦ࠽ࠤࠪࡹࠠࠩࡰࡲࡻࡦࡺࡶ࠯ࡰࡨࡸ࠮ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᏎ") %time.strftime(l11l1l11l111_tv_ (u"ࠥࠩࡩ࠵ࠥ࡮࠱ࠨ࡝࠿ࠦࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠣᏏ"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪᏐ"):t,l11l1l11l111_tv_ (u"ࠬࡺࡶࡪࡦࠪᏑ"):l11l1l11l111_tv_ (u"࠭ࠧᏒ"),l11l1l11l111_tv_ (u"ࠧࡪ࡯ࡪࠫᏓ"):l11l1l11l111_tv_ (u"ࠨࠩᏔ"),l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭Ꮥ"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠪ࡫ࡷࡵࡵࡱࠩᏖ"):l11l1l11l111_tv_ (u"ࠫࠬᏗ"),l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࡧࡳ࡫ࠬᏘ"):l11l1l11l111_tv_ (u"࠭ࠧᏙ")})
    return l1ll1ll111l11l111_tv_.l1ll1ll1l1l11l111_tv_(out,local={})
def l111l1lll11l111_tv_(url):
    url,l1llll1l11l11l111_tv_=url.split(l11l1l11l111_tv_ (u"ࠧࡀࠩᏚ")) if l11l1l11l111_tv_ (u"ࠨࡁࠪᏛ")in url else (url,l11l1l11l111_tv_ (u"ࠩࠪᏜ"))
    print url,l1llll1l11l11l111_tv_
    l1lll1ll11l11l111_tv_=[]
    header ={l11l1l11l111_tv_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᏝ"):l1lll1l1lll11l111_tv_,
            l11l1l11l111_tv_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧᏞ"):l11l1l11l111_tv_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭Ꮯ"),
            l11l1l11l111_tv_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧᏠ"):url,
            l11l1l11l111_tv_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧᏡ"):l1llll1l11l11l111_tv_,
            }
    content,c = l111111l11l111_tv_(url,header=header)
    try:
        data = json.loads(content)
        if not data.get(l11l1l11l111_tv_ (u"ࠨ࡮࡬ࡱ࡮ࡺࠧᏢ"),False):
            l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭Ꮳ"):data.get(l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᏤ"))}]
        else:
            l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠫࡲࡹࡧࠨᏥ"):l11l1l11l111_tv_ (u"ࠬࡕࡧࡳࡣࡱ࡭ࡨࢀ࡯࡯ࡣࠣࡨࡴࡹࡴचࡲࡱࡳॠऍࠠ࡮ࡣࡷࡩࡷ࡯ࡡृࡷ࠱ࡠࡳ࡙ࡥࡳࡹࡨࡶࡾࠦࡳआࠢࡲࡦࡪࡩ࡮ࡪࡧࠣࡴࡷࢀࡥࡤ࡫ईঀࡴࡴࡥ࠯ࠩᏦ")}]
    except:
        l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"࠭࡭ࡴࡩࠪᏧ"):l11l1l11l111_tv_ (u"ࠧࡑࡴࡲࡦࡱ࡫࡭ࠡࡼࠣࡳࡩࡩࡺࡺࡶࡤࡲ࡮࡫࡭ࠡॼࡵࣷࡩࡲࡡࠨᏨ")}]
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        print l11l1l11l111_tv_ (u"ࠨ࡞ࡱࠫᏩ"),l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨᏪ"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᏫ")))
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪᏬ")))
        print l1lll1ll11l11l111_tv_
