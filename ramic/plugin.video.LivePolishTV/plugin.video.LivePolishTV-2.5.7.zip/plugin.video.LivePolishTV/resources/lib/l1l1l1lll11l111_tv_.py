# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re
from urlparse import urlparse
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡰࡤࡸࡻ࠴ࡰ࡭࠱ࠪᵥ")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠶࠲࠱࠴࠳࠸࠶࠷࠳࠱࠵࠵࠸ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧᵦ")
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᵧ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠪࠫᵨ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    ids = [(a.start(), a.end()) for a in re.finditer(l11l1l11l111_tv_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺ࠭ࡨࡴࡲࡹࡵࠨ࠾ࠨᵩ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l1l1lll1lll11l111_tv_ = content[ ids[i][1]:ids[i+1][0] ]
        title = re.compile(l11l1l11l111_tv_ (u"ࠬࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠸ࡃ࠭ᵪ")).findall(l1l1lll1lll11l111_tv_)
        href = re.compile(l11l1l11l111_tv_ (u"࠭࠼ࡢࠢࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺ࠭ࡨࡴࡲࡹࡵ࠳ࡩࡵࡧࡰࠤࡰࡧࡴ࠮࡮࡬ࡷࡹࠦ࡭ࡰࡴࡨࡳ࡫ࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠧᵫ")).findall(l1l1lll1lll11l111_tv_)
        l1l11l1lllll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠧ࠽࡫ࠣࡧࡱࡧࡳࡴ࠿ࠥࡪࡦࠦࡦࡢࠢࡩࡥ࠲ࡩࡡࡳࡧࡷ࠱ࡷ࡯ࡧࡩࡶࠣࡪࡦ࠳ࡦࡸࠤࡁࡀ࠴࡯࠾ࡍ࡫ࡱ࡯ࡡࡹࠪࠩ࡞ࡧ࠯࠮ࡢࡳࠫࠩᵬ")).findall(l1l1lll1lll11l111_tv_)
        if href and title:
            group = href[0].split(l11l1l11l111_tv_ (u"ࠨࡁࠪᵭ"))[-1] if l11l1l11l111_tv_ (u"ࠩࡂࠫᵮ") in href[0] else l11l1l11l111_tv_ (u"ࠪࠫᵯ")
            l1l11l1lllll11l111_tv_ = l1l11l1lllll11l111_tv_[0] if l1l11l1lllll11l111_tv_ else l11l1l11l111_tv_ (u"ࠫࡄ࠭ᵰ")
            t = title[0].replace(l11l1l11l111_tv_ (u"ࠬࠬ࡮ࡣࡵࡳ࠿ࠬᵱ"),l11l1l11l111_tv_ (u"࠭ࠧᵲ")).replace(l11l1l11l111_tv_ (u"ࠧࡐࡰ࡯࡭ࡳ࡫ࠧᵳ"),l11l1l11l111_tv_ (u"ࠨࠩᵴ")).strip()
            code = l11l1l11l111_tv_ (u"ࡷࠪ࡟ࡑ࡯࡮࡬ࣵࡺ࠾ࠪࡹ࡝ࠡࠧࡶࠫᵵ")%(l1l11l1lllll11l111_tv_,group)
            out.append({l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩᵶ"):t,l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩᵷ"):t,l11l1l11l111_tv_ (u"ࠬ࡯࡭ࡨࠩᵸ"):l11l1l11l111_tv_ (u"࠭ࠧᵹ"),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫᵺ"):href[0],l11l1l11l111_tv_ (u"ࠨࡩࡵࡳࡺࡶࠧᵻ"):group,l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩᵼ"):l11l1l11l111_tv_ (u"ࠪࠫᵽ"),l11l1l11l111_tv_ (u"ࠫࡵࡲ࡯ࡵࠩᵾ"):l11l1l11l111_tv_ (u"ࠬ࠭ᵿ"),l11l1l11l111_tv_ (u"࠭ࡣࡰࡦࡨࠫᶀ"):code})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡺࡧ࡯ࡰࡴࡽ࡝ࡖࡲࡧࡥࡹ࡫ࡤ࠻ࠢࠨࡷࠥ࠮ࡰࡴࡣ࠰ࡸࡻ࠯࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨᶁ") %time.strftime(l11l1l11l111_tv_ (u"ࠣࠧࡧ࠳ࠪࡳ࠯࡛ࠦ࠽ࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨᶂ"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨᶃ"):t,l11l1l11l111_tv_ (u"ࠪࡸࡻ࡯ࡤࠨᶄ"):l11l1l11l111_tv_ (u"ࠫࠬᶅ"),l11l1l11l111_tv_ (u"ࠬ࡯࡭ࡨࠩᶆ"):l11l1l11l111_tv_ (u"࠭ࠧᶇ"),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫᶈ"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠨࡩࡵࡳࡺࡶࠧᶉ"):l11l1l11l111_tv_ (u"ࠩࠪᶊ"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࡥࡱࡩࠪᶋ"):l11l1l11l111_tv_ (u"ࠫࠬᶌ")})
    return out
l11ll11l11l11l111_tv_=[l11l1l11l111_tv_ (u"ࠬࡼ࠲࠯ࡷࡶࡸࡷ࡫ࡡ࡮࡫ࡻ࠲ࡨࡵ࡭ࠨᶍ"),l11l1l11l111_tv_ (u"࠭ࡵࡴࡶࡵࡩࡦࡳࡩࡹ࠰ࡦࡳࡲ࠭ᶎ"),l11l1l11l111_tv_ (u"ࠧࡸ࡫ࡱࡸࡪࡾ࠮࡭࡫ࡰࡥ࠲ࡩࡩࡵࡻ࠱ࡨࡪ࠭ᶏ"),l11l1l11l111_tv_ (u"ࠨࡵࡷࡥࡹ࡯ࡣ࠯ࡷ࠰ࡴࡷࡵ࠮ࡧࡴࠪᶐ"),
    l11l1l11l111_tv_ (u"ࠩ࡯ࡳࡴࡱ࡮ࡪ࡬࠱࡭ࡳ࠭ᶑ"),l11l1l11l111_tv_ (u"ࠪࡻ࡮ࢀࡪࡢ࠰ࡷࡺࠬᶒ"),l11l1l11l111_tv_ (u"ࠫࡼࡽࡷ࠯ࡶࡹࡴ࠳ࡶ࡬ࠨᶓ"),l11l1l11l111_tv_ (u"ࠬࡺࡥ࡭ࡧ࠰ࡻ࡮ࢀࡪࡢ࠰࡬ࡷࠬᶔ"),l11l1l11l111_tv_ (u"࠭ࡴࡦ࡮ࡨ࠱ࡼ࡯ࡺ࡫ࡣ࠱ࡧࡴࡳࠧᶕ"),l11l1l11l111_tv_ (u"ࠧࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣ࠰ࡦࡱࡧࡣ࡬࠰ࡦࡳࡲ࠭ᶖ"),
    l11l1l11l111_tv_ (u"ࠨࡹࡺࡻ࠳ࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠱ࡧࡴࡳࠧᶗ"),l11l1l11l111_tv_ (u"ࠩࡧࡥࡷࡳ࡯ࡸࡣ࠰ࡸࡪࡲࡥࡸ࡫ࡽ࡮ࡦ࠴ࡩ࡯ࡨࡲࠫᶘ"),l11l1l11l111_tv_ (u"ࠪࡸࡻ࠳ࡷࡦࡧࡥ࠲ࡨࡵ࡭ࠨᶙ"),l11l1l11l111_tv_ (u"ࠫࡴࡪࡰࡢ࡮ࡷࡺ࠳ࡶ࡬ࠨᶚ"),l11l1l11l111_tv_ (u"ࠬࢀ࡯ࡣࡣࡦࡾࡹࡼ࠮ࡪࡰࡩࡳࠬᶛ"),l11l1l11l111_tv_ (u"࠭ࡤࡦ࡭ࡲࡨࡪࡸ࠮ࡸࡵ࠲ࡩࡲࡨࡥࡥࠩᶜ")]
def l1llll1ll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡰࡤࡸࡻ࠴ࡰ࡭࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ࡹࡼࡰ࠲࠯ࡲࡲࡱ࡯࡮ࡦ࠱ࠪᶝ")):
    out=[]
    content = l111111l11l111_tv_(url)
    l11ll1ll1ll11l111_tv_ =re.compile(l11l1l11l111_tv_ (u"ࠨ࠾ࡧࡸࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵࡣࡵ࡫ࡪࡺ࠽ࠣࡡࡥࡰࡦࡴ࡫ࠣࡀࠪᶞ")).findall(content)
    for l11ll11ll11l111_tv_ in l11ll1ll1ll11l111_tv_:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶࠧᶟ")+urllib.unquote(l11ll11ll11l111_tv_).split(l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰࠨᶠ"))[-1]
        title = urlparse(l11ll11ll11l111_tv_).netloc
        if l11l1l11l111_tv_ (u"ࠫࡼ࡫ࡢࡤࡣࡦ࡬ࡪ࠴ࡧࡰࡱࡪࡰࡪࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳࠧᶡ") in title:
            l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠭ᶢ")+l11ll11ll11l111_tv_.split(l11l1l11l111_tv_ (u"࠭࠺ࠨᶣ"))[-1]
            title = urlparse(l11ll11ll11l111_tv_).netloc
        if title in l11ll11l11l11l111_tv_:
            title = l11l1l11l111_tv_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡨࡴࡨࡩࡳࡣࠥࡴ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᶤ")%title
        else:
            title = l11l1l11l111_tv_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡴࡨࡨࡢࠫࡳ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᶥ")%title
        out.append({l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨᶦ"):title,l11l1l11l111_tv_ (u"ࠪࡸࡻ࡯ࡤࠨᶧ"):title,l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨᶨ"):l11ll11ll11l111_tv_})
    return out
def l11ll11l1ll11l111_tv_(url):
    l1ll11lll1l11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࠭ᶩ")
    try:
        if l11l1l11l111_tv_ (u"࠭ࡣࡳ࠰ࡳ࡬ࡵ࠭ᶪ") in url:
            content = l111111l11l111_tv_(url)
            data = re.compile(l11l1l11l111_tv_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷࡥࡷ࡭ࡥࡵ࠿ࠥࡣࡧࡲࡡ࡯࡭ࠥࡂࠬᶫ")).findall(content)
            if data:
                l11111l11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠨࡵࡷࡶࡪࡧ࡭࠾ࠩᶬ")+data[0].split(l11l1l11l111_tv_ (u"ࠩ࡬ࡨࡂ࠭ᶭ"))[-1]
        else:
            l11111l11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠪࡷࡹࡸࡥࡢ࡯ࡀࠫᶮ")+url.split(l11l1l11l111_tv_ (u"ࠫ࡮ࡪ࠽ࠨᶯ"))[-1]
        query = l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡵࡴࡶࡵࡩࡦࡳࡩࡹ࠰ࡦࡳࡲ࠵ࠧᶰ")+l11111l11ll11l111_tv_.replace(l11l1l11l111_tv_ (u"࠭࠽ࠨᶱ"),l11l1l11l111_tv_ (u"ࠧ࠯ࡲ࡫ࡴࡄ࡯ࡤ࠾ࠩᶲ"))
        content = l111111l11l111_tv_(query,header = {l11l1l11l111_tv_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᶳ"): l11l1l11l111_tv_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡚ࠠࠩ࠴࠵ࡀࠦࡌࡪࡰࡸࡼࠥ࡯࠶࠹࠸࠾ࠤࡷࡼ࠺࠵࠶࠱࠴࠮ࠦࡇࡦࡥ࡮ࡳ࠴࠸࠰࠲࠲࠳࠵࠵࠷ࠠࡇ࡫ࡵࡩ࡫ࡵࡸ࠰࠶࠷࠲࠵ࠦࡉࡤࡧࡺࡩࡦࡹࡥ࡭࠱࠷࠸࠳࠶ࠧᶴ"), l11l1l11l111_tv_ (u"ࠪࡅࡨࡩࡥࡱࡶࠪᶵ"): l11l1l11l111_tv_ (u"ࠫ࠯࠵ࠪࠨᶶ")})
        l1lllll111ll11l111_tv_ = re.findall(l11l1l11l111_tv_ (u"ࠧࡾ࡟ࡧ࡫ࡵࡷࡹࡥࡩࡱ࠰࠮ࡃࠬ࠮࠮ࠫࡁࠬࠫࠧᶷ"), content)[0]
        l111ll111ll11l111_tv_ = [l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡴ࡮ࡩ࠱ࡹࡸࡺࡲࡦࡣࡰ࡭ࡽ࠴ࡣࡰ࡯࠲ࠫᶸ"),l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡯࡬ࡶ࠳࡮ࡵ࡭࡭ࡩ࡭ࡱ࡫ࡳ࠯ࡥࡲࡱ࠴࠭ᶹ")]
        l1111lll1ll11l111_tv_=l11l1l11l111_tv_ (u"ࠨࠩᶺ")
        for l1llllll1l1l11l111_tv_ in l111ll111ll11l111_tv_:
            l1llllll1l1l11l111_tv_ = l111ll111ll11l111_tv_[0]
            l111l1l111l11l111_tv_ = l1llllll1l1l11l111_tv_ + l11l1l11l111_tv_ (u"ࠩࡶࡸࡦࡺࡳ࠯ࡲ࡫ࡴࡄࡶ࠽ࠨᶻ") + l1lllll111ll11l111_tv_
            source = l111111l11l111_tv_(l111l1l111l11l111_tv_, header = {l11l1l11l111_tv_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫᶼ"): query, l11l1l11l111_tv_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᶽ"): l11l1l11l111_tv_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡝࠷࠱࠼ࠢࡏ࡭ࡳࡻࡸࠡ࡫࠹࠼࠻ࡁࠠࡳࡸ࠽࠸࠹࠴࠰ࠪࠢࡊࡩࡨࡱ࡯࠰࠴࠳࠵࠵࠶࠱࠱࠳ࠣࡊ࡮ࡸࡥࡧࡱࡻ࠳࠹࠺࠮࠱ࠢࡌࡧࡪࡽࡥࡢࡵࡨࡰ࠴࠺࠴࠯࠲ࠪᶾ"), l11l1l11l111_tv_ (u"࠭ࡁࡤࡥࡨࡴࡹ࠭ᶿ"): l11l1l11l111_tv_ (u"ࠧࠫ࠱࠭ࠫ᷀")})
            l1111lll1ll11l111_tv_ = re.findall(l11l1l11l111_tv_ (u"ࠨࡸࡤࡶࠥࡰࡤࡵ࡭ࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᷁"), source)
            if l1111lll1ll11l111_tv_:
                l1111lll1ll11l111_tv_=l1111lll1ll11l111_tv_[0]
                break
        if l1111lll1ll11l111_tv_:
            l1ll11lll1l11l111_tv_= l1llllll1l1l11l111_tv_ + l11l1l11l111_tv_ (u"ࠩࡷࡱ࡬࠴࡭࠴ࡷ࠻ࡃ᷂ࠬ") + l11111l11ll11l111_tv_.replace(l11l1l11l111_tv_ (u"ࠪ࠲ࡵ࡮ࡰࡀ࡫ࡧࠫ᷃"),l11l1l11l111_tv_ (u"ࠫࠬ᷄")) + l11l1l11l111_tv_ (u"ࠬࠬࡴࡰ࡭ࡨࡲࡂ࠭᷅") + l1111lll1ll11l111_tv_ +l11l1l11l111_tv_ (u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱ࠢࠫ࡜࠶࠷࠻ࠡࡎ࡬ࡲࡺࡾࠠࡪ࠸࠻࠺ࡀࠦࡲࡷ࠼࠷࠸࠳࠶ࠩࠡࡉࡨࡧࡰࡵ࠯࠳࠲࠴࠴࠵࠷࠰࠲ࠢࡉ࡭ࡷ࡫ࡦࡰࡺ࠲࠸࠹࠴࠰ࠡࡋࡦࡩࡼ࡫ࡡࡴࡧ࡯࠳࠹࠺࠮࠱ࠨࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ᷆")+url
    except:
        pass
    print(l11l1l11l111_tv_ (u"ࠧࡷ࡫ࡧࡳࡤࡻࡲ࡭ࠩ᷇"),l1ll11lll1l11l111_tv_)
    return l1ll11lll1l11l111_tv_
def l111l1lll11l111_tv_(item):
    host = item.get(l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ᷈"))
    url = item.get(l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭᷉"))
    l1lll1ll11l11l111_tv_=l11l1l11l111_tv_ (u"᷊ࠪࠫ")
    if l11l1l11l111_tv_ (u"ࠫࡸࡺࡡࡵ࡫ࡦ࠲ࡺ࠳ࡰࡳࡱ࠱ࡪࡷ࠭᷋") in host or l11l1l11l111_tv_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠱ࡧࡴࡳࠧ᷌") in url:
        data=l11l1l11l111_tv_ (u"࠭ࡳࡳࡥࡀࠦࠪࡹࠢࠨ᷍")%url
        l1lll1ll11l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
    elif l11l1l11l111_tv_ (u"ࠧࡥࡧ࡮ࡳࡩ࡫ࡲ࠯ࡹࡶ࠳ࡪࡳࡢࡦࡦ᷎ࠪ") in url:
        from l1llll11l11l111_tv_ import l1ll1111l1l11l111_tv_
        l1lll1ll11l11l111_tv_ = l1ll1111l1l11l111_tv_(url)
    elif l11l1l11l111_tv_ (u"ࠨࡼࡲࡦࡦࡩࡺࡵࡸ࠱࡭ࡳ࡬࡯ࠨ᷏") in url:
        from l111ll11l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ᷐࠭"),l11l1l11l111_tv_ (u"ࠪࠫ᷑")) if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"ࠫࠬ᷒")
    elif l11l1l11l111_tv_ (u"ࠬࡵࡤࡱࡣ࡯ࡸࡻ࠴ࡰ࡭ࠩᷓ") in url:
        from l1lll111l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪᷔ"),l11l1l11l111_tv_ (u"ࠧࠨᷕ")) if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"ࠨࠩᷖ")
    elif l11l1l11l111_tv_ (u"ࠩࡧࡥࡷࡳ࡯ࡸࡣ࠰ࡸࡻ࠴ࡰ࡭ࠩᷗ") in url:
        from l1llll111l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᷘ"),l11l1l11l111_tv_ (u"ࠫࠬᷙ")) if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"ࠬ࠭ᷚ")
    elif l11l1l11l111_tv_ (u"࠭ࡴࡦ࡮ࡨࡺ࡭ࡹ࠮ࡱ࡮ࠪᷛ") in url:
        from l1ll111ll11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫᷜ"),l11l1l11l111_tv_ (u"ࠨࠩᷝ")) if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"ࠩࠪᷞ")
    if l11l1l11l111_tv_ (u"ࠪࡸࡻ࠳ࡷࡦࡧࡥ࠲ࡨࡵ࡭ࠨᷟ") in url:
        from l1llllll1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨᷠ"),l11l1l11l111_tv_ (u"ࠬ࠭ᷡ")) if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"࠭ࠧᷢ")
    elif l11l1l11l111_tv_ (u"ࠧࡸ࡫ࡱࡸࡪࡾ࠮࡭࡫ࡰࡥ࠲ࡩࡩࡵࡻ࠱ࡨࡪ࠭ᷣ") in url:
        from l1l11ll1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬᷤ"),l11l1l11l111_tv_ (u"ࠩࠪᷥ")) if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"ࠪࠫᷦ")
    elif l11l1l11l111_tv_ (u"ࠫࡺࡹࡴࡳࡧࡤࡱ࡮ࡾࠧᷧ") in url:
        l1lll1ll11l11l111_tv_ = l11ll11l1ll11l111_tv_(url)
    elif l11l1l11l111_tv_ (u"ࠬࡺࡥ࡭ࡧࡺ࡭ࡿࡰࡡ࠮ࡤ࡯ࡥࡨࡱࠧᷨ") in host:
        from l11l111l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪᷩ"),l11l1l11l111_tv_ (u"ࠧࠨᷪ")) if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"ࠨࠩᷫ")
    elif l11l1l11l111_tv_ (u"ࠩ࡯ࡳࡴࡱ࡮ࡪ࡬࠱࡭ࡳ࠭ᷬ") in host:
        from l1lll1l1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᷭ"),l11l1l11l111_tv_ (u"ࠫࠬᷮ")) if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"ࠬ࠭ᷯ")
    elif l11l1l11l111_tv_ (u"࠭ࡷࡪࡼ࡭ࡥ࠳ࡺࡶࠨᷰ") in host:
        from l1l1lllll11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫᷱ"),l11l1l11l111_tv_ (u"ࠨࠩᷲ"))  if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"ࠩࠪᷳ")
    elif l11l1l11l111_tv_ (u"ࠪࡨࡦࡸ࡭ࡰࡹࡤ࠱ࡹ࡫࡬ࡦࡹ࡬ࡾ࡯ࡧ࠮ࡪࡰࡩࡳࠬᷴ") in host:
        from l11l11l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨ᷵"),l11l1l11l111_tv_ (u"ࠬ࠭᷶")) if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"᷷࠭ࠧ")
    elif l11l1l11l111_tv_ (u"ࠧࡵࡧ࡯ࡩ࠲ࡽࡩࡻ࡬ࡤ᷸ࠫ") in host:
        from l11llll1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠨࡷࡵࡰ᷹ࠬ"),l11l1l11l111_tv_ (u"᷺ࠩࠪ")) if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"ࠪࠫ᷻")
    elif l11l1l11l111_tv_ (u"ࠫࡼࡽࡷ࠯ࡶࡹࡴ࠳ࡶ࡬ࠨ᷼") in host:
        from l11ll1lll11l111_tv_ import _1l1l11l11l11l111_tv_
        l1lll1ll11l11l111_tv_ = _1l1l11l11l11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭᷽ࠩ"),l11l1l11l111_tv_ (u"࠭ࠧ᷾"))  if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"ࠧࠨ᷿")
    return l1lll1ll11l11l111_tv_
