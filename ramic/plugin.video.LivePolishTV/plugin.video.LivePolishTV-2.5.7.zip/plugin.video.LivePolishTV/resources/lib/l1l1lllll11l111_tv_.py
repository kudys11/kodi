# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re
import time,json
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸ࡫ࡽ࡮ࡦ࠴ࡴࡷ࠱ࠪẋ")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠶࠲࠱࠴࠳࠸࠶࠷࠳࠱࠵࠵࠸ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧẌ")
__all__=[l11l1l11l111_tv_ (u"ࠩࡪࡩࡹࡉࡨࡢࡰࡱࡩࡱࡹࠧẍ"),l11l1l11l111_tv_ (u"ࠪ࡫ࡪࡺࡃࡩࡣࡱࡲࡪࡲࡖࡪࡦࡨࡳࠬẎ")]
fix={
l11l1l11l111_tv_ (u"ࠫࡆࡲࡥ࡬࡫ࡱࡳࠬẏ"):l11l1l11l111_tv_ (u"ࠬࡧ࡬ࡦࠢ࡮࡭ࡳࡵࠫࠨẐ"),
l11l1l11l111_tv_ (u"࠭ࡁ࡯࡫ࡰࡥࡱ࠭ẑ"):l11l1l11l111_tv_ (u"ࠧࡂࡰ࡬ࡱࡦࡲࠠࡑ࡮ࡤࡲࡪࡺࠧẒ"),
l11l1l11l111_tv_ (u"ࠨࡅࡤࡲࡦࡲࠧẓ"):l11l1l11l111_tv_ (u"ࠩࡆࡥࡳࡧ࡬ࠬࠩẔ"),
l11l1l11l111_tv_ (u"ࠪࡇࡦࡴࡡ࡭ࡦ࡬ࡷࡨࡵࡶࡦࡴࡼࠫẕ"):l11l1l11l111_tv_ (u"ࠫࡈࡧ࡮ࡢ࡮࠮ࠤࡉ࡯ࡳࡤࡱࡹࡩࡷࡿࠠࡉࡆࠪẖ"),
l11l1l11l111_tv_ (u"ࠬࡉࡡ࡯ࡣ࡯ࡪࡦࡳࡩ࡭ࡻࠪẗ"):l11l1l11l111_tv_ (u"࠭ࡃࡢࡰࡤࡰ࠰ࠦࡆࡢ࡯࡬ࡰࡾ࠭ẘ"),
l11l1l11l111_tv_ (u"ࠧࡄࡣࡱࡥࡱ࡬ࡩ࡭࡯ࠪẙ"):l11l1l11l111_tv_ (u"ࠨࡅࡤࡲࡦࡲࠫࠡࡈ࡬ࡰࡲ࠭ẚ"),
l11l1l11l111_tv_ (u"ࠩࡆࡥࡳࡧ࡬ࡴࡲࡲࡶࡹ࠭ẛ"):l11l1l11l111_tv_ (u"ࠪࡇࡦࡴࡡ࡭࠭ࠣࡗࡵࡵࡲࡵࠩẜ"),
l11l1l11l111_tv_ (u"ࠫࡈࡧ࡮ࡢ࡮ࡶࡴࡴࡸࡴ࠳ࠩẝ"):l11l1l11l111_tv_ (u"ࠬࡉࡡ࡯ࡣ࡯࠯࡙ࠥࡰࡰࡴࡷࠤ࠷࠭ẞ"),
l11l1l11l111_tv_ (u"࠭ࡃࡢࡴࡷࡳࡴࡴࠧẟ"):l11l1l11l111_tv_ (u"ࠧࡄࡣࡵࡸࡴࡵ࡮ࠡࡐࡨࡸࡼࡵࡲ࡬ࠩẠ"),
l11l1l11l111_tv_ (u"ࠨࡅ࡬ࡲࡪࡳࡡࡹࠩạ"):l11l1l11l111_tv_ (u"ࠩࡆ࡭ࡳ࡫࡭ࡢࡺࠪẢ"),
l11l1l11l111_tv_ (u"ࠪࡇࡴࡳࡥࡥࡻࠪả"):l11l1l11l111_tv_ (u"ࠫࡈࡵ࡭ࡦࡦࡼࠤࡈ࡫࡮ࡵࡴࡤࡰࠬẤ"),
l11l1l11l111_tv_ (u"ࠬࡊࡩࡴࡥࡲࡺࡪࡸࡹࠨấ"):l11l1l11l111_tv_ (u"࠭ࡄࡪࡵࡦࡳࡻ࡫ࡲࡺࠢࡆ࡬ࡦࡴ࡮ࡦ࡮ࠪẦ"),
l11l1l11l111_tv_ (u"ࠧࡅ࡫ࡶࡧࡴࡼࡥࡳࡻ࡫࡭ࡸࡺ࡯ࡳ࡫ࡤࠫầ"):l11l1l11l111_tv_ (u"ࠨࡆ࡬ࡷࡨࡵࡶࡦࡴࡼࠤࡍ࡯ࡳࡵࡱࡵ࡭ࡦ࠭Ẩ"),
l11l1l11l111_tv_ (u"ࠩࡇ࡭ࡸࡩ࡯ࡷࡧࡵࡽࡸࡩࡩࡦࡰࡦࡩࠬẩ"):l11l1l11l111_tv_ (u"ࠪࡈ࡮ࡹࡣࡰࡸࡨࡶࡾࠦࡓࡤ࡫ࡨࡲࡨ࡫ࠧẪ"),
l11l1l11l111_tv_ (u"ࠫࡉ࡯ࡳ࡯ࡧࡼ࡮ࡺࡴࡩࡰࡴࠪẫ"):l11l1l11l111_tv_ (u"ࠬࡊࡩࡴࡰࡨࡽࠥࡐࡵ࡯࡫ࡲࡶࠬẬ"),
l11l1l11l111_tv_ (u"࠭ࡅ࡭ࡧࡹࡩࡳ࠭ậ"):l11l1l11l111_tv_ (u"ࠧࡆ࡮ࡨࡺࡪࡴࠧẮ"),
l11l1l11l111_tv_ (u"ࠨࡇ࡯ࡩࡻ࡫࡮ࡦࡺࡷࡶࡦ࠭ắ"):l11l1l11l111_tv_ (u"ࠩࡈࡰࡪࡼࡥ࡯ࠢࡈࡼࡹࡸࡡࠨẰ"),
l11l1l11l111_tv_ (u"ࠪࡉࡱ࡫ࡶࡦࡰࡶࡴࡴࡸࡴࡴࠩằ"):l11l1l11l111_tv_ (u"ࠫࡊࡲࡥࡷࡧࡱࠤࡘࡶ࡯ࡳࡶࡶࠫẲ"),
l11l1l11l111_tv_ (u"ࠬࡋࡳ࡬ࡣࠪẳ"):l11l1l11l111_tv_ (u"࠭ࡅࡴ࡭ࡤࠤ࡙࡜ࠧẴ"),
l11l1l11l111_tv_ (u"ࠧࡆࡷࡵࡳࡸࡶ࡯ࡳࡶ࠴ࠫẵ"):l11l1l11l111_tv_ (u"ࠨࡇࡸࡶࡴࡹࡰࡰࡴࡷࠫẶ"),
l11l1l11l111_tv_ (u"ࠩࡈࡹࡷࡵࡳࡱࡱࡵࡸ࠷࠭ặ"):l11l1l11l111_tv_ (u"ࠪࡉࡺࡸ࡯ࡴࡲࡲࡶࡹࠦ࠲ࠨẸ"),
l11l1l11l111_tv_ (u"ࠫࡋ࡯࡬࡮ࡤࡲࡼࠬẹ"):l11l1l11l111_tv_ (u"ࠬࡌࡩ࡭࡯ࡥࡳࡽ࠭Ẻ"),
l11l1l11l111_tv_ (u"࠭ࡈࡣࡱࠪẻ"):l11l1l11l111_tv_ (u"ࠧࡉࡄࡒࠫẼ"),
l11l1l11l111_tv_ (u"ࠨࡊࡥࡳ࠷࠭ẽ"):l11l1l11l111_tv_ (u"ࠩࡋࡆࡔ࠸ࠧẾ"),
l11l1l11l111_tv_ (u"ࠪࡌࡧࡵ࠳ࠨế"):l11l1l11l111_tv_ (u"ࠫࡍࡈࡏ࠴ࠩỀ"),
l11l1l11l111_tv_ (u"ࠬࡎࡩࡴࡶࡲࡶࡾ࠭ề"):l11l1l11l111_tv_ (u"࠭ࡈࡪࡵࡷࡳࡷࡿࠧỂ"),
l11l1l11l111_tv_ (u"ࠧࡌ࡫ࡱࡳࡵࡵ࡬ࡴ࡭ࡤࠫể"):l11l1l11l111_tv_ (u"ࠨࡍ࡬ࡲࡴࠦࡐࡰ࡮ࡶ࡯ࡦ࠭Ễ"),
l11l1l11l111_tv_ (u"ࠩࡐࡸࡻ࠭ễ"):l11l1l11l111_tv_ (u"ࠪࡑ࡙࡜ࠠࡑࡱ࡯ࡷࡰࡧࠧỆ"),
l11l1l11l111_tv_ (u"ࠫࡓࡧࡴࡨࡧࡲࠫệ"):l11l1l11l111_tv_ (u"ࠬࡔࡡࡵ࡫ࡲࡲࡦࡲࠠࡈࡧࡲ࡫ࡷࡧࡰࡩ࡫ࡦࠤࡈ࡮ࡡ࡯ࡰࡨࡰࠬỈ"),
l11l1l11l111_tv_ (u"࠭ࡎࡢࡶࡪࡩࡴࡽࡩ࡭ࡦࠪỉ"):l11l1l11l111_tv_ (u"ࠧࡏࡣࡷࠤࡌ࡫࡯࡙ࠡ࡬ࡰࡩ࠭Ị"),
l11l1l11l111_tv_ (u"ࠨࡐࡶࡴࡴࡸࡴࠨị"):l11l1l11l111_tv_ (u"ࠩࡱࡗࡵࡵࡲࡵࠩỌ"),
l11l1l11l111_tv_ (u"ࠪࡔࡴࡲࡳࡢࡶࠪọ"):l11l1l11l111_tv_ (u"ࠫࡕࡵ࡬ࡴࡣࡷࠫỎ"),
l11l1l11l111_tv_ (u"ࠬࡖ࡯࡭ࡵࡤࡸࡳ࡫ࡷࡴࠩỏ"):l11l1l11l111_tv_ (u"࠭ࡐࡰ࡮ࡶࡥࡹࠦࡎࡦࡹࡶࠫỐ"),
l11l1l11l111_tv_ (u"ࠧࡑࡱ࡯ࡷࡦࡺࡰ࡭ࡣࡼࠫố"):l11l1l11l111_tv_ (u"ࠨࡒࡲࡰࡸࡧࡴࠡࡒ࡯ࡥࡾ࠭Ồ"),
l11l1l11l111_tv_ (u"ࠩࡓࡳࡱࡹࡡࡵࡵࡳࡳࡷࡺࠧồ"):l11l1l11l111_tv_ (u"ࠪࡔࡴࡲࡳࡢࡶࠣࡗࡵࡵࡲࡵࠩỔ"),
l11l1l11l111_tv_ (u"ࠫࡕࡵ࡬ࡴࡣࡷࡷࡵࡵࡲࡵࡧࡻࡸࡷࡧࠧổ"):l11l1l11l111_tv_ (u"ࠬࡖ࡯࡭ࡵࡤࡸ࡙ࠥࡰࡰࡴࡷࠤࡊࡾࡴࡳࡣࠪỖ"),
l11l1l11l111_tv_ (u"࠭ࡐࡰ࡮ࡶࡥࡹࡹࡰࡰࡴࡷࡲࡪࡽࡳࠨỗ"):l11l1l11l111_tv_ (u"ࠧࡑࡱ࡯ࡷࡦࡺࠠࡔࡲࡲࡶࡹࠦࡎࡦࡹࡶࠫỘ"),
l11l1l11l111_tv_ (u"ࠨࡖ࡯ࡧࠬộ"):l11l1l11l111_tv_ (u"ࠩࡗࡐࡈ࠭Ớ"),
l11l1l11l111_tv_ (u"ࠪࡘࡷࡧࡶࡦ࡮ࠪớ"):l11l1l11l111_tv_ (u"࡙ࠫࡸࡡࡷࡧ࡯ࠤࡈ࡮ࡡ࡯ࡰࡨࡰࠬỜ"),
l11l1l11l111_tv_ (u"࡚ࠬࡶ࠵ࠩờ"):l11l1l11l111_tv_ (u"࠭ࡔࡗࠢ࠷ࠫỞ"),
l11l1l11l111_tv_ (u"ࠧࡕࡸࡱࠫở"):l11l1l11l111_tv_ (u"ࠨࡖ࡙ࡒࠬỠ"),
l11l1l11l111_tv_ (u"ࠩࡗࡺࡳ࠸࠴ࠨỡ"):l11l1l11l111_tv_ (u"ࠪࡘ࡛ࡔࠠ࠳࠶ࠪỢ"),
l11l1l11l111_tv_ (u"࡙ࠫࡼ࡮࠸ࠩợ"):l11l1l11l111_tv_ (u"࡚ࠬࡖࡏࠢ࠺ࠫỤ"),
l11l1l11l111_tv_ (u"࠭ࡔࡷࡰࡶࡸࡾࡲࡥࠨụ"):l11l1l11l111_tv_ (u"ࠧࡕࡘࡑࠤࡘࡺࡹ࡭ࡧࠪỦ"),
l11l1l11l111_tv_ (u"ࠨࡖࡹࡲࡹࡻࡲࡣࡱࠪủ"):l11l1l11l111_tv_ (u"ࠩࡗ࡚ࡓࠦࡔࡶࡴࡥࡳࠬỨ"),
l11l1l11l111_tv_ (u"ࠪࡘࡻࡶ࠱ࠨứ"):l11l1l11l111_tv_ (u"࡙ࠫ࡜ࡐࠡ࠳ࠪỪ"),
l11l1l11l111_tv_ (u"࡚ࠬࡶࡱ࠴ࠪừ"):l11l1l11l111_tv_ (u"࠭ࡔࡗࡒࠣ࠶ࠬỬ"),
l11l1l11l111_tv_ (u"ࠧࡕࡸࡳࡷࡪࡸࡩࡢ࡮ࡨࠫử"):l11l1l11l111_tv_ (u"ࠨࡖ࡙ࡔ࡙ࠥࡥࡳ࡫ࡤࡰࡪ࠭Ữ"),
l11l1l11l111_tv_ (u"ࠩࡗࡺࡵࡹࡰࡰࡴࡷࠫữ"):l11l1l11l111_tv_ (u"ࠪࡘ࡛ࡖࠠࡔࡲࡲࡶࡹ࠭Ự"),
l11l1l11l111_tv_ (u"࡙ࠫࡼࡰࡶ࡮ࡶࠫự"):l11l1l11l111_tv_ (u"࡚ࠬࡖࠡࡒࡸࡰࡸ࠭Ỳ"),
l11l1l11l111_tv_ (u"࠭ࡖࡪࡸࡤࠫỳ"):l11l1l11l111_tv_ (u"ࠧࡗࡋ࡙ࡅࠥࡖ࡯࡭ࡵ࡮ࡥࠬỴ"),
}
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    l1llll11l1l11l111_tv_ = fix.get(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠨࡶࡹ࡭ࡩ࠭ỵ")),l11l1l11l111_tv_ (u"ࠩࠪỶ"))
    if l1llll11l1l11l111_tv_:
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩỷ")]=l1llll11l1l11l111_tv_
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩỸ")]=l1llll11l1l11l111_tv_
    return l1l1l1ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩỹ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࠧỺ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    url=l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸ࡫ࡽ࡮ࡦ࠴ࡴࡷ࠱ࠪỻ")
    content = l111111l11l111_tv_(url)
    l11llll11ll11l111_tv_=re.compile(l11l1l11l111_tv_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬࡼࡧࡴࡤࡪ࠱࠮ࡄ࠯ࠢ࠿࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࡁ࠵ࡡ࠿ࠩỼ")).findall(content)
    out=[]
    for ch in l11llll11ll11l111_tv_:
        t = ch[1].split(l11l1l11l111_tv_ (u"ࠩ࠲ࠫỽ"))[-1].split(l11l1l11l111_tv_ (u"ࠪ࠲ࠬỾ"))[0].title()
        i = l1llll111ll11l111_tv_ + ch[1]
        h = l1llll111ll11l111_tv_ + ch[0]
        out.append(l1lll1l1l1l11l111_tv_({l11l1l11l111_tv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪỿ"):t,l11l1l11l111_tv_ (u"ࠬࡺࡶࡪࡦࠪἀ"):t,l11l1l11l111_tv_ (u"࠭ࡩ࡮ࡩࠪἁ"):i,l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫἂ"):h,l11l1l11l111_tv_ (u"ࠨࡩࡵࡳࡺࡶࠧἃ"):l11l1l11l111_tv_ (u"ࠩࠪἄ"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࡥࡱࡩࠪἅ"):l11l1l11l111_tv_ (u"ࠫࠬἆ")}))
    out = sorted(out, key=lambda k: k[l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫἇ")],reverse=False)
    if out and addheader:
        t=l11l1l11l111_tv_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡹࡦ࡮࡯ࡳࡼࡣࡕࡱࡦࡤࡸࡪࡪ࠺ࠡࠧࡶࠤ࠭ࡽࡩࡻ࡬ࡤ࠲ࡹࡼࠩ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩἈ") %time.strftime(l11l1l11l111_tv_ (u"ࠢࠦࡦ࠲ࠩࡲ࠵࡚ࠥ࠼ࠣࠩࡍࡀࠥࡎ࠼ࠨࡗࠧἉ"))
        out.append({l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧἊ"):t,l11l1l11l111_tv_ (u"ࠩࡷࡺ࡮ࡪࠧἋ"):l11l1l11l111_tv_ (u"ࠪࠫἌ"),l11l1l11l111_tv_ (u"ࠫ࡮ࡳࡧࠨἍ"):l11l1l11l111_tv_ (u"ࠬ࠭Ἆ"),l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪἏ"):l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸ࡫ࡽ࡮ࡦ࠴ࡴࡷ࠱ࠪἐ"),l11l1l11l111_tv_ (u"ࠨࡩࡵࡳࡺࡶࠧἑ"):l11l1l11l111_tv_ (u"ࠩࠪἒ"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࡥࡱࡩࠪἓ"):l11l1l11l111_tv_ (u"ࠫࠬἔ")})
    return out
def l11l1llll1l11l111_tv_(url,params=None,header={}):
    req = urllib2.Request(url,params,headers=header)
    sock=urllib2.urlopen(req)
    cookies=sock.info()[l11l1l11l111_tv_ (u"࡙ࠬࡥࡵ࠯ࡆࡳࡴࡱࡩࡦࠩἕ")]
    sock.close()
    return cookies
def l1llll1l1lll11l111_tv_(cookies=l11l1l11l111_tv_ (u"࠭ࠧ἖"),value=l11l1l11l111_tv_ (u"ࠧࡴࡧࡶࡷࡸ࡯ࡤࠨ἗")):
    l1l11l111ll11l111_tv_=cookies.find(value+l11l1l11l111_tv_ (u"ࠨ࠿ࠪἘ"))
    if l1l11l111ll11l111_tv_==-1:
        l1l11l111lll11l111_tv_ (u"ࠩࠪἙ")
    else:
        l1l11l11l1l11l111_tv_=cookies.find(l11l1l11l111_tv_ (u"ࠪ࠿ࠬἚ"),l1l11l111ll11l111_tv_+1)
    return cookies[l1l11l111ll11l111_tv_:l1l11l11l1l11l111_tv_]
def l111l1lll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼ࡯ࡺ࡫ࡣ࠱ࡸࡻ࠵ࡷࡢࡶࡦ࡬࠳ࡶࡨࡱࡁ࡬ࡨࡂ࠷࠲࠳ࠩἛ")):
    l1lll1ll11l11l111_tv_=[]
    if l11l1l11l111_tv_ (u"ࠬࡽࡩࡻ࡬ࡤ࠲ࡹࡼࠧἜ") in url:
        id = re.search(l11l1l11l111_tv_ (u"࠭ࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠥࠩἝ"),url)
        if id:
            id = id.group(1)
        elif l11l1l11l111_tv_ (u"ࠧࡪࡦࡀࠫ἞")in url:
            id=url.l1l111lll1ll11l111_tv_(l11l1l11l111_tv_ (u"ࠨ࡫ࡧࡁࠬ἟"))[-1]
        else:
            id=l11l1l11l111_tv_ (u"ࠩ࠴࠶࠷࠭ἠ")
        l1l11l11111l11l111_tv_=l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻ࡮ࢀࡪࡢ࠰ࡷࡺ࠴ࡶ࡯ࡳࡶࡨࡶ࠳ࡶࡨࡱࡁࡦ࡬ࡂࠫࡳࠨἡ")%id
        l1l111llllll11l111_tv_=l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼ࡯ࡺ࡫ࡣ࠱ࡸࡻ࠵ࡰ࡭ࡣࡼࡩࡷ࠴ࡰࡩࡲࡂࡸࡦࡸࡧࡦࡶࡀࡩࡵࡵ࡮ࡢ࠵ࠩࡧ࡭ࡃࠥࡴࠩἢ")%id
        l1l111llllll11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡩࡻ࡬ࡤ࠲ࡹࡼ࠯ࡱ࡮ࡤࡽࡪࡸ࠮ࡱࡪࡳࡃࠫࡩࡨ࠾ࠧࡶࠫἣ")%id
        print l1l111llllll11l111_tv_
        header={
                l11l1l11l111_tv_ (u"࠭ࡁࡤࡥࡨࡴࡹ࠭ἤ"):l11l1l11l111_tv_ (u"ࠧࡵࡧࡻࡸ࠴࡮ࡴ࡮࡮࠯ࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࡫ࡸࡲࡲࠫࡹ࡯࡯࠰ࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻࡱࡱࡁࡱ࠾࠲࠱࠽࠱࡯࡭ࡢࡩࡨ࠳ࡼ࡫ࡢࡱ࠮࠭࠳࠯ࡁࡱ࠾࠲࠱࠼ࠬἥ"),
                l11l1l11l111_tv_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬἦ"):l11l1l11l111_tv_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠷࠳࠲࠵࠴࠲࠷࠸࠴࠲࠶࠶࠲ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨἧ"),
                l11l1l11l111_tv_ (u"ࠪࡌࡴࡹࡴࠨἨ"):l11l1l11l111_tv_ (u"ࠫࡼ࡯ࡺ࡫ࡣ࠱ࡸࡻ࠭Ἡ"),
                l11l1l11l111_tv_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭Ἢ"):url,
                l11l1l11l111_tv_ (u"࠭ࡃࡢࡥ࡫ࡩ࠲ࡉ࡯࡯ࡶࡵࡳࡱ࠭Ἣ"):l11l1l11l111_tv_ (u"ࠧ࡮ࡣࡻ࠱ࡦ࡭ࡥ࠾࠲ࠪἬ"),
                l11l1l11l111_tv_ (u"ࠣࡅࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠧἭ"):l11l1l11l111_tv_ (u"ࠤ࡮ࡩࡪࡶ࠭ࡢ࡮࡬ࡺࡪࠨἮ"),
                l11l1l11l111_tv_ (u"࡙ࠪࡵ࡭ࡲࡢࡦࡨ࠱ࡎࡴࡳࡦࡥࡸࡶࡪ࠳ࡒࡦࡳࡸࡩࡸࡺࡳࠨἯ"):l11l1l11l111_tv_ (u"ࠫ࠶࠭ἰ"),
                }
        c=l11l1llll1l11l111_tv_(url,header=header)
        l1llll1l11l11l111_tv_=l11l1l11l111_tv_ (u"ࠬࠦࠧἱ").join([l11l1l11l111_tv_ (u"࠭ࠥࡴ࠽ࠪἲ")%l1llll1l1lll11l111_tv_(c,s) for s in [l11l1l11l111_tv_ (u"ࠧࡠࡡࡦࡪࡩࡻࡩࡥࠩἳ"),l11l1l11l111_tv_ (u"ࠨࡒࡋࡔࡘࡋࡓࡔࡋࡇࠫἴ")]])
        header[l11l1l11l111_tv_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩἵ")]=l1llll1l11l11l111_tv_
        data = l111111l11l111_tv_(l1l11l11111l11l111_tv_,header=header)
        l1l11l11l11l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠪࡷࡷࡩ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩἶ")).findall(data)
        if len(l1l11l11l11l11l111_tv_)>0:
            l1l111llll1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡪࡳࡢࡦࡦࡖ࡛ࡋࡢࡳࠫ࡞ࠫࡠࡸ࠰࡛ࠣ࡞ࠪࡡ࠭࠴ࠪ࠯ࡵࡺࡪ࠮ࡡࠢ࡝ࠩࡠࠫἷ")).findall(data)
            l1l11l111l1l11l111_tv_ = urllib.unquote(l1l11l11l11l11l111_tv_[0]).decode(l11l1l11l111_tv_ (u"ࠬࡻࡴࡧ࠯࠻ࠫἸ"))
            l1l11l1111ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭ࡲࡵ࡯ࡳ࠾࠴࠵ࠨ࠯ࠬࡂ࠭࠴࠮࠮ࠫࡁࠬ࠳࠭࠴ࠪࡀࠫ࡟ࡃ࠭࠴ࠪࡀࠫ࡟ࠪࡸࡺࡲࡦࡣࡰࡘࡾࡶࡥࠨἹ")).findall(l1l11l111l1l11l111_tv_)
            l1ll11lll1l11l111_tv_ = l11l1l11l111_tv_ (u"ࠧࡳࡶࡰࡴ࠿࠵࠯ࠨἺ") + l1l11l1111ll11l111_tv_[0][0] + l11l1l11l111_tv_ (u"ࠨ࠱ࠪἻ") + l1l11l1111ll11l111_tv_[0][1] + l11l1l11l111_tv_ (u"ࠩࡂࠫἼ") + l1l11l1111ll11l111_tv_[0][3] + l11l1l11l111_tv_ (u"ࠪࠤࡵࡲࡡࡺࡲࡤࡸ࡭ࡃࠧἽ") + l1l11l1111ll11l111_tv_[0][2] + l11l1l11l111_tv_ (u"ࠫࡄ࠭Ἶ") + l1l11l1111ll11l111_tv_[0][3] +  l11l1l11l111_tv_ (u"ࠬࠦࡴࡪ࡯ࡨࡳࡺࡺ࠽࠳࠷ࠣࡷࡼ࡬ࡕࡳ࡮ࡀ࡬ࡹࡺࡰ࠻࠱࠲ࡻ࡮ࢀࡪࡢ࠰ࡷࡺ࠴ࡶ࡬ࡢࡻࡨࡶ࠴࡙ࡴࡳࡱࡥࡩࡒ࡫ࡤࡪࡣࡓࡰࡦࡿࡢࡢࡥ࡮ࡣࡻ࠺࠮ࡴࡹࡩࠤࡱ࡯ࡶࡦ࠿ࡷࡶࡺ࡫ࠠࡱࡣࡪࡩ࡚ࡸ࡬࠾ࠩἿ") + l1l111llllll11l111_tv_
            l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪὀ"):l1ll11lll1l11l111_tv_}]
        else:
            l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠧ࡮ࡵࡪࠫὁ"):l11l1l11l111_tv_ (u"ࠨ࡝ࡅࡡࡇࡸࡡ࡬ࠢࡺࡳࡱࡴࡹࡤࡪࠣࡱ࡮࡫ࡪࡴࡥࠤ࡟࠴ࡈ࡝࡝ࡰ࡝ࡩࠥࡽࡺࡨ࡮जࡨࡺࠦ࡮ࡢࠢࡧࡹঁࡧࠠࡪ࡮ࡲय़ऌࠦ࡯ࡨ࡮ईࡨࡦࡰअࡤࡻࡦ࡬ࠥࡵࡳࣴࡤࠣ࠱ࠥࡪ࡯ࡴࡶजࡴࠥࡺࡹ࡭࡭ࡲࠤࡩࡲࡡࠡࡷॿࡽࡹࡱ࡯ࡸࡰ࡬࡯ࣸࡽࠠࡑࡴࡨࡱ࡮ࡻ࡭࠯࡞ࡱ࡟ࡇࡣࡋࡰࡰࡷࡥࠥࡖࡲࡦ࡯࡬ࡹࡲࠦ࡮ࡪࡧࠣࡦञࡪअࠡࡶࡸࠤࡴࡨࡳृࡷࡪ࡭ࡼࡧ࡮ࡦࠣ࠱࡟࠴ࡈ࡝ࠨὂ")}]
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_()
    for o in out:
        print o.get(l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨὃ"))
