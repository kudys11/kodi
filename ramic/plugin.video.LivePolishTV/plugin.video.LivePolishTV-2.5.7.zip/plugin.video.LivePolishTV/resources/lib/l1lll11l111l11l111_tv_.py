# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re,time
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡰࡰ࡮ࡲࡲ࠲ࡺࡶ࠯ࡤ࡯ࡳ࡬ࡹࡰࡰࡶ࠱ࡧࡴࡳ࠯ࠨᓸ")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ᓹ")
__all__=[l11l1l11l111_tv_ (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ᓺ"),l11l1l11l111_tv_ (u"ࠩࡪࡩࡹࡉࡨࡢࡰࡱࡩࡱ࡜ࡩࡥࡧࡲࠫᓻ")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᓼ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠫࠬᓽ")
    return l11ll11ll11l111_tv_
def l1ll1l1l1ll11l111_tv_(url):
    l1lll1lll1l11l111_tv_=url
    try:
        req = urllib2.Request(url,headers={l11l1l11l111_tv_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᓾ"):l1lll1l1lll11l111_tv_})
        response = urllib2.urlopen(req, timeout=15)
        l1lll1lll1l11l111_tv_=response.geturl()
        response.close()
    except: pass
    return l1lll1lll1l11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࡠࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠾࠲ࡰ࡮ࡄࠧᓿ")).findall(content)
    for href,title in l1lll1lllll11l111_tv_:
        out.append({l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᔀ"):title.strip(),l11l1l11l111_tv_ (u"ࠨࡶࡹ࡭ࡩ࠭ᔁ"):title.strip(),l11l1l11l111_tv_ (u"ࠩ࡬ࡱ࡬࠭ᔂ"):l11l1l11l111_tv_ (u"ࠪࠫᔃ"),l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨᔄ"):href,l11l1l11l111_tv_ (u"ࠬ࡭ࡲࡰࡷࡳࠫᔅ"):l11l1l11l111_tv_ (u"࠭ࠧᔆ"),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࡩࡵ࡭ࠧᔇ"):l11l1l11l111_tv_ (u"ࠨࠩᔈ")})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡼࡩࡱࡲ࡯ࡸ࡟ࡘࡴࡩࡧࡴࡦࡦ࠽ࠤࠪࡹࠠࠩࡲࡲࡰࡴࡴ࠭ࡵࡸࠬ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᔉ") %time.strftime(l11l1l11l111_tv_ (u"ࠥࠩࡩ࠵ࠥ࡮࠱ࠨ࡝࠿ࠦࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠣᔊ"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪᔋ"):t,l11l1l11l111_tv_ (u"ࠬࡺࡶࡪࡦࠪᔌ"):l11l1l11l111_tv_ (u"࠭ࠧᔍ"),l11l1l11l111_tv_ (u"ࠧࡪ࡯ࡪࠫᔎ"):l11l1l11l111_tv_ (u"ࠨࠩᔏ"),l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭ᔐ"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠪ࡫ࡷࡵࡵࡱࠩᔑ"):l11l1l11l111_tv_ (u"ࠫࠬᔒ"),l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࡧࡳ࡫ࠬᔓ"):l11l1l11l111_tv_ (u"࠭ࠧᔔ")})
    return out
def l111l1lll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡱࡱ࡯ࡳࡳ࠳ࡴࡷ࠰ࡥࡰࡴ࡭ࡳࡱࡱࡷ࠲ࡨࡵ࡭࠰ࡲ࠲ࡸࡻࡴ࠮ࡩࡶࡰࡰࠬᔕ")):
    l1lll1ll11l11l111_tv_=[]
    if l11l1l11l111_tv_ (u"ࠨࡤ࡯ࡳ࡬ࡹࡰࡰࡶࠪᔖ") in url:
        content = l111111l11l111_tv_(url)
        l1111l111ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠩࡸࡲࡪࡹࡣࡢࡲࡨࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࡝ࠫࠪᔗ")).findall(content)
        l1111l111ll11l111_tv_ = urllib.unquote(l1111l111ll11l111_tv_[0]) if l1111l111ll11l111_tv_ else l11l1l11l111_tv_ (u"ࠪࠫᔘ")
        src = re.compile(l11l1l11l111_tv_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᔙ"),re.IGNORECASE).findall(l1111l111ll11l111_tv_)
        if src:
            src=src[0]
            if not l11l1l11l111_tv_ (u"ࠬࡨ࡬ࡰࡩࡶࡴࡴࡺࠧᔚ") in src:
                src = l1ll1l1l1ll11l111_tv_(src)
            content = l111111l11l111_tv_(src)
            l1111l111ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭ࡤࡰࡥࡸࡱࡪࡴࡴ࠯ࡹࡵ࡭ࡹ࡫࡜ࠩ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࡠ࠮࠭ᔛ")).findall(content)
            if l1111l111ll11l111_tv_:
                l1111l111ll11l111_tv_ = l1111l111ll11l111_tv_[0].replace(l11l1l11l111_tv_ (u"ࠧ࡝࡞ࡸ࠴࠵࠭ᔜ"),l11l1l11l111_tv_ (u"ࠨࠩᔝ")).decode(l11l1l11l111_tv_ (u"ࠩ࡫ࡩࡽ࠭ᔞ"))
                if l11l1l11l111_tv_ (u"ࠪࡨࡴࡩࡵ࡮ࡧࡱࡸ࠳ࡽࡲࡪࡶࡨࠫᔟ") in l1111l111ll11l111_tv_:
                    l1111l111ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡩࡵࡣࡶ࡯ࡨࡲࡹ࠴ࡷࡳ࡫ࡷࡩࡡ࠮ࡵ࡯ࡧࡶࡧࡦࡶࡥ࡝ࠪ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࡡ࠯ࠧᔠ")).findall(l1111l111ll11l111_tv_)
                    l1111l111ll11l111_tv_ = urllib.unquote(l1111l111ll11l111_tv_[0]) if l1111l111ll11l111_tv_ else l11l1l11l111_tv_ (u"ࠬ࠭ᔡ")
                src = re.compile(l11l1l11l111_tv_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᔢ"),re.IGNORECASE).findall(l1111l111ll11l111_tv_)
                if src:
                    src = src[0].replace(l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡯ࡷ࡯ࡰࡷ࡫ࡦࡦࡴ࠱ࡧࡴࡳ࠯ࡀࠩᔣ"),l11l1l11l111_tv_ (u"ࠨࠩᔤ"))
                    data = l111111l11l111_tv_(src)
                    l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src,data)
                    if l1ll11lll1l11l111_tv_: return [{l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭ᔥ"):l1ll11lll1l11l111_tv_}]
                else:
                    l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src,l1111l111ll11l111_tv_)
                    if l1ll11lll1l11l111_tv_: return [{l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᔦ"):l1ll11lll1l11l111_tv_}]
            l1111l111ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡩࡵࡣࡶ࡯ࡨࡲࡹ࠴ࡷࡳ࡫ࡷࡩࡡ࠮ࡵ࡯ࡧࡶࡧࡦࡶࡥ࡝ࠪ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࡡ࠯ࠧᔧ")).findall(content)
            if l1111l111ll11l111_tv_:
                data = urllib.unquote(l1111l111ll11l111_tv_[0]) if l1111l111ll11l111_tv_ else l11l1l11l111_tv_ (u"ࠬ࠭ᔨ")
                l1lll1ll11l11l111_tv_ = l1lll11l11ll11l111_tv_(data)
            else:
                l1lll1ll11l11l111_tv_ = l1lll11l11ll11l111_tv_(content)
    return l1lll1ll11l11l111_tv_
def l1lll11l11ll11l111_tv_(data):
    l1lll1ll11l11l111_tv_=[]
    l111111llll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭ࡻࠣࡨ࡬ࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᔩ")).findall(data)
    l1l1ll1ll1l11l111_tv_=l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡱ࠰࡭ࡻࡵࡩࡤ࡯࠰ࡦࡳࡲ࠵࠶࠰࠳࠵࠳࡯ࡽࡰ࡭ࡣࡼࡩࡷ࠴ࡦ࡭ࡣࡶ࡬࠳ࡹࡷࡧࠩᔪ")
    l1ll1l11l1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠨ࠾ࡰࡩࡹࡧࠠࡤࡱࡱࡸࡪࡴࡴ࠾࡝ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟ࠣࡴࡷࡵࡰࡦࡴࡷࡽࡂࡡࠢ࡝ࠩࡠࡳ࡬ࡀࡵࡳ࡮࡞ࠦࡡ࠭࡝࠰ࡀࠪᔫ")).findall(data)
    if l111111llll11l111_tv_ and l111111llll11l111_tv_[0].endswith(l11l1l11l111_tv_ (u"ࠩࡰ࠷ࡺ࠾ࠧᔬ")):
        l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᔭ"):l111111llll11l111_tv_[0]}]
    elif l111111llll11l111_tv_ and l1ll1l11l1l11l111_tv_:
        href = l111111llll11l111_tv_[0]+ l11l1l11l111_tv_ (u"ࠫࠥࡹࡷࡧࡗࡵࡰࡂࠫࡳࠡࡲࡤ࡫ࡪ࡛ࡲ࡭࠿ࠨࡷࠥࡲࡩࡷࡧࡀ࠵ࠥࡺࡩ࡮ࡧࡲࡹࡹࡃ࠱࠱ࠩᔮ")%(l1l1ll1ll1l11l111_tv_,l1ll1l11l1l11l111_tv_[0])
        l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩᔯ"):href}]
    else:
        l1ll1l1111l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡩࡧࡴࡤࡱࡪࡄࠧᔰ"),re.DOTALL|re.IGNORECASE).findall(data)
        if l1ll1l1111l11l111_tv_:
            connection = re.compile(l11l1l11l111_tv_ (u"ࠧ࡯ࡧࡷࡇࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴ࠽ࠩࡴࡷࡱࡵ࠴ࠪࡀࠫࠥࠫᔱ")).findall(l1ll1l1111l11l111_tv_[0])
            if connection:
                source = re.compile(l11l1l11l111_tv_ (u"ࠨࡵࡲࡹࡷࡩࡥ࠾ࠪ࡞ࡢࠫࡣࠫࠪࠩᔲ")).findall(connection[0])
                if source:
                    href = source[0] + l11l1l11l111_tv_ (u"ࠩࠣࡷࡼ࡬ࡕࡳ࡮ࡀࠩࡸࠦࡰࡢࡩࡨ࡙ࡷࡲ࠽ࠦࡵࠣࡰ࡮ࡼࡥ࠾࠳ࠣࡸ࡮ࡳࡥࡰࡷࡷࡁ࠶࠶ࠧᔳ")%(l1l1ll1ll1l11l111_tv_,l1ll1l11l1l11l111_tv_[0])
                    l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᔴ"):href}]
            else:
                href = l1ll11ll1ll11l111_tv_.decode(l1ll1l11l1l11l111_tv_[0],l1ll1l1111l11l111_tv_[0])
                if href : l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨᔵ"):href}]
    return l1lll1ll11l11l111_tv_
