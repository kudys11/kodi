# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡶࡲࡪࡸࡤࡸࡪ࡮ࡤ࠯ࡲࡺࠫᔶ")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠰࠯࠲࠱࠶࠻࠼࠱࠯࠳࠳࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬᔷ")
__all__=[l11l1l11l111_tv_ (u"ࠧࡨࡧࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬᔸ"),l11l1l11l111_tv_ (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰ࡛࡯ࡤࡦࡱࠪᔹ")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᔺ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠪࠫᔻ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿࡞ࠦࡡ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠬᔼ")).findall(content)
    for href,title in l1lll1lllll11l111_tv_:
        out.append({l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫᔽ"):title.strip(),l11l1l11l111_tv_ (u"࠭ࡴࡷ࡫ࡧࠫᔾ"):title.strip(),l11l1l11l111_tv_ (u"ࠧࡪ࡯ࡪࠫᔿ"):l11l1l11l111_tv_ (u"ࠨࠩᕀ"),l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭ᕁ"):href,l11l1l11l111_tv_ (u"ࠪ࡫ࡷࡵࡵࡱࠩᕂ"):l11l1l11l111_tv_ (u"ࠫࠬᕃ"),l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࡧࡳ࡫ࠬᕄ"):l11l1l11l111_tv_ (u"࠭ࠧᕅ")})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡺࡧ࡯ࡰࡴࡽ࡝ࡖࡲࡧࡥࡹ࡫ࡤ࠻ࠢࠨࡷࠥ࠮ࡰࡴࡣ࠰ࡸࡻ࠯࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨᕆ") %time.strftime(l11l1l11l111_tv_ (u"ࠣࠧࡧ࠳ࠪࡳ࠯࡛ࠦ࠽ࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨᕇ"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨᕈ"):t,l11l1l11l111_tv_ (u"ࠪࡸࡻ࡯ࡤࠨᕉ"):l11l1l11l111_tv_ (u"ࠫࠬᕊ"),l11l1l11l111_tv_ (u"ࠬ࡯࡭ࡨࠩᕋ"):l11l1l11l111_tv_ (u"࠭ࠧᕌ"),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫᕍ"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠨࡩࡵࡳࡺࡶࠧᕎ"):l11l1l11l111_tv_ (u"ࠩࠪᕏ"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࡥࡱࡩࠪᕐ"):l11l1l11l111_tv_ (u"ࠫࠬᕑ")})
    return out
def l111l1lll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡷࡽࡵ࡫ࡲࡵࡸ࠱ࡧࡴࡳ࠮ࡱ࡮࠲ࡸࡻࡴࠧᕒ")):
    l1lll1ll11l11l111_tv_=[]
    if l11l1l11l111_tv_ (u"࠭ࡴࡺࡲࡨࡶࡹࡼࠧᕓ") in url:
        content = l111111l11l111_tv_(url)
        l1ll1l1111l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠩ࠰࠭ࡃ࠮ࡂ࠯ࡪࡨࡵࡥࡲ࡫࠾ࠨᕔ")).findall(content)
        if l1ll1l1111l11l111_tv_:
            src = re.compile(l11l1l11l111_tv_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᕕ"),re.IGNORECASE).findall(l1ll1l1111l11l111_tv_[0])
            if src:
                data = l111111l11l111_tv_(src[0])
                if file :
                    l111111llll11l111_tv_ = file[0].split(l11l1l11l111_tv_ (u"ࠩࠩࠫᕖ"))[0]
                    href = l111111llll11l111_tv_ + l11l1l11l111_tv_ (u"ࠪࠤࡸࡽࡦࡖࡴ࡯ࡁࠪࡹࠠ࡭࡫ࡹࡩࡂ࠷ࠠࡵ࡫ࡰࡩࡴࡻࡴ࠾࠳࠳ࠤࡵࡧࡧࡦࡗࡵࡰࡂࠫࡳࠨᕗ")%(src[0],url)
                    l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨᕘ"):href}]
                else:
                    l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,l1111l111ll11l111_tv_)
                    if l1ll11lll1l11l111_tv_: l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩᕙ"):l1ll11lll1l11l111_tv_}]
    return l1lll1ll11l11l111_tv_
