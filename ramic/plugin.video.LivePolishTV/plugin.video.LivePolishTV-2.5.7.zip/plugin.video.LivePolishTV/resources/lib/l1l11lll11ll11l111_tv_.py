# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re
import time
import l1ll11ll1ll11l111_tv_
import cookielib
import urlparse
import threading
import l1ll1ll111l11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡫ࡩ࡯ࡧ࠮ࡵࡸ࠲ࠫᯟ")
l1lll1l1lll11l111_tv_ = l11l1l11l111_tv_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠶࠯࠳࠾ࠤࡷࡼ࠺࠳࠴࠱࠴࠮ࠦࡇࡦࡥ࡮ࡳ࠴࠸࠰࠲࠲࠳࠵࠵࠷ࠠࡇ࡫ࡵࡩ࡫ࡵࡸ࠰࠴࠵࠲࠵࠭ᯠ")
l1lll1ll1ll11l111_tv_=15
fix={}
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    l1llll11l1l11l111_tv_ = fix.get(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩᯡ")),l11l1l11l111_tv_ (u"ࠬ࠭ᯢ"))
    if l1llll11l1l11l111_tv_:
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬᯣ")]=l1llll11l1l11l111_tv_
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠧࡵࡸ࡬ࡨࠬᯤ")]=l1llll11l1l11l111_tv_
    return l1l1l1ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},l1llll1111l11l111_tv_=True):
    l1llll1l11l11l111_tv_=l11l1l11l111_tv_ (u"ࠨࠩᯥ")
    l1llll1ll1l11l111_tv_=[]
    if l1llll1111l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {l11l1l11l111_tv_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ᯦࠭"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_ =  response.read()
        response.close()
        l1llll1l11l11l111_tv_ = l11l1l11l111_tv_ (u"ࠪࠫᯧ").join([l11l1l11l111_tv_ (u"ࠫࠪࡹ࠽ࠦࡵ࠾ࠫᯨ")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
    except urllib2.HTTPError as e:
        l11ll11ll11l111_tv_ = l11l1l11l111_tv_ (u"ࠬ࠭ᯩ")
    return l11ll11ll11l111_tv_,l1llll1l11l11l111_tv_
def l1l1lll111l11l111_tv_(url, l1ll111l1ll11l111_tv_, index):
    out = l1l1l1lllll11l111_tv_(url)
    l1ll111l1ll11l111_tv_[index]=out
def l11l11l1l11l111_tv_(addheader=False):
    out=[]
    l1l111lllll11l111_tv_ = list()
    l1l1llll111l11l111_tv_=[l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡴࡷ࠰ࡲࡴࡪࡴ࡫ࡢࡶࡤࡰࡴ࡭࠮࡮࡮࠲ࡳ࡬ࡵ࡬࡯ࡧࠪᯪ"),l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡵࡸ࠱ࡳࡵ࡫࡮࡬ࡣࡷࡥࡱࡵࡧ࠯࡯࡯࠳࡮ࡴࡦࡰࡴࡰࡥࡨࡿࡪ࡯ࡧࠪᯫ"),l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡹ࠲ࡴࡶࡥ࡯࡭ࡤࡸࡦࡲ࡯ࡨ࠰ࡰࡰ࠴࡬ࡩ࡭࡯ࡲࡻࡪ࠵ࠧᯬ"),
            l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷࡺ࠳ࡵࡰࡦࡰ࡮ࡥࡹࡧ࡬ࡰࡩ࠱ࡱࡱ࠵࡮ࡢࡷ࡮ࡳࡼ࡫ࠧᯭ"),l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸࡻ࠴࡯ࡱࡧࡱ࡯ࡦࡺࡡ࡭ࡱࡪ࠲ࡲࡲ࠯ࡣࡣ࡭࡯ࡴࡽࡥࠨᯮ"),l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹࡼ࠮ࡰࡲࡨࡲࡰࡧࡴࡢ࡮ࡲ࡫࠳ࡳ࡬࠰ࡵࡳࡳࡷࡺ࡯ࡸࡧࠪᯯ")]
    l1ll111l1ll11l111_tv_ = [[] for x in l1l1llll111l11l111_tv_]
    for i,url in enumerate(l1l1llll111l11l111_tv_):
        thread = threading.Thread(name=l11l1l11l111_tv_ (u"࡚ࠬࡨࡳࡧࡤࡨࠪࡪࠧᯰ")%i, target = l1l1lll111l11l111_tv_, args=[url,l1ll111l1ll11l111_tv_,i])
        l1l111lllll11l111_tv_.append(thread)
        thread.start()
    while any([i.isAlive() for i in l1l111lllll11l111_tv_]): time.sleep(0.1)
    del l1l111lllll11l111_tv_[:]
    for l1l1l1ll11l111_tv_ in l1ll111l1ll11l111_tv_:
        out.extend(l1l1l1ll11l111_tv_)
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡹࡦ࡮࡯ࡳࡼࡣࡕࡱࡦࡤࡸࡪࡪ࠺ࠡࠧࡶࠤ࠭ࡺࡥ࡭ࡧ࠰ࡻ࡮ࢀࡪࡢࠫ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᯱ") %time.strftime(l11l1l11l111_tv_ (u"ࠢࠦࡦ࠲ࠩࡲ࠵࡚ࠥ࠼ࠣࠩࡍࡀࠥࡎ࠼ࠨࡗ᯲ࠧ"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫᯳ࠧ"):t,l11l1l11l111_tv_ (u"ࠩࡷࡺ࡮ࡪࠧ᯴"):l11l1l11l111_tv_ (u"ࠪࠫ᯵"),l11l1l11l111_tv_ (u"ࠫ࡮ࡳࡧࠨ᯶"):l11l1l11l111_tv_ (u"ࠬ࠭᯷"),l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪ᯸"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠧࡨࡴࡲࡹࡵ࠭᯹"):l11l1l11l111_tv_ (u"ࠨࠩ᯺"),l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩ᯻"):l11l1l11l111_tv_ (u"ࠪࠫ᯼")})
    out = l1ll1ll111l11l111_tv_.l1ll1ll1l1l11l111_tv_(out,local)
    return out
def l11l11l1l11l111_tv_(addheader=False):
    out=[]
    content,c = l111111l11l111_tv_(l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡭࡫ࡪࡢ࠰ࡷࡺ࠴࠭᯽"))
    ids = [(a.start(), a.end()) for a in re.finditer(l11l1l11l111_tv_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡧ࡭ࡧ࡮࡯ࡧ࡯ࠤࡧࡵࡸࠨ᯾"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l1l1lll1lll11l111_tv_ = content[ ids[i][1]:ids[i+1][0] ]
        href  = re.compile(l11l1l11l111_tv_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ᯿")).findall(l1l1lll1lll11l111_tv_)
        l1llll11lll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠧ࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᰀ")).findall(l1l1lll1lll11l111_tv_)
        title = re.compile(l11l1l11l111_tv_ (u"ࠨ࠾࡫࠸ࠥࡩ࡬ࡢࡵࡶࡁࠧࡶ࡯ࡴࡶ࠰ࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᰁ")).findall(l1l1lll1lll11l111_tv_)
        if re.search(l11l1l11l111_tv_ (u"ࠩ࠿࡭ࠥࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡣࡰࡰ࠰ࡩࡾ࡫࠭ࡰࡲࡨࡲࠧࡄࠧᰂ"),l1l1lll1lll11l111_tv_) and href:
            t = title[0]
            i = l1llll11lll11l111_tv_[0] if l1llll11lll11l111_tv_ else l11l1l11l111_tv_ (u"ࠪࠫᰃ")
            h = href[0]
            out.append(l1lll1l1l1l11l111_tv_({l11l1l11l111_tv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪᰄ"):t,l11l1l11l111_tv_ (u"ࠬࡺࡶࡪࡦࠪᰅ"):t,l11l1l11l111_tv_ (u"࠭ࡩ࡮ࡩࠪᰆ"):i,l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫᰇ"):h,l11l1l11l111_tv_ (u"ࠨࡩࡵࡳࡺࡶࠧᰈ"):l11l1l11l111_tv_ (u"ࠩࠪᰉ"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࡥࡱࡩࠪᰊ"):l11l1l11l111_tv_ (u"ࠫࠬᰋ"),l11l1l11l111_tv_ (u"ࠬࡩ࡯ࡥࡧࠪᰌ"):l11l1l11l111_tv_ (u"࠭ࠧᰍ")}))
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡺࡧ࡯ࡰࡴࡽ࡝ࡖࡲࡧࡥࡹ࡫ࡤ࠻ࠢࠨࡷࠥ࠮ࡨࡦ࡬ࡤ࠲ࡹࡼࠩ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᰎ") %time.strftime(l11l1l11l111_tv_ (u"ࠣࠧࡧ࠳ࠪࡳ࠯࡛ࠦ࠽ࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨᰏ"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨᰐ"):t,l11l1l11l111_tv_ (u"ࠪࡸࡻ࡯ࡤࠨᰑ"):l11l1l11l111_tv_ (u"ࠫࠬᰒ"),l11l1l11l111_tv_ (u"ࠬ࡯࡭ࡨࠩᰓ"):l11l1l11l111_tv_ (u"࠭ࠧᰔ"),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫᰕ"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠨࡩࡵࡳࡺࡶࠧᰖ"):l11l1l11l111_tv_ (u"ࠩࠪᰗ"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࡥࡱࡩࠪᰘ"):l11l1l11l111_tv_ (u"ࠫࠬᰙ")})
    out = l1ll1ll111l11l111_tv_.l1ll1ll1l1l11l111_tv_(out,local)
    return out
def l111l1lll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡮ࡥ࡫ࡣ࠱ࡸࡻ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࡷ࡫ࡨࡻ࠴ࡩࡡ࡯ࡣ࡯࠱࠷࠭ᰚ")):
    l1lll1ll11l11l111_tv_=[]
    content,c = l111111l11l111_tv_(url)
    l1l1ll11lll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭ࡣࡩࡣࡱࡲࡪࡲࡆ࡮ࡵࡘࡶࡱࡃࠨࡳࡶࡰࡴࡠࡤࠦ࡞ࠬࠬࠫᰛ")).findall(content)
    l1l1lll1l1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠧࡤࡪࡤࡲࡳ࡫࡬ࡊࡦࡀࠬࡠࡤࠦ࡞ࠬࠬࠫᰜ")).findall(content)
    l1l1ll1ll1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠨ࠾ࡲࡦ࡯࡫ࡣࡵࠢ࠱࠮ࠥࡪࡡࡵࡣࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴࠴ࠪࡀࡵࡺࡪ࠮ࠨࠧᰝ")).findall(content)
    l1l1ll1ll1l11l111_tv_ = l1l1ll1ll1l11l111_tv_[0] if l1l1ll1ll1l11l111_tv_ else l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡫ࡩ࡯ࡧ࠮ࡵࡸ࠲ࡺ࡮࡫ࡷࡦࡴࡑࡳࡈ࡮ࡡࡵ࠰ࡶࡻ࡫࠭ᰞ")
    if l1l1ll11lll11l111_tv_ and l1l1lll1l1l11l111_tv_:
        src = urllib.unquote(l1l1ll11lll11l111_tv_[0])
        l1l1ll1111l11l111_tv_ = l1l1lll1l1l11l111_tv_[0]
        l1ll11lll1l11l111_tv_ =src+l1l1ll1111l11l111_tv_+l11l1l11l111_tv_ (u"ࠪࠤࡵࡲࡡࡺࡲࡤࡸ࡭ࡃࡳࡵࡴࡨࡥࡲࠦࡳࡸࡨࡘࡶࡱࡃࠧᰟ")+l1l1ll1ll1l11l111_tv_ + l11l1l11l111_tv_ (u"ࠫࠥࡹࡷࡧࡘࡩࡽࡂ࠷ࠠ࡭࡫ࡹࡩࡂ࠷ࠠࡵ࡫ࡰࡩࡴࡻࡴ࠾࠳࠶ࠤࡵࡧࡧࡦࡗࡵࡰࡂ࠭ᰠ")+url
        l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩᰡ"):l1ll11lll1l11l111_tv_,l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬᰢ"):l11l1l11l111_tv_ (u"ࠧࠨᰣ"),l11l1l11l111_tv_ (u"ࠨࡴࡨࡷࡴࡲࡶࡦࡦࠪᰤ"):1})
    else:
        src=l11l1l11l111_tv_ (u"ࠩࡵࡸࡲࡶ࠺࠰࠱࠻࠻࠳࠷࠲࠱࠰࠶࠺࠳࠿࠷࠰ࡸ࡬ࡨࡪࡵ࠯ࠨᰥ")
        l1l1ll1111l11l111_tv_=url.split(l11l1l11l111_tv_ (u"ࠪ࠱ࠬᰦ"))[-1]
        l1ll11lll1l11l111_tv_ =src+l1l1ll1111l11l111_tv_+l11l1l11l111_tv_ (u"ࠫࠥࡶ࡬ࡢࡻࡳࡥࡹ࡮࠽ࡴࡶࡵࡩࡦࡳࠠࡴࡹࡩ࡙ࡷࡲ࠽ࠨᰧ")+l1l1ll1ll1l11l111_tv_ + l11l1l11l111_tv_ (u"ࠬࠦࡳࡸࡨ࡙ࡪࡾࡃ࠱ࠡ࡮࡬ࡺࡪࡃ࠱ࠡࡶ࡬ࡱࡪࡵࡵࡵ࠿࠴࠷ࠥࡶࡡࡨࡧࡘࡶࡱࡃࠧᰨ")+url
        l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪᰩ"):l1ll11lll1l11l111_tv_,l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᰪ"):l11l1l11l111_tv_ (u"ࠨࠩᰫ"),l11l1l11l111_tv_ (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫᰬ"):1})
    return l1lll1ll11l11l111_tv_
def l1l1ll1l1ll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸࡻ࠴࡯ࡱࡧࡱ࡯ࡦࡺࡡ࡭ࡱࡪ࠲ࡲࡲ࠯ࡰࡩࡲࡰࡳ࡫࠯ࡱࡱ࡯ࡷࡦࡺ࠭ࡰࡰ࡯࡭ࡳ࡫࠯ࠨᰭ")):
    l1lll1ll11l11l111_tv_=[]
    content,c = l111111l11l111_tv_(url)
    l1l1lll11ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠭࠴ࠪࡀࠫ࠿࠳࡮࡬ࡲࡢ࡯ࡨࡂࠬᰮ"),re.DOTALL).findall(content)
    for l1ll1l1111l11l111_tv_ in l1l1lll11ll11l111_tv_:
        l1ll1l11l1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᰯ")).findall(l1ll1l1111l11l111_tv_)
        if l1ll1l11l1l11l111_tv_:
            data,c = l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0])
            l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
            if l1ll11lll1l11l111_tv_:
                l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪᰰ"):l1ll11lll1l11l111_tv_,l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᰱ"):l11l1l11l111_tv_ (u"ࠨࡎ࡬ࡺࡪࠦࠧᰲ")+urlparse.urlparse(l1ll11lll1l11l111_tv_).netloc,l11l1l11l111_tv_ (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫᰳ"):1})
                break
            else:
                l1ll1l1l11l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠪ࡟ࠧࡢࠧ࡞ࠪ࡫ࡸࡹࡶ࠮ࠫࡁ࡟࠲ࡲ࠹ࡵ࡜࠺ࡠ࠭ࡠࠨ࡜ࠨ࡟ࠪᰴ")).findall(data)
                if l1ll1l1l11l11l111_tv_:
                    l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨᰵ"):l1ll1l1l11l11l111_tv_[0],l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫᰶ"):l11l1l11l111_tv_ (u"࠭ࡌࡪࡸࡨࠤ࠭ࡳ࠳ࡶ᰷ࠫࠪ"),l11l1l11l111_tv_ (u"ࠧࡳࡧࡶࡳࡱࡼࡥࡥࠩ᰸"):1})
                    break
                else:
                    l1ll1l1111l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠪ࠱࠮ࡄ࠯࠼࠰࡫ࡩࡶࡦࡳࡥ࠿ࠩ᰹"),re.DOTALL).findall(data)
                    l1ll1l1111l11l111_tv_ = l1ll1l1111l11l111_tv_[0] if l1ll1l1111l11l111_tv_ else l11l1l11l111_tv_ (u"ࠩࠪ᰺")
                    l1ll1l11l1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᰻")).findall(l1ll1l1111l11l111_tv_)
                    if l1ll1l11l1l11l111_tv_:
                        data,c = l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0])
                    l1ll1l1l11l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡠࠨ࡜ࠨ࡟ࠫ࡬ࡹࡺࡰ࠯ࠬࡂࡠ࠳ࡳ࠳ࡶ࡝࠻ࡡ࠮ࡡࠢ࡝ࠩࡠࠫ᰼")).findall(data)
                    if l1ll1l1l11l11l111_tv_:
                        l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩ᰽"):l1ll1l1l11l11l111_tv_[0],l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ᰾"):l11l1l11l111_tv_ (u"ࠧࡍ࡫ࡹࡩࠥ࠮࡭࠴ࡷࠬࠫ᰿"),l11l1l11l111_tv_ (u"ࠨࡴࡨࡷࡴࡲࡶࡦࡦࠪ᱀"):1})
                        break
                    else:
                        l1l1l1ll11l11l111_tv_ = [x.strip() for x in re.findall(l11l1l11l111_tv_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡟ࡷ࠯࡮ࡴࡵࡲ࠽࠳࠴ࡺࡥ࡭ࡧ࠰ࡻ࡮ࢀࡪࡢ࠰ࡦࡳࡲ࠵ࡺࡢࡲࡤࡷ࠳࠰࠿ࠪࠤࠪ᱁"),content)]
                        for l1l1ll111ll11l111_tv_ in l1l1l1ll11l11l111_tv_:
                            print l11l1l11l111_tv_ (u"ࠪࡾࡦࡶࡡࡴࠩ᱂")
                            data,c = l111111l11l111_tv_( l1l1ll111ll11l111_tv_ )
                            l1l1lll11ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠭࠴ࠪࡀࠫ࠿࠳࡮࡬ࡲࡢ࡯ࡨࡂࠬ᱃"),re.DOTALL).findall(data)
                            for l1ll1l1111l11l111_tv_ in l1l1lll11ll11l111_tv_:
                                l1ll11lll1l11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࠭᱄")
                                l1ll1l11l1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᱅")).findall(l1ll1l1111l11l111_tv_)
                                if l1ll1l11l1l11l111_tv_:
                                    data,c = l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0])
                                    l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
                                if l1ll11lll1l11l111_tv_:
                                    l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫ᱆"):l1ll11lll1l11l111_tv_,l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ᱇"):l11l1l11l111_tv_ (u"ࠩࡏ࡭ࡻ࡫ࠠࠨ᱈")+urlparse.urlparse(l1ll11lll1l11l111_tv_).netloc,l11l1l11l111_tv_ (u"ࠪࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ᱉"):1})
                                    break
    return l1lll1ll11l11l111_tv_
def l1l1l1lll1l11l111_tv_():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        url=l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨ᱊"))
        print l11l1l11l111_tv_ (u"ࠬࡢ࡮ࠨ᱋"),l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ᱌"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫᱍ")))
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᱎ")))
        print l1lll1ll11l11l111_tv_
