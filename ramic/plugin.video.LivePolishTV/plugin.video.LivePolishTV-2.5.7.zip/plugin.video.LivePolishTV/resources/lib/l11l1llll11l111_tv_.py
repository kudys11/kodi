# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
_1lll1ll111l11l111_tv_=l11l1l11l111_tv_ (u"ࠧࡢࡵࡧࡪࡦࡹࡤࡧࠩᑻ")
import os,re
import urllib,urllib2
import cookielib,json
import threading,time
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠻࠴࠱࠼࡚ࠢ࡭ࡳ࠼࠴࠼ࠢࡻ࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠻࠶࠮࠱࠰࠶࠵࠶࠸࠮࠲࠲࠴ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫᑼ")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠩࡹ࡭ࡩ࡫࡯ࡴࡶࡤࡶ࠴࠷࠮࠵࠹ࠣࡇࡋࡔࡥࡵࡹࡲࡶࡰ࠵࠸࠱࠺࠱࠵࠳࠺ࠠࡅࡣࡵࡻ࡮ࡴ࠯࠲࠸࠱࠵࠳࠶ࠧᑽ")
l11ll111l11l111_tv_=l11l1l11l111_tv_ (u"ࡵࠫࡨࡵ࡯࡬࡫ࡨࠫᑾ")
l1lll1ll1ll11l111_tv_=15
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡶࡩ࡭ࡱࡷ࠲ࡼࡶ࠮ࡱ࡮࠲ࡸࡻ࠭ᑿ")
def l1lll1llll1l11l111_tv_(l1llll1ll1l11l111_tv_):
    if not l1llll1ll1l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        l1llll1ll1l11l111_tv_.load(l11ll111l11l111_tv_,True,True)
    return l11l1l11l111_tv_ (u"ࠬࡁࠧᒀ").join([l11l1l11l111_tv_ (u"࠭ࠥࡴ࠿ࠨࡷࠬᒁ")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
def l111111l11l111_tv_(url,data=None,header={},proxy={},l1llll1l1l11l111_tv_=True,l1l1l11llll11l111_tv_=True,out=False):
    l1lll11l1l1l11l111_tv_={}
    if l11ll111l11l111_tv_ and l1llll1l1l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        try:
            l1llll1ll1l11l111_tv_.load(l11ll111l11l111_tv_,True,True)
        except:
            l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        l1lll1lll11l11l111_tv_ = urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_)
        if proxy:
            l1lll1l1l1ll11l111_tv_ = urllib2.ProxyHandler(proxy)
            opener = urllib2.build_opener(l1lll1l1l1ll11l111_tv_, l1lll1lll11l11l111_tv_)
        else:
            opener = urllib2.build_opener(l1lll1lll11l11l111_tv_)
        urllib2.install_opener(opener)
    req = urllib2.Request(url,data)
    headers = {l11l1l11l111_tv_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᒂ"):l1lll1l1lll11l111_tv_}
    headers.update(header)
    req = urllib2.Request(url,data,headers=headers)
    try:
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_ =  response.read()
        l1lll11l1l1l11l111_tv_[l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬᒃ")] = response.geturl() if out else l11l1l11l111_tv_ (u"ࠩࠪᒄ")
        response.close()
        if l11ll111l11l111_tv_ and l1l1l11llll11l111_tv_ and l1llll1l1l11l111_tv_:
            l1lll11l1l1l11l111_tv_[l11l1l11l111_tv_ (u"ࠪࡧࡴࡵ࡫ࡪࡧࠪᒅ")]=l11l1l11l111_tv_ (u"ࠫࡀ࠭ᒆ").join([l11l1l11l111_tv_ (u"ࠬࠫࡳ࠾ࠧࡶࠫᒇ")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
            l1llll1ll1l11l111_tv_.save(l11ll111l11l111_tv_, True,True)
    except urllib2.HTTPError as e:
        l11ll11ll11l111_tv_ = l11l1l11l111_tv_ (u"࠭ࠧᒈ")
    if out:
        return l11ll11ll11l111_tv_,l1lll11l1l1l11l111_tv_
    return l11ll11ll11l111_tv_
def l1llll111l1l11l111_tv_():
    import xbmcaddon
    l111l1ll11l111_tv_        = xbmcaddon.Addon()
    user = l111l1ll11l111_tv_.getSetting(l11l1l11l111_tv_ (u"ࠧࡱ࡫࡯ࡳࡹࡽࡰ࠯ࡷࡶࡩࡷ࠭ᒉ"))
    password = l111l1ll11l111_tv_.getSetting(l11l1l11l111_tv_ (u"ࠨࡲ࡬ࡰࡴࡺࡷࡱ࠰ࡳࡥࡸࡹࠧᒊ"))
    l111l11111l11l111_tv_ = l11l1l11l111_tv_ (u"ࠩ࡯ࡳ࡬࡯࡮࠾ࠧࡶࠪࡵࡧࡳࡴࡹࡲࡶࡩࡃࠥࡴࠨࡧࡩࡻ࡯ࡣࡦ࠿ࡺࡩࡧ࠭ᒋ") %(user.replace(l11l1l11l111_tv_ (u"ࠪࡄࠬᒌ"),l11l1l11l111_tv_ (u"ࠫࠪ࠺࠰ࠨᒍ")),password)
    return l111l11111l11l111_tv_
def l1lll1l11lll11l111_tv_(token=l11l1l11l111_tv_ (u"ࠬ࠭ᒎ")):
    try:
        import xbmcaddon
        xbmcaddon.Addon().setSetting(l11l1l11l111_tv_ (u"࠭ࡰࡪ࡮ࡲࡸࡼࡶ࠮ࡵࡱ࡮ࡩࡳ࠭ᒏ"),token)
    except:
        pass
    return
def l1lll1l1ll1l11l111_tv_():
    try:
        import xbmcaddon
        l1lll11lllll11l111_tv_ = xbmcaddon.Addon().getSetting(l11l1l11l111_tv_ (u"ࠧࡱ࡫࡯ࡳࡹࡽࡰ࠯ࡶࡲ࡯ࡪࡴࠧᒐ"))
    except:
        l1lll11lllll11l111_tv_=l11l1l11l111_tv_ (u"ࠨࠩᒑ")
    return l1lll11lllll11l111_tv_
def l1lll11ll11l11l111_tv_():
    url = l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡵ࡯࠭ࡱ࡫࡯ࡳࡹ࠴ࡷࡱ࠰ࡳࡰ࠴ࡻࡳࡦࡴ࠲ࡰࡴ࡭ࡩ࡯ࠩᒒ")
    try:
        data = l1llll111l1l11l111_tv_()
    except:
        data=l11l1l11l111_tv_ (u"ࠪࠫᒓ")
    content = l111111l11l111_tv_(url, data)
    if l11l1l11l111_tv_ (u"ࠫࠧࡹࡴࡢࡶࡸࡷࠧࡀࠠࠣࡱ࡮ࠦࠬᒔ") in content:
        data = json.loads(content)
        l1lll1l11lll11l111_tv_(data.get(l11l1l11l111_tv_ (u"ࠬࡻࡳࡦࡴࠪᒕ"),{}).get(l11l1l11l111_tv_ (u"࠭ࡴࡰ࡭ࡨࡲࠬᒖ"),l11l1l11l111_tv_ (u"ࠧࠨᒗ")))
        return True
    else:
        l1lll1l11lll11l111_tv_(l11l1l11l111_tv_ (u"ࠨࠩᒘ"))
        return False
def l11l11l1l11l111_tv_(addheader=False):
    l1lll11lll1l11l111_tv_ = l1lll11ll11l11l111_tv_()
    if l1lll11lll1l11l111_tv_:
        l1lll1l111ll11l111_tv_ = l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡵ࡯࠭ࡱ࡫࡯ࡳࡹ࠴ࡷࡱ࠰ࡳࡰ࠴ࡩࡨࡢࡰࡱࡩࡱࡹ࠯࡭࡫ࡶࡸࡄࡪࡥࡷ࡫ࡦࡩࡂࡽࡥࡣࠩᒙ")
    else:
        l1lll1l111ll11l111_tv_= l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡺࡡࡵ࡫ࡦ࠱ࡵ࡯࡬ࡰࡶ࠱ࡻࡵ࠴ࡰ࡭࠱ࡶࡸࡦࡺࡩࡤ࠱ࡪࡹࡪࡹࡴ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵ࠲ࡰ࡮ࡹࡴ࠰ࡹࡨࡦ࠳ࡰࡳࡰࡰࠪᒚ")
    content = l111111l11l111_tv_(l1lll1l111ll11l111_tv_)
    data= json.loads(content)
    out=[]
    for l1l1ll1111l11l111_tv_ in data.get(l11l1l11l111_tv_ (u"ࠫࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ᒛ"),[]):
        if l1lll11lll1l11l111_tv_:
            code =  l1l1ll1111l11l111_tv_.get(l11l1l11l111_tv_ (u"ࠬࡧࡣࡤࡧࡶࡷࡤࡹࡴࡢࡶࡸࡷࠬᒜ"),l11l1l11l111_tv_ (u"࠭ࠧᒝ"))
        else:
            code = l11l1l11l111_tv_ (u"ࠧࡣࡴࡤ࡯ࠥࡪ࡯ࡴࡶࡨࡴࡺ࠭ᒞ") if l1l1ll1111l11l111_tv_.get(l11l1l11l111_tv_ (u"ࠨࡩࡸࡩࡸࡺ࡟ࡵ࡫ࡰࡩࡴࡻࡴࠨᒟ"),l11l1l11l111_tv_ (u"ࠩࠪᒠ")) ==l11l1l11l111_tv_ (u"ࠪ࠴ࠬᒡ") else l11l1l11l111_tv_ (u"ࠦࡹࡿ࡭ࡤࡼࡤࡷࡴࡽࡹࠣᒢ")
        out.append({l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫᒣ"):l1l1ll1111l11l111_tv_.get(l11l1l11l111_tv_ (u"࠭࡮ࡢ࡯ࡨࠫᒤ"),l11l1l11l111_tv_ (u"ࠧࠨᒥ")),l11l1l11l111_tv_ (u"ࠨࡶࡹ࡭ࡩ࠭ᒦ"):l1l1ll1111l11l111_tv_.get(l11l1l11l111_tv_ (u"ࠩࡱࡥࡲ࡫ࠧᒧ"),l11l1l11l111_tv_ (u"ࠪࠫᒨ")),l11l1l11l111_tv_ (u"ࠫ࡮ࡳࡧࠨᒩ"):l1l1ll1111l11l111_tv_.get(l11l1l11l111_tv_ (u"ࠬࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨᒪ"),l11l1l11l111_tv_ (u"࠭ࠧᒫ")),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫᒬ"):l1l1ll1111l11l111_tv_.get(l11l1l11l111_tv_ (u"ࠨ࡫ࡧࠫᒭ"),l11l1l11l111_tv_ (u"ࠩࠪᒮ")),l11l1l11l111_tv_ (u"ࠪ࡫ࡷࡵࡵࡱࠩᒯ"):l11l1l11l111_tv_ (u"ࠫࠬᒰ"),l11l1l11l111_tv_ (u"ࠬࡩ࡯ࡥࡧࠪᒱ"):code})
    if not out:
        out.append({l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬᒲ"):l11l1l11l111_tv_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࡓ࡯ࡣࠡࡰ࡬ࡩࠥࢀ࡮ࡢ࡮ࡨࡾ࡮ࡵ࡮ࡰ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᒳ"),l11l1l11l111_tv_ (u"ࠨࡶࡹ࡭ࡩ࠭ᒴ"):l11l1l11l111_tv_ (u"ࠩࠪᒵ"),l11l1l11l111_tv_ (u"ࠪ࡭ࡲ࡭ࠧᒶ"):l11l1l11l111_tv_ (u"ࠫࠬᒷ"),l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩᒸ"):l11l1l11l111_tv_ (u"࠭ࠧᒹ"),l11l1l11l111_tv_ (u"ࠧࡨࡴࡲࡹࡵ࠭ᒺ"):l11l1l11l111_tv_ (u"ࠨࠩᒻ"),l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩᒼ"):l11l1l11l111_tv_ (u"ࠪࠫᒽ")})
    return out
def l1lll1l11l1l11l111_tv_():
    content=l111111l11l111_tv_(l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯࡫ࡧࡧࡱࡵࡡ࡬࠰ࡦࡳࡲ࠵ࡰࡳࡱࡻࡽࡱ࡯ࡳࡵ࠱ࡩࡶࡪ࡫࠭ࡱࡴࡲࡼࡾ࠳࡬ࡪࡵࡷ࠱ࡵࡵ࡬ࡢࡰࡧ࠲࡭ࡺ࡭࡭ࠩᒾ"),l1llll1l1l11l111_tv_=False)
    l1lll1lll1ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠬࡂࡤࡪࡸࠣࡷࡹࡿ࡬ࡦ࠿ࠥࡻ࡮ࡪࡴࡩ࠼࡟ࡨ࠰ࠫࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࡟ࡨ࠰࠯ࠥࠣࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩᒿ")).findall(content)
    l1lll1l1l11l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭࠼ࡵࡦࡁࠬ࡭ࡺࡴࡱ࡝ࡶࡡ࠯࠯࠼࠰ࡶࡧࡂࡁࡺࡤ࠿ࠪ࡟ࡨ࠰࠯࠼࠰ࡶࡧࡂࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡧࡂࠬᓀ"),re.DOTALL).findall(content)
    proxies=[{x[0]: l11l1l11l111_tv_ (u"ࠧࠦࡵ࠽ࠩࡸ࠭ᓁ")%(x[2],x[1])} for x in l1lll1l1l11l11l111_tv_]
    return proxies
def _1lll1ll11ll11l111_tv_(content):
    try:
        data= json.loads(content)
        data = data.get(l11l1l11l111_tv_ (u"ࠨࡦࡤࡸࡦ࠭ᓂ"),{})
        l1ll1l11l11l111_tv_ = data.get(l11l1l11l111_tv_ (u"ࠤࡶࡸࡷ࡫ࡡ࡮ࡡࡦ࡬ࡦࡴ࡮ࡦ࡮ࠥᓃ"),{}).get(l11l1l11l111_tv_ (u"ࠪࡷࡹࡸࡥࡢ࡯ࡶࠫᓄ"),[])
        l1llll1111ll11l111_tv_ =l1ll1l11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨᓅ"),[])[-1]
    except:
        data={}
        l1llll1111ll11l111_tv_ = l11l1l11l111_tv_ (u"ࠬ࠭ᓆ")# data.get(l11l1l11l111_tv_ (u"࠭ࡳࡵࡴࡨࡥࡲࡥࡣࡩࡣࡱࡲࡪࡲࠧᓇ"),{}).get(l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࡣࡧࡧࡳࡦࠩᓈ"),l11l1l11l111_tv_ (u"ࠨࠩᓉ"))
    return l1llll1111ll11l111_tv_,data
def _1llll11111l11l111_tv_(content):
    l1llll1111ll11l111_tv_=[]
    try:
        l1lll11ll1ll11l111_tv_= json.loads(content)
        data = l1lll11ll1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠩࡧࡥࡹࡧࠧᓊ"),{})
        l1ll1l11l11l111_tv_ = data.get(l11l1l11l111_tv_ (u"ࠥࡷࡹࡸࡥࡢ࡯ࡢࡧ࡭ࡧ࡮࡯ࡧ࡯ࠦᓋ"),{}).get(l11l1l11l111_tv_ (u"ࠫࡸࡺࡲࡦࡣࡰࡷࠬᓌ"),[])
        idx=1;
        for stream in l1ll1l11l11l111_tv_:
            if l11l1l11l111_tv_ (u"ࠬࡪࡡࡴࡪࠪᓍ") in stream.get(l11l1l11l111_tv_ (u"࠭ࡴࡺࡲࡨࠫᓎ"),l11l1l11l111_tv_ (u"ࠧࠨᓏ")): l1lll1ll1l1l11l111_tv_=l11l1l11l111_tv_ (u"ࠨࠢࠫࡘࡾࡲ࡫ࡰࠢࡎࡓࡉࡏࠠ࠲࠺ࠬࠫᓐ")
            else: l1lll1ll1l1l11l111_tv_=l11l1l11l111_tv_ (u"ࠩࠪᓑ")
            for href in stream.get(l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᓒ"),[]):
                title = l11l1l11l111_tv_ (u"ࡹࠬࡒࡩ࡯࡭ࠣࠩࡩ࠲ࠠ࡫ࡣ࡮ࡳॠऍ࠺ࠡ࡝ࡅࡡࠪࡹ࡛࠰ࡄࡠࠤࠪࡹࠧᓓ")%(idx,stream.get(l11l1l11l111_tv_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭ᓔ"),l11l1l11l111_tv_ (u"࠭ࠧᓕ")),l1lll1ll1l1l11l111_tv_)
                l1llll1111ll11l111_tv_.append({l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫᓖ"):href,l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᓗ"):title})
                idx+=1
    except:
        l1lll11ll1ll11l111_tv_={}
        l1llll1111ll11l111_tv_ = []
    return l1llll1111ll11l111_tv_,l1lll11ll1ll11l111_tv_
def l1l1lll111l11l111_tv_(url ,proxy, l1ll111l1ll11l111_tv_, index):
    header={l11l1l11l111_tv_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩᓘ"):l1lll1llll1l11l111_tv_(None)}
    try:
        content = l111111l11l111_tv_(url,header=header,proxy=proxy,l1llll1l1l11l111_tv_=False)
    except:
        content=l11l1l11l111_tv_ (u"ࠪࠫᓙ")
    l1ll111l1ll11l111_tv_[index]= _1lll1ll11ll11l111_tv_(content)
l1lll1ll1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠫࠬᓚ")
l1lll1ll1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡥࡶࡦࡳ࡫ࡢ࠯ࡳࡶࡴࡾࡹ࠯ࡲ࡯ࠫᓛ")
l1lll1llllll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࠧᓜ")
def l1lll1l1llll11l111_tv_(url,header={}):
    l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࡼࡿࠪᓝ")
    global l1lll1llllll11l111_tv_
    try:
        if not l1lll1llllll11l111_tv_:
            req = urllib2.Request(l1lll1ll1lll11l111_tv_,data=None,headers={l11l1l11l111_tv_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᓞ"): l11l1l11l111_tv_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠷࠳࠲࠵࠴࠲࠷࠸࠴࠲࠶࠶࠲ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨᓟ")})
            response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
            cookies=response.headers.get(l11l1l11l111_tv_ (u"ࠪࡷࡪࡺ࠭ࡤࡱࡲ࡯࡮࡫ࠧᓠ"),l11l1l11l111_tv_ (u"ࠫࠥ࠭ᓡ")).split(l11l1l11l111_tv_ (u"ࠬࠦࠧᓢ"))[0]
            response.close()
            l1lll1llllll11l111_tv_ = cookies
        else:
            cookies=l1lll1llllll11l111_tv_
        data = l11l1l11l111_tv_ (u"࠭ࡵ࠾ࠧࡶࠪࡦࡲ࡬ࡰࡹࡆࡳࡴࡱࡩࡦࡵࡀࡳࡳ࠭ᓣ")%urllib.quote_plus(url)
        l1lll1l1111l11l111_tv_ = l1lll1ll1lll11l111_tv_+l11l1l11l111_tv_ (u"ࠧ࠰࡫ࡱࡧࡱࡻࡤࡦࡵ࠲ࡴࡷࡵࡣࡦࡵࡶ࠲ࡵ࡮ࡰࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡷࡳࡨࡦࡺࡥࠨᓤ")
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        l1llll1ll1l11l111_tv_.load(l11ll111l11l111_tv_,True,True)
        c=l11l1l11l111_tv_ (u"ࠨ࠽ࠪᓥ").join([l11l1l11l111_tv_ (u"ࠩࡦ࡟ࡵ࡯࡬ࡰࡶ࠱ࡻࡵ࠴ࡰ࡭࡟࡞࠳ࡢࡡࠥࡴ࡟ࡀࠩࡸ࠭ᓦ")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
        headers={l11l1l11l111_tv_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᓧ"): l1lll1l1lll11l111_tv_,l11l1l11l111_tv_ (u"࡚ࠫࡶࡧࡳࡣࡧࡩ࠲ࡏ࡮ࡴࡧࡦࡹࡷ࡫࠭ࡓࡧࡴࡹࡪࡹࡴࡴࠩᓨ"):1,l11l1l11l111_tv_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬᓩ"):cookies+c}
        headers.update(header)
        req = urllib2.Request(l1lll1l1111l11l111_tv_,data,headers)
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_=response.read()
        if l11l1l11l111_tv_ (u"࠭ࡳࡴ࡮ࡤ࡫ࡷ࡫ࡥࠨᓪ") in l11ll11ll11l111_tv_:
            l1lll1l1111l11l111_tv_ = l1lll1ll1lll11l111_tv_+l11l1l11l111_tv_ (u"ࠧ࠰࡫ࡱࡧࡱࡻࡤࡦࡵ࠲ࡴࡷࡵࡣࡦࡵࡶ࠲ࡵ࡮ࡰࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡵࡶࡰࡦ࡭ࡲࡦࡧࠪᓫ")
            req = urllib2.Request(l1lll1l1111l11l111_tv_,data,headers)
            response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
            l11ll11ll11l111_tv_=response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠨࡽࢀࠫᓬ")
    return l11ll11ll11l111_tv_
def l111l1lll11l111_tv_(id=l11l1l11l111_tv_ (u"ࠩ࠹࠶ࠬᓭ")):
    if not id:
        return [{l11l1l11l111_tv_ (u"ࠪࡱࡸ࡭ࠧᓮ"):l11l1l11l111_tv_ (u"࡙ࠫ࡫ࡧࡰࠢࡱ࡭ࡪࠦࡺࡢࡩࡵࡥࡲࡧࡹࠢࠩᓯ")}]
    l1lll1ll11l11l111_tv_=[]
    if l1lll1l1ll1l11l111_tv_():
        url=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡱ࡫࠰ࡴ࡮ࡲ࡯ࡵ࠰ࡺࡴ࠳ࡶ࡬࠰ࡸ࠴࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴ࠫࡳࡀࡨࡲࡶࡲࡧࡴࡠ࡫ࡧࡁ࠷ࠬࡤࡦࡸ࡬ࡧࡪࡥࡴࡺࡲࡨࡁࡼ࡫ࡢࠨᓰ")%id
    else:
        url=l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡲ࡬࠱ࡵ࡯࡬ࡰࡶ࠱ࡻࡵ࠴ࡰ࡭࠱ࡹ࠵࠴࡭ࡵࡦࡵࡷ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴ࠫࡳࡀࡨࡲࡶࡲࡧࡴࡠ࡫ࡧࡁ࠷ࠬࡤࡦࡸ࡬ࡧࡪࡥࡴࡺࡲࡨࡁࡼ࡫ࡢࠨᓱ")%id
    content = l111111l11l111_tv_(url)
    l1llll1111ll11l111_tv_,data =_1llll11111l11l111_tv_(content)
    if not l1llll1111ll11l111_tv_:
        content = l1lll1l1llll11l111_tv_(url)
        l1llll1111ll11l111_tv_,data =_1llll11111l11l111_tv_(content)
    if l1llll1111ll11l111_tv_:
        l1lll1ll11l11l111_tv_=l1llll1111ll11l111_tv_
    else:
        try:
            l1lll11l1lll11l111_tv_= data[l11l1l11l111_tv_ (u"ࠢࡦࡴࡵࡳࡷࡹࠢᓲ")][0]
        except:
            l1lll11l1lll11l111_tv_= {l11l1l11l111_tv_ (u"ࡶࠩࡦࡳࡩ࡫ࠧᓳ"): -1, l11l1l11l111_tv_ (u"ࡷࠪࡱࡸ࡭ࠧᓴ"): l11l1l11l111_tv_ (u"ࡸࠫࡕࡸ࡯ࡣ࡮ࡨࡱࠬᓵ")}
        msg = l11l1l11l111_tv_ (u"ࡹࠬࡳࡳࡨ࠼ࠣ࡟ࡇࡣࡻ࡮ࡵࡪࢁࡠ࠵ࡂ࡞࠮ࠣࡧࡴࡪࡥ࠻ࠢ࡞ࡆࡢࢁࡣࡰࡦࡨࢁࡠ࠵ࡂ࡞ࠩᓶ").format(**l1lll11l1lll11l111_tv_)
        l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠬࡳࡳࡨࠩᓷ"):msg}]
    return l1lll1ll11l11l111_tv_
