# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re
import time
import l1ll11ll1ll11l111_tv_
import urlparse
import cookielib
import threading
__all__=[l11l1l11l111_tv_ (u"࠭ࡧࡦࡶࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ᭗"),l11l1l11l111_tv_ (u"ࠧࡨࡧࡷࡇ࡭ࡧ࡮࡯ࡧ࡯࡚࡮ࡪࡥࡰࠩ᭘")]
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡨࡰࡪࡽࡩࡻ࡬ࡤ࠱ࡱ࡯ࡶࡦ࠰ࡦࡳࡲ࠵ࠧ᭙")
l1lll1l1lll11l111_tv_ = l11l1l11l111_tv_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠼࠮࠲࠽ࠣࡶࡻࡀ࠲࠳࠰࠳࠭ࠥࡍࡥࡤ࡭ࡲ࠳࠷࠶࠱࠱࠲࠴࠴࠶ࠦࡆࡪࡴࡨࡪࡴࡾ࠯࠳࠴࠱࠴ࠬ᭚")
fix={
l11l1l11l111_tv_ (u"ࠪࡘࡻࡶ࠱ࠨ᭛"):l11l1l11l111_tv_ (u"࡙ࠫ࡜ࡐࠡ࠳ࠪ᭜"),
 l11l1l11l111_tv_ (u"࡚ࠬࡶࡱ࠴ࠪ᭝"):l11l1l11l111_tv_ (u"࠭ࡔࡗࡒࠣ࠶ࠬ᭞"),
 l11l1l11l111_tv_ (u"ࠧࡕࡸࡳ࡬ࡩ࠭᭟"):l11l1l11l111_tv_ (u"ࠨࡖ࡙ࡔࠥࡎࡄࠨ᭠"),
 l11l1l11l111_tv_ (u"ࠩࡗࡺࡳ࠭᭡"):l11l1l11l111_tv_ (u"ࠪࡘ࡛ࡔࠧ᭢"),
 l11l1l11l111_tv_ (u"࡙ࠫࡼ࡮࠳࠶ࠪ᭣"):l11l1l11l111_tv_ (u"࡚ࠬࡖࡏ࠴࠷ࠫ᭤"),
 l11l1l11l111_tv_ (u"࠭ࡁࡹࡰࠪ᭥"):l11l1l11l111_tv_ (u"ࠧࡂ࡚ࡑࠫ᭦"),
 l11l1l11l111_tv_ (u"ࠨࡊࡥࡳ࠷࠭᭧"):l11l1l11l111_tv_ (u"ࠩࡋࡆࡔ࠸ࠧ᭨"),
 l11l1l11l111_tv_ (u"ࠪࡔࡦࡸࡡࠨ᭩"):l11l1l11l111_tv_ (u"ࠫࡕࡧࡲࡢࠩ᭪"),
 l11l1l11l111_tv_ (u"ࠬࡌࡩ࡭࡯ࡥࡳࡽ࠭᭫"):l11l1l11l111_tv_ (u"࠭ࡆࡪ࡮ࡰࡦࡴࡾ᭬ࠧ"),
 l11l1l11l111_tv_ (u"ࠧࡄࡱࡰࡩࡩࡿࡣࡦࡰࡷࡩࡷ࠭᭭"):l11l1l11l111_tv_ (u"ࠨࡅࡲࡱࡪࡪࡹࠡࡅࡨࡲࡹ࡫ࡲࠨ᭮"),
 l11l1l11l111_tv_ (u"ࠩࡄࡲ࡮ࡳࡡ࡭ࡲ࡯ࡥࡳ࡫ࡴࠨ᭯"):l11l1l11l111_tv_ (u"ࠪࡅࡳ࡯࡭ࡢ࡮ࠣࡔࡱࡧ࡮ࡦࡶࠪ᭰"),
 l11l1l11l111_tv_ (u"ࠫࡈࡧ࡮ࡢ࡮ࡧ࡭ࡸࡩ࡯ࡷࡧࡵࡽࠬ᭱"):l11l1l11l111_tv_ (u"ࠬࡊࡩࡴࡥࡲࡺࡪࡸࡹࠡࡅࡤࡲࡦࡲࠧ᭲"),
 l11l1l11l111_tv_ (u"࠭ࡄࡪࡵࡦࡳࡻ࡫ࡲࡺࡶࡸࡶࡧࡵࠧ᭳"):l11l1l11l111_tv_ (u"ࠧࡅ࡫ࡶࡧࡴࡼࡥࡳࡻࠣࡸࡺࡸࡢࡰࠩ᭴"),
 l11l1l11l111_tv_ (u"ࠨࡊ࡬ࡷࡹࡵࡲࡺࠩ᭵"):l11l1l11l111_tv_ (u"ࠩࡋ࡭ࡸࡺ࡯ࡳࡻࠪ᭶"),
 l11l1l11l111_tv_ (u"ࠪࡌ࠷࠭᭷"):l11l1l11l111_tv_ (u"ࠫࡍ࠸ࠧ᭸"),
 l11l1l11l111_tv_ (u"ࠬࡔࡡࡵࡩࡨࡳࡼ࡯࡬ࡥࠩ᭹"):l11l1l11l111_tv_ (u"࠭ࡎࡢࡶࡪࡩࡴࡽࡩ࡭ࡦࠪ᭺"),
 l11l1l11l111_tv_ (u"ࠧࡕࡸࡱࡷࡹࡿ࡬ࡦࠩ᭻"):l11l1l11l111_tv_ (u"ࠨࡖࡹࡲ࡙ࠥࡴࡺ࡮ࡨࠫ᭼"),
 l11l1l11l111_tv_ (u"ࠩࡗࡰࡨ࠭᭽"):l11l1l11l111_tv_ (u"ࠪࡘࡑࡉࠧ᭾"),
 l11l1l11l111_tv_ (u"ࠫࡊࡻࡲࡰࡵࡳࡳࡷࡺࠧ᭿"):l11l1l11l111_tv_ (u"ࠬࡋࡵࡳࡱࡶࡴࡴࡸࡴࠨᮀ"),
 l11l1l11l111_tv_ (u"࠭ࡅ࡭ࡧࡹࡩࡳࡹࡰࡰࡴࡷࡷࠬᮁ"):l11l1l11l111_tv_ (u"ࠧࡆ࡮ࡨࡺࡪࡴࠠࡴࡲࡲࡶࡹࡹࠧᮂ"),
 l11l1l11l111_tv_ (u"ࠨࡒࡲࡰࡸࡧࡴࡴࡲࡲࡶࡹ࠭ᮃ"):l11l1l11l111_tv_ (u"ࠩࡓࡳࡱࡹࡡࡵࠢࡶࡴࡴࡸࡴࠨᮄ")}
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    l1llll11l1l11l111_tv_ = fix.get(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠪࡸࡻ࡯ࡤࠨᮅ")),l11l1l11l111_tv_ (u"ࠫࠬᮆ"))
    if l1llll11l1l11l111_tv_:
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫᮇ")]=l1llll11l1l11l111_tv_
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"࠭ࡴࡷ࡫ࡧࠫᮈ")]=l1llll11l1l11l111_tv_
    return l1l1l1ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᮉ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=20)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠨࠩᮊ")
    return l11ll11ll11l111_tv_
def l1l1lll111l11l111_tv_(l11ll1lllll11l111_tv_, l1ll111l1ll11l111_tv_, index):
    out = l11lll11l1l11l111_tv_(url=l11ll1lllll11l111_tv_)
    l1ll111l1ll11l111_tv_[index]=out
def l11l11l1l11l111_tv_(addheader=False):
    out=[]
    l11lll1ll1l11l111_tv_ =[l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷࡩࡱ࡫ࡷࡪࡼ࡭ࡥ࠲ࡲࡩࡷࡧ࠱ࡧࡴࡳ࠯ࡰࡩࡲࡰࡳ࡫࠮ࡩࡶࡰࡰࠬᮋ"),
            l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸࡪࡲࡥࡸ࡫ࡽ࡮ࡦ࠳࡬ࡪࡸࡨ࠲ࡨࡵ࡭࠰࡫ࡱࡪࡴࡸ࡭ࡢࡥࡼ࡮ࡳ࡫࠮ࡩࡶࡰࡰࠬᮌ"),
            l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹ࡫࡬ࡦࡹ࡬ࡾ࡯ࡧ࠭࡭࡫ࡹࡩ࠳ࡩ࡯࡮࠱ࡩ࡭ࡱࡳ࡯ࡸࡧ࠱࡬ࡹࡳ࡬ࠨᮍ"),
            l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡺࡥ࡭ࡧࡺ࡭ࡿࡰࡡ࠮࡮࡬ࡺࡪ࠴ࡣࡰ࡯࠲ࡲࡦࡻ࡫ࡰࡹࡨ࠲࡭ࡺ࡭࡭ࠩᮎ"),
            l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡴࡦ࡮ࡨࡻ࡮ࢀࡪࡢ࠯࡯࡭ࡻ࡫࠮ࡤࡱࡰ࠳ࡸࡶ࡯ࡳࡶࡲࡻࡪ࠴ࡨࡵ࡯࡯ࠫᮏ"),
            l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣ࠰ࡰ࡮ࡼࡥ࠯ࡥࡲࡱ࠴ࡳࡵࡻࡻࡦࡾࡳ࡫࠮ࡩࡶࡰࡰࠬᮐ"),
            l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡨࡰࡪࡽࡩࡻ࡬ࡤ࠱ࡱ࡯ࡶࡦ࠰ࡦࡳࡲ࠵ࡢࡢ࡬࡮ࡳࡼ࡫࠮ࡩࡶࡰࡰࠬᮑ")]
    l1l111lllll11l111_tv_ = []
    l1ll111l1ll11l111_tv_ = [[] for x in l11lll1ll1l11l111_tv_]
    for i,l11ll1lllll11l111_tv_ in enumerate(l11lll1ll1l11l111_tv_):
        thread = threading.Thread(name=l11l1l11l111_tv_ (u"ࠩࡗ࡬ࡷ࡫ࡡࡥࠧࡧࠫᮒ")%i, target = l1l1lll111l11l111_tv_, args=[l11ll1lllll11l111_tv_,l1ll111l1ll11l111_tv_,i])
        l1l111lllll11l111_tv_.append(thread)
        thread.start()
    while any([i.isAlive() for i in l1l111lllll11l111_tv_]): time.sleep(0.1)
    del l1l111lllll11l111_tv_[:]
    for l1l1l1ll11l111_tv_ in l1ll111l1ll11l111_tv_:
        out.extend(l1l1l1ll11l111_tv_)
    if len(out)>0 and addheader:
        t=l11l1l11l111_tv_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡽࡪࡲ࡬ࡰࡹࡠ࡙ࡵࡪࡡࡵࡧࡧ࠾ࠥࠫࡳࠡࠪࡷࡩࡱ࡫ࡷࡪࡼ࡭ࡥ࠲ࡲࡩࡷࡧ࠱ࡧࡴࡳࠩ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᮓ") %time.strftime(l11l1l11l111_tv_ (u"ࠦࠪࡪ࠯ࠦ࡯࠲ࠩ࡞ࡀࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠤᮔ"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫᮕ"):t,l11l1l11l111_tv_ (u"࠭ࡴࡷ࡫ࡧࠫᮖ"):l11l1l11l111_tv_ (u"ࠧࠨᮗ"),l11l1l11l111_tv_ (u"ࠨ࡫ࡰ࡫ࠬᮘ"):l11l1l11l111_tv_ (u"ࠩࠪᮙ"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᮚ"):l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹ࡫࡬ࡦࡹ࡬ࡾ࡯ࡧ࠭࡭࡫ࡹࡩ࠳ࡩ࡯࡮࠱ࠪᮛ"),l11l1l11l111_tv_ (u"ࠬ࡭ࡲࡰࡷࡳࠫᮜ"):l11l1l11l111_tv_ (u"࠭ࠧᮝ"),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࡩࡵ࡭ࠧᮞ"):l11l1l11l111_tv_ (u"ࠨࠩᮟ")})
    return out
def l11lll11l1l11l111_tv_(url=l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷࡩࡱ࡫ࡷࡪࡼ࡭ࡥ࠲ࡲࡩࡷࡧ࠱ࡧࡴࡳ࠯࡯ࡣࡸ࡯ࡴࡽࡥ࠯ࡪࡷࡱࡱ࠭ᮠ")):
    content = l111111l11l111_tv_(url)
    out=[]
    l11lll1l11l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡩ࡬ࡢࡵࡶࡁࠧࡲࡩ࡯࡭ࠥࡂࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࡛࡟࠾ࡠ࠮ࠬᮡ"),re.DOTALL).findall(content)
    group=url.split(l11l1l11l111_tv_ (u"ࠫ࠴࠭ᮢ"))[-1].split(l11l1l11l111_tv_ (u"ࠬ࠴ࠧᮣ"))[0]
    for href,title in l11lll1l11l11l111_tv_:
        t=title.split(l11l1l11l111_tv_ (u"࠭࠯ࠨᮤ"))[-1].split(l11l1l11l111_tv_ (u"ࠧ࠯ࠩᮥ"))[0].strip()
        h=urllib.unquote(l1llll111ll11l111_tv_+href)
        l1llll11lll11l111_tv_=urllib.unquote(l1llll111ll11l111_tv_+title)
        out.append(l1lll1l1l1l11l111_tv_({l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᮦ"):t,l11l1l11l111_tv_ (u"ࠩࡷࡺ࡮ࡪࠧᮧ"):t,l11l1l11l111_tv_ (u"ࠪ࡭ࡲ࡭ࠧᮨ"):l1llll11lll11l111_tv_,l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨᮩ"):h,l11l1l11l111_tv_ (u"ࠬ࡭ࡲࡰࡷࡳ᮪ࠫ"):group,l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࡨࡴ࡬᮫࠭"):l11l1l11l111_tv_ (u"ࠧࠨᮬ"),l11l1l11l111_tv_ (u"ࠨࡥࡲࡨࡪ࠭ᮭ"):group}))
    return out
def l111l1lll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷࡩࡱ࡫ࡷࡪࡼ࡭ࡥ࠲ࡲࡩࡷࡧ࠱ࡧࡴࡳ࠯ࡧ࡫࡯ࡱ࡮ࡱ࠯࠹࠵࠲ࡸࡻࡶ࠱࠮ࡪࡧࠫᮮ")):
    l1lll1ll11l11l111_tv_=[]
    content = l111111l11l111_tv_(url)
    l1ll1l1111l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨࠬ࠳࠰࠿ࠪ࠾࠲࡭࡫ࡸࡡ࡮ࡧࡁࠫᮯ"),re.DOTALL).findall(content)
    if l1ll1l1111l11l111_tv_:
        l1ll1l11l1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ᮰")).findall(l1ll1l1111l11l111_tv_[0])
        if l1ll1l11l1l11l111_tv_:
            data = l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0])
            l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
            l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩ᮱"):l1ll11lll1l11l111_tv_}]
            print l11l1l11l111_tv_ (u"࠭ࠤࠥࠦࠧࠨࠩࠪࠤࠥࠦࠧࠨࠩࠪࠤࠥࠦࠧࠨࠩࠪࠤࠥࠩ᮲"),l1ll11lll1l11l111_tv_
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        print l11l1l11l111_tv_ (u"ࠧ࡝ࡰࠪ᮳"),l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ᮴"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭᮵")))
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ᮶")))
        print l1lll1ll11l11l111_tv_
