# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re,time
import cookielib
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡧ࡭ࡪࡩࡲࡷࡹࡼ࠮ࡦࡷ࠲ࠫ૿")
l1lll1ll1ll11l111_tv_=20
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠷࠹࠲࠵࠴࠲࠺࠴࠷࠲࠽࠽ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧ଀")
__all__=[l11l1l11l111_tv_ (u"ࠪ࡫ࡪࡺࡃࡩࡣࡱࡲࡪࡲࡳࠨଁ"),l11l1l11l111_tv_ (u"ࠫ࡬࡫ࡴࡄࡪࡤࡲࡳ࡫࡬ࡗ࡫ࡧࡩࡴ࠭ଂ")]
fix={
l11l1l11l111_tv_ (u"ࠬࡧࡸ࡯ࠩଃ"):l11l1l11l111_tv_ (u"࠭ࡁ࡙ࡐࠪ଄"),
l11l1l11l111_tv_ (u"ࠧࡣࡤࡦ࡬ࡩ࠭ଅ"):l11l1l11l111_tv_ (u"ࠨࡄࡅࡇࠬଆ"),
l11l1l11l111_tv_ (u"ࠩࡦࡲ࡭ࡪࠧଇ"):l11l1l11l111_tv_ (u"ࠪࡇࡦࡸࡴࡰࡱࡱࠤࡓ࡫ࡴࡸࡱࡵ࡯ࠬଈ"),
l11l1l11l111_tv_ (u"ࠫࡪࡲࡥࡷࡧࡱ࡬ࡩ࠭ଉ"):l11l1l11l111_tv_ (u"ࠬࡋ࡬ࡦࡸࡨࡲࠬଊ"),
l11l1l11l111_tv_ (u"࠭ࡦࡪ࡮ࡰࡦࡴࡾࠧଋ"):l11l1l11l111_tv_ (u"ࠧࡇ࡫࡯ࡱࡧࡵࡸࠨଌ"),
l11l1l11l111_tv_ (u"ࠨࡪࡥࡳ࡭ࡪࠧ଍"):l11l1l11l111_tv_ (u"ࠩࡋࡆࡔ࠭଎"),
l11l1l11l111_tv_ (u"ࠪࡸࡻ࠺ࠧଏ"):l11l1l11l111_tv_ (u"࡙ࠫ࡜ࠠ࠵ࠩଐ"),
l11l1l11l111_tv_ (u"ࠬࡺࡶࡱࡷ࡯ࡷࠬ଑"):l11l1l11l111_tv_ (u"࠭ࡔࡗࠢࡓࡹࡱࡹࠧ଒"),
l11l1l11l111_tv_ (u"ࠧࡵࡸࡱࡷࡹࡿ࡬ࡦࠩଓ"):l11l1l11l111_tv_ (u"ࠨࡖ࡙ࡒ࡙ࠥࡴࡺ࡮ࡨࠫଔ"),
l11l1l11l111_tv_ (u"ࠩࡷࡺࡵ࠷ࡨࡥࠩକ"):l11l1l11l111_tv_ (u"ࠪࡘ࡛ࡖࠠ࠲ࠩଖ"),
l11l1l11l111_tv_ (u"ࠫࡹࡼࡰ࠳ࡪࡧࠫଗ"):l11l1l11l111_tv_ (u"࡚ࠬࡖࡑࠢ࠵ࠫଘ"),
l11l1l11l111_tv_ (u"࠭ࡴࡷࡲ࡬ࡲ࡫ࡵࠧଙ"):l11l1l11l111_tv_ (u"ࠧࡕࡘࡓࠤࡎࡴࡦࡰࠩଚ"),
l11l1l11l111_tv_ (u"ࠨࡥࡩࡥࡲ࡯࡬ࡺࠩଛ"):l11l1l11l111_tv_ (u"ࠩࡆࡳࡲ࡫ࡤࡺࠢࡆࡩࡳࡺࡲࡢ࡮ࠣࡊࡦࡳࡩ࡭ࡻࠪଜ"),
l11l1l11l111_tv_ (u"ࠪࡪ࡮ࡲ࡭ࡣࡱࡻࡴࡷ࡫࡭ࡪࡷࡰࠫଝ"):l11l1l11l111_tv_ (u"ࠫࡋ࡯࡬࡮ࡤࡲࡼࠬଞ"),
l11l1l11l111_tv_ (u"ࠬ࡬࡯ࡹࡪࡧࠫଟ"): l11l1l11l111_tv_ (u"࠭ࡆࡰࡺࠪଠ"),
l11l1l11l111_tv_ (u"ࠧ࡯ࡩࡨࡳࡵ࡫࡯ࡱ࡮ࡨࠫଡ"): l11l1l11l111_tv_ (u"ࠨࡐࡤࡸࠥࡍࡥࡰࠢࡓࡩࡴࡶ࡬ࡦࠩଢ"),
l11l1l11l111_tv_ (u"ࠩࡳࡰࡦࡴࡥࡵࡧࠪଣ"):l11l1l11l111_tv_ (u"ࠪࡔࡱࡧ࡮ࡦࡶࡨࠫତ"),
l11l1l11l111_tv_ (u"ࠫࡵࡵ࡬ࡴࡣࡷࡷࡵࡵࡲࡵࠩଥ"):l11l1l11l111_tv_ (u"ࠬࡖ࡯࡭ࡵࡤࡸࠥࡹࡰࡰࡴࡷࠫଦ"),
l11l1l11l111_tv_ (u"࠭ࡰࡰ࡮ࡶࡥࡹࡹࡰࡰࡴࡷࡲࡪࡽࡳࠨଧ"):l11l1l11l111_tv_ (u"ࠧࡑࡱ࡯ࡷࡦࡺࠠࡴࡲࡲࡶࡹࠦ࡮ࡦࡹࡶࠫନ"),
l11l1l11l111_tv_ (u"ࠨࡵࡸࡴࡪࡸࡳࡵࡣࡦ࡮ࡦ࠭଩"):l11l1l11l111_tv_ (u"ࠩࡖࡹࡵ࡫ࡲࡴࡶࡤࡧ࡯ࡧࠧପ"),
l11l1l11l111_tv_ (u"ࠪࡸࡻࡴࡨࡥࠩଫ"):l11l1l11l111_tv_ (u"࡙ࠫ࡜ࡎࠨବ"),
l11l1l11l111_tv_ (u"ࠬࡺࡶࡱ࠳ࠪଭ"):l11l1l11l111_tv_ (u"࠭ࡔࡗࡒࠣ࠵ࠬମ"),
l11l1l11l111_tv_ (u"ࠧࡵࡸࡳࡴࡴࡲ࡯࡯࡫ࡤࠫଯ"):l11l1l11l111_tv_ (u"ࠨࡖ࡙ࡔࠥࡶ࡯࡭ࡱࡱ࡭ࡦ࠭ର"),
}
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    l1llll11l1l11l111_tv_ = fix.get(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠩࡷࡺ࡮ࡪࠧ଱")),l11l1l11l111_tv_ (u"ࠪࠫଲ"))
    if l1llll11l1l11l111_tv_:
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪଳ")]=l1llll11l1l11l111_tv_
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠬࡺࡶࡪࡦࠪ଴")]=l1llll11l1l11l111_tv_
    return l1l1l1ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},l1llll1111l11l111_tv_=True):
    l1llll1l11l11l111_tv_=l11l1l11l111_tv_ (u"࠭ࠧଵ")
    l1llll1ll1l11l111_tv_=[]
    if l1llll1111l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {l11l1l11l111_tv_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫଶ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_ =  response.read()
        response.close()
    except:
        print l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࡱ࡯ࡢ࠳࠰ࡸࡶࡱࡵࡰࡦࡰࠣࡉࡗࡘࡏࡓࠩଷ")
        l11ll11ll11l111_tv_ = l11l1l11l111_tv_ (u"ࠩࠪସ")
    l1llll1l11l11l111_tv_ = l11l1l11l111_tv_ (u"ࠪࠫହ").join([l11l1l11l111_tv_ (u"ࠫࠪࡹ࠽ࠦࡵ࠾ࠫ଺")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
    return l11ll11ll11l111_tv_,l1llll1l11l11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content,l1llll1l11l11l111_tv_ = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡲ࠭ࡴ࡯࠰࠺ࠥࡩ࡯࡭࠯ࡰࡨ࠲࠹ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࡠࡸ࠰࠼࠰ࡦ࡬ࡺࡃ࠭଻"),re.DOTALL).findall(content)
    for ch in l1lll1lllll11l111_tv_:
        href = re.search(l11l1l11l111_tv_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁ଼ࠬࠦࠬ"),ch)
        l1llll11lll11l111_tv_ = re.search(l11l1l11l111_tv_ (u"ࠧࡥࡣࡷࡥ࠲ࡵࡲࡪࡩ࡬ࡲࡦࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨଽ"),ch)
        if href:
            href = href.group(1)
            title = href.split(l11l1l11l111_tv_ (u"ࠨ࠱ࠪା"))[-1]
            l1llll11lll11l111_tv_ = l1llll111ll11l111_tv_+l1llll11lll11l111_tv_.group(1) if l1llll11lll11l111_tv_ else l11l1l11l111_tv_ (u"ࠩࠪି")
            out.append(l1lll1l1l1l11l111_tv_({l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩୀ"):title.strip(),l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩୁ"):title.strip(),l11l1l11l111_tv_ (u"ࠬ࡯࡭ࡨࠩୂ"):l1llll11lll11l111_tv_,l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪୃ"):l1llll111ll11l111_tv_+href+l11l1l11l111_tv_ (u"ࠧࡽࠧࡶࠫୄ")%l1llll1l11l11l111_tv_,l11l1l11l111_tv_ (u"ࠨࡩࡵࡳࡺࡶࠧ୅"):l11l1l11l111_tv_ (u"ࠩࠪ୆"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࡥࡱࡩࠪେ"):l11l1l11l111_tv_ (u"ࠫࠬୈ")}))
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡿࡥ࡭࡮ࡲࡻࡢ࡛ࡰࡥࡣࡷࡩࡩࡀࠠࠦࡵࠣࠬࡦࡳࡩࡨࡱࡶࡸࡻ࠴ࡥࡶࠫ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ୉") %time.strftime(l11l1l11l111_tv_ (u"ࠨࠥࡥ࠱ࠨࡱ࠴࡙ࠫ࠻ࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦ୊"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ୋ"):t,l11l1l11l111_tv_ (u"ࠨࡶࡹ࡭ࡩ࠭ୌ"):l11l1l11l111_tv_ (u"୍ࠩࠪ"),l11l1l11l111_tv_ (u"ࠪ࡭ࡲ࡭ࠧ୎"):l11l1l11l111_tv_ (u"ࠫࠬ୏"),l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩ୐"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"࠭ࡧࡳࡱࡸࡴࠬ୑"):l11l1l11l111_tv_ (u"ࠧࠨ୒"),l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࡪࡶࡧࠨ୓"):l11l1l11l111_tv_ (u"ࠩࠪ୔")})
    return out
def l111l1lll11l111_tv_(url):
    l1lll1ll11l11l111_tv_=[]
    print l11l1l11l111_tv_ (u"ࠪ࡫ࡪࡺࡃࡩࡣࡱࡲࡪࡲࡖࡪࡦࡨࡳࠬ୕"),url
    if l11l1l11l111_tv_ (u"ࠫࡦࡳࡩࡨࡱࡶࡸࡻ࠭ୖ") in url:
        l1lll1lll1l11l111_tv_,l1llll1l11l11l111_tv_=url.split(l11l1l11l111_tv_ (u"ࠬࢂࠧୗ"))
        header = {l11l1l11l111_tv_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ୘"):l1lll1l1lll11l111_tv_,l11l1l11l111_tv_ (u"ࠧࡉࡱࡶࡸࠬ୙"):l11l1l11l111_tv_ (u"ࠨࡣࡰ࡭࡬ࡵࡳࡵࡸ࠱ࡩࡺ࠭୚"),l11l1l11l111_tv_ (u"ࠩࡆࡳࡳࡴࡥࡤࡶ࡬ࡳࡳ࠭୛"):l11l1l11l111_tv_ (u"ࠪ࡯ࡪ࡫ࡰ࠮ࡣ࡯࡭ࡻ࡫ࠧଡ଼"),l11l1l11l111_tv_ (u"࡚ࠫࡶࡧࡳࡣࡧࡩ࠲ࡏ࡮ࡴࡧࡦࡹࡷ࡫࠭ࡓࡧࡴࡹࡪࡹࡴࡴࠩଢ଼"):l11l1l11l111_tv_ (u"ࠬ࠷ࠧ୞")}
        print l11l1l11l111_tv_ (u"࠭࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡶࡴ࡯ࠫୟ"),l1lll1lll1l11l111_tv_
        print l11l1l11l111_tv_ (u"ࠧࡰࡲࡨࡲ࡮ࡴࡧࠡࡷࡵࡰࠬୠ"),l1lll1lll1l11l111_tv_
        c1,c=l111111l11l111_tv_(l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡣࡰ࡭࡬ࡵࡳࡵࡸ࠱ࡩࡺ࠵ࠧୡ"),l1llll1111l11l111_tv_=True)
        content,c = l111111l11l111_tv_(l1lll1lll1l11l111_tv_,header=header,l1llll1111l11l111_tv_=True)
        src = re.compile(l11l1l11l111_tv_ (u"ࠩࠫ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡲ࡯ࡧࡰࡵࡷࡺ࠳࡫ࡵ࠰࠰࠭ࡃࡡ࠴࡭࠴ࡷ࠻࠭ࠬୢ")).findall(content)
        if src:
            print src
            l1llll1l1ll11l111_tv_=src[0]
            content,C=l111111l11l111_tv_(l1llll1l1ll11l111_tv_,header=header,l1llll1111l11l111_tv_=True)
            l1llll1l1ll11l111_tv_ += l11l1l11l111_tv_ (u"ࠪࢀࡈࡵ࡯࡬࡫ࡨࡁࠪࡹࠦࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠪࡹࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠧࡶࠫୣ")%(c,l1lll1l1lll11l111_tv_,l1lll1lll1l11l111_tv_)
            l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨ୤"):l1llll1l1ll11l111_tv_}]
        else:
            l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠬࡳࡳࡨࠩ୥"):l11l1l11l111_tv_ (u"࠭ࡎࡪࡧࠣࡾࡳࡧ࡬ࡢࡼॅࡩࡲࠦ࡬ࡪࡰ࡮ࡹࠬ୦")}]
    print l1lll1ll11l11l111_tv_
    return l1lll1ll11l11l111_tv_
def test():
    out=l11l11l1l11l111_tv_(addheader=False)
    for o in out:
        print o[l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭୧")]
        print l111l1lll11l111_tv_(o[l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬ୨")])
