# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re
import urlparse
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠶࠲࠱࠴࠳࠸࠶࠷࠳࠱࠵࠵࠸ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧὉ")
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭Ὂ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠪࠫὋ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡲࡦࡣ࡯ࡹ࠷࠺࠮ࡵࡸ࠲ࠫὌ"))
    l1l111l1llll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠬࡂࡨ࠲ࡀࠫ࠲࠰ࡅࠩ࠽࠱࡫࠵ࡃ࠴ࠫࡀ࠾࡫࠶ࡃ࠮࠮ࠬࡁࠬࡀ࠴࡮࠲࠿࠰࠮ࡃࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠰ࡰࡤ࠱ࡿࡿࡷࡰ࠱࡞ࡢࠧࡣࠪࠪࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࡜ࡠࠥࡡ࠰࠯ࠢࠨὍ"),re.DOTALL).findall(content)
    out=[]
    for title,code,href,l1llll11lll11l111_tv_ in l1l111l1llll11l111_tv_:
        l1llll11lll11l111_tv_ = urlparse.urljoin(l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡴࡨࡥࡱࡻ࠲࠵࠰ࡷࡺ࠴࠭὎"),l1llll11lll11l111_tv_)
        href = urlparse.urljoin(l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡵࡩࡦࡲࡵ࠳࠶࠱ࡸࡻ࠵ࠧ὏"),href)
        out.append({l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧὐ"):title.strip(),l11l1l11l111_tv_ (u"ࠩࡷࡺ࡮ࡪࠧὑ"):title.strip(),l11l1l11l111_tv_ (u"ࠪ࡭ࡲ࡭ࠧὒ"):l1llll11lll11l111_tv_,l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨὓ"):href,l11l1l11l111_tv_ (u"ࠬࡩ࡯ࡥࡧࠪὔ"):code,l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࡨࡴ࡬࠭ὕ"):l11l1l11l111_tv_ (u"ࠧࠨὖ")})
    l1l111ll111l11l111_tv_ = re.findall(l11l1l11l111_tv_ (u"ࠨ࠾ࡤࠤࡨࡲࡡࡴࡵࡀࠦࡻ࡯ࡤࡦࡱ࠰ࡸ࡭ࡻ࡭ࡣࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬὗ"),content,re.DOTALL)
    for l1l1l1ll11l111_tv_ in l1l111ll111l11l111_tv_:
        href = re.findall(l11l1l11l111_tv_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ὘"),l1l1l1ll11l111_tv_)
        href = urlparse.urljoin(l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡸࡥࡢ࡮ࡸ࠶࠹࠴ࡴࡷ࠱ࠪὙ"),href[0]) if href else l11l1l11l111_tv_ (u"ࠫࠬ὚")
        l1llll11lll11l111_tv_ = re.findall(l11l1l11l111_tv_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪὛ"),l1l1l1ll11l111_tv_)
        l1llll11lll11l111_tv_ = urlparse.urljoin(l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡴࡨࡥࡱࡻ࠲࠵࠰ࡷࡺ࠴࠭὜"),l1llll11lll11l111_tv_[-1])if l1llll11lll11l111_tv_ else l11l1l11l111_tv_ (u"ࠧࠨὝ")
        title = re.findall(l11l1l11l111_tv_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭὞"),l1l1l1ll11l111_tv_)
        title = title[0].strip() if title else l11l1l11l111_tv_ (u"ࠩࠪὟ")
        code = re.findall(l11l1l11l111_tv_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡴࡨࡰࡪࡧࡳࡦࡦࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࠬὠ"),l1l1l1ll11l111_tv_)
        code = code[0].strip() if code else l11l1l11l111_tv_ (u"ࠫࠬὡ")
        if href and title and l1llll11lll11l111_tv_:
            out.append({l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫὢ"):title.strip(),l11l1l11l111_tv_ (u"࠭ࡴࡷ࡫ࡧࠫὣ"):title.strip(),l11l1l11l111_tv_ (u"ࠧࡪ࡯ࡪࠫὤ"):l1llll11lll11l111_tv_,l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬὥ"):href,l11l1l11l111_tv_ (u"ࠩࡦࡳࡩ࡫ࠧὦ"):code,l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࡥࡱࡩࠪὧ"):l11l1l11l111_tv_ (u"ࠫࠬὨ")})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡿࡥ࡭࡮ࡲࡻࡢ࡛ࡰࡥࡣࡷࡩࡩࡀࠠࠦࡵࠣࠬࡼࡸࡥࡢ࡮ࡸ࠶࠹࠯࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨὩ") %time.strftime(l11l1l11l111_tv_ (u"ࠨࠥࡥ࠱ࠨࡱ࠴࡙ࠫ࠻ࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦὪ"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭Ὣ"):t,l11l1l11l111_tv_ (u"ࠨࡶࡹ࡭ࡩ࠭Ὤ"):l11l1l11l111_tv_ (u"ࠩࠪὭ"),l11l1l11l111_tv_ (u"ࠪ࡭ࡲ࡭ࠧὮ"):l11l1l11l111_tv_ (u"ࠫࠬὯ"),l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩὰ"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"࠭ࡧࡳࡱࡸࡴࠬά"):l11l1l11l111_tv_ (u"ࠧࠨὲ"),l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࡪࡶࡧࠨέ"):l11l1l11l111_tv_ (u"ࠩࠪὴ")})
    return out
def l111l1lll11l111_tv_(url):
    l1lll1ll11l11l111_tv_=[]
    content = l111111l11l111_tv_(url)
    src  = re.compile(l11l1l11l111_tv_ (u"ࠪࡷࡷࡩ࡜ࡴࠬࡀࡠࡸ࠰ࠢࠩࡪࡷࡸࡵ࠴ࠫ࠯࡯࠶ࡹ࠽࠯ࠢࠡࡶࡼࡴࡪࡃࠢࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲࠬή")).findall(content)
    if src:
        l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨὶ"):src[-1]+l11l1l11l111_tv_ (u"ࠬࢂࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠩࡸࠬࡒࡦࡨࡨࡶࡪࡃࠥࡴࠩί")%(l1lll1l1lll11l111_tv_,url),l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬὸ"):l11l1l11l111_tv_ (u"ࠧࡍ࡫ࡱ࡯ࠥ࠭ό")})
    else:
        src  = re.compile(l11l1l11l111_tv_ (u"ࠨࡵࡵࡧࡡࡹࠪ࠾࡞ࡶ࠮ࠧ࠮ࡨࡵࡶࡳ࠲࠰ࡅࠩࠣࠢࡷࡽࡵ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡ࡮ࡤࡦࡪࡲ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨὺ")).findall(content)
        for l11ll11ll11l111_tv_, t,q in src:
            if l11l1l11l111_tv_ (u"ࠤࠪ࠯ࡸࡸࡶࠬࠩࠥύ") in l11ll11ll11l111_tv_: continue
            l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧὼ"):l11ll11ll11l111_tv_+l11l1l11l111_tv_ (u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠨࡷࠫࡘࡥࡧࡧࡵࡩࡂࠫࡳࠨώ")%(l1lll1l1lll11l111_tv_,url),l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ὾"):q})
    return l1lll1ll11l11l111_tv_
