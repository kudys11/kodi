# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡸࡾࡶࡥࡳࡶࡹ࠲ࡨࡵ࡭࠯ࡲ࡯ࠫḨ")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ḩ")
__all__=[l11l1l11l111_tv_ (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭Ḫ"),l11l1l11l111_tv_ (u"ࠩࡪࡩࡹࡉࡨࡢࡰࡱࡩࡱ࡜ࡩࡥࡧࡲࠫḫ")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧḬ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠫࠬḭ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠬࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀ࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃ࠭Ḯ")).findall(content)
    for href,title in l1lll1lllll11l111_tv_:
        out.append({l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬḯ"):title.strip(),l11l1l11l111_tv_ (u"ࠧࡵࡸ࡬ࡨࠬḰ"):title.strip(),l11l1l11l111_tv_ (u"ࠨ࡫ࡰ࡫ࠬḱ"):l11l1l11l111_tv_ (u"ࠩࠪḲ"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧḳ"):href,l11l1l11l111_tv_ (u"ࠫ࡬ࡸ࡯ࡶࡲࠪḴ"):l11l1l11l111_tv_ (u"ࠬ࠭ḵ"),l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࡨࡴ࡬࠭Ḷ"):l11l1l11l111_tv_ (u"ࠧࠨḷ")})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡻࡨࡰࡱࡵࡷ࡞ࡗࡳࡨࡦࡺࡥࡥ࠼ࠣࠩࡸࠦࠨࡱࡵࡤ࠱ࡹࡼࠩ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩḸ") %time.strftime(l11l1l11l111_tv_ (u"ࠤࠨࡨ࠴ࠫ࡭࠰ࠧ࡜࠾ࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢḹ"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩḺ"):t,l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩḻ"):l11l1l11l111_tv_ (u"ࠬ࠭Ḽ"),l11l1l11l111_tv_ (u"࠭ࡩ࡮ࡩࠪḽ"):l11l1l11l111_tv_ (u"ࠧࠨḾ"),l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬḿ"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠩࡪࡶࡴࡻࡰࠨṀ"):l11l1l11l111_tv_ (u"ࠪࠫṁ"),l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫṂ"):l11l1l11l111_tv_ (u"ࠬ࠭ṃ")})
    return out
url=l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡸࡾࡶࡥࡳࡶࡹ࠲ࡨࡵ࡭࠯ࡲ࡯࠳ࡹࡼ࠭࠳ࠩṄ")
def l111l1lll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡹࡿࡰࡦࡴࡷࡺ࠳ࡩ࡯࡮࠰ࡳࡰ࠴ࡺࡶ࡯ࠩṅ")):
    l1lll1ll11l11l111_tv_=[]
    if l11l1l11l111_tv_ (u"ࠨࡶࡼࡴࡪࡸࡴࡷࠩṆ") in url:
        content = l111111l11l111_tv_(url)
        l1ll1l1111l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠫ࠲࠯ࡅࠩ࠽࠱࡬ࡪࡷࡧ࡭ࡦࡀࠪṇ")).findall(content)
        if l1ll1l1111l11l111_tv_:
            src = re.compile(l11l1l11l111_tv_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨṈ"),re.IGNORECASE).findall(l1ll1l1111l11l111_tv_[0])
            if src:
                data = l111111l11l111_tv_(src[0])
                l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src[0],data)
                if l1ll11lll1l11l111_tv_: l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨṉ"):l1ll11lll1l11l111_tv_}]
    return l1lll1ll11l11l111_tv_
