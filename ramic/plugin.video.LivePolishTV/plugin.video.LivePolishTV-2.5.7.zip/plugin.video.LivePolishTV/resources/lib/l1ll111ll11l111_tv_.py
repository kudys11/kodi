# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib,urlparse
import re
import l1ll11ll1ll11l111_tv_
import l1ll1ll111l11l111_tv_,time
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡨࡰࡪࡼࡨࡴ࠰ࡳࡰ࠴࠭ᥨ")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠷࠳࠲࠵࠴࠲࠷࠸࠴࠲࠶࠶࠲ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨᥩ")
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᥪ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠫࠬᥫ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠬࡂ࡬ࡪࠢ࡬ࡨࡂࠨ࡭ࡦࡰࡸ࠱࡮ࡺࡥ࡮࠯࡟ࡨ࠰ࠨࠠࡤ࡮ࡤࡷࡸࡃࠢ࡜ࡠࠥࡡ࠯ࠨ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠻࠱࠲ࡸࡪࡲࡥࡷࡪࡶ࠲ࡵࡲ࠯࠯ࠬࡂ࠳࠮ࠨ࠾ࠩ࠰࠮ࡃ࠮ࡂ࠯ࡢࡀ࠿࠳ࡱ࡯࠾ࠨᥬ")).findall(content)
    for href,title in l1lll1lllll11l111_tv_:
        out.append({l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬᥭ"):title.strip(),l11l1l11l111_tv_ (u"ࠧࡵࡸ࡬ࡨࠬ᥮"):title.strip(),l11l1l11l111_tv_ (u"ࠨ࡫ࡰ࡫ࠬ᥯"):l11l1l11l111_tv_ (u"ࠩࠪᥰ"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᥱ"):href,l11l1l11l111_tv_ (u"ࠫ࡬ࡸ࡯ࡶࡲࠪᥲ"):l11l1l11l111_tv_ (u"ࠬ࠭ᥳ"),l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࡨࡴ࡬࠭ᥴ"):l11l1l11l111_tv_ (u"ࠧࠨ᥵")})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡻࡨࡰࡱࡵࡷ࡞ࡗࡳࡨࡦࡺࡥࡥ࠼ࠣࠩࡸࠦࠨࡵࡧ࡯ࡩࡻ࡮ࡳࠪ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ᥶") %time.strftime(l11l1l11l111_tv_ (u"ࠤࠨࡨ࠴ࠫ࡭࠰ࠧ࡜࠾ࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢ᥷"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ᥸"):t,l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩ᥹"):l11l1l11l111_tv_ (u"ࠬ࠭᥺"),l11l1l11l111_tv_ (u"࠭ࡩ࡮ࡩࠪ᥻"):l11l1l11l111_tv_ (u"ࠧࠨ᥼"),l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬ᥽"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠩࡪࡶࡴࡻࡰࠨ᥾"):l11l1l11l111_tv_ (u"ࠪࠫ᥿"),l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫᦀ"):l11l1l11l111_tv_ (u"ࠬ࠭ᦁ")})
    out = l1ll1ll111l11l111_tv_.l1ll1ll1l1l11l111_tv_(out,local={})
    return out
def l111l1lll11l111_tv_(url):
    l1lll1ll11l11l111_tv_=[]
    content = l111111l11l111_tv_(url)
    l1l1lll11ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡩࡧࡴࡤࡱࡪࡄࠧᦂ"),re.DOTALL).findall(content)
    if l1l1lll11ll11l111_tv_:
        l1ll1l1111l11l111_tv_ = l1l1lll11ll11l111_tv_[0]
        l1ll1l11l1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᦃ"),re.DOTALL|re.IGNORECASE).findall(l1ll1l1111l11l111_tv_)
        if l1ll1l11l1l11l111_tv_:
            l1111l11l1l11l111_tv_ = l1ll1l11l1l11l111_tv_[0]
            if l1111l11l1l11l111_tv_.startswith(l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡬ࡳࡰࡦࡿࡥࡳ࠰ࡨࡱࡧࡸࡡࡵࡱࡵ࡭ࡦ࠴ࡣࡰ࡯࠲ࡃࡸࡃࠧᦄ")):
                suffix = l11l1l11l111_tv_ (u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠨᦅ")+l1lll1l1lll11l111_tv_+l11l1l11l111_tv_ (u"ࠪࠪࡗ࡫ࡦࡦࡴࡨࡶࡂ࠭ᦆ")+l1111l11l1l11l111_tv_
                l1ll11lll1l11l111_tv_ = l1111l11l1l11l111_tv_.replace(l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡶ࡬ࡢࡻࡨࡶ࠳࡫࡭ࡣࡴࡤࡸࡴࡸࡩࡢ࠰ࡦࡳࡲ࠵࠿ࡴ࠿ࠪᦇ"),l11l1l11l111_tv_ (u"ࠬ࠭ᦈ"))
                l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪᦉ"):l1ll11lll1l11l111_tv_+suffix,l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᦊ"):l11l1l11l111_tv_ (u"ࠨࡎ࡬ࡺࡪࠦࠧᦋ")+urlparse.urlparse(l1ll11lll1l11l111_tv_).netloc,l11l1l11l111_tv_ (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫᦌ"):1})
            else:
                l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᦍ"):l11l1l11l111_tv_ (u"ࠫࠬᦎ"),l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫᦏ"):l11l1l11l111_tv_ (u"࠭ࠧᦐ"),l11l1l11l111_tv_ (u"ࠧ࡮ࡵࡪࠫᦑ"):l11l1l11l111_tv_ (u"ࠨࡑࡧࡲࡴॡ࡮ࡪ࡭ࠣࡨࡴࠦࡳࡵࡴࡲࡲࡾࡀࠠ࡜ࡄࡠࡿࢂࡡ࠯ࡃ࡟ࠪᦒ").format(urlparse.urlparse(l1111l11l1l11l111_tv_).netloc)})
    if not l1lll1ll11l11l111_tv_:
        f1   = re.compile(l11l1l11l111_tv_ (u"ࠩࠫࡃ࠿ࡹ࡯ࡶࡴࡦࡩࢁ࡬ࡩ࡭ࡧࠬࡠࡸ࠰࠺࡝ࡵ࠭࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠩࠥࡡࠬᦓ")).findall(content)
        if   f1:  l1ll11lll1l11l111_tv_ = f1[0]
        else:   l1ll11lll1l11l111_tv_=l11l1l11l111_tv_ (u"ࠪࠫᦔ")
        if l1ll11lll1l11l111_tv_:
            suffix = l11l1l11l111_tv_ (u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪᦕ")+l1lll1l1lll11l111_tv_+l11l1l11l111_tv_ (u"ࠬࠬࡒࡦࡨࡨࡶࡪࡸ࠽ࠨᦖ")+url
            l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪᦗ"):l1ll11lll1l11l111_tv_+suffix,l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᦘ"):l11l1l11l111_tv_ (u"ࠨࡎ࡬ࡺࡪࠦࠧᦙ")+urlparse.urlparse(l1ll11lll1l11l111_tv_).netloc,l11l1l11l111_tv_ (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫᦚ"):1})
    if not l1lll1ll11l11l111_tv_: l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᦛ"):l11l1l11l111_tv_ (u"ࠫࠬᦜ"),l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫᦝ"):l11l1l11l111_tv_ (u"࠭ࡎࡪࡥࠪᦞ"),l11l1l11l111_tv_ (u"ࠧ࡮ࡵࡪࠫᦟ"):l11l1l11l111_tv_ (u"ࠨࡐ࡬ࡧࠥࡴࡩࡦࠢࡽࡲࡦࡲࡥࡻ࡫ࡲࡲࡴ࠭ᦠ")})
    return l1lll1ll11l11l111_tv_
def test():
    out=l11l11l1l11l111_tv_(addheader=False)
