# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re
from urlparse import urlparse
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡩ࡯ࡣࡷࡺ࠳ࡶ࡬࠰ࠩ႑")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭႒")
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ႓"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠩࠪ႔")
    return l11ll11ll11l111_tv_
def l11ll1lll1l11l111_tv_(url=l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡪࡩࡺࡦ࡮࡬ࡺࡪ࠴ࡴࡷ࠱ࡵ࠲ࡵ࡮ࡰࡀࡴࡀ࠸࠶࠽࠵࠹࠲ࠩࡨ࡮ࡸࡥࡤࡶࠪ႕")):
    req = urllib2.Request(url,data=None,headers={l11l1l11l111_tv_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ႖"):l1lll1l1lll11l111_tv_,l11l1l11l111_tv_ (u"࡛ࠬࡰࡨࡴࡤࡨࡪ࠳ࡉ࡯ࡵࡨࡧࡺࡸࡥ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡵࠪ႗"):l11l1l11l111_tv_ (u"࠭࠱ࠨ႘")})
    response = urllib2.urlopen(req, timeout=15)
    l11ll111lll11l111_tv_ = response.geturl()
    response.close()
    return l11ll111lll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    l1lll1lll1l11l111_tv_=l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮ࡧࡦࡾࡪࡲࡩࡷࡧ࠱ࡸࡻ࠵࡮ࡢ࠯ࡽࡽࡼࡵ࠯ࠨ႙")
    content = l111111l11l111_tv_(l1lll1lll1l11l111_tv_)
    a= re.findall(l11l1l11l111_tv_ (u"ࠣ࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠫ࠭ࡡ࡞ࠨ࡟࠮࠭ࠬࠦࡣ࡭ࡣࡶࡷࡂ࠭ࡣࡩࡣࡱࡲࡪࡲࠧࠡࡣ࡯ࡸࡂ࠭ࠨ࡜ࡠࠪࡡ࠰࠯ࠧࠡࡶ࡬ࡸࡱ࡫࠽ࠨࠪ࡞ࡢࠬࡣࠫࠪࠩࡁࡠࡸ࠰࠼ࡴࡲࡤࡲ࠭ࡡ࡞࠿࡟࠮࠭ࡃࡂࡢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠪࠬࡠࡤࠧ࡞࠭ࠬࠫࠥࡺࡩࡵ࡮ࡨࡁࠬ࠮࡛࡟ࠩࡠ࠯࠮࠭࠾࠽ࡵࡳࡥࡳࠦࡣ࡭ࡣࡶࡷࡂ࠭ࡤࡢࡶࡤࠫࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠴ࠫࡀ࠾ࡶࡴࡦࡴࠠࡤ࡮ࡤࡷࡸࡃ࡜ࠣ࠰࠮ࡃࡡࠨ࠾ࠩ࠰࠮ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃࠨႚ"),content)
    out=[]
    for t1,l11ll11llll11l111_tv_,l11ll11ll1l11l111_tv_,l11ll1l11ll11l111_tv_,l11ll1l111l11l111_tv_,l11ll1l1lll11l111_tv_,l11ll1l1l1l11l111_tv_,l11ll1ll11l11l111_tv_,code in a:
        title = l11ll1l1l1l11l111_tv_+l11ll11llll11l111_tv_ +l11l1l11l111_tv_ (u"ࠩࠣࡂࠥ࠭ႛ")+l11ll1ll11l11l111_tv_
        l1llll11lll11l111_tv_ = t1
        href = l11ll1l111l11l111_tv_
        code = code
        out.append({l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩႜ"):title,l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩႝ"):title,l11l1l11l111_tv_ (u"ࠬ࡯࡭ࡨࠩ႞"):l11l1l11l111_tv_ (u"࠭ࠧ႟"),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫႠ"):href,l11l1l11l111_tv_ (u"ࠨࡩࡵࡳࡺࡶࠧႡ"):l11ll11llll11l111_tv_,l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩႢ"):l11l1l11l111_tv_ (u"ࠪࠫႣ"),l11l1l11l111_tv_ (u"ࠫࡵࡲ࡯ࡵࠩႤ"):l11l1l11l111_tv_ (u"ࠬ࠭Ⴅ"),l11l1l11l111_tv_ (u"࠭ࡣࡰࡦࡨࠫႦ"):code})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡺࡧ࡯ࡰࡴࡽ࡝ࡖࡲࡧࡥࡹ࡫ࡤ࠻ࠢࠨࡷࠥ࠮࡭ࡦࡥࡽࡩࡱ࡯ࡶࡦࠫ࡞࠳ࡈࡕࡌࡐࡔࡠࠫႧ") %time.strftime(l11l1l11l111_tv_ (u"ࠣࠧࡧ࠳ࠪࡳ࠯࡛ࠦ࠽ࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨႨ"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨႩ"):t,l11l1l11l111_tv_ (u"ࠪࡸࡻ࡯ࡤࠨႪ"):l11l1l11l111_tv_ (u"ࠫࠬႫ"),l11l1l11l111_tv_ (u"ࠬ࡯࡭ࡨࠩႬ"):l11l1l11l111_tv_ (u"࠭ࠧႭ"),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫႮ"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠨࡩࡵࡳࡺࡶࠧႯ"):l11l1l11l111_tv_ (u"ࠩࠪႰ"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࡥࡱࡩࠪႱ"):l11l1l11l111_tv_ (u"ࠫࠬႲ")})
    return out
l11ll11l11l11l111_tv_=[l11l1l11l111_tv_ (u"ࠬࡼ࠲࠯ࡷࡶࡸࡷ࡫ࡡ࡮࡫ࡻ࠲ࡨࡵ࡭ࠨႳ"),l11l1l11l111_tv_ (u"࠭ࡵࡴࡶࡵࡩࡦࡳࡩࡹ࠰ࡦࡳࡲ࠭Ⴔ"),l11l1l11l111_tv_ (u"ࠧࡸ࡫ࡱࡸࡪࡾ࠮࡭࡫ࡰࡥ࠲ࡩࡩࡵࡻ࠱ࡨࡪ࠭Ⴕ"),l11l1l11l111_tv_ (u"ࠨࡵࡷࡥࡹ࡯ࡣ࠯ࡷ࠰ࡴࡷࡵ࠮ࡧࡴࠪႶ"),
    l11l1l11l111_tv_ (u"ࠩ࡯ࡳࡴࡱ࡮ࡪ࡬࠱࡭ࡳ࠭Ⴗ"),l11l1l11l111_tv_ (u"ࠪࡻ࡮ࢀࡪࡢ࠰ࡷࡺࠬႸ"),l11l1l11l111_tv_ (u"ࠫࡼࡽࡷ࠯ࡶࡹࡴ࠳ࡶ࡬ࠨႹ"),l11l1l11l111_tv_ (u"ࠬࡺࡥ࡭ࡧ࠰ࡻ࡮ࢀࡪࡢ࠰࡬ࡷࠬႺ"),l11l1l11l111_tv_ (u"࠭ࡴࡦ࡮ࡨ࠱ࡼ࡯ࡺ࡫ࡣ࠱ࡧࡴࡳࠧႻ"),l11l1l11l111_tv_ (u"ࠧࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣ࠰ࡦࡱࡧࡣ࡬࠰ࡦࡳࡲ࠭Ⴜ"),
    l11l1l11l111_tv_ (u"ࠨࡹࡺࡻ࠳ࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠱ࡧࡴࡳࠧႽ"),l11l1l11l111_tv_ (u"ࠩࡧࡥࡷࡳ࡯ࡸࡣ࠰ࡸࡪࡲࡥࡸ࡫ࡽ࡮ࡦ࠴ࡩ࡯ࡨࡲࠫႾ"),l11l1l11l111_tv_ (u"ࠪࡸࡻ࠳ࡷࡦࡧࡥ࠲ࡨࡵ࡭ࠨႿ"),l11l1l11l111_tv_ (u"ࠫࡩࡧࡲ࡮ࡱࡺࡥ࠲ࡺࡶ࠯ࡲ࡯ࠫჀ"),l11l1l11l111_tv_ (u"ࠬࡺࡥ࡭ࡧࡹ࡬ࡸ࠴ࡰ࡭ࠩჁ")]
def l1llll1ll11l111_tv_(url=l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭ࡦࡥࡽࡩࡱ࡯ࡶࡦ࠰ࡷࡺ࠴ࡴࡡ࠮ࡼࡼࡻࡴ࠵ࡰࡪ࡮࡮ࡥࡤࡴ࡯ࡻࡰࡤ࠳ࡨ࡫ࡲࡳࡣࡧ࠱ࡨࢀࡡࡳࡰ࡬࠱ࡷࡧࡤࡰ࡯࠰ࡸࡷ࡫ࡦ࡭࠯ࡪࡨࡦࡴࡳ࡬࠯ࡳࡰࡺࡹ࡬ࡪࡩࡤ࠱࠼࠶࠶࠶࠹࠱࡬ࡹࡳ࡬ࠨჂ")):
    out=[]
    content = l111111l11l111_tv_(url)
    l11ll1ll1ll11l111_tv_ = re.findall(l11l1l11l111_tv_ (u"ࠢ࠽ࡵࡳࡥࡳࠦࡣ࡭ࡣࡶࡷࡂ࠭࡬ࡪࡰ࡮ࡣࡹ࡯ࡴ࡭ࡧࠪࡂ࠭ࡡ࡞࠿࡟࠮ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠫࡀ࠾ࡤࠤࡷ࡫࡬࠾ࠩࡱࡳ࡫ࡵ࡬࡭ࡱࡺࠫࠥࡺࡡࡳࡩࡨࡸࡂ࠭࡟ࡣ࡮ࡤࡲࡰ࠭ࠠࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨჃ"),content,re.DOTALL)
    for title,l11ll11ll11l111_tv_ in l11ll1ll1ll11l111_tv_:
        out.append({l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧჄ"):title.strip(),l11l1l11l111_tv_ (u"ࠩࡷࡺ࡮ࡪࠧჅ"):title.strip(),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧ჆"):l11ll11ll11l111_tv_.replace(l11l1l11l111_tv_ (u"ࠫࠨࡩࠧჇ"),l11l1l11l111_tv_ (u"ࠬࠬࡤࡪࡴࡨࡧࡹ࠭჈"))})
    return out
def l111l1lll11l111_tv_(item):
    host = item.get(l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ჉"))
    print item
    url = l11ll1lll1l11l111_tv_(item.get(l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫ჊")))
    print url
    l1lll1ll11l11l111_tv_=l11l1l11l111_tv_ (u"ࠨࠩ჋")
    if l11l1l11l111_tv_ (u"ࠩࡶࡸࡦࡺࡩࡤ࠰ࡸ࠱ࡵࡸ࡯࠯ࡨࡵࠫ჌") in host or l11l1l11l111_tv_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠯ࡥࡲࡱࠬჍ") in url:
        data=l11l1l11l111_tv_ (u"ࠫࡸࡸࡣ࠾ࠤࠨࡷࠧ࠭჎")%url
        l1lll1ll11l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
    elif l11l1l11l111_tv_ (u"ࠬࡪࡡࡳ࡯ࡲࡻࡦ࠳ࡴࡷ࠰ࡳࡰࠬ჏") in url:
        from l1llll111l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪა"),l11l1l11l111_tv_ (u"ࠧࠨბ")) if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"ࠨࠩგ")
    elif l11l1l11l111_tv_ (u"ࠩࡷࡩࡱ࡫ࡶࡩࡵ࠱ࡴࡱ࠭დ") in url:
        from l1ll111ll11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧე"),l11l1l11l111_tv_ (u"ࠫࠬვ")) if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"ࠬ࠭ზ")
    if l11l1l11l111_tv_ (u"࠭ࡴࡷ࠯ࡺࡩࡪࡨ࠮ࡤࡱࡰࠫთ") in url:
        from l1llllll1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫი"),l11l1l11l111_tv_ (u"ࠨࠩკ")) if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"ࠩࠪლ")
    elif l11l1l11l111_tv_ (u"ࠪࡻ࡮ࡴࡴࡦࡺ࠱ࡰ࡮ࡳࡡ࠮ࡥ࡬ࡸࡾ࠴ࡤࡦࠩმ") in url:
        from l1l11ll1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨნ"),l11l1l11l111_tv_ (u"ࠬ࠭ო")) if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"࠭ࠧპ")
    elif l11l1l11l111_tv_ (u"ࠧࡶࡵࡷࡶࡪࡧ࡭ࡪࡺࠪჟ") in url:
        l1lll1ll11l11l111_tv_ = l11ll11l1ll11l111_tv_(url)
    elif l11l1l11l111_tv_ (u"ࠨࡶࡨࡰࡪࡽࡩࡻ࡬ࡤ࠱ࡧࡲࡡࡤ࡭ࠪრ") in url:
        from l11l111l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭ს"),l11l1l11l111_tv_ (u"ࠪࠫტ")) if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"ࠫࠬუ")
    elif l11l1l11l111_tv_ (u"ࠬࡲ࡯ࡰ࡭ࡱ࡭࡯࠴ࡩ࡯ࠩფ") in url:
        from l1lll1l1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪქ"),l11l1l11l111_tv_ (u"ࠧࠨღ")) if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"ࠨࠩყ")
    elif l11l1l11l111_tv_ (u"ࠩࡺ࡭ࡿࡰࡡ࠯ࡶࡹࠫშ") in url:
        from l1l1lllll11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧჩ"),l11l1l11l111_tv_ (u"ࠫࠬც"))  if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"ࠬ࠭ძ")
    elif l11l1l11l111_tv_ (u"࠭ࡤࡢࡴࡰࡳࡼࡧ࠭ࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣ࠱࡭ࡳ࡬࡯ࠨწ") in url:
        from l11l11l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫჭ"),l11l1l11l111_tv_ (u"ࠨࠩხ")) if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"ࠩࠪჯ")
    elif l11l1l11l111_tv_ (u"ࠪࡸࡪࡲࡥ࠮ࡹ࡬ࡾ࡯ࡧࠧჰ") in url:
        from l11llll1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨჱ"),l11l1l11l111_tv_ (u"ࠬ࠭ჲ")) if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"࠭ࠧჳ")
    elif l11l1l11l111_tv_ (u"ࠧࡸࡹࡺ࠲ࡹࡼࡰ࠯ࡲ࡯ࠫჴ") in host:
        from l11ll1lll11l111_tv_ import _1l1l11l11l11l111_tv_
        l1lll1ll11l11l111_tv_ = _1l1l11l11l11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬჵ"),l11l1l11l111_tv_ (u"ࠩࠪჶ"))  if l1lll1ll11l11l111_tv_ else l11l1l11l111_tv_ (u"ࠪࠫჷ")
    else:
        l1l11l1l1ll11l111_tv_ (u"ࠫࡊࡒࡓࡆࠩჸ")
        data = l111111l11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
    print(l11l1l11l111_tv_ (u"ࠬࡼࡩࡥࡧࡲࠫჹ"),l1lll1ll11l11l111_tv_)
    return l1lll1ll11l11l111_tv_
