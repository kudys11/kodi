# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re,json
import time
import l1ll11ll1ll11l111_tv_
import cookielib
import urlparse
import threading
import l1ll1ll111l11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡭࡫ࡪࡢ࠰ࡷࡺ࠴࠭น")
l1lll1l1lll11l111_tv_ = l11l1l11l111_tv_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠸࠱࠵ࡀࠦࡲࡷ࠼࠵࠶࠳࠶ࠩࠡࡉࡨࡧࡰࡵ࠯࠳࠲࠴࠴࠵࠷࠰࠲ࠢࡉ࡭ࡷ࡫ࡦࡰࡺ࠲࠶࠷࠴࠰ࠨบ")
l1lll1ll1ll11l111_tv_=15
fix={}
local={}
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    l1llll11l1l11l111_tv_ = fix.get(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"࠭ࡴࡷ࡫ࡧࠫป")),l11l1l11l111_tv_ (u"ࠧࠨผ"))
    if l1llll11l1l11l111_tv_:
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧฝ")]=l1llll11l1l11l111_tv_
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠩࡷࡺ࡮ࡪࠧพ")]=l1llll11l1l11l111_tv_
    return l1l1l1ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},l1llll1111l11l111_tv_=True):
    l1llll1l11l11l111_tv_=l11l1l11l111_tv_ (u"ࠪࠫฟ")
    l1llll1ll1l11l111_tv_=[]
    if l1llll1111l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {l11l1l11l111_tv_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨภ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_ =  response.read()
        response.close()
        l1llll1l11l11l111_tv_ = l11l1l11l111_tv_ (u"ࠬ࠭ม").join([l11l1l11l111_tv_ (u"࠭ࠥࡴ࠿ࠨࡷࡀ࠭ย")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
    except urllib2.HTTPError as e:
        l11ll11ll11l111_tv_ = l11l1l11l111_tv_ (u"ࠧࠨร")
    return l11ll11ll11l111_tv_,l1llll1l11l11l111_tv_
def l1l1lll111l11l111_tv_(url, l1ll111l1ll11l111_tv_, index):
    out = l1l1l1lllll11l111_tv_(url)
    l1ll111l1ll11l111_tv_[index]=out
def l11l11l1l11l111_tv_(addheader=False):
    out=[]
    content,c = l111111l11l111_tv_(l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡪࡨ࡮ࡦ࠴ࡴࡷ࠱ࡤ࡮ࡦࡾ࠯ࡈࡧࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷ࠴࠭ฤ"))
    try:
        content = json.loads(content).get(l11l1l11l111_tv_ (u"ࠩࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫล"),l11l1l11l111_tv_ (u"ࠪࠫฦ"))
    except:
        content,c = l111111l11l111_tv_(l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡭࡫ࡪࡢ࠰ࡷࡺ࠴࠭ว"))
    ids = [(a.start(), a.end()) for a in re.finditer(l11l1l11l111_tv_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡧ࡭ࡧ࡮࡯ࡧ࡯ࠤࡧࡵࡸࠨศ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l1l1lll1lll11l111_tv_ = content[ ids[i][1]:ids[i+1][0] ]
        href  = re.compile(l11l1l11l111_tv_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬษ")).findall(l1l1lll1lll11l111_tv_)
        l1llll11lll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠧ࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪส")).findall(l1l1lll1lll11l111_tv_)
        title = re.compile(l11l1l11l111_tv_ (u"ࠨ࠾࡫࠸ࠥࡩ࡬ࡢࡵࡶࡁࠧࡶ࡯ࡴࡶ࠰ࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪห")).findall(l1l1lll1lll11l111_tv_)
        if re.search(l11l1l11l111_tv_ (u"ࠩ࠿࡭ࠥࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡣࡰࡰ࠰ࡩࡾ࡫࠭ࡰࡲࡨࡲࠧࡄࠧฬ"),l1l1lll1lll11l111_tv_) and href:
            t = title[0]
            i = l1llll11lll11l111_tv_[0] if l1llll11lll11l111_tv_ else l11l1l11l111_tv_ (u"ࠪࠫอ")
            h = href[0]
            out.append(l1lll1l1l1l11l111_tv_({l11l1l11l111_tv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪฮ"):t,l11l1l11l111_tv_ (u"ࠬࡺࡶࡪࡦࠪฯ"):t,l11l1l11l111_tv_ (u"࠭ࡩ࡮ࡩࠪะ"):i,l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫั"):h,l11l1l11l111_tv_ (u"ࠨࡩࡵࡳࡺࡶࠧา"):l11l1l11l111_tv_ (u"ࠩ࡫ࡩࡾࡺࡶࠨำ"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࡥࡱࡩࠪิ"):l11l1l11l111_tv_ (u"ࠫࠬี"),l11l1l11l111_tv_ (u"ࠬࡩ࡯ࡥࡧࠪึ"):l11l1l11l111_tv_ (u"࠭ࠧื")}))
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡺࡧ࡯ࡰࡴࡽ࡝ࡖࡲࡧࡥࡹ࡫ࡤ࠻ࠢࠨࡷࠥ࠮ࡨࡦ࡬ࡤ࠲ࡹࡼࠩ࡜࠱ࡆࡓࡑࡕࡒ࡞ุࠩ") %time.strftime(l11l1l11l111_tv_ (u"ࠣࠧࡧ࠳ࠪࡳ࠯࡛ࠦ࠽ࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨู"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨฺ"):t,l11l1l11l111_tv_ (u"ࠪࡸࡻ࡯ࡤࠨ฻"):l11l1l11l111_tv_ (u"ࠫࠬ฼"),l11l1l11l111_tv_ (u"ࠬ࡯࡭ࡨࠩ฽"):l11l1l11l111_tv_ (u"࠭ࠧ฾"),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫ฿"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠨࡩࡵࡳࡺࡶࠧเ"):l11l1l11l111_tv_ (u"ࠩࠪแ"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࡥࡱࡩࠪโ"):l11l1l11l111_tv_ (u"ࠫࠬใ")})
    return out
url=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡮ࡥ࡫ࡣ࠱ࡸࡻ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࡷ࡫ࡨࡻ࠴ࡺࡶࡱ࠯࠴࠱࠻࠭ไ")
def l111l1lll11l111_tv_(url=l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡨࡦ࡬ࡤ࠲ࡹࡼ࠯ࡤࡪࡤࡲࡳ࡫࡬࠰ࡸ࡬ࡩࡼ࠵ࡴࡷࡰ࠰࠹࠺࠶࠳ࠨๅ")):
    l1lll1ll11l11l111_tv_=[]
    content,c = l111111l11l111_tv_(url)
    header = {l11l1l11l111_tv_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫๆ"):l1lll1l1lll11l111_tv_,l11l1l11l111_tv_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ็"):c}
    l1l1ll11lll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠩࡦ࡬ࡦࡴ࡮ࡦ࡮ࡉࡱࡸ࡛ࡲ࡭࠿ࠫࡶࡹࡳࡰ࡜ࡠࠩࡡ࠯࠯่ࠧ")).findall(content)
    l1l1lll1l1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠪࡧ࡭ࡧ࡮࡯ࡧ࡯ࡍࡩࡃࠨ࡜ࡠࠩࡡ࠯࠯้ࠧ")).findall(content)
    l1l1ll1ll1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡁࡵࡢ࡫ࡧࡦࡸࠥ࠴ࠪࠡࡦࡤࡸࡦࡃࠢࠩࡪࡷࡸࡵࡀ࠯࠰࠰࠭ࡃࡸࡽࡦࠪࠤ๊ࠪ")).findall(content)
    l1l1ll1ll1l11l111_tv_ = l1l1ll1ll1l11l111_tv_[0] if l1l1ll1ll1l11l111_tv_ else l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡮ࡥ࡫ࡣ࠱ࡸࡻ࠵ࡶࡪࡧࡺࡩࡷࡔ࡯ࡄࡪࡤࡸ࠳ࡹࡷࡧ๋ࠩ")
    value=re.compile(l11l1l11l111_tv_ (u"࠭ࡶࡢ࡮ࡸࡩࡂࠨࠨࡳࡶࡰࡴ࡛࡯ࡤࡦࡱ࠱࠮ࡄࠨࠩࠨ์")).findall(content)
    value = value[0] if value else l11l1l11l111_tv_ (u"ࠧࠨํ")
    l1l1ll11l1l11l111_tv_ = re.findall( l11l1l11l111_tv_ (u"ࠨࡸࡤࡶࠥࡵ࡬ࡥࡗࡱ࡭ࡶࡏࡄࠡ࠿ࠣࡠࠬ࠮࠮ࠫࡁࠬࡠࠬࡁࠧ๎"),content)
    l1l1ll1llll11l111_tv_ = re.findall( l11l1l11l111_tv_ (u"ࠩࡸࡶࡱࡀࠠ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࡟࠯ࠥࡶ࡯ࡱࡗࡳ࡙ࡳ࡯ࡱࡊࡆ࠯ࠫ๏"),content)
    l1l1ll1llll11l111_tv_ = l1l1ll1llll11l111_tv_[0] if l1l1ll1llll11l111_tv_ else l11l1l11l111_tv_ (u"ࠪࠫ๐")
    l1l1ll11l1l11l111_tv_ = l1l1ll11l1l11l111_tv_[0] if l1l1ll11l1l11l111_tv_ else l11l1l11l111_tv_ (u"ࠫࠬ๑")
    l1l1l1ll1ll11l111_tv_,c = l111111l11l111_tv_(l1l1ll1llll11l111_tv_+l1l1ll11l1l11l111_tv_,header=header)
    l1l1l1ll1ll11l111_tv_ = json.loads(l1l1l1ll1ll11l111_tv_).get(l11l1l11l111_tv_ (u"ࠬࡻ࡮ࡪࡳࡌࡨࠬ๒"),l11l1l11l111_tv_ (u"࠭ࠧ๓"))
    l1l1ll1l11l11l111_tv_ = re.findall(l11l1l11l111_tv_ (u"ࠧࡶࡰ࡬ࡵࡎࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࠧ๔"),value)
    l1l1ll1l11l11l111_tv_ = l1l1ll1l11l11l111_tv_[0] if l1l1ll1l11l11l111_tv_ else l1l1l1ll1ll11l111_tv_
    value = value.replace(l1l1ll1l11l11l111_tv_,l1l1l1ll1ll11l111_tv_)
    value=value.replace(l11l1l11l111_tv_ (u"ࠨࠨࡤࡱࡵࡁࠧ๕"),l11l1l11l111_tv_ (u"ࠩࠣࠫ๖")).replace(l11l1l11l111_tv_ (u"ࠪࠦࠬ๗"),l11l1l11l111_tv_ (u"ࠫࠬ๘"))
    value = l11l1l11l111_tv_ (u"ࠬࠦࠧ๙").join(value.split(l11l1l11l111_tv_ (u"࠭ࠠࠨ๚"))[3:])
    header.update({l11l1l11l111_tv_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ๛"):l11l1l11l111_tv_ (u"ࠨࡕ࡫ࡳࡨࡱࡷࡢࡸࡨࡊࡱࡧࡳࡩ࠱࠵࠻࠳࠶࠮࠱࠰࠴࠻࠵࠭๜"),
        l11l1l11l111_tv_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ๝"):url,
        })
    if l1l1ll11lll11l111_tv_ and l1l1lll1l1l11l111_tv_:
        src = urllib.unquote(l1l1ll11lll11l111_tv_[0])
        l1l1ll1111l11l111_tv_ = l1l1lll1l1l11l111_tv_[0]
        l1ll11lll1l11l111_tv_ =src+l1l1ll1111l11l111_tv_+l11l1l11l111_tv_ (u"ࠪࠤࡵࡲࡡࡺࡲࡤࡸ࡭ࡃࡳࡵࡴࡨࡥࡲࠦࡳࡸࡨࡘࡶࡱࡃࠧ๞")+l1l1ll1ll1l11l111_tv_ + l11l1l11l111_tv_ (u"ࠫࠥࡶࡡࡨࡧࡘࡶࡱࡃࠧ๟")+url + l11l1l11l111_tv_ (u"ࠬࠦࡵ࡯࡫ࡴࡍࡩࡃࠧ๠")+l1l1l1ll1ll11l111_tv_
        l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪ๡"):l1ll11lll1l11l111_tv_,l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭๢"):l11l1l11l111_tv_ (u"ࠨࠩ๣"),l11l1l11l111_tv_ (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ๤"):1})
    else:
        src=l11l1l11l111_tv_ (u"ࠪࡶࡹࡳࡰ࠻࠱࠲࠼࠼࠴࠱࠳࠲࠱࠷࠻࠴࠳࠴࠱ࡹ࡭ࡩ࡫࡯࠰ࠩ๥")
        l1l1ll1111l11l111_tv_=url.split(l11l1l11l111_tv_ (u"ࠫ࠲࠭๦"))[-1]
        l1ll11lll1l11l111_tv_ =src+l1l1ll1111l11l111_tv_+l11l1l11l111_tv_ (u"ࠬࠦࡰ࡭ࡣࡼࡴࡦࡺࡨ࠾ࡵࡷࡶࡪࡧ࡭ࠡࡵࡺࡪ࡚ࡸ࡬࠾ࠩ๧")+l1l1ll1ll1l11l111_tv_ + l11l1l11l111_tv_ (u"࠭ࠠࡱࡣࡪࡩ࡚ࡸ࡬࠾ࠩ๨")+url + l11l1l11l111_tv_ (u"ࠧࠡࡷࡱ࡭ࡶࡏࡤ࠾ࠩ๩")+l1l1l1ll1ll11l111_tv_
        l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬ๪"):l1ll11lll1l11l111_tv_,l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ๫"):l11l1l11l111_tv_ (u"ࠪࠫ๬"),l11l1l11l111_tv_ (u"ࠫࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭๭"):1})
    print l1lll1ll11l11l111_tv_
    l1lll1ll11l11l111_tv_ = [{l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩ๮"):l11l1l11l111_tv_ (u"࠭ࡲࡵ࡯ࡳ࠾࠴࠵࠸࠸࠰࠴࠶࠵࠴࠳࠷࠰࠶࠷࠴ࡼࡩࡥࡧࡲ࠳࠺࠻࠰࠴ࠢࡳࡰࡦࡿࡰࡢࡶ࡫ࡁࡸࡺࡲࡦࡣࡰࠤࡸࡽࡦࡖࡴ࡯ࡁ࡭ࡺࡴࡱ࠼࠲࠳࡭࡫ࡪࡢ࠰ࡷࡺ࠴ࡼࡩࡦࡹࡨࡶࡓࡵࡃࡩࡣࡷ࠲ࡸࡽࡦࠡࡲࡤ࡫ࡪ࡛ࡲ࡭࠿࡫ࡸࡹࡶ࠺࠰࠱࡫ࡩ࡯ࡧ࠮ࡵࡸ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳ࡻ࡯ࡥࡸ࠱ࡷࡺࡳ࠳࠵࠶࠲࠶ࠤࡺࡴࡩࡲࡋࡧࡁ࠶࠻࠱࠳࠻࠵࠺࠵࠿࠶࠲࠸࠳࠹࠷࠻ࡡ࠳ࡦ࠹ࡦ࠾࠶࠵࠴ࡧࡥ࠻࠽࠹࠴࠺࠻࠻࠶࠾࠽ࠧ๯"),l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭๰"):l11l1l11l111_tv_ (u"ࠨࠩ๱"),l11l1l11l111_tv_ (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ๲"):1}]
    return l1lll1ll11l11l111_tv_
def l1l1ll1l1ll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸࡻ࠴࡯ࡱࡧࡱ࡯ࡦࡺࡡ࡭ࡱࡪ࠲ࡲࡲ࠯ࡰࡩࡲࡰࡳ࡫࠯ࡱࡱ࡯ࡷࡦࡺ࠭ࡰࡰ࡯࡭ࡳ࡫࠯ࠨ๳")):
    l1lll1ll11l11l111_tv_=[]
    content,c = l111111l11l111_tv_(url)
    l1l1lll11ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠭࠴ࠪࡀࠫ࠿࠳࡮࡬ࡲࡢ࡯ࡨࡂࠬ๴"),re.DOTALL).findall(content)
    for l1ll1l1111l11l111_tv_ in l1l1lll11ll11l111_tv_:
        l1ll1l11l1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ๵")).findall(l1ll1l1111l11l111_tv_)
        if l1ll1l11l1l11l111_tv_:
            data,c = l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0])
            l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
            if l1ll11lll1l11l111_tv_:
                l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪ๶"):l1ll11lll1l11l111_tv_,l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭๷"):l11l1l11l111_tv_ (u"ࠨࡎ࡬ࡺࡪࠦࠧ๸")+urlparse.urlparse(l1ll11lll1l11l111_tv_).netloc,l11l1l11l111_tv_ (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ๹"):1})
                break
            else:
                l1ll1l1l11l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠪ࡟ࠧࡢࠧ࡞ࠪ࡫ࡸࡹࡶ࠮ࠫࡁ࡟࠲ࡲ࠹ࡵ࡜࠺ࡠ࠭ࡠࠨ࡜ࠨ࡟ࠪ๺")).findall(data)
                if l1ll1l1l11l11l111_tv_:
                    l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨ๻"):l1ll1l1l11l11l111_tv_[0],l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ๼"):l11l1l11l111_tv_ (u"࠭ࡌࡪࡸࡨࠤ࠭ࡳ࠳ࡶࠫࠪ๽"),l11l1l11l111_tv_ (u"ࠧࡳࡧࡶࡳࡱࡼࡥࡥࠩ๾"):1})
                    break
                else:
                    l1ll1l1111l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠪ࠱࠮ࡄ࠯࠼࠰࡫ࡩࡶࡦࡳࡥ࠿ࠩ๿"),re.DOTALL).findall(data)
                    l1ll1l1111l11l111_tv_ = l1ll1l1111l11l111_tv_[0] if l1ll1l1111l11l111_tv_ else l11l1l11l111_tv_ (u"ࠩࠪ຀")
                    l1ll1l11l1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨກ")).findall(l1ll1l1111l11l111_tv_)
                    if l1ll1l11l1l11l111_tv_:
                        data,c = l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0])
                    l1ll1l1l11l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡠࠨ࡜ࠨ࡟ࠫ࡬ࡹࡺࡰ࠯ࠬࡂࡠ࠳ࡳ࠳ࡶ࡝࠻ࡡ࠮ࡡࠢ࡝ࠩࡠࠫຂ")).findall(data)
                    if l1ll1l1l11l11l111_tv_:
                        l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩ຃"):l1ll1l1l11l11l111_tv_[0],l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬຄ"):l11l1l11l111_tv_ (u"ࠧࡍ࡫ࡹࡩࠥ࠮࡭࠴ࡷࠬࠫ຅"),l11l1l11l111_tv_ (u"ࠨࡴࡨࡷࡴࡲࡶࡦࡦࠪຆ"):1})
                        break
                    else:
                        l1l1l1ll11l11l111_tv_ = [x.strip() for x in re.findall(l11l1l11l111_tv_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡟ࡷ࠯࡮ࡴࡵࡲ࠽࠳࠴ࡺࡥ࡭ࡧ࠰ࡻ࡮ࢀࡪࡢ࠰ࡦࡳࡲ࠵ࡺࡢࡲࡤࡷ࠳࠰࠿ࠪࠤࠪງ"),content)]
                        for l1l1ll111ll11l111_tv_ in l1l1l1ll11l11l111_tv_:
                            print l11l1l11l111_tv_ (u"ࠪࡾࡦࡶࡡࡴࠩຈ")
                            data,c = l111111l11l111_tv_( l1l1ll111ll11l111_tv_ )
                            l1l1lll11ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠭࠴ࠪࡀࠫ࠿࠳࡮࡬ࡲࡢ࡯ࡨࡂࠬຉ"),re.DOTALL).findall(data)
                            for l1ll1l1111l11l111_tv_ in l1l1lll11ll11l111_tv_:
                                l1ll11lll1l11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࠭ຊ")
                                l1ll1l11l1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ຋")).findall(l1ll1l1111l11l111_tv_)
                                if l1ll1l11l1l11l111_tv_:
                                    data,c = l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0])
                                    l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
                                if l1ll11lll1l11l111_tv_:
                                    l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫຌ"):l1ll11lll1l11l111_tv_,l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧຍ"):l11l1l11l111_tv_ (u"ࠩࡏ࡭ࡻ࡫ࠠࠨຎ")+urlparse.urlparse(l1ll11lll1l11l111_tv_).netloc,l11l1l11l111_tv_ (u"ࠪࡶࡪࡹ࡯࡭ࡸࡨࡨࠬຏ"):1})
                                    break
    return l1lll1ll11l11l111_tv_
def l1l1l1lll1l11l111_tv_():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        url=l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨຐ"))
        print l11l1l11l111_tv_ (u"ࠬࡢ࡮ࠨຑ"),l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬຒ"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫຓ")))
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧດ")))
        print l1lll1ll11l11l111_tv_
