# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re,json,time
import cookielib
import l1ll11ll1ll11l111_tv_
import urlparse
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡪࡰࡷࡩࡽ࠴࡬ࡪ࡯ࡤ࠱ࡨ࡯ࡴࡺ࠰ࡧࡩࠬ࿨")
l1lll1ll1ll11l111_tv_=10
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠰࠯࠲࠱࠶࠻࠼࠱࠯࠳࠳࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬ࿩")
__all__=[l11l1l11l111_tv_ (u"ࠧࡨࡧࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ࿪"),l11l1l11l111_tv_ (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰ࡛࡯ࡤࡦࡱࠪ࿫")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭࿬"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠪࠫ࿭")
    return l11ll11ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},l1llll1111l11l111_tv_=True):
    l1llll1l11l11l111_tv_=l11l1l11l111_tv_ (u"ࠫࠬ࿮")
    l1llll1ll1l11l111_tv_=[]
    if l1llll1111l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {l11l1l11l111_tv_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ࿯"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_ =  response.read()
        response.close()
        l1llll1l11l11l111_tv_ = l11l1l11l111_tv_ (u"࠭ࠧ࿰").join([l11l1l11l111_tv_ (u"ࠧࠦࡵࡀࠩࡸࡁࠧ࿱")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
    except urllib2.HTTPError as e:
        l11ll11ll11l111_tv_ = l11l1l11l111_tv_ (u"ࠨࠩ࿲")
    return l11ll11ll11l111_tv_,l1llll1l11l11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content,c = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    l11llll11ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪࡧࡳ࠳࠰࠿ࠪࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭࿳")).findall(content)
    out=[]
    for h,i in l11llll11ll11l111_tv_:
        l1llll11lll11l111_tv_= urlparse.urljoin(l1llll111ll11l111_tv_,i)
        title=h.split(l11l1l11l111_tv_ (u"ࠪ࠳ࠬ࿴"))[-1].split(l11l1l11l111_tv_ (u"ࠫ࠳࠭࿵"))[0]
        href=urlparse.urljoin(l1llll111ll11l111_tv_,h)
        out.append({l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ࿶"):title.strip(),l11l1l11l111_tv_ (u"࠭ࡴࡷ࡫ࡧࠫ࿷"):title.strip(),l11l1l11l111_tv_ (u"ࠧࡪ࡯ࡪࠫ࿸"):l1llll11lll11l111_tv_,l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬ࿹"):href,l11l1l11l111_tv_ (u"ࠩࡪࡶࡴࡻࡰࠨ࿺"):l11l1l11l111_tv_ (u"ࠪࠫ࿻"),l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫ࿼"):l11l1l11l111_tv_ (u"ࠬ࠭࿽")})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡹࡦ࡮࡯ࡳࡼࡣࡕࡱࡦࡤࡸࡪࡪ࠺ࠡࠧࡶࠤ࠭ࡽࡩ࡯ࡶࡨࡼ࠮ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࿾") %time.strftime(l11l1l11l111_tv_ (u"ࠢࠦࡦ࠲ࠩࡲ࠵࡚ࠥ࠼ࠣࠩࡍࡀࠥࡎ࠼ࠨࡗࠧ࿿"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧက"):t,l11l1l11l111_tv_ (u"ࠩࡷࡺ࡮ࡪࠧခ"):l11l1l11l111_tv_ (u"ࠪࠫဂ"),l11l1l11l111_tv_ (u"ࠫ࡮ࡳࡧࠨဃ"):l11l1l11l111_tv_ (u"ࠬ࠭င"),l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪစ"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠧࡨࡴࡲࡹࡵ࠭ဆ"):l11l1l11l111_tv_ (u"ࠨࠩဇ"),l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩဈ"):l11l1l11l111_tv_ (u"ࠪࠫဉ")})
    return out
def l111l1lll11l111_tv_(url):
    l1lll1ll11l11l111_tv_=[]
    content,c = l111111l11l111_tv_(url)
    data = l11llll11ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡸࡵࡵࡳࡥࡨ࠾ࡡࡹࠪ࡜࡞ࠪࠦࡢ࠮࠮ࠫࡁࠬ࡟ࡡ࠭ࠢ࡞ࠩည")).findall(content)
    if data:
        l11llll111l11l111_tv_=data[0]+l11l1l11l111_tv_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࠦࡵ࡙ࠩࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠦࡵࠪဋ")%(url,l1lll1l1lll11l111_tv_)
        l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪဌ"):l11llll111l11l111_tv_}]
    else:
        l1lll1ll11l11l111_tv_=l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠧ࡮ࡵࡪࠫဍ"):l11l1l11l111_tv_ (u"ࠨࡐࡲࡸ࡭࡯࡮ࡨࠢࡩࡳࡺࡴࡤࠨဎ")}]
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        print l11l1l11l111_tv_ (u"ࠩ࡟ࡲࠬဏ"),l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩတ"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨထ")))
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫဒ")))
        print l1lll1ll11l11l111_tv_
