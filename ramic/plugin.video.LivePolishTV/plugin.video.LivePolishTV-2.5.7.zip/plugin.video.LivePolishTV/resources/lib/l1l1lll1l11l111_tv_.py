# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib,urlparse
import re
import l1ll11ll1ll11l111_tv_
import l1ll1ll111l11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡴ࡯ࡸࡹࡤࡸࡨ࡮ࡴࡷ࡮࡬ࡺࡪ࠴࡮ࡦࡶ࠲ࡴࡴࡲࡡ࡯ࡦ࠰ࡸࡻ࠳ࡣࡩࡣࡱࡲࡪࡲࡳ࠮࡮࡬ࡺࡪ࠳ࡳࡵࡴࡨࡥࡲ࠳ࡷࡢࡶࡦ࡬࠲ࡶ࡯࡭࡫ࡶ࡬࠲ࡺࡶ࠮ࡱࡱࡰ࡮ࡴࡥ࠮ࡥ࡫ࡥࡳࡴࡥ࡭࠯ࡩࡶࡪ࡫࠯ࠨᏭ")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠰࠯࠲࠱࠶࠻࠼࠱࠯࠳࠳࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬᏮ")
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᏯ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠨࠩᏰ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀ࡟ࡡ࠭ࠢ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠩࠥࡡࡡࡹࠪࡵ࡫ࡷࡰࡪࡃ࡛࡝ࠩࠥࡡ࠭࠴ࠪࡀࠫ࡞ࡠࠬࠨ࡝࡝ࡵ࠭ࡘࡆࡘࡇࡆࡖࡀࠦࡤࡨ࡬ࡢࡰ࡮ࠦࡃࡢࡳࠫ࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀ࡟ࡡ࠭ࠢ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠩࠥࡡࡡࡹࠪࡴࡶࡼࡰࡪ࠭Ᏹ")).findall(content)
    for href,title,l1llll11lll11l111_tv_ in l1lll1lllll11l111_tv_:
        if len(href)>26:
            out.append({l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩᏲ"):title.strip(),l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩᏳ"):title.strip(),l11l1l11l111_tv_ (u"ࠬ࡯࡭ࡨࠩᏴ"):l1llll11lll11l111_tv_,l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪᏵ"):href,l11l1l11l111_tv_ (u"ࠧࡨࡴࡲࡹࡵ࠭᏶"):l11l1l11l111_tv_ (u"ࠨࠩ᏷"),l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩᏸ"):l11l1l11l111_tv_ (u"ࠪࠫᏹ")})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡾ࡫࡬࡭ࡱࡺࡡ࡚ࡶࡤࡢࡶࡨࡨ࠿ࠦࠥࡴࠢࠫࡲࡴࡽࡷࡢࡶࡦ࡬ࡹࡼ࡬ࡪࡸࡨ࠭ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᏺ") %time.strftime(l11l1l11l111_tv_ (u"ࠧࠫࡤ࠰ࠧࡰ࠳ࠪ࡟࠺ࠡࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥᏻ"))
        out.insert(0,{l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬᏼ"):t,l11l1l11l111_tv_ (u"ࠧࡵࡸ࡬ࡨࠬᏽ"):l11l1l11l111_tv_ (u"ࠨࠩ᏾"),l11l1l11l111_tv_ (u"ࠩ࡬ࡱ࡬࠭᏿"):l11l1l11l111_tv_ (u"ࠪࠫ᐀"),l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨᐁ"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠬ࡭ࡲࡰࡷࡳࠫᐂ"):l11l1l11l111_tv_ (u"࠭ࠧᐃ"),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࡩࡵ࡭ࠧᐄ"):l11l1l11l111_tv_ (u"ࠨࠩᐅ")})
    return l1ll1ll111l11l111_tv_.l1ll1ll1l1l11l111_tv_(out,local={})
def l1llll1ll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡱࡳࡼࡽࡡࡵࡥ࡫ࡸࡻࡲࡩࡷࡧ࠱ࡲࡪࡺ࠯ࡦࡷࡵࡳࡸࡶ࡯ࡳࡶ࠰࡬ࡩ࠳ࡰࡰ࡮ࡤࡲࡩ࠳ࡷࡢࡶࡦ࡬࠲࡫ࡵࡳࡱࡶࡴࡴࡸࡴ࠮ࡲࡲࡰࡦࡴࡤ࠮ࡱࡱࡰ࡮ࡴࡥ࠮ࡧࡸࡶࡴࡹࡰࡰࡴࡷ࠱ࡨ࡮ࡡ࡯ࡰࡨࡰ࠴࠭ᐆ")):
    out=[]
    content = l111111l11l111_tv_(url)
    l1llll11l1ll11l111_tv_ =re.compile(l11l1l11l111_tv_ (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨ࠲࠯ࡹࡲࡤ࠿࡞ࡠࠬࠨ࡝ࠩ࠰࠭࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠲ࡺࡡࡣ࠯ࡩࡶࡦࡳࡥ࠰࠰࠭ࡃ࠮ࡡ࡜ࠨࠤࡠࠫᐇ"),re.IGNORECASE).findall(content)
    for l11ll11ll11l111_tv_ in l1llll11l1ll11l111_tv_:
        l11ll11ll11l111_tv_ = urlparse.urljoin(l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡳࡵࡷࡸࡣࡷࡧ࡭ࡺࡶ࡭࡫ࡹࡩ࠳ࡴࡥࡵ࠱ࠪᐈ"),l11ll11ll11l111_tv_)
        content = l111111l11l111_tv_(l11ll11ll11l111_tv_)
        l11ll1ll1ll11l111_tv_ = re.findall(l11l1l11l111_tv_ (u"ࠬࡂࡡࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡵࡸࡦࠥࡹࡥࡳࡸࡨࡶࠧࠦࡩࡥ࠿ࠥ࠲࠯ࡅࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᐉ"),content)
        for l,t in l11ll1ll1ll11l111_tv_:
            href = urlparse.urljoin(l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡮ࡰࡹࡺࡥࡹࡩࡨࡵࡸ࡯࡭ࡻ࡫࠮࡯ࡧࡷ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠲ࡺࡡࡣ࠯ࡩࡶࡦࡳࡥ࠰ࠩᐊ"),l)
            out.append({l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᐋ"):t,l11l1l11l111_tv_ (u"ࠨࡶࡹ࡭ࡩ࠭ᐌ"):t,l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭ᐍ"):href})
    if not out:
        out.append({l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩᐎ"):l11l1l11l111_tv_ (u"ࠫࡑ࡯࡮࡬ࠢ࠴ࠫᐏ"),l11l1l11l111_tv_ (u"ࠬࡺࡶࡪࡦࠪᐐ"):l11l1l11l111_tv_ (u"࠭ࡌࡪࡰ࡮ࠤ࠶࠭ᐑ"),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫᐒ"):url})
    return out
def l111l1lll11l111_tv_(item):
    host = item.get(l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᐓ"))
    url = item.get(l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭ᐔ"))
    l1lll1ll11l11l111_tv_=l11l1l11l111_tv_ (u"ࠪࠫᐕ")
    content = l111111l11l111_tv_(url)
    l1llll11l11l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰ࡳࡳࡥࡀ࡟ࡡ࠭ࠢ࡞ࠪ࡫ࡸࡹࡶ࠺࠰࠱ࡷࡺࡹࡵࡳࡴ࠰࠭ࡃ࠮ࡡ࡜ࠨࠤࡠࠫᐖ") ,re.IGNORECASE).findall(content)
    if l1llll11l11l11l111_tv_:
        l1lll1ll11l11l111_tv_ = _1llll11llll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡺࡶࡵࡱࡶࡷ࠳ࡴࡥࡵ࠱ࡳࡳࡱࡧ࡮ࡥ࠯ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶ࠳ࡹࡼࡰ࠲࠳࠱࡬ࡹࡳ࡬ࠨᐗ"))
    else:
        src = re.findall(l11l1l11l111_tv_ (u"࠭ࡳࡳࡥ࡟ࡷ࠯ࡃ࡜ࡴࠬ࡞ࡠࠬࠨ࡝ࠩࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡨࡹࡦࡶࡹ࠲ࡴࡸࡧ࠰࠰࠭ࡃ࠮ࡡ࡜ࠨࠤࡠࠫᐘ"),content,re.I)
        if src:
            l1lll1ll11l11l111_tv_ =_1llllllllll11l111_tv_(src[0])
        else:
            l1llll11l11l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥ࠯ࠬࡶࡶࡨࡃ࡛࡝ࠩࠥࡡ࠭࡮ࡴࡵࡲ࠽࠲࠯ࡅࠩ࡜࡞ࠪࠦࡢ࠭ᐙ") ,re.IGNORECASE).findall(content)
            print l1llll11l11l11l111_tv_
    return l1lll1ll11l11l111_tv_
def _1llll11llll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡹࡸࡴࡹࡳ࠯ࡰࡨࡸ࠴ࡶ࡯࡭ࡣࡱࡨ࠲ࡩࡨࡢࡰࡱࡩࡱࡹ࠯ࡵࡸࡳ࠵࠶࠴ࡨࡵ࡯࡯ࠫᐚ")):
    l1llll1l111l11l111_tv_ = l111111l11l111_tv_(url)
    l1ll11lll1l11l111_tv_=l11l1l11l111_tv_ (u"ࠩࠪᐛ")
    src = re.findall(l11l1l11l111_tv_ (u"ࠪࡷࡷࡩ࡜ࡴࠬࡀࡠࡸ࠰࡛࡝ࠩࠥࡡ࠭࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡥࡽࡪࡺࡶ࠯ࡱࡵ࡫࠴࠴ࠪࡀࠫ࡞ࡠࠬࠨ࡝ࠨᐜ"),l1llll1l111l11l111_tv_,re.I)
    if src: l1ll11lll1l11l111_tv_ = _1llllllllll11l111_tv_(src[0])
    return l1ll11lll1l11l111_tv_
def _1llllllllll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡼࡩࡹࡼ࠮ࡰࡴࡪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰ࠳ࡶࡨࡱࡁࡩ࡭ࡱ࡫࠽࠸࠳ࠩࡻ࡮ࡪࡴࡩ࠿࠺࠹࠵ࠬࡨࡦ࡫ࡪ࡬ࡹࡃ࠴࠹࠲ࠩࡥࡺࡺ࡯ࡴࡶࡤࡶࡹࡃࡴࡳࡷࡨࠫᐝ")):
    l1ll11lll1l11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࠭ᐞ")
    data = l111111l11l111_tv_(url)
    l111l11l1ll11l111_tv_ = re.findall(l11l1l11l111_tv_ (u"࡛࠭࡝ࠩࠥࡡ࠭࡮ࡴࡵࡲ࠽࠳࠴࠴ࠪࡦ࡯ࡥࡩࡩ࠴ࡰࡩࡲ࠱࠮ࡄ࠯࡛࡝ࠩࠥࡡࠬᐟ"),data,re.I)
    l111l11l1ll11l111_tv_ = l111l11l1ll11l111_tv_[0] if l111l11l1ll11l111_tv_ else l11l1l11l111_tv_ (u"ࠧࠨᐠ")
    l1lllll1ll1l11l111_tv_ = l111111l11l111_tv_(l111l11l1ll11l111_tv_)
    if l1lllll1ll1l11l111_tv_:
        name            = re.findall(l11l1l11l111_tv_ (u"ࠨࡸࡤࡶࡡࡹࠫ࡯ࡣࡰࡩࡡࡹࠪ࠾࡞ࡶ࠮ࡠࡢࠧࠣ࡟ࠫ࠲࠯ࡅࠩ࡜࡞ࠪࠦࡢ࠭ᐡ"),l1lllll1ll1l11l111_tv_)[0]
        l11l1ll11ll11l111_tv_    = re.findall(l11l1l11l111_tv_ (u"ࠩࡹࡥࡷࡢࡳࠬࡧࡧ࡫ࡪࡹࡥࡳࡸࡨࡶ࡮ࡶ࡜ࡴࠬࡀࡠࡸ࠰࡛࡝ࠩࠥࡡ࠭࠴ࠪࡀࠫ࡞ࡠࠬࠨ࡝ࠨᐢ"),l1lllll1ll1l11l111_tv_)[0]
        l11l111l11l11l111_tv_         = re.findall(l11l1l11l111_tv_ (u"ࠪࡺࡦࡸ࡜ࡴ࠭ࡤࡴࡵࡔࡡ࡮ࡧ࡟ࡷ࠯ࡃ࡜ࡴࠬ࡞ࡠࠬࠨ࡝ࠩ࠰࠭ࡃ࠮ࡡ࡜ࠨࠤࡠࠫᐣ"),l1lllll1ll1l11l111_tv_)[0]
        width         = re.findall(l11l1l11l111_tv_ (u"ࠫࡻࡧࡲ࡝ࡵ࠮ࡻ࡮ࡪࡴࡩ࡞ࡶ࠮ࡂࡢࡳࠫ࡝࡟ࠫࠧࡣࠨ࠯ࠬࡂ࠭ࡠࡢࠧࠣ࡟ࠪᐤ"),l1lllll1ll1l11l111_tv_)[0]
        l111l11ll1l11l111_tv_         = re.findall(l11l1l11l111_tv_ (u"ࠬࡼࡡࡳ࡞ࡶ࠯࡭࡫ࡩࡨࡪࡷࡠࡸ࠰࠽࡝ࡵ࠭࡟ࡡ࠭ࠢ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠩࠥࡡࠬᐥ"),l1lllll1ll1l11l111_tv_)[0]
        l1llll11ll1l11l111_tv_ = re.findall(l11l1l11l111_tv_ (u"࠭ࡶࡢࡴ࡟ࡷ࠰࡮࡬ࡴࡗࡕࡐࡡࡹࠪ࠾࡞ࡶ࠮࠳࠰ࠨࡵࡱ࡮ࡩࡳࡃ࠮ࠫࡁࠬ࡟ࡡ࠭ࠢ࡞ࠩᐦ"),l1lllll1ll1l11l111_tv_)[0]
        l1ll11lll1l11l111_tv_ = l11l1l11l111_tv_ (u"ࠢࡩࡶࡷࡴ࠿࠵࠯ࠣᐧ")+l11l1ll11ll11l111_tv_+l11l1l11l111_tv_ (u"ࠣ࠱ࠥᐨ")+l11l111l11l11l111_tv_+l11l1l11l111_tv_ (u"ࠤ࠲ࠦᐩ")+name+l11l1l11l111_tv_ (u"ࠥ࠲ࡲ࠹ࡵ࠹ࡁࠥᐪ")+l1llll11ll1l11l111_tv_
        l1ll11lll1l11l111_tv_+=l11l1l11l111_tv_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࡻࡾࠨࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࡻࡾࠩᐫ").format(l111l11l1ll11l111_tv_,urllib.quote(l1lll1l1lll11l111_tv_))
    return l1ll11lll1l11l111_tv_
def test():
    out=l11l11l1l11l111_tv_()
    l1l1l1ll11l111_tv_=out[17]
    items=l1llll1ll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩᐬ")))
    item=items[0]
    l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_( items[0] )
    len(l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡮ࡰࡹࡺࡥࡹࡩࡨࡵࡸ࡯࡭ࡻ࡫࠮ࡤࡱ࠲ࠫᐭ"))
