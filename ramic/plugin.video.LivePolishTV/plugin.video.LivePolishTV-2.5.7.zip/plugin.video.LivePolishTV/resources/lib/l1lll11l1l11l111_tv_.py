# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import sys,re,os,json,time
from copy import deepcopy
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
def l1ll1l1l11l111_tv_(hour,l1lll111l11l11l111_tv_):
    try:
        from cron import CronManager,CronJob
        l1ll1llll1ll11l111_tv_ = CronManager()
        l1lll1111lll11l111_tv_ = l1ll1llll1ll11l111_tv_.getJobs()
        for job in l1lll1111lll11l111_tv_:
            print job.name
            if l11l1l11l111_tv_ (u"ࠫࡑ࡯ࡶࡦࡒࡲࡰ࡮ࡹࡨࡕࡘࠪᖂ") in job.name:
                l1ll1llll1ll11l111_tv_.deleteJob(job.id)
    except:
        xbmcgui.Dialog().ok(l11l1l11l111_tv_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡸࡥࡥ࡟ࡓࡶࡴࡨ࡬ࡦ࡯࡞࠳ࡈࡕࡌࡐࡔࡠࠤࠬᖃ"),l11l1l11l111_tv_ (u"࠭ࡗࡵࡻࡦࡾࡰࡧࠠ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࡹࡥࡳࡸ࡬ࡧࡪ࠴ࡣࡳࡱࡱࡼࡧࡳࡣ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࡱ࡭ࡪࠦࡪࡦࡵࡷࠤࡿࡧࡩ࡯ࡵࡷࡥࡱࡵࡷࡢࡰࡤࠫᖄ"), l11l1l11l111_tv_ (u"ࠧࡇࡷࡱ࡯ࡨࡰࡡࠡࡣࡸࡸࡴࡳࡡࡵࡻࡦࡾࡳ࡫ࡪࠡࡣ࡮ࡸࡺࡧ࡬ࡪࡼࡤࡧ࡯࡯ࠠ࡯࡫ࡨࠤࡧटࡤࡻ࡫ࡨࠤࡩࢀࡩࡢॄࡤऋ࠳࠭ᖅ"))
        return False
    if l1lll111l11l11l111_tv_==l11l1l11l111_tv_ (u"ࠨࡶࡵࡹࡪ࠭ᖆ"):
        job = CronJob()
        job.name = l11l1l11l111_tv_ (u"ࠤࡏ࡭ࡻ࡫ࡐࡰ࡮࡬ࡷ࡭࡚ࡖࠣᖇ")
        job.command = l11l1l11l111_tv_ (u"ࠪࡖࡺࡴࡐ࡭ࡷࡪ࡭ࡳ࠮ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡍ࡫ࡹࡩࡕࡵ࡬ࡪࡵ࡫ࡘ࡛ࡅ࡭ࡰࡦࡨࡁࡆ࡛ࡔࡐ࡯࠶ࡹ࠮࠭ᖈ")
        job.expression = l11l1l11l111_tv_ (u"ࠦ࠵ࠦࠥࡴࠢ࠭ࠤ࠯ࠦࠪࠣᖉ")%(hour)
        job.show_notification = l11l1l11l111_tv_ (u"ࠧࡺࡲࡶࡧࠥᖊ")
        l1ll1llll1ll11l111_tv_.addJob(job)
        xbmcgui.Dialog().ok(l11l1l11l111_tv_ (u"࠭ࡣࡳࡱࡱࡼࡧࡳࡣࠨᖋ"),l11l1l11l111_tv_ (u"ࠧࡂࡷࡷࡳࡲࡧࡴࡺࡥࡽࡲࡦࠦࡡ࡬ࡶࡸࡥࡱ࡯ࡺࡢࡥ࡭࡭ࠥࡰࡥࡴࡶࠣ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞ࡃࡎࡘ࡞࡝ࡎࡂ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᖌ"),l11l1l11l111_tv_ (u"ࠨࡎ࡬ࡷࡹࡧࠠ࡮࠵ࡸࠤࡧटࡤࡻ࡫ࡨࠤࡴࡪज़ࡸ࡫ࡨঀࡦࡴࡡࠡࡥࡲࡨࡿ࡯ࡥ࡯ࡰ࡬ࡩࠥࡵࠠࡨࡱࡧࡾ࡮ࡴࡩࡦࠢࠨࡷ࠿࠶࠰ࠨᖍ")%hour)
    else:
        xbmcgui.Dialog().ok(l11l1l11l111_tv_ (u"ࠩࡦࡶࡴࡴࡸࡣ࡯ࡦࠫᖎ"),l11l1l11l111_tv_ (u"ࠪࡅࡺࡺ࡯࡮ࡣࡷࡽࡨࢀ࡮ࡢࠢࡤ࡯ࡹࡻࡡ࡭࡫ࡽࡥࡨࡰࡩࠡ࡬ࡨࡷࡹ࡛ࠦࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠ࡛࡞ेऄࡄ࡜ࡒࡒࡆࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᖏ"))
    return True
def l1ll1lll111l11l111_tv_(l1ll1lll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠫࡵࡼࡲ࠯࡫ࡳࡸࡻࡹࡩ࡮ࡲ࡯ࡩࠬᖐ"),l1lll1l11l111_tv_={l11l1l11l111_tv_ (u"ࠬࡳ࠳ࡶࡒࡤࡸ࡭࠭ᖑ"): l11l1l11l111_tv_ (u"࠭ࡤࡶࡲࡤࠫᖒ")}):
    xbmc.executeJSONRPC(l11l1l11l111_tv_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡁࡥࡦࡲࡲࡸ࠴ࡓࡦࡶࡄࡨࡩࡵ࡮ࡆࡰࡤࡦࡱ࡫ࡤࠣ࠮ࠥ࡭ࡩࠨ࠺࠲࠮ࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡡࡥࡦࡲࡲ࡮ࡪࠢ࠻ࠤࠨࡷࠧ࠲ࠠࠣࡧࡱࡥࡧࡲࡥࡥࠤ࠽ࡸࡷࡻࡥࡾࡿࠪᖓ")%l1ll1lll11ll11l111_tv_ )
    xbmc.sleep(500)
    l1ll1ll1l1ll11l111_tv_=1
    msg=l11l1l11l111_tv_ (u"ࠨࠩᖔ")
    try:
        l1ll1ll1l11l11l111_tv_ = xbmcaddon.Addon(l1ll1lll11ll11l111_tv_)
        l1ll1ll1l11l11l111_tv_.setSetting(l11l1l11l111_tv_ (u"ࠩࡰ࠷ࡺࡖࡡࡵࡪࠪᖕ"),str(l1lll1l11l111_tv_.get(l11l1l11l111_tv_ (u"ࠪࡱ࠸ࡻࡐࡢࡶ࡫ࠫᖖ"),l11l1l11l111_tv_ (u"ࠫࠬᖗ"))))
        msg=l11l1l11l111_tv_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࡭ࡲࡦࡧࡱࡡࡔࡑ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠡࡗࡵࡹࡨ࡮࡯࡮ࠢࡳࡳࡳࡵࡷ࡯࡫ࡨࠤࡐࡵࡤࡪࠢ࡭ࡩॠࡲࡩࠡ࡮࡬ࡷࡹࡧࠠ࡬ࡣࡱࡥेࣹࡷࠡࡒ࡙ࡖࠥࡹࡩचࠢࡱ࡭ࡪࠦࡵࡢ࡭ࡷࡹࡦࡲ࡮ࡪॄࡤࠫᖘ")
    except:
        msg=l11l1l11l111_tv_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠࡉࡗࡘࡏࡓ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࡒ࡮࡫ࡵࡥࡣࡱࡥࠥࡧ࡫ࡵࡷࡤࡰ࡮ࢀࡡࡤ࡬ࡤࠤࡺࡹࡴࡢࡹ࡬ࡩॉࠦࡐࡗࡔࠪᖙ")
    l1ll1ll1l11l11l111_tv_ = xbmcaddon.Addon(l1ll1lll11ll11l111_tv_)
    l1ll1ll1ll1l11l111_tv_ = xbmc.translatePath(l1ll1ll1l11l11l111_tv_.getAddonInfo(l11l1l11l111_tv_ (u"ࠧࡱࡴࡲࡪ࡮ࡲࡥࠨᖚ"))).decode(l11l1l11l111_tv_ (u"ࠨࡷࡷࡪ࠲࠾ࠧᖛ"))
    l111l11111l11l111_tv_=l11l1l11l111_tv_ (u"ࠩࠪࠫࠒࠐ࠼ࡴࡧࡷࡸ࡮ࡴࡧࡴࡀࠐࠎࠥࠦࠠࠡ࠾ࡶࡩࡹࡺࡩ࡯ࡩࠣ࡭ࡩࡃࠢࡦࡲࡪࡇࡦࡩࡨࡦࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࡸࡷࡻࡥࠣࠢ࠲ࡂࠒࠐࠠࠡࠢࠣࡀࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯ࡤ࠾ࠤࡨࡴ࡬ࡖࡡࡵࡪࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࠧࠦ࠯࠿ࠏࠍࠤࠥࠦࠠ࠽ࡵࡨࡸࡹ࡯࡮ࡨࠢ࡬ࡨࡂࠨࡥࡱࡩࡓࡥࡹ࡮ࡔࡺࡲࡨࠦࠥࡼࡡ࡭ࡷࡨࡁࠧࢁࡥࡱࡩࡓࡥࡹ࡮ࡔࡺࡲࡨࢁࠧࠦ࠯࠿ࠏࠍࠤࠥࠦࠠ࠽ࡵࡨࡸࡹ࡯࡮ࡨࠢ࡬ࡨࡂࠨࡥࡱࡩࡗࡗࡔࡼࡥࡳࡴ࡬ࡨࡪࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࡵࡴࡸࡩࠧࠦ࠯࠿ࠏࠍࠤࠥࠦࠠ࠽ࡵࡨࡸࡹ࡯࡮ࡨࠢ࡬ࡨࡂࠨࡥࡱࡩࡗ࡭ࡲ࡫ࡓࡩ࡫ࡩࡸࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࡻࡦࡲࡪࡘ࡮ࡳࡥࡔࡪ࡬ࡪࡹࢃࠢࠡ࠱ࡁࠑࠏࠦࠠࠡࠢ࠿ࡷࡪࡺࡴࡪࡰࡪࠤ࡮ࡪ࠽ࠣࡧࡳ࡫࡚ࡸ࡬ࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࡾࡩࡵ࡭ࡕࡳ࡮ࢀࠦࠥ࠵࠾ࠎࠌࠣࠤࠥࠦ࠼ࡴࡧࡷࡸ࡮ࡴࡧࠡ࡫ࡧࡁࠧࡲ࡯ࡨࡱࡅࡥࡸ࡫ࡕࡳ࡮ࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࠧࠦ࠯࠿ࠏࠍࠤࠥࠦࠠ࠽ࡵࡨࡸࡹ࡯࡮ࡨࠢ࡬ࡨࡂࠨ࡬ࡰࡩࡲࡊࡷࡵ࡭ࡆࡲࡪࠦࠥࡼࡡ࡭ࡷࡨࡁࠧࢁ࡬ࡰࡩࡲࡊࡷࡵ࡭ࡆࡲࡪࢁࠧࠦ࠯࠿ࠏࠍࠤࠥࠦࠠ࠽ࡵࡨࡸࡹ࡯࡮ࡨࠢ࡬ࡨࡂࠨ࡬ࡰࡩࡲࡔࡦࡺࡨࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࠥࠤ࠴ࡄࠍࠋࠢࠣࠤࠥࡂࡳࡦࡶࡷ࡭ࡳ࡭ࠠࡪࡦࡀࠦࡱࡵࡧࡰࡒࡤࡸ࡭࡚ࡹࡱࡧࠥࠤࡻࡧ࡬ࡶࡧࡀࠦ࠶ࠨࠠ࠰ࡀࠐࠎࠥࠦࠠࠡ࠾ࡶࡩࡹࡺࡩ࡯ࡩࠣ࡭ࡩࡃࠢ࡮࠵ࡸࡇࡦࡩࡨࡦࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࡸࡷࡻࡥࠣࠢ࠲ࡂࠒࠐࠠࠡࠢࠣࡀࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥ࡯ࡤ࠾ࠤࡰ࠷ࡺࡖࡡࡵࡪࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࢀࡳ࠳ࡶࡒࡤࡸ࡭ࢃࠢࠡ࠱ࡁࠑࠏࠦࠠࠡࠢ࠿ࡷࡪࡺࡴࡪࡰࡪࠤ࡮ࡪ࠽ࠣ࡯࠶ࡹࡕࡧࡴࡩࡖࡼࡴࡪࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࡼ࡯࠶ࡹࡕࡧࡴࡩࡖࡼࡴࡪࢃࠢࠡ࠱ࡁࠑࠏࠦࠠࠡࠢ࠿ࡷࡪࡺࡴࡪࡰࡪࠤ࡮ࡪ࠽ࠣ࡯࠶ࡹ࡚ࡸ࡬ࠣࠢࡹࡥࡱࡻࡥ࠾ࠤࠥࠤ࠴ࡄࠍࠋࠢࠣࠤࠥࡂࡳࡦࡶࡷ࡭ࡳ࡭ࠠࡪࡦࡀࠦࡸ࡫ࡰ࠲ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࠦࠥ࠵࠾ࠎࠌࠣࠤࠥࠦ࠼ࡴࡧࡷࡸ࡮ࡴࡧࠡ࡫ࡧࡁࠧࡹࡥࡱ࠴ࠥࠤࡻࡧ࡬ࡶࡧࡀࠦࠧࠦ࠯࠿ࠏࠍࠤࠥࠦࠠ࠽ࡵࡨࡸࡹ࡯࡮ࡨࠢ࡬ࡨࡂࠨࡳࡦࡲ࠶ࠦࠥࡼࡡ࡭ࡷࡨࡁࠧࠨࠠ࠰ࡀࠐࠎࠥࠦࠠࠡ࠾ࡶࡩࡹࡺࡩ࡯ࡩࠣ࡭ࡩࡃࠢࡴࡶࡤࡶࡹࡔࡵ࡮ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥ࠵ࠧࠦ࠯࠿ࠏࠍࡀ࠴ࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠾ࠨࠩࠪᖜ")
    l111l11111l11l111_tv_ = l111l11111l11l111_tv_.format(**l1lll1l11l111_tv_)
    print(l11l1l11l111_tv_ (u"ࠪࡥࡩࡪ࡯࡯ࡡࡨࡲࡦࡨ࡬ࡦࡡࡤࡲࡩࡥࡳࡦࡶࠪᖝ"),l11l1l11l111_tv_ (u"ࠫࡵࡸ࡯ࡧ࡫࡯ࡩࡕࡧࡴࡩࠩᖞ"))
    print l1ll1ll1ll1l11l111_tv_
    print l1lll1l11l111_tv_
    print l111l11111l11l111_tv_
    try:
        if not os.path.exists(l1ll1ll1ll1l11l111_tv_):
            os.makedirs(l1ll1ll1ll1l11l111_tv_)
    except:
        pass
    with open(os.path.join(l1ll1ll1ll1l11l111_tv_,l11l1l11l111_tv_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫᖟ")),l11l1l11l111_tv_ (u"࠭ࡷࠨᖠ")) as l1l111ll1ll11l111_tv_:
        print(l11l1l11l111_tv_ (u"ࠧࡢࡦࡧࡳࡳࡥࡥ࡯ࡣࡥࡰࡪࡥࡡ࡯ࡦࡢࡷࡪࡺࠧᖡ"),l11l1l11l111_tv_ (u"ࠨࡹࡵ࡭ࡹ࡯࡮ࡨࠢࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨᖢ"))
        l1l111ll1ll11l111_tv_.write(l111l11111l11l111_tv_)
    return msg
def l1ll1lll11l111_tv_(fname,path,l1l1l1l1l11l111_tv_,l111111ll11l111_tv_):
    l1ll1llll11l11l111_tv_ = os.path.join(path,fname)
    if os.path.exists(l1ll1llll11l11l111_tv_):
        xbmc.executebuiltin(l11l1l11l111_tv_ (u"ࠩࡖࡸࡴࡶࡐࡗࡔࡐࡥࡳࡧࡧࡦࡴࠪᖣ"))
        xbmc.executebuiltin(l11l1l11l111_tv_ (u"ࠪࡔ࡛ࡘ࠮ࡔࡶࡲࡴࡒࡧ࡮ࡢࡩࡨࡶࠬᖤ"))
        l1lll1111l1l11l111_tv_={l11l1l11l111_tv_ (u"ࠫࡲ࠹ࡵࡑࡣࡷ࡬ࠬᖥ"): l1ll1llll11l11l111_tv_,l11l1l11l111_tv_ (u"ࠬࡳ࠳ࡶࡒࡤࡸ࡭࡚ࡹࡱࡧࠪᖦ"):l11l1l11l111_tv_ (u"࠭࠰ࠨᖧ"),l11l1l11l111_tv_ (u"ࠧࡦࡲࡪ࡙ࡷࡲࠧᖨ"):l111111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠨࡧࡳ࡫࡙࡯࡭ࡦࡕ࡫࡭࡫ࡺࠧᖩ"):l1l1l1l1l11l111_tv_,l11l1l11l111_tv_ (u"ࠩࡨࡴ࡬ࡖࡡࡵࡪࡗࡽࡵ࡫ࠧᖪ"):l11l1l11l111_tv_ (u"ࠪ࠵ࠬᖫ"),l11l1l11l111_tv_ (u"ࠫࡱࡵࡧࡰࡈࡵࡳࡲࡋࡰࡨࠩᖬ"):l11l1l11l111_tv_ (u"ࠬ࠸ࠧᖭ")}
        msg=l1ll1lll111l11l111_tv_(l1ll1lll11ll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࡰࡷࡴ࠱࡭ࡵࡺࡶࡴ࡫ࡰࡴࡱ࡫ࠧᖮ"),l1lll1l11l111_tv_=l1lll1111l1l11l111_tv_)
        xbmcgui.Dialog().notification(l11l1l11l111_tv_ (u"ࠧࠨᖯ"), msg, xbmcgui.NOTIFICATION_INFO, 1000)
        version = int(xbmc.getInfoLabel(l11l1l11l111_tv_ (u"ࠣࡕࡼࡷࡹ࡫࡭࠯ࡄࡸ࡭ࡱࡪࡖࡦࡴࡶ࡭ࡴࡴࠢᖰ") )[0:2])
        print l11l1l11l111_tv_ (u"ࠩࡎࡳࡩ࡯ࠠࡷࡧࡵࡷ࡮ࡵ࡮࠻ࠢࠨࡨ࠱ࠦࡣࡩࡧࡦ࡯࡮ࡴࡧࠡ࡫ࡩࠤࡕ࡜ࡒࠡ࡫ࡶࠤࡦࡩࡴࡪࡸࡨࠫᖱ") % version
        if version<17:
            try:
                l1lll111l1ll11l111_tv_ = xbmc.executeJSONRPC(l11l1l11l111_tv_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠢ࡮ࡧࡷ࡬ࡴࡪࠢ࠻ࠤࡖࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡌ࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࡗࡣ࡯ࡹࡪࠨࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡸ࡫ࡴࡵ࡫ࡱ࡫ࠧࡀࠢࡱࡸࡵࡱࡦࡴࡡࡨࡧࡵ࠲ࡪࡴࡡࡣ࡮ࡨࡨࠧࢃࠬࠣ࡫ࡧࠦ࠿࠿ࡽࠨᖲ"))
                l1ll1lllllll11l111_tv_ = json.loads(l1lll111l1ll11l111_tv_)
                l1ll1ll11lll11l111_tv_ = l1ll1lllllll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࠫᖳ"),{}).get(l11l1l11l111_tv_ (u"ࠬࡼࡡ࡭ࡷࡨࠫᖴ"),l11l1l11l111_tv_ (u"࠭ࠧᖵ"))
                if not l1ll1ll11lll11l111_tv_:
                    xbmcgui.Dialog().ok(l11l1l11l111_tv_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡ࡙࡫࡬ࡦࡹ࡬ࡾ࡯ࡧࠠ࡯࡫ࡨࠤ࡯࡫ࡳࡵࠢࡤ࡯ࡹࡿࡷ࡯ࡣࠤ࡟࠴ࡉࡏࡍࡑࡕࡡࠥ࠭ᖶ"),l11l1l11l111_tv_ (u"ࠨࡖࡨࡰࡪࡽࡩࡻ࡬ࡤࠤࡕ࡜ࡒࠡࡰ࡬ࡩࠥࡰࡥࡴࡶࠣࡥࡰࡺࡹࡸࡣࡲࡻࡦࡴࡡࠨᖷ"), l11l1l11l111_tv_ (u"ࠩࡄ࡯ࡹࡿࡷࡶ࡬ࠣ࡭ࠥࡻࡲࡶࡥ࡫ࡳࡲࠦࡰࡰࡰࡲࡻࡳ࡯ࡥࠡ࡬ࡤ࡯࡚ࠥࡥ࡭ࡧࡺ࡭ࡿࡰࡡࠡࡵ࡬झࠥࡴࡩࡦࠢࡳࡳ࡯ࡧࡷࡪࠩᖸ"))
                    xbmc.executebuiltin(l11l1l11l111_tv_ (u"ࠪࡅࡨࡺࡩࡷࡣࡷࡩ࡜࡯࡮ࡥࡱࡺࠬ࠶࠶࠰࠳࠳ࠬࠫᖹ"))
            except:
                pass
        else:
            pass
    else:
        xbmcgui.Dialog().notification(l11l1l11l111_tv_ (u"ࠫࡊࡘࡒࡐࡔࠪᖺ"), l11l1l11l111_tv_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡸࡥࡥ࡝ࡏ࡭ࡸࡺࡡࠡ࡯࠶ࡹࠥࡰࡥࡴࡼࡦࡾࡪࠦ࡮ࡪࡧࠣ࡭ࡸࡺ࡮ࡪࡧ࡭ࡩࠦࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᖻ"), xbmcgui.NOTIFICATION_ERROR, 3000)
def l11l1l1ll11l111_tv_(fname,path,l1l11l1ll11l111_tv_,l1l111ll11l11l111_tv_=None):
    l1lll111111l11l111_tv_ = os.path.join(path,fname)
    l1lll11111ll11l111_tv_ = xbmcgui.DialogProgressBG()
    l1lll11111ll11l111_tv_.create(l11l1l11l111_tv_ (u"࠭ࡔࡸࡱࡵࡾञࠦ࡬ࡪࡵࡷझࠥࡶࡲࡰࡩࡵࡥࡲࣹࡷࠡࡖ࡙ࠤࡠࠫࡳ࡞ࠩᖼ")%(fname), l11l1l11l111_tv_ (u"ࠧࡖॾࡼࡻࡦࡰࠠࡻࠢ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࡑࡘࡕࠤࡎࡖࡔࡗࠢࡖ࡭ࡲࡶ࡬ࡦࠢࡆࡰ࡮࡫࡮ࡵ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᖽ"))
    l1lll11111ll11l111_tv_.update(0,message=l11l1l11l111_tv_ (u"ࠨࡕࡽࡹࡰࡧ࡭ࠡ࡭ࡤࡲࡦैࣳࡸࠢ࠱࠲࠳࠭ᖾ"))
    if l1l111ll11l11l111_tv_:
        mod = l1l111ll11l11l111_tv_(l1l11l1ll11l111_tv_)
    else:
        mod = __import__(l1l11l1ll11l111_tv_)
    l1ll1lllll1l11l111_tv_ = mod.l11l11l1l11l111_tv_(addheader=True)
    N=len(l1ll1lllll1l11l111_tv_)
    l11l1ll1l11l111_tv_=[]
    l1lll11111ll11l111_tv_.update(0,message= l11l1l11l111_tv_ (u"ࠩ࡝ࡲࡦࡲࡡࡻॄࡨࡱࠥࠫࡤࠨᖿ") % N  )
    l1l111lllll11l111_tv_ = []
    l1ll111l1ll11l111_tv_ = [[] for x in range(N)]
    def l1l1lll111l11l111_tv_(l1l1l1ll11l111_tv_, l1ll111l1ll11l111_tv_, index,N):
        l1ll1l11l11l111_tv_ = mod.l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᗀ"),l11l1l11l111_tv_ (u"ࠫࠬᗁ")))
        l1ll111l1ll11l111_tv_[index]=l1ll1l11l11l111_tv_
        l1ll1lll1lll11l111_tv_ = sum([1 for x in l1ll111l1ll11l111_tv_ if x ])
        message = l11l1l11l111_tv_ (u"ࠬࠫࡤ࠰ࠧࡧࠤࠪࡹࠧᗂ")%(l1ll1lll1lll11l111_tv_,N-1,l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬᗃ"),l11l1l11l111_tv_ (u"ࠧࠨᗄ")))
        l1ll1ll1llll11l111_tv_ = int(l1ll1lll1lll11l111_tv_*100.0/N)
        l1lll11111ll11l111_tv_.update(l1ll1ll1llll11l111_tv_, message=message)
    try:
        xbmc.log(l11l1l11l111_tv_ (u"ࠨࡔࡸࡲࡳ࡯࡮ࡨ࡚ࠢࡳࡷࡱࡥࡳࠢࡗ࡬ࡷ࡫ࡡࡥࡵࠣࡔࡴࡵ࡬ࠨᗅ"))
        import l1ll11l11ll11l111_tv_
        pool = l1ll11l11ll11l111_tv_.ThreadPool(10)
        for i,l1l1l1ll11l111_tv_ in enumerate(l1ll1lllll1l11l111_tv_):
            time.sleep(0.1)
            pool.l1ll11l1lll11l111_tv_(l1l1lll111l11l111_tv_, *(l1l1l1ll11l111_tv_,l1ll111l1ll11l111_tv_,i,N-1))
        pool.l1ll11111ll11l111_tv_()
        xbmc.log(l11l1l11l111_tv_ (u"ࠩࡕࡹࡳࡴࡩ࡯ࡩ࡛ࠣࡴࡸ࡫ࡦࡴࠣࡘ࡭ࡸࡥࡢࡦࡶࠤࡕࡵ࡯࡭࠼ࠣࡈࡔࡔࡅࠨᗆ"))
        for l1l1l1ll11l111_tv_,l1ll1l11l11l111_tv_ in zip(l1ll1lllll1l11l111_tv_,l1ll111l1ll11l111_tv_):
            for stream in l1ll1l11l11l111_tv_:
                l11ll11ll11l111_tv_ = stream.get(l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᗇ"),l11l1l11l111_tv_ (u"ࠫࠬᗈ"))
                if l11ll11ll11l111_tv_:
                    l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩᗉ")]=l11ll11ll11l111_tv_
                    l11l1ll1l11l111_tv_.append(deepcopy(l1l1l1ll11l111_tv_))
    except:
        xbmc.log(l11l1l11l111_tv_ (u"࠭ࡒࡶࡰࡱ࡭ࡳ࡭ࠠࡕࡪࡵࡩࡦࡪࡳࠨᗊ"))
        for i,l1l1l1ll11l111_tv_ in enumerate(l1ll1lllll1l11l111_tv_):
            l1ll1ll1llll11l111_tv_ = int((i)*100.0/N)
            message = l11l1l11l111_tv_ (u"ࠧࠦࡦ࠲ࠩࡩࠦࠥࡴࠩᗋ")%(i,N-1,l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᗌ"),l11l1l11l111_tv_ (u"ࠩࠪᗍ")))
            l1lll11111ll11l111_tv_.update(l1ll1ll1llll11l111_tv_, message=message)
            l1ll1l11l11l111_tv_ = mod.l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᗎ"),l11l1l11l111_tv_ (u"ࠫࠬᗏ")))
            for stream in l1ll1l11l11l111_tv_:
                l11ll11ll11l111_tv_ = stream.get(l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩᗐ"),l11l1l11l111_tv_ (u"࠭ࠧᗑ"))
                msg = stream.get(l11l1l11l111_tv_ (u"ࠧ࡮ࡵࡪࠫᗒ"),l11l1l11l111_tv_ (u"ࠨࠩᗓ"))
                if l11ll11ll11l111_tv_:
                    l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭ᗔ")]=l11ll11ll11l111_tv_
                    l11l1ll1l11l111_tv_.append(deepcopy(l1l1l1ll11l111_tv_))
                elif msg: l1lll11111ll11l111_tv_.update(l1ll1ll1llll11l111_tv_, message=stream.get(l11l1l11l111_tv_ (u"ࠪࡱࡸ࡭ࠧᗕ")))
    l1lll11111ll11l111_tv_.close()
    if l11l1ll1l11l111_tv_:
        if len(l1ll1lllll1l11l111_tv_)>0:
            l11l1ll1l11l111_tv_.insert(0,l1ll1lllll1l11l111_tv_[0])
        if l1ll1lll1l1l11l111_tv_(l11l1ll1l11l111_tv_,l1lll111111l11l111_tv_):
            xbmcgui.Dialog().notification(l11l1l11l111_tv_ (u"ࠫࡑ࡯ࡳࡵࡣࠣࡾࡦࡶࡩࡴࡣࡱࡥࠬᗖ"), l1lll111111l11l111_tv_, xbmcgui.NOTIFICATION_INFO, 10000)
        else:
            xbmcgui.Dialog().notification(l11l1l11l111_tv_ (u"ࠬࡖࡲࡰࡤ࡯ࡩࡲࠦࡺࠡࡼࡤࡴ࡮ࡹࡥ࡮ࠢࡧࡳࠥࡶࡩ࡭࡭ࡸࠫᗗ"), l1lll111111l11l111_tv_, xbmcgui.NOTIFICATION_ERROR, 10000)
    return l11l1ll1l11l111_tv_
def l1ll1lll1l1l11l111_tv_(out,fname=l11l1l11l111_tv_ (u"࠭ࡴࡦ࡮ࡨࡻ࡮ࢀࡪࡢࡦࡤࡸࡻ࠴࡭࠴ࡷࠪᗘ")):
    try:
        l1lllllllll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࡊ࠲࡙࡝࡛ࡋ࡬ࡐࡔࡪࡁࡂ࠭ᗙ").decode(l11l1l11l111_tv_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨᗚ")) +l11l1l11l111_tv_ (u"ࠩ࠽࠱࠶ࠦࡴࡷࡩ࠰࡭ࡩࡃࠢࡼࡶࡹ࡭ࡩࢃࠢࠡࡩࡵࡳࡺࡶ࠭ࡵ࡫ࡷࡰࡪࡃࠢࡑࡱࡳࡹࡱࡧࡲ࡯ࡻࠥࠤࡹࡼࡧ࠮࡮ࡲ࡫ࡴࡃࠢࡼ࡫ࡰ࡫ࢂࠨࠠࡶࡴ࡯࠱ࡪࡶࡧ࠾ࠤࡾࡹࡷࡲࡥࡱࡩࢀࠦࠥ࡭ࡲࡰࡷࡳ࠱ࡹ࡯ࡴ࡭ࡧࡀࠦࢀ࡭ࡲࡰࡷࡳࢁࠧ࠲ࡻࡵ࡫ࡷࡰࡪࢃ࡜࡯ࡽࡸࡶࡱࢃ࡜࡯࡞ࡱࠫᗛ")
        l1l11ll1l1l11l111_tv_=l11l1l11l111_tv_ (u"ࠪࡍ࠵࡜࡙ࡗࡇ࠳ࡾ࡛ࡗ࡯࠾ࠩᗜ").decode(l11l1l11l111_tv_ (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫᗝ"))
        for l1l1l1ll11l111_tv_ in out:
            l1l11ll1l1l11l111_tv_=l1l11ll1l1l11l111_tv_+l1lllllllll11l111_tv_.format(**l1l1l1ll11l111_tv_)
        with  open(fname,l11l1l11l111_tv_ (u"ࠬࡽࠧᗞ")) as l1l111ll1ll11l111_tv_:
            l1l111ll1ll11l111_tv_.write(l1l11ll1l1l11l111_tv_)
        ret=True
    except:
        ret=False
    return ret
