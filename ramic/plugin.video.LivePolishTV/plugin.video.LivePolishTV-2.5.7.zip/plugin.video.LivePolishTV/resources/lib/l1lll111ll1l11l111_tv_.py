# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡰࡴࡣ࠰ࡸࡻ࠴ࡢ࡭ࡱࡪࡷࡵࡵࡴ࠯ࡥࡲࡱ࠴࠭ᕚ")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ᕛ")
__all__=[l11l1l11l111_tv_ (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭ᕜ"),l11l1l11l111_tv_ (u"ࠩࡪࡩࡹࡉࡨࡢࡰࡱࡩࡱ࡜ࡩࡥࡧࡲࠫᕝ")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᕞ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠫࠬᕟ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠬࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀ࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃ࠭ᕠ")).findall(content)
    for href,title in l1lll1lllll11l111_tv_:
        out.append({l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬᕡ"):title.strip(),l11l1l11l111_tv_ (u"ࠧࡵࡸ࡬ࡨࠬᕢ"):title.strip(),l11l1l11l111_tv_ (u"ࠨ࡫ࡰ࡫ࠬᕣ"):l11l1l11l111_tv_ (u"ࠩࠪᕤ"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᕥ"):href,l11l1l11l111_tv_ (u"ࠫ࡬ࡸ࡯ࡶࡲࠪᕦ"):l11l1l11l111_tv_ (u"ࠬ࠭ᕧ"),l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࡨࡴ࡬࠭ᕨ"):l11l1l11l111_tv_ (u"ࠧࠨᕩ")})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡻࡨࡰࡱࡵࡷ࡞ࡗࡳࡨࡦࡺࡥࡥ࠼ࠣࠩࡸࠦࠨࡱࡵࡤ࠱ࡹࡼࠩ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᕪ") %time.strftime(l11l1l11l111_tv_ (u"ࠤࠨࡨ࠴ࠫ࡭࠰ࠧ࡜࠾ࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢᕫ"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩᕬ"):t,l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩᕭ"):l11l1l11l111_tv_ (u"ࠬ࠭ᕮ"),l11l1l11l111_tv_ (u"࠭ࡩ࡮ࡩࠪᕯ"):l11l1l11l111_tv_ (u"ࠧࠨᕰ"),l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬᕱ"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠩࡪࡶࡴࡻࡰࠨᕲ"):l11l1l11l111_tv_ (u"ࠪࠫᕳ"),l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫᕴ"):l11l1l11l111_tv_ (u"ࠬ࠭ᕵ")})
    return out
def l111l1lll11l111_tv_(url=l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡰࡴࡣ࠰ࡸࡻ࠴ࡢ࡭ࡱࡪࡷࡵࡵࡴ࠯ࡤࡨ࠳ࡵ࠵ࡴࡷࡲ࠰࠵࠳࡮ࡴ࡮࡮ࠪᕶ")):
    l1lll1ll11l11l111_tv_=[]
    if l11l1l11l111_tv_ (u"ࠧࡱࡵࡤ࠱ࡹࡼ࠮ࡣ࡮ࡲ࡫ࡸࡶ࡯ࡵࠩᕷ") in url:
        content = l111111l11l111_tv_(url)
        l1111l111ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠨࡦࡲࡧࡺࡳࡥ࡯ࡶ࠱ࡻࡷ࡯ࡴࡦ࡞ࠫࡹࡳ࡫ࡳࡤࡣࡳࡩࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࡞ࠬࠫᕸ")).findall(content)
        l1111l111ll11l111_tv_ = urllib.unquote(l1111l111ll11l111_tv_[0]) if l1111l111ll11l111_tv_ else l11l1l11l111_tv_ (u"ࠩࠪᕹ")
        src = re.compile(l11l1l11l111_tv_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᕺ"),re.IGNORECASE).findall(l1111l111ll11l111_tv_)
        if src:
            if src[0].startswith(l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱࠩᕻ")):
                data = l111111l11l111_tv_(src[0])
                l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src[0],data)
                if l1ll11lll1l11l111_tv_:
                    return [{l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩᕼ"):l1ll11lll1l11l111_tv_}]
            file = re.compile(l11l1l11l111_tv_ (u"࠭࡜ࡀࡨ࡬ࡰࡪࡃࠨ࠯ࠬࡂ࠭ࠩ࠭ᕽ")).findall(src[0])
            if file :
                l111111llll11l111_tv_ = file[0].split(l11l1l11l111_tv_ (u"ࠧࠧࠩᕾ"))[0]
                href = l111111llll11l111_tv_ + l11l1l11l111_tv_ (u"ࠨࠢࡶࡻ࡫࡛ࡲ࡭࠿ࠨࡷࠥࡲࡩࡷࡧࡀ࠵ࠥࡺࡩ࡮ࡧࡲࡹࡹࡃ࠱࠱ࠢࡳࡥ࡬࡫ࡕࡳ࡮ࡀࠩࡸ࠭ᕿ")%(src[0],url)
                l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭ᖀ"):href}]
            else:
                l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,l1111l111ll11l111_tv_)
                if l1ll11lll1l11l111_tv_: l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᖁ"):l1ll11lll1l11l111_tv_}]
    return l1lll1ll11l11l111_tv_
def test():
    out=l11l11l1l11l111_tv_(addheader=False)
