# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import cookielib
import threading
import re
import time
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡳࡳࡷࡺ࠮ࡵࡸࡳ࠲ࡵࡲࠧᢈ")
proxy={}
l1lll1ll1ll11l111_tv_ = 10
l11lll1llll11l111_tv_=l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡳࡣࡰ࡯ࡦ࠴ࡰࡳࡱࡻࡽ࠳ࡴࡥࡵ࠰ࡳࡰ࠴࡯࡮ࡥࡧࡻ࠲ࡵ࡮ࡰࡀࡳࡀࠫᢉ")
l1ll111l111l11l111_tv_=l11l1l11l111_tv_ (u"ࠪࠫᢊ")
def l111111l11l111_tv_(url,proxy={},timeout=l1lll1ll1ll11l111_tv_,l1llll1111l11l111_tv_=True):
    global l1ll111l111l11l111_tv_
    l1llll1ll1l11l111_tv_=[]
    if proxy:
        urllib2.install_opener(urllib2.build_opener(urllib2.ProxyHandler(proxy)))
    elif l1llll1111l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    req = urllib2.Request(url)
    req.add_header(l11l1l11l111_tv_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᢋ"), l11l1l11l111_tv_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠺࠹࠮࠱࠰࠵࠻࠽࠻࠮࠲࠳࠹ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫᢌ"))
    try:
        response = urllib2.urlopen(req,timeout=timeout)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࠧᢍ")
    l1ll111l111l11l111_tv_ = l11l1l11l111_tv_ (u"ࠧࠨᢎ").join([l11l1l11l111_tv_ (u"ࠨࠧࡶࡁࠪࡹ࠻ࠨᢏ")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(url=l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡴࡴࡸࡴ࠯ࡶࡹࡴ࠳ࡶ࡬࠰ࡶࡵࡥࡳࡹ࡭ࡪࡵ࡭ࡩࠬᢐ")):
    out=[]
    content=l111111l11l111_tv_(l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡵࡵࡲࡵ࠰ࡷࡺࡵ࠴ࡰ࡭࠱ࡷࡶࡦࡴࡳ࡮࡫ࡶ࡮ࡪ࠭ᢑ"))
    ids = [(a.start(), a.end()) for a in re.finditer(l11l1l11l111_tv_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡧࡥࡹ࡫ࠢ࠿ࠩᢒ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l1l1lll1lll11l111_tv_ = content[ ids[i][1]:ids[i+1][0] ]
        l1l1llllllll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠬࡂࡳࡱࡣࡱࡂ࠭ࡊ࡚ࡊ࠰࠭࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬᢓ")).findall(l1l1lll1lll11l111_tv_)
        if l1l1llllllll11l111_tv_:
            l1ll1111l1ll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࠧᢔ")
        else:
            l1ll1111l1ll11l111_tv_=re.compile(l11l1l11l111_tv_ (u"ࠧ࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬᢕ")).findall(l1l1lll1lll11l111_tv_)
            l1ll1111l1ll11l111_tv_ = l1ll1111l1ll11l111_tv_[0]+l11l1l11l111_tv_ (u"ࠨࠢࠪᢖ") if l1ll1111l1ll11l111_tv_ else l11l1l11l111_tv_ (u"ࠩࠪᢗ")
        l1l1llllll1l11l111_tv_ = [(a.start(), a.end()) for a in re.finditer(l11l1l11l111_tv_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡷࡩࡲ࠳ࡴࡪ࡯ࡨࠤࡱ࡯ࡶࡦࠤࡁࠫᢘ"), l1l1lll1lll11l111_tv_)]
        l1l1llllll1l11l111_tv_.append( (-1,-1) )
        for j in range(len(l1l1llllll1l11l111_tv_[:-1])):
            item = l1l1lll1lll11l111_tv_[ l1l1llllll1l11l111_tv_[j][1]:l1l1llllll1l11l111_tv_[j+1][0] ]
            href=[]
            time = re.compile(l11l1l11l111_tv_ (u"ࠫࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨᢙ")).findall(item)
            title= re.compile(l11l1l11l111_tv_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡹ࡫࡭࠮ࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࡞ࡢࡁࡣࠫࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᢚ"),re.DOTALL).findall(item)
            if not title:
                l1ll111111ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦ࡮ࡺࡥ࡮࠯ࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧᢛ"),re.DOTALL).findall(item)
                l1ll111111ll11l111_tv_ = l1ll111111ll11l111_tv_[0] if l1ll111111ll11l111_tv_ else l11l1l11l111_tv_ (u"ࠧࠨᢜ")
                href  = re.compile(l11l1l11l111_tv_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᢝ")).findall(l1ll111111ll11l111_tv_)
                title = re.compile(l11l1l11l111_tv_ (u"ࠩࡁࠬ࠳࠰࠿ࠪ࠾ࠪᢞ")).findall(l1ll111111ll11l111_tv_)
            if title and time:
                t = l11l1l11l111_tv_ (u"ࠪࠩࡸࠫࡳ࠻ࠢ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࠦࡵ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᢟ")%(l1ll1111l1ll11l111_tv_,time[0],title[0].strip())
                code=l11l1l11l111_tv_ (u"ࠫࡠࡈ࡝࡜ࡅࡒࡐࡔࡘࠠ࡭࡫ࡪ࡬ࡹ࡭ࡲࡦࡧࡱࡡࡑ࡯ࡶࡦ࡝࠲ࡇࡔࡒࡏࡓ࡟࡞࠳ࡇࡣࠧᢠ") if href else l11l1l11l111_tv_ (u"ࠬ࠭ᢡ")
                href = l1ll1111ll1l11l111_tv_(href[0]) if href else l11l1l11l111_tv_ (u"࠭ࠧᢢ")
                out.append({l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᢣ"):t,l11l1l11l111_tv_ (u"ࠨࡶࡹ࡭ࡩ࠭ᢤ"):l11l1l11l111_tv_ (u"ࠩࠪᢥ"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᢦ"):href,l11l1l11l111_tv_ (u"ࠫ࡬ࡸ࡯ࡶࡲࠪᢧ"):l11l1l11l111_tv_ (u"ࠬ࠭ᢨ"),l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࡨࡴ࡬ᢩ࠭"):l11l1l11l111_tv_ (u"ࠧࠨᢪ"),l11l1l11l111_tv_ (u"ࠨࡥࡲࡨࡪ࠭᢫"):code})
    return out
def l1lll1l11l1l11l111_tv_():
    content=l111111l11l111_tv_(l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡩࡥࡥ࡯ࡳࡦࡱ࠮ࡤࡱࡰ࠳ࡵࡸ࡯ࡹࡻ࡯࡭ࡸࡺ࠯ࡧࡴࡨࡩ࠲ࡶࡲࡰࡺࡼ࠱ࡱ࡯ࡳࡵ࠯ࡳࡳࡱࡧ࡮ࡥ࠰࡫ࡸࡲࡲࠧ᢬"))
    l1lll1lll1ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠪࡀࡩ࡯ࡶࠡࡵࡷࡽࡱ࡫࠽ࠣࡹ࡬ࡨࡹ࡮࠺࡝ࡦ࠮ࠩࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࡝ࡦ࠮࠭ࠪࠨ࠾࠽࠱ࡧ࡭ࡻࡄࠧ᢭")).findall(content)
    l1lll1l1l11l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡁࡺࡤ࠿ࠪ࡫ࡸࡹࡶ࡛ࡴ࡟࠭࠭ࡁ࠵ࡴࡥࡀ࠿ࡸࡩࡄࠨ࡝ࡦ࠮࠭ࡁ࠵ࡴࡥࡀ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡥࡀࠪ᢮"),re.DOTALL).findall(content)
    proxies=[{x[0]: l11l1l11l111_tv_ (u"ࠬࠫࡳ࠻ࠧࡶࠫ᢯")%(x[2],x[1])} for x in l1lll1l1l11l11l111_tv_]
    return proxies
def l1ll1111ll1l11l111_tv_(url):
    l1ll111l1lll11l111_tv_=url
    return l1ll111l1lll11l111_tv_
    if url==l11l1l11l111_tv_ (u"࠭ࠧᢰ"):
        return l1ll111l1lll11l111_tv_
    if url.startswith(l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴࡲࡲࡶࡹ࠴ࡴࡷࡲ࠱ࡴࡱ࠭ᢱ")):
        content = l111111l11l111_tv_(url)
    else:
        content = l111111l11l111_tv_(l1llll111ll11l111_tv_+url)
    l1ll1l1111l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠣ࠾࡬ࡪࡷࡧ࡭ࡦࠪ࠱࠮ࡄ࠯࠼࠰࡫ࡩࡶࡦࡳࡥ࠿ࠤᢲ"), re.DOTALL).findall(content)
    for frame in l1ll1l1111l11l111_tv_:
        src = re.compile(l11l1l11l111_tv_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᢳ"), re.DOTALL).findall(frame)
        if src:
            l1ll111l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸࡻࡶࡳࡵࡴࡨࡥࡲ࠴ࡴࡷࡲ࠱ࡴࡱ࠭ᢴ")+src[0]
    return l1ll111l1lll11l111_tv_
def l111l1lll11l111_tv_(ex_link):
    if l11l1l11l111_tv_ (u"ࠫࡸ࡫ࡳࡴ࠱ࡷࡺࡵࡲࡡࡺࡧࡵ࠲ࡵ࡮ࡰࠨᢵ") in ex_link:
        url = ex_link.replace(l11l1l11l111_tv_ (u"ࠬࡺࡶࡱࡵࡷࡶࡪࡧ࡭࠯ࡶࡹࡴ࠳ࡶ࡬ࠨᢶ"),l11l1l11l111_tv_ (u"࠭ࡳࡱࡱࡵࡸ࠳ࡺࡶࡱ࠰ࡳࡰࠬᢷ"))
    else:
        id = re.compile(l11l1l11l111_tv_ (u"ࠧ࠰ࠪ࡟ࡨ࠰࠯࠯ࠨᢸ")).findall(ex_link)
        url = l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵࡳࡳࡷࡺ࠮ࡵࡸࡳ࠲ࡵࡲ࠯ࡴࡧࡶࡷ࠴ࡺࡶࡱ࡮ࡤࡽࡪࡸ࠮ࡱࡪࡳࡃࡨࡵࡰࡺࡡ࡬ࡨࡂࠫࡳࠧࡱࡥ࡮ࡪࡩࡴࡠ࡫ࡧࡁࠪࡹࠦࡢࡷࡷࡳࡵࡲࡡࡺ࠿ࡷࡶࡺ࡫ࠧᢹ")%(id[0],id[0]) if id else l11l1l11l111_tv_ (u"ࠩࠪᢺ")
    l1ll11l1l11l111_tv_ = l1l11l1111l11l111_tv_(url)
    if not l1ll11l1l11l111_tv_ or l11l1l11l111_tv_ (u"ࠪࡱࡦࡺࡥࡳ࡫ࡤࡰࡤࡴࡩࡦࡦࡲࡷࡹ࡫ࡰ࡯ࡻࠪᢻ") in l1ll11l1l11l111_tv_ :
        l1ll11l1l11l111_tv_ = l1l11l1111l11l111_tv_(url,use=l11l1l11l111_tv_ (u"ࠫࡵ࡭ࡡࡵࡧ࠵ࠫᢼ"))
        if not l1ll11l1l11l111_tv_:
            l1ll11l1l11l111_tv_ = l1l11l1111l11l111_tv_(url,use=l11l1l11l111_tv_ (u"ࠬࡶࡲࡰࡺࡼࠫᢽ"))
    if not isinstance(l1ll11l1l11l111_tv_,list) and l11l1l11l111_tv_ (u"࠭࡭ࡢࡰ࡬ࡪࡪࡹࡴ࠯࡯࠶ࡹ࠽࠭ᢾ") in l1ll11l1l11l111_tv_:
        l1ll11l1l11l111_tv_ = l1ll1111l11l11l111_tv_(l1ll11l1l11l111_tv_.strip())
    if not l1ll11l1l11l111_tv_:
        l1ll11l1l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠧ࡮ࡵࡪࠫᢿ"):l11l1l11l111_tv_ (u"ࠨࡏࡤࡸࡪࡸࡩࡢॄࠣ࡮ࡪࡹࡴࠡࡰ࡬ࡩࡩࡵࡳࡵछࡳࡲࡾ࠭ᣀ")}]
    return l1ll11l1l11l111_tv_
def l1ll11111l1l11l111_tv_(url):
    try:
        l1l1llll1lll11l111_tv_ =l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡥࡶࡦࡳ࡫ࡢ࠰ࡳࡶࡴࡾࡹ࠯ࡰࡨࡸ࠳ࡶ࡬࠰࡫ࡱࡨࡪࡾ࠮ࡱࡪࡳࡃࡶࡃࠥࡴࠨ࡫ࡰࡂ࠶ࠧᣁ")%urllib.quote_plus(url)
        headers={l11l1l11l111_tv_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᣂ"): l11l1l11l111_tv_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡪࡰ࠹࠸ࡀࠦࡸ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠸࠴࠲࠵࠴࠳࠲࠸࠶࠲࠶࠶࠰ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨᣃ"),l11l1l11l111_tv_ (u"࡛ࠬࡰࡨࡴࡤࡨࡪ࠳ࡉ࡯ࡵࡨࡧࡺࡸࡥ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡵࠪᣄ"):1,
        l11l1l11l111_tv_ (u"࠭ࡁࡤࡥࡨࡴࡹ࠭ᣅ"):l11l1l11l111_tv_ (u"ࠧࡵࡧࡻࡸ࠴࡮ࡴ࡮࡮࠯ࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࡫ࡸࡲࡲࠫࡹ࡯࡯࠰ࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻࡱࡱࡁࡱ࠾࠲࠱࠽࠱࡯࡭ࡢࡩࡨ࠳ࡼ࡫ࡢࡱ࠮࡬ࡱࡦ࡭ࡥ࠰ࡣࡳࡲ࡬࠲ࠪ࠰ࠬ࠾ࡵࡂ࠶࠮࠹ࠩᣆ")}
        req = urllib2.Request(l1l1llll1lll11l111_tv_,None,headers)
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_=response.read()
        response.close()
        print l11l1l11l111_tv_ (u"ࠨࡉࡄࡘࡊ࠸ࠠࡪࡰ࡙ࠣࡘࡋࠧᣇ")
    except:
        print l11l1l11l111_tv_ (u"ࠩࡊࡅ࡙ࡋࠠࡪࡰ࡙ࠣࡘࡋࠠࡆࡔࡕࡓࡗ࠭ᣈ")
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠪࠫᣉ")
    return l11ll11ll11l111_tv_
def l1l11l1111l11l111_tv_(url=l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡶ࡯ࡳࡶ࠱ࡸࡻࡶ࠮ࡱ࡮࠲ࡷࡪࡹࡳ࠰ࡶࡹࡴࡱࡧࡹࡦࡴ࠱ࡴ࡭ࡶ࠿ࡤࡱࡳࡽࡤ࡯ࡤ࠾࠵࠸࠼࠷࠾࠲࠸࠲ࠩࡳࡧࡰࡥࡤࡶࡢ࡭ࡩࡃ࠳࠶࠺࠵࠼࠷࠽࠰ࠧࡣࡸࡸࡴࡶ࡬ࡢࡻࡀࡸࡷࡻࡥࠨᣊ"),use=l11l1l11l111_tv_ (u"ࠬ࠭ᣋ")):
    l1ll111l1lll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࠧᣌ")
    if not url: return l1ll111l1lll11l111_tv_
    if use==l11l1l11l111_tv_ (u"ࠧࡱࡩࡤ࡫ࡪ࠭ᣍ"):
        data = l111111l11l111_tv_(l11lll1llll11l111_tv_+urllib.quote_plus(url)+l11l1l11l111_tv_ (u"ࠨࠨ࡫ࡰࡂ࠸ࡡ࠶ࠩᣎ"))
        l1ll111l1lll11l111_tv_ = l1ll1111l11l11l111_tv_(_1ll11111lll11l111_tv_(data))
    elif use==l11l1l11l111_tv_ (u"ࠩࡳ࡫ࡦࡺࡥ࠳ࠩᣏ"):
        data = l1ll11111l1l11l111_tv_(url)
        l1ll111l1lll11l111_tv_ = l1ll1111l11l11l111_tv_(_1ll11111lll11l111_tv_(data))
    elif use==l11l1l11l111_tv_ (u"ࠪࡴࡷࡵࡸࡺࠩᣐ"):
        proxies = l1lll1l11l1l11l111_tv_()
        l1l111lllll11l111_tv_ = list()
        l1ll111l1ll11l111_tv_ = [[] for x in proxies]
        for i,proxy in enumerate(proxies):
            thread = threading.Thread(name=l11l1l11l111_tv_ (u"࡙ࠫ࡮ࡲࡦࡣࡧࠩࡩ࠭ᣑ")%i, target = l1l1lll111l11l111_tv_, args=[url,proxy,l1ll111l1ll11l111_tv_,i])
            l1l111lllll11l111_tv_.append(thread)
            thread.start()
        while any([i.isAlive() for i in l1l111lllll11l111_tv_]) and len(l1ll111l1lll11l111_tv_)==0:
            for l in l1ll111l1ll11l111_tv_:
                l = l1ll111l1ll11l111_tv_[3]
                if isinstance(l,list):
                    l1ll111l1lll11l111_tv_ = l
                    break
            time.sleep(0.1)
        del l1l111lllll11l111_tv_[:]
    else:
        data = l111111l11l111_tv_(url)
        l1ll111l1lll11l111_tv_ = _1ll11111lll11l111_tv_(data)
    return l1ll111l1lll11l111_tv_
def _1ll11111lll11l111_tv_(data):
    l1ll111l1lll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠬ࠷࠺ࡼࡵࡵࡧࡠࡀ࡜ࡴ࡟࠮࡟ࡡ࠭ࠢ࡞ࠪ࠱࠯ࡄ࠯࡛࡝ࠩࠥࡡࠬᣒ"), re.DOTALL).findall(data)
    if not l1ll111l1lll11l111_tv_:
        l1ll111l1lll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠨ࠰࠻ࡽࡶࡶࡨࡀ࡜ࠨࠪ࠱࠯ࡄ࠯࡜ࠨࠤᣓ"), re.DOTALL).findall(data)
    l1ll111l1lll11l111_tv_ = l1ll111l1lll11l111_tv_[0] if l1ll111l1lll11l111_tv_ else l11l1l11l111_tv_ (u"ࠧࠨᣔ")
    return l1ll111l1lll11l111_tv_
def l1l1lll111l11l111_tv_(ex_link ,proxy, l1ll111l1ll11l111_tv_, index):
    data = l111111l11l111_tv_(ex_link,proxy,timeout=10)
    l11ll11ll11l111_tv_ = l1ll1111l11l11l111_tv_(_1ll11111lll11l111_tv_(data))
    l1ll111l1ll11l111_tv_[index]= l11ll11ll11l111_tv_ if not l11l1l11l111_tv_ (u"ࠨ࡯ࡤࡸࡪࡸࡩࡢ࡮ࡢࡲ࡮࡫ࡤࡰࡵࡷࡩࡵࡴࡹࠨᣕ") in l11ll11ll11l111_tv_ else l11l1l11l111_tv_ (u"ࠩࠪᣖ")
def l1ll1111l11l11l111_tv_(url):
    out=url
    if url and url.endswith(l11l1l11l111_tv_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩᣗ")):
        l1l1lllll11l11l111_tv_ = re.search(l11l1l11l111_tv_ (u"ࠫ࠴࠮࡜ࡸ࠭ࠬࡠ࠳ࡳ࠳ࡶ࠺ࠪᣘ"),url)
        l1l1lllll11l11l111_tv_ = l1l1lllll11l11l111_tv_.group(1) if l1l1lllll11l11l111_tv_ else l11l1l11l111_tv_ (u"ࠬࡳࡡ࡯࡫ࡩࡩࡸࡺࠧᣙ")
        content = l111111l11l111_tv_(url)
        matches=re.compile(l11l1l11l111_tv_ (u"࠭ࡒࡆࡕࡒࡐ࡚࡚ࡉࡐࡐࡀࠬ࠳࠰࠿ࠪ࡞ࡵࡠࡳ࠮ࡑࡶࡣ࡯࡭ࡹࡿࡌࡦࡸࡨࡰࡸࡢࠨ࠯ࠬ࡟࠭࠴ࡳࡡ࡯࡫ࡩࡩࡸࡺ࡜ࠩࡨࡲࡶࡲࡧࡴ࠾࡯࠶ࡹ࠽࠳ࡡࡢࡲ࡯ࡠ࠮࠯ࠧᣚ")).findall(content)
        if matches:
            out=[{l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᣛ"):l11l1l11l111_tv_ (u"ࠨࡣࡸࡸࡴ࠭ᣜ"),l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭ᣝ"):url}]
            for title, part in matches:
                l1l1l1ll11l111_tv_={l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩᣞ"):title,l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨᣟ"):url.replace(l1l1lllll11l11l111_tv_,part)}
                out.append(l1l1l1ll11l111_tv_)
    return out
def l1l1lllll1ll11l111_tv_():
    content = l111111l11l111_tv_(l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡰࡰࡴࡷ࠲ࡹࡼࡰ࠯ࡲ࡯࠳ࡷ࡯࡯࠰࠴࠸࠼࠺࠷࠷࠸࠳࠲ࡴࡷࡵࡧࡳࡣࡰࠫᣠ"))
    l1ll111l11ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭࠼ࡴࡲࡤࡲࠥࡩ࡬ࡢࡵࡶࡁࠧ࡫ࡰࡨ࠯࡬ࡸࡪࡳࠨ࠯ࠬࡂ࠭ࡡࡴ࡜ࡵ࡞ࡷࡠࡹࡂ࠯ࡴࡲࡤࡲࡃ࠭ᣡ"),re.DOTALL).findall(content)
    out=[]
    for item in l1ll111l11ll11l111_tv_:
        l1ll111ll11l11l111_tv_=re.compile(l11l1l11l111_tv_ (u"ࠧࡥࡣࡷࡥ࠲࡯ࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᣢ")).findall(item)
        l1ll1111llll11l111_tv_=re.compile(l11l1l11l111_tv_ (u"ࠨࡦࡤࡸࡦ࠳ࡲࡦࡦ࡬ࡶࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᣣ")).findall(item)
        times=re.compile(l11l1l11l111_tv_ (u"ࠩࠥࡸ࡮ࡳࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩᣤ")).findall(item)
        title=re.compile(l11l1l11l111_tv_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᣥ")).findall(item)
        category=re.compile(l11l1l11l111_tv_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡧࡴࡦࡩࡲࡶࡾࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᣦ")).findall(item)
        l1ll111l1l1l11l111_tv_=re.compile(l11l1l11l111_tv_ (u"ࠬࡪࡡࡵࡣ࠰ࡦࡷࡵࡡࡥࡥࡤࡷࡹ࠳ࡳࡵࡣࡵࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᣧ")).findall(item)
        l1ll111l1l1l11l111_tv_ = float(l1ll111l1l1l11l111_tv_[0])/1000 if l1ll111l1l1l11l111_tv_ else 0
        l1l1llll1l1l11l111_tv_=re.compile(l11l1l11l111_tv_ (u"࠭ࡤࡢࡶࡤ࠱ࡧࡸ࡯ࡢࡦࡦࡥࡸࡺ࠭ࡦࡰࡧࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᣨ")).findall(item)
        l1l1llll1l1l11l111_tv_ = float(l1l1llll1l1l11l111_tv_[0])/1000 if l1l1llll1l1l11l111_tv_ else 0
        if item.find(l11l1l11l111_tv_ (u"ࠧࡷ࡫ࡧࡩࡴ࠳ࡩࡤࡱࡱࠫᣩ")) and l1ll1111llll11l111_tv_ and times and title and category:
            if time.localtime().tm_yday==time.localtime(l1ll111l1l1l11l111_tv_).tm_yday:
                print l11l1l11l111_tv_ (u"ࠨࡖࡒࡈࡆ࡟ࠧᣪ")
                times = [time.strftime(l11l1l11l111_tv_ (u"ࠤࠨࡥࠥࠫࡈ࠻ࠧࡐࠦᣫ"), time.localtime(l1ll111l1l1l11l111_tv_))]
            else:
                times = [time.strftime(l11l1l11l111_tv_ (u"ࠥࠩࡦࠦࠥࡉ࠼ࠨࡑࠧᣬ"), time.localtime(l1ll111l1l1l11l111_tv_))]
            id = re.compile(l11l1l11l111_tv_ (u"ࠫ࠴࠮࡜ࡥ࠭ࠬ࠳ࠬᣭ")).findall(l1ll1111llll11l111_tv_[0]) if l1ll1111llll11l111_tv_ else l11l1l11l111_tv_ (u"ࠬ࠭ᣮ")
            href = l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡴࡷࡲࡶࡸࡷ࡫ࡡ࡮࠰ࡷࡺࡵ࠴ࡰ࡭࠱ࡶࡩࡸࡹ࠯ࡵࡸࡳࡰࡦࡿࡥࡳ࠰ࡳ࡬ࡵࡅ࡯ࡣ࡬ࡨࡧࡹࡥࡩࡥ࠿ࠪᣯ")+id[0] if id else l11l1l11l111_tv_ (u"ࠧࠨᣰ")
            code=l11l1l11l111_tv_ (u"ࠨ࡝ࡅࡡࡠࡉࡏࡍࡑࡕࠤ࡬ࡸࡥࡦࡰࡠࡺ࡮ࡪࡥࡰ࡝࠲ࡇࡔࡒࡏࡓ࡟࡞࠳ࡇࡣࠧᣱ") if href else l11l1l11l111_tv_ (u"ࠩࠪᣲ")
            if time.time() <= l1l1llll1l1l11l111_tv_:
                l1ll111l1l1l11l111_tv_=l1ll111l1l1l11l111_tv_/10
                code=l11l1l11l111_tv_ (u"ࠪ࡟ࡇࡣ࡛ࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸ࡬ࡸࡥࡦࡰࡠࡐ࡮ࡼࡥ࡜࠱ࡆࡓࡑࡕࡒ࡞࡝࠲ࡆࡢ࠭ᣳ")
                times = [times[0].split(l11l1l11l111_tv_ (u"ࠫࠥ࠭ᣴ"))[-1]]
            t = l11l1l11l111_tv_ (u"ࠬࠫࡳ࠻ࠢ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࠦࡵ࠯ࠤࠪࡹ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨᣵ")%(times[0],title[0].strip(),category[0].strip())
            print times[0]
            out.append({l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ᣶"):t,l11l1l11l111_tv_ (u"ࠧࡵࡸ࡬ࡨࠬ᣷"):l11l1l11l111_tv_ (u"ࠨࠩ᣸"),l11l1l11l111_tv_ (u"ࠩ࡬ࡱ࡬࠭᣹"):l11l1l11l111_tv_ (u"ࠪࠫ᣺"),l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨ᣻"):href,l11l1l11l111_tv_ (u"ࠬ࡭ࡲࡰࡷࡳࠫ᣼"):l11l1l11l111_tv_ (u"࠭ࠧ᣽"),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࡩࡵ࡭ࠧ᣾"):l11l1l11l111_tv_ (u"ࠨࠩ᣿"),l11l1l11l111_tv_ (u"ࠩࡦࡳࡩ࡫ࠧᤀ"):code,l11l1l11l111_tv_ (u"ࠪࡸࡹ࡯࡭ࡦࠩᤁ"):l1ll111l1l1l11l111_tv_})
    out = sorted(out, key=lambda x: x[l11l1l11l111_tv_ (u"ࠫࡹࡺࡩ࡮ࡧࠪᤂ")])
    return out
def test():
    out=l1ll1111111l11l111_tv_()
    out=l1l1lllll1ll11l111_tv_()
