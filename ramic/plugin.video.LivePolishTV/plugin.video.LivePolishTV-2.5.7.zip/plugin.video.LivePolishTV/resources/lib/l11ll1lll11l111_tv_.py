# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import re
import urllib2,urllib
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡏࡘ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠸࠴࠳࠶࠮࠳࠸࠹࠵࠳࠷࠰࠳ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩ᳿")
l1llll111ll11l111_tv_ = l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹࡼࡰࡴࡶࡵࡩࡦࡳ࠮ࡵࡸࡳ࠲ࡵࡲ࠯ࠨᴀ")
l11lll1llll11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡥࡶࡦࡳ࡫ࡢ࠰ࡳࡶࡴࡾࡹ࠯ࡰࡨࡸ࠳ࡶ࡬࠰࡫ࡱࡨࡪࡾ࠮ࡱࡪࡳࡃࡶࡃࠧᴁ")
__all__=[l11l1l11l111_tv_ (u"࠭ࡧࡦࡶࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫᴂ"),l11l1l11l111_tv_ (u"ࠧࡨࡧࡷࡇ࡭ࡧ࡮࡯ࡧ࡯࡚࡮ࡪࡥࡰࠩᴃ")]
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    return l1l1l1ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},cookies={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᴄ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=10)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_ = l11l1l11l111_tv_ (u"ࠩࠪᴅ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(url=l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸࡻࡶࡳࡵࡴࡨࡥࡲ࠴ࡶࡰࡦ࠱ࡸࡻࡶ࠮ࡱ࡮ࠪᴆ")):
    data=l111111l11l111_tv_(url)
    l1l11ll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠦ࠴ࡹࡥࡴࡵ࠲ࡸࡻࡶ࡬ࡢࡻࡨࡶ࠳ࡶࡨࡱࡁࡲࡦ࡯࡫ࡣࡵࡡ࡬ࡨࡂࠫࡳࠣᴇ")
    l1l11ll1l11l11l111_tv_=re.compile(l11l1l11l111_tv_ (u"ࠬࡪࡡࡵࡣ࠰ࡺ࡮ࡪࡥࡰ࠯࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᴈ")).findall(data)
    l1l11ll11l1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭࠼ࡴࡲࡤࡲࠥࡩ࡬ࡢࡵࡶࡁࠧ࡯࡭ࡨࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠤ࠴ࡄࠧᴉ")).findall(data)
    len(l1l11ll1l11l11l111_tv_)
    len(l1l11ll11l1l11l111_tv_)
    out=[]
    for i in range(len(l1l11ll1l11l11l111_tv_)):
        l1l11ll11lll11l111_tv_ = l1l11ll1l11l11l111_tv_[i][0]
        title = l1l11ll11l1l11l111_tv_[i][1].decode(l11l1l11l111_tv_ (u"ࠧࡶࡶࡩ࠱࠽࠭ᴊ")) + l11l1l11l111_tv_ (u"ࠨࠢ࠽ࠤࠬᴋ") + l1l11ll1l11l11l111_tv_[i][1].decode(l11l1l11l111_tv_ (u"ࠩࡸࡸ࡫࠳࠸ࠨᴌ"))
        l1llll11lll11l111_tv_ = l1l11ll11l1l11l111_tv_[i][0]
        out.append({l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩᴍ"):title,l11l1l11l111_tv_ (u"ࠫ࡮ࡳࡧࠨᴎ"):l1llll11lll11l111_tv_,
                    l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩᴏ"):url+l1l11ll111ll11l111_tv_ % l1l11ll11lll11l111_tv_})
    return out
def l111l1lll11l111_tv_(ex_link=l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡴࡷࡲࡶࡸࡷ࡫ࡡ࡮࠰ࡷࡺࡵ࠴ࡰ࡭࠱ࡶࡩࡸࡹ࠯ࡵࡸࡳࡰࡦࡿࡥࡳ࠰ࡳ࡬ࡵࡅ࡯ࡣ࡬ࡨࡧࡹࡥࡩࡥ࠿࠴࠹࠹࠹࠸࠷࠲࠺ࠫᴐ")):
    data=l111111l11l111_tv_(ex_link)
    l1lll1ll11l11l111_tv_=[]
    l11l1l111ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠢ࠱࠼ࡾࡷࡷࡩ࠺ࠨࠪ࠱࠮ࡄ࠯ࠧࠣᴑ"), re.DOTALL).findall(data)
    if l11l1l111ll11l111_tv_:
        if l11l1l11l111_tv_ (u"ࠨ࡯ࡤࡸࡪࡸࡩࡢ࡮ࡢࡲ࡮࡫ࡤࡰࡵࡷࡩࡵࡴࡹࠨᴒ") in l11l1l111ll11l111_tv_[0]:
            data = l111111l11l111_tv_(l11lll1llll11l111_tv_+urllib.quote_plus(ex_link)+l11l1l11l111_tv_ (u"ࠩࠩ࡬ࡱࡃ࠲ࡢ࠷ࠪᴓ"))
            l11l1l111ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠥ࠴࠿ࢁࡳࡳࡥ࠽ࠫ࠭࠴ࠪࡀࠫࠪࠦᴔ"), re.DOTALL).findall(data)
        l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨᴕ"):l11l1l111ll11l111_tv_[0],l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡫࡯ࡩࠬᴖ"):l11l1l11l111_tv_ (u"࠭ࡌࡪࡸࡨࠫᴗ"),l11l1l11l111_tv_ (u"ࠧࡳࡧࡶࡳࡱࡼࡥࡥࠩᴘ"):1})
    return l1lll1ll11l11l111_tv_
def _1l1l11l11l11l111_tv_(url=l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡺࡶࡱ࠰ࡳࡰ࠴ࡺࡶࡱ࡮ࡤࡽࡪࡸ࠿ࡤࡪࡤࡲࡳ࡫࡬ࡠ࡫ࡧࡁ࠶࠼࠳࠵࠳࠼࠵ࠫࡧࡵࡵࡱࡳࡰࡦࡿ࠽ࡵࡴࡸࡩࠬᴙ")):
    l1lll1ll11l11l111_tv_=[{}]
    if l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡴࡷࡲ࠱ࡴࡱ࠵ࡴࡷࡲ࡯ࡥࡾ࡫ࡲࠨᴚ") in url:
        data=l111111l11l111_tv_(url)
        src=re.compile(l11l1l11l111_tv_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᴛ")).findall(data)
        if src and src[0].startswith(l11l1l11l111_tv_ (u"ࠫ࠴ࡹࡥࡴࡵ࠲ࡸࡻࡶ࡬ࡢࡻࡨࡶ࠳ࡶࡨࡱࠩᴜ")):
            l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡺࡶࡱࡵࡷࡶࡪࡧ࡭࠯ࡶࡹࡴ࠳ࡶ࡬ࠨᴝ")+src[0])
    elif l11l1l11l111_tv_ (u"࠭࠯ࡴࡧࡶࡷ࠴ࡺࡶࡱ࡮ࡤࡽࡪࡸ࠮ࡱࡪࡳࠫᴞ") in url:
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
    return l1lll1ll11l11l111_tv_
