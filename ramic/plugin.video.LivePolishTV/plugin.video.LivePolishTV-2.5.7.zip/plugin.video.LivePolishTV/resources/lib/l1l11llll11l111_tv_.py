# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re
import time
import threading
import l1ll11ll1ll11l111_tv_
__all__=[l11l1l11l111_tv_ (u"ࠪ࡫ࡪࡺࡃࡩࡣࡱࡲࡪࡲࡳࠨ໕"),l11l1l11l111_tv_ (u"ࠫ࡬࡫ࡴࡄࡪࡤࡲࡳ࡫࡬ࡗ࡫ࡧࡩࡴ࠭໖")]
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    return l1l1l1ll11l111_tv_
def l111111l11l111_tv_(url,data=None):
    req = urllib2.Request(url,data)
    req.add_header(l11l1l11l111_tv_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ໗"), l11l1l11l111_tv_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠹࠲࠶ࡁࠠࡳࡸ࠽࠶࠷࠴࠰ࠪࠢࡊࡩࡨࡱ࡯࠰࠴࠳࠵࠵࠶࠱࠱࠳ࠣࡊ࡮ࡸࡥࡧࡱࡻ࠳࠷࠸࠮࠱ࠩ໘"))
    try:
        response = urllib2.urlopen(req, timeout=10)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except: l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࠨ໙")
    return l11ll11ll11l111_tv_
def l1l1lll111l11l111_tv_(url, l1ll111l1ll11l111_tv_, index):
    out = l1l1l1lllll11l111_tv_(url)
    l1ll111l1ll11l111_tv_[index]=out
def l11l11l1l11l111_tv_(addheader=False):
    out=[]
    url=l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡫࡮ࡰࡺࡨ࠮ࡪࡰࡩࡳ࠴࠭໚")
    content = l111111l11l111_tv_(url)
    items=re.compile(l11l1l11l111_tv_ (u"ࠩ࠿ࡰ࡮ࠦࡩࡥ࠿ࠥࡱࡪࡴࡵ࠮࡫ࡷࡩࡲ࠳࡜ࡥ࠭ࠥࠤࡨࡲࡡࡴࡵࡀࠦ࠳࠰ࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃࡂ࠯࡭࡫ࡁࠫ໛")).findall(content)
    for h,t in items:
        out.append(l1lll1l1l1l11l111_tv_({l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩໜ"):t,l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩໝ"):t,l11l1l11l111_tv_ (u"ࠬ࡯࡭ࡨࠩໞ"):l11l1l11l111_tv_ (u"࠭ࠧໟ"),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫ໠"):h,l11l1l11l111_tv_ (u"ࠨࡩࡵࡳࡺࡶࠧ໡"):l11l1l11l111_tv_ (u"ࠩࠪ໢"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࡥࡱࡩࠪ໣"):l11l1l11l111_tv_ (u"ࠫࠬ໤"),l11l1l11l111_tv_ (u"ࠬࡩ࡯ࡥࡧࠪ໥"):l11l1l11l111_tv_ (u"࠭ࠧ໦")}))
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡺࡧ࡯ࡰࡴࡽ࡝ࡖࡲࡧࡥࡹ࡫ࡤ࠻ࠢࠨࡷࠥ࠮ࡩ࡬࡮ࡸࡦ࠮ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ໧") %time.strftime(l11l1l11l111_tv_ (u"ࠣࠧࡧ࠳ࠪࡳ࠯࡛ࠦ࠽ࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨ໨"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ໩"):t,l11l1l11l111_tv_ (u"ࠪࡸࡻ࡯ࡤࠨ໪"):l11l1l11l111_tv_ (u"ࠫࠬ໫"),l11l1l11l111_tv_ (u"ࠬ࡯࡭ࡨࠩ໬"):l11l1l11l111_tv_ (u"࠭ࠧ໭"),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫ໮"):l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡫࡮ࡰࡺࡨ࠮࡯ࡧࡷࠫ໯"),l11l1l11l111_tv_ (u"ࠩࡪࡶࡴࡻࡰࠨ໰"):l11l1l11l111_tv_ (u"ࠪࠫ໱"),l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫ໲"):l11l1l11l111_tv_ (u"ࠬ࠭໳")})
    return out
def l1l1l1lllll11l111_tv_(url=l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡩ࡬࡮ࡸࡦ࠳ࡴࡥࡵ࠱࡬ࡲ࡫ࡵ࠯ࠨ໴")):
    out=[]
    content = l111111l11l111_tv_(url)
    code=url[:-1].split(l11l1l11l111_tv_ (u"ࠧ࠰ࠩ໵"))[-1]
    l1l11l111ll11l111_tv_=content.find(l11l1l11l111_tv_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡧࡱࡸࡷࡿ࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠩ໶"))
    l1l11l11l1l11l111_tv_=content[l1l11l111ll11l111_tv_:].find(l11l1l11l111_tv_ (u"ࠩ࠱ࡩࡳࡺࡲࡺ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠪ໷"))
    content = content[l1l11l111ll11l111_tv_:l1l11l111ll11l111_tv_+l1l11l11l1l11l111_tv_]
    href=re.compile(l11l1l11l111_tv_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠾࠴࠵ࡩ࡬࡮ࡸࡦ࠳ࡴࡥࡵ࠱࠱࠮ࡄ࠯ࠢࠨ໸")).findall(content)
    title = re.compile(l11l1l11l111_tv_ (u"ࠫࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ໹")).findall(content)
    l1llll11lll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ໺")).findall(content)
    for h,t,i in zip(href,title,l1llll11lll11l111_tv_):
        t = t.replace(l11l1l11l111_tv_ (u"࠭ࡔࡦ࡮ࡨࡻ࡮ࢀࡪࡢࠢࡲࡲࡱ࡯࡮ࡦࠢ࠰ࠤࠬ໻"),l11l1l11l111_tv_ (u"ࠧࠨ໼")).replace(l11l1l11l111_tv_ (u"ࠨࡡࠪ໽"),l11l1l11l111_tv_ (u"ࠩࠣࠫ໾")).strip()
        out.append(l1lll1l1l1l11l111_tv_({l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ໿"):t,l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩༀ"):t,l11l1l11l111_tv_ (u"ࠬ࡯࡭ࡨࠩ༁"):i,l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪ༂"):h,l11l1l11l111_tv_ (u"ࠧࡨࡴࡲࡹࡵ࠭༃"):l11l1l11l111_tv_ (u"ࠨࠩ༄"),l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩ༅"):l11l1l11l111_tv_ (u"ࠪࠫ༆"),l11l1l11l111_tv_ (u"ࠫࡨࡵࡤࡦࠩ༇"):code}))
    return out
def l111l1lll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡯࡫࡭ࡷࡥ࠲࡮ࡴࡦࡰ࠱ࡷࡺࡳ࠳࠲࠵ࠩ༈")):
    l1lll1ll11l11l111_tv_=[]
    if l11l1l11l111_tv_ (u"࠭ࡩ࡬࡮ࡸࡦࠬ༉") in url:
        l1l111l1lll11l111_tv_ = l111111l11l111_tv_(url)
        l1l1lll11ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠩ࠰࠭ࡃ࠮ࡂ࠯ࡪࡨࡵࡥࡲ࡫࠾ࠨ༊")).findall(l1l111l1lll11l111_tv_)
        l1l1ll111ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨ࠮ࠫࡁࠥࠤࡦࡲࡴ࠾ࠤ࡝ࡥࡵࡧࡳࡰࡹࡼࠤࡕࡲࡡࡺࡧࡵࠦࠬ་")).findall(l1l111l1lll11l111_tv_)
        if l1l1ll111ll11l111_tv_:
            l1l11lll1ll11l111_tv_ = l111111l11l111_tv_(l1l1ll111ll11l111_tv_[0])
            l1l111lll1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠫ࠲࠯ࡅࠩ࠽࠱࡬ࡪࡷࡧ࡭ࡦࡀࠪ༌")).findall(l1l11lll1ll11l111_tv_)
            if l1l111lll1l11l111_tv_:
                l1l1lll11ll11l111_tv_.extend(l1l111lll1l11l111_tv_)
        l1l111lllll11l111_tv_ = []
        l1ll111l1ll11l111_tv_ = [[] for x in l1l1lll11ll11l111_tv_]
        for i,l1ll1l1111l11l111_tv_ in enumerate(l1l1lll11ll11l111_tv_):
            thread = threading.Thread(name=l11l1l11l111_tv_ (u"ࠪࡘ࡭ࡸࡥࡢࡦࠨࡨࠬ།")%i, target = l1l1l11111l11l111_tv_, args=[l1ll1l1111l11l111_tv_,l1ll111l1ll11l111_tv_,i])
            l1l111lllll11l111_tv_.append(thread)
            thread.start()
        while any([i.isAlive() for i in l1l111lllll11l111_tv_]): time.sleep(0.1)
        del l1l111lllll11l111_tv_[:]
        for i,l1l1l1ll11l111_tv_ in enumerate(l1ll111l1ll11l111_tv_):
            if l1l1l1ll11l111_tv_:
                l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨ༎"):l1l1l1ll11l111_tv_,l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ༏"):l11l1l11l111_tv_ (u"࠭ࡌࡪࡰ࡮ࠤࠪࡪࠧ༐")%(i+1),l11l1l11l111_tv_ (u"ࠧࡳࡧࡶࡳࡱࡼࡥࡥࠩ༑"):1})
    return l1lll1ll11l11l111_tv_
def l1l1l11111l11l111_tv_(l1ll1l1111l11l111_tv_, l1ll111l1ll11l111_tv_, index):
    out = l1l11ll11ll11l111_tv_(l1ll1l1111l11l111_tv_)
    l1ll111l1ll11l111_tv_[index]=out
def l1l11ll11ll11l111_tv_(l1ll1l1111l11l111_tv_):
    l1l11llllll11l111_tv_=l11l1l11l111_tv_ (u"ࠨࠩ༒")
    l1ll1l11l1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ༓")).findall(l1ll1l1111l11l111_tv_)
    if l1ll1l11l1l11l111_tv_:
        data=l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0])
        l1l11llllll11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(l1ll1l11l1l11l111_tv_[0],data)
    return l1l11llllll11l111_tv_
def _1l1l11l11l11l111_tv_(url=l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡰࡲࡵࡣ࠰࡬ࡲ࡫ࡵ࠯ࡴࡶࡵࡩࡦࡳ࠯ࡵࡸࡱ࠶࠹࠴ࡨࡵ࡯࡯ࠫ༔")):
    l1l11llllll11l111_tv_=l11l1l11l111_tv_ (u"ࠫࠬ༕")
    content=l111111l11l111_tv_(url)
    l1l11l1llll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠬ࡫ࡶࡢ࡮࡟ࠬࡺࡴࡥࡴࡥࡤࡴࡪࡢࠨ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࡟࠭ࡡ࠯࠻࡝ࡰࠪ༖")).findall(content)
    code = re.search(l11l1l11l111_tv_ (u"࠭࡜ࠬࠢ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠥࡢࠫࠨ༗"),content)
    code = urllib.unquote(code.group(1)) if code else l11l1l11l111_tv_ (u"ࠧࠨ༘")
    l1l11l11lll11l111_tv_ = l11l1l11l111_tv_ (u"ࠨ༙ࠩ")
    if l1l11l1llll11l111_tv_ and code:
        l1l111ll11l11l111_tv_ = urllib.unquote(l1l11l1llll11l111_tv_[0])
        _split = re.compile(l11l1l11l111_tv_ (u"ࠩࡶࡠ࠳ࡹࡰ࡭࡫ࡷࡠ࠭ࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣࠧ༚")).findall(l1l111ll11l11l111_tv_)[0]
        _1l11llll1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠪࡹࡳ࡫ࡳࡤࡣࡳࡩࡡ࠮ࡴ࡮ࡲ࡟࡟࠶ࡢ࡝ࠡ࡞࠮ࠤࡠࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢࡢࠩࠨ༛")).findall(l1l111ll11l11l111_tv_)[0]
        _1l11lll11l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡨ࡮ࡡࡳࡅࡲࡨࡪࡇࡴ࡝ࠪ࡬ࡠ࠮ࡢࠩ࡝࠭ࠫ࠲࠯ࡅࠩ࡝ࠫ࡟࠿ࠬ༜")).findall(l1l111ll11l11l111_tv_)[0]
        tmp = code.split(str(_split))
        l1l11ll111l11l111_tv_ = tmp[1] + str(_1l11llll1l11l111_tv_)
        table=[]
        for i in range(0, len(code)):
            a = ord(code[i])
            b = int(l1l11ll111l11l111_tv_[i % len(l1l11ll111l11l111_tv_)])
            table.append((b ^ a) + int(_1l11lll11l11l111_tv_))
            l1l11l11lll11l111_tv_ = l11l1l11l111_tv_ (u"ࠬ࠭༝").join(map(chr, table))
    src = re.search(l11l1l11l111_tv_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ༞"),l1l11l11lll11l111_tv_)
    if src:
        src=src.group(1)
        if src.startswith(l11l1l11l111_tv_ (u"ࠧ࠰࠱ࠪ༟")):
            src=l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀࠧ༠")+src
    else:
        src=l11l1l11l111_tv_ (u"ࠩࠪ༡")
    if l1l11l11lll11l111_tv_.find(l11l1l11l111_tv_ (u"ࠪࡺࡦࡸࠠࡢࠢࡀࠫ༢"))>0:
        a=int(re.search(l11l1l11l111_tv_ (u"ࠫࡦࠦ࠽ࠡࠪ࡞࠴࠲࠿࡝ࠬࠫࠪ༣"),l1l11l11lll11l111_tv_).group(1))
        b=int(re.search(l11l1l11l111_tv_ (u"ࠬࡨࠠ࠾ࠢࠫ࡟࠵࠳࠹࡞࠭ࠬࠫ༤"),l1l11l11lll11l111_tv_).group(1))
        c=int(re.search(l11l1l11l111_tv_ (u"࠭ࡣࠡ࠿ࠣࠬࡠ࠶࠭࠺࡟࠮࠭ࠬ༥"),l1l11l11lll11l111_tv_).group(1))
        d=int(re.search(l11l1l11l111_tv_ (u"ࠧࡥࠢࡀࠤ࠭ࡡ࠰࠮࠻ࡠ࠯࠮࠭༦"),l1l11l11lll11l111_tv_).group(1))
        f=int(re.search(l11l1l11l111_tv_ (u"ࠨࡨࠣࡁࠥ࠮࡛࠱࠯࠼ࡡ࠰࠯ࠧ༧"),l1l11l11lll11l111_tv_).group(1))
        l1l11l1ll1l11l111_tv_ = re.search(l11l1l11l111_tv_ (u"ࠩࡹࡣࡵࡧࡲࡵࠢࡀࠤࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࠻ࠨ༨"),l1l11l11lll11l111_tv_).group(1)
        l11ll11ll11l111_tv_ = l11l1l11l111_tv_ (u"ࠪࡶࡹࡳࡰ࠻࠱࠲ࠩࡩ࠴ࠥࡥ࠰ࠨࡨ࠳ࠫࡤ࠰ࠩ༩")%(a/f,b/f,c/f,d/f) + l1l11l1ll1l11l111_tv_.split(l11l1l11l111_tv_ (u"ࠫ࠴࠭༪"))[1]+l11l1l11l111_tv_ (u"ࠬ࠵ࠧ༫")+l11l1l11l111_tv_ (u"࠭ࠠࡱ࡮ࡤࡽࡵࡧࡴࡩ࠿ࠪ༬")+l1l11l1ll1l11l111_tv_.split(l11l1l11l111_tv_ (u"ࠧ࠰ࠩ༭"))[-1]
        l1l1ll1ll1l11l111_tv_=re.compile(l11l1l11l111_tv_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭༮")).findall(l1l11l11lll11l111_tv_)[-1]
        l1l1ll1ll1l11l111_tv_=l1l1ll1ll1l11l111_tv_.replace(l11l1l11l111_tv_ (u"ࠩ࠱࡮ࡸ࠭༯"),l11l1l11l111_tv_ (u"ࠪ࠲࡫ࡲࡡࡴࡪ࠱ࡷࡼ࡬ࠧ༰")).replace(l11l1l11l111_tv_ (u"ࠫࡤࡸࡥ࡮ࡱࡷࡩࠬ༱"),l11l1l11l111_tv_ (u"ࠬ࠭༲"))
        l1l11llllll11l111_tv_ = l11ll11ll11l111_tv_ + l11l1l11l111_tv_ (u"࠭ࠠࡴࡹࡩ࡙ࡷࡲ࠽ࠨ༳")+l1l1ll1ll1l11l111_tv_ + l11l1l11l111_tv_ (u"ࠧࠡࡵࡺࡪ࡛࡬ࡹ࠾࠳ࠣࡰ࡮ࡼࡥ࠾࠳ࠣࡸ࡮ࡳࡥࡰࡷࡷࡁ࠶࠹ࠠࡱࡣࡪࡩ࡚ࡸ࡬࠾ࠩ༴")+url
    elif l11l1l11l111_tv_ (u"ࠨࡵࡷࡥࡹ࡯ࡣ࠯ࡷ࠰ࡴࡷࡵ࠮ࡧࡴ༵ࠪ") in src:
        source = re.compile(l11l1l11l111_tv_ (u"ࠩࡶࡳࡺࡸࡣࡦ࠿ࠫࡶࡹࡳࡰ࠯ࠬࡂ࡟ࡣࠬ࡝ࠫࠫࠪ༶")).findall(src)
        if source:
            l1l11llllll11l111_tv_=source[0]
    else:
        data = l111111l11l111_tv_(src)
        l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src,l1l11l11lll11l111_tv_.replace(l11l1l11l111_tv_ (u"ࠪࡠࡡ༷࠭"),l11l1l11l111_tv_ (u"ࠫࠬ༸")))
        if l1ll11lll1l11l111_tv_:
            l1l11llllll11l111_tv_=l1ll11lll1l11l111_tv_
        elif data:
            idx = data.find(l11l1l11l111_tv_ (u"ࠬࡏ࡮ࡪࡶ࡬ࡥࡱ࡯ࡺࡦࠢࡳࡰࡦࡿࡥࡳ༹ࠩ"))
            if idx<0:
                src = re.search(l11l1l11l111_tv_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ༺"),data)
                if src:
                    src=src.group(1)
                    if src.startswith(l11l1l11l111_tv_ (u"ࠧ࠰࠱ࠪ༻")):
                        src=l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀࠧ༼")+src
                    data = l111111l11l111_tv_(src)
                    idx = data.find(l11l1l11l111_tv_ (u"ࠩࡌࡲ࡮ࡺࡩࡢ࡮࡬ࡾࡪࠦࡰ࡭ࡣࡼࡩࡷ࠭༽"))
            data = data[idx:]
            l1l1ll1ll1l11l111_tv_ = re.search(l11l1l11l111_tv_ (u"ࠪࠦ࡫ࡲࡡࡴࡪࡳࡰࡦࡿࡥࡳࠤ࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ༾"),data)
            if l1l1ll1ll1l11l111_tv_:
                l1l1ll1ll1l11l111_tv_=l1l1ll1ll1l11l111_tv_.group(1)
                if l1l1ll1ll1l11l111_tv_.startswith(l11l1l11l111_tv_ (u"ࠫ࠴࠵ࠧ༿")):
                    l1l1ll1ll1l11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫཀ")+l1l1ll1ll1l11l111_tv_
            file = re.search(l11l1l11l111_tv_ (u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࠭࡝࡟ࡲࡡࡺࠠ࡞࠭ࠥࡸࡾࡶࡥࠣࠩཁ"),data)
            if file:
                file=file.group(1)
                if file.endswith(l11l1l11l111_tv_ (u"ࠧ࡮࠵ࡸ࠼ࠬག")):
                    l1l11llllll11l111_tv_ = file
                else:
                    l1l11llllll11l111_tv_ = file + l11l1l11l111_tv_ (u"ࠨࠢࡶࡻ࡫࡛ࡲ࡭࠿ࠪགྷ")+l1l1ll1ll1l11l111_tv_ + l11l1l11l111_tv_ (u"ࠩࠣࡷࡼ࡬ࡖࡧࡻࡀ࠵ࠥࡲࡩࡷࡧࡀ࠵ࠥࡺࡩ࡮ࡧࡲࡹࡹࡃ࠱࠴ࠢࡳࡥ࡬࡫ࡕࡳ࡮ࡀࠫང")+url
    return l1l11llllll11l111_tv_
def l1l11l1l11l11l111_tv_(out,):
    l1l11ll1lll11l111_tv_=[]
    for l1l1l1ll11l111_tv_ in out:
        print l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩཅ")),l11l1l11l111_tv_ (u"ࠫ࠿ࠦࠧཆ"),l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩཇ"),l11l1l11l111_tv_ (u"࠭ࠧ཈"))
        l1ll11lll1l11l111_tv_ = l1l11l1111l11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫཉ"),l11l1l11l111_tv_ (u"ࠨࠩཊ")))
        if l1ll11lll1l11l111_tv_:
            l1l11l1l1ll11l111_tv_ (u"ࠩ࡟ࡸࠬཋ"),l1ll11lll1l11l111_tv_
            l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧཌ")]=l1ll11lll1l11l111_tv_
            l1l11ll1lll11l111_tv_.append(l1l1l1ll11l111_tv_)
    return l1l11ll1lll11l111_tv_
def l11l1l1ll11l111_tv_(out,fname=l11l1l11l111_tv_ (u"ࠫ࡮ࡱ࡬ࡶࡤ࠱ࡱ࠸ࡻࠧཌྷ")):
    l1lllllllll11l111_tv_=l11l1l11l111_tv_ (u"ࠬࠩࡅ࡙ࡖࡌࡒࡋࡀ࠭࠲ࠢࡷࡺ࡬࠳ࡩࡥ࠿ࠥࡿࡹࡼࡩࡥࡿࠥࠤࡹࡼࡧ࠮࡮ࡲ࡫ࡴࡃࠢࡼ࡫ࡰ࡫ࢂࠨࠠࡶࡴ࡯࠱ࡪࡶࡧ࠾ࠤࡾࡹࡷࡲࡥࡱࡩࢀࠦࠥ࡭ࡲࡰࡷࡳ࠱ࡹ࡯ࡴ࡭ࡧࡀࠦࢀ࡭ࡲࡰࡷࡳࢁࠧ࠲ࡻࡵ࡫ࡷࡰࡪࢃ࡜࡯ࡽࡸࡶࡱࢃ࡜࡯࡞ࡱࠫཎ")
    l1l11ll1l1l11l111_tv_=l11l1l11l111_tv_ (u"࠭ࠣࡆ࡚ࡗࡑ࠸࡛࡜࡯ࠩཏ")
    for l1l1l1ll11l111_tv_ in out:
        l1l11ll1l1l11l111_tv_=l1l11ll1l1l11l111_tv_+l1lllllllll11l111_tv_.format(**l1l1l1ll11l111_tv_)
    l1l111ll1ll11l111_tv_ = open(fname,l11l1l11l111_tv_ (u"ࠧࡸࠩཐ"))
    l1l111ll1ll11l111_tv_.write(l1l11ll1l1l11l111_tv_)
    l1l111ll1ll11l111_tv_.close()
def test():
    out=l11l11l1l11l111_tv_(addheader=False)
    for l1l1l1ll11l111_tv_ in out:
        print l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧད")),l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭དྷ")),l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠪ࡭ࡲ࡭ࠧན"))
        l1ll11lll1l11l111_tv_ = l111l1lll11l111_tv_(url=l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨཔ")))
        print l1ll11lll1l11l111_tv_
