# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re
import time
import l1ll11ll1ll11l111_tv_
import cookielib
import urlparse
import threading
import l1ll1ll111l11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷࡩࡱ࡫࠭ࡸ࡫ࡽ࡮ࡦ࠴ࡩࡴ࠱ࠪᦡ")
l1lll1l1lll11l111_tv_ = l11l1l11l111_tv_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠶࠯࠳࠾ࠤࡷࡼ࠺࠳࠴࠱࠴࠮ࠦࡇࡦࡥ࡮ࡳ࠴࠸࠰࠲࠲࠳࠵࠵࠷ࠠࡇ࡫ࡵࡩ࡫ࡵࡸ࠰࠴࠵࠲࠵࠭ᦢ")
l1lll1ll1ll11l111_tv_=15
__all__=[l11l1l11l111_tv_ (u"ࠫ࡬࡫ࡴࡄࡪࡤࡲࡳ࡫࡬ࡴࠩᦣ"),l11l1l11l111_tv_ (u"ࠬ࡭ࡥࡵࡅ࡫ࡥࡳࡴࡥ࡭ࡘ࡬ࡨࡪࡵࠧᦤ")]
fix={
 l11l1l11l111_tv_ (u"࠭ࡴࡷࡲ࠴ࠫᦥ"):l11l1l11l111_tv_ (u"ࠧࡕࡘࡓࠤ࠶࠭ᦦ"),
 l11l1l11l111_tv_ (u"ࠨࡶࡹࡴ࡭ࡪࠧᦧ"): l11l1l11l111_tv_ (u"ࠩࡗ࡚ࡕࠦࡈࡅࠩᦨ"),
 l11l1l11l111_tv_ (u"ࠪࡸࡻࡴ࠷ࠨᦩ"):l11l1l11l111_tv_ (u"࡙ࠫ࡜ࡎࠡ࠹ࠪᦪ"),
 l11l1l11l111_tv_ (u"ࠬࡶ࡯࡭ࡵࠪᦫ"):l11l1l11l111_tv_ (u"࠭ࡐࡰ࡮ࡶࡥࡹ࠭᦬"),
 l11l1l11l111_tv_ (u"ࠧࡢࡰ࡬ࡱࡦࡲࡰ࡭ࡣࡱࡩࡹ࠭᦭"): l11l1l11l111_tv_ (u"ࠨࡃࡱ࡭ࡲࡧ࡬ࠡࡒ࡯ࡥࡳ࡫ࡴࠨ᦮"),
 l11l1l11l111_tv_ (u"ࠩࡥࡳࡴࡳࡥࡳࡣࡱ࡫ࠬ᦯"): l11l1l11l111_tv_ (u"ࠪࡆࡴࡵ࡭ࡦࡴࡤࡲ࡬࠭ᦰ"),
 l11l1l11l111_tv_ (u"ࠫࡨࡧ࡮ࡢ࡮ࠪᦱ"): l11l1l11l111_tv_ (u"ࠬࡉࡡ࡯ࡣ࡯࠯ࠬᦲ"),
 l11l1l11l111_tv_ (u"࠭ࡣࡢࡰࡤࡰࡩ࡯ࡳࡤࡱࡹࡩࡷࡿࠧᦳ"): l11l1l11l111_tv_ (u"ࠧࡄࡣࡱࡥࡱ࠱ࠠࡅ࡫ࡶࡧࡴࡼࡥࡳࡻࠣࡌࡉ࠭ᦴ"),
 l11l1l11l111_tv_ (u"ࠨࡥࡤࡲࡦࡲࡦࡢ࡯࡬ࡰࡾ࠭ᦵ"): l11l1l11l111_tv_ (u"ࠩࡆࡥࡳࡧ࡬ࠬࠢࡉ࡭ࡱࡳࠧᦶ"),
 l11l1l11l111_tv_ (u"ࠪࡧࡦࡴࡡ࡭ࡵࡳࡳࡷࡺࠧᦷ"): l11l1l11l111_tv_ (u"ࠫࡈࡧ࡮ࡢ࡮࠮ࠤࡘࡶ࡯ࡳࡶࠪᦸ"),
 l11l1l11l111_tv_ (u"ࠬࡩࡡ࡯ࡣ࡯ࡷࡵࡵࡲࡵ࠴ࠪᦹ"): l11l1l11l111_tv_ (u"࠭ࡃࡢࡰࡤࡰ࠰ࠦࡓࡱࡱࡵࡸࠥ࠸ࠧᦺ"),
 l11l1l11l111_tv_ (u"ࠧࡤࡣࡵࡸࡴࡵ࡮ࠨᦻ"): l11l1l11l111_tv_ (u"ࠨࡅࡤࡶࡹࡵ࡯࡯ࠢࡑࡩࡹࡽ࡯ࡳ࡭ࠪᦼ"),
 l11l1l11l111_tv_ (u"ࠩࡦࡪ࡮ࡲ࡭ࠨᦽ"): l11l1l11l111_tv_ (u"ࠪࡇࡦࡴࡡ࡭࠭ࠣࡊ࡮ࡲ࡭ࠨᦾ"),
 l11l1l11l111_tv_ (u"ࠫࡨ࡯࡮ࡦ࡯ࡤࡼࠬᦿ"): l11l1l11l111_tv_ (u"ࠬࡉࡩ࡯ࡧࡰࡥࡽ࠭ᧀ"),
 l11l1l11l111_tv_ (u"࠭ࡣࡰ࡯ࡨࡨࡾࡩࡥ࡯ࡶࡨࡶࠬᧁ"): l11l1l11l111_tv_ (u"ࠧࡄࡱࡰࡩࡩࡿࠠࡄࡧࡱࡸࡷࡧ࡬ࠨᧂ"),
 l11l1l11l111_tv_ (u"ࠨࡦ࡬ࡷࡨࡵࡶࡦࡴࡼࠫᧃ"): l11l1l11l111_tv_ (u"ࠩࡇ࡭ࡸࡩ࡯ࡷࡧࡵࡽࠥࡉࡨࡢࡰࡱࡩࡱ࠭ᧄ"),
 l11l1l11l111_tv_ (u"ࠪࡨ࡮ࡹࡣࡰࡸࡨࡶࡾ࡮ࡩࡴࡶࡲࡶ࡮ࡧࠧᧅ"): l11l1l11l111_tv_ (u"ࠫࡉ࡯ࡳࡤࡱࡹࡩࡷࡿࠠࡉ࡫ࡶࡸࡴࡸࡩࡢࠩᧆ"),
 l11l1l11l111_tv_ (u"ࠬࡪࡩࡴࡥࡲࡺࡪࡸࡹ࡭࡫ࡩࡩࠬᧇ"): l11l1l11l111_tv_ (u"࠭ࡄࡪࡵࡦࡳࡻ࡫ࡲࡺࠢࡏ࡭࡫࡫ࠧᧈ"),
 l11l1l11l111_tv_ (u"ࠧࡥ࡫ࡶࡧࡴࡼࡥࡳࡻࡶࠫᧉ"): l11l1l11l111_tv_ (u"ࠨࡆ࡬ࡷࡨࡵࡶࡦࡴࡼࠤࡘࡩࡩࡦࡰࡦࡩࠬ᧊"),
 l11l1l11l111_tv_ (u"ࠩࡧ࡭ࡸࡴࡥࡺ࠯ࡦ࡬ࡦࡴ࡮ࡦ࡮ࠪ᧋"): l11l1l11l111_tv_ (u"ࠪࡈ࡮ࡹ࡮ࡦࡻࠣࡇ࡭ࡧ࡮࡯ࡧ࡯ࠫ᧌"),
 l11l1l11l111_tv_ (u"ࠫࡪࡲࡥࡷࡧࡱࠫ᧍"): l11l1l11l111_tv_ (u"ࠬࡋ࡬ࡦࡸࡨࡲࠬ᧎"),
 l11l1l11l111_tv_ (u"࠭ࡥ࡭ࡧࡹࡩࡳࡹࡰࡰࡴࡷࠫ᧏"): l11l1l11l111_tv_ (u"ࠧࡆ࡮ࡨࡺࡪࡴࠠࡔࡲࡲࡶࡹࡹࠧ᧐"),
 l11l1l11l111_tv_ (u"ࠨࡧࡸࡶࡴࡹࡰࡰࡴࡷࠫ᧑"): l11l1l11l111_tv_ (u"ࠩࡈࡹࡷࡵࡳࡱࡱࡵࡸࠬ᧒"),
 l11l1l11l111_tv_ (u"ࠪࡩࡺࡸ࡯ࡴࡲࡲࡶࡹ࠸ࠧ᧓"): l11l1l11l111_tv_ (u"ࠫࡊࡻࡲࡰࡵࡳࡳࡷࡺࠠ࠳ࠩ᧔"),
 l11l1l11l111_tv_ (u"ࠬ࡬࡯ࡹࠩ᧕"): l11l1l11l111_tv_ (u"࠭ࡆࡰࡺࠪ᧖"),
 l11l1l11l111_tv_ (u"ࠧࡩ࠴ࠣࠫ᧗"): l11l1l11l111_tv_ (u"ࠨࡊ࡬ࡷࡹࡵࡲࡺࠢ࠵ࠤࠬ᧘"),
 l11l1l11l111_tv_ (u"ࠩ࡫ࡦࡴ࠭᧙"): l11l1l11l111_tv_ (u"ࠪࡌࡇࡕࠧ᧚"),
 l11l1l11l111_tv_ (u"ࠫ࡭ࡨ࡯࠳ࠩ᧛"): l11l1l11l111_tv_ (u"ࠬࡎࡂࡐ࠴ࠪ᧜"),
 l11l1l11l111_tv_ (u"࠭ࡨࡣࡱ࠶ࠫ᧝"): l11l1l11l111_tv_ (u"ࠧࡉࡄࡒ࠷ࠬ᧞"),
 l11l1l11l111_tv_ (u"ࠨ࡫ࡧࠫ᧟"): l11l1l11l111_tv_ (u"ࠩࡌࡈࠬ᧠"),
 l11l1l11l111_tv_ (u"ࠪ࡯࡮ࡴ࡯ࡱࡱ࡯ࡷࡰࡧࠧ᧡"): l11l1l11l111_tv_ (u"ࠫࡐ࡯࡮ࡰࠢࡓࡳࡱࡹ࡫ࡢࠩ᧢"),
 l11l1l11l111_tv_ (u"ࠬࡱࡵࡤࡪࡨࡲࡪ࠭᧣"): l11l1l11l111_tv_ (u"࠭ࡋࡶࡥ࡫ࡲ࡮ࡧࠫࠨ᧤"),
 l11l1l11l111_tv_ (u"ࠧ࡮࡫ࡱ࡭ࡲ࡯࡮ࡪࠩ᧥"): l11l1l11l111_tv_ (u"ࠨࡏ࡬ࡲ࡮ࡳࡩ࡯࡫࠮ࠫ᧦"),
 l11l1l11l111_tv_ (u"ࠩࡱࡥࡹ࡭ࡥࡰࠩ᧧"): l11l1l11l111_tv_ (u"ࠪࡒࡦࡺࡩࡰࡰࡤࡰࠥࡍࡥࡰࡩࡵࡥࡵ࡮ࡩࡤࠢࡆ࡬ࡦࡴ࡮ࡦ࡮ࠪ᧨"),
 l11l1l11l111_tv_ (u"ࠫࡳࡧࡴࡨࡧࡲࡻ࡮ࡲࡤࠨ᧩"): l11l1l11l111_tv_ (u"ࠬࡔࡡࡵࠢࡊࡩࡴࠦࡗࡪ࡮ࡧࠫ᧪"),
 l11l1l11l111_tv_ (u"࠭࡮ࡴࡲࡲࡶࡹ࠭᧫"): l11l1l11l111_tv_ (u"ࠧ࡯ࡕࡳࡳࡷࡺࠧ᧬"),
 l11l1l11l111_tv_ (u"ࠨࡵࡷࡳࡵࡱ࡬ࡢࡶ࡮ࡥࠬ᧭"): l11l1l11l111_tv_ (u"ࠩࡖࡸࡴࡶ࡫࡭ࡣࡷ࡯ࡦࠦࡔࡗࠩ᧮"),
 l11l1l11l111_tv_ (u"ࠪࡸࡱࡩࠧ᧯"): l11l1l11l111_tv_ (u"࡙ࠫࡒࡃࠨ᧰"),
 l11l1l11l111_tv_ (u"ࠬࡺࡶ࡯ࠩ᧱"): l11l1l11l111_tv_ (u"࠭ࡔࡗࡐࠪ᧲"),
 l11l1l11l111_tv_ (u"ࠧࡵࡸࡱ࠶࠹࠭᧳"): l11l1l11l111_tv_ (u"ࠨࡖ࡙ࡒࠥ࠸࠴ࠨ᧴"),
 l11l1l11l111_tv_ (u"ࠩࡷࡺࡳ࠸࠴ࡣ࡫ࡶࠫ᧵"): l11l1l11l111_tv_ (u"ࠪࡘ࡛ࡔࠠ࠳࠶ࠣࡆࡎ࡙ࠧ᧶"),
 l11l1l11l111_tv_ (u"ࠫࡹࡼ࡮࠸ࠩ᧷"): l11l1l11l111_tv_ (u"࡚ࠬࡖࡏࠢ࠺ࠫ᧸"),
 l11l1l11l111_tv_ (u"࠭ࡴࡷࡰࡶࡸࡾࡲࡥࠨ᧹"): l11l1l11l111_tv_ (u"ࠧࡕࡘࡑࠤࡘࡺࡹ࡭ࡧࠪ᧺"),
 l11l1l11l111_tv_ (u"ࠨࡶࡹࡲࡹࡻࡲࡣࡱࠪ᧻"): l11l1l11l111_tv_ (u"ࠩࡗ࡚ࡓࠦࡔࡶࡴࡥࡳࠬ᧼"),
 l11l1l11l111_tv_ (u"ࠪࡸࡻࡶ࠱ࠨ᧽"): l11l1l11l111_tv_ (u"࡙ࠫ࡜ࡐࠡ࠳ࠪ᧾"),
 l11l1l11l111_tv_ (u"ࠬࡺࡶࡱ࠴ࠪ᧿"): l11l1l11l111_tv_ (u"࠭ࡔࡗࡒࠣ࠶ࠬᨀ"),
 l11l1l11l111_tv_ (u"ࠧࡵࡸࡳ࡬ࡩ࠭ᨁ"): l11l1l11l111_tv_ (u"ࠨࡖ࡙ࡔࠥࡎࡄࠨᨂ"),
 l11l1l11l111_tv_ (u"ࠩࡷࡺࡵ࡯࡮ࡧࡱ࠴ࠫᨃ"): l11l1l11l111_tv_ (u"ࠪࡘ࡛ࡖࠠࡊࡰࡩࡳࠬᨄ"),
 l11l1l11l111_tv_ (u"ࠫࡹࡼࡰࡴࡧࡵ࡭ࡦࡲࡥࠨᨅ"): l11l1l11l111_tv_ (u"࡚ࠬࡖࡑࠢࡖࡩࡷ࡯ࡡ࡭ࡧࠪᨆ"),
 l11l1l11l111_tv_ (u"࠭ࡴࡷࡲࡶࡴࡴࡸࡴࠨᨇ"): l11l1l11l111_tv_ (u"ࠧࡕࡘࡓࠤࡘࡶ࡯ࡳࡶࠪᨈ"),
 l11l1l11l111_tv_ (u"ࠨࡶࡹࡴࡺࡲࡳࠨᨉ"): l11l1l11l111_tv_ (u"ࠩࡗ࡚ࠥࡖࡵ࡭ࡵࠪᨊ"),
 l11l1l11l111_tv_ (u"ࠪࡸࡻࡸࡥࡱࡷࡥࡰ࡮ࡱࡡࠨᨋ"): l11l1l11l111_tv_ (u"࡙ࠫ࡜ࠠࡓࡧࡳࡹࡧࡲࡩ࡬ࡣࠪᨌ"),
 l11l1l11l111_tv_ (u"ࠬࡾࡴࡳࡣࠪᨍ"): l11l1l11l111_tv_ (u"࠭ࡄࡪࡵࡦࡳࡻ࡫ࡲࡺࠢࡗࡹࡷࡨ࡯࡚ࠡࡷࡶࡦ࠭ᨎ"),
 l11l1l11l111_tv_ (u"ࠧࡱࡵࠪᨏ"):l11l1l11l111_tv_ (u"ࠨࡒࡲࡰࡸࡧࡴࠡࡕࡳࡳࡷࡺࠧᨐ"),
 l11l1l11l111_tv_ (u"ࠩࡳࡷࡳ࠭ᨑ"):l11l1l11l111_tv_ (u"ࠪࡔࡴࡲࡳࡢࡶࠣࡗࡵࡵࡲࡵࠢࡑࡩࡼࡹࠧᨒ"),
 l11l1l11l111_tv_ (u"ࠫࡵࡹࡥࠨᨓ"):l11l1l11l111_tv_ (u"ࠬࡖ࡯࡭ࡵࡤࡸ࡙ࠥࡰࡰࡴࡷࠤࡊࡾࡴࡳࡣࠪᨔ"),
 l11l1l11l111_tv_ (u"࠭ࡳࡶࡲࡨࡶࡸࡺࡡࡤ࡬ࡤࠫᨕ"):l11l1l11l111_tv_ (u"ࠧࡔࡷࡳࡩࡷࡹࡴࡢࡥ࡭ࡥࠬᨖ"),
 l11l1l11l111_tv_ (u"ࠨࡲࡲࡰࡸ࠭ᨗ"):l11l1l11l111_tv_ (u"ࠩࡓࡳࡱࡹࡡࡵᨘࠩ"),
 l11l1l11l111_tv_ (u"ࠪࡸࡻࡼ࠴ࠨᨙ"):l11l1l11l111_tv_ (u"࡙ࠫ࡜ࠠ࠵ࠩᨚ"),
 l11l1l11l111_tv_ (u"ࠬࡶ࡯࡭ࡵ࠵ࠫᨛ"):l11l1l11l111_tv_ (u"࠭ࡐࡰ࡮ࡶࡥࡹࠦ࠲ࠨ᨜"),
 l11l1l11l111_tv_ (u"ࠧࡱࡱ࡯ࡷࡦࡺࡣࡢࡨࡨࠫ᨝"):l11l1l11l111_tv_ (u"ࠨࡒࡲࡰࡸࡧࡴࠡࡅࡤࡪࡪ࠭᨞"),
 l11l1l11l111_tv_ (u"ࠩࡳࡳࡱࡹࡡࡵࡲ࡯ࡥࡾ࠭᨟"):l11l1l11l111_tv_ (u"ࠪࡔࡴࡲࡳࡢࡶࠣࡔࡱࡧࡹࠨᨠ"),
 l11l1l11l111_tv_ (u"ࠫࡵࡵ࡬ࡴࡣࡷࡪ࡮ࡲ࡭ࠨᨡ"):l11l1l11l111_tv_ (u"ࠬࡖ࡯࡭ࡵࡤࡸࠥࡌࡩ࡭࡯ࠪᨢ"),
 l11l1l11l111_tv_ (u"࠭ࡰࡰ࡮ࡶࡥࡹࡴࡡࡵࡷࡵࡩࠬᨣ"):l11l1l11l111_tv_ (u"ࠧࡑࡱ࡯ࡷࡦࡺࠠࡏࡣࡷࡹࡷ࡫ࠧᨤ"),
 l11l1l11l111_tv_ (u"ࠨࡲࡲࡰࡸࡧࡴࡩ࡫ࡶࡸࡴࡸࡹࠨᨥ"):l11l1l11l111_tv_ (u"ࠩࡓࡳࡱࡹࡡࡵࠢࡋ࡭ࡸࡺ࡯ࡳࡻࠪᨦ"),
 l11l1l11l111_tv_ (u"ࠪࡴࡴࡲࡳࡢࡶࡨࡼࡵࡲ࡯ࡳࡧࠪᨧ"):l11l1l11l111_tv_ (u"ࠫࡕࡵ࡬ࡴࡣࡷࠤࡊࡾࡰ࡭ࡱࡵࡩࠬᨨ"),
 l11l1l11l111_tv_ (u"ࠬࡶ࡯࡭ࡵࡤࡸ࡫ࡵ࡯ࡥࠩᨩ"):l11l1l11l111_tv_ (u"࠭ࡐࡰ࡮ࡶࡥࡹࠦࡆࡰࡱࡧࠫᨪ"),
 l11l1l11l111_tv_ (u"ࠧࡱࡵࡩࠫᨫ"):l11l1l11l111_tv_ (u"ࠨࡒࡲࡰࡸࡧࡴࠡࡕࡳࡳࡷࡺࠠࡇ࡫ࡪ࡬ࡹ࠭ᨬ"),
 l11l1l11l111_tv_ (u"ࠩࡶࡹࡵ࡫ࡲࡱࡱ࡯ࡷࡦࡺࠧᨭ"):l11l1l11l111_tv_ (u"ࠪࡗࡺࡶࡥࡳࠢࡓࡳࡱࡹࡡࡵࠩᨮ"),
 l11l1l11l111_tv_ (u"ࠫࡼࡶࡴࡷࠩᨯ"):l11l1l11l111_tv_ (u"ࠬ࡝ࡐࡕࡘࠪᨰ"),
 l11l1l11l111_tv_ (u"࠭ࡰࡰ࡮ࡱࡩࡼࡹࠧᨱ"):l11l1l11l111_tv_ (u"ࠧࡑࡱ࡯ࡷࡦࡺࠠࡏࡧࡺࡷࠬᨲ"),
 l11l1l11l111_tv_ (u"ࠨࡲࡲࡰࡸࡧࡴ࡯ࡧࡺࡷ࠷࠭ᨳ"):l11l1l11l111_tv_ (u"ࠩࡓࡳࡱࡹࡡࡵࠢࡑࡩࡼࡹࠠ࠳ࠩᨴ"),
 l11l1l11l111_tv_ (u"ࠪࡸࡻࡺࡲࡸࡣࡰࠫᨵ"):l11l1l11l111_tv_ (u"࡙ࠫ࡜ࠠࡕࡴࡺࡥࡲ࠭ᨶ"),
 l11l1l11l111_tv_ (u"ࠬࡩࡡ࡯ࡣ࡯ࡷࡪࡸࡩࡢ࡮ࡨࠫᨷ"): l11l1l11l111_tv_ (u"࠭ࡃࡢࡰࡤࡰ࠰ࠦࡓࡦࡴ࡬ࡥࡱ࡫ࠧᨸ"),
 l11l1l11l111_tv_ (u"ࠧ࠲࠵ࡸࡰ࡮ࡩࡡࠨᨹ"):l11l1l11l111_tv_ (u"ࠨ࠳࠶ࠤ࡚ࡲࡩࡤࡣࠪᨺ"),
 l11l1l11l111_tv_ (u"ࠩࡩ࡭ࡱࡳࡢࡰࡺࠪᨻ"):l11l1l11l111_tv_ (u"ࠪࡊ࡮ࡲ࡭ࡣࡱࡻࠫᨼ"),
 l11l1l11l111_tv_ (u"ࠫ࡫࡯࡬࡮ࡤࡲࡼࡪࡾࡴࡳࡣࠪᨽ"):l11l1l11l111_tv_ (u"ࠬࡌࡩ࡭࡯ࡥࡳࡽࠦࡅࡹࡶࡵࡥࠬᨾ"),
 l11l1l11l111_tv_ (u"࠭ࡦࡪ࡮ࡰࡦࡴࡾࡰࡳࡧࡰ࡭ࡺࡳࠧᨿ"):l11l1l11l111_tv_ (u"ࠧࡇ࡫࡯ࡱࡧࡵࡸࠡࡒࡵࡩࡲ࡯ࡵ࡮ࠩᩀ"),
 l11l1l11l111_tv_ (u"ࠨࡨ࡬ࡰࡲࡨ࡯ࡹࡧࡻࡸࡷࡧࠧᩁ"):l11l1l11l111_tv_ (u"ࠩࡉ࡭ࡱࡳࡢࡰࡺࠣࡉࡽࡺࡲࡢࠩᩂ"),
 l11l1l11l111_tv_ (u"ࠪࡪ࡮ࡲ࡭ࡣࡱࡻࡥࡨࡺࡩࡰࡰࠪᩃ"):l11l1l11l111_tv_ (u"ࠫࡋ࡯࡬࡮ࡤࡲࡼࠥࡇࡣࡵ࡫ࡲࡲࠬᩄ"),
 l11l1l11l111_tv_ (u"ࠬ࡬ࡩ࡭࡯ࡥࡳࡽ࡬ࡡ࡮࡫࡯ࡽࠬᩅ"):l11l1l11l111_tv_ (u"࠭ࡆࡪ࡮ࡰࡦࡴࡾࠠࡇࡣࡰ࡭ࡱࡿࠧᩆ"),
 l11l1l11l111_tv_ (u"ࠧࡢࡺࡱࠫᩇ"):l11l1l11l111_tv_ (u"ࠣࡃ࡛ࡒࠧᩈ"),
 l11l1l11l111_tv_ (u"ࠩࡤࡼࡳࡹࡰࡪࡰࠪᩉ"):l11l1l11l111_tv_ (u"ࠪࡅ࡝ࡔࠠࡔࡲ࡬ࡲࠬᩊ"),
 l11l1l11l111_tv_ (u"ࠫࡦࡾ࡮ࡣ࡮ࡤࡧࡰ࠭ᩋ"):l11l1l11l111_tv_ (u"ࠬࡇࡘࡏࠢࡅࡰࡦࡩ࡫ࠨᩌ"),
 l11l1l11l111_tv_ (u"࠭ࡡࡹࡰࡺ࡬࡮ࡺࡥࠨᩍ"):l11l1l11l111_tv_ (u"ࠧࡂ࡚ࡑࠤ࡜࡮ࡩࡵࡧࠪᩎ"),
 l11l1l11l111_tv_ (u"ࠨࡥࡥࡷࡷ࡫ࡡ࡭࡫ࡷࡽࠬᩏ"):l11l1l11l111_tv_ (u"ࠩࡆࡆࡘࠦࡒࡦࡣ࡯࡭ࡹࡿࠧᩐ"),
 l11l1l11l111_tv_ (u"ࠪࡧࡧࡹࡡࡤࡶ࡬ࡳࡳ࠭ᩑ"):l11l1l11l111_tv_ (u"ࠫࡈࡈࡓࠡࡃࡦࡸ࡮ࡵ࡮ࠨᩒ"),
 l11l1l11l111_tv_ (u"ࠬࡩࡢࡴࡧࡸࡶࡴࡶࡡࠨᩓ"):l11l1l11l111_tv_ (u"࠭ࡃࡃࡕࠣࡉࡺࡸ࡯ࡱࡣࠪᩔ"),
 l11l1l11l111_tv_ (u"ࠧࡱࡣࡵࡥࠬᩕ"):l11l1l11l111_tv_ (u"ࠨࡒࡤࡶࡦࡳ࡯ࡶࡰࡷࠤࡈ࡮ࡡ࡯ࡰࡨࡰࠬᩖ"),
 l11l1l11l111_tv_ (u"ࠩࡷࡲࡹ࠭ᩗ"):l11l1l11l111_tv_ (u"ࠪࡘࡓ࡚ࠧᩘ"),
 l11l1l11l111_tv_ (u"ࠫ࡫ࡵࡸࡤࡱࡰࡩࡩࡿࠧᩙ"):l11l1l11l111_tv_ (u"ࠬࡌ࡯ࡹࠢࡆࡳࡲ࡫ࡤࡺࠩᩚ"),
 l11l1l11l111_tv_ (u"࠭ࡳࡤࡨ࡬࠵ࠬᩛ"):l11l1l11l111_tv_ (u"ࠧࡔࡥ࡬ࡊ࡮ࠦࡕ࡯࡫ࡹࡩࡷࡹࡡ࡭ࠩᩜ"),
 l11l1l11l111_tv_ (u"ࠨࡷࡱ࡭ࡻ࡫ࡲࡴࡣ࡯ࠫᩝ"):l11l1l11l111_tv_ (u"ࠩࡘࡲ࡮ࡼࡥࡳࡵࡤࡰࠥࡎࡄࠨᩞ"),
 l11l1l11l111_tv_ (u"ࠪࡦࡧࡩࠧ᩟"):l11l1l11l111_tv_ (u"ࠫࡇࡈࡃࠡࡊࡇ᩠ࠫ"),
 l11l1l11l111_tv_ (u"ࠬࡨࡢࡤࡧࡤࡶࡹ࡮ࠧᩡ"):l11l1l11l111_tv_ (u"࠭ࡂࡃࡅࠣࡉࡦࡸࡴࡩࠩᩢ"),
 l11l1l11l111_tv_ (u"ࠧࡩ࡫ࡶࡸࡴࡸࡹࠨᩣ"):l11l1l11l111_tv_ (u"ࠨࡊ࡬ࡷࡹࡵࡲࡺࠩᩤ"),
 l11l1l11l111_tv_ (u"ࠩࡩࡳࡨࡻࡳࡵࡸࠪᩥ"):l11l1l11l111_tv_ (u"ࠪࡊࡴࡱࡵࡴࠢࡗ࡚ࠬᩦ"),
 l11l1l11l111_tv_ (u"ࠫࡪࡲࡥࡷࡧࡱࡩࡽࡺࡲࡢࠩᩧ"):l11l1l11l111_tv_ (u"ࠬࡋ࡬ࡦࡸࡨࡲ࡙ࠥࡰࡰࡴࡷࡷࠬᩨ"),
 l11l1l11l111_tv_ (u"࠭ࡥࡹࡶࡵࡩࡲ࡫ࡳࡱࡱࡵࡸࡸ࠭ᩩ"):l11l1l11l111_tv_ (u"ࠧࡆࡺࡷࡶࡪࡳࡥࠡࡕࡳࡳࡷࡺࡳࠨᩪ"),
 l11l1l11l111_tv_ (u"ࠨࡶࡵࡥࡻ࡫࡬ࡤࡪࡤࡲࡳ࡫࡬ࠨᩫ"):l11l1l11l111_tv_ (u"ࠩࡗࡶࡦࡼࡥ࡭ࠢࡆ࡬ࡦࡴ࡮ࡦ࡮ࠪᩬ"),
 l11l1l11l111_tv_ (u"ࠪࡨ࡮ࡹ࡮ࡦࡻࡻࡨࠬᩭ"):l11l1l11l111_tv_ (u"ࠫࡉ࡯ࡳ࡯ࡧࡼࠤ࡝ࡊࠧᩮ"),
 l11l1l11l111_tv_ (u"ࠬࡪࡩࡴࡰࡨࡽ࡯ࡻ࡮ࡪࡱࡵࠫᩯ"):l11l1l11l111_tv_ (u"࠭ࡄࡪࡵࡱࡩࡾࠦࡊࡶࡰ࡬ࡳࡷ࠭ᩰ"),
 l11l1l11l111_tv_ (u"ࠧࡥ࡫ࡶࡲࡪࡿࠧᩱ"):l11l1l11l111_tv_ (u"ࠨࡆ࡬ࡷࡳ࡫ࡹࠡࡅ࡫ࡥࡳࡴࡥ࡭ࠩᩲ"),
 l11l1l11l111_tv_ (u"ࠩࡱ࡭ࡨࡱࡥ࡭ࡱࡧࡩࡴࡴࠧᩳ"):l11l1l11l111_tv_ (u"ࠪࡒ࡮ࡩ࡫ࡦ࡮ࡲࡨࡪࡵ࡮ࠨᩴ"),
 l11l1l11l111_tv_ (u"ࠫࡨࡴࠧ᩵"):l11l1l11l111_tv_ (u"ࠬࡉࡡࡳࡶࡲࡳࡳࠦࡎࡦࡶࡺࡳࡷࡱࠧ᩶"),
 l11l1l11l111_tv_ (u"࠭ࡦࡪࡩ࡫ࡸࡧࡵࡸࠨ᩷"):l11l1l11l111_tv_ (u"ࠧࡇ࡫ࡪ࡬ࡹࠦࡂࡰࡺࠪ᩸"),
 }
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    l1llll11l1l11l111_tv_ = fix.get(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠨࡶࡹ࡭ࡩ࠭᩹")),l11l1l11l111_tv_ (u"ࠩࠪ᩺"))
    if l1llll11l1l11l111_tv_:
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ᩻")]=l1llll11l1l11l111_tv_
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩ᩼")]=l1llll11l1l11l111_tv_
    return l1l1l1ll11l111_tv_
local={
l11l1l11l111_tv_ (u"ࠧࡎ࠲ࠣ᩽"):l11l1l11l111_tv_ (u"ࠨࠨࡩࠪ࡞ࡠࡸ࠰࠭࡞࠴ࠬࡃ࠭ࡡ࡜ࡴࠬ࠰ࡡࡍࡊࠩࡀࠫࠥ᩾"),
l11l1l11l111_tv_ (u"ࠢࡑࡱ࡯ࡷࡦࡺ᩿ࠢ"):l11l1l11l111_tv_ (u"ࠣࠪࡓࡳࡠ࠳࡝࡭ࡵࡤࡸ࠭ࡡ࡜ࡴࠬ࠰ࡡ࡙࡜ࠩࡀࠪ࡞ࡠࡸ࠰࠭࡞ࡊࡇ࠭ࡄ࠯ࠢ᪀"),
}
def l111111l11l111_tv_(url,data=None,header={},l1llll1111l11l111_tv_=True):
    l1llll1l11l11l111_tv_=l11l1l11l111_tv_ (u"ࠩࠪ᪁")
    l1llll1ll1l11l111_tv_=[]
    if l1llll1111l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {l11l1l11l111_tv_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ᪂"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_ =  response.read()
        response.close()
        l1llll1l11l11l111_tv_ = l11l1l11l111_tv_ (u"ࠫࠬ᪃").join([l11l1l11l111_tv_ (u"ࠬࠫࡳ࠾ࠧࡶ࠿ࠬ᪄")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
    except:
        l11ll11ll11l111_tv_ = l11l1l11l111_tv_ (u"࠭ࠧ᪅")
    return l11ll11ll11l111_tv_,l1llll1l11l11l111_tv_
def l1l1lll111l11l111_tv_(url, l1ll111l1ll11l111_tv_, index):
    out = l1l1l1lllll11l111_tv_(url)
    l1ll111l1ll11l111_tv_[index]=out
def l11l11l1l11l111_tv_(addheader=False):
    out=[]
    l1l111lllll11l111_tv_ = list()
    l1l1llll111l11l111_tv_=[l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡵࡧ࡯ࡩ࠲ࡽࡩࡻ࡬ࡤ࠲࡮ࡹ࠯࠳ࡱࡪࡳࡱࡴࡥࠨ᪆"),l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡨࡰࡪ࠳ࡷࡪࡼ࡭ࡥ࠳࡯ࡳ࠰࡫ࡱࡪࡴ࠭᪇"),
            l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷࡩࡱ࡫࠭ࡸ࡫ࡽ࡮ࡦ࠴ࡩࡴ࠱ࡩ࡭ࡱࡳ࡯ࡸࡧࠪ᪈"),l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸࡪࡲࡥ࠮ࡹ࡬ࡾ࡯ࡧ࠮ࡪࡵ࠲ࡲࡦࡻ࡫ࡰࡹࡨࠫ᪉"),
            l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹ࡫࡬ࡦ࠯ࡺ࡭ࡿࡰࡡ࠯࡫ࡶ࠳ࡸࡶ࡯ࡳࡶࡲࡻࡪ࠭᪊"),l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡺࡥ࡭ࡧ࠰ࡻ࡮ࢀࡪࡢ࠰࡬ࡷ࠴ࡨࡡ࡫࡭ࡲࡻࡪ࠭᪋")]
    l1ll111l1ll11l111_tv_ = [[] for x in l1l1llll111l11l111_tv_]
    for i,url in enumerate(l1l1llll111l11l111_tv_):
        thread = threading.Thread(name=l11l1l11l111_tv_ (u"࠭ࡔࡩࡴࡨࡥࡩࠫࡤࠨ᪌")%i, target = l1l1lll111l11l111_tv_, args=[url,l1ll111l1ll11l111_tv_,i])
        l1l111lllll11l111_tv_.append(thread)
        thread.start()
    while any([i.isAlive() for i in l1l111lllll11l111_tv_]): time.sleep(0.1)
    del l1l111lllll11l111_tv_[:]
    for l1l1l1ll11l111_tv_ in l1ll111l1ll11l111_tv_:
        out.extend(l1l1l1ll11l111_tv_)
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡺࡧ࡯ࡰࡴࡽ࡝ࡖࡲࡧࡥࡹ࡫ࡤ࠻ࠢࠨࡷࠥ࠮ࡴࡦ࡮ࡨ࠱ࡼ࡯ࡺ࡫ࡣࠬ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᪍") %time.strftime(l11l1l11l111_tv_ (u"ࠣࠧࡧ࠳ࠪࡳ࠯࡛ࠦ࠽ࠤࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨ᪎"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ᪏"):t,l11l1l11l111_tv_ (u"ࠪࡸࡻ࡯ࡤࠨ᪐"):l11l1l11l111_tv_ (u"ࠫࠬ᪑"),l11l1l11l111_tv_ (u"ࠬ࡯࡭ࡨࠩ᪒"):l11l1l11l111_tv_ (u"࠭ࠧ᪓"),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫ᪔"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠨࡩࡵࡳࡺࡶࠧ᪕"):l11l1l11l111_tv_ (u"ࠩࠪ᪖"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࡥࡱࡩࠪ᪗"):l11l1l11l111_tv_ (u"ࠫࠬ᪘")})
    return out
def l1l1l1lllll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡺࡥ࡭ࡧ࠰ࡻ࡮ࢀࡪࡢ࠰࡬ࡷ࠴࠸࡯ࡨࡱ࡯ࡲࡪ࠭᪙")):
    out=[]
    content,c = l111111l11l111_tv_(url)
    code=url.split(l11l1l11l111_tv_ (u"࠭࠯ࠨ᪚"))[-1].replace(l11l1l11l111_tv_ (u"ࠧ࠳ࠩ᪛"),l11l1l11l111_tv_ (u"ࠨࠩ᪜"))
    items = re.compile(l11l1l11l111_tv_ (u"ࠩ࠿ࡸࡩࠦࡣ࡭ࡣࡶࡷࡂࠨࡣࡰ࡮ࡸࡱࡳ࠴ࠫࡀࡪࡵࡩ࡫ࡃ࡛ࠣ࡞ࠪࡡ࠭ࡡ࡞ࠣ࡞ࠪࡡ࠰࠯࡛ࠣ࡞ࠪࡡ࠳࠱࠿࠽࡫ࡰ࡫ࡡࡹࠪࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ᪝")).findall(content)
    for href,l1l1lll1llll11l111_tv_ in items:
        c = code
        t = l1l1lll1llll11l111_tv_.split(l11l1l11l111_tv_ (u"ࠪ࠳ࠬ᪞"))[-1].split(l11l1l11l111_tv_ (u"ࠫ࠳࠭᪟"))[0]
        i = l1l1lll1llll11l111_tv_
        h = href
        if l11l1l11l111_tv_ (u"ࠬࡂࠧ᪠") in h:
            continue
        out.append(l1lll1l1l1l11l111_tv_({l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ᪡"):t,l11l1l11l111_tv_ (u"ࠧࡵࡸ࡬ࡨࠬ᪢"):t,l11l1l11l111_tv_ (u"ࠨ࡫ࡰ࡫ࠬ᪣"):i,l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭᪤"):h,l11l1l11l111_tv_ (u"ࠪ࡫ࡷࡵࡵࡱࠩ᪥"):l11l1l11l111_tv_ (u"ࠫࠬ᪦"),l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࡧࡳ࡫ࠬᪧ"):l11l1l11l111_tv_ (u"࠭ࠧ᪨"),l11l1l11l111_tv_ (u"ࠧࡤࡱࡧࡩࠬ᪩"):c}))
    return out
class l1lll1111ll11l111_tv_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
def l1l1llll11ll11l111_tv_(l1ll1l1l11l11l111_tv_,l1111l11lll11l111_tv_=l11l1l11l111_tv_ (u"ࠨࠩ᪪")):
    try:
        header={l11l1l11l111_tv_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ᪫"):l1111l11lll11l111_tv_,
            l11l1l11l111_tv_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ᪬"):l1lll1l1lll11l111_tv_,
            l11l1l11l111_tv_ (u"ࠫࡆࡩࡣࡦࡲࡷࠫ᪭"):l11l1l11l111_tv_ (u"ࠬ࠰࠯ࠫࠩ᪮"),
            l11l1l11l111_tv_ (u"࠭ࡁࡤࡥࡨࡴࡹ࠳ࡅ࡯ࡥࡲࡨ࡮ࡴࡧࠨ᪯"):l11l1l11l111_tv_ (u"ࠧࡨࡼ࡬ࡴ࠱ࠦࡤࡦࡨ࡯ࡥࡹ࡫ࠧ᪰"),
            l11l1l11l111_tv_ (u"ࠨࡃࡦࡧࡪࡶࡴ࠮ࡎࡤࡲ࡬ࡻࡡࡨࡧࠪ᪱"):l11l1l11l111_tv_ (u"ࠩࡨࡲ࠲࡛ࡓ࠭ࡧࡱ࠿ࡶࡃ࠰࠯࠺ࠪ᪲"),
            l11l1l11l111_tv_ (u"ࠪࡇࡦࡩࡨࡦ࠯ࡆࡳࡳࡺࡲࡰ࡮ࠪ᪳"):l11l1l11l111_tv_ (u"ࠫࡳࡵ࠭ࡤࡣࡦ࡬ࡪ࠭᪴"),
            }
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(l1lll1111ll11l111_tv_,urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        opener.addheaders = header.items()
        response = opener.open(l1ll1l1l11l11l111_tv_,timeout=5)
        l11ll111lll11l111_tv_ = response.headers.get(l11l1l11l111_tv_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴ᪵ࠧ"),l11l1l11l111_tv_ (u"᪶࠭ࠧ"))
        response.close()
    except:
        l11ll111lll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࠨ᪷")
    if l11ll111lll11l111_tv_:
        return l11ll111lll11l111_tv_
    else:
        return l1ll1l1l11l11l111_tv_
url=l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡨࡰࡪ࠳ࡷࡪࡼ࡭ࡥ࠳࡯ࡳ࠰ࡣࡻࡲ࠲ࡨ࡬ࡢࡥ࡮࠳᪸ࠬ")
url=l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷࡩࡱ࡫࠭ࡸ࡫ࡽ࡮ࡦ࠴ࡩࡴ࠱ࡷࡺࡳ࠳࠷࠰᪹ࠩ")
def l111l1lll11l111_tv_(url):
    l1lll1ll11l11l111_tv_=[]
    url = url.replace(l11l1l11l111_tv_ (u"ࠪࡸࡪࡲࡥ࠮ࡹ࡬ࡾ࡯ࡧ࠮ࡤࡱࡰ᪺ࠫ"),l11l1l11l111_tv_ (u"ࠫࡹ࡫࡬ࡦ࠯ࡺ࡭ࡿࡰࡡ࠯࡫ࡶࠫ᪻"))
    content,c = l111111l11l111_tv_(url)
    l1l1lll11ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠮࠮ࠫࡁࠬࡀ࠴࡯ࡦࡳࡣࡰࡩࡃ࠭᪼"),re.DOTALL).findall(content)
    for l1ll1l1111l11l111_tv_ in l1l1lll11ll11l111_tv_:
        l1ll1l11l1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀ᪽ࠫࠥࠫ"),re.DOTALL|re.IGNORECASE).findall(l1ll1l1111l11l111_tv_)
        if l1ll1l11l1l11l111_tv_:
            l1111l11l1l11l111_tv_ = l1ll1l11l1l11l111_tv_[0]
            data,c = l111111l11l111_tv_(l1111l11l1l11l111_tv_)
            l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
            if l1ll11lll1l11l111_tv_:
                l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫ᪾"):l1ll11lll1l11l111_tv_,l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ᪿࠧ"):l11l1l11l111_tv_ (u"ࠩࡏ࡭ࡻ࡫ࠠࠨᫀ")+urlparse.urlparse(l1ll11lll1l11l111_tv_).netloc,l11l1l11l111_tv_ (u"ࠪࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ᫁"):1})
                break
            else:
                l1ll1l1l11l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡠࠨ࡜ࠨ࡟ࠫ࡬ࡹࡺࡰ࠯ࠬࡂࡠ࠳ࡳ࠳ࡶ࡝࠻ࡡ࠮ࡡࠢ࡝ࠩࡠࠫ᫂")).findall(data)
                if l1ll1l1l11l11l111_tv_:
                    l1ll1l1l11l11l111_tv_ = l1ll1l1l11l11l111_tv_[0]+l11l1l11l111_tv_ (u"ࠬࢂࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀ᫃ࠫ")+l1lll1l1lll11l111_tv_+l11l1l11l111_tv_ (u"࠭ࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾᫄ࠩ")+l1111l11l1l11l111_tv_
                    l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫ᫅"):l1ll1l1l11l11l111_tv_,l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ᫆"):l11l1l11l111_tv_ (u"ࠩࡏ࡭ࡻ࡫ࠠࠩ࡯࠶ࡹ࠮࠭᫇"),l11l1l11l111_tv_ (u"ࠪࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ᫈"):1})
                    break
                else:
                    l1ll1l1111l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠭࠴ࠪࡀࠫ࠿࠳࡮࡬ࡲࡢ࡯ࡨࡂࠬ᫉"),re.DOTALL).findall(data)
                    l1ll1l1111l11l111_tv_ = l1ll1l1111l11l111_tv_[0] if l1ll1l1111l11l111_tv_ else l11l1l11l111_tv_ (u"᫊ࠬ࠭")
                    l1ll1l11l1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᫋")).findall(l1ll1l1111l11l111_tv_)
                    if l1ll1l11l1l11l111_tv_:
                        data,c = l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0]) if l1ll1l11l1l11l111_tv_[0].startswith(l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴࠬᫌ")) else (content,l11l1l11l111_tv_ (u"ࠨࠩᫍ"))
                    l1ll1l1l11l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠩ࡞ࠦࡡ࠭࡝ࠩࡪࡷࡸࡵ࠴ࠪࡀ࡞࠱ࡱ࠸ࡻ࡛࠹࡟ࠬ࡟ࠧࡢࠧ࡞ࠩᫎ")).findall(data)
                    if l1ll1l1l11l11l111_tv_:
                        l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧ᫏"):l1ll1l1l11l11l111_tv_[0],l11l1l11l111_tv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ᫐"):l11l1l11l111_tv_ (u"ࠬࡒࡩࡷࡧࠣࠬࡲ࠹ࡵࠪࠩ᫑"),l11l1l11l111_tv_ (u"࠭ࡲࡦࡵࡲࡰࡻ࡫ࡤࠨ᫒"):1})
                        break
                    else:
                        l1l1l1ll11l11l111_tv_ = [x.strip() for x in re.findall(l11l1l11l111_tv_ (u"ࠧࡩࡴࡨࡪࡂࡡ࡜ࠨࠤࡠࠬࡡࡹࠪࡩࡶࡷࡴ࠿࠵࠯ࡵࡧ࡯ࡩ࠲ࡽࡩࡻ࡬ࡤ࠲࠰࠵ࡺࡢࡲࡤࡷ࠳࠰࠿ࠪ࡝࡟ࠫࠧࡣ࡜ࡴࠬࡁࠫ᫓"),content)]
                        for l1l1ll111ll11l111_tv_ in l1l1l1ll11l11l111_tv_:
                            data,c = l111111l11l111_tv_( l1l1ll111ll11l111_tv_ )
                            l1l1lll11ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠪ࠱࠮ࡄ࠯࠼࠰࡫ࡩࡶࡦࡳࡥ࠿ࠩ᫔"),re.DOTALL).findall(data)
                            for l1ll1l1111l11l111_tv_ in l1l1lll11ll11l111_tv_:
                                l1ll11lll1l11l111_tv_=l11l1l11l111_tv_ (u"ࠩࠪ᫕")
                                l1ll1l11l1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᫖")).findall(l1ll1l1111l11l111_tv_)
                                if l1ll1l11l1l11l111_tv_:
                                    data,c = l111111l11l111_tv_(l1ll1l11l1l11l111_tv_[0])
                                    l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
                                if l1ll11lll1l11l111_tv_:
                                    l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨ᫗"):l1ll11lll1l11l111_tv_,l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ᫘"):l11l1l11l111_tv_ (u"࠭ࡌࡪࡸࡨࠤࠬ᫙")+urlparse.urlparse(l1ll11lll1l11l111_tv_).netloc,l11l1l11l111_tv_ (u"ࠧࡳࡧࡶࡳࡱࡼࡥࡥࠩ᫚"):1})
                                    break
                        break
    return l1lll1ll11l11l111_tv_
def l1l1l1lll1l11l111_tv_():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[1]
    for l1l1l1ll11l111_tv_ in out:
        url=l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬ᫛"))
        print l11l1l11l111_tv_ (u"ࠩ࡟ࡲࠬ᫜"),l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ᫝"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨ᫞")))
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩ᫟")))
        print l1lll1ll11l11l111_tv_
