# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re
import time
import sys,os
import json
import cookielib
import threading
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡬ࡰࡱ࡮ࡲ࡮ࡰ࠮ࡪࡰࠪṊ")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠰࠯࠲࠱࠶࠻࠼࠱࠯࠳࠳࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬṋ")
l1lll1ll1ll11l111_tv_ = l11l1l11l111_tv_ (u"ࠧ࠲࠲ࠪṌ")
fix={}
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    l1llll11l1l11l111_tv_ = fix.get(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠨࡶࡹ࡭ࡩ࠭ṍ")),l11l1l11l111_tv_ (u"ࠩࠪṎ"))
    if l1llll11l1l11l111_tv_:
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩṏ")]=l1llll11l1l11l111_tv_
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩṐ")]=l1llll11l1l11l111_tv_
    return l1l1l1ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},cookies=None,l1llll1l1l11l111_tv_=True):
    if l1llll1l1l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {l11l1l11l111_tv_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩṑ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    if cookies:
        req.add_header(l11l1l11l111_tv_ (u"ࠨࡣࡰࡱ࡮࡭ࡪࠨṒ"), cookies)
    try:
        response = urllib2.urlopen(req, timeout=10)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࠨṓ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡩࡪࡨ࠮ࡵࡸ࠲࡮ࡸࡵ࡮࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠩࡳࡵࡺࡩࡰࡰࡀࡳࡳࡲࡩ࡯ࡧ࠰ࡥࡱࡶࡨࡢࡤࡨࡸ࡮ࡩࡡ࡭ࠩṔ"))
    try:
        data = json.loads(content)
    except:
        data = {}
    out=[]
    for k,v in data.items():
        print v.keys()
        group=l11l1l11l111_tv_ (u"ࠩࠪṕ")
        t=v.get(l11l1l11l111_tv_ (u"ࠪࡧ࡭ࡧ࡮࡯ࡧ࡯ࡣࡹ࡯ࡴ࡭ࡧࠪṖ"))
        i=v.get(l11l1l11l111_tv_ (u"ࠫࡨ࡮ࡡ࡯ࡰࡨࡰࡤࡲ࡯ࡨࡱࡢࡹࡷࡲࠧṗ"))
        h=v.get(l11l1l11l111_tv_ (u"ࠬࡩࡨࡢࡰࡱࡩࡱࡥ࡮ࡢ࡯ࡨࠫṘ"))
        if h:
            out.append(l1lll1l1l1l11l111_tv_({l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬṙ"):t,l11l1l11l111_tv_ (u"ࠧࡵࡸ࡬ࡨࠬṚ"):t,l11l1l11l111_tv_ (u"ࠨ࡫ࡰ࡫ࠬṛ"):i,l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭Ṝ"):h,l11l1l11l111_tv_ (u"ࠪ࡫ࡷࡵࡵࡱࠩṝ"):group,l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫṞ"):l11l1l11l111_tv_ (u"ࠬ࠭ṟ")}))
    if len(out)>0 and addheader:
        t=l11l1l11l111_tv_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡹࡦ࡮࡯ࡳࡼࡣࡕࡱࡦࡤࡸࡪࡪ࠺ࠡࠧࡶࠤ࠭ࡽࡥࡦࡤ࠱ࡸࡻ࠯࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨṠ") %time.strftime(l11l1l11l111_tv_ (u"ࠢࠦࡦ࠲ࠩࡲ࠵࡚ࠥ࠼ࠣࠩࡍࡀࠥࡎ࠼ࠨࡗࠧṡ"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧṢ"):t,l11l1l11l111_tv_ (u"ࠩࡷࡺ࡮ࡪࠧṣ"):l11l1l11l111_tv_ (u"ࠪࠫṤ"),l11l1l11l111_tv_ (u"ࠫ࡮ࡳࡧࠨṥ"):l11l1l11l111_tv_ (u"ࠬ࠭Ṧ"),l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪṧ"):l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡨࡩࡧ࠴ࡴࡷ࠱ࠪṨ"),l11l1l11l111_tv_ (u"ࠨࡩࡵࡳࡺࡶࠧṩ"):l11l1l11l111_tv_ (u"ࠩࠪṪ"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࡥࡱࡩࠪṫ"):l11l1l11l111_tv_ (u"ࠫࠬṬ")})
    return out
def l1l11l1ll11l11l111_tv_(l1l11l11l1ll11l111_tv_):
    param=[]
    if len(l1l11l11l1ll11l111_tv_) >= 2:
        params = l1l11l11l1ll11l111_tv_
        l1l11l1l11ll11l111_tv_ = params.replace(l11l1l11l111_tv_ (u"ࠬࡅࠧṭ"), l11l1l11l111_tv_ (u"࠭ࠧṮ"))
        if (params[len(params)-1] == l11l1l11l111_tv_ (u"ࠧ࠰ࠩṯ")):
            params = params[0:len(params)-2]
        l1l11l1l1l1l11l111_tv_ = l1l11l1l11ll11l111_tv_.split(l11l1l11l111_tv_ (u"ࠨࠨࠪṰ"))
        param = {}
        for i in range(len(l1l11l1l1l1l11l111_tv_)):
            l1l11l1l1lll11l111_tv_ = {}
            l1l11l1l1lll11l111_tv_ = l1l11l1l1l1l11l111_tv_[i].split(l11l1l11l111_tv_ (u"ࠩࡀࠫṱ"))
            if (len(l1l11l1l1lll11l111_tv_)) == 2:
                param[l1l11l1l1lll11l111_tv_[0]] = l1l11l1l1lll11l111_tv_[1]
        return param
def l111l1lll11l111_tv_(l1l11l11ll1l11l111_tv_=l11l1l11l111_tv_ (u"ࠪࡸࡻࡶ࠲ࡩࡦࡧࡻࡴࡰ࡫ࡢࠩṲ")):
    l1lll1ll11l11l111_tv_=[]
    url=l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡥࡦࡤ࠱ࡸࡻ࠵ࡡࡱ࡫࠲ࡷࡪࡺࡰ࡭ࡣࡼࡩࡷ࠭ṳ")
    data = l111111l11l111_tv_(url,l11l1l11l111_tv_ (u"ࠬࡩࡨࡢࡰࡱࡩࡱࡃࠥࡴࠩṴ")%l1l11l11ll1l11l111_tv_)
    if data:
        data = urllib.unquote(data)
        param=l1l11l1ll11l11l111_tv_(data)
        l1l11l1l111l11l111_tv_ = param.get(l11l1l11l111_tv_ (u"࠭࠱࠱ࠩṵ"))
        l1l11l1ll1ll11l111_tv_ = param.get(l11l1l11l111_tv_ (u"ࠧ࠲࠳ࠪṶ"))
        l1l11l11llll11l111_tv_ = param.get( l11l1l11l111_tv_ (u"ࠨ࠴࠳ࠫṷ"))
        token = param.get( l11l1l11l111_tv_ (u"ࠩ࠺࠷ࠬṸ"))
        l1l1ll1ll1l11l111_tv_=l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡺࡡࡵ࡫ࡦ࠲ࡼ࡫ࡥࡣ࠰ࡷࡺ࠴ࡶ࡬ࡢࡻࡨࡶ࠳ࡹࡷࡧࠩṹ")
        if  l1l11l11llll11l111_tv_ == l11l1l11l111_tv_ (u"ࠫ࠶࠭Ṻ"):
            l1l11l1ll1ll11l111_tv_ = l1l11l1ll1ll11l111_tv_ + l11l1l11l111_tv_ (u"ࠬࡎࡉࠨṻ")
        else:
            l1l11l1ll1ll11l111_tv_ = l1l11l1ll1ll11l111_tv_ + l11l1l11l111_tv_ (u"࠭ࡌࡐ࡙ࠪṼ")
        l111111llll11l111_tv_ = str(l1l11l1l111l11l111_tv_) + l11l1l11l111_tv_ (u"ࠧ࠰ࠩṽ") + str(l1l11l1ll1ll11l111_tv_) + l11l1l11l111_tv_ (u"ࠨࠢ࡯࡭ࡻ࡫࠽ࡵࡴࡸࡩࠥࡶࡡࡨࡧࡘࡶࡱࡃࡴࡰ࡭ࡨࡲࠥࡹࡷࡧࡗࡵࡰࡂ࠭Ṿ") + str(token)
        l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭ṿ"):l111111llll11l111_tv_}]
    else:
        l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠪࡱࡸ࡭ࠧẀ"):l11l1l11l111_tv_ (u"ࠫ࡜࡫ࠠࡢࡴࡨࠤ࡭ࡧࡶࡪࡰࡪࠤࡦࠦࡰࡳࡱࡥࡰࡪࡳࠧẁ")}]
    print(l11l1l11l111_tv_ (u"ࠬࡽࡥࡦࡤࡷࡺࠬẂ"),l11l1l11l111_tv_ (u"࠭ࡧࡦࡶࡆ࡬ࡦࡴ࡮ࡦ࡮࡙࡭ࡩ࡫࡯ࠨẃ"),l1lll1ll11l11l111_tv_)
    return l1lll1ll11l11l111_tv_
def test():
    out=l11l11l1l11l111_tv_(addheader=False)
    o = out[0]
    for o in out:
        url= o.get(l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫẄ"))
        title= o.get(l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧẅ"))
        print title
        o[l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭Ẇ")]=l111l1lll11l111_tv_(o.get(l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧẇ")))
        print o[l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨẈ")]
    with open(l11l1l11l111_tv_ (u"ࠬࡲ࡯ࡰ࡭ࡱ࡭࡯࠴ࡪࡴࡱࡱࠫẉ"), l11l1l11l111_tv_ (u"࠭ࡷࠨẊ")) as l11lll1l1ll11l111_tv_:
        json.dump(out, l11lll1l1ll11l111_tv_, indent=2, sort_keys=True)
