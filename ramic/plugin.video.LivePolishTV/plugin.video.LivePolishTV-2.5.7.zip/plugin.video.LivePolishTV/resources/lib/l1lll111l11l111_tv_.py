# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re,json,time,urlparse
import cookielib
import l1ll11ll1ll11l111_tv_
import l1ll1ll111l11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡰࡦࡳࡥࡱࡺࡶ࠯ࡲ࡯࠳ࠬᑊ")
l1lll1ll1ll11l111_tv_=10
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠶࠲࠱࠴࠳࠸࠶࠷࠳࠱࠵࠵࠸ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧᑋ")
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᑌ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠪࠫᑍ")
    return l11ll11ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},l1llll1111l11l111_tv_=True):
    l1llll1l11l11l111_tv_=l11l1l11l111_tv_ (u"ࠫࠬᑎ")
    l1llll1ll1l11l111_tv_=[]
    if l1llll1111l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {l11l1l11l111_tv_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᑏ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_ =  response.read()
        response.close()
        l1llll1l11l11l111_tv_ = l11l1l11l111_tv_ (u"࠭ࠧᑐ").join([l11l1l11l111_tv_ (u"ࠧࠦࡵࡀࠩࡸࡁࠧᑑ")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
    except urllib2.HTTPError as e:
        l11ll11ll11l111_tv_ = l11l1l11l111_tv_ (u"ࠨࠩᑒ")
    return l11ll11ll11l111_tv_,l1llll1l11l11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content,c = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    data = re.findall(l11l1l11l111_tv_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴ࡵࡤࡱࡣ࡯ࡸࡻ࠴ࡰ࡭࠱࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿࠾࡬ࡱ࡬ࠦࡷࡪࡦࡷ࡬ࡂࠨ࡜ࡥ࠭ࠥࠤ࡭࡫ࡩࡨࡪࡷࡁࠧࡢࡤࠬࠤࠣࡷࡷࡩ࠽ࠣࠪ࡫ࡸࡹࡶ࠺࠯ࠬࡂ࠭ࠧ࠭ᑓ"),content)
    out=[]
    for href,title,l1llll11lll11l111_tv_ in data:
        out.append({l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩᑔ"):title.strip(),l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩᑕ"):title.strip(),l11l1l11l111_tv_ (u"ࠬ࡯࡭ࡨࠩᑖ"):l1llll11lll11l111_tv_,l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪᑗ"):href,l11l1l11l111_tv_ (u"ࠧࡨࡴࡲࡹࡵ࠭ᑘ"):l11l1l11l111_tv_ (u"ࠨࠩᑙ"),l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩᑚ"):l11l1l11l111_tv_ (u"ࠪࠫᑛ")})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡾ࡫࡬࡭ࡱࡺࡡ࡚ࡶࡤࡢࡶࡨࡨ࠿ࠦࠥࡴࠢࠫࡳࡩࡶࡡ࡭ࡶࡹ࠭ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᑜ") %time.strftime(l11l1l11l111_tv_ (u"ࠧࠫࡤ࠰ࠧࡰ࠳ࠪ࡟࠺ࠡࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥᑝ"))
        out.insert(0,{l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬᑞ"):t,l11l1l11l111_tv_ (u"ࠧࡵࡸ࡬ࡨࠬᑟ"):l11l1l11l111_tv_ (u"ࠨࠩᑠ"),l11l1l11l111_tv_ (u"ࠩ࡬ࡱ࡬࠭ᑡ"):l11l1l11l111_tv_ (u"ࠪࠫᑢ"),l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨᑣ"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠬ࡭ࡲࡰࡷࡳࠫᑤ"):l11l1l11l111_tv_ (u"࠭ࠧᑥ"),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࡩࡵ࡭ࠧᑦ"):l11l1l11l111_tv_ (u"ࠨࠩᑧ")})
    return l1ll1ll111l11l111_tv_.l1ll1ll1l1l11l111_tv_(out,local={})
def l111l1lll11l111_tv_(url):
    url,l1llll1l11l11l111_tv_=url.split(l11l1l11l111_tv_ (u"ࠩࡂࠫᑨ")) if l11l1l11l111_tv_ (u"ࠪࡃࠬᑩ")in url else (url,l11l1l11l111_tv_ (u"ࠫࠬᑪ"))
    print url,l1llll1l11l11l111_tv_
    l1lll1ll11l11l111_tv_=[]
    header ={l11l1l11l111_tv_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᑫ"):l1lll1l1lll11l111_tv_,
            l11l1l11l111_tv_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩᑬ"):l11l1l11l111_tv_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨᑭ"),
            l11l1l11l111_tv_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩᑮ"):url,
            l11l1l11l111_tv_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩᑯ"):l1llll1l11l11l111_tv_,
            }
    content,c = l111111l11l111_tv_(url,header=header)
    l1ll11lll1l11l111_tv_=l11l1l11l111_tv_ (u"ࠪࠫᑰ")
    src = re.compile(l11l1l11l111_tv_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡪࡷࡧ࡭ࡦࠩᑱ"),re.DOTALL|re.I).findall(content)
    if src:
        if l11l1l11l111_tv_ (u"ࠬࡪࡥ࡬ࡱࡧࡩࡷ࠴ࡷࡴ࠱ࡨࡱࡧ࡫ࡤ࠰ࠩᑲ") in src[0]:
            from l1llll11l11l111_tv_ import l1ll1111l1l11l111_tv_
            l1ll11lll1l11l111_tv_ = l1ll1111l1l11l111_tv_(src[0])
            print l1ll11lll1l11l111_tv_
        else:
            data,c = l111111l11l111_tv_(src[0])
            l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src[0],data)
    if l1ll11lll1l11l111_tv_:
        l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪᑳ"):l1ll11lll1l11l111_tv_,l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᑴ"):l11l1l11l111_tv_ (u"ࠨࡎ࡬ࡺࡪࠦࠧᑵ")+urlparse.urlparse(l1ll11lll1l11l111_tv_).netloc,l11l1l11l111_tv_ (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫᑶ"):1})
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        print l11l1l11l111_tv_ (u"ࠪࡠࡳ࠭ᑷ"),l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪᑸ"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩᑹ")))
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬᑺ")))
        print l1lll1ll11l11l111_tv_
