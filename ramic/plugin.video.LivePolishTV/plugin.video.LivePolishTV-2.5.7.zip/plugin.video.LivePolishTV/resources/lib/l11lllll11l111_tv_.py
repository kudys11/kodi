# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import re
import urllib2,urllib
import base64
import urlparse
import time,json
import os
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠺࠶࠮࠱࠰࠵࠺࠻࠷࠮࠲࠲࠵ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫཕ")
l1llll111ll11l111_tv_ =l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡩࡵ࡫ࡹ࡭࠳ࡶ࡬࠰ࠩབ")
__all__=[l11l1l11l111_tv_ (u"ࠧࡨࡧࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬབྷ"),l11l1l11l111_tv_ (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰ࡛࡯ࡤࡦࡱࠪམ")]
fix={
l11l1l11l111_tv_ (u"ࠩࡗ࡚ࡕ࠷ࠠࡉࡆࠪཙ"):l11l1l11l111_tv_ (u"ࠪࡘ࡛ࡖࠠ࠲ࠩཚ"),
l11l1l11l111_tv_ (u"࡙ࠫ࡜ࡐ࠳ࠢࡋࡈࠬཛ"):l11l1l11l111_tv_ (u"࡚ࠬࡖࡑࠢ࠵ࠫཛྷ"),
l11l1l11l111_tv_ (u"࠭ࡐࡐࡎࡖࡅ࡙ࠦࡈࡅࠩཝ"):l11l1l11l111_tv_ (u"ࠧࡑࡱ࡯ࡷࡦࡺࠧཞ"),
l11l1l11l111_tv_ (u"ࠨࡖ࡙ࡒࠬཟ"):l11l1l11l111_tv_ (u"ࠩࡗ࡚ࡓ࠭འ"),
l11l1l11l111_tv_ (u"ࠪࡌࡇࡕࠠࡉࡆࠪཡ"):l11l1l11l111_tv_ (u"ࠫࡍࡈࡏࠨར"),
l11l1l11l111_tv_ (u"ࠬࡉࡁࡏࡃࡏࠤࡘࡖࡏࡓࡖࠪལ"): l11l1l11l111_tv_ (u"࠭ࡃࡢࡰࡤࡰ࠰ࠦࡓࡱࡱࡵࡸࠬཤ"),
l11l1l11l111_tv_ (u"ࠧࡇࡋࡏࡑࡇࡕࡘࠡࡒࡕࡉࡒࡏࡕࡎࠩཥ"):l11l1l11l111_tv_ (u"ࠨࡈ࡬ࡰࡲࡨ࡯ࡹࠩས"),
l11l1l11l111_tv_ (u"ࠩࡐ࡭ࡳ࡯ࠠࡎ࡫ࡱ࡭ࠬཧ"):l11l1l11l111_tv_ (u"ࠪࡑ࡮ࡴࡩ࡮࡫ࡱ࡭࠰࠭ཨ"),
l11l1l11l111_tv_ (u"ࠫࡊ࡙ࡋࡂࠢࡗ࡚ࠬཀྵ"):l11l1l11l111_tv_ (u"ࠬࡋࡳ࡬ࡣࠣࡘ࡛࠭ཪ"),
l11l1l11l111_tv_ (u"࠭ࡐࡰ࡮ࡲࠤ࡙࡜ࠧཫ"):l11l1l11l111_tv_ (u"ࠧࡑࡱ࡯ࡳ࡚ࠥࡖࠨཬ"),
l11l1l11l111_tv_ (u"ࠨࡇࡖࡏࡆࠦࡐࡂࡔࡗ࡝ࠦ࠭཭"):l11l1l11l111_tv_ (u"ࠩࡈࡷࡰࡧࠠࡑࡣࡵࡸࠬ཮"),
l11l1l11l111_tv_ (u"ࠪࡇ࡟࡝ࡏࡓࡍࡄࠤࡕࡕࡌࡔࡍࡌࡉࠥࡘࡁࡅࡋࡒࠤࡑࡏࡖࡆࠩ཯"):l11l1l11l111_tv_ (u"ࠫࡈࢀࡷࣴࡴ࡮ࡥࠥࡖ࡯࡭ࡵ࡮࡭ࡪࠦࡒࡢࡦ࡬ࡳࠬ཰"),
l11l1l11l111_tv_ (u"ࠬ࡜ࡏཱ࡙ࠩ"):l11l1l11l111_tv_ (u"࠭ࡖࡐི࡚ࠪ"),
l11l1l11l111_tv_ (u"ࠧࡕ࡮ࡦࠤࡍࡊཱིࠧ"):l11l1l11l111_tv_ (u"ࠨࡖࡏࡇུࠬ"),
l11l1l11l111_tv_ (u"ࠩࡦࡥࡳࡧ࡬ࠡࡨ࡬ࡰࡲཱུ࠭"):l11l1l11l111_tv_ (u"ࠪࡇࡦࡴࡡ࡭࠭ࠣࡊ࡮ࡲ࡭ࠨྲྀ"),
l11l1l11l111_tv_ (u"ࠫࡈࡕࡍࡆࡆ࡜ࠤࡈࡋࡎࡕࡔࡄࡐࠬཷ"):l11l1l11l111_tv_ (u"ࠬࡉ࡯࡮ࡧࡧࡽࠥࡉࡥ࡯ࡶࡵࡥࡱ࠭ླྀ"),
l11l1l11l111_tv_ (u"࠭ࡐࡐࡎࡖࡅ࡙ࠦ࠲ࡉࡆࠪཹ"):l11l1l11l111_tv_ (u"ࠧࡑࡱ࡯ࡷࡦࡺࠠ࠳ེࠩ"),
l11l1l11l111_tv_ (u"ࠨࡒࡒࡐࡘࡇࡔࠡࡕࡓࡓࡗ࡚ࠠࡉࡆཻࠪ"):l11l1l11l111_tv_ (u"ࠩࡓࡳࡱࡹࡡࡵࠢࡖࡴࡴࡸࡴࠨོ"),
l11l1l11l111_tv_ (u"ࠪࡘ࡛ࡖࠠࡉࡆཽࠪ"):l11l1l11l111_tv_ (u"࡙ࠫ࡜ࡐࠡࡊࡇࠫཾ"),
l11l1l11l111_tv_ (u"ࠬࡊࡩࡴࡥࡲࡺࡪࡸࡹࠡࡅ࡫ࡥࡳࡴࡥ࡭ࠩཿ"):l11l1l11l111_tv_ (u"࠭ࡄࡪࡵࡦࡳࡻ࡫ࡲࡺࠢࡆ࡬ࡦࡴ࡮ࡦ࡮ྀࠪ")
}
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    l1llll11l1l11l111_tv_ = fix.get(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠧࡵࡸ࡬ࡨཱྀࠬ")),l11l1l11l111_tv_ (u"ࠨࠩྂ"))
    if l1llll11l1l11l111_tv_:
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨྃ")]=l1llll11l1l11l111_tv_
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠪࡸࡻ࡯ࡤࠨ྄")]=l1llll11l1l11l111_tv_
    return l1l1l1ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},cookies={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ྅"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=10)
        header[l11l1l11l111_tv_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ྆")]=response.info()[l11l1l11l111_tv_ (u"࠭ࡓࡦࡶ࠰ࡇࡴࡵ࡫ࡪࡧࠪ྇")]
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        req = urllib2.Request(url,data,headers=header)
        response = urllib2.urlopen(req, timeout=10)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(url=l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡶ࡬ࡺ࡮࠴ࡰ࡭࠱ࡤࡴ࡮࠴ࡰࡩࡲࠪྈ"),data=l11l1l11l111_tv_ (u"ࠨࡣࡦࡸ࡮ࡵ࡮࠾ࡉࡨࡸࡘࡺࡲࡦࡣࡰࡷࠬྉ"))
    content = json.loads(content) if content else {}
    content = content.get(l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡲࡲࠧྊ"),l11l1l11l111_tv_ (u"ࠪࠫྋ"))
    l1llll11lll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩྌ"),re.DOTALL).findall(content)
    title = re.compile(l11l1l11l111_tv_ (u"ࠬࡂࡨ࠶ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠹ࡃ࠭ྍ"),re.DOTALL).findall(content)
    href = re.compile(l11l1l11l111_tv_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨྎ"),re.DOTALL).findall(content)
    out=[]
    for h,t,i in zip(href,title,l1llll11lll11l111_tv_):
        h = urlparse.urljoin(l1llll111ll11l111_tv_,h)
        t = t.strip()
        i = urlparse.urljoin(l1llll111ll11l111_tv_,i)
        out.append(l1lll1l1l1l11l111_tv_({l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ྏ"):t,l11l1l11l111_tv_ (u"ࠨࡶࡹ࡭ࡩ࠭ྐ"):t,l11l1l11l111_tv_ (u"ࠩ࡬ࡱ࡬࠭ྑ"):i,l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧྒ"):h,l11l1l11l111_tv_ (u"ࠫ࡬ࡸ࡯ࡶࡲࠪྒྷ"):l11l1l11l111_tv_ (u"ࠬ࠭ྔ"),l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࡨࡴ࡬࠭ྕ"):l11l1l11l111_tv_ (u"ࠧࠨྖ")}))
    if addheader and out:
        t=l11l1l11l111_tv_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡻࡨࡰࡱࡵࡷ࡞ࡗࡳࡨࡦࡺࡥࡥ࠼ࠣࠩࡸࠦࠨࡪࡶ࡬ࡺ࡮࠯࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨྗ") %time.strftime(l11l1l11l111_tv_ (u"ࠤࠨࡨ࠴ࠫ࡭࠰ࠧ࡜࠾ࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢ྘"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩྙ"):t,l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩྚ"):l11l1l11l111_tv_ (u"ࠬ࠭ྛ"),l11l1l11l111_tv_ (u"࠭ࡩ࡮ࡩࠪྜ"):l11l1l11l111_tv_ (u"ࠧࠨྜྷ"),l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬྞ"):l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬ࡸ࡮ࡼࡩ࠯ࡲ࡯࠳ࠬྟ"),l11l1l11l111_tv_ (u"ࠪ࡫ࡷࡵࡵࡱࠩྠ"):l11l1l11l111_tv_ (u"ࠫࠬྡ"),l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࡧࡳ࡫ࠬྡྷ"):l11l1l11l111_tv_ (u"࠭ࠧྣ")})
    return out
    content = l111111l11l111_tv_(url=l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡶ࡬ࡺ࡮࠴ࡰ࡭࠱ࡤࡴ࡮࠴ࡰࡩࡲࠪྤ"),data=l11l1l11l111_tv_ (u"ࠨࡵࡷࡶࡪࡧ࡭࠾ࠧࡶࠪࡦࡩࡴࡪࡱࡱࡁࡌ࡫ࡴࡔࡶࡵࡩࡦࡳࠧྥ"))
def l111l1lll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬ࡸ࡮ࡼࡩ࠯ࡲ࡯࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠲ࡺࡥ࡭ࡧࡺ࡭ࡿࡿࡪ࡯ࡻ࠲ࡈ࡮ࡹࡣࡰࡸࡨࡶࡾࡥࡃࡩࡣࡱࡲࡪࡲࠧྦ")):
    l1lll1ll11l11l111_tv_=[]
    if l11l1l11l111_tv_ (u"ࠪ࡭ࡹ࡯ࡶࡪ࠰ࡳࡰࠬྦྷ") in url:
        content = l111111l11l111_tv_(url)
        l11ll11ll11l111_tv_=re.compile(l11l1l11l111_tv_ (u"ࠫࡵࡲࡡࡺࡏ࠶࡙࠽ࡨࡹࡈࡴ࡬ࡲࡩࡖ࡬ࡢࡻࡨࡶࡡ࠮ࠢࠩ࠰࠭ࡃ࠮ࠨ࡜ࠪࠩྨ")).findall(content)
        if l11ll11ll11l111_tv_:
            if l11ll11ll11l111_tv_[0].startswith(l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲࠪྩ")):
                l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪྪ"):l11ll11ll11l111_tv_[0],l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷ࡭ࡱ࡫ࠧྫ"):l11l1l11l111_tv_ (u"ࠨࡎ࡬ࡺࡪ࠭ྫྷ"),l11l1l11l111_tv_ (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫྭ"):1})
            else:
                l1l1ll1ll1l11l111_tv_=l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡹ࡯ࡶࡪ࠰ࡳࡰ࠴ࡰࡳ࠰࡬ࡺࡴࡱࡧࡹࡦࡴ࠰࠻࠳࠶࠮࠴࠱࡭ࡻࡵࡲࡡࡺࡧࡵ࠲࡫ࡲࡡࡴࡪ࠱ࡷࡼ࡬ࠧྮ")
                l1l111l1l1l11l111_tv_ = l11ll11ll11l111_tv_[0].replace(l11l1l11l111_tv_ (u"ࠫ࡫ࡲࡶ࠻ࠩྯ"),l11l1l11l111_tv_ (u"ࠬ࠭ྰ")) + l11l1l11l111_tv_ (u"࠭ࠠࡴࡹࡩ࡙ࡷࡲ࠽ࠨྱ")+l1l1ll1ll1l11l111_tv_ + l11l1l11l111_tv_ (u"ࠧࠡࡵࡺࡪ࡛࡬ࡹ࠾࠳ࠣࡰ࡮ࡼࡥ࠾࠳ࠣࡸ࡮ࡳࡥࡰࡷࡷࡁ࠶࠶ࠠࡱࡣࡪࡩ࡚ࡸ࡬࠾ࠩྲ")+url
                l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬླ"):l1l111l1l1l11l111_tv_,l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹ࡯࡬ࡦࠩྴ"):l11l1l11l111_tv_ (u"ࠪࡐ࡮ࡼࡥࠨྵ"),l11l1l11l111_tv_ (u"ࠫࡷ࡫ࡳࡰ࡮ࡹࡩࡩ࠭ྶ"):1})
        else:
            l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠬࡳࡳࡨࠩྷ"):l11l1l11l111_tv_ (u"࡚࠭ࡣࡻࡷࠤࡼ࡯ࡥ࡭ࡷࠣࡨࡦࡸ࡭ࡰࡹࡼࡧ࡭ࠦࡵॽࡻࡷ࡯ࡴࡽ࡮ࡪ࡭ࣶࡻࠥࡱ࡯ࡳࡼࡼࡷࡹࡧࠠࡻࠢࡳࡳࡷࡺࡡ࡭ࡷࠤ࠲ࠬྸ")}]
    return l1lll1ll11l11l111_tv_
def l111l1lll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡶ࡬ࡺ࡮࠴ࡰ࡭࠱ࡲ࡫ࡱࡧࡤࡢ࡬࠱࡬ࡹࡳ࡬ࡀ࡭ࡤࡲࡦࡲ࠽ࡱࡱ࡯ࡷࡦࡺࡰ࡭ࡣࡼࠫྐྵ")):
    l1lll1ll11l11l111_tv_=[]
    if l11l1l11l111_tv_ (u"ࠨ࡫ࡷ࡭ࡻ࡯࠮ࡱ࡮ࠪྺ") in url:
        ch= url.split(l11l1l11l111_tv_ (u"ࠩࡀࠫྻ"))[-1]
        content = l111111l11l111_tv_(url=l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡹ࡯ࡶࡪ࠰ࡳࡰ࠴ࡧࡰࡪ࠰ࡳ࡬ࡵ࠭ྼ"),data=l11l1l11l111_tv_ (u"ࠫࡸࡺࡲࡦࡣࡰࡁࠪࡹࠦࡢࡥࡷ࡭ࡴࡴ࠽ࡈࡧࡷࡗࡹࡸࡥࡢ࡯ࠪ྽")%ch)
        content = json.loads(content) if content else {}
        l11ll11ll11l111_tv_ = content.get(l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩ྾"),l11l1l11l111_tv_ (u"࠭ࠧ྿"))
        if l11ll11ll11l111_tv_:
            l11ll11ll11l111_tv_ = l11ll11ll11l111_tv_.replace(l11l1l11l111_tv_ (u"ࠧ࠻࠺࠳ࠫ࿀"),l11l1l11l111_tv_ (u"ࠨ࠼࠻࠵ࠬ࿁"))
            l11ll11ll11l111_tv_ += l11l1l11l111_tv_ (u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠦࡵࠪ࿂")%l1lll1l1lll11l111_tv_
            if l11ll11ll11l111_tv_:
                l1lll1ll11l11l111_tv_.append({l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧ࿃"):l11ll11ll11l111_tv_,l11l1l11l111_tv_ (u"ࠫࡹ࡯ࡴࡪ࡮ࡨࠫ࿄"):content.get(l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ࿅"),ch),l11l1l11l111_tv_ (u"࠭ࡲࡦࡵࡲࡰࡻ࡫ࡤࠨ࿆"):1})
            else:
                l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠧ࡮ࡵࡪࠫ࿇"):l11l1l11l111_tv_ (u"ࠨࡒࡵࡳࡧࡲࡥ࡮ࠢࡽࠤࡴࡩࡺࡺࡶࡤࡲ࡮࡫࡭ࠡॼࡵࣷࡩैࡡࠡ࡭ࡤࡲࡦैࡵ࠯ࠩ࿈")}]
        else:
            l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠩࡰࡷ࡬࠭࿉"):l11l1l11l111_tv_ (u"ࠪࡔࡷࡵࡢ࡭ࡧࡰࠤࡿࠦ࡯ࡤࡼࡼࡸࡦࡴࡩࡦ࡯ࠣॾࡷࣹࡤृࡣࠣ࡯ࡦࡴࡡृࡷ࠱ࠫ࿊")}]
    return l1lll1ll11l11l111_tv_
