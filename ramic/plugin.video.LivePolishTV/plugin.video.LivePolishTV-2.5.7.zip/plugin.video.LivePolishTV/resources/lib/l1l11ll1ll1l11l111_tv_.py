# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡴࡷࡲ࠴࠱ࡴࡴ࡬ࡪࡰࡨ࠲ࡧࡲ࡯ࡨࡵࡳࡳࡹ࠴ࡣࡰ࡯࠲ࡴ࠴ࡺࡶࡱ࠯࠴࠱ࡴࡴ࡬ࡪࡰࡨ࠱ࡰࡧ࡮ࡢ࡮ࡼ࠲࡭ࡺ࡭࡭ࠩ᳑")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭᳒")
__all__=[l11l1l11l111_tv_ (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰࡸ࠭᳓"),l11l1l11l111_tv_ (u"ࠩࡪࡩࡹࡉࡨࡢࡰࡱࡩࡱ࡜ࡩࡥࡧࡲ᳔ࠫ")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ᳕ࠧ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"᳖ࠫࠬ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    data=False
    out=[]
    l1111l111ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠬࡪ࡯ࡤࡷࡰࡩࡳࡺ࠮ࡸࡴ࡬ࡸࡪࡢࠨࡶࡰࡨࡷࡨࡧࡰࡦ࡞ࠫࡠࠬ࠮࠮ࠫࡁࠬࡠࠬࡢࠩࠨ᳗")).findall(content)
    if l1111l111ll11l111_tv_:
        data = urllib.unquote(l1111l111ll11l111_tv_[0])
    l1111l111ll11l111_tv_=re.compile(l11l1l11l111_tv_ (u"࠭ࡤࡰࡥࡸࡱࡪࡴࡴ࠯ࡹࡵ࡭ࡹ࡫࡜ࠩ࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࡠ࠮᳘࠭")).findall(content)
    if l1111l111ll11l111_tv_:
        data= l1111l111ll11l111_tv_[0].replace(l11l1l11l111_tv_ (u"ࠧ࡝࡞ࡸ࠴࠵᳙࠭"),l11l1l11l111_tv_ (u"ࠨࠩ᳚")).decode(l11l1l11l111_tv_ (u"ࠩ࡫ࡩࡽ࠭᳛"))
    if data:
        l1l11ll1l1ll11l111_tv_=re.compile(l11l1l11l111_tv_ (u"ࠪࡀࡧࡻࡴࡵࡱࡱࠤࡨࡲࡡࡴࡵࡀࠦࡧࡻࡴࡵࡱࡱ࠵ࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡡ࡞࠿࡟࠭࠳ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡨࡵࡵࡶࡲࡲࡃ᳜࠭")).findall(data)
        for href,title in l1l11ll1l1ll11l111_tv_:
            h = href
            t = title.strip()
            if h and t:
                out.append({l11l1l11l111_tv_ (u"ࠫࡹ࡯ࡴ࡭ࡧ᳝ࠪ"):t,l11l1l11l111_tv_ (u"ࠬࡺࡶࡪࡦ᳞ࠪ"):t,l11l1l11l111_tv_ (u"࠭ࡩ࡮ࡩ᳟ࠪ"):l11l1l11l111_tv_ (u"ࠧࠨ᳠"),l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬ᳡"):h,l11l1l11l111_tv_ (u"ࠩࡪࡶࡴࡻࡰࠨ᳢"):l11l1l11l111_tv_ (u"᳣ࠪࠫ"),l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࡦࡲࡪ᳤ࠫ"):l11l1l11l111_tv_ (u"᳥ࠬ࠭")})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡹࡦ࡮࡯ࡳࡼࡣࡕࡱࡦࡤࡸࡪࡪ࠺ࠡࠧࡶࠤ࠭ࡩࡩ࡯ࡧࡰࡥ࠲ࡺࡶࠪ࡝࠲ࡇࡔࡒࡏࡓ࡟᳦ࠪ") %time.strftime(l11l1l11l111_tv_ (u"ࠢࠦࡦ࠲ࠩࡲ࠵࡚ࠥ࠼ࠣࠩࡍࡀࠥࡎ࠼ࠨࡗ᳧ࠧ"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫᳨ࠧ"):t,l11l1l11l111_tv_ (u"ࠩࡷࡺ࡮ࡪࠧᳩ"):l11l1l11l111_tv_ (u"ࠪࠫᳪ"),l11l1l11l111_tv_ (u"ࠫ࡮ࡳࡧࠨᳫ"):l11l1l11l111_tv_ (u"ࠬ࠭ᳬ"),l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮᳭ࠪ"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠧࡨࡴࡲࡹࡵ࠭ᳮ"):l11l1l11l111_tv_ (u"ࠨࠩᳯ"),l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩᳰ"):l11l1l11l111_tv_ (u"ࠪࠫᳱ")})
    return out
def l111l1lll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡶ࡯ࡳࡶࡼ࠵࠹࠴ࡢ࡭ࡱࡪࡷࡵࡵࡴ࠯ࡥࡲࡱ࠴ࡶ࠯ࡵࡲ࠴ࡥ࠳࡮ࡴ࡮࡮ࠪᳲ")):
    l1lll1ll11l11l111_tv_=[]
    if l11l1l11l111_tv_ (u"ࠬࡨ࡬ࡰࡩࡶࡴࡴࡺࠧᳳ") in url:
        content = l111111l11l111_tv_(url)
        l111111llll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭ࠢࠩࡴࡷࡱࡵࡀ࠯࠰࠰࠭ࡃ࠮ࠨࠧ᳴")).findall(content)
        l1l1ll1ll1l11l111_tv_=l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡱ࠰࡭ࡻࡵࡩࡤ࡯࠰ࡦࡳࡲ࠵࠶࠰࠳࠵࠳࡯ࡽࡰ࡭ࡣࡼࡩࡷ࠴ࡦ࡭ࡣࡶ࡬࠳ࡹࡷࡧࠩᳵ")
        if l111111llll11l111_tv_:
            href = l111111llll11l111_tv_[0]+ l11l1l11l111_tv_ (u"ࠨࠢࡶࡻ࡫࡛ࡲ࡭࠿ࠨࡷࠥࡶࡡࡨࡧࡘࡶࡱࡃࠥࡴࠢ࡯࡭ࡻ࡫࠽࠲ࠢࡷ࡭ࡲ࡫࡯ࡶࡶࡀ࠵࠵࠭ᳶ")%(l1l1ll1ll1l11l111_tv_,url)
            l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭᳷"):href}]
        l1111l111ll11l111_tv_=re.compile(l11l1l11l111_tv_ (u"ࠪࡨࡴࡩࡵ࡮ࡧࡱࡸ࠳ࡽࡲࡪࡶࡨࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࡝ࠫࠪ᳸")).findall(content)
        if l1111l111ll11l111_tv_:
            data= l1111l111ll11l111_tv_[0].replace(l11l1l11l111_tv_ (u"ࠫࡡࡢࡵ࠱࠲ࠪ᳹"),l11l1l11l111_tv_ (u"ࠬ࠭ᳺ")).decode(l11l1l11l111_tv_ (u"࠭ࡨࡦࡺࠪ᳻"))
            l1111l111ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠧࡥࡱࡦࡹࡲ࡫࡮ࡵ࠰ࡺࡶ࡮ࡺࡥ࡝ࠪࡸࡲࡪࡹࡣࡢࡲࡨࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧ࡝ࠫࠪ᳼")).findall(data)
            if l1111l111ll11l111_tv_:
                data = urllib.unquote(l1111l111ll11l111_tv_[0])
                href = l1ll11ll1ll11l111_tv_.decode(url,data)
                if href: l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬ᳽"):href}]
    return l1lll1ll11l11l111_tv_
def test():
    out=l11l11l1l11l111_tv_()
    for o in out:
        l11ll11ll11l111_tv_ = l111l1lll11l111_tv_(o.get(l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭᳾")))
        print l11ll11ll11l111_tv_
