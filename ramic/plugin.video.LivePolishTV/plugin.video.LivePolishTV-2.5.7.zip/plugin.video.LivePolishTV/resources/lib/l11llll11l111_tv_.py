# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib,urlparse
import re,time
import l1l1lll1l11l111_tv_ as l1llll111lll11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡯ࡱࡺࡻࡦࡺࡣࡩࡶࡹࡰ࡮ࡼࡥ࠯ࡰࡨࡸ࠴࠭ᐮ")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠶࠲࠱࠴࠳࠸࠶࠷࠳࠱࠵࠵࠸ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧᐯ")
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᐰ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠪࠫᐱ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡁ࡮࠳࠿ࡕࡳࡳࡷࡺࡳࠡࡅ࡫ࡥࡳࡴࡥ࡭ࡵ࠿࠳࡭࠹࠾࡝ࡵ࠭ࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡶࡨࡼࡹࡽࡩࡥࡩࡨࡸࠧࡄ࡜ࡴࠬ࠿ࡹࡱࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᐲ"),re.DOTALL).findall(content)
    if l1lll1lllll11l111_tv_:
        for href,title in re.findall(l11l1l11l111_tv_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᐳ"),l1lll1lllll11l111_tv_[0]):
           out.append({l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬᐴ"):title.strip(),l11l1l11l111_tv_ (u"ࠧࡵࡸ࡬ࡨࠬᐵ"):title.strip(),l11l1l11l111_tv_ (u"ࠨ࡫ࡰ࡫ࠬᐶ"):l11l1l11l111_tv_ (u"ࠩࠪᐷ"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᐸ"):urlparse.urljoin(l1llll111ll11l111_tv_,href),l11l1l11l111_tv_ (u"ࠫ࡬ࡸ࡯ࡶࡲࠪᐹ"):l11l1l11l111_tv_ (u"ࠬࡹࡰࡰࡴࡷࠫᐺ"),l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࡨࡴ࡬࠭ᐻ"):l11l1l11l111_tv_ (u"ࠧࠨᐼ")})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡻࡨࡰࡱࡵࡷ࡞ࡗࡳࡨࡦࡺࡥࡥ࠼ࠣࠩࡸࠦࠨ࡯ࡱࡺࡻࡦࡺࡣࡩࡶࡹࡰ࡮ࡼࡥࠡࡕࡓࡓࡗ࡚ࠩ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᐽ") %time.strftime(l11l1l11l111_tv_ (u"ࠤࠨࡨ࠴ࠫ࡭࠰ࠧ࡜࠾ࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢᐾ"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩᐿ"):t,l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩᑀ"):l11l1l11l111_tv_ (u"ࠬ࠭ᑁ"),l11l1l11l111_tv_ (u"࠭ࡩ࡮ࡩࠪᑂ"):l11l1l11l111_tv_ (u"ࠧࠨᑃ"),l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬᑄ"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠩࡪࡶࡴࡻࡰࠨᑅ"):l11l1l11l111_tv_ (u"ࠪࠫᑆ"),l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫᑇ"):l11l1l11l111_tv_ (u"ࠬ࠭ᑈ")})
    return out
l1llll1ll11l111_tv_ = l1llll111lll11l111_tv_.l1llll1ll11l111_tv_
l111l1lll11l111_tv_ = l1llll111lll11l111_tv_.l111l1lll11l111_tv_
def test():
    out=l11l11l1l11l111_tv_()
    l1l1l1ll11l111_tv_=out[0]
    items=l1llll1ll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪᑉ")))
    for item in items:
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_( item )
