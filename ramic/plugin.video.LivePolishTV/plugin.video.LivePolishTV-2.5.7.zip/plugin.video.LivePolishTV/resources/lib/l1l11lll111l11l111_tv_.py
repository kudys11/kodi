# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re
from urlparse import urlparse
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡺࡥ࡭ࡧࡺ࡭ࡿࡿࡪ࡬ࡣ࠱ࡴࡱ࠵ࠧᱼ")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠰࠯࠲࠱࠶࠻࠼࠱࠯࠳࠳࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬᱽ")
__all__=[l11l1l11l111_tv_ (u"ࠧࡨࡧࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ᱾"),l11l1l11l111_tv_ (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰ࡛࡯ࡤࡦࡱࠪ᱿"),l11l1l11l111_tv_ (u"ࠩࡪࡩࡹ࡙ࡴࡳࡧࡤࡱࡸ࠭ᲀ")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᲁ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except: l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠫࠬᲂ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1l11ll1llll11l111_tv_ = l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡺࡥ࡭ࡧࡺ࡭ࡿࡿࡪ࡬ࡣ࠱ࡴࡱ࠵ࡩ࡯ࡦࡨࡼ࠳ࡶࡨࡱࡁࡷࡺࡂ࠭ᲃ")
    l11llll11ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭࠼ࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠨᲄ")).findall(content)
    for ch in l11llll11ll11l111_tv_:
        t=ch
        href=l1l11ll1llll11l111_tv_+urllib.quote_plus(ch)
        out.append({l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᲅ"):t,l11l1l11l111_tv_ (u"ࠨࡶࡹ࡭ࡩ࠭ᲆ"):t,l11l1l11l111_tv_ (u"ࠩ࡬ࡱ࡬࠭ᲇ"):l11l1l11l111_tv_ (u"ࠪࠫᲈ"),l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨᲉ"):href,l11l1l11l111_tv_ (u"ࠬ࡭ࡲࡰࡷࡳࠫᲊ"):l11l1l11l111_tv_ (u"࠭ࠧ᲋"),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࡩࡵ࡭ࠧ᲌"):l11l1l11l111_tv_ (u"ࠨࠩ᲍"),l11l1l11l111_tv_ (u"ࠩࡳࡰࡴࡺࠧ᲎"):l11l1l11l111_tv_ (u"ࠪࠫ᲏"),l11l1l11l111_tv_ (u"ࠫࡨࡵࡤࡦࠩᲐ"):l11l1l11l111_tv_ (u"ࠬ࠭Ბ")})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡹࡦ࡮࡯ࡳࡼࡣࡕࡱࡦࡤࡸࡪࡪ࠺ࠡࠧࡶࠤ࠭ࡶࡳࡢ࠯ࡷࡺ࠮ࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᲒ") %time.strftime(l11l1l11l111_tv_ (u"ࠢࠦࡦ࠲ࠩࡲ࠵࡚ࠥ࠼ࠣࠩࡍࡀࠥࡎ࠼ࠨࡗࠧᲓ"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᲔ"):t,l11l1l11l111_tv_ (u"ࠩࡷࡺ࡮ࡪࠧᲕ"):l11l1l11l111_tv_ (u"ࠪࠫᲖ"),l11l1l11l111_tv_ (u"ࠫ࡮ࡳࡧࠨᲗ"):l11l1l11l111_tv_ (u"ࠬ࠭Ი"),l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪᲙ"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠧࡨࡴࡲࡹࡵ࠭Ლ"):l11l1l11l111_tv_ (u"ࠨࠩᲛ"),l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩᲜ"):l11l1l11l111_tv_ (u"ࠪࠫᲝ")})
    return out
l11ll11l11l11l111_tv_=[l11l1l11l111_tv_ (u"ࠫࡸࡺࡡࡵ࡫ࡦ࠲ࡺ࠳ࡰࡳࡱ࠱ࡪࡷ࠭Პ"),l11l1l11l111_tv_ (u"ࠬࡺࡥ࡭ࡧࡺ࡭ࡿࡰࡡ࠯࡯࡯ࠫᲟ"),l11l1l11l111_tv_ (u"࠭ࡴࡦ࡮ࡨࡱࡦࡴࡩࡢ࡭࠱ࡳࡷ࡭ࠧᲠ"),l11l1l11l111_tv_ (u"ࠧ࡯ࡱࡺࡥࡹࡼ࠮࡯ࡧࡷࠫᲡ"),l11l1l11l111_tv_ (u"ࠨࡶࡨࡰࡪࡽࡩࡻ࡬ࡤ࠱ࡱ࡯ࡶࡦ࠰ࡦࡳࡲ࠭Ტ"),l11l1l11l111_tv_ (u"ࠩࡸࡶ࡭ࡪ࠮ࡵࡸࠪᲣ"),
    l11l1l11l111_tv_ (u"ࠪ࡭ࡰࡲࡵࡣ࠰ࡱࡩࡹ࠭Ფ"),l11l1l11l111_tv_ (u"ࠫࡱࡵ࡯࡬ࡰ࡬࡮࠳࡯࡮ࠨᲥ"),l11l1l11l111_tv_ (u"ࠬࡽࡩࡻ࡬ࡤ࠲ࡹࡼࠧᲦ"),l11l1l11l111_tv_ (u"࠭ࡷࡸࡹ࠱ࡸࡻࡶ࠮ࡱ࡮ࠪᲧ"),l11l1l11l111_tv_ (u"ࠧࡵࡧ࡯ࡩ࠲ࡽࡩࡻ࡬ࡤ࠲ࡨࡵ࡭ࠨᲨ")]
def l1llll1ll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡹ࠱ࡴࡴ࡬ࡪࡰࡨ࠲࡫ࡳ࠯ࡵࡧ࡯ࡩࡼ࡯ࡺ࡫ࡣ࠱ࡴ࡭ࡶ࠿ࡵࡸ࠷ࡃࡵࡵࡤࡴࡶࡤࡻࡴࡽࡥࠨᲩ")):
    out=[]
    content = l111111l11l111_tv_(url)
    l11ll1ll1ll11l111_tv_ =re.compile(l11l1l11l111_tv_ (u"ࠩࡷࡥࡷ࡭ࡥࡵ࠿ࠥࡣࡧࡲࡡ࡯࡭ࠥࠤࡷ࡫࡬࠾ࠤࡱࡳ࡫ࡵ࡬࡭ࡱࡺࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᲪ")).findall(content)
    for l11ll11ll11l111_tv_ in l11ll1ll1ll11l111_tv_:
        title = urlparse(l11ll11ll11l111_tv_).netloc
        if title in l11ll11l11l11l111_tv_:
            title = l11l1l11l111_tv_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡷ࡫ࡥ࡯࡟ࠨࡷࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Ძ")%title
        else:
            title = l11l1l11l111_tv_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞ࠧࡶ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᲬ")%title
        out.append({l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫᲭ"):title,l11l1l11l111_tv_ (u"࠭ࡴࡷ࡫ࡧࠫᲮ"):title,l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫᲯ"):l11ll11ll11l111_tv_})
    return out
def l111l1lll11l111_tv_(item):
    host = item.get(l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᲰ"))
    url = item.get(l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭Ჱ"))
    l1lll1ll11l11l111_tv_=l11l1l11l111_tv_ (u"ࠪࠫᲲ")
    if l11l1l11l111_tv_ (u"ࠫࡸࡺࡡࡵ࡫ࡦ࠲ࡺ࠳ࡰࡳࡱ࠱ࡪࡷ࠭Ჳ") in host:
        data=l11l1l11l111_tv_ (u"ࠬࡹࡲࡤ࠿ࠥࠩࡸࠨࠧᲴ")%url
        l1lll1ll11l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
    elif l11l1l11l111_tv_ (u"࠭ࡴࡦ࡮ࡨࡻ࡮ࢀࡪࡢ࠰ࡰࡰࠬᲵ") in url:
        data = l111111l11l111_tv_(url)
        tmp = re.compile(l11l1l11l111_tv_ (u"ࠧࡴࡴࡦࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࠩᲶ")).findall(data)
        if tmp:
            if l11l1l11l111_tv_ (u"ࠨࡶࡨࡰࡪ࠳ࡷࡪࡼ࡭ࡥ࠳ࡩ࡯࡮ࠩᲷ") in tmp[0] or l11l1l11l111_tv_ (u"ࠩࡷࡩࡱ࡫ࡷࡪࡼ࡭ࡥ࠲ࡲࡩࡷࡧ࠱ࡧࡴࡳࠧᲸ") in tmp[0]:
                data = l111111l11l111_tv_(tmp[0])
        l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
    elif l11l1l11l111_tv_ (u"ࠪࡸࡪࡲࡥ࡮ࡣࡱ࡭ࡦࡱ࠮ࡰࡴࡪࠫᲹ") in url:
        from l1ll1ll1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url.replace(l11l1l11l111_tv_ (u"ࠫ࠴ࡲࡩࡷࡧ࠲ࠫᲺ"),l11l1l11l111_tv_ (u"ࠬ࠵ࡤࡢࡶࡤ࠳ࠬ᲻")))
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪ᲼"),l11l1l11l111_tv_ (u"ࠧࠨᲽ"))
    elif l11l1l11l111_tv_ (u"ࠨࡰࡲࡻࡦࡺࡶ࠯ࡰࡨࡸࠬᲾ") in url:
        from l1ll1l1l1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url.replace(l11l1l11l111_tv_ (u"ࠩ࠲ࡰ࡮ࡼࡥ࠰ࠩᲿ"),l11l1l11l111_tv_ (u"ࠪ࠳ࡩࡧࡴࡢ࠱ࠪ᳀")))
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨ᳁"),l11l1l11l111_tv_ (u"ࠬ࠭᳂"))
    elif l11l1l11l111_tv_ (u"࠭ࡵࡳࡪࡧ࠲ࡹࡼࠧ᳃") in host:
        data=l11l1l11l111_tv_ (u"ࠧࡴࡴࡦࡁࠧࠫࡳࠣࠩ᳄")%url
        l1lll1ll11l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
    elif l11l1l11l111_tv_ (u"ࠨ࡫࡮ࡰࡺࡨ࠮࡯ࡧࡷࠫ᳅") in host:
        from l1l11llll11l111_tv_ import _1l1l11l11l11l111_tv_
        l1lll1ll11l11l111_tv_ = _1l1l11l11l11l111_tv_(url)
    elif l11l1l11l111_tv_ (u"ࠩ࡯ࡳࡴࡱ࡮ࡪ࡬࠱࡭ࡳ࠭᳆") in host:
        from l1lll1l1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧ᳇"),l11l1l11l111_tv_ (u"ࠫࠬ᳈"))
    elif l11l1l11l111_tv_ (u"ࠬࡽࡩࡻ࡬ࡤ࠲ࡹࡼࠧ᳉") in host:
        from l1l1lllll11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪ᳊"),l11l1l11l111_tv_ (u"ࠧࠨ᳋"))
    elif l11l1l11l111_tv_ (u"ࠨࡶࡨࡰࡪࡽࡩࡻ࡬ࡤ࠱ࡱ࡯ࡶࡦ࠰ࡦࡳࡲ࠭᳌") in host:
        data = l111111l11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
    elif l11l1l11l111_tv_ (u"ࠩࡷࡩࡱ࡫࠭ࡸ࡫ࡽ࡮ࡦ࠭᳍") in host:
        data = l111111l11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
    elif l11l1l11l111_tv_ (u"ࠪࡻࡼࡽ࠮ࡵࡸࡳ࠲ࡵࡲࠧ᳎") in host:
        from l11ll1lll11l111_tv_ import _1l1l11l11l11l111_tv_
        l1lll1ll11l11l111_tv_ = _1l1l11l11l11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨ᳏"),l11l1l11l111_tv_ (u"ࠬ࠭᳐"))
    return l1lll1ll11l11l111_tv_
