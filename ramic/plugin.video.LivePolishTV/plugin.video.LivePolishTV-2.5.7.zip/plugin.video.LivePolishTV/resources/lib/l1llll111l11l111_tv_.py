# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re,time
import l1ll11ll1ll11l111_tv_
import l1ll1ll111l11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡪࡡࡳ࡯ࡲࡻࡦ࠳ࡴࡷ࠰ࡳࡰࠬග")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠰࠯࠲࠱࠶࠻࠼࠱࠯࠳࠳࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬඝ")
__all__=[l11l1l11l111_tv_ (u"ࠧࡨࡧࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬඞ"),l11l1l11l111_tv_ (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰ࡛࡯ࡤࡦࡱࠪඟ")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ච"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠪࠫඡ")
    return l11ll11ll11l111_tv_
locals={
l11l1l11l111_tv_ (u"ࠦࡕࡵ࡬ࡴࡣࡷࠤ࠷ࠨජ") 									:l11l1l11l111_tv_ (u"ࠧ࠮ࡐࡰ࡮࡞ࡰࡢ࠰ࡳࡢࡶ࡞ࡠࡸ࠳࡝ࠫ࠴ࠫ࡟ࡡࡹ࠭࡞ࠬࡗ࡚࠮ࡅࠨ࡜࡞ࡶ࠱ࡢ࠰ࡈࡅࠫࡂ࠭ࠧඣ"),
l11l1l11l111_tv_ (u"ࠨࡐࡰ࡮ࡶࡥࡹࠦࡓࡱࡱࡵࡸࠧඤ") 								:l11l1l11l111_tv_ (u"ࠢࠩࡒࡲࡰࡠࡲ࡝ࠫࡵࡤࡸࡠࡢࡳ࠮࡟࠭ࡗࡵࡵࡲࡵࠪ࡞ࡠࡸ࠳࡝ࠫ࠳ࠬࡃ࠭ࡡ࡜ࡴ࠯ࡠ࠮࡙࡜ࠩࡀࠪ࡞ࡠࡸ࠳࡝ࠫࡊࡇ࠭ࡄ࠯ࠢඥ"),
}
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡦࡤࡶࡲࡵࡷࡢ࠯ࡷࡺ࠳ࡶ࡬ࠨඦ"))
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴ࡪࡡࡳ࡯ࡲࡻࡦ࠳ࡴࡷ࠰ࡳࡰ࠴࠴ࠫࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠬට")).findall(content)
    for href,title in l1lll1lllll11l111_tv_:
        out.append({l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩඨ"):title.strip(),l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩඩ"):title.strip(),l11l1l11l111_tv_ (u"ࠬ࡯࡭ࡨࠩඪ"):l11l1l11l111_tv_ (u"࠭ࠠࠨණ"),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫඬ"):href,l11l1l11l111_tv_ (u"ࠨࡩࡵࡳࡺࡶࠧත"):l11l1l11l111_tv_ (u"ࠩࠣࠫථ"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࡥࡱࡩࠪද"):l11l1l11l111_tv_ (u"ࠫࠥ࠭ධ")})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡿࡥ࡭࡮ࡲࡻࡢ࡛ࡰࡥࡣࡷࡩࡩࡀࠠࠦࡵࠣࠬࡩࡧࡲ࡮ࡱࡺࡥ࠲ࡺࡶ࠯ࡲ࡯࠭ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭න") %time.strftime(l11l1l11l111_tv_ (u"ࠨࠥࡥ࠱ࠨࡱ࠴࡙ࠫ࠻ࠢࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠦ඲"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ඳ"):t,l11l1l11l111_tv_ (u"ࠨࡶࡹ࡭ࡩ࠭ප"):l11l1l11l111_tv_ (u"ࠩࠪඵ"),l11l1l11l111_tv_ (u"ࠪ࡭ࡲ࡭ࠧබ"):l11l1l11l111_tv_ (u"ࠫࠬභ"),l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩම"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"࠭ࡧࡳࡱࡸࡴࠬඹ"):l11l1l11l111_tv_ (u"ࠧࠨය"),l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࡪࡶࡧࠨර"):l11l1l11l111_tv_ (u"ࠩࠪ඼")})
    return l1ll1ll111l11l111_tv_.l1ll1ll1l1l11l111_tv_(out,locals)
def l111l1lll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡨࡦࡸ࡭ࡰࡹࡤ࠱ࡹࡼ࠮ࡱ࡮࠲ࡴࡴࡲࡳࡢࡶ࠰࡬ࡩ࠵ࠧල")):
    l1lll1ll11l11l111_tv_=[]
    if l11l1l11l111_tv_ (u"ࠫࡰࡧ࡮ࡢ࡮ࡼࠫ඾") in url:
        data = l111111l11l111_tv_(url.replace(l11l1l11l111_tv_ (u"ࠬࠦࠧ඿"),l11l1l11l111_tv_ (u"࠭ࠥ࠳࠲ࠪව")))
        l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
        if l1ll11lll1l11l111_tv_:
            l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫශ"):l1ll11lll1l11l111_tv_}]
    else:
        content = l111111l11l111_tv_(url)
        l1ll1l1111l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠪ࠱࠯ࡰࡧ࡮ࡢ࡮ࡼ࠲࠯ࡅࠩ࠽࠱࡬ࡪࡷࡧ࡭ࡦࡀࠪෂ")).findall(content)
        if l1ll1l1111l11l111_tv_:
            src = re.compile(l11l1l11l111_tv_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧස"),re.IGNORECASE).findall(l1ll1l1111l11l111_tv_[0])
            if src:
                data = l111111l11l111_tv_(src[0].replace(l11l1l11l111_tv_ (u"ࠪࠤࠬහ"),l11l1l11l111_tv_ (u"ࠫࠪ࠸࠰ࠨළ")))
                l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src[0],data)
                if l1ll11lll1l11l111_tv_:
                    l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩෆ"):l1ll11lll1l11l111_tv_}]
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        print l11l1l11l111_tv_ (u"࠭࡜࡯ࠩ෇"),l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭෈"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬ෉")))
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ්")))
        print l1lll1ll11l11l111_tv_
