# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re,time
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹ࡫࡬ࡦࡹ࡬ࡾ࡯ࡧ࠮࡮࡮ࠪ᮷")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠺࠶࠮࠱࠰࠵࠺࠻࠷࠮࠲࠲࠵ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫ᮸")
__all__=[l11l1l11l111_tv_ (u"࠭ࡧࡦࡶࡆ࡬ࡦࡴ࡮ࡦ࡮ࡶࠫ᮹"),l11l1l11l111_tv_ (u"ࠧࡨࡧࡷࡇ࡭ࡧ࡮࡯ࡧ࡯࡚࡮ࡪࡥࡰࠩᮺ")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᮻ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠩࠪᮼ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸࡪࡲࡥࡸ࡫ࡽ࡮ࡦ࠴࡭࡭࠱ࡦ࡬ࡦࡴ࡮ࡦ࡮ࡶ࠳ࠬᮽ"))
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡦ࡬ࡦࡴ࡮ࡦ࡮ࠥࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠽࠱ࡤࡂࡁ࠵ࡤࡪࡸࡁࠫᮾ")).findall(content)
    for href,_1l11lll1l1l11l111_tv_,l1llll11lll11l111_tv_,title in l1lll1lllll11l111_tv_:
        out.append({l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫᮿ"):title.strip(),l11l1l11l111_tv_ (u"࠭ࡴࡷ࡫ࡧࠫᯀ"):title.strip(),l11l1l11l111_tv_ (u"ࠧࡪ࡯ࡪࠫᯁ"):l1llll11lll11l111_tv_,l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬᯂ"):href,l11l1l11l111_tv_ (u"ࠩࡪࡶࡴࡻࡰࠨᯃ"):l11l1l11l111_tv_ (u"ࠪࠫᯄ"),l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫᯅ"):l11l1l11l111_tv_ (u"ࠬ࠭ᯆ")})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡹࡦ࡮࡯ࡳࡼࡣࡕࡱࡦࡤࡸࡪࡪ࠺ࠡࠧࡶࠤ࠭ࡺࡥ࡭ࡧࡺ࡭ࡿࡰࡡ࠯࡯࡯࠭ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᯇ") %time.strftime(l11l1l11l111_tv_ (u"ࠢࠦࡦ࠲ࠩࡲ࠵࡚ࠥ࠼ࠣࠩࡍࡀࠥࡎ࠼ࠨࡗࠧᯈ"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᯉ"):t,l11l1l11l111_tv_ (u"ࠩࡷࡺ࡮ࡪࠧᯊ"):l11l1l11l111_tv_ (u"ࠪࠫᯋ"),l11l1l11l111_tv_ (u"ࠫ࡮ࡳࡧࠨᯌ"):l11l1l11l111_tv_ (u"ࠬ࠭ᯍ"),l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪᯎ"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠧࡨࡴࡲࡹࡵ࠭ᯏ"):l11l1l11l111_tv_ (u"ࠨࠩᯐ"),l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩᯑ"):l11l1l11l111_tv_ (u"ࠪࠫᯒ")})
    return out
def l111l1lll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹ࡫࡬ࡦࡹ࡬ࡾ࡯ࡧ࠮࡮࡮࠲ࡸࡻ࠵ࡴࡷࡲ࠰࠵࠴࠭ᯓ")):
    l1lll1ll11l11l111_tv_=[]
    if l11l1l11l111_tv_ (u"ࠬࡺࡥ࡭ࡧࡺ࡭ࡿࡰࡡ࠯࡯࡯ࠫᯔ") in url:
        content = l111111l11l111_tv_(url)
        l1ll1l1111l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡩࡧࡴࡤࡱࡪࡄࠧᯕ")).findall(content)
        if l1ll1l1111l11l111_tv_:
            src = re.compile(l11l1l11l111_tv_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᯖ"),re.IGNORECASE).findall(l1ll1l1111l11l111_tv_[0])
            if src:
                data = l111111l11l111_tv_(src[0])
                tmp = re.compile(l11l1l11l111_tv_ (u"ࠨࡵࡵࡧࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࠪᯗ")).findall(data)
                if tmp:
                    if l11l1l11l111_tv_ (u"ࠩࡷࡩࡱ࡫࠭ࡸ࡫ࡽ࡮ࡦ࠴ࡣࡰ࡯ࠪᯘ") in tmp[0] or l11l1l11l111_tv_ (u"ࠪࡸࡪࡲࡥࡸ࡫ࡽ࡮ࡦ࠳࡬ࡪࡸࡨ࠲ࡨࡵ࡭ࠨᯙ") in tmp[0]:
                        data = l111111l11l111_tv_(tmp[0])
                l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src[0],data)
                if l1ll11lll1l11l111_tv_: l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨᯚ"):l1ll11lll1l11l111_tv_}]
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        print l11l1l11l111_tv_ (u"ࠬࡢ࡮ࠨᯛ"),l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬᯜ"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫᯝ")))
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᯞ")))
        print l1lll1ll11l11l111_tv_
