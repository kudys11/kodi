# coding: UTF-8
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urlparse,cookielib,urllib2,urllib
import time,re,os
url=l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬࡬ࡴࡲࡡ࡯ࡦ࡬ࡥ࠳ࡺࡶ࠰ࠩ୩")
l1llll1ll1l11l111_tv_= cookielib.LWPCookieJar()
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡏࡘ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠸࠴࠳࠶࠮࠳࠸࠹࠵࠳࠷࠰࠳ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩ୪")
l1lll11l11l11l111_tv_=l1lll1l1lll11l111_tv_
def l1ll1llllll11l111_tv_(url,l1llll1ll1l11l111_tv_=l1llll1ll1l11l111_tv_,l1lll11l11l11l111_tv_=l1lll1l1lll11l111_tv_):
    l1ll1lll11l11l111_tv_=l11l1l11l111_tv_ (u"ࠫࠬ୫")
    try:
        class l1lll1111ll11l111_tv_(urllib2.HTTPErrorProcessor):
            def http_response(self, request, response):
                return response
        def l1ll1lll1ll11l111_tv_(s):
            try:
                offset=1 if s[0]==l11l1l11l111_tv_ (u"ࠬ࠱ࠧ୬") else 0
                val = int(eval(s.replace(l11l1l11l111_tv_ (u"࠭ࠡࠬ࡝ࡠࠫ୭"),l11l1l11l111_tv_ (u"ࠧ࠲ࠩ୮")).replace(l11l1l11l111_tv_ (u"ࠨࠣࠤ࡟ࡢ࠭୯"),l11l1l11l111_tv_ (u"ࠩ࠴ࠫ୰")).replace(l11l1l11l111_tv_ (u"ࠪ࡟ࡢ࠭ୱ"),l11l1l11l111_tv_ (u"ࠫ࠵࠭୲")).replace(l11l1l11l111_tv_ (u"ࠬ࠮ࠧ୳"),l11l1l11l111_tv_ (u"࠭ࡳࡵࡴࠫࠫ୴"))[offset:]))
                return val
            except:
                pass
        if l1llll1ll1l11l111_tv_==None:
            l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(l1lll1111ll11l111_tv_, urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        opener.addheaders = [(l11l1l11l111_tv_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ୵"), l1lll11l11l11l111_tv_)]
        try:
            response = opener.open(url)
            result=l1ll1lll11l11l111_tv_ = response.read()
            response.close()
        except urllib2.HTTPError as e:
            result=l1ll1lll11l11l111_tv_ = e.read()
        l1lll1l111l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠨࡰࡤࡱࡪࡃࠢ࡫ࡵࡦ࡬ࡱࡥࡶࡤࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠱࠿ࠪࠤ࠲ࡂࠬ୶")).findall(result)[0]
        init = re.compile(l11l1l11l111_tv_ (u"ࠩࡶࡩࡹ࡚ࡩ࡮ࡧࡲࡹࡹࡢࠨࡧࡷࡱࡧࡹ࡯࡯࡯࡞ࠫࡠ࠮ࢁ࡜ࡴࠬ࠱࠮ࡄ࠴ࠪ࠻ࠪ࠱࠮ࡄ࠯ࡽ࠼ࠩ୷")).findall(result)[0]
        l1lll11llll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࡵࠦࡨ࡮ࡡ࡭࡮ࡨࡲ࡬࡫࠭ࡧࡱࡵࡱࡡ࠭࡜ࠪ࠽࡟ࡷ࠯࠮࠮ࠫࠫࡤ࠲ࡻࠨ୸")).findall(result)[0]
        l1lll11l1ll11l111_tv_ = l1ll1lll1ll11l111_tv_(init)
        lines = l1lll11llll11l111_tv_.split(l11l1l11l111_tv_ (u"ࠫࡀ࠭୹"))
        if l1lll1l111l11l111_tv_:
            for line in lines:
                if len(line)>0 and l11l1l11l111_tv_ (u"ࠬࡃࠧ୺") in line:
                    l1lll11ll1l11l111_tv_=line.split(l11l1l11l111_tv_ (u"࠭࠽ࠨ୻"))
                    l1ll1ll1lll11l111_tv_ = l1ll1lll1ll11l111_tv_(l1lll11ll1l11l111_tv_[1])
                    l1lll11l1ll11l111_tv_ = int(eval(str(l1lll11l1ll11l111_tv_)+l1lll11ll1l11l111_tv_[0][-1]+str(l1ll1ll1lll11l111_tv_)))
            l1ll1llll1l11l111_tv_ = l1lll11l1ll11l111_tv_ + len(urlparse.urlparse(url).netloc)
            u=url
            query = l11l1l11l111_tv_ (u"ࠧࠦࡵ࠲ࡧࡩࡴ࠭ࡤࡩ࡬࠳ࡱ࠵ࡣࡩ࡭ࡢ࡮ࡸࡩࡨ࡭ࡁ࡭ࡷࡨ࡮࡬ࡠࡸࡦࡁࠪࡹࠦ࡫ࡵࡦ࡬ࡱࡥࡡ࡯ࡵࡺࡩࡷࡃࠥࡴࠩ୼") % (u, l1lll1l111l11l111_tv_, l1ll1llll1l11l111_tv_)
            if l11l1l11l111_tv_ (u"ࠨࡶࡼࡴࡪࡃࠢࡩ࡫ࡧࡨࡪࡴࠢࠡࡰࡤࡱࡪࡃࠢࡱࡣࡶࡷࠧ࠭୽") in result:
                l1lll111lll11l111_tv_=re.compile(l11l1l11l111_tv_ (u"ࠩࡱࡥࡲ࡫࠽ࠣࡲࡤࡷࡸࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ୾")).findall(result)[0]
                query = l11l1l11l111_tv_ (u"ࠪࠩࡸ࠵ࡣࡥࡰ࠰ࡧ࡬࡯࠯࡭࠱ࡦ࡬ࡰࡥࡪࡴࡥ࡫ࡰࡄࡶࡡࡴࡵࡀࠩࡸࠬࡪࡴࡥ࡫ࡰࡤࡼࡣ࠾ࠧࡶࠪ࡯ࡹࡣࡩ࡮ࡢࡥࡳࡹࡷࡦࡴࡀࠩࡸ࠭୿") % (u,urllib.quote_plus(l1lll111lll11l111_tv_), l1lll1l111l11l111_tv_, l1ll1llll1l11l111_tv_)
                time.sleep(5)
            l1llll1l11l11l111_tv_ =l11l1l11l111_tv_ (u"ࠫࠬ஀").join([l11l1l11l111_tv_ (u"ࠬࠫࡳ࠾ࠧࡶ࠿ࠬ஁")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
            opener = urllib2.build_opener(l1lll1111ll11l111_tv_,urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
            opener.addheaders = [(l11l1l11l111_tv_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪஂ"), l1lll11l11l11l111_tv_)]
            opener.addheaders.append((l11l1l11l111_tv_ (u"ࠧࡤࡱࡲ࡯࡮࡫ࠧஃ"),l1llll1l11l11l111_tv_))
            opener.addheaders.append((l11l1l11l111_tv_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ஄"),l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡩ࡭ࡱ࡯ࡳࡦࡴ࠱ࡸࡻ࠵ࠧஅ")))
            try:
                response = opener.open(query)
                response.close()
            except urllib2.HTTPError as e:
                response = e.read()
        return l1llll1ll1l11l111_tv_
    except:
        return None
def l1lll1l11ll11l111_tv_(l11ll111l11l111_tv_):
    l1lll111l1l11l111_tv_=l11l1l11l111_tv_ (u"ࠪࠫஆ")
    if os.path.isfile(l11ll111l11l111_tv_):
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        l1llll1ll1l11l111_tv_.load(l11ll111l11l111_tv_)
        for c in l1llll1ll1l11l111_tv_:
            l1lll111l1l11l111_tv_+=l11l1l11l111_tv_ (u"ࠫࠪࡹ࠽ࠦࡵ࠾ࠫஇ")%(c.name, c.value)
    return l1lll111l1l11l111_tv_
