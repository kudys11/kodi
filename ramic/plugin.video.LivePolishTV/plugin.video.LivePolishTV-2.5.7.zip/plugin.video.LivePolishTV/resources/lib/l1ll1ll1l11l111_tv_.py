# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re,json
import time
import cookielib
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡺࡥ࡭ࡧࡰࡥࡳ࡯ࡡ࡬࠰ࡲࡶ࡬࠭ᤃ")
l1lll1ll1ll11l111_tv_=10
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠰࠯࠲࠱࠶࠻࠼࠱࠯࠳࠳࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬᤄ")
__all__=[l11l1l11l111_tv_ (u"ࠧࡨࡧࡷࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬᤅ"),l11l1l11l111_tv_ (u"ࠨࡩࡨࡸࡈ࡮ࡡ࡯ࡰࡨࡰ࡛࡯ࡤࡦࡱࠪᤆ")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᤇ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠪࠫᤈ")
    return l11ll11ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},l1llll1111l11l111_tv_=True):
    l1llll1l11l11l111_tv_=l11l1l11l111_tv_ (u"ࠫࠬᤉ")
    l1llll1ll1l11l111_tv_=[]
    if l1llll1111l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {l11l1l11l111_tv_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᤊ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1lll1ll1ll11l111_tv_)
        l11ll11ll11l111_tv_ =  response.read()
        response.close()
        l1llll1l11l11l111_tv_ = l11l1l11l111_tv_ (u"࠭ࠧᤋ").join([l11l1l11l111_tv_ (u"ࠧࠦࡵࡀࠩࡸࡁࠧᤌ")%(c.name, c.value) for c in l1llll1ll1l11l111_tv_])
    except urllib2.HTTPError as e:
        l11ll11ll11l111_tv_ = l11l1l11l111_tv_ (u"ࠨࠩᤍ")
    return l11ll11ll11l111_tv_,l1llll1l11l11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content,c = l111111l11l111_tv_(l11l1l11l111_tv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡷࡩࡱ࡫࡭ࡢࡰ࡬ࡥࡰ࠴࡯ࡳࡩ࠲ࡷࡹࡸࡥࡢ࡯ࡶࠫᤎ"))
    try:
        data = json.loads(content)
    except:
        data=[]
    out=[]
    for d in data:
        l1llll11lll11l111_tv_= l1llll111ll11l111_tv_+d.get(l11l1l11l111_tv_ (u"ࠪࡰࡴ࡭࡯ࠨᤏ"))
        title=d.get(l11l1l11l111_tv_ (u"ࠫࡳࡧ࡭ࡦࠩᤐ"))
        href=l1llll111ll11l111_tv_+l11l1l11l111_tv_ (u"ࠬ࠵ࡤࡢࡶࡤ࠳ࠬᤑ")+d.get(l11l1l11l111_tv_ (u"࠭ࡣࡩࡣࡱࡩࡱ࠭ᤒ"))+l11l1l11l111_tv_ (u"ࠧࡀࠩᤓ")+c
        out.append({l11l1l11l111_tv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᤔ"):title.strip(),l11l1l11l111_tv_ (u"ࠩࡷࡺ࡮ࡪࠧᤕ"):title.strip(),l11l1l11l111_tv_ (u"ࠪ࡭ࡲ࡭ࠧᤖ"):l1llll11lll11l111_tv_,l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨᤗ"):href,l11l1l11l111_tv_ (u"ࠬ࡭ࡲࡰࡷࡳࠫᤘ"):l11l1l11l111_tv_ (u"࠭ࠧᤙ"),l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࡩࡵ࡭ࠧᤚ"):l11l1l11l111_tv_ (u"ࠨࠩᤛ")})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡼࡩࡱࡲ࡯ࡸ࡟ࡘࡴࡩࡧࡴࡦࡦ࠽ࠤࠪࡹࠠࠩࡶࡨࡰࡪࡳࡡ࡯࡫ࡤ࡯࠳ࡵࡲࡨࠫ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᤜ") %time.strftime(l11l1l11l111_tv_ (u"ࠥࠩࡩ࠵ࠥ࡮࠱ࠨ࡝࠿ࠦࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠣᤝ"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪᤞ"):t,l11l1l11l111_tv_ (u"ࠬࡺࡶࡪࡦࠪ᤟"):l11l1l11l111_tv_ (u"࠭ࠧᤠ"),l11l1l11l111_tv_ (u"ࠧࡪ࡯ࡪࠫᤡ"):l11l1l11l111_tv_ (u"ࠨࠩᤢ"),l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭ᤣ"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠪ࡫ࡷࡵࡵࡱࠩᤤ"):l11l1l11l111_tv_ (u"ࠫࠬᤥ"),l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࡧࡳ࡫ࠬᤦ"):l11l1l11l111_tv_ (u"࠭ࠧᤧ")})
    return out
def l111l1lll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡵࡧ࡯ࡩࡲࡧ࡮ࡪࡣ࡮࠲ࡴࡸࡧ࠰ࡦࡤࡸࡦ࠵ࡗ࠷࠷ࡎ࠽ࡑ࡟ࡘ࠷ࡑࡂࡣࡤࡩࡦࡥࡷ࡬ࡨࡂࡪࡦ࠹࠲࠼࠺࠶࠼ࡡ࠳࠶ࡧࡧ࠼࠿࠲ࡦࡧ࠸࠶࠾࠽࠳࠹࠷࠺࠶࠷ࡧࡣ࠵ࡨ࠹࠵࠹࠾࠵࠷࠴࠴࠽࠷࠸࠻ࠨᤨ")):
    url,l1llll1l11l11l111_tv_=url.split(l11l1l11l111_tv_ (u"ࠨࡁࠪᤩ")) if l11l1l11l111_tv_ (u"ࠩࡂࠫᤪ")in url else (url,l11l1l11l111_tv_ (u"ࠪࠫᤫ"))
    print url,l1llll1l11l11l111_tv_
    l1lll1ll11l11l111_tv_=[]
    header ={l11l1l11l111_tv_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ᤬"):l1lll1l1lll11l111_tv_,
            l11l1l11l111_tv_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ᤭"):l11l1l11l111_tv_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ᤮"),
            l11l1l11l111_tv_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ᤯"):url,
            l11l1l11l111_tv_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨᤰ"):l1llll1l11l11l111_tv_,
            }
    content,c = l111111l11l111_tv_(url,header=header)
    try:
        data = json.loads(content)
        print data
        l11ll11ll11l111_tv_ = data.get(l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭ᤱ"))
        if l11ll11ll11l111_tv_:
            l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᤲ"):l11ll11ll11l111_tv_}]
        else:
            l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠫࡲࡹࡧࠨᤳ"):l11l1l11l111_tv_ (u"ࠬࡒࡩ࡮࡫ࡷࡸࡪࡪࠠࡢࡥࡦࡩࡸࡹࠠ࠯࠰࠱ࠤࡲࡧࡹࡣࡧࠣࡰࡦࡺࡥࡳࠩᤴ")}]
    except:
        l1lll1ll11l11l111_tv_=[]
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        print l11l1l11l111_tv_ (u"࠭࡜࡯ࠩᤵ"),l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᤶ"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬᤷ")))
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨᤸ")))
        print l1lll1ll11l11l111_tv_
