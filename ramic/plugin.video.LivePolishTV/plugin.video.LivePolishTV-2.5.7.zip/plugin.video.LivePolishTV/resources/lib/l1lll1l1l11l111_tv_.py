# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re
import time
import sys,os
import json
import cookielib
import threading
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡭ࡱࡲ࡯ࡳ࡯ࡪ࠯࡫ࡱࠫဓ")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭န")
l11lll1llll11l111_tv_ = l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡨࡲࡢ࡯࡮ࡥ࠳ࡶࡲࡰࡺࡼ࠲ࡳ࡫ࡴ࠯ࡲ࡯࠳࡮ࡴࡤࡦࡺ࠱ࡴ࡭ࡶ࠿ࡲ࠿ࠪပ")
l1lll1ll1ll11l111_tv_ = l11l1l11l111_tv_ (u"ࠩ࠴࠴ࠬဖ")
__all__=[l11l1l11l111_tv_ (u"ࠪ࡫ࡪࡺࡃࡩࡣࡱࡲࡪࡲࡳࠨဗ"),l11l1l11l111_tv_ (u"ࠫ࡬࡫ࡴࡄࡪࡤࡲࡳ࡫࡬ࡗ࡫ࡧࡩࡴ࠭ဘ")]
fix={
l11l1l11l111_tv_ (u"ࠬࡉࡁࡏࡃॄ࠯ࠬမ"):l11l1l11l111_tv_ (u"࠭ࡃࡢࡰࡤࡰ࠰࠭ယ"),
l11l1l11l111_tv_ (u"ࠧࡄࡣࡱࡥࡱࠦࡓࡱࡱࡵࡸࠥࡎࡄࠨရ"):l11l1l11l111_tv_ (u"ࠨࡅࡤࡲࡦࡲࠫࠡࡕࡳࡳࡷࡺࠧလ"),
l11l1l11l111_tv_ (u"ࠩࡋࡆࡔࡎࡄࠨဝ"):l11l1l11l111_tv_ (u"ࠪࡌࡇࡕࠧသ"),
l11l1l11l111_tv_ (u"ࠫࡒ࡯࡮ࡪ࡯࡬ࡲ࡮ࠦࡈࡅࠩဟ"):l11l1l11l111_tv_ (u"ࠬࡓࡩ࡯࡫ࡰ࡭ࡳ࡯ࠫࠨဠ"),
l11l1l11l111_tv_ (u"࠭ࡐࡰ࡮ࡶࡥࡹ࠸ࡈࡅࠩအ"):l11l1l11l111_tv_ (u"ࠧࡑࡱ࡯ࡷࡦࡺࠠ࠳ࠩဢ"),
l11l1l11l111_tv_ (u"ࠨࡐࡶࡴࡴࡸࡴࡉࡆࠪဣ"):l11l1l11l111_tv_ (u"ࠤࡱࡗࡵࡵࡲࡵࠤဤ"),
l11l1l11l111_tv_ (u"ࠪࡘࡑࡉࠠࡑࡱ࡯ࡷࡰࡧࠠࡉࡆࠪဥ"):l11l1l11l111_tv_ (u"࡙ࠦࡒࡃࠣဦ"),
l11l1l11l111_tv_ (u"ࠬࡊࡩࡴࡥࡲࡺࡪࡸࡹࠡࡅ࡫ࡥࡳࡴࡥ࡭ࠢࡋ࡭ࡸࡺ࡯ࡳ࡫ࡤࠫဧ"):l11l1l11l111_tv_ (u"ࠨࡄࡪࡵࡦࡳࡻ࡫ࡲࡺࠢࡋ࡭ࡸࡺ࡯ࡳ࡫ࡤࠦဨ"),
l11l1l11l111_tv_ (u"ࠧࡕࡘࡓࡌࡉ࠭ဩ"):l11l1l11l111_tv_ (u"ࠨࡖ࡙ࡔࠥࡎࡄࠨဪ"),
l11l1l11l111_tv_ (u"ࠩࡑࡅ࡙ࡍࡅࡐࡅࡋࡅࡓࡋࡌࡍࠢࡋࡈࠬါ"):l11l1l11l111_tv_ (u"ࠥࡒࡦࡺࡩࡰࡰࡤࡰࠥࡍࡥࡰࡩࡵࡥࡵ࡮ࡩࡤࠢࡆ࡬ࡦࡴ࡮ࡦ࡮ࠥာ"),
l11l1l11l111_tv_ (u"࡙ࠫ࡜ࡐ࠳ࠢࡋࡈࠬိ"):l11l1l11l111_tv_ (u"࡚ࠬࡖࡑࠢ࠵ࠫီ"),
l11l1l11l111_tv_ (u"࠭ࡔࡗࡒ࠴ࡌࡉ࠭ု"):l11l1l11l111_tv_ (u"ࠧࡕࡘࡓࠤ࠶࠭ူ"),
l11l1l11l111_tv_ (u"ࠨࡖ࡙ࡔࠥࡎࡄࠨေ"):l11l1l11l111_tv_ (u"ࠩࡗ࡚ࡕࠦࡈࡅࠩဲ"),
l11l1l11l111_tv_ (u"ࠪࡔࡔࡒࡓࡂࡖࠣࡌࡉ࠭ဳ"):l11l1l11l111_tv_ (u"ࠫࡕࡵ࡬ࡴࡣࡷࠫဴ"),
l11l1l11l111_tv_ (u"ࠬࡖࡏࡍࡕࡄࡘ࠷ࡎࡄࠨဵ"):l11l1l11l111_tv_ (u"࠭ࡐࡰ࡮ࡶࡥࡹࠦ࠲ࠨံ"),
l11l1l11l111_tv_ (u"ࠧࡕࡘࡑࠤࡕࡒ့ࠧ"):l11l1l11l111_tv_ (u"ࠨࡖ࡙ࡒࠬး"),
l11l1l11l111_tv_ (u"ࠩࡆࡓࡒࡋࡄ࡚ࠢࡆࡉࡓ࡚ࡒࡂࡎ္ࠪ"):l11l1l11l111_tv_ (u"ࠪࡇࡴࡳࡥࡥࡻࠣࡇࡪࡴࡴࡳࡣ࡯်ࠫ"),
l11l1l11l111_tv_ (u"ࠫࡉ࡯ࡳࡤࡱࡹࡩࡷࡿࠠࡄࡪࡤࡲࡳ࡫࡬ࠡࡒࡏࠫျ"):l11l1l11l111_tv_ (u"ࠬࡊࡩࡴࡥࡲࡺࡪࡸࡹࠡࡅ࡫ࡥࡳࡴࡥ࡭ࠩြ"),
l11l1l11l111_tv_ (u"࠭ࡆࡊࡎࡐࡆࡔ࡞ࠠࡉࡆࠪွ"):l11l1l11l111_tv_ (u"ࠧࡇ࡫࡯ࡱࡧࡵࡸࠨှ"),
l11l1l11l111_tv_ (u"ࠨࡇࡘࡖࡔ࡙ࡐࡐࡔࡗࡌࡉ࠭ဿ"):l11l1l11l111_tv_ (u"ࠩࡈࡹࡷࡵࡳࡱࡱࡵࡸࠬ၀")
}
def l1lll1l1l1l11l111_tv_(l1l1l1ll11l111_tv_):
    l1llll11l1l11l111_tv_ = fix.get(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠪࡸࡻ࡯ࡤࠨ၁")),l11l1l11l111_tv_ (u"ࠫࠬ၂"))
    if l1llll11l1l11l111_tv_:
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ၃")]=l1llll11l1l11l111_tv_
        l1l1l1ll11l111_tv_[l11l1l11l111_tv_ (u"࠭ࡴࡷ࡫ࡧࠫ၄")]=l1llll11l1l11l111_tv_
    return l1l1l1ll11l111_tv_
def l111111l11l111_tv_(url,data=None,header={},cookies=None,l1llll1l1l11l111_tv_=True):
    if l1llll1l1l11l111_tv_:
        l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
        urllib2.install_opener(opener)
    if not header:
        header = {l11l1l11l111_tv_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ၅"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    if cookies:
        req.add_header(l11l1l11l111_tv_ (u"ࠣࡥࡲࡳࡰ࡯ࡥࠣ၆"), cookies)
    try:
        response = urllib2.urlopen(req, timeout=10)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠩࠪ၇")
    return l11ll11ll11l111_tv_
def l1l1lll111l11l111_tv_(l11ll1lllll11l111_tv_, l1ll111l1ll11l111_tv_, index):
    out = l11lll11l1l11l111_tv_(l11ll1lllll11l111_tv_=l11ll1lllll11l111_tv_)
    l1ll111l1ll11l111_tv_[index]=out
def l11l11l1l11l111_tv_(addheader=False):
    out=[]
    l11lll1ll1l11l111_tv_ = range(1)
    l1l111lllll11l111_tv_ = []
    l1ll111l1ll11l111_tv_ = [[] for x in l11lll1ll1l11l111_tv_]
    for i,l11ll1lllll11l111_tv_ in enumerate(l11lll1ll1l11l111_tv_):
        thread = threading.Thread(name=l11l1l11l111_tv_ (u"ࠪࡘ࡭ࡸࡥࡢࡦࠨࡨࠬ၈")%i, target = l1l1lll111l11l111_tv_, args=[l11ll1lllll11l111_tv_+1,l1ll111l1ll11l111_tv_,i])
        l1l111lllll11l111_tv_.append(thread)
        thread.start()
    while any([i.isAlive() for i in l1l111lllll11l111_tv_]): time.sleep(0.1)
    del l1l111lllll11l111_tv_[:]
    for l1l1l1ll11l111_tv_ in l1ll111l1ll11l111_tv_:
        out.extend(l1l1l1ll11l111_tv_)
    if len(out)>0 and addheader:
        t=l11l1l11l111_tv_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡾ࡫࡬࡭ࡱࡺࡡ࡚ࡶࡤࡢࡶࡨࡨ࠿ࠦࠥࡴࠢࠫࡰࡴࡵ࡫࡯࡫࡭࠲࡮ࡴࠩ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ၉") %time.strftime(l11l1l11l111_tv_ (u"ࠧࠫࡤ࠰ࠧࡰ࠳ࠪ࡟࠺ࠡࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥ၊"))
        out.insert(0,{l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ။"):t,l11l1l11l111_tv_ (u"ࠧࡵࡸ࡬ࡨࠬ၌"):l11l1l11l111_tv_ (u"ࠨࠩ၍"),l11l1l11l111_tv_ (u"ࠩ࡬ࡱ࡬࠭၎"):l11l1l11l111_tv_ (u"ࠪࠫ၏"),l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨၐ"):l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡿ࡯ࡺ࠰ࡷࡺ࠴࠭ၑ"),l11l1l11l111_tv_ (u"࠭ࡧࡳࡱࡸࡴࠬၒ"):l11l1l11l111_tv_ (u"ࠧࠨၓ"),l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࡪࡶࡧࠨၔ"):l11l1l11l111_tv_ (u"ࠩࠪၕ")})
    return out
def l11lll11l1l11l111_tv_(l11ll1lllll11l111_tv_=1):
    url = l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡱࡵ࡯࡬ࡰ࡬࡮࠳࡯࡮࠰ࡶࡨࡰࡪࡽࡩࡻ࡬ࡤ࠱ࡴࡴ࡬ࡪࡰࡨ࠳ࡸࡺࡲࡰࡰࡤ࡟ࠪࡪ࡝ࠬࠩၖ")%(l11ll1lllll11l111_tv_)
    content = l111111l11l111_tv_(l11lll1llll11l111_tv_+url)
    out=[]
    l11lll1l11l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡁ࡮࠳ࠡࡥ࡯ࡥࡸࡹ࠮ࠫࡁ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧၗ")).findall(content)
    l11lll111ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪၘ")).findall(content)
    for l11lll11lll11l111_tv_,href in zip(l11lll111ll11l111_tv_,l11lll1l11l11l111_tv_):
        group=l11l1l11l111_tv_ (u"࠭ࠧၙ")
        t=href[-1].split(l11l1l11l111_tv_ (u"ࠧ࡜ࠩၚ"))[0].strip()
        i=urllib.unquote(l11lll11lll11l111_tv_[-1].replace(l11lll1llll11l111_tv_,l11l1l11l111_tv_ (u"ࠨࠩၛ")))
        h=urllib.unquote(l11lll11lll11l111_tv_[0].replace(l11lll1llll11l111_tv_,l11l1l11l111_tv_ (u"ࠩࠪၜ")))
        out.append(l1lll1l1l1l11l111_tv_({l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩၝ"):t,l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩၞ"):t,l11l1l11l111_tv_ (u"ࠬ࡯࡭ࡨࠩၟ"):i,l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪၠ"):h,l11l1l11l111_tv_ (u"ࠧࡨࡴࡲࡹࡵ࠭ၡ"):group,l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࡪࡶࡧࠨၢ"):l11l1l11l111_tv_ (u"ࠩࠪၣ")}))
    return out
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡱࡵ࡯࡬ࡰ࡬࡮࠳࡯࡮࠰ࡶࡨࡰࡪࡽࡩࡻ࡬ࡤ࠱ࡴࡴ࡬ࡪࡰࡨ࠳ࠬၤ"))
    if not content:
        content = l111111l11l111_tv_(l11lll1llll11l111_tv_+l11l1l11l111_tv_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡲ࡯ࡰ࡭ࡱ࡭࡯࠴ࡩ࡯࠱ࡷࡩࡱ࡫ࡷࡪࡼ࡭ࡥ࠲ࡵ࡮࡭࡫ࡱࡩ࠴࠭ၥ"))
    out=[]
    l11lll1l11l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠬࡂࡨ࠴ࠢࡦࡰࡦࡹࡳ࠯ࠬࡂࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨၦ")).findall(content)
    l11lll111ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫၧ")).findall(content)
    for l11lll11lll11l111_tv_,href in zip(l11lll111ll11l111_tv_,l11lll1l11l11l111_tv_):
        group=l11l1l11l111_tv_ (u"ࠧࠨၨ")
        t=href[-1].split(l11l1l11l111_tv_ (u"ࠨ࡝ࠪၩ"))[0].strip()
        i=urllib.unquote(l11lll11lll11l111_tv_[-1].replace(l11lll1llll11l111_tv_,l11l1l11l111_tv_ (u"ࠩࠪၪ")))
        h=urllib.unquote(l11lll11lll11l111_tv_[0].replace(l11lll1llll11l111_tv_,l11l1l11l111_tv_ (u"ࠪࠫၫ")))
        out.append(l1lll1l1l1l11l111_tv_({l11l1l11l111_tv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪၬ"):t,l11l1l11l111_tv_ (u"ࠬࡺࡶࡪࡦࠪၭ"):t,l11l1l11l111_tv_ (u"࠭ࡩ࡮ࡩࠪၮ"):i,l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫၯ"):h,l11l1l11l111_tv_ (u"ࠨࡩࡵࡳࡺࡶࠧၰ"):group,l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩၱ"):l11l1l11l111_tv_ (u"ࠪࠫၲ")}))
    if len(out)>0 and addheader:
        t=l11l1l11l111_tv_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡾ࡫࡬࡭ࡱࡺࡡ࡚ࡶࡤࡢࡶࡨࡨ࠿ࠦࠥࡴࠢࠫࡰࡴࡵ࡫࡯࡫࡭࠲࡮ࡴࠩ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩၳ") %time.strftime(l11l1l11l111_tv_ (u"ࠧࠫࡤ࠰ࠧࡰ࠳ࠪ࡟࠺ࠡࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠥၴ"))
        out.insert(0,{l11l1l11l111_tv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬၵ"):t,l11l1l11l111_tv_ (u"ࠧࡵࡸ࡬ࡨࠬၶ"):l11l1l11l111_tv_ (u"ࠨࠩၷ"),l11l1l11l111_tv_ (u"ࠩ࡬ࡱ࡬࠭ၸ"):l11l1l11l111_tv_ (u"ࠪࠫၹ"),l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨၺ"):l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡲ࡯ࡰ࡭ࡱ࡭࡯࠴ࡩ࡯࠱ࠪၻ"),l11l1l11l111_tv_ (u"࠭ࡧࡳࡱࡸࡴࠬၼ"):l11l1l11l111_tv_ (u"ࠧࠨၽ"),l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࡪࡶࡧࠨၾ"):l11l1l11l111_tv_ (u"ࠩࠪၿ")})
    return out
def l111l1lll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠪ࠳ࡹ࡫࡬ࡦࡹ࡬ࡾ࡯ࡧ࠭ࡵࡸࡳ࠵࡭ࡪ࠭࡭ࡧ࡮ࡸࡴࡸ࠭࠲࠻࠵ࠫႀ")):
    l1lll1ll11l11l111_tv_=[]
    id = url.split(l11l1l11l111_tv_ (u"ࠫ࠲࠭ႁ"))[-1]
    l11lll1111l11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡬ࡰࡱ࡮ࡲ࡮ࡰ࠮ࡪࡰ࠲ࡸࡻ࠵ࡤࡢࡶࡤ࠳ࠪࡹࠧႂ")%id
    data = l111111l11l111_tv_(l11lll1111l11l111_tv_)
    if not data:
        data = l111111l11l111_tv_(l11lll1llll11l111_tv_+l11lll1111l11l111_tv_)
    if data:
        src = re.compile(l11l1l11l111_tv_ (u"࠭ࠢ࡜ࡗࡿࡹࡢࡸ࡬ࠣ࠼ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨࠧႃ")).findall(data)
        if src:
            l1ll11lll1l11l111_tv_ = src[0].replace(l11l1l11l111_tv_ (u"ࠧ࡝࡞ࠪႄ"),l11l1l11l111_tv_ (u"ࠨࠩႅ"))+l11l1l11l111_tv_ (u"ࠤࡿࡶࡪ࡬ࡥࡳࡧࡵࡁࠪࡹࠢႆ")%(url)
            l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧႇ"):l1ll11lll1l11l111_tv_}]
    else:
        l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠫࡲࡹࡧࠨႈ"):l11l1l11l111_tv_ (u"ࠬ࡝ࡥࠡࡣࡵࡩࠥ࡮ࡡࡷ࡫ࡱ࡫ࠥࡧࠠࡱࡴࡲࡦࡱ࡫࡭ࠡࡹ࡬ࡸ࡭ࠦࡌࡰࡱ࡮ࡲ࡮ࡰ࠮ࡪࡰࠪႉ")}]
    return l1lll1ll11l11l111_tv_
def test():
    out=l11l11l1l11l111_tv_(addheader=False)
    o = out[0]
    for o in out:
        url= o.get(l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪႊ"))
        title= o.get(l11l1l11l111_tv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ႋ"))
        print title
        o[l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬႌ")]=l111l1lll11l111_tv_(o.get(l11l1l11l111_tv_ (u"ࠩࡸࡶࡱႍ࠭")))
        print o[l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧႎ")]
    with open(l11l1l11l111_tv_ (u"ࠫࡱࡵ࡯࡬ࡰ࡬࡮࠳ࡰࡳࡰࡰࠪႏ"), l11l1l11l111_tv_ (u"ࠬࡽࠧ႐")) as l11lll1l1ll11l111_tv_:
        json.dump(out, l11lll1l1ll11l111_tv_, indent=2, sort_keys=True)
