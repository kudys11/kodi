# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re
from urlparse import urlparse
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡵࡸ࠰ࡳࡳࡲࡩ࡯ࡧ࠱ࡪࡲ࠵ࠧᴟ")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠶࠲࠱࠴࠳࠸࠶࠷࠳࠱࠵࠵࠸ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧᴠ")
__all__=[l11l1l11l111_tv_ (u"ࠩࡪࡩࡹࡉࡨࡢࡰࡱࡩࡱࡹࠧᴡ"),l11l1l11l111_tv_ (u"ࠪ࡫ࡪࡺࡃࡩࡣࡱࡲࡪࡲࡖࡪࡦࡨࡳࠬᴢ")]
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᴣ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠬ࠭ᴤ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    ids = [(a.start(), a.end()) for a in re.finditer(l11l1l11l111_tv_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦ࡮ࡺࡥ࡮ࠤࡁࠫᴥ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l1l1lll1lll11l111_tv_ = content[ ids[i][1]:ids[i+1][0] ]
        title = re.compile(l11l1l11l111_tv_ (u"ࠧ࠽ࡤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡦࡃ࠭ᴦ")).findall(l1l1lll1lll11l111_tv_)
        l1ll1ll11l1l11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࠥࡃࠢࡱࡴࡲ࡫ࡹࡼ࡬ࡪࡵࡷࡥࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᴧ"),re.DOTALL).findall(l1l1lll1lll11l111_tv_)
        l1ll1ll11l1l11l111_tv_ = re.sub(l11l1l11l111_tv_ (u"ࡴࠪࡀ࠳࠰࠿࠿ࠩᴨ"),l11l1l11l111_tv_ (u"ࠪࠫᴩ"),l1ll1ll11l1l11l111_tv_[0]) if l1ll1ll11l1l11l111_tv_ else l11l1l11l111_tv_ (u"ࠫࠬᴪ")
        href = re.compile(l11l1l11l111_tv_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠨᴫ")).findall(l1l1lll1lll11l111_tv_)
        l1l11l1lllll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࠭࠼ࡣࡀ࡟ࡷ࠯࠮࡜ࡥ࠭ࠬࡠࡸ࠰࠼࠰ࡤࡁࠫᴬ")).findall(l1l1lll1lll11l111_tv_)
        if href and title:
            group = href[0].split(l11l1l11l111_tv_ (u"ࠧࡀࠩᴭ"))[-1] if l11l1l11l111_tv_ (u"ࠨࡁࠪᴮ") in href[0] else l11l1l11l111_tv_ (u"ࠩࠪᴯ")
            l1l11l1lllll11l111_tv_ = l1l11l1lllll11l111_tv_[0] if l1l11l1lllll11l111_tv_ else l11l1l11l111_tv_ (u"ࠪࡃࠬᴰ")
            t = title[0].strip()
            code = l11l1l11l111_tv_ (u"ࠫࡠࡒࡩ࡯࡭ࣶࡻ࠿ࠫࡳ࡞ࠢࠨࡷࠬᴱ")%(l1l11l1lllll11l111_tv_,group)
            out.append({l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫᴲ"):t,l11l1l11l111_tv_ (u"࠭ࡴࡷ࡫ࡧࠫᴳ"):t,l11l1l11l111_tv_ (u"ࠧࡪ࡯ࡪࠫᴴ"):l11l1l11l111_tv_ (u"ࠨࠩᴵ"),l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭ᴶ"):href[0],l11l1l11l111_tv_ (u"ࠪ࡫ࡷࡵࡵࡱࠩᴷ"):group,l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫᴸ"):l11l1l11l111_tv_ (u"ࠬ࠭ᴹ"),l11l1l11l111_tv_ (u"࠭ࡰ࡭ࡱࡷࠫᴺ"):l1ll1ll11l1l11l111_tv_,l11l1l11l111_tv_ (u"ࠧࡤࡱࡧࡩࠬᴻ"):code})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡻࡨࡰࡱࡵࡷ࡞ࡗࡳࡨࡦࡺࡥࡥ࠼ࠣࠩࡸࠦࠨࡱࡵࡤ࠱ࡹࡼࠩ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᴼ") %time.strftime(l11l1l11l111_tv_ (u"ࠤࠨࡨ࠴ࠫ࡭࠰ࠧ࡜࠾ࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠢᴽ"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩᴾ"):t,l11l1l11l111_tv_ (u"ࠫࡹࡼࡩࡥࠩᴿ"):l11l1l11l111_tv_ (u"ࠬ࠭ᵀ"),l11l1l11l111_tv_ (u"࠭ࡩ࡮ࡩࠪᵁ"):l11l1l11l111_tv_ (u"ࠧࠨᵂ"),l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬᵃ"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠩࡪࡶࡴࡻࡰࠨᵄ"):l11l1l11l111_tv_ (u"ࠪࠫᵅ"),l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫᵆ"):l11l1l11l111_tv_ (u"ࠬ࠭ᵇ")})
    return out
l11ll11l11l11l111_tv_=[l11l1l11l111_tv_ (u"࠭ࡳࡵࡣࡷ࡭ࡨ࠴ࡵ࠮ࡲࡵࡳ࠳࡬ࡲࠨᵈ"),l11l1l11l111_tv_ (u"ࠧࡪ࡭࡯ࡹࡧ࠴࡮ࡦࡶࠪᵉ"),l11l1l11l111_tv_ (u"ࠨ࡮ࡲࡳࡰࡴࡩ࡫࠰࡬ࡲࠬᵊ"),l11l1l11l111_tv_ (u"ࠩࡺ࡭ࡿࡰࡡ࠯ࡶࡹࠫᵋ"),l11l1l11l111_tv_ (u"ࠪࡻࡼࡽ࠮ࡵࡸࡳ࠲ࡵࡲࠧᵌ"),l11l1l11l111_tv_ (u"ࠫࡹ࡫࡬ࡦ࠯ࡺ࡭ࡿࡰࡡ࠯ࡥࡲࡱࠬᵍ")]
def l1llll1ll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡺࡶ࠮ࡱࡱࡰ࡮ࡴࡥ࠯ࡨࡰ࠳ࡹ࡫࡬ࡦࡹ࡬ࡾ࡯ࡧ࠮ࡱࡪࡳࡃࡹࡼ࠴ࡀࡲࡲࡨࡸࡺࡡࡸࡱࡺࡩࠬᵎ")):
    out=[]
    content = l111111l11l111_tv_(url)
    l11ll1ll1ll11l111_tv_ =re.compile(l11l1l11l111_tv_ (u"࠭࠼ࡢࠢࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺࡡ࡭࡫ࡱ࡯ࡦࡲࡩ࡯࡭ࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᵏ")).findall(content)
    for l11ll11ll11l111_tv_ in l11ll1ll1ll11l111_tv_:
        title = urlparse(l11ll11ll11l111_tv_).netloc
        if title in l11ll11l11l11l111_tv_:
            title = l11l1l11l111_tv_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡨࡴࡨࡩࡳࡣࠥࡴ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᵐ")%title
        else:
            title = l11l1l11l111_tv_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡴࡨࡨࡢࠫࡳ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᵑ")%title
        out.append({l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨᵒ"):title,l11l1l11l111_tv_ (u"ࠪࡸࡻ࡯ࡤࠨᵓ"):title,l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨᵔ"):l11ll11ll11l111_tv_})
    return out
def l111l1lll11l111_tv_(item):
    host = item.get(l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫᵕ"))
    url = item.get(l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪᵖ"))
    l1lll1ll11l11l111_tv_=l11l1l11l111_tv_ (u"ࠧࠨᵗ")
    if l11l1l11l111_tv_ (u"ࠨࡵࡷࡥࡹ࡯ࡣ࠯ࡷ࠰ࡴࡷࡵ࠮ࡧࡴࠪᵘ") in host:
        data=l11l1l11l111_tv_ (u"ࠩࡶࡶࡨࡃࠢࠦࡵࠥࠫᵙ")%url
        l1lll1ll11l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
    elif l11l1l11l111_tv_ (u"ࠪ࡭ࡰࡲࡵࡣ࠰ࡱࡩࡹ࠭ᵚ") in host:
        from l1l11llll11l111_tv_ import _1l1l11l11l11l111_tv_
        l1lll1ll11l11l111_tv_ = _1l1l11l11l11l111_tv_(url)
    elif l11l1l11l111_tv_ (u"ࠫࡱࡵ࡯࡬ࡰ࡬࡮࠳࡯࡮ࠨᵛ") in host:
        from l1lll1l1l11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩᵜ"),l11l1l11l111_tv_ (u"࠭ࠧᵝ"))
    elif l11l1l11l111_tv_ (u"ࠧࡸ࡫ࡽ࡮ࡦ࠴ࡴࡷࠩᵞ") in host:
        from l1l1lllll11l111_tv_ import l111l1lll11l111_tv_
        l1lll1ll11l11l111_tv_ = l111l1lll11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬᵟ"),l11l1l11l111_tv_ (u"ࠩࠪᵠ"))
    elif l11l1l11l111_tv_ (u"ࠪࡸࡪࡲࡥ࠮ࡹ࡬ࡾ࡯ࡧࠧᵡ") in host:
        data = l111111l11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(url,data)
    elif l11l1l11l111_tv_ (u"ࠫࡼࡽࡷ࠯ࡶࡹࡴ࠳ࡶ࡬ࠨᵢ") in host:
        from l11ll1lll11l111_tv_ import _1l1l11l11l11l111_tv_
        l1lll1ll11l11l111_tv_ = _1l1l11l11l11l111_tv_(url)
        l1lll1ll11l11l111_tv_ = l1lll1ll11l11l111_tv_[0].get(l11l1l11l111_tv_ (u"ࠬࡻࡲ࡭ࠩᵣ"),l11l1l11l111_tv_ (u"࠭ࠧᵤ"))
    return l1lll1ll11l11l111_tv_
