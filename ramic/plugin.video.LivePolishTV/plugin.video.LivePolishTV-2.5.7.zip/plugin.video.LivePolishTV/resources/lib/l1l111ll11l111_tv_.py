# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2,urllib
import re
import cookielib
import urlparse
import l1ll11ll1ll11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸࡪࡲࡥ࡮࡫࡮࡭࠳ࡾࡹࡻ࠱᤹ࠪ")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡐ࡙࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠹࠵࠴࠰࠯࠴࠹࠺࠶࠴࠱࠱࠴ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪ᤺")
__all__=[l11l1l11l111_tv_ (u"ࠬ࡭ࡥࡵࡅ࡫ࡥࡳࡴࡥ࡭ࡵ᤻ࠪ"),l11l1l11l111_tv_ (u"࠭ࡧࡦࡶࡆ࡬ࡦࡴ࡮ࡦ࡮࡙࡭ࡩ࡫࡯ࠨ᤼")]
def l111111l11l111_tv_(url,data=None,header={}):
    l1llll1ll1l11l111_tv_ = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1llll1ll1l11l111_tv_))
    urllib2.install_opener(opener)
    if not header:
        header = {l11l1l11l111_tv_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ᤽"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except: l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠨࠩ᤾")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l11llll11ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠫࡀࠫ࠿࠳ࡦࡄࠧ᤿")).findall(content)
    for href,t in l11llll11ll11l111_tv_:
        if href.startswith(l11l1l11l111_tv_ (u"ࠪࡘ࡛࠭᥀")):
            out.append({l11l1l11l111_tv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ᥁"):t,l11l1l11l111_tv_ (u"ࠬࡺࡶࡪࡦࠪ᥂"):t,l11l1l11l111_tv_ (u"࠭ࡩ࡮ࡩࠪ᥃"):l11l1l11l111_tv_ (u"ࠧࠨ᥄"),l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬ᥅"):urlparse.urljoin(l1llll111ll11l111_tv_,href),l11l1l11l111_tv_ (u"ࠩࡪࡶࡴࡻࡰࠨ᥆"):l11l1l11l111_tv_ (u"ࠪࠫ᥇"),l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࡦࡲࡪࠫ᥈"):l11l1l11l111_tv_ (u"ࠬ࠭᥉"),l11l1l11l111_tv_ (u"࠭ࡰ࡭ࡱࡷࠫ᥊"):l11l1l11l111_tv_ (u"ࠧࠨ᥋"),l11l1l11l111_tv_ (u"ࠨࡥࡲࡨࡪ࠭᥌"):l11l1l11l111_tv_ (u"ࠩࠪ᥍")})
    if addheader and len(out):
        t=l11l1l11l111_tv_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡽࡪࡲ࡬ࡰࡹࡠ࡙ࡵࡪࡡࡵࡧࡧ࠾ࠥࠫࡳࠡࠪࡷࡩࡱ࡫ࡷࡪࡼ࡭ࡥ࠲ࡨ࡬ࡢࡥ࡮࠭ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭᥎") %time.strftime(l11l1l11l111_tv_ (u"ࠦࠪࡪ࠯ࠦ࡯࠲ࠩ࡞ࡀࠠࠦࡊ࠽ࠩࡒࡀࠥࡔࠤ᥏"))
        out.insert(0,{l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫᥐ"):t,l11l1l11l111_tv_ (u"࠭ࡴࡷ࡫ࡧࠫᥑ"):l11l1l11l111_tv_ (u"ࠧࠨᥒ"),l11l1l11l111_tv_ (u"ࠨ࡫ࡰ࡫ࠬᥓ"):l11l1l11l111_tv_ (u"ࠩࠪᥔ"),l11l1l11l111_tv_ (u"ࠪࡹࡷࡲࠧᥕ"):l1llll111ll11l111_tv_,l11l1l11l111_tv_ (u"ࠫ࡬ࡸ࡯ࡶࡲࠪᥖ"):l11l1l11l111_tv_ (u"ࠬ࠭ᥗ"),l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࡨࡴ࡬࠭ᥘ"):l11l1l11l111_tv_ (u"ࠧࠨᥙ")})
    return out
def l111l1lll11l111_tv_(url=l11l1l11l111_tv_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡶࡨࡰࡪࡽࡩࡻ࡬ࡤ࠱ࡧࡲࡡࡤ࡭࠱ࡧࡴࡳ࠯ࡵࡸࡱ࠻ࠬᥚ")):
    l1lll1ll11l11l111_tv_=[]
    content = l111111l11l111_tv_(url)
    l1ll1l111ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠫ࠲࠯ࡅࠩ࠽࠱࡬ࡪࡷࡧ࡭ࡦࠩᥛ"),re.DOTALL).findall(content)
    src = [url] if l11l1l11l111_tv_ (u"ࠪ࡯ࡦࡴࡡ࡭ࠩᥜ") in url else []
    for m in l1ll1l111ll11l111_tv_:
        l11ll11ll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᥝ")).findall(m)
        if l11ll11ll11l111_tv_:
            if l11ll11ll11l111_tv_[0].startswith(l11l1l11l111_tv_ (u"ࠬ࡮ࡴࡵࡲࠪᥞ")):
                pass
            else:
                src.append(urlparse.urljoin(l1llll111ll11l111_tv_,l11ll11ll11l111_tv_[0]))
    if src:
        src = src[0]
        print src
        data = l111111l11l111_tv_(src)
        l1ll1l11lll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"࡛࠭࡝ࠩࠥࡡ࠭࡮ࡴࡵࡲ࠱࠮ࡡ࠴࡭࠴ࡷ࠻ࡃ࠮ࡡ࡜ࠨࠤࡠࠫᥟ")).findall(data)
        if l1ll1l11lll11l111_tv_:
            l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫᥠ"):l1ll1l11lll11l111_tv_[0]}]
        else:
            l1ll11lll1l11l111_tv_ = l1ll11ll1ll11l111_tv_.decode(src,data)
            if l1ll11lll1l11l111_tv_:
                l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠨࡷࡵࡰࠬᥡ"):l1ll11lll1l11l111_tv_}]
    if not l1lll1ll11l11l111_tv_:
        l1lll1ll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠩࡰࡷ࡬࠭ᥢ"):l11l1l11l111_tv_ (u"ࠪࡔࡷࡵࡢ࡭ࡧࡰࠤࡿ࡫ࠠॻࡴࣶࡨे࡫࡭ࠨᥣ")}]
    return l1lll1ll11l11l111_tv_
def test():
    out = l11l11l1l11l111_tv_(False)
    l1ll11lllll11l111_tv_=[]
    l1l1l1ll11l111_tv_ =out[0]
    for l1l1l1ll11l111_tv_ in out:
        print l11l1l11l111_tv_ (u"ࠫࡡࡴࠧᥤ"),l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫᥥ"))
        l1lll1ll11l11l111_tv_=l111l1lll11l111_tv_(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"࠭ࡵࡳ࡮ࠪᥦ")))
        print l1lll1ll11l11l111_tv_
        if not l1lll1ll11l11l111_tv_:
            l1ll11lllll11l111_tv_.append(l1l1l1ll11l111_tv_.get(l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫᥧ")))
        print l1lll1ll11l11l111_tv_
