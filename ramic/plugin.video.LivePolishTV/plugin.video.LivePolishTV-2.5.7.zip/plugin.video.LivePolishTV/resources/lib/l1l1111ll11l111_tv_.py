# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import urllib2
import re,json
from ramic import go as l1l1lllllll11l111_tv_
l1llll111ll11l111_tv_=l11l1l11l111_tv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡦ࡬ࡰ࠲ࡵࡲ࠯ࡔࡧ࡭ࡱ࠽࠴࡮ࡴࡨ࠲ࡸࡷࡧ࡮ࡴ࡯࡬ࡷ࡯࡫࠮ࡹࡵࡳࠫᗟ")
l1lll1l1lll11l111_tv_=l11l1l11l111_tv_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ᗠ")
def l111111l11l111_tv_(url,data=None,header={}):
    if not header:
        header = {l11l1l11l111_tv_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᗡ"):l1lll1l1lll11l111_tv_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req, timeout=15)
        l11ll11ll11l111_tv_ = response.read()
        response.close()
    except:
        l11ll11ll11l111_tv_=l11l1l11l111_tv_ (u"ࠩࠪᗢ")
    return l11ll11ll11l111_tv_
def l11l11l1l11l111_tv_(addheader=False):
    content = l111111l11l111_tv_(l1llll111ll11l111_tv_)
    out=[]
    l1lll1lllll11l111_tv_ = re.compile(l11l1l11l111_tv_ (u"ࠪࡀࡸࡶࡡ࡯ࠢࡦࡰࡦࡹࡳ࠾ࠤ࡭ࡷࡴࡴࠠࡩ࡫ࡧࡨࡪࡴࠢ࠿ࠪࡾ࠲࠯ࡅࡽࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩᗣ")).findall(content)
    l1l1llll11l11l111_tv_=[]
    for data in l1lll1lllll11l111_tv_:
        data = json.loads(data)
        code = l11l1l11l111_tv_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡱ࡯ࡧࡩࡶࡪࡶࡪ࡫࡮࡞ࡎ࡬ࡺࡪࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᗤ") if l11l1l11l111_tv_ (u"ࠬ࡜ࡉࡅࡇࡒࡣࡕࡒࡁ࡚ࡋࡑࡋࠬᗥ") in data.get(l11l1l11l111_tv_ (u"࠭ࡳࡵࡣࡷࡹࡸ࠭ᗦ"),l11l1l11l111_tv_ (u"ࠧࠨᗧ")) else l11l1l11l111_tv_ (u"ࠨࠩᗨ")
        href = data.get(l11l1l11l111_tv_ (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩᗩ"),{}).get(l11l1l11l111_tv_ (u"ࠪࡪ࡮ࡲࡥࠨᗪ"),l11l1l11l111_tv_ (u"ࠫࠬᗫ"))
        title = data.get(l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫᗬ"))
        l1ll1ll11l1l11l111_tv_ = l11l1l11l111_tv_ (u"࠭ࠥࡴ࡞ࡱࠩࡸࡢ࡮ࠦࡵ࡟ࡲࠪࡹࠧᗭ")%(data.get(l11l1l11l111_tv_ (u"ࠧࡥࡧࡶࡧࠬᗮ"),l11l1l11l111_tv_ (u"ࠨࠩᗯ")),data.get(l11l1l11l111_tv_ (u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫᗰ"),l11l1l11l111_tv_ (u"ࠪࠫᗱ")),data.get(l11l1l11l111_tv_ (u"ࠫࡵࡧࡲࡢ࡯ࡶࠫᗲ"),{}).get(l11l1l11l111_tv_ (u"ࠬࡹࡴࡢࡴࡷࠫᗳ"),l11l1l11l111_tv_ (u"࠭ࠧᗴ")),data.get(l11l1l11l111_tv_ (u"ࠧࡱࡣࡵࡥࡲࡹࠧᗵ"),{}).get(l11l1l11l111_tv_ (u"ࠨࡵࡷࡳࡵ࠭ᗶ"),l11l1l11l111_tv_ (u"ࠩࠪᗷ")))
        title = l1l1lllllll11l111_tv_[l11l1l11l111_tv_ (u"ࠪࡨࡪࡩ࡯ࡥࡧࡋࡘࡒࡒࡥ࡯ࡶࡵ࡭ࡪࡹࠧᗸ")](title)
        l1ll1ll11l1l11l111_tv_ = l1l1lllllll11l111_tv_[l11l1l11l111_tv_ (u"ࠫࡩ࡫ࡣࡰࡦࡨࡌ࡙ࡓࡌࡦࡰࡷࡶ࡮࡫ࡳࠨᗹ")](l1ll1ll11l1l11l111_tv_)
        l1l1l1ll11l111_tv_ = {l11l1l11l111_tv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫᗺ"):title.strip(),l11l1l11l111_tv_ (u"࠭ࡰ࡭ࡱࡷࠫᗻ"):l1ll1ll11l1l11l111_tv_,l11l1l11l111_tv_ (u"ࠧࡶࡴ࡯ࠫᗼ"):href,l11l1l11l111_tv_ (u"ࠨࡥࡲࡨࡪ࠭ᗽ"):code}
        if code:l1l1llll11l11l111_tv_.append(l1l1l1ll11l111_tv_)
    if not l1l1llll11l11l111_tv_:
        l1l1llll11l11l111_tv_=[{l11l1l11l111_tv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨᗾ"):l11l1l11l111_tv_ (u"ࠪࡅࡰࡺࡵࡢ࡮ࡱ࡭ࡪࠦࡢࡳࡣ࡮ࠤࡹࡸࡡ࡯ࡵࡰ࡭ࡸࡰࡩࠡࡰࡤࠤঁࡿࡷࡰࠩᗿ"),l11l1l11l111_tv_ (u"ࠫࡺࡸ࡬ࠨᘀ"):l11l1l11l111_tv_ (u"ࠬ࠭ᘁ")}]
    return l1l1llll11l11l111_tv_
def l111l1lll11l111_tv_(url):
    url = url.replace(l11l1l11l111_tv_ (u"࠭࠯࡯ࡸࡵ࠳ࠬᘂ"), l11l1l11l111_tv_ (u"ࠧ࠰࡮࡬ࡺࡪ࡮࡬ࡴ࠱ࠪᘃ")) + l11l1l11l111_tv_ (u"ࠣ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷ࠲ࡲ࠹ࡵ࠹ࠤᘄ")
    return [{l11l1l11l111_tv_ (u"ࠩࡸࡶࡱ࠭ᘅ"):url,l11l1l11l111_tv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩᘆ"):l11l1l11l111_tv_ (u"ࠫࡸࡺࡲࡦࡣࡰࠫᘇ")}]
