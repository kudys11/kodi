# -*- coding: utf-8 -*-
import sys
l1lllll11l111_tv_ = sys.version_info [0] == 2
l1l1l11l111_tv_ = 2048
l1llll11l111_tv_ = 7
def l11l1l11l111_tv_ (lll11l111_tv_):
	global l1ll1ll11l111_tv_
	l1ll11l11l111_tv_ = ord (lll11l111_tv_ [-1])
	l1l11l11l111_tv_ = lll11l111_tv_ [:-1]
	l1ll11l111_tv_ = l1ll11l11l111_tv_ % len (l1l11l11l111_tv_)
	l11l11l111_tv_ = l1l11l11l111_tv_ [:l1ll11l111_tv_] + l1l11l11l111_tv_ [l1ll11l111_tv_:]
	if l1lllll11l111_tv_:
		l111ll11l111_tv_ = unicode () .join ([unichr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	else:
		l111ll11l111_tv_ = str () .join ([chr (ord (char) - l1l1l11l111_tv_ - (l1l1ll11l111_tv_ + l1ll11l11l111_tv_) % l1llll11l111_tv_) for l1l1ll11l111_tv_, char in enumerate (l11l11l111_tv_)])
	return eval (l111ll11l111_tv_)
import xbmc,xbmcgui
import time,re,os,sys,threading
try: from shutil import rmtree
except: rmtree = False
import ramic
def l1l11l111_tv_(l1l1l1l11l111_tv_,l11ll11l111_tv_=[l11l1l11l111_tv_ (u"ࠫࠬ૟")]):
    debug=1
def l11lll11l111_tv_(name=l11l1l11l111_tv_ (u"ࠬ࠭ૠ")):
    debug=1
def l1lllll111l11l111_tv_(name=l11l1l11l111_tv_ (u"࠭ࠧ૨")):
    debug=1
def l111l11l111_tv_(top):
    debug=1
def l111ll1l11l111_tv_():
    debug=1
def run(argument):
    try:
        debug=1
    except: pass
def l1lllll1lll11l111_tv_(fname):
    debug=1
def l1lllll1l1l11l111_tv_():
    debug=1

