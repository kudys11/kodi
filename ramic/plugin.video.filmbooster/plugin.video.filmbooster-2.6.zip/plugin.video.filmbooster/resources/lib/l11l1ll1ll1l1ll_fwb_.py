# -*- coding: utf-8 -*-
import sys
l1ll11ll1l1ll_fwb_ = sys.version_info [0] == 2
l1111ll1l1ll_fwb_ = 2048
l1l1l1ll1l1ll_fwb_ = 7
def l1l111ll1l1ll_fwb_ (keyedStringLiteral):
	global l11ll1ll1l1ll_fwb_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll1l1ll_fwb_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,random,json
import cookielib
l11lll1111ll1l1ll_fwb_=10
l1llll1ll11ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠰࠯࠲࠱࠶࠻࠼࠱࠯࠳࠳࠶࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬᙫ")
def l11ll11l11ll1l1ll_fwb_(url,data=None,header={},l1llll11l111ll1l1ll_fwb_=True):
    l11111l111ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࠨᙬ")
    l11l11l1l1ll1l1ll_fwb_=[]
    if l1llll11l111ll1l1ll_fwb_:
        l11l11l1l1ll1l1ll_fwb_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l11l11l1l1ll1l1ll_fwb_))
        urllib2.install_opener(opener)
    if not header:
        header = {l1l111ll1l1ll_fwb_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ᙭"):l1llll1ll11ll1l1ll_fwb_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l11lll1111ll1l1ll_fwb_)
        l111111l1ll1l1ll_fwb_ =  response.read()
        response.close()
        l11111l111ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠩࠪ᙮").join([l1l111ll1l1ll_fwb_ (u"ࠪࠩࡸࡃࠥࡴ࠽ࠪᙯ")%(c.name, c.value) for c in l11l11l1l1ll1l1ll_fwb_])
    except urllib2.HTTPError as e:
        l111111l1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠫࠬᙰ")
    return l111111l1ll1l1ll_fwb_,l11111l111ll1l1ll_fwb_
url = l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵ࠮ࡤࡱࡰ࠳ࡪࡳࡢࡦࡦ࠲࡚࠷࡜ࡳࡗࡍ࡛ࡔࠬᙱ")
url = l1l111ll1l1ll_fwb_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡷࡧࡰࡪࡦࡹ࡭ࡩ࡫࡯࠯ࡥࡲࡱ࠴࡫࡭ࡣࡧࡧ࠳ࡊࡉࡣࡺࡃࡕ࡫ࡒ࠭ᙲ")
def l11l1ll1l1ll1l1ll_fwb_(url):
    url = url.replace(l1l111ll1l1ll_fwb_ (u"ࠧࡩࡶࡷࡴ࠿࠭ᙳ"),l1l111ll1l1ll_fwb_ (u"ࠨࡪࡷࡸࡵࡹ࠺ࠨᙴ")).replace(l1l111ll1l1ll_fwb_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠱ࠪᙵ"),l1l111ll1l1ll_fwb_ (u"ࠪ࠳ࡄࡼ࠽ࠨᙶ"))
    content,c = l11ll11l11ll1l1ll_fwb_(url)
    match = re.findall(l1l111ll1l1ll_fwb_ (u"࡛ࠫࠬ࠭ࠣࠩࡠࡃࡸࡵࡵࡳࡥࡨࡷࡠ࠭ࠢ࡞ࡁ࡟ࡷ࠯ࡀ࡜ࡴࠬࠫࡠࡠ࠴ࠪࡀ࡞ࡠ࠭ࠬ࠭ࠧᙷ"), content)
    l1llll11l1l1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠬ࠭ᙸ")
    if not match:
        data = {}
        data[l1l111ll1l1ll_fwb_ (u"࠭ࡣࡰࡰࡩ࡭ࡷࡳ࠮ࡺࠩᙹ")] = random.randint(0, 120)
        data[l1l111ll1l1ll_fwb_ (u"ࠧࡤࡱࡱࡪ࡮ࡸ࡭࠯ࡺࠪᙺ")] = random.randint(0, 120)
        header={l1l111ll1l1ll_fwb_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᙻ"):l1llll1ll11ll1l1ll_fwb_,l1l111ll1l1ll_fwb_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪᙼ"):url}
        l1llll11lll1ll1l1ll_fwb_ = url + l1l111ll1l1ll_fwb_ (u"ࠪࠧࠬᙽ")
        content,c = l11ll11l11ll1l1ll_fwb_(l1llll11lll1ll1l1ll_fwb_,urllib.urlencode(data),header=header)
        match = re.findall(l1l111ll1l1ll_fwb_ (u"࡛ࠫࠬ࠭ࠣࠩࡠࡃࡸࡵࡵࡳࡥࡨࡷࡠ࠭ࠢ࡞ࡁ࡟ࡷ࠯ࡀ࡜ࡴࠬࠫࡠࡠ࠴ࠪࡀ࡞ࡠ࠭ࠬ࠭ࠧᙾ"), content)
    if match:
        try:
            data = json.loads(match[0])
            l1llll11l1l1ll1l1ll_fwb_=[]
            for d in data:
                if isinstance(d,dict):
                    l1llll11ll11ll1l1ll_fwb_ = d.get(l1l111ll1l1ll_fwb_ (u"ࠬ࡬ࡩ࡭ࡧࠪᙿ"),l1l111ll1l1ll_fwb_ (u"࠭ࠧ "))+l1l111ll1l1ll_fwb_ (u"ࠧࡽࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂࠫࡳࠧࡔࡨࡪࡪࡸࡥࡳ࠿ࠨࡷࠬᚁ")%(l1llll1ll11ll1l1ll_fwb_,url)
                    l1llll11l1l1ll1l1ll_fwb_.append((d.get(l1l111ll1l1ll_fwb_ (u"ࠨ࡮ࡤࡦࡪࡲࠧᚂ"),l1l111ll1l1ll_fwb_ (u"ࠩࠪᚃ")),l1llll11ll11ll1l1ll_fwb_))
        except:
            l1llll11l1l1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠪࠫࠬࡡࠧࠣ࡟ࡂࡪ࡮ࡲࡥ࡜ࠩࠥࡡࡄࡢࡳࠫ࠼࡟ࡷ࠯ࡡࠧࠣ࡟ࡂࠬࡠࡤࠧࠣ࡟࠮࠭ࠬ࠭ࠧᚄ"), match[0])
            if l1llll11l1l1ll1l1ll_fwb_:
                l1llll11l1l1ll1l1ll_fwb_ = l1llll11l1l1ll1l1ll_fwb_[0].replace(l1l111ll1l1ll_fwb_ (u"ࠫࡡ࠵ࠧᚅ"), l1l111ll1l1ll_fwb_ (u"ࠬ࠵ࠧᚆ"))
                l1llll11l1l1ll1l1ll_fwb_ += l1l111ll1l1ll_fwb_ (u"࠭ࡼࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠪࡹࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠧࡶࠫᚇ")%(l1llll1ll11ll1l1ll_fwb_,url)
    return l1llll11l1l1ll1l1ll_fwb_
