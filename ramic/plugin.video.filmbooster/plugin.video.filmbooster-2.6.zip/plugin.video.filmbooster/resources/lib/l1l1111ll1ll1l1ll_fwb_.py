# -*- coding: utf-8 -*-
import sys
l1ll11ll1l1ll_fwb_ = sys.version_info [0] == 2
l1111ll1l1ll_fwb_ = 2048
l1l1l1ll1l1ll_fwb_ = 7
def l1l111ll1l1ll_fwb_ (keyedStringLiteral):
	global l11ll1ll1l1ll_fwb_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll1l1ll_fwb_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import os,re,urllib
import xbmc,xbmcaddon,xbmcgui,xbmcvfs
l1l11l1111ll1l1ll_fwb_    = xbmcaddon.Addon().getAddonInfo
l1l11l11l1ll1l1ll_fwb_     = xbmcvfs.File
l11llllll1ll1l1ll_fwb_   = xbmcvfs.delete
l1l111l111ll1l1ll_fwb_     = xbmc.translatePath(l1l11l1111ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"࠭ࡰࡳࡱࡩ࡭ࡱ࡫ࠧఇ"))).decode(l1l111ll1l1ll_fwb_ (u"ࠧࡶࡶࡩ࠱࠽࠭ఈ"))
l1l111l1l1ll1l1ll_fwb_        = xbmcgui.ControlImage
l1l1111111ll1l1ll_fwb_ = xbmcgui.WindowDialog()
l1l11111l1ll1l1ll_fwb_     = xbmc.Keyboard
def l1l1111l11ll1l1ll_fwb_(response):
    try:
        i = os.path.join(l1l111l111ll1l1ll_fwb_,l1l111ll1l1ll_fwb_ (u"ࠨࡥࡤࡴࡹࡩࡨࡢ࠰ࡳࡲ࡬࠭ఉ"))
        f = l1l11l11l1ll1l1ll_fwb_(i, l1l111ll1l1ll_fwb_ (u"ࠩࡺࠫఊ"))
        f.write(response)
        f.close()
        f = l1l111l1l1ll1l1ll_fwb_(450,5,375,115, i)
        d = l1l1111111ll1l1ll_fwb_
        d.addControl(f)
        l11llllll1ll1l1ll_fwb_(i)
        d.show()
        k = xbmc.Keyboard(l1l111ll1l1ll_fwb_ (u"ࠪࠫఋ"), l1l111ll1l1ll_fwb_ (u"ࠫࠬఌ"))
        k.doModal()
        c = k.getText() if k.isConfirmed() else None
        if c == l1l111ll1l1ll_fwb_ (u"ࠬ࠭఍"): c = None
        d.removeControl(f)
        d.close()
        return c
    except:
        return
def l11lllll11ll1l1ll_fwb_(title=l1l111ll1l1ll_fwb_ (u"࠭ࠧఎ"),l1l111lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࠨఏ"),l1l111ll11ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠨࠩఐ")):
    xbmcgui.Dialog().ok(title,l1l111lll1ll1l1ll_fwb_,l1l111ll11ll1l1ll_fwb_)
