# -*- coding: utf-8 -*-
import sys
l1ll11ll1l1ll_fwb_ = sys.version_info [0] == 2
l1111ll1l1ll_fwb_ = 2048
l1l1l1ll1l1ll_fwb_ = 7
def l1l111ll1l1ll_fwb_ (keyedStringLiteral):
	global l11ll1ll1l1ll_fwb_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll1l1ll_fwb_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import re
import time
import json
import urllib2
_1lll1ll11l1ll1l1ll_fwb_ = { l1l111ll1l1ll_fwb_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᚈ"): l1l111ll1l1ll_fwb_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠻࠴࠲࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠳࠱࠰࠳࠲࠶࠻࠹࠺࠰࠹࠽࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬᚉ")}
_1lll1lll111ll1l1ll_fwb_ = 10
def l11ll11l11ll1l1ll_fwb_(url,data={},headers={}):
    req = urllib2.Request(url,json.dumps(data),headers=headers)
    try:
        response = urllib2.urlopen(req, timeout=10)
        l111111l1ll1l1ll_fwb_ = response.read()
        response.close()
    except:
        l111111l1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠩࠪᚊ")
    return l111111l1ll1l1ll_fwb_
def l11lll111ll1l1ll_fwb_(url):
    if l1l111ll1l1ll_fwb_ (u"ࠪࡷ࡭࠴ࡳࡵ࠱ࠪᚋ") in url:
        url = _1lll1lllll1ll1l1ll_fwb_(url)
    elif l1l111ll1l1ll_fwb_ (u"ࠫࡸࡧࡦࡦ࡮࡬ࡲࡰ࡯࡮ࡨ࠰ࡱࡩࡹ࠭ᚌ") in url:
        url = _1lll1llll11ll1l1ll_fwb_(url)
    elif l1l111ll1l1ll_fwb_ (u"ࠬࡼࡩࡪࡦ࠱ࡱࡪ࠭ᚍ") in url:
        url = _1lll1ll1l11ll1l1ll_fwb_(url)
    return url
def _1lll1ll1l11ll1l1ll_fwb_(uri):
    l1llll1111l1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"࠭ࠧᚎ")
    html = l11ll11l11ll1l1ll_fwb_(uri, headers=_1lll1ll11l1ll1l1ll_fwb_)
    l1lll1lll1l1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࡲࠨࡵࡨࡷࡸ࡯࡯࡯ࡋࡧࡠ࠿࠮࠮ࠫࡁࠬࡠࠧࡢࠬࠨᚏ"), html)
    if len(l1lll1lll1l1ll1l1ll_fwb_) > 0:
        l1lll1lll1l1ll1l1ll_fwb_ = re.sub(l1l111ll1l1ll_fwb_ (u"ࡳࠩ࡟ࡷࡡࠨࠧᚐ"), l1l111ll1l1ll_fwb_ (u"ࠩࠪᚑ"), l1lll1lll1l1ll1l1ll_fwb_[0])
        l1llll111l11ll1l1ll_fwb_ = {
            l1l111ll1l1ll_fwb_ (u"࡙ࠥࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠢᚒ"): l1l111ll1l1ll_fwb_ (u"ࠦࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱ࠢࠫ࡜࠶࠷࠻ࠡࡎ࡬ࡲࡺࡾࠠࡹ࠺࠹ࡣ࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠷࠱࠵࠶ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠷࠷࠯࠲࠱࠽࠻࠹࠮࠵࠸ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠻࠮࠲࠳ࠥᚓ"),
            l1l111ll1l1ll_fwb_ (u"ࠧࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠢᚔ"): l1l111ll1l1ll_fwb_ (u"ࠨࡧࡻ࡫ࡳ࠰ࡩ࡫ࡦ࡭ࡣࡷࡩ࠱ࡹࡤࡤࡪࠥᚕ"),
            l1l111ll1l1ll_fwb_ (u"ࠢࡂࡥࡦࡩࡵࡺ࠭ࡍࡣࡱ࡫ࡺࡧࡧࡦࠤᚖ"): l1l111ll1l1ll_fwb_ (u"ࠣࡧࡱ࠱࡚࡙ࠬࡦࡰ࠾࠰ࡶࡃ࠰࠯࠺ࠥᚗ"),
            l1l111ll1l1ll_fwb_ (u"ࠤࡆࡳࡳࡴࡥࡤࡶ࡬ࡳࡳࠨᚘ"): l1l111ll1l1ll_fwb_ (u"ࠥ࡯ࡪ࡫ࡰ࠮ࡣ࡯࡭ࡻ࡫ࠢᚙ"),
            l1l111ll1l1ll_fwb_ (u"ࠦࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠥᚚ"): l1l111ll1l1ll_fwb_ (u"ࠧࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠦ᚛"),
            l1l111ll1l1ll_fwb_ (u"ࠨࡈࡰࡵࡷࠦ᚜"): l1l111ll1l1ll_fwb_ (u"ࠢࡴࡪ࠱ࡷࡹࠨ᚝"),
            l1l111ll1l1ll_fwb_ (u"ࠣࡔࡨࡪࡪࡸࡥࡳࠤ᚞"): uri,
            l1l111ll1l1ll_fwb_ (u"ࠤࡒࡶ࡮࡭ࡩ࡯ࠤ᚟"): l1l111ll1l1ll_fwb_ (u"ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡺ࡮࡯ࡤ࠯࡯ࡨࠦᚠ"),
            l1l111ll1l1ll_fwb_ (u"ࠦ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠢᚡ"): l1l111ll1l1ll_fwb_ (u"ࠧ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹࠨᚢ")
        }
        time.sleep(5)
        l1llll111ll1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡶࡪ࡫ࡧ࠲ࡲ࡫࠯ࡴࡪࡲࡶࡹ࡫ࡳࡵ࠯ࡸࡶࡱ࠵ࡥ࡯ࡦ࠰ࡥࡩࡹࡥࡴࡵ࡬ࡳࡳࡅࡡࡥࡕࡨࡷࡸ࡯࡯࡯ࡋࡧࡁࠪࡹࠦࡢࡦࡥࡨࡂ࠷ࠦࡤࡣ࡯ࡰࡧࡧࡣ࡬࠿ࡦࠫᚣ")%l1lll1lll1l1ll1l1ll_fwb_
        response = l11ll11l11ll1l1ll_fwb_(l1llll111ll1ll1l1ll_fwb_, headers=l1llll111l11ll1l1ll_fwb_)
        l1llll1111l1ll1l1ll_fwb_=re.search(l1l111ll1l1ll_fwb_ (u"ࠧࠣࡦࡨࡷࡹ࡯࡮ࡢࡶ࡬ࡳࡳ࡛ࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫᚤ"),response)
        if l1llll1111l1ll1l1ll_fwb_:
            l1llll1111l1ll1l1ll_fwb_=l1llll1111l1ll1l1ll_fwb_.group(1).replace(l1l111ll1l1ll_fwb_ (u"ࠨ࡞࡟ࠫᚥ"),l1l111ll1l1ll_fwb_ (u"ࠩࠪᚦ"))
    return l1llll1111l1ll1l1ll_fwb_
def _1lll1llll11ll1l1ll_fwb_(url):
    hash = url.split(l1l111ll1l1ll_fwb_ (u"ࠪ࠳ࠬᚧ"))[-1]
    l1lll1ll1ll1ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡧࡳࡩࠩᚨ"): hash}
    headers = { l1l111ll1l1ll_fwb_ (u"ࠧࡇࡣࡤࡧࡳࡸࠧᚩ"): l1l111ll1l1ll_fwb_ (u"ࠨࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯࠮ࠣࡸࡪࡾࡴ࠰ࡲ࡯ࡥ࡮ࡴࠬࠡࠬ࠲࠮ࠧᚪ"),
                l1l111ll1l1ll_fwb_ (u"ࠢࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪࠨᚫ"): l1l111ll1l1ll_fwb_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱࠫᚬ")}
    response = l11ll11l11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶࡥ࡫࡫࡬ࡪࡰ࡮࡭ࡳ࡭࠮࡯ࡧࡷ࠳ࡻ࠷࠯ࡱࡴࡲࡸࡪࡩࡴࡦࡦࠪᚭ"),data=l1lll1ll1ll1ll1l1ll_fwb_,headers=headers)
    l1llll111111ll1l1ll_fwb_ = json.loads( response)
    if l1llll111111ll1l1ll_fwb_:
        l1lll11111ll1l1ll_fwb_=l1llll111111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠪࡰ࡮ࡴ࡫ࡴࠩᚮ"),[])
        if len(l1lll11111ll1l1ll_fwb_):
            url=l1lll11111ll1l1ll_fwb_[0].get(l1l111ll1l1ll_fwb_ (u"ࠫࡺࡸ࡬ࠨᚯ"),l1l111ll1l1ll_fwb_ (u"ࠬ࠭ᚰ"))
    return url
def _1lll1lllll1ll1l1ll_fwb_(uri):
    l1llll1111l1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"࠭ࠧᚱ")
    html = l11ll11l11ll1l1ll_fwb_(uri, headers=_1lll1ll11l1ll1l1ll_fwb_)
    l1lll1lll1l1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࡲࠨࡵࡨࡷࡸ࡯࡯࡯ࡋࡧࡠ࠿࠮࠮ࠫࡁࠬࡠࠧࡢࠬࠨᚲ"), html)
    if len(l1lll1lll1l1ll1l1ll_fwb_) > 0:
        l1lll1lll1l1ll1l1ll_fwb_ = re.sub(l1l111ll1l1ll_fwb_ (u"ࡳࠩ࡟ࡷࡡࠨࠧᚳ"), l1l111ll1l1ll_fwb_ (u"ࠩࠪᚴ"), l1lll1lll1l1ll1l1ll_fwb_[0])
        l1llll111l11ll1l1ll_fwb_ = {
            l1l111ll1l1ll_fwb_ (u"࡙ࠥࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠢᚵ"): l1l111ll1l1ll_fwb_ (u"ࠦࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱ࠢࠫ࡜࠶࠷࠻ࠡࡎ࡬ࡲࡺࡾࠠࡹ࠺࠹ࡣ࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠷࠱࠵࠶ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠷࠷࠯࠲࠱࠽࠻࠹࠮࠵࠸ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠻࠮࠲࠳ࠥᚶ"),
            l1l111ll1l1ll_fwb_ (u"ࠧࡇࡣࡤࡧࡳࡸ࠲ࡋ࡮ࡤࡱࡧ࡭ࡳ࡭ࠢᚷ"): l1l111ll1l1ll_fwb_ (u"ࠨࡧࡻ࡫ࡳ࠰ࡩ࡫ࡦ࡭ࡣࡷࡩ࠱ࡹࡤࡤࡪࠥᚸ"),
            l1l111ll1l1ll_fwb_ (u"ࠢࡂࡥࡦࡩࡵࡺ࠭ࡍࡣࡱ࡫ࡺࡧࡧࡦࠤᚹ"): l1l111ll1l1ll_fwb_ (u"ࠣࡧࡱ࠱࡚࡙ࠬࡦࡰ࠾࠰ࡶࡃ࠰࠯࠺ࠥᚺ"),
            l1l111ll1l1ll_fwb_ (u"ࠤࡆࡳࡳࡴࡥࡤࡶ࡬ࡳࡳࠨᚻ"): l1l111ll1l1ll_fwb_ (u"ࠥ࡯ࡪ࡫ࡰ࠮ࡣ࡯࡭ࡻ࡫ࠢᚼ"),
            l1l111ll1l1ll_fwb_ (u"ࠦࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠥᚽ"): l1l111ll1l1ll_fwb_ (u"ࠧࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠦᚾ"),
            l1l111ll1l1ll_fwb_ (u"ࠨࡈࡰࡵࡷࠦᚿ"): l1l111ll1l1ll_fwb_ (u"ࠢࡴࡪ࠱ࡷࡹࠨᛀ"),
            l1l111ll1l1ll_fwb_ (u"ࠣࡔࡨࡪࡪࡸࡥࡳࠤᛁ"): uri,
            l1l111ll1l1ll_fwb_ (u"ࠤࡒࡶ࡮࡭ࡩ࡯ࠤᛂ"): l1l111ll1l1ll_fwb_ (u"ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡷ࡭࠴ࡳࡵࠤᛃ"),
            l1l111ll1l1ll_fwb_ (u"ࠦ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠢᛄ"): l1l111ll1l1ll_fwb_ (u"ࠧ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹࠨᛅ")
        }
        time.sleep(5)
        l1llll111ll1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳࡩ࠰ࡶࡸ࠴ࡹࡨࡰࡴࡷࡩࡸࡺ࠭ࡶࡴ࡯࠳ࡪࡴࡤ࠮ࡣࡧࡷࡪࡹࡳࡪࡱࡱࡃࡦࡪࡓࡦࡵࡶ࡭ࡴࡴࡉࡥ࠿ࠨࡷࠫࡧࡤࡣࡦࡀ࠵ࠫࡩࡡ࡭࡮ࡥࡥࡨࡱ࠽ࡤࠩᛆ")%l1lll1lll1l1ll1l1ll_fwb_
        response = l11ll11l11ll1l1ll_fwb_(l1llll111ll1ll1l1ll_fwb_, headers=l1llll111l11ll1l1ll_fwb_)
        l1llll1111l1ll1l1ll_fwb_=re.search(l1l111ll1l1ll_fwb_ (u"ࠧࠣࡦࡨࡷࡹ࡯࡮ࡢࡶ࡬ࡳࡳ࡛ࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫᛇ"),response)
        if l1llll1111l1ll1l1ll_fwb_:
            l1llll1111l1ll1l1ll_fwb_=l1llll1111l1ll1l1ll_fwb_.group(1).replace(l1l111ll1l1ll_fwb_ (u"ࠨ࡞࡟ࠫᛈ"),l1l111ll1l1ll_fwb_ (u"ࠩࠪᛉ"))
    return l1llll1111l1ll1l1ll_fwb_
