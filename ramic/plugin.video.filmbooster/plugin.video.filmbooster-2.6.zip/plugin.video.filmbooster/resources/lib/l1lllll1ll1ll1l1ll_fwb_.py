# coding: UTF-8
import sys
l1ll11ll1l1ll_fwb_ = sys.version_info [0] == 2
l1111ll1l1ll_fwb_ = 2048
l1l1l1ll1l1ll_fwb_ = 7
def l1l111ll1l1ll_fwb_ (keyedStringLiteral):
	global l11ll1ll1l1ll_fwb_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll1l1ll_fwb_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import re,os
import urllib2
import urllib
import urlparse
import time
import cookielib
l1llll1ll11ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡏࡘ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠸࠴࠳࠶࠮࠳࠸࠹࠵࠳࠷࠰࠳ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩබ")
l1lll1llll1ll1l1ll_fwb_=l1llll1ll11ll1l1ll_fwb_
l1ll1l1l1l1ll1l1ll_fwb_ = 3
class l1lll1ll111ll1l1ll_fwb_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
    https_response = http_response
def l1lll111111ll1l1ll_fwb_(l1ll1l11l11ll1l1ll_fwb_):
    try:
        offset = 1 if l1ll1l11l11ll1l1ll_fwb_[0] == l1l111ll1l1ll_fwb_ (u"ࠫ࠰࠭භ") else 0
        return int(eval(l1ll1l11l11ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠬࠧࠫ࡜࡟ࠪම"), l1l111ll1l1ll_fwb_ (u"࠭࠱ࠨඹ")).replace(l1l111ll1l1ll_fwb_ (u"ࠧࠢࠣ࡞ࡡࠬය"), l1l111ll1l1ll_fwb_ (u"ࠨ࠳ࠪර")).replace(l1l111ll1l1ll_fwb_ (u"ࠩ࡞ࡡࠬ඼"), l1l111ll1l1ll_fwb_ (u"ࠪ࠴ࠬල")).replace(l1l111ll1l1ll_fwb_ (u"ࠫ࠭࠭඾"), l1l111ll1l1ll_fwb_ (u"ࠬࡹࡴࡳࠪࠪ඿"))[offset:]))
    except:
        pass
url=l1l111ll1l1ll_fwb_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤࡦࡤࡼ࠳ࡺࡶ࠰ࠩව")
wait=True
l1ll11llll1ll1l1ll_fwb_=l1llll1ll11ll1l1ll_fwb_
l11l11l1l1ll1l1ll_fwb_ = cookielib.LWPCookieJar()
def l111lll111ll1l1ll_fwb_(url,l11l11l1l1ll1l1ll_fwb_=l11l11l1l1ll1l1ll_fwb_,l1lll1llll1ll1l1ll_fwb_=l1llll1ll11ll1l1ll_fwb_):
    return l1ll1l11111ll1l1ll_fwb_(url,l11l11l1l1ll1l1ll_fwb_,l1ll11llll1ll1l1ll_fwb_=l1lll1llll1ll1l1ll_fwb_, wait=True)
def l1ll1l11111ll1l1ll_fwb_(url, l11l11l1l1ll1l1ll_fwb_, l1ll11llll1ll1l1ll_fwb_=None, wait=True):
    if l1ll11llll1ll1l1ll_fwb_ is None: l1ll11llll1ll1l1ll_fwb_ = l1llll1ll11ll1l1ll_fwb_
    headers = {l1l111ll1l1ll_fwb_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫශ"): l1ll11llll1ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩෂ"): url}
    if l11l11l1l1ll1l1ll_fwb_ is not None:
        try: l11l11l1l1ll1l1ll_fwb_.load(ignore_discard=True)
        except: pass
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l11l11l1l1ll1l1ll_fwb_))
        urllib2.install_opener(opener)
    request = urllib2.Request(url)
    for key in headers: request.add_header(key, headers[key])
    try:
        response = urllib2.urlopen(request)
        html = response.read()
    except urllib2.HTTPError as e:
        html = e.read()
    l1ll1l1ll11ll1l1ll_fwb_ = 0
    while l1ll1l1ll11ll1l1ll_fwb_ < l1ll1l1l1l1ll1l1ll_fwb_:
        l1ll1l111l1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠩࡹࡥࡷࠦࠨࡀ࠼ࡶ࠰ࡹ࠲࡯࠭ࡲ࠯ࡦ࠱ࡸࠬࡦ࠮ࡤ࠰ࡰ࠲ࡩ࠭ࡰ࠯࡫ࢁࡺࠬࡳ࠮ࡤ࠭࠱࡬ࠬ࡝ࡵ࠭ࠬࡠࡤ࠽࡞࠭ࠬࡁࢀࠨࠨ࡜ࡠࠥࡡ࠰࠯ࠢ࠻ࠪ࡞ࡢࢂࡣࠫࠪࡿ࠾࠲࠰ࡩࡨࡢ࡮࡯ࡩࡳ࡭ࡥ࠮ࡨࡲࡶࡲࡢࠧ࡝ࠫ࠾࠲࠯ࡅ࡜࡯࠰࠭ࡃࡀ࠮࠮ࠫࡁࠬ࠿ࡦࡢ࠮ࡷࡣ࡯ࡹࡪ࠭ස")
        l1ll1ll1ll1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠪ࡭ࡳࡶࡵࡵࠢࡷࡽࡵ࡫࠽ࠣࡪ࡬ࡨࡩ࡫࡮ࠣࠢࡱࡥࡲ࡫࠽ࠣ࡬ࡶࡧ࡭ࡲ࡟ࡷࡥࠥࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭ࡡ࡞ࠣ࡟࠮࠭ࠬහ")
        l1ll1ll1l11ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠫ࡮ࡴࡰࡶࡶࠣࡸࡾࡶࡥ࠾ࠤ࡫࡭ࡩࡪࡥ࡯ࠤࠣࡲࡦࡳࡥ࠾ࠤࡳࡥࡸࡹࠢࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࡞ࡢࠧࡣࠫࠪࠩළ")
        l1ll1ll11l1ll1l1ll_fwb_ = re.search(l1ll1l111l1ll1l1ll_fwb_, html, re.DOTALL)
        l1ll1lll111ll1l1ll_fwb_ = re.search(l1ll1ll1ll1ll1l1ll_fwb_, html)
        l1lll1111l1ll1l1ll_fwb_ = re.search(l1ll1ll1l11ll1l1ll_fwb_, html)
        if not l1ll1ll11l1ll1l1ll_fwb_ or not l1ll1lll111ll1l1ll_fwb_ or not l1lll1111l1ll1l1ll_fwb_:
            return False
        l1lll111l11ll1l1ll_fwb_, l1ll1l1l111ll1l1ll_fwb_, l1ll1ll1111ll1l1ll_fwb_, l1ll1llll11ll1l1ll_fwb_ = l1ll1ll11l1ll1l1ll_fwb_.groups()
        l1lll111ll1ll1l1ll_fwb_ = l1ll1lll111ll1l1ll_fwb_.group(1)
        password = l1lll1111l1ll1l1ll_fwb_.group(1)
        l1ll1l11ll1ll1l1ll_fwb_ = (l1lll111l11ll1l1ll_fwb_, l1ll1l1l111ll1l1ll_fwb_)
        result = int(l1lll111111ll1l1ll_fwb_(l1ll1ll1111ll1l1ll_fwb_.rstrip()))
        for l1ll1l11l11ll1l1ll_fwb_ in l1ll1llll11ll1l1ll_fwb_.split(l1l111ll1l1ll_fwb_ (u"ࠬࡁࠧෆ")):
            l1ll1l11l11ll1l1ll_fwb_ = l1ll1l11l11ll1l1ll_fwb_.rstrip()
            if l1ll1l11l11ll1l1ll_fwb_[:len(l1l111ll1l1ll_fwb_ (u"࠭࠮ࠨ෇").join(l1ll1l11ll1ll1l1ll_fwb_))] != l1l111ll1l1ll_fwb_ (u"ࠧ࠯ࠩ෈").join(l1ll1l11ll1ll1l1ll_fwb_):
                    print l1l111ll1l1ll_fwb_ (u"ࠨࡇࡴࡹࡦࡺࡩࡰࡰࠣࡨࡴ࡫ࡳࠡࡰࡲࡸࠥࡹࡴࡢࡴࡷࠤࡼ࡯ࡴࡩࠢࡹࡥࡷࡴࡡ࡮ࡧࠣࢀࠪࡹࡼࠨ෉") % (l1ll1l11l11ll1l1ll_fwb_)
            else:
                    l1ll1l11l11ll1l1ll_fwb_ = l1ll1l11l11ll1l1ll_fwb_[len(l1l111ll1l1ll_fwb_ (u"ࠩ࠱්ࠫ").join(l1ll1l11ll1ll1l1ll_fwb_)):]
            l1ll11lll11ll1l1ll_fwb_ = l1ll1l11l11ll1l1ll_fwb_[2:]
            l1ll1lllll1ll1l1ll_fwb_ = l1ll1l11l11ll1l1ll_fwb_[0]
            if l1ll1lllll1ll1l1ll_fwb_ not in [l1l111ll1l1ll_fwb_ (u"ࠪ࠯ࠬ෋"), l1l111ll1l1ll_fwb_ (u"ࠫ࠲࠭෌"), l1l111ll1l1ll_fwb_ (u"ࠬ࠰ࠧ෍"), l1l111ll1l1ll_fwb_ (u"࠭࠯ࠨ෎")]:
                print l1l111ll1l1ll_fwb_ (u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡱࡳࡩࡷࡧࡴࡰࡴ࠽ࠤࢁࠫࡳࡽࠩා") % (l1ll1l11l11ll1l1ll_fwb_)
                continue
            result = int(str(eval(str(result) + l1ll1lllll1ll1l1ll_fwb_ + str(l1lll111111ll1l1ll_fwb_(l1ll11lll11ll1l1ll_fwb_)))))
        scheme = urlparse.urlparse(url).scheme
        l1lll11l111ll1l1ll_fwb_ = urlparse.urlparse(url).hostname
        result += len(l1lll11l111ll1l1ll_fwb_)
        if wait: time.sleep(5)
        url = l1l111ll1l1ll_fwb_ (u"ࠨࠧࡶ࠾࠴࠵ࠥࡴ࠱ࡦࡨࡳ࠳ࡣࡨ࡫࠲ࡰ࠴ࡩࡨ࡬ࡡ࡭ࡷࡨ࡮࡬ࡀ࡬ࡶࡧ࡭ࡲ࡟ࡷࡥࡀࠩࡸࠬࡪࡴࡥ࡫ࡰࡤࡧ࡮ࡴࡹࡨࡶࡂࠫࡳࠧࡲࡤࡷࡸࡃࠥࡴࠩැ") % (scheme, l1lll11l111ll1l1ll_fwb_, l1lll111ll1ll1l1ll_fwb_, result, urllib.quote(password))
        request = urllib2.Request(url)
        for key in headers: request.add_header(key, headers[key])
        try:
            opener = urllib2.build_opener(l1lll1ll111ll1l1ll_fwb_)
            urllib2.install_opener(opener)
            response = urllib2.urlopen(request)
            while response.getcode() in [301, 302, 303, 307]:
                if l11l11l1l1ll1l1ll_fwb_ is not None:
                    l11l11l1l1ll1l1ll_fwb_.l1ll1lll1l1ll1l1ll_fwb_(response, request)
                request = urllib2.Request(response.info().getheader(l1l111ll1l1ll_fwb_ (u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫෑ")))
                for key in headers: request.add_header(key, headers[key])
                if l11l11l1l1ll1l1ll_fwb_ is not None:
                    l11l11l1l1ll1l1ll_fwb_.l1ll1l1lll1ll1l1ll_fwb_(request)
                response = urllib2.urlopen(request)
            final = response.read()
            if l1l111ll1l1ll_fwb_ (u"ࠪࡧ࡫࠳ࡢࡳࡱࡺࡷࡪࡸ࠭ࡷࡧࡵ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠭ි") in final:
                l1ll1l1ll11ll1l1ll_fwb_ += 1
                html = final
            else:
                break
        except urllib2.HTTPError as e:
            print l1l111ll1l1ll_fwb_ (u"ࠫࡈࡲ࡯ࡶࡦࡉࡰࡦࡸࡥࠡࡇࡵࡶࡴࡸ࠺ࠡࠧࡶࠤࡴࡴࠠࡶࡴ࡯࠾ࠥࠫࡳࠨී") % (e.code, url)
            return False
    return l11l11l1l1ll1l1ll_fwb_
def l1lllllll11ll1l1ll_fwb_(l111111l11ll1l1ll_fwb_):
    l1lll1ll1l1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠬ࠭ු")
    if os.path.isfile(l111111l11ll1l1ll_fwb_):
        l11l11l1l1ll1l1ll_fwb_ = cookielib.LWPCookieJar()
        l11l11l1l1ll1l1ll_fwb_.load(l111111l11ll1l1ll_fwb_)
        for c in l11l11l1l1ll1l1ll_fwb_:
            l1lll1ll1l1ll1l1ll_fwb_+=l1l111ll1l1ll_fwb_ (u"࠭ࠥࡴ࠿ࠨࡷࡀ࠭෕")%(c.name, c.value)
    return l1lll1ll1l1ll1l1ll_fwb_
