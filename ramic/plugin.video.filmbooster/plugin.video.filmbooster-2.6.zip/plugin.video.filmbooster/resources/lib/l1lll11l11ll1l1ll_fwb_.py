# -*- coding: utf-8 -*-
import sys
l1ll11ll1l1ll_fwb_ = sys.version_info [0] == 2
l1111ll1l1ll_fwb_ = 2048
l1l1l1ll1l1ll_fwb_ = 7
def l1l111ll1l1ll_fwb_ (keyedStringLiteral):
	global l11ll1ll1l1ll_fwb_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll1l1ll_fwb_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
l1l111ll1l1ll_fwb_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࡄࡱࡹࡩࡳࡧ࡮ࡵࠢࡄࡨࡩ࠳࡯࡯ࠌࠍࠤࠥࠦࠠࡕࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡩࡴࠢࡩࡶࡪ࡫ࠠࡴࡱࡩࡸࡼࡧࡲࡦ࠼ࠣࡽࡴࡻࠠࡤࡣࡱࠤࡷ࡫ࡤࡪࡵࡷࡶ࡮ࡨࡵࡵࡧࠣ࡭ࡹࠦࡡ࡯ࡦ࠲ࡳࡷࠦ࡭ࡰࡦ࡬ࡪࡾࠐࠠࠡࠢࠣ࡭ࡹࠦࡵ࡯ࡦࡨࡶࠥࡺࡨࡦࠢࡷࡩࡷࡳࡳࠡࡱࡩࠤࡹ࡮ࡥࠡࡉࡑ࡙ࠥࡍࡥ࡯ࡧࡵࡥࡱࠦࡐࡶࡤ࡯࡭ࡨࠦࡌࡪࡥࡨࡲࡸ࡫ࠠࡢࡵࠣࡴࡺࡨ࡬ࡪࡵ࡫ࡩࡩࠦࡢࡺࠌࠣࠤࠥࠦࡴࡩࡧࠣࡊࡷ࡫ࡥࠡࡕࡲࡪࡹࡽࡡࡳࡧࠣࡊࡴࡻ࡮ࡥࡣࡷ࡭ࡴࡴࠬࠡࡧ࡬ࡸ࡭࡫ࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࠢ࠶ࠤࡴ࡬ࠠࡵࡪࡨࠤࡑ࡯ࡣࡦࡰࡶࡩ࠱ࠦ࡯ࡳࠌࠣࠤࠥࠦࠨࡢࡶࠣࡽࡴࡻࡲࠡࡱࡳࡸ࡮ࡵ࡮ࠪࠢࡤࡲࡾࠦ࡬ࡢࡶࡨࡶࠥࡼࡥࡳࡵ࡬ࡳࡳ࠴ࠊࠋࠢࠣࠤ࡚ࠥࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰࠤ࡮ࡹࠠࡥ࡫ࡶࡸࡷ࡯ࡢࡶࡶࡨࡨࠥ࡯࡮ࠡࡶ࡫ࡩࠥ࡮࡯ࡱࡧࠣࡸ࡭ࡧࡴࠡ࡫ࡷࠤࡼ࡯࡬࡭ࠢࡥࡩࠥࡻࡳࡦࡨࡸࡰ࠱ࠐࠠࠡࠢࠣࡦࡺࡺࠠࡘࡋࡗࡌࡔ࡛ࡔࠡࡃࡑ࡝ࠥ࡝ࡁࡓࡔࡄࡒ࡙࡟࠻ࠡࡹ࡬ࡸ࡭ࡵࡵࡵࠢࡨࡺࡪࡴࠠࡵࡪࡨࠤ࡮ࡳࡰ࡭࡫ࡨࡨࠥࡽࡡࡳࡴࡤࡲࡹࡿࠠࡰࡨࠍࠤࠥࠦࠠࡎࡇࡕࡇࡍࡇࡎࡕࡃࡅࡍࡑࡏࡔ࡚ࠢࡲࡶࠥࡌࡉࡕࡐࡈࡗࡘࠦࡆࡐࡔࠣࡅࠥࡖࡁࡓࡖࡌࡇ࡚ࡒࡁࡓࠢࡓ࡙ࡗࡖࡏࡔࡇ࠱ࠤ࡙ࠥࡥࡦࠢࡷ࡬ࡪࠐࠠࠡࠢࠣࡋࡓ࡛ࠠࡈࡧࡱࡩࡷࡧ࡬ࠡࡒࡸࡦࡱ࡯ࡣࠡࡎ࡬ࡧࡪࡴࡳࡦࠢࡩࡳࡷࠦ࡭ࡰࡴࡨࠤࡩ࡫ࡴࡢ࡫࡯ࡷ࠳ࠐࠊࠡࠢࠣࠤ࡞ࡵࡵࠡࡵ࡫ࡳࡺࡲࡤࠡࡪࡤࡺࡪࠦࡲࡦࡥࡨ࡭ࡻ࡫ࡤࠡࡣࠣࡧࡴࡶࡹࠡࡱࡩࠤࡹ࡮ࡥࠡࡉࡑ࡙ࠥࡍࡥ࡯ࡧࡵࡥࡱࠦࡐࡶࡤ࡯࡭ࡨࠦࡌࡪࡥࡨࡲࡸ࡫ࠊࠡࠢࠣࠤࡦࡲ࡯࡯ࡩࠣࡻ࡮ࡺࡨࠡࡶ࡫࡭ࡸࠦࡰࡳࡱࡪࡶࡦࡳ࠮ࠡࠢࡌࡪࠥࡴ࡯ࡵ࠮ࠣࡷࡪ࡫ࠠ࠽ࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡭࡮ࡶ࠰ࡲࡶ࡬࠵࡬ࡪࡥࡨࡲࡸ࡫ࡳ࠰ࡀ࠱ࠎࠧࠨࠢූ")
import os
import sys
import urllib
import urlparse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
l1l11ll1ll1ll1l1ll_fwb_ = 1000
l1ll11l1l11ll1l1ll_fwb_ = xbmcaddon.Addon().getLocalizedString
l1l1lll1l11ll1l1ll_fwb_ = xbmc.getLocalizedString
l1l1l1lll11ll1l1ll_fwb_ = xbmcaddon.Addon().getSetting
setSetting = xbmcaddon.Addon().setSetting
l111l1ll1l1ll_fwb_ = xbmcaddon.Addon
l1l1l11l111ll1l1ll_fwb_ = xbmcplugin.addDirectoryItem
item = xbmcgui.ListItem
directory = xbmcplugin.endOfDirectory
content = xbmcplugin.setContent
property = xbmcplugin.setProperty
l1l11l1111ll1l1ll_fwb_ = xbmcaddon.Addon().getAddonInfo
l1l111l1ll1ll1l1ll_fwb_ = xbmc.getInfoLabel
l1l111l11l1ll1l1ll_fwb_ = xbmc.getCondVisibility
l1l11l1ll11ll1l1ll_fwb_ = xbmc.executeJSONRPC
l1l1ll11l11ll1l1ll_fwb_ = xbmcgui.Window(10000)
l1l111ll111ll1l1ll_fwb_ = xbmcgui.Dialog()
l1l11ll1l11ll1l1ll_fwb_ = xbmcgui.DialogProgress()
l1l11ll1111ll1l1ll_fwb_ = xbmcgui.DialogProgressBG()
l1l1111111ll1l1ll_fwb_ = xbmcgui.WindowDialog()
l1l11l11ll1ll1l1ll_fwb_ = xbmcgui.ControlButton
l1l111l1l1ll1l1ll_fwb_ = xbmcgui.ControlImage
l1l11111l1ll1l1ll_fwb_ = xbmc.Keyboard
sleep = xbmc.sleep
l1l11l1lll1ll1l1ll_fwb_ = xbmc.executebuiltin
l1l1lllll11ll1l1ll_fwb_ = xbmc.getSkinDir()
l1ll11111l1ll1l1ll_fwb_ = xbmc.Player()
l1l1lll1111ll1l1ll_fwb_ = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
resolve = xbmcplugin.setResolvedUrl
l1l11l11l1ll1l1ll_fwb_ = xbmcvfs.File
l1l1l11l1l1ll1l1ll_fwb_ = xbmcvfs.mkdir
l11llllll1ll1l1ll_fwb_ = xbmcvfs.delete
l1l1ll1ll11ll1l1ll_fwb_ = xbmcvfs.rmdir
l1l1l111l11ll1l1ll_fwb_ = xbmcvfs.listdir
l1l1lll1ll1ll1l1ll_fwb_ = xbmc.translatePath
l1ll111l111ll1l1ll_fwb_ = xbmc.translatePath(l1l111ll1l1ll_fwb_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡸࡱࡩ࡯࠱ࠪ෗"))
l1l11l11111ll1l1ll_fwb_ = xbmc.translatePath(l1l11l1111ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠩࡳࡥࡹ࡮ࠧෘ")))
l1l111l111ll1l1ll_fwb_ = xbmc.translatePath(l1l11l1111ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠪࡴࡷࡵࡦࡪ࡮ࡨࠫෙ"))).decode(l1l111ll1l1ll_fwb_ (u"ࠫࡺࡺࡦ࠮࠺ࠪේ"))
l1l111ll1l1ll1l1ll_fwb_ = os.path.join(l1l111l111ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫෛ"))
l1l11l1l111ll1l1ll_fwb_ = os.path.join(l1l111l111ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"࠭ࡶࡪࡧࡺࡷ࠳ࡪࡢࠨො"))
l1l1llll1l1ll1l1ll_fwb_ = os.path.join(l1l111l111ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠧࡣࡱࡲ࡯ࡲࡧࡲ࡬ࡵ࠱ࡨࡧ࠭ෝ"))
l1l11lll111ll1l1ll_fwb_ = os.path.join(l1l111l111ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠨࡲࡵࡳࡻ࡯ࡤࡦࡴࡶ࠲࠶࠹࠮ࡥࡤࠪෞ"))
l1l1l111ll1ll1l1ll_fwb_ = os.path.join(l1l111l111ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠩࡰࡩࡹࡧ࠮࠶࠰ࡧࡦࠬෟ"))
l1ll1111111ll1l1ll_fwb_ = os.path.join(l1l111l111ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠪࡰ࡮ࡨࡲࡢࡴࡼ࠲ࡩࡨࠧ෠"))
l1ll111l1l1ll1l1ll_fwb_ = os.path.join(l1l111l111ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠫࡨࡧࡣࡩࡧ࠱ࡨࡧ࠭෡"))
key = l1l111ll1l1ll_fwb_ (u"ࠧࡘࡧࡖ࡭࡛ࡴ࠷ࡹ࠵ࡷ࠺ࡻ࠳ࡆࡅࡄࠩࡉ࠮ࡏࡧࡖࡥࡔࡪ࡙ࡱ࡞ࡷ࠳ࡵ࠸ࠥ෢")
l1ll1111ll1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠨࡰ࠳ࡵ࠸ࡺ࠽ࡿ࠯ࡃࡁࡈࠬࡍ࠱ࡍࡣࠤ෣")
def l1ll11ll111ll1l1ll_fwb_():
    l1l1l1llll1ll1l1ll_fwb_ = l1l11l11l11ll1l1ll_fwb_() ; l1111ll1ll1l1ll_fwb_ = l1l1llllll1ll1l1ll_fwb_()
    if not (l1111ll1ll1l1ll_fwb_ == None and l1l1l1llll1ll1l1ll_fwb_ in [l1l111ll1l1ll_fwb_ (u"ࠧ࠮ࠩ෤"), l1l111ll1l1ll_fwb_ (u"ࠨࠩ෥")]): return os.path.join(l1111ll1ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠩ࡬ࡧࡴࡴ࠮ࡱࡰࡪࠫ෦"))
    return l1l11l1111ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠪ࡭ࡨࡵ࡮ࠨ෧"))
def l1ll11ll1l1ll1l1ll_fwb_():
    l1l1l1llll1ll1l1ll_fwb_ = l1l11l11l11ll1l1ll_fwb_() ; l1111ll1ll1l1ll_fwb_ = l1l1llllll1ll1l1ll_fwb_()
    if not (l1111ll1ll1l1ll_fwb_ == None and l1l1l1llll1ll1l1ll_fwb_ in [l1l111ll1l1ll_fwb_ (u"ࠫ࠲࠭෨"), l1l111ll1l1ll_fwb_ (u"ࠬ࠭෩")]): return os.path.join(l1111ll1ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"࠭ࡰࡰࡵࡷࡩࡷ࠴ࡰ࡯ࡩࠪ෪"))
    elif l1l1l1llll1ll1l1ll_fwb_ == l1l111ll1l1ll_fwb_ (u"ࠧ࠮ࠩ෫"): return l1l111ll1l1ll_fwb_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬ෬")
    return l1l11l1111ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠩ࡬ࡧࡴࡴࠧ෭"))
def l1l11l1l1l1ll1l1ll_fwb_():
    l1l1l1llll1ll1l1ll_fwb_ = l1l11l11l11ll1l1ll_fwb_() ; l1111ll1ll1l1ll_fwb_ = l1l1llllll1ll1l1ll_fwb_()
    if not (l1111ll1ll1l1ll_fwb_ == None and l1l1l1llll1ll1l1ll_fwb_ in [l1l111ll1l1ll_fwb_ (u"ࠪ࠱ࠬ෮"), l1l111ll1l1ll_fwb_ (u"ࠫࠬ෯")]): return os.path.join(l1111ll1ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠬࡶ࡯ࡴࡶࡨࡶ࠳ࡶ࡮ࡨࠩ෰"))
    return l1l111ll1l1ll_fwb_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡖࡪࡦࡨࡳ࠳ࡶ࡮ࡨࠩ෱")
def l1l1l1l11l1ll1l1ll_fwb_():
    l1l1l1llll1ll1l1ll_fwb_ = l1l11l11l11ll1l1ll_fwb_() ; l1111ll1ll1l1ll_fwb_ = l1l1llllll1ll1l1ll_fwb_()
    if not (l1111ll1ll1l1ll_fwb_ == None and l1l1l1llll1ll1l1ll_fwb_ in [l1l111ll1l1ll_fwb_ (u"ࠧ࠮ࠩෲ"), l1l111ll1l1ll_fwb_ (u"ࠨࠩෳ")]): return os.path.join(l1111ll1ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠩࡥࡥࡳࡴࡥࡳ࠰ࡳࡲ࡬࠭෴"))
    return l1l111ll1l1ll_fwb_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷ࡚࡮ࡪࡥࡰ࠰ࡳࡲ࡬࠭෵")
def l1ll111lll1ll1l1ll_fwb_():
    l1l1l1llll1ll1l1ll_fwb_ = l1l11l11l11ll1l1ll_fwb_() ; l1111ll1ll1l1ll_fwb_ = l1l1llllll1ll1l1ll_fwb_()
    if not (l1111ll1ll1l1ll_fwb_ == None and l1l1l1llll1ll1l1ll_fwb_ in [l1l111ll1l1ll_fwb_ (u"ࠫ࠲࠭෶"), l1l111ll1l1ll_fwb_ (u"ࠬ࠭෷")]): return os.path.join(l1111ll1ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠴ࡪࡱࡩࠪ෸"))
    return l1l11l1111ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠧࡧࡣࡱࡥࡷࡺࠧ෹"))
def l1l1l1l1ll1ll1l1ll_fwb_():
    l1l1l1llll1ll1l1ll_fwb_ = l1l11l11l11ll1l1ll_fwb_() ; l1111ll1ll1l1ll_fwb_ = l1l1llllll1ll1l1ll_fwb_()
    if not (l1111ll1ll1l1ll_fwb_ == None and l1l1l1llll1ll1l1ll_fwb_ in [l1l111ll1l1ll_fwb_ (u"ࠨ࠯ࠪ෺"), l1l111ll1l1ll_fwb_ (u"ࠩࠪ෻")]): return os.path.join(l1111ll1ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠪࡲࡪࡾࡴ࠯ࡲࡱ࡫ࠬ෼"))
    return l1l111ll1l1ll_fwb_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸ࡛࡯ࡤࡦࡱ࠱ࡴࡳ࡭ࠧ෽")
def l1l1l11ll11ll1l1ll_fwb_():
    return l1l11l1111ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠬ࡯ࡤࠨ෾"))
def l11l11111ll1l1ll_fwb_():
    return l1l11l1111ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"࠭࡮ࡢ࡯ࡨࠫ෿"))
def l1l111lll11ll1l1ll_fwb_(l1l1ll1l1l1ll1l1ll_fwb_):
    try:
        query = urllib.urlencode(l1l1ll1l1l1ll1l1ll_fwb_)
    except UnicodeEncodeError:
        for k in l1l1ll1l1l1ll1l1ll_fwb_:
            if isinstance(l1l1ll1l1l1ll1l1ll_fwb_[k], unicode):
                l1l1ll1l1l1ll1l1ll_fwb_[k] = l1l1ll1l1l1ll1l1ll_fwb_[k].encode(l1l111ll1l1ll_fwb_ (u"ࠧࡶࡶࡩ࠱࠽࠭฀"))
        query = urllib.urlencode(l1l1ll1l1l1ll1l1ll_fwb_)
    l1l1lll11l1ll1l1ll_fwb_ = sys.argv[0]
    if not l1l1lll11l1ll1l1ll_fwb_: l1l1lll11l1ll1l1ll_fwb_ = l1l1l11ll11ll1l1ll_fwb_()
    return l1l1lll11l1ll1l1ll_fwb_ + l1l111ll1l1ll_fwb_ (u"ࠨࡁࠪก") + query
def l1l1llllll1ll1l1ll_fwb_():
    l1l1l1llll1ll1l1ll_fwb_ = l1l11l11l11ll1l1ll_fwb_()
    if l1l1l1llll1ll1l1ll_fwb_ in [l1l111ll1l1ll_fwb_ (u"ࠩ࠰ࠫข"), l1l111ll1l1ll_fwb_ (u"ࠪࠫฃ")]: return
    elif l1l111l11l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲ࡍࡧࡳࡂࡦࡧࡳࡳ࠮ࡳࡤࡴ࡬ࡴࡹ࠴ࡣࡰࡸࡨࡲࡦࡴࡴ࠯ࡣࡵࡸࡼࡵࡲ࡬ࠫࠪค")):
        return os.path.join(xbmcaddon.Addon(l1l111ll1l1ll_fwb_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡩ࡯ࡷࡧࡱࡥࡳࡺ࠮ࡢࡴࡷࡻࡴࡸ࡫ࠨฅ")).getAddonInfo(l1l111ll1l1ll_fwb_ (u"࠭ࡰࡢࡶ࡫ࠫฆ")), l1l111ll1l1ll_fwb_ (u"ࠧࡳࡧࡶࡳࡺࡸࡣࡦࡵࠪง"), l1l111ll1l1ll_fwb_ (u"ࠨ࡯ࡨࡨ࡮ࡧࠧจ"), l1l1l1llll1ll1l1ll_fwb_)
def l1l11l11l11ll1l1ll_fwb_():
    l1l11l11l11ll1l1ll_fwb_ = l1l1l1lll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠩࡤࡴࡵ࡫ࡡࡳࡣࡱࡧࡪ࠴࠱ࠨฉ")).lower() if l1l111l11l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡌࡦࡹࡁࡥࡦࡲࡲ࠭ࡹࡣࡳ࡫ࡳࡸ࠳ࡩ࡯ࡷࡧࡱࡥࡳࡺ࠮ࡢࡴࡷࡻࡴࡸ࡫ࠪࠩช")) else l1l1l1lll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠫࡦࡶࡰࡦࡣࡵࡥࡳࡩࡥ࠯ࡣ࡯ࡸࠬซ")).lower()
    return l1l11l11l11ll1l1ll_fwb_
def l1l11lll1l1ll1l1ll_fwb_():
    l1l11l1lll1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠬࡘࡵ࡯ࡒ࡯ࡹ࡬࡯࡮ࠩࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡷࡨࡸࡩࡱࡶ࠱ࡧࡴࡼࡥ࡯ࡣࡱࡸ࠳ࡧࡲࡵࡹࡲࡶࡰ࠯ࠧฌ"))
def l1l1l1111l1ll1l1ll_fwb_(message, l1l111llll1ll1l1ll_fwb_=l1l11l1111ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"࠭࡮ࡢ࡯ࡨࠫญ")), l1l11ll11l1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࠨฎ"), time=3000, l1l1l1l1111ll1l1ll_fwb_=False):
    if l1l11ll11l1ll1l1ll_fwb_ == l1l111ll1l1ll_fwb_ (u"ࠨࠩฏ"): l1l11ll11l1ll1l1ll_fwb_ = l1ll11ll111ll1l1ll_fwb_()
    elif l1l11ll11l1ll1l1ll_fwb_ == l1l111ll1l1ll_fwb_ (u"ࠩࡌࡒࡋࡕࠧฐ"): l1l11ll11l1ll1l1ll_fwb_ = xbmcgui.NOTIFICATION_INFO
    elif l1l11ll11l1ll1l1ll_fwb_ == l1l111ll1l1ll_fwb_ (u"࡛ࠪࡆࡘࡎࡊࡐࡊࠫฑ"): l1l11ll11l1ll1l1ll_fwb_ = xbmcgui.NOTIFICATION_WARNING
    elif l1l11ll11l1ll1l1ll_fwb_ == l1l111ll1l1ll_fwb_ (u"ࠫࡊࡘࡒࡐࡔࠪฒ"): l1l11ll11l1ll1l1ll_fwb_ = xbmcgui.NOTIFICATION_ERROR
    l1l111ll111ll1l1ll_fwb_.notification(l1l111llll1ll1l1ll_fwb_, message, l1l11ll11l1ll1l1ll_fwb_, time, l1l1l1l1111ll1l1ll_fwb_)
def l1ll11l11l1ll1l1ll_fwb_(l1l1ll111l1ll1l1ll_fwb_, l1l1llll111ll1l1ll_fwb_, l1l1ll11ll1ll1l1ll_fwb_, l1l111llll1ll1l1ll_fwb_=l1l11l1111ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠬࡴࡡ࡮ࡧࠪณ")), l1l111l1111ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"࠭ࠧด"), l1l1l11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࠨต")):
    return l1l111ll111ll1l1ll_fwb_.yesno(l1l111llll1ll1l1ll_fwb_, l1l1ll111l1ll1l1ll_fwb_, l1l1llll111ll1l1ll_fwb_, l1l1ll11ll1ll1l1ll_fwb_, l1l111l1111ll1l1ll_fwb_, l1l1l11lll1ll1l1ll_fwb_)
def l1l11llll11ll1l1ll_fwb_(list, l1l111llll1ll1l1ll_fwb_=l1l11l1111ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠨࡰࡤࡱࡪ࠭ถ"))):
    return l1l111ll111ll1l1ll_fwb_.select(l1l111llll1ll1l1ll_fwb_, list)
def l1ll1111l11ll1l1ll_fwb_():
    netloc = [urlparse.urlparse(sys.argv[0]).netloc, l1l111ll1l1ll_fwb_ (u"ࠩࠪท"), l1l111ll1l1ll_fwb_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰࡯࡭ࡻ࡫࠮ࡴࡶࡵࡩࡦࡳࡳࡱࡴࡲࠫธ"), l1l111ll1l1ll_fwb_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡴ࡭ࡹࡴࡳࡧࡤࡱࡸ࠭น"), l1l111ll1l1ll_fwb_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡨࡶࡳࡵࡴࡨࡥࡲࡹࠧบ"), l1l111ll1l1ll_fwb_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡺࡩ࡯࡭࡯ࡩࡵࡧࡤࠨป"), l1l111ll1l1ll_fwb_ (u"ࠧࡴࡥࡵ࡭ࡵࡺ࠮ࡵࡸࡪࡹ࡮ࡪࡥ࠯ࡨࡸࡰࡱࡹࡣࡳࡧࡨࡲࠬผ"), l1l111ll1l1ll_fwb_ (u"ࠨࡵࡦࡶ࡮ࡶࡴ࠯ࡶࡹ࡫ࡺ࡯ࡤࡦ࠰ࡤࡷࡸࡧࡳࡴ࡫ࡱࡷࠬฝ")]
    if not l1l111l1ll1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠩࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡖ࡬ࡶࡩ࡬ࡲࡓࡧ࡭ࡦࠩพ")) in netloc: sys.exit()
def l1ll11l1111ll1l1ll_fwb_():
    if l1l111l11l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡌࡦࡹࡁࡥࡦࡲࡲ࠭ࡹࡣࡳ࡫ࡳࡸ࠳ࡩ࡯ࡷࡧࡱࡥࡳࡺ࠮࡮ࡧࡷࡥࡩࡧࡴࡢࠫࠪฟ")):
        return os.path.join(xbmcaddon.Addon(l1l111ll1l1ll_fwb_ (u"ࠫࡸࡩࡲࡪࡲࡷ࠲ࡨࡵࡶࡦࡰࡤࡲࡹ࠴࡭ࡦࡶࡤࡨࡦࡺࡡࠨภ")).getAddonInfo(l1l111ll1l1ll_fwb_ (u"ࠬࡶࡡࡵࡪࠪม")), l1l111ll1l1ll_fwb_ (u"࠭ࡲࡦࡵࡲࡹࡷࡩࡥࡴࠩย"), l1l111ll1l1ll_fwb_ (u"ࠧࡥࡣࡷࡥࠬร"), l1l111ll1l1ll_fwb_ (u"ࠨ࡯ࡨࡸࡦ࠴ࡤࡣࠩฤ"))
def l1l1l1ll1l1ll1l1ll_fwb_(l1l11lllll1ll1l1ll_fwb_=None):
    l1ll111ll11ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"ࠩࡅࡹࡱ࡭ࡡࡳ࡫ࡤࡲࠬล"): l1l111ll1l1ll_fwb_ (u"ࠪࡦ࡬࠭ฦ"), l1l111ll1l1ll_fwb_ (u"ࠫࡈ࡮ࡩ࡯ࡧࡶࡩࠬว"): l1l111ll1l1ll_fwb_ (u"ࠬࢀࡨࠨศ"), l1l111ll1l1ll_fwb_ (u"࠭ࡃࡳࡱࡤࡸ࡮ࡧ࡮ࠨษ"): l1l111ll1l1ll_fwb_ (u"ࠧࡩࡴࠪส"), l1l111ll1l1ll_fwb_ (u"ࠨࡅࡽࡩࡨ࡮ࠧห"): l1l111ll1l1ll_fwb_ (u"ࠩࡦࡷࠬฬ"), l1l111ll1l1ll_fwb_ (u"ࠪࡈࡦࡴࡩࡴࡪࠪอ"): l1l111ll1l1ll_fwb_ (u"ࠫࡩࡧࠧฮ"), l1l111ll1l1ll_fwb_ (u"ࠬࡊࡵࡵࡥ࡫ࠫฯ"): l1l111ll1l1ll_fwb_ (u"࠭࡮࡭ࠩะ"), l1l111ll1l1ll_fwb_ (u"ࠧࡆࡰࡪࡰ࡮ࡹࡨࠨั"): l1l111ll1l1ll_fwb_ (u"ࠨࡧࡱࠫา"), l1l111ll1l1ll_fwb_ (u"ࠩࡉ࡭ࡳࡴࡩࡴࡪࠪำ"): l1l111ll1l1ll_fwb_ (u"ࠪࡪ࡮࠭ิ"), l1l111ll1l1ll_fwb_ (u"ࠫࡋࡸࡥ࡯ࡥ࡫ࠫี"): l1l111ll1l1ll_fwb_ (u"ࠬ࡬ࡲࠨึ"), l1l111ll1l1ll_fwb_ (u"࠭ࡇࡦࡴࡰࡥࡳ࠭ื"): l1l111ll1l1ll_fwb_ (u"ࠧࡥࡧุࠪ"), l1l111ll1l1ll_fwb_ (u"ࠨࡉࡵࡩࡪࡱูࠧ"): l1l111ll1l1ll_fwb_ (u"ࠩࡨࡰฺࠬ"), l1l111ll1l1ll_fwb_ (u"ࠪࡌࡪࡨࡲࡦࡹࠪ฻"): l1l111ll1l1ll_fwb_ (u"ࠫ࡭࡫ࠧ฼"), l1l111ll1l1ll_fwb_ (u"ࠬࡎࡵ࡯ࡩࡤࡶ࡮ࡧ࡮ࠨ฽"): l1l111ll1l1ll_fwb_ (u"࠭ࡨࡶࠩ฾"), l1l111ll1l1ll_fwb_ (u"ࠧࡊࡶࡤࡰ࡮ࡧ࡮ࠨ฿"): l1l111ll1l1ll_fwb_ (u"ࠨ࡫ࡷࠫเ"), l1l111ll1l1ll_fwb_ (u"ࠩࡍࡥࡵࡧ࡮ࡦࡵࡨࠫแ"): l1l111ll1l1ll_fwb_ (u"ࠪ࡮ࡦ࠭โ"), l1l111ll1l1ll_fwb_ (u"ࠫࡐࡵࡲࡦࡣࡱࠫใ"): l1l111ll1l1ll_fwb_ (u"ࠬࡱ࡯ࠨไ"), l1l111ll1l1ll_fwb_ (u"࠭ࡎࡰࡴࡺࡩ࡬࡯ࡡ࡯ࠩๅ"): l1l111ll1l1ll_fwb_ (u"ࠧ࡯ࡱࠪๆ"), l1l111ll1l1ll_fwb_ (u"ࠨࡒࡲࡰ࡮ࡹࡨࠨ็"): l1l111ll1l1ll_fwb_ (u"ࠩࡳࡰ่ࠬ"), l1l111ll1l1ll_fwb_ (u"ࠪࡔࡴࡸࡴࡶࡩࡸࡩࡸ࡫้ࠧ"): l1l111ll1l1ll_fwb_ (u"ࠫࡵࡺ๊ࠧ"), l1l111ll1l1ll_fwb_ (u"ࠬࡘ࡯࡮ࡣࡱ࡭ࡦࡴ๋ࠧ"): l1l111ll1l1ll_fwb_ (u"࠭ࡲࡰࠩ์"), l1l111ll1l1ll_fwb_ (u"ࠧࡓࡷࡶࡷ࡮ࡧ࡮ࠨํ"): l1l111ll1l1ll_fwb_ (u"ࠨࡴࡸࠫ๎"), l1l111ll1l1ll_fwb_ (u"ࠩࡖࡩࡷࡨࡩࡢࡰࠪ๏"): l1l111ll1l1ll_fwb_ (u"ࠪࡷࡷ࠭๐"), l1l111ll1l1ll_fwb_ (u"ࠫࡘࡲ࡯ࡷࡣ࡮ࠫ๑"): l1l111ll1l1ll_fwb_ (u"ࠬࡹ࡫ࠨ๒"), l1l111ll1l1ll_fwb_ (u"࠭ࡓ࡭ࡱࡹࡩࡳ࡯ࡡ࡯ࠩ๓"): l1l111ll1l1ll_fwb_ (u"ࠧࡴ࡮ࠪ๔"), l1l111ll1l1ll_fwb_ (u"ࠨࡕࡳࡥࡳ࡯ࡳࡩࠩ๕"): l1l111ll1l1ll_fwb_ (u"ࠩࡨࡷࠬ๖"), l1l111ll1l1ll_fwb_ (u"ࠪࡗࡼ࡫ࡤࡪࡵ࡫ࠫ๗"): l1l111ll1l1ll_fwb_ (u"ࠫࡸࡼࠧ๘"), l1l111ll1l1ll_fwb_ (u"࡚ࠬࡨࡢ࡫ࠪ๙"): l1l111ll1l1ll_fwb_ (u"࠭ࡴࡩࠩ๚"), l1l111ll1l1ll_fwb_ (u"ࠧࡕࡷࡵ࡯࡮ࡹࡨࠨ๛"): l1l111ll1l1ll_fwb_ (u"ࠨࡶࡵࠫ๜"), l1l111ll1l1ll_fwb_ (u"ࠩࡘ࡯ࡷࡧࡩ࡯࡫ࡤࡲࠬ๝"): l1l111ll1l1ll_fwb_ (u"ࠪࡹࡰ࠭๞")}
    l1l1l111111ll1l1ll_fwb_ = [l1l111ll1l1ll_fwb_ (u"ࠫࡧ࡭ࠧ๟"),l1l111ll1l1ll_fwb_ (u"ࠬࡩࡳࠨ๠"),l1l111ll1l1ll_fwb_ (u"࠭ࡤࡢࠩ๡"),l1l111ll1l1ll_fwb_ (u"ࠧࡥࡧࠪ๢"),l1l111ll1l1ll_fwb_ (u"ࠨࡧ࡯ࠫ๣"),l1l111ll1l1ll_fwb_ (u"ࠩࡨࡲࠬ๤"),l1l111ll1l1ll_fwb_ (u"ࠪࡩࡸ࠭๥"),l1l111ll1l1ll_fwb_ (u"ࠫ࡫࡯ࠧ๦"),l1l111ll1l1ll_fwb_ (u"ࠬ࡬ࡲࠨ๧"),l1l111ll1l1ll_fwb_ (u"࠭ࡨࡦࠩ๨"),l1l111ll1l1ll_fwb_ (u"ࠧࡩࡴࠪ๩"),l1l111ll1l1ll_fwb_ (u"ࠨࡪࡸࠫ๪"),l1l111ll1l1ll_fwb_ (u"ࠩ࡬ࡸࠬ๫"),l1l111ll1l1ll_fwb_ (u"ࠪ࡮ࡦ࠭๬"),l1l111ll1l1ll_fwb_ (u"ࠫࡰࡵࠧ๭"),l1l111ll1l1ll_fwb_ (u"ࠬࡴ࡬ࠨ๮"),l1l111ll1l1ll_fwb_ (u"࠭࡮ࡰࠩ๯"),l1l111ll1l1ll_fwb_ (u"ࠧࡱ࡮ࠪ๰"),l1l111ll1l1ll_fwb_ (u"ࠨࡲࡷࠫ๱"),l1l111ll1l1ll_fwb_ (u"ࠩࡵࡳࠬ๲"),l1l111ll1l1ll_fwb_ (u"ࠪࡶࡺ࠭๳"),l1l111ll1l1ll_fwb_ (u"ࠫࡸࡱࠧ๴"),l1l111ll1l1ll_fwb_ (u"ࠬࡹ࡬ࠨ๵"),l1l111ll1l1ll_fwb_ (u"࠭ࡳࡳࠩ๶"),l1l111ll1l1ll_fwb_ (u"ࠧࡴࡸࠪ๷"),l1l111ll1l1ll_fwb_ (u"ࠨࡶ࡫ࠫ๸"),l1l111ll1l1ll_fwb_ (u"ࠩࡷࡶࠬ๹"),l1l111ll1l1ll_fwb_ (u"ࠪࡹࡰ࠭๺"),l1l111ll1l1ll_fwb_ (u"ࠫࡿ࡮ࠧ๻")]
    l1l1ll1l111ll1l1ll_fwb_ = [l1l111ll1l1ll_fwb_ (u"ࠬ࡫࡮ࠨ๼"),l1l111ll1l1ll_fwb_ (u"࠭ࡳࡷࠩ๽"),l1l111ll1l1ll_fwb_ (u"ࠧ࡯ࡱࠪ๾"),l1l111ll1l1ll_fwb_ (u"ࠨࡦࡤࠫ๿"),l1l111ll1l1ll_fwb_ (u"ࠩࡩ࡭ࠬ຀"),l1l111ll1l1ll_fwb_ (u"ࠪࡲࡱ࠭ກ"),l1l111ll1l1ll_fwb_ (u"ࠫࡩ࡫ࠧຂ"),l1l111ll1l1ll_fwb_ (u"ࠬ࡯ࡴࠨ຃"),l1l111ll1l1ll_fwb_ (u"࠭ࡥࡴࠩຄ"),l1l111ll1l1ll_fwb_ (u"ࠧࡧࡴࠪ຅"),l1l111ll1l1ll_fwb_ (u"ࠨࡲ࡯ࠫຆ"),l1l111ll1l1ll_fwb_ (u"ࠩ࡫ࡹࠬງ"),l1l111ll1l1ll_fwb_ (u"ࠪࡩࡱ࠭ຈ"),l1l111ll1l1ll_fwb_ (u"ࠫࡹࡸࠧຉ"),l1l111ll1l1ll_fwb_ (u"ࠬࡸࡵࠨຊ"),l1l111ll1l1ll_fwb_ (u"࠭ࡨࡦࠩ຋"),l1l111ll1l1ll_fwb_ (u"ࠧ࡫ࡣࠪຌ"),l1l111ll1l1ll_fwb_ (u"ࠨࡲࡷࠫຍ"),l1l111ll1l1ll_fwb_ (u"ࠩࡽ࡬ࠬຎ"),l1l111ll1l1ll_fwb_ (u"ࠪࡧࡸ࠭ຏ"),l1l111ll1l1ll_fwb_ (u"ࠫࡸࡲࠧຐ"),l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡲࠨຑ"),l1l111ll1l1ll_fwb_ (u"࠭࡫ࡰࠩຒ")]
    l1l11l111l1ll1l1ll_fwb_ = [l1l111ll1l1ll_fwb_ (u"ࠧࡨࡸࠪຓ"), l1l111ll1l1ll_fwb_ (u"ࠨࡩࡸࠫດ"), l1l111ll1l1ll_fwb_ (u"ࠩࡪࡨࠬຕ"), l1l111ll1l1ll_fwb_ (u"ࠪ࡫ࡦ࠭ຖ"), l1l111ll1l1ll_fwb_ (u"ࠫ࡬ࡴࠧທ"), l1l111ll1l1ll_fwb_ (u"ࠬ࡭࡬ࠨຘ"), l1l111ll1l1ll_fwb_ (u"࠭ࡴࡺࠩນ"), l1l111ll1l1ll_fwb_ (u"ࠧࡵࡹࠪບ"), l1l111ll1l1ll_fwb_ (u"ࠨࡶࡷࠫປ"), l1l111ll1l1ll_fwb_ (u"ࠩࡷࡶࠬຜ"), l1l111ll1l1ll_fwb_ (u"ࠪࡸࡸ࠭ຝ"), l1l111ll1l1ll_fwb_ (u"ࠫࡹࡴࠧພ"), l1l111ll1l1ll_fwb_ (u"ࠬࡺ࡯ࠨຟ"), l1l111ll1l1ll_fwb_ (u"࠭ࡴ࡭ࠩຠ"), l1l111ll1l1ll_fwb_ (u"ࠧࡵ࡭ࠪມ"), l1l111ll1l1ll_fwb_ (u"ࠨࡶ࡫ࠫຢ"), l1l111ll1l1ll_fwb_ (u"ࠩࡷ࡭ࠬຣ"), l1l111ll1l1ll_fwb_ (u"ࠪࡸ࡬࠭຤"), l1l111ll1l1ll_fwb_ (u"ࠫࡹ࡫ࠧລ"), l1l111ll1l1ll_fwb_ (u"ࠬࡺࡡࠨ຦"), l1l111ll1l1ll_fwb_ (u"࠭ࡤࡦࠩວ"), l1l111ll1l1ll_fwb_ (u"ࠧࡥࡣࠪຨ"), l1l111ll1l1ll_fwb_ (u"ࠨࡦࡽࠫຩ"), l1l111ll1l1ll_fwb_ (u"ࠩࡧࡺࠬສ"), l1l111ll1l1ll_fwb_ (u"ࠪࡵࡺ࠭ຫ"), l1l111ll1l1ll_fwb_ (u"ࠫࡿ࡮ࠧຬ"), l1l111ll1l1ll_fwb_ (u"ࠬࢀࡡࠨອ"), l1l111ll1l1ll_fwb_ (u"࠭ࡺࡶࠩຮ"), l1l111ll1l1ll_fwb_ (u"ࠧࡸࡣࠪຯ"), l1l111ll1l1ll_fwb_ (u"ࠨࡹࡲࠫະ"), l1l111ll1l1ll_fwb_ (u"ࠩ࡭ࡺࠬັ"), l1l111ll1l1ll_fwb_ (u"ࠪ࡮ࡦ࠭າ"), l1l111ll1l1ll_fwb_ (u"ࠫࡨ࡮ࠧຳ"), l1l111ll1l1ll_fwb_ (u"ࠬࡩ࡯ࠨິ"), l1l111ll1l1ll_fwb_ (u"࠭ࡣࡢࠩີ"), l1l111ll1l1ll_fwb_ (u"ࠧࡤࡧࠪຶ"), l1l111ll1l1ll_fwb_ (u"ࠨࡥࡼࠫື"), l1l111ll1l1ll_fwb_ (u"ࠩࡦࡷຸࠬ"), l1l111ll1l1ll_fwb_ (u"ࠪࡧࡷູ࠭"), l1l111ll1l1ll_fwb_ (u"ࠫࡨࡼ຺ࠧ"), l1l111ll1l1ll_fwb_ (u"ࠬࡩࡵࠨົ"), l1l111ll1l1ll_fwb_ (u"࠭ࡰࡴࠩຼ"), l1l111ll1l1ll_fwb_ (u"ࠧࡱࡶࠪຽ"), l1l111ll1l1ll_fwb_ (u"ࠨࡲࡤࠫ຾"), l1l111ll1l1ll_fwb_ (u"ࠩࡳ࡭ࠬ຿"), l1l111ll1l1ll_fwb_ (u"ࠪࡴࡱ࠭ເ"), l1l111ll1l1ll_fwb_ (u"ࠫࡲ࡭ࠧແ"), l1l111ll1l1ll_fwb_ (u"ࠬࡳ࡬ࠨໂ"), l1l111ll1l1ll_fwb_ (u"࠭࡭࡯ࠩໃ"), l1l111ll1l1ll_fwb_ (u"ࠧ࡮࡫ࠪໄ"), l1l111ll1l1ll_fwb_ (u"ࠨ࡯࡫ࠫ໅"), l1l111ll1l1ll_fwb_ (u"ࠩࡰ࡯ࠬໆ"), l1l111ll1l1ll_fwb_ (u"ࠪࡱࡹ࠭໇"), l1l111ll1l1ll_fwb_ (u"ࠫࡲࡹ່ࠧ"), l1l111ll1l1ll_fwb_ (u"ࠬࡳࡲࠨ້"), l1l111ll1l1ll_fwb_ (u"࠭࡭ࡺ໊ࠩ"), l1l111ll1l1ll_fwb_ (u"ࠧࡷࡧ໋ࠪ"), l1l111ll1l1ll_fwb_ (u"ࠨࡸ࡬ࠫ໌"), l1l111ll1l1ll_fwb_ (u"ࠩ࡬ࡷࠬໍ"), l1l111ll1l1ll_fwb_ (u"ࠪ࡭ࡺ࠭໎"), l1l111ll1l1ll_fwb_ (u"ࠫ࡮ࡺࠧ໏"), l1l111ll1l1ll_fwb_ (u"ࠬࡼ࡯ࠨ໐"), l1l111ll1l1ll_fwb_ (u"࠭ࡩࡪࠩ໑"), l1l111ll1l1ll_fwb_ (u"ࠧࡪ࡭ࠪ໒"), l1l111ll1l1ll_fwb_ (u"ࠨ࡫ࡲࠫ໓"), l1l111ll1l1ll_fwb_ (u"ࠩ࡬ࡥࠬ໔"), l1l111ll1l1ll_fwb_ (u"ࠪ࡭ࡪ࠭໕"), l1l111ll1l1ll_fwb_ (u"ࠫ࡮ࡪࠧ໖"), l1l111ll1l1ll_fwb_ (u"ࠬ࡯ࡧࠨ໗"), l1l111ll1l1ll_fwb_ (u"࠭ࡦࡳࠩ໘"), l1l111ll1l1ll_fwb_ (u"ࠧࡧࡻࠪ໙"), l1l111ll1l1ll_fwb_ (u"ࠨࡨࡤࠫ໚"), l1l111ll1l1ll_fwb_ (u"ࠩࡩࡪࠬ໛"), l1l111ll1l1ll_fwb_ (u"ࠪࡪ࡮࠭ໜ"), l1l111ll1l1ll_fwb_ (u"ࠫ࡫ࡰࠧໝ"), l1l111ll1l1ll_fwb_ (u"ࠬ࡬࡯ࠨໞ"), l1l111ll1l1ll_fwb_ (u"࠭ࡳࡴࠩໟ"), l1l111ll1l1ll_fwb_ (u"ࠧࡴࡴࠪ໠"), l1l111ll1l1ll_fwb_ (u"ࠨࡵࡴࠫ໡"), l1l111ll1l1ll_fwb_ (u"ࠩࡶࡻࠬ໢"), l1l111ll1l1ll_fwb_ (u"ࠪࡷࡻ࠭໣"), l1l111ll1l1ll_fwb_ (u"ࠫࡸࡻࠧ໤"), l1l111ll1l1ll_fwb_ (u"ࠬࡹࡴࠨ໥"), l1l111ll1l1ll_fwb_ (u"࠭ࡳ࡬ࠩ໦"), l1l111ll1l1ll_fwb_ (u"ࠧࡴ࡫ࠪ໧"), l1l111ll1l1ll_fwb_ (u"ࠨࡵࡲࠫ໨"), l1l111ll1l1ll_fwb_ (u"ࠩࡶࡲࠬ໩"), l1l111ll1l1ll_fwb_ (u"ࠪࡷࡲ࠭໪"), l1l111ll1l1ll_fwb_ (u"ࠫࡸࡲࠧ໫"), l1l111ll1l1ll_fwb_ (u"ࠬࡹࡣࠨ໬"), l1l111ll1l1ll_fwb_ (u"࠭ࡳࡢࠩ໭"), l1l111ll1l1ll_fwb_ (u"ࠧࡴࡩࠪ໮"), l1l111ll1l1ll_fwb_ (u"ࠨࡵࡨࠫ໯"), l1l111ll1l1ll_fwb_ (u"ࠩࡶࡨࠬ໰"), l1l111ll1l1ll_fwb_ (u"ࠪࡰ࡬࠭໱"), l1l111ll1l1ll_fwb_ (u"ࠫࡱࡨࠧ໲"), l1l111ll1l1ll_fwb_ (u"ࠬࡲࡡࠨ໳"), l1l111ll1l1ll_fwb_ (u"࠭࡬࡯ࠩ໴"), l1l111ll1l1ll_fwb_ (u"ࠧ࡭ࡱࠪ໵"), l1l111ll1l1ll_fwb_ (u"ࠨ࡮࡬ࠫ໶"), l1l111ll1l1ll_fwb_ (u"ࠩ࡯ࡺࠬ໷"), l1l111ll1l1ll_fwb_ (u"ࠪࡰࡹ࠭໸"), l1l111ll1l1ll_fwb_ (u"ࠫࡱࡻࠧ໹"), l1l111ll1l1ll_fwb_ (u"ࠬࡿࡩࠨ໺"), l1l111ll1l1ll_fwb_ (u"࠭ࡹࡰࠩ໻"), l1l111ll1l1ll_fwb_ (u"ࠧࡦ࡮ࠪ໼"), l1l111ll1l1ll_fwb_ (u"ࠨࡧࡲࠫ໽"), l1l111ll1l1ll_fwb_ (u"ࠩࡨࡲࠬ໾"), l1l111ll1l1ll_fwb_ (u"ࠪࡩࡪ࠭໿"), l1l111ll1l1ll_fwb_ (u"ࠫࡪࡻࠧༀ"), l1l111ll1l1ll_fwb_ (u"ࠬ࡫ࡴࠨ༁"), l1l111ll1l1ll_fwb_ (u"࠭ࡥࡴࠩ༂"), l1l111ll1l1ll_fwb_ (u"ࠧࡳࡷࠪ༃"), l1l111ll1l1ll_fwb_ (u"ࠨࡴࡺࠫ༄"), l1l111ll1l1ll_fwb_ (u"ࠩࡵࡱࠬ༅"), l1l111ll1l1ll_fwb_ (u"ࠪࡶࡳ࠭༆"), l1l111ll1l1ll_fwb_ (u"ࠫࡷࡵࠧ༇"), l1l111ll1l1ll_fwb_ (u"ࠬࡨࡥࠨ༈"), l1l111ll1l1ll_fwb_ (u"࠭ࡢࡨࠩ༉"), l1l111ll1l1ll_fwb_ (u"ࠧࡣࡣࠪ༊"), l1l111ll1l1ll_fwb_ (u"ࠨࡤࡰࠫ་"), l1l111ll1l1ll_fwb_ (u"ࠩࡥࡲࠬ༌"), l1l111ll1l1ll_fwb_ (u"ࠪࡦࡴ࠭།"), l1l111ll1l1ll_fwb_ (u"ࠫࡧ࡮ࠧ༎"), l1l111ll1l1ll_fwb_ (u"ࠬࡨࡩࠨ༏"), l1l111ll1l1ll_fwb_ (u"࠭ࡢࡳࠩ༐"), l1l111ll1l1ll_fwb_ (u"ࠧࡣࡵࠪ༑"), l1l111ll1l1ll_fwb_ (u"ࠨࡱࡰࠫ༒"), l1l111ll1l1ll_fwb_ (u"ࠩࡲ࡮ࠬ༓"), l1l111ll1l1ll_fwb_ (u"ࠪࡳࡨ࠭༔"), l1l111ll1l1ll_fwb_ (u"ࠫࡴࡹࠧ༕"), l1l111ll1l1ll_fwb_ (u"ࠬࡵࡲࠨ༖"), l1l111ll1l1ll_fwb_ (u"࠭ࡸࡩࠩ༗"), l1l111ll1l1ll_fwb_ (u"ࠧࡩࡼ༘ࠪ"), l1l111ll1l1ll_fwb_ (u"ࠨࡪࡼ༙ࠫ"), l1l111ll1l1ll_fwb_ (u"ࠩ࡫ࡶࠬ༚"), l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡹ࠭༛"), l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡻࠧ༜"), l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡩࠨ༝"), l1l111ll1l1ll_fwb_ (u"࠭ࡨࡰࠩ༞"), l1l111ll1l1ll_fwb_ (u"ࠧࡩࡣࠪ༟"), l1l111ll1l1ll_fwb_ (u"ࠨࡪࡨࠫ༠"), l1l111ll1l1ll_fwb_ (u"ࠩࡸࡾࠬ༡"), l1l111ll1l1ll_fwb_ (u"ࠪࡹࡷ࠭༢"), l1l111ll1l1ll_fwb_ (u"ࠫࡺࡱࠧ༣"), l1l111ll1l1ll_fwb_ (u"ࠬࡻࡧࠨ༤"), l1l111ll1l1ll_fwb_ (u"࠭ࡡࡢࠩ༥"), l1l111ll1l1ll_fwb_ (u"ࠧࡢࡤࠪ༦"), l1l111ll1l1ll_fwb_ (u"ࠨࡣࡨࠫ༧"), l1l111ll1l1ll_fwb_ (u"ࠩࡤࡪࠬ༨"), l1l111ll1l1ll_fwb_ (u"ࠪࡥࡰ࠭༩"), l1l111ll1l1ll_fwb_ (u"ࠫࡦࡳࠧ༪"), l1l111ll1l1ll_fwb_ (u"ࠬࡧ࡮ࠨ༫"), l1l111ll1l1ll_fwb_ (u"࠭ࡡࡴࠩ༬"), l1l111ll1l1ll_fwb_ (u"ࠧࡢࡴࠪ༭"), l1l111ll1l1ll_fwb_ (u"ࠨࡣࡹࠫ༮"), l1l111ll1l1ll_fwb_ (u"ࠩࡤࡽࠬ༯"), l1l111ll1l1ll_fwb_ (u"ࠪࡥࡿ࠭༰"), l1l111ll1l1ll_fwb_ (u"ࠫࡳࡲࠧ༱"), l1l111ll1l1ll_fwb_ (u"ࠬࡴ࡮ࠨ༲"), l1l111ll1l1ll_fwb_ (u"࠭࡮ࡰࠩ༳"), l1l111ll1l1ll_fwb_ (u"ࠧ࡯ࡣࠪ༴"), l1l111ll1l1ll_fwb_ (u"ࠨࡰࡥ༵ࠫ"), l1l111ll1l1ll_fwb_ (u"ࠩࡱࡨࠬ༶"), l1l111ll1l1ll_fwb_ (u"ࠪࡲࡪ༷࠭"), l1l111ll1l1ll_fwb_ (u"ࠫࡳ࡭ࠧ༸"), l1l111ll1l1ll_fwb_ (u"ࠬࡴࡹࠨ༹"), l1l111ll1l1ll_fwb_ (u"࠭࡮ࡳࠩ༺"), l1l111ll1l1ll_fwb_ (u"ࠧ࡯ࡸࠪ༻"), l1l111ll1l1ll_fwb_ (u"ࠨ࡭ࡤࠫ༼"), l1l111ll1l1ll_fwb_ (u"ࠩ࡮࡫ࠬ༽"), l1l111ll1l1ll_fwb_ (u"ࠪ࡯ࡰ࠭༾"), l1l111ll1l1ll_fwb_ (u"ࠫࡰࡰࠧ༿"), l1l111ll1l1ll_fwb_ (u"ࠬࡱࡩࠨཀ"), l1l111ll1l1ll_fwb_ (u"࠭࡫ࡰࠩཁ"), l1l111ll1l1ll_fwb_ (u"ࠧ࡬ࡰࠪག"), l1l111ll1l1ll_fwb_ (u"ࠨ࡭ࡰࠫགྷ"), l1l111ll1l1ll_fwb_ (u"ࠩ࡮ࡰࠬང"), l1l111ll1l1ll_fwb_ (u"ࠪ࡯ࡸ࠭ཅ"), l1l111ll1l1ll_fwb_ (u"ࠫࡰࡸࠧཆ"), l1l111ll1l1ll_fwb_ (u"ࠬࡱࡷࠨཇ"), l1l111ll1l1ll_fwb_ (u"࠭࡫ࡷࠩ཈"), l1l111ll1l1ll_fwb_ (u"ࠧ࡬ࡷࠪཉ"), l1l111ll1l1ll_fwb_ (u"ࠨ࡭ࡼࠫཊ")]
    name = None
    name = l1l1l1lll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠩࡤࡴ࡮࠴࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨཋ"))
    if not name: name = l1l111ll1l1ll_fwb_ (u"ࠪࡅ࡚࡚ࡏࠨཌ")
    if name[-1].isupper():
        try: name = xbmc.l1l111l1l11ll1l1ll_fwb_(xbmc.l1l1l1ll111ll1l1ll_fwb_).split(l1l111ll1l1ll_fwb_ (u"ࠫࠥ࠭ཌྷ"))[0]
        except: pass
    try: name = l1ll111ll11ll1l1ll_fwb_[name]
    except: name = l1l111ll1l1ll_fwb_ (u"ࠬ࡫࡮ࠨཎ")
    l1ll11l1l11ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"࠭ࡴࡳࡣ࡮ࡸࠬཏ"): name} if name in l1l1l111111ll1l1ll_fwb_ else {l1l111ll1l1ll_fwb_ (u"ࠧࡵࡴࡤ࡯ࡹ࠭ཐ"): l1l111ll1l1ll_fwb_ (u"ࠨࡧࡱࠫད")}
    l1ll11l1l11ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡷࡺࡩࡨࠧདྷ")] = name if name in l1l1ll1l111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠪࡩࡳ࠭ན")
    l1ll11l1l11ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬཔ")] = name if name in l1l11l111l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠬ࡫࡮ࠨཕ")
    if l1l11lllll1ll1l1ll_fwb_:
        l1ll11l1l11ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡴࡳࡣ࡮ࡸࠬབ")] = [i[0] for i in l1ll111ll11ll1l1ll_fwb_.iteritems() if i[1] == l1ll11l1l11ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡵࡴࡤ࡯ࡹ࠭བྷ")]][0]
        l1ll11l1l11ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡶࡹࡨࡧ࠭མ")] = [i[0] for i in l1ll111ll11ll1l1ll_fwb_.iteritems() if i[1] == l1ll11l1l11ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡷࡺࡩࡨࠧཙ")]][0]
        l1ll11l1l11ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨࠫཚ")] = [i[0] for i in l1ll111ll11ll1l1ll_fwb_.iteritems() if i[1] == l1ll11l1l11ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬཛ")]][0]
    return l1ll11l1l11ll1l1ll_fwb_
def version():
    num = l1l111ll1l1ll_fwb_ (u"ࠬ࠭ཛྷ")
    try: version = l111l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"࠭ࡸࡣ࡯ࡦ࠲ࡦࡪࡤࡰࡰࠪཝ")).getAddonInfo(l1l111ll1l1ll_fwb_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨཞ"))
    except: version = l1l111ll1l1ll_fwb_ (u"ࠨ࠻࠼࠽ࠬཟ")
    for i in version:
        if i.isdigit(): num += i
        else: break
    return int(num)
def openSettings(query=None, id=l1l11l1111ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠩ࡬ࡨࠬའ"))):
    try:
        l1l1l1l1l11ll1l1ll_fwb_()
        l1l11l1lll1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠪࡅࡩࡪ࡯࡯࠰ࡒࡴࡪࡴࡓࡦࡶࡷ࡭ࡳ࡭ࡳࠩࠧࡶ࠭ࠬཡ") % id)
        if query == None: raise Exception()
        c, f = query.split(l1l111ll1l1ll_fwb_ (u"ࠫ࠳࠭ར"))
        l1l11l1lll1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"࡙ࠬࡥࡵࡈࡲࡧࡺࡹࠨࠦ࡫ࠬࠫལ") % (int(c) + 100))
        l1l11l1lll1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"࠭ࡓࡦࡶࡉࡳࡨࡻࡳࠩࠧ࡬࠭ࠬཤ") % (int(f) + 200))
    except:
        return
def l1ll11l1ll1ll1l1ll_fwb_():
    return l1l11l1lll1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠧࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫཥ"))
def l1l1ll1lll1ll1l1ll_fwb_():
    return l1l11l1lll1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠨࡃࡦࡸ࡮ࡼࡡࡵࡧ࡚࡭ࡳࡪ࡯ࡸࠪࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬࠯ࠧས"))
def l1l1l1l1l11ll1l1ll_fwb_():
    return l1l11l1lll1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠩࡇ࡭ࡦࡲ࡯ࡨ࠰ࡆࡰࡴࡹࡥࠩࡤࡸࡷࡾࡪࡩࡢ࡮ࡲ࡫࠮࠭ཧ"))
def l1l1ll11111ll1l1ll_fwb_():
    return l1l11l1lll1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠪࡅࡨࡺࡩࡰࡰࠫࡕࡺ࡫ࡵࡦࠫࠪཨ"))
