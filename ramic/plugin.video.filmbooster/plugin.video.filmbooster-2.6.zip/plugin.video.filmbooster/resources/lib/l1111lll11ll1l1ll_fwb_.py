# coding: UTF-8
import sys
l1ll11ll1l1ll_fwb_ = sys.version_info [0] == 2
l1111ll1l1ll_fwb_ = 2048
l1l1l1ll1l1ll_fwb_ = 7
def l1l111ll1l1ll_fwb_ (keyedStringLiteral):
	global l11ll1ll1l1ll_fwb_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll1l1ll_fwb_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urlparse,cookielib,urllib2,urllib
import time,re,os
url=l1l111ll1l1ll_fwb_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤࡦࡤࡼ࠳ࡺࡶ࠰ࠩඏ")
l11l11l1l1ll1l1ll_fwb_= cookielib.LWPCookieJar()
l1llll1ll11ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ඐ")
l1lll1llll1ll1l1ll_fwb_=l1llll1ll11ll1l1ll_fwb_
def l111lll111ll1l1ll_fwb_(url,l11l11l1l1ll1l1ll_fwb_=l11l11l1l1ll1l1ll_fwb_,l1lll1llll1ll1l1ll_fwb_=l1llll1ll11ll1l1ll_fwb_):
    l1llll111l1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠨࠩඑ")
    try:
        class l1lll1ll111ll1l1ll_fwb_(urllib2.HTTPErrorProcessor):
            def http_response(self, request, response):
                return response
        def l1lll1l1l11ll1l1ll_fwb_(s):
            try:
                offset=1 if s[0]==l1l111ll1l1ll_fwb_ (u"ࠩ࠮ࠫඒ") else 0
                val = int(eval(s.replace(l1l111ll1l1ll_fwb_ (u"ࠪࠥ࠰ࡡ࡝ࠨඓ"),l1l111ll1l1ll_fwb_ (u"ࠫ࠶࠭ඔ")).replace(l1l111ll1l1ll_fwb_ (u"ࠬࠧࠡ࡜࡟ࠪඕ"),l1l111ll1l1ll_fwb_ (u"࠭࠱ࠨඖ")).replace(l1l111ll1l1ll_fwb_ (u"ࠧ࡜࡟ࠪ඗"),l1l111ll1l1ll_fwb_ (u"ࠨ࠲ࠪ඘")).replace(l1l111ll1l1ll_fwb_ (u"ࠩࠫࠫ඙"),l1l111ll1l1ll_fwb_ (u"ࠪࡷࡹࡸࠨࠨක"))[offset:]))
                return val
            except:
                pass
        if l11l11l1l1ll1l1ll_fwb_==None:
            l11l11l1l1ll1l1ll_fwb_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(l1lll1ll111ll1l1ll_fwb_, urllib2.HTTPCookieProcessor(l11l11l1l1ll1l1ll_fwb_))
        opener.addheaders = [(l1l111ll1l1ll_fwb_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨඛ"), l1lll1llll1ll1l1ll_fwb_)]
        try:
            response = opener.open(url)
            result=l1llll111l1ll1l1ll_fwb_ = response.read()
            response.close()
        except urllib2.HTTPError as e:
            result=l1llll111l1ll1l1ll_fwb_ = e.read()
        time.sleep(1)
        try:
            response = opener.open(url+l1l111ll1l1ll_fwb_ (u"ࠬࡳ࡯ࡥࡧࡵ࠲࡭ࡺ࡭࡭ࠩග"))
            result=l1llll111l1ll1l1ll_fwb_ = response.read()
            response.close()
        except urllib2.HTTPError as e:
            result=l1llll111l1ll1l1ll_fwb_ = e.read()
        l1llll11l11ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"࠭࡮ࡢ࡯ࡨࡁࠧࡰࡳࡤࡪ࡯ࡣࡻࡩࠢࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠯ࡄ࠯ࠢ࠰ࡀࠪඝ")).findall(result)[0]
        init = re.compile(l1l111ll1l1ll_fwb_ (u"ࠧࡴࡧࡷࡘ࡮ࡳࡥࡰࡷࡷࡠ࠭࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡜ࠩ࡞ࠬࡿࡡࡹࠪ࠯ࠬࡂ࠲࠯ࡀࠨ࠯ࠬࡂ࠭ࢂࡁࠧඞ")).findall(result)[0]
        l1llll11ll1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࡳࠤࡦ࡬ࡦࡲ࡬ࡦࡰࡪࡩ࠲࡬࡯ࡳ࡯࡟ࠫࡡ࠯࠻࡝ࡵ࠭ࠬ࠳࠰ࠩࡢ࠰ࡹࠦඟ")).findall(result)[0]
        l1llll11111ll1l1ll_fwb_ = l1lll1l1l11ll1l1ll_fwb_(init)
        lines = l1llll11ll1ll1l1ll_fwb_.split(l1l111ll1l1ll_fwb_ (u"ࠩ࠾ࠫච"))
        if l1llll11l11ll1l1ll_fwb_:
            for line in lines:
                if len(line)>0 and l1l111ll1l1ll_fwb_ (u"ࠪࡁࠬඡ") in line:
                    l1lll1l11l1ll1l1ll_fwb_=line.split(l1l111ll1l1ll_fwb_ (u"ࠫࡂ࠭ජ"))
                    l1lll1l1111ll1l1ll_fwb_ = l1lll1l1l11ll1l1ll_fwb_(l1lll1l11l1ll1l1ll_fwb_[1])
                    l1llll11111ll1l1ll_fwb_ = int(eval(str(l1llll11111ll1l1ll_fwb_)+l1lll1l11l1ll1l1ll_fwb_[0][-1]+str(l1lll1l1111ll1l1ll_fwb_)))
            l1lll1l1ll1ll1l1ll_fwb_ = l1llll11111ll1l1ll_fwb_ + len(urlparse.urlparse(url).netloc)
            u=l1l111ll1l1ll_fwb_ (u"ࠬ࠵ࠧඣ").join(url.split(l1l111ll1l1ll_fwb_ (u"࠭࠯ࠨඤ"))[:-1])
            query = l1l111ll1l1ll_fwb_ (u"ࠧࠦࡵ࠲ࡧࡩࡴ࠭ࡤࡩ࡬࠳ࡱ࠵ࡣࡩ࡭ࡢ࡮ࡸࡩࡨ࡭ࡁ࡭ࡷࡨ࡮࡬ࡠࡸࡦࡁࠪࡹࠦ࡫ࡵࡦ࡬ࡱࡥࡡ࡯ࡵࡺࡩࡷࡃࠥࡴࠩඥ") % (u, l1llll11l11ll1l1ll_fwb_, l1lll1l1ll1ll1l1ll_fwb_)
            if l1l111ll1l1ll_fwb_ (u"ࠨࡶࡼࡴࡪࡃࠢࡩ࡫ࡧࡨࡪࡴࠢࠡࡰࡤࡱࡪࡃࠢࡱࡣࡶࡷࠧ࠭ඦ") in result:
                l1lll1lll11ll1l1ll_fwb_=re.compile(l1l111ll1l1ll_fwb_ (u"ࠩࡱࡥࡲ࡫࠽ࠣࡲࡤࡷࡸࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧට")).findall(result)[0]
                query = l1l111ll1l1ll_fwb_ (u"ࠪࠩࡸ࠵ࡣࡥࡰ࠰ࡧ࡬࡯࠯࡭࠱ࡦ࡬ࡰࡥࡪࡴࡥ࡫ࡰࡄࡶࡡࡴࡵࡀࠩࡸࠬࡪࡴࡥ࡫ࡰࡤࡼࡣ࠾ࠧࡶࠪ࡯ࡹࡣࡩ࡮ࡢࡥࡳࡹࡷࡦࡴࡀࠩࡸ࠭ඨ") % (u,urllib.quote_plus(l1lll1lll11ll1l1ll_fwb_), l1llll11l11ll1l1ll_fwb_, l1lll1l1ll1ll1l1ll_fwb_)
                time.sleep(5)
            l11111l111ll1l1ll_fwb_ =l1l111ll1l1ll_fwb_ (u"ࠫࠬඩ").join([l1l111ll1l1ll_fwb_ (u"ࠬࠫࡳ࠾ࠧࡶ࠿ࠬඪ")%(c.name, c.value) for c in l11l11l1l1ll1l1ll_fwb_])
            opener = urllib2.build_opener(l1lll1ll111ll1l1ll_fwb_,urllib2.HTTPCookieProcessor(l11l11l1l1ll1l1ll_fwb_))
            opener.addheaders = [(l1l111ll1l1ll_fwb_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪණ"), l1lll1llll1ll1l1ll_fwb_,l1l111ll1l1ll_fwb_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨඬ"),url)]
            opener.addheaders.append((l1l111ll1l1ll_fwb_ (u"ࠨࡥࡲࡳࡰ࡯ࡥࠨත"),l11111l111ll1l1ll_fwb_))
            try:
                response = opener.open(query)
                response.close()
            except urllib2.HTTPError as e:
                response = e.read()
        return l11l11l1l1ll1l1ll_fwb_
    except:
        return None
def l1lllllll11ll1l1ll_fwb_(l111111l11ll1l1ll_fwb_):
    l1lll1ll1l1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠩࠪථ")
    if os.path.isfile(l111111l11ll1l1ll_fwb_):
        l11l11l1l1ll1l1ll_fwb_ = cookielib.LWPCookieJar()
        l11l11l1l1ll1l1ll_fwb_.load(l111111l11ll1l1ll_fwb_)
        for c in l11l11l1l1ll1l1ll_fwb_:
            l1lll1ll1l1ll1l1ll_fwb_+=l1l111ll1l1ll_fwb_ (u"ࠪࠩࡸࡃࠥࡴ࠽ࠪද")%(c.name, c.value)
    return l1lll1ll1l1ll1l1ll_fwb_
