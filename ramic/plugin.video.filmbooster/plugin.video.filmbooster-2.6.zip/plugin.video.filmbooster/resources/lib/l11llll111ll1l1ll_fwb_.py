# coding: UTF-8
import sys
l1ll11ll1l1ll_fwb_ = sys.version_info [0] == 2
l1111ll1l1ll_fwb_ = 2048
l1l1l1ll1l1ll_fwb_ = 7
def l1l111ll1l1ll_fwb_ (keyedStringLiteral):
	global l11ll1ll1l1ll_fwb_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll1l1ll_fwb_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
l1l111ll1l1ll_fwb_ (u"ࠨࠢࠣࠌࠣࠤࠥࠦࡵࡳ࡮ࡵࡩࡸࡵ࡬ࡷࡧࡵࠤ࡝ࡈࡍࡄࠢࡄࡨࡩࡵ࡮ࠋࠢࠣࠤࠥࡉ࡯ࡱࡻࡵ࡭࡬࡮ࡴࠡࠪࡆ࠭ࠥ࠸࠰࠲࠵ࠣࡆࡸࡺࡲࡥࡵࡰ࡯ࡷࠐࠠࠡࠌࠣࠤࠥࠦࡔࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥ࡯ࡳࠡࡨࡵࡩࡪࠦࡳࡰࡨࡷࡻࡦࡸࡥ࠻ࠢࡼࡳࡺࠦࡣࡢࡰࠣࡶࡪࡪࡩࡴࡶࡵ࡭ࡧࡻࡴࡦࠢ࡬ࡸࠥࡧ࡮ࡥ࠱ࡲࡶࠥࡳ࡯ࡥ࡫ࡩࡽࠏࠦࠠࠡࠢ࡬ࡸࠥࡻ࡮ࡥࡧࡵࠤࡹ࡮ࡥࠡࡶࡨࡶࡲࡹࠠࡰࡨࠣࡸ࡭࡫ࠠࡈࡐࡘࠤࡌ࡫࡮ࡦࡴࡤࡰࠥࡖࡵࡣ࡮࡬ࡧࠥࡒࡩࡤࡧࡱࡷࡪࠦࡡࡴࠢࡳࡹࡧࡲࡩࡴࡪࡨࡨࠥࡨࡹࠋࠢࠣࠤࠥࡺࡨࡦࠢࡉࡶࡪ࡫ࠠࡔࡱࡩࡸࡼࡧࡲࡦࠢࡉࡳࡺࡴࡤࡢࡶ࡬ࡳࡳ࠲ࠠࡦ࡫ࡷ࡬ࡪࡸࠠࡷࡧࡵࡷ࡮ࡵ࡮ࠡ࠵ࠣࡳ࡫ࠦࡴࡩࡧࠣࡐ࡮ࡩࡥ࡯ࡵࡨ࠰ࠥࡵࡲࠋࠢࠣࠤࠥ࠮ࡡࡵࠢࡼࡳࡺࡸࠠࡰࡲࡷ࡭ࡴࡴࠩࠡࡣࡱࡽࠥࡲࡡࡵࡧࡵࠤࡻ࡫ࡲࡴ࡫ࡲࡲ࠳ࠐࠠࠡࠌࠣࠤࠥࠦࡔࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥ࡯ࡳࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷࡩࡩࠦࡩ࡯ࠢࡷ࡬ࡪࠦࡨࡰࡲࡨࠤࡹ࡮ࡡࡵࠢ࡬ࡸࠥࡽࡩ࡭࡮ࠣࡦࡪࠦࡵࡴࡧࡩࡹࡱ࠲ࠊࠡࠢࠣࠤࡧࡻࡴ࡙ࠡࡌࡘࡍࡕࡕࡕࠢࡄࡒ࡞ࠦࡗࡂࡔࡕࡅࡓ࡚࡙࠼ࠢࡺ࡭ࡹ࡮࡯ࡶࡶࠣࡩࡻ࡫࡮ࠡࡶ࡫ࡩࠥ࡯࡭ࡱ࡮࡬ࡩࡩࠦࡷࡢࡴࡵࡥࡳࡺࡹࠡࡱࡩࠎࠥࠦࠠࠡࡏࡈࡖࡈࡎࡁࡏࡖࡄࡆࡎࡒࡉࡕ࡛ࠣࡳࡷࠦࡆࡊࡖࡑࡉࡘ࡙ࠠࡇࡑࡕࠤࡆࠦࡐࡂࡔࡗࡍࡈ࡛ࡌࡂࡔࠣࡔ࡚ࡘࡐࡐࡕࡈ࠲ࠥࠦࡓࡦࡧࠣࡸ࡭࡫ࠊࠡࠢࠣࠤࡌࡔࡕࠡࡉࡨࡲࡪࡸࡡ࡭ࠢࡓࡹࡧࡲࡩࡤࠢࡏ࡭ࡨ࡫࡮ࡴࡧࠣࡪࡴࡸࠠ࡮ࡱࡵࡩࠥࡪࡥࡵࡣ࡬ࡰࡸ࠴ࠊࠡࠢࠍࠤ࡚ࠥࠦࠠࡱࡸࠤࡸ࡮࡯ࡶ࡮ࡧࠤ࡭ࡧࡶࡦࠢࡵࡩࡨ࡫ࡩࡷࡧࡧࠤࡦࠦࡣࡰࡲࡼࠤࡴ࡬ࠠࡵࡪࡨࠤࡌࡔࡕࠡࡉࡨࡲࡪࡸࡡ࡭ࠢࡓࡹࡧࡲࡩࡤࠢࡏ࡭ࡨ࡫࡮ࡴࡧࠍࠤࠥࠦࠠࡢ࡮ࡲࡲ࡬ࠦࡷࡪࡶ࡫ࠤࡹ࡮ࡩࡴࠢࡳࡶࡴ࡭ࡲࡢ࡯࠱ࠤࠥࡏࡦࠡࡰࡲࡸ࠱ࠦࡳࡦࡧࠣࡀ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡩࡱࡹ࠳ࡵࡲࡨ࠱࡯࡭ࡨ࡫࡮ࡴࡧࡶ࠳ࡃ࠴ࠊࠡࠢࠍࠤࠥࠦࠠࡂࡦࡤࡴࡹ࡫ࡤࠡࡨࡲࡶࠥࡻࡳࡦࠢ࡬ࡲࠥࡾࡢ࡮ࡥࠣࡪࡷࡵ࡭࠻ࠌࠣࠤࠥࠦࡨࡵࡶࡳࡷ࠿࠵࠯ࡨ࡫ࡷ࡬ࡺࡨ࠮ࡤࡱࡰ࠳ࡪ࡯࡮ࡢࡴࡶ࠳࡯ࡹ࠭ࡣࡧࡤࡹࡹ࡯ࡦࡺ࠱ࡥࡰࡴࡨ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡱࡻࡷ࡬ࡴࡴ࠯࡫ࡵࡥࡩࡦࡻࡴࡪࡨ࡬ࡩࡷ࠵ࡵ࡯ࡲࡤࡧࡰ࡫ࡲࡴ࠱ࡳࡥࡨࡱࡥࡳ࠰ࡳࡽࠏࠦࠠࠋࠢࠣࠤࠥࡻࡳࡢࡩࡨ࠾ࠏࠦࠠࠋࠢࠣࠤࠥ࡯ࡦࠡࡦࡨࡸࡪࡩࡴࠩࡵࡲࡱࡪࡥࡳࡵࡴ࡬ࡲ࡬࠯࠺ࠋࠢࠣࠤࠥࠦࠠࠡࠢࡸࡲࡵࡧࡣ࡬ࡧࡧࠤࡂࠦࡵ࡯ࡲࡤࡧࡰ࠮ࡳࡰ࡯ࡨࡣࡸࡺࡲࡪࡰࡪ࠭ࠏࠦࠠࠋࠢࠣࠎ࡚ࡴࡰࡢࡥ࡮ࡩࡷࠦࡦࡰࡴࠣࡈࡪࡧ࡮ࠡࡇࡧࡻࡦࡸࡤࠨࡵࠣࡴ࠳ࡧ࠮ࡤ࠰࡮࠲ࡪ࠴ࡲࠋࠤࠥࠦᎽ")
import re
import string
def l1111lllll1ll1l1ll_fwb_(source):
    l1l111ll1l1ll_fwb_ (u"ࠢࠣࠤࡇࡩࡹ࡫ࡣࡵࡵࠣࡻ࡭࡫ࡴࡩࡧࡵࠤࡥࡹ࡯ࡶࡴࡦࡩࡥࠦࡩࡴࠢࡓ࠲ࡆ࠴ࡃ࠯ࡍ࠱ࡉ࠳ࡘ࠮ࠡࡥࡲࡨࡪࡪ࠮ࠣࠤࠥᎾ")
    source = source.replace(l1l111ll1l1ll_fwb_ (u"ࠨࠢࠪᎿ"),l1l111ll1l1ll_fwb_ (u"ࠩࠪᏀ"))
    if re.search(l1l111ll1l1ll_fwb_ (u"ࠪࡩࡻࡧ࡬ࠩࡨࡸࡲࡨࡺࡩࡰࡰࠫࡴ࠱ࡧࠬࡤ࠮࡮࠰ࡪ࠲ࠨࡀ࠼ࡵࢀࡩ࠯ࠧᏁ"),source): return True
    else: return False
def unpack(source):
    l1l111ll1l1ll_fwb_ (u"ࠦࠧࠨࡕ࡯ࡲࡤࡧࡰࡹࠠࡑ࠰ࡄ࠲ࡈ࠴ࡋ࠯ࡇ࠱ࡖ࠳ࠦࡰࡢࡥ࡮ࡩࡩࠦࡪࡴࠢࡦࡳࡩ࡫࠮ࠣࠤࠥᏂ")
    l1111ll1l11ll1l1ll_fwb_, l111l11l111ll1l1ll_fwb_, l111l1l1l11ll1l1ll_fwb_, count = _111l1l1111ll1l1ll_fwb_(source)
    if count != len(l111l11l111ll1l1ll_fwb_):
        raise l111l111111ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠬࡓࡡ࡭ࡨࡲࡶࡲ࡫ࡤࠡࡲ࠱ࡥ࠳ࡩ࠮࡬࠰ࡨ࠲ࡷ࠴ࠠࡴࡻࡰࡸࡦࡨ࠮ࠨᏃ"))
    try:
        unbase = l111l11l1l1ll1l1ll_fwb_(l111l1l1l11ll1l1ll_fwb_)
    except TypeError:
        raise l111l111111ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"࠭ࡕ࡯࡭ࡱࡳࡼࡴࠠࡱ࠰ࡤ࠲ࡨ࠴࡫࠯ࡧ࠱ࡶ࠳ࠦࡥ࡯ࡥࡲࡨ࡮ࡴࡧ࠯ࠩᏄ"))
    def lookup(match):
        l1l111ll1l1ll_fwb_ (u"ࠢࠣࠤࡏࡳࡴࡱࠠࡶࡲࠣࡷࡾࡳࡢࡰ࡮ࡶࠤ࡮ࡴࠠࡵࡪࡨࠤࡸࡿ࡮ࡵࡪࡨࡸ࡮ࡩࠠࡴࡻࡰࡸࡦࡨ࠮ࠣࠤࠥᏅ")
        l111l1l11l1ll1l1ll_fwb_  = match.group(0)
        return l111l11l111ll1l1ll_fwb_[unbase(l111l1l11l1ll1l1ll_fwb_)] or l111l1l11l1ll1l1ll_fwb_
    source = re.sub(l1l111ll1l1ll_fwb_ (u"ࡳࠩࠪࠫࡡࡨ࡜ࡸ࠭࡟ࡦࠬ࠭ࠧᏆ"), lookup, l1111ll1l11ll1l1ll_fwb_)
    return _111l111ll1ll1l1ll_fwb_(source)
def _111l1l1111ll1l1ll_fwb_(source):
    l1l111ll1l1ll_fwb_ (u"ࠤࠥࠦࡏࡻࡩࡤࡧࠣࡪࡷࡵ࡭ࠡࡣࠣࡷࡴࡻࡲࡤࡧࠣࡪ࡮ࡲࡥࠡࡶ࡫ࡩࠥ࡬࡯ࡶࡴࠣࡥࡷ࡭ࡳࠡࡰࡨࡩࡩ࡫ࡤࠡࡤࡼࠤࡩ࡫ࡣࡰࡦࡨࡶ࠳ࠨࠢࠣᏇ")
    l111l11ll11ll1l1ll_fwb_ = (l1l111ll1l1ll_fwb_ (u"ࡵࠦࠧࠨࡽ࡝ࠪࠪࠬ࠳࠰ࠩࠨ࠮ࠣ࠮࠭ࡢࡤࠬࠫ࠯ࠤ࠯࠮࡜ࡥ࠭ࠬ࠰ࠥ࠰ࠧࠩ࠰࠭ࡃ࠮࠭࡜࠯ࡵࡳࡰ࡮ࡺ࡜ࠩࠩ࡟ࢀࠬࡢࠩࠣࠤࠥᏈ"))
    args = re.search(l111l11ll11ll1l1ll_fwb_, source, re.DOTALL).groups()
    try:
        return args[0], args[3].split(l1l111ll1l1ll_fwb_ (u"ࠫࢁ࠭Ꮙ")), int(args[1]), int(args[2])
    except ValueError:
        raise l111l111111ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠬࡉ࡯ࡳࡴࡸࡴࡹ࡫ࡤࠡࡲ࠱ࡥ࠳ࡩ࠮࡬࠰ࡨ࠲ࡷ࠴ࠠࡥࡣࡷࡥ࠳࠭Ꮚ"))
def _111l111ll1ll1l1ll_fwb_(source):
    l1l111ll1l1ll_fwb_ (u"ࠨࠢࠣࡕࡷࡶ࡮ࡶࠠࡴࡶࡵ࡭ࡳ࡭ࠠ࡭ࡱࡲ࡯ࡺࡶࠠࡵࡣࡥࡰࡪࠦࠨ࡭࡫ࡶࡸ࠮ࠦࡡ࡯ࡦࠣࡶࡪࡶ࡬ࡢࡥࡨࠤࡻࡧ࡬ࡶࡧࡶࠤ࡮ࡴࠠࡴࡱࡸࡶࡨ࡫࠮ࠣࠤࠥᏋ")
    match = re.search(l1l111ll1l1ll_fwb_ (u"ࡲࠨࠩࠪࡺࡦࡸࠠࠫࠪࡢࡠࡼ࠱ࠩ࡝࠿࡟࡟ࠧ࠮࠮ࠫࡁࠬࠦࡡࡣ࠻ࠨࠩࠪᏌ"), source, re.DOTALL)
    if match:
        l1ll1l11ll1ll1l1ll_fwb_, l111l1111l1ll1l1ll_fwb_ = match.groups()
        l1111ll1ll1ll1l1ll_fwb_ = len(match.group(0))
        lookup = l111l1111l1ll1l1ll_fwb_.split(l1l111ll1l1ll_fwb_ (u"ࠨࠤ࠯ࠦࠬᏍ"))
        l1111lll111ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠩࠨࡷࡠࠫࠥࡥ࡟ࠪᏎ") % l1ll1l11ll1ll1l1ll_fwb_
        for index, value in enumerate(lookup):
            source = source.replace(l1111lll111ll1l1ll_fwb_ % index, l1l111ll1l1ll_fwb_ (u"ࠪࠦࠪࡹࠢࠨᏏ") % value)
        return source[l1111ll1ll1ll1l1ll_fwb_:]
    return source
class l111l11l1l1ll1l1ll_fwb_(object):
    l1l111ll1l1ll_fwb_ (u"ࠦࠧࠨࡆࡶࡰࡦࡸࡴࡸࠠࡧࡱࡵࠤࡦࠦࡧࡪࡸࡨࡲࠥࡨࡡࡴࡧ࠱ࠤ࡜࡯࡬࡭ࠢࡨࡪ࡫࡯ࡣࡪࡧࡱࡸࡱࡿࠠࡤࡱࡱࡺࡪࡸࡴࠋࠢࠣࠤࠥࡹࡴࡳ࡫ࡱ࡫ࡸࠦࡴࡰࠢࡱࡥࡹࡻࡲࡢ࡮ࠣࡲࡺࡳࡢࡦࡴࡶ࠲ࠧࠨࠢᏐ")
    l1111lll1l1ll1l1ll_fwb_  = {
        52 : l1l111ll1l1ll_fwb_ (u"ࠬ࠶࠱࠳࠵࠷࠹࠻࠽࠸࠺ࡣࡥࡧࡩ࡫ࡦࡨࡪ࡬࡮ࡰࡲ࡭࡯ࡱࡳࡵࡷࡹࡴࡶࡸࡺࡼࡾࢀࡁࡃࡅࡇࡉࡋࡍࡈࡊࡌࡎࡐࡒࡔࡏࡑࠩᏑ"),
        54 : l1l111ll1l1ll_fwb_ (u"࠭࠰࠲࠴࠶࠸࠺࠼࠷࠹࠻ࡤࡦࡨࡪࡥࡧࡩ࡫࡭࡯ࡱ࡬࡮ࡰࡲࡴࡶࡸࡳࡵࡷࡹࡻࡽࡿࡺࡂࡄࡆࡈࡊࡌࡇࡉࡋࡍࡏࡑࡓࡎࡐࡒࡔࡖࠬᏒ"),
        62 : l1l111ll1l1ll_fwb_ (u"ࠧ࠱࠳࠵࠷࠹࠻࠶࠸࠺࠼ࡥࡧࡩࡤࡦࡨࡪ࡬࡮ࡰ࡫࡭࡯ࡱࡳࡵࡷࡲࡴࡶࡸࡺࡼࡾࡹࡻࡃࡅࡇࡉࡋࡆࡈࡊࡌࡎࡐࡒࡍࡏࡑࡓࡕࡗ࡙ࡔࡖࡘ࡚࡜࡞ࡠࠧᏓ"),
        95 : l1l111ll1l1ll_fwb_ (u"ࠨࠩࠪࠤࠦࠨࠣࠥࠧࠩࡠࠬ࠮ࠩࠫ࠭࠯࠱࠳࠵࠰࠲࠴࠶࠸࠺࠼࠷࠹࠻࠽࠿ࡁࡃ࠾ࡀࡂࡄࡆࡈࡊࡅࡇࡉࡋࡍࡏࡑࡌࡎࡐࡒࡔࡖࡘࡓࡕࡗ࡙࡛࡝࡟࡚࡜࡞ࡠࡢࡤࡦࡡࡣࡥࡧࡩ࡫࡭ࡨࡪ࡬࡮ࡰࡲࡴ࡯ࡱࡳࡵࡷࡹࡻࡶࡸࡺࡼࡾࢀࢂࡽࡿࠩࠪࠫᏔ")
    }
    def __init__(self, base):
        self.base = base
        if 2 <= base <= 36:
            self.unbase = lambda string: int(string, base)
        else:
            try:
                self.l111l11lll1ll1l1ll_fwb_ = dict((cipher, index) for
                    index, cipher in enumerate(self.l1111lll1l1ll1l1ll_fwb_[base]))
            except KeyError:
                raise TypeError(l1l111ll1l1ll_fwb_ (u"ࠩࡘࡲࡸࡻࡰࡱࡱࡵࡸࡪࡪࠠࡣࡣࡶࡩࠥ࡫࡮ࡤࡱࡧ࡭ࡳ࡭࠮ࠨᏕ"))
            self.unbase = self._1111llll11ll1l1ll_fwb_
    def __call__(self, string):
        return self.unbase(string)
    def _1111llll11ll1l1ll_fwb_(self, string):
        l1l111ll1l1ll_fwb_ (u"ࠥࠦࠧࡊࡥࡤࡱࡧࡩࡸࠦࡡࠡࠢࡹࡥࡱࡻࡥࠡࡶࡲࠤࡦࡴࠠࡪࡰࡷࡩ࡬࡫ࡲ࠯ࠤࠥࠦᏖ")
        l111l111l11ll1l1ll_fwb_ = 0
        for index, cipher in enumerate(string[::-1]):
            l111l111l11ll1l1ll_fwb_ += (self.base ** index) * self.l111l11lll1ll1l1ll_fwb_[cipher]
        return l111l111l11ll1l1ll_fwb_
class l111l111111ll1l1ll_fwb_(Exception):
    l1l111ll1l1ll_fwb_ (u"ࠦࠧࠨࡂࡢࡦ࡯ࡽࠥࡶࡡࡤ࡭ࡨࡨࠥࡹ࡯ࡶࡴࡦࡩࠥࡵࡲࠡࡩࡨࡲࡪࡸࡡ࡭ࠢࡨࡶࡷࡵࡲ࠯ࠢࡄࡶ࡬ࡻ࡭ࡦࡰࡷࠤ࡮ࡹࠠࡢࠌࠣࠤࠥࠦ࡭ࡦࡣࡱ࡭ࡳ࡭ࡦࡶ࡮ࠣࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮࠯ࠤࠥࠦᏗ")
    pass
if __name__ == l1l111ll1l1ll_fwb_ (u"ࠧࡥ࡟࡮ࡣ࡬ࡲࡤࡥࠢᏘ"):
    test=l1l111ll1l1ll_fwb_ (u"࠭ࠧࠨࡧࡹࡥࡱ࠮ࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠩࡲ࠯ࡥ࠱ࡩࠬ࡬࠮ࡨ࠰ࡩ࠯ࡻࡸࡪ࡬ࡰࡪ࠮ࡣ࠮࠯ࠬ࡭࡫࠮࡫࡜ࡥࡠ࠭ࡵࡃࡰ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࡱࡩࡼࠦࡒࡦࡩࡈࡼࡵ࠮ࠧ࡝࡞ࡥࠫ࠰ࡩ࠮ࡵࡱࡖࡸࡷ࡯࡮ࡨࠪࡤ࠭࠰࠭࡜࡝ࡤࠪ࠰ࠬ࡭ࠧࠪ࠮࡮࡟ࡨࡣࠩ࠼ࡴࡨࡸࡺࡸ࡮ࠡࡲࢀࠬࠬ࠺ࠨ࡝ࠩ࠶࠴ࡡ࠭ࠩ࠯࠴ࡽࠬࢀ࠸ࡹ࠻࡞ࠪ࠹࠿࠵࠯ࡢ࠰࠻࠲࠼࠵ࡩ࠰ࡼ࠲ࡽ࠴ࡽ࠮࠳ࡺ࡟ࠫ࠱࠸ࡷ࠻ࡽࡥ࠾ࡡ࠭࠲ࡷ࡞ࠪ࠰࠶࠿࠺࡝ࠩ࠿ࡴࡃࡂࡵ࠿࠾࠵ࠤࡩࡃࠢ࠳࠲ࠥࠤࡨࡃࠢࠤ࠳࠺ࠦࡃ࠸ࡵࠡ࠳࠼࠲ࡁ࠵࠲࠿࠾࠲ࡹࡃࡂ࠱࠷࠱ࡁࡀࡺࡄ࠼࠳ࠢࡧࡁࠧ࠷࠸ࠣࠢࡦࡁࠧࠩ࠱࠶ࠤࡁ࠶ࡹࠦ࠲ࡴࠢ࠵ࡶࠥ࠸ࡱ࠯࠾࠲࠶ࡃࡂ࠯ࡶࡀ࠿࠳ࡵࡄ࡜ࠨ࠮࠵ࡴ࠿ࡢࠧ࠽ࡲࡁࡀࡺࡄ࠼࠳ࠢࡧࡁࠧ࠸࠰ࠣࠢࡦࡁࠧࠩ࠱࠸ࠤࡁ࠶ࡴࠦ࠲࡯ࠢࡥ࠲ࡁ࠵࠲࠿࠾࠲ࡹࡃࡂ࠱࠷࠱ࡁࡀࡺࡄ࠼࠳ࠢࡧࡁࠧ࠷࠸ࠣࠢࡦࡁࠧࠩ࠱࠶ࠤࡁ࠶ࡲࠦ࠲࡭ࠢ࠵࡯ࠥ࠸ࡪ࠯࠾࠲࠶ࡃࡂ࠯ࡶࡀ࠿࠳ࡵࡄ࡜ࠨ࠮ࢀ࠰࠷࡯࠺࡝ࠩ࠵࡬ࡡ࠭ࠬ࠳ࡩ࠽࡟ࢀ࠷࠴࠻ࠤ࠴࠵ࠧ࠲ࡢ࠻ࠤ࠸࠾࠴࠵ࡡ࠯࠺࠱࠻࠴࠸ࡦ࠰࠳࠶࠲࠶࠸ࠢࡾ࠮ࡾ࠵࠹ࡀࠢ࠳ࡧࠥ࠰ࡧࡀࠢ࠶࠼࠲࠳ࡦ࠴࠸࠯࠹࠲࠶ࡩ࠵࠱࠴࠰࠴࠶ࠧࢃࠬ࡞࠮࠵ࡧ࠿ࠨ࠱࠲ࠤ࠯࠶ࡧࡀ࡛ࡼ࠳࠳࠾ࡡ࠭࠲ࡢ࡞ࠪ࠰࠷࠿࠺࡝ࠩ࠸࠾࠴࠵ࡶ࠯࠺࠱࠻࠴ࡺ࠭࡮࠱ࡰ࠲࠷࠾࡜ࠨࡿ࠯ࡿ࠶࠶࠺࡝ࠩ࠵࠻ࡡ࠭ࡽ࡞࠮࠵࠺࠿ࢁ࡜ࠨ࠴࠸࠱࠸ࡢࠧ࠻ࡽ࡟ࠫ࠷࠺࡜ࠨ࠼ࡾࡠࠬ࠸࠳࡝ࠩ࠽࠶࠷࠲࡜ࠨ࠴࠴ࡠࠬࡀ࡜ࠨ࠷࠽࠳࠴ࡧ࠮࠹࠰࠺࠳࡮࠵ࡺ࠰ࡻ࠲ࡠࠬ࠲࡜ࠨ࠳ࡽࡠࠬࡀ࡜ࠨࡹ࡟ࠫ࠱ࡢࠧ࠲ࡻ࡟ࠫ࠿ࡢࠧ࠲ࡺ࡟ࠫࢂࢃࡽ࠭ࡵ࠽ࡠࠬ࠻࠺࠰࠱ࡹ࠲࠽࠴࠷࠰ࡶ࠰ࡱ࠴ࡹ࠯࠲ࡹ࠱࠵ࡻࡢࠧ࠭࠳ࡸ࠾ࠧ࠷ࡴࠣ࠮࠴ࡷ࠿ࠨ࠱ࡳࠤ࠯࠵ࡶࡀ࡜ࠨ࠳ࡳࡠࠬ࠲࠱ࡰ࠼ࠥ࠵ࡳࠨࠬ࠲࡯࠽ࠦ࠶ࡲࠢ࠭࠳࡮࠾ࡡ࠭࠵࡝ࠩ࠯࠵࡯ࡀ࡜ࠨࡱ࡟ࠫ࠱ࢃࠩ࠼࡮ࠣࡩࡀࡲࠠ࡬࠿࠳࠿ࡱࠦ࠶࠾࠲࠾࠸࠭࠯࠮࠲࡫ࠫ࠽࠭ࡾࠩࡼࡨࠫ࠺ࡃ࠶ࠩ࡬࠭ࡀࡼ࠳ࡸ࠭࠷࠽࠹ࡁࡽ࠴ࡲ࠼ࡨࠫࡵࠦࡃ࠰ࠧࠨ࡮ࡂࡂࡷࠩࡼ࠸ࡀ࠱࠶ࡁ࠴ࠩࠫ࠱࠵࡭࠮ࠩ࠼࠶ࠫ࠭࠳࠷ࡧࠩࡱࠬ࠿ࠩ࠮࡜ࠨࠥ࠴ࡪࡡ࠭ࠩ࠯࡬ࠫ࠭ࡀࠪࠨ࡝ࠩ࡫࠲࡬ࡢࠧࠪ࠰࡭ࠬ࠮ࢃࡽࠪ࠽࠷ࠬ࠮࠴࠱ࡦࠪ࠼ࠬࡽ࠯ࡻ࠷࠿࠰࠵ࢂ࠯࠻࠵ࠪࠬ࠲࠶ࡪࠨ࠺ࠪࡻ࠭ࢀࡴࠨࡹࠫࢀ࠭ࡀ࠺ࠨࠪ࠰࠴ࡧ࠭࠿ࠨࠪࡽࠧࠬࡡ࠭ࡨ࠯ࡩ࡟ࠫ࠮࠴ࡪࠩࠫࢀ࠭ࡀ࠿ࠠ࡯ࠪࡻ࠭ࢀࠪࠨ࡝ࠩ࡫࠲࡬ࡢࠧࠪ࠰࠴ࡦ࠭࠯࠻ࡧࠪࡨ࠭࠶ࡧ࠻ࡦ࠿࠴࠿ࢂ࠭ࠬ࠴࠸࠯࠵࠵࠿ࠬࠨࡾࡿࡪࡴࡴࡴࡽࡾ࡭ࡻࡵࡲࡡࡺࡧࡵࢀ࡭ࡺࡴࡱࡾࡳ࠴࠶࠶࠲࠹࠻࠸ࢀࡲ࡫ࡼࡷ࡫ࡧࡸࡴࢂࡦࡶࡰࡦࡸ࡮ࡵ࡮ࡽࡧࡧ࡫ࡪ࠹ࡼࡧ࡫࡯ࡩࢁࡩ࡯࡭ࡱࡵࢀࡸ࡯ࡺࡦࡾࡹࡺࡵࡲࡡࡺࡾ࡬ࡪࢁࡼࡩࡥࡧࡲࡣࡦࡪࡼࡥ࡫ࡹࢀࢁࡹࡨࡰࡹࡿࡸࡹ࠷࠰࠳࠺࠼࠹ࢁࡼࡡࡳࡾࡳࡰࡦࡿࡥࡳࡾࡧࡳࡕࡲࡡࡺࡾࡩࡥࡱࡹࡥࡽࡾ࠵࠵࠻࠶࠰ࡽࡲࡲࡷ࡮ࡺࡩࡰࡰࡿࡷࡰ࡯࡮ࡽࡶࡨࡷࡹࢂࡼࡴࡶࡤࡸ࡮ࡩࡼ࠲ࡻ࠺ࡳࡰࡸࡱ࡬ࡸ࠷࡮࡮ࢂࡼ࠱࠲࠳࠶࠵ࢂ࠰࠲ࡾࡷࡽࡵ࡫ࡼ࠴࠸࠳ࡴࢁࡳࡰ࠵ࡾࡹ࡭ࡩ࡫࡯ࡽ࡮ࡤࡦࡪࡲࡼࡇࡈࡉࡊࡋࡌࡼࡣࡴࡿࡊࡋ࠶࠰࠱࠲ࡿࢀࡩ࡫࡬ࡦࡶࡨࡨࢁࡸࡥࡵࡷࡵࡲࢁ࡮ࡩࡥࡧࡿࡳࡳࡉ࡯࡮ࡲ࡯ࡩࡹ࡫ࡼࡰࡰࡓࡰࡦࡿࡼࡰࡰࡖࡩࡪࡱࡼࡱ࡮ࡤࡽࡤࡲࡩ࡮࡫ࡷࡣࡧࡵࡸࡽࡵࡨࡸࡋࡻ࡬࡭ࡵࡦࡶࡪ࡫࡮ࡽࡵࡷࡳࡵࢂ࡯࡯ࡖ࡬ࡱࡪࢂࡤࡰࡥ࡮ࢀࡵࡸ࡯ࡷ࡫ࡧࡩࡷࢂ࠳࠺࠳ࡿ࡬ࡪ࡯ࡧࡩࡶࡿ࠺࠺࠶ࡼࡸ࡫ࡧࡸ࡭ࢂ࡯ࡷࡧࡵࢀࡨࡵ࡮ࡵࡴࡲࡰࡧࡧࡲࡽ࠷࠴࠵࠵ࢂࡤࡶࡴࡤࡸ࡮ࡵ࡮ࡽࡷࡱ࡭࡫ࡵࡲ࡮ࡾࡶࡸࡷ࡫ࡴࡤࡪ࡬ࡲ࡬ࢂࡺࡪࡲࡿࡷࡹࡵࡲ࡮ࡶࡵࡳࡴࡶࡥࡳࡾ࠵࠵࠸ࢂࡦࡳࡧࡴࡹࡪࡴࡣࡺࡾࡳࡶࡪ࡬ࡩࡹࡾࡿࡴࡦࡺࡨࡽࡶࡵࡹࡪࢂࡥ࡯ࡣࡥࡰࡪࡪࡼࡱࡴࡨࡺ࡮࡫ࡷࡽࡶ࡬ࡱࡪࡹ࡬ࡪࡦࡨࡶࡹࡵ࡯࡭ࡶ࡬ࡴࡵࡲࡵࡨ࡫ࡱࢀࡵࡲࡵࡨ࡫ࡱࡷࢁ࡮ࡴ࡮࡮࠸ࢀࡸࡽࡦࡽࡵࡵࡧࢁ࡬࡬ࡢࡵ࡫ࢀࡲࡵࡤࡦࡵࡿ࡬ࡩࡥࡤࡦࡨࡤࡹࡱࡺࡼ࠴ࡤ࡭࡬ࡴ࡮ࡦࡹࡲ࡬ࡵࡼࡽࡳ࠵ࡲ࡫ࡺࡶࡺࡳ࡯ࡱ࡯ࡼࡴࡩࡹࡤࡪࡸࡱࡰ࠸࠷࠵ࡦࡶࡲࡰࡨ࡬ࡻ࠸ࡶࡪ࡬ࡷ࠶ࡶࡼ࠹ࡾࡹ࠽࠷ࡨࡺ࡬ࡥࢁ࠸࠴࠱ࡲࡿ࠷ࡧࡰࡨࡰࡪࡩࡼࡵ࡯ࡱࡸࡹࡶ࠸ࡵ࡮ࡶࡲࡶࡶࡲࡴࡲࡸࡰࡥࡼࡧ࡭ࡻ࡭࡬࠴࠺࠸ࡩࡹ࡮࡬ࡤࡤ࠷࠻ࡹࡦࡨࡳ࠹ࡹࡿࡿ࠳ࡵࡸ࠵ࡳ࡮ࡪࡱࡽࡪࡧࢀࡴࡸࡩࡨ࡫ࡱࡥࡱࢂࡲࡢࡶ࡬ࡳࢁࡨࡲࡰ࡭ࡨࡲࢁ࡯ࡳࡽ࡮࡬ࡲࡰࢂ࡙ࡰࡷࡵࢀࡸࡻࡣࡩࡾࡑࡳࢁࡴ࡯ࡧ࡫࡯ࡩࢁࡳ࡯ࡳࡧࡿࡥࡳࡿࡼࡢࡸࡤ࡭ࡱࡧࡢࡦࡾࡑࡳࡹࢂࡆࡪ࡮ࡨࢀࡔࡑࡼࡱࡴࡨࡺ࡮ࡽࡼ࡫ࡲࡪࢀ࡮ࡳࡡࡨࡧࡿࡷࡪࡺࡵࡱࡾࡩࡰࡻࡶ࡬ࡢࡻࡨࡶࠬ࠴ࡳࡱ࡮࡬ࡸ࠭࠭ࡼࠨࠫࠬ࠭ࠬ࠭ࠧᏙ")
    print unpack(test)
