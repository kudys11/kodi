# -*- coding: utf-8 -*-
import sys
l1ll11ll1l1ll_fwb_ = sys.version_info [0] == 2
l1111ll1l1ll_fwb_ = 2048
l1l1l1ll1l1ll_fwb_ = 7
def l1l111ll1l1ll_fwb_ (keyedStringLiteral):
	global l11ll1ll1l1ll_fwb_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll1l1ll_fwb_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
l1l111ll1l1ll_fwb_ (u"ࠤࠥࠦࠒࠐࡃࡳࡧࡤࡸࡪࡪࠠࡰࡰࠣࡘ࡭ࡻࠠࡇࡧࡥࠤ࠶࠷ࠠ࠲࠺࠽࠸࠼ࡀ࠴࠴ࠢ࠵࠴࠶࠼ࠍࠋࠏࠍࡄࡦࡻࡴࡩࡱࡵ࠾ࠥࡸࡡ࡮࡫ࡦࠑࠏࠨࠢࠣ఑")
import urllib2
import re
import l11llll111ll1l1ll_fwb_ as l11llll111ll1l1ll_fwb_
l11l1l1ll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡤࡦࡤ࠲ࡵࡲࠧఒ")
l11lll1111ll1l1ll_fwb_ = 5
def l11ll11l11ll1l1ll_fwb_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l1l111ll1l1ll_fwb_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨఓ"), l1l111ll1l1ll_fwb_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠹࠾࠮࠱࠰࠵࠹࠻࠺࠮࠺࠹ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪఔ"))
    if cookies:
        req.add_header(l1l111ll1l1ll_fwb_ (u"ࠨࡃࡰࡱ࡮࡭ࡪࠨక"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11lll1111ll1l1ll_fwb_)
        l111111l1ll1l1ll_fwb_ =  response.read()
        response.close()
    except:
        l111111l1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࠨఖ")
    return l111111l1ll1l1ll_fwb_
def _11l1ll111ll1l1ll_fwb_(content):
    src =l1l111ll1l1ll_fwb_ (u"ࠨࠩగ")
    l11l11lll1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠤࡨࡺࡦࡲࠨ࠯ࠬࡂ࠭ࡡࢁ࡜ࡾ࡞ࠬࡠ࠮ࠨఘ"),re.DOTALL).findall(content)
    for l11ll1lll1ll1l1ll_fwb_ in l11l11lll1ll1l1ll_fwb_:
        l11ll1lll1ll1l1ll_fwb_=re.sub(l1l111ll1l1ll_fwb_ (u"ࠪࠤࠥ࠭ఙ"),l1l111ll1l1ll_fwb_ (u"ࠫࠥ࠭చ"),l11ll1lll1ll1l1ll_fwb_)
        l11ll1lll1ll1l1ll_fwb_=re.sub(l1l111ll1l1ll_fwb_ (u"ࠬࡢ࡮ࠨఛ"),l1l111ll1l1ll_fwb_ (u"࠭ࠧజ"),l11ll1lll1ll1l1ll_fwb_)
        try:
            l11lll1ll1ll1l1ll_fwb_ = l11llll111ll1l1ll_fwb_.unpack(l11ll1lll1ll1l1ll_fwb_)
        except:
            l11lll1ll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࠨఝ")
        if l11lll1ll1ll1l1ll_fwb_:
            l11lll1ll1ll1l1ll_fwb_=re.sub(l1l111ll1l1ll_fwb_ (u"ࡳࠩ࡟ࡠࠬఞ"),l1l111ll1l1ll_fwb_ (u"ࡴࠪࠫట"),l11lll1ll1ll1l1ll_fwb_)
            l11lll11l1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠪࡪ࡮ࡲࡥ࠻࡞ࡶ࠮ࡠࡢࠧࠣ࡟ࠫ࠲࠰ࡅࠩ࡜࡞ࠪࠦࡢ࠲ࠧఠ"),  re.DOTALL).search(l11lll1ll1ll1l1ll_fwb_)
            l11lll1l11ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠫࡺࡸ࡬࠻࡞ࡶ࠮ࡠࡢࠧࠣ࡟ࠫ࠲࠰ࡅࠩ࡜࡞ࠪࠦࡢ࠲ࠧడ"),  re.DOTALL).search(l11lll1ll1ll1l1ll_fwb_)
            if l11lll11l1ll1l1ll_fwb_:
                src = l11lll11l1ll1l1ll_fwb_.group(1)
            elif l11lll1l11ll1l1ll_fwb_:
                src = l11lll1l11ll1l1ll_fwb_.group(1)
            if src:
                break
    return src
def _11ll1l111ll1l1ll_fwb_(content):
    src=l1l111ll1l1ll_fwb_ (u"ࠬ࠭ఢ")
    l11l1llll1ll1l1ll_fwb_ = content.find(l1l111ll1l1ll_fwb_ (u"࠭ࡼࡽࡾ࡫ࡸࡹࡶࠧణ"))
    if l11l1llll1ll1l1ll_fwb_>0:
        l11ll11111ll1l1ll_fwb_ = content.find(l1l111ll1l1ll_fwb_ (u"ࠧ࠯ࡵࡳࡰ࡮ࡺࠧత"),l11l1llll1ll1l1ll_fwb_)
        encoded =content[l11l1llll1ll1l1ll_fwb_:l11ll11111ll1l1ll_fwb_]
        if encoded:
            l11ll1l1l1ll1l1ll_fwb_ = encoded.split(l1l111ll1l1ll_fwb_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲࠨథ"))[0]
            l11ll1l1l1ll1l1ll_fwb_=re.sub(l1l111ll1l1ll_fwb_ (u"ࡴࠪ࡟ࢁࡣࠫ࡝ࡹࡾ࠶࠱࠹ࡽ࡜ࡾࡠ࠯ࠬద"),l1l111ll1l1ll_fwb_ (u"ࠪࢀࠬధ"),l11ll1l1l1ll1l1ll_fwb_,re.DOTALL)
            l11ll1l1l1ll1l1ll_fwb_=re.sub(l1l111ll1l1ll_fwb_ (u"ࡶࠬࡡࡼ࡞࠭࡟ࡻࢀ࠸ࠬ࠴ࡿ࡞ࢀࡢ࠱ࠧన"),l1l111ll1l1ll_fwb_ (u"ࠬࢂࠧ఩"),l11ll1l1l1ll1l1ll_fwb_,re.DOTALL)
            l11ll1ll11ll1l1ll_fwb_=[l1l111ll1l1ll_fwb_ (u"࠭ࡨࡵࡶࡳࠫప"),l1l111ll1l1ll_fwb_ (u"ࠧࡤࡦࡤࠫఫ"),l1l111ll1l1ll_fwb_ (u"ࠨࡲ࡯ࠫబ"),l1l111ll1l1ll_fwb_ (u"ࠩ࡯ࡳ࡬ࡵࠧభ"),l1l111ll1l1ll_fwb_ (u"ࠪࡻ࡮ࡪࡴࡩࠩమ"),l1l111ll1l1ll_fwb_ (u"ࠫ࡭࡫ࡩࡨࡪࡷࠫయ"),l1l111ll1l1ll_fwb_ (u"ࠬࡺࡲࡶࡧࠪర"),l1l111ll1l1ll_fwb_ (u"࠭ࡳࡵࡣࡷ࡭ࡨ࠭ఱ"),l1l111ll1l1ll_fwb_ (u"ࠧࡴࡶࠪల"),l1l111ll1l1ll_fwb_ (u"ࠨ࡯ࡳ࠸ࠬళ"),l1l111ll1l1ll_fwb_ (u"ࠩࡩࡥࡱࡹࡥࠨఴ"),l1l111ll1l1ll_fwb_ (u"ࠪࡺ࡮ࡪࡥࡰࠩవ"),l1l111ll1l1ll_fwb_ (u"ࠫࡸࡺࡡࡵ࡫ࡦࠫశ"),
                    l1l111ll1l1ll_fwb_ (u"ࠬࡺࡹࡱࡧࠪష"),l1l111ll1l1ll_fwb_ (u"࠭ࡳࡸࡨࠪస"),l1l111ll1l1ll_fwb_ (u"ࠧࡱ࡮ࡤࡽࡪࡸࠧహ"),l1l111ll1l1ll_fwb_ (u"ࠨࡨ࡬ࡰࡪ࠭఺"),l1l111ll1l1ll_fwb_ (u"ࠩࡦࡳࡳࡺࡲࡰ࡮ࡥࡥࡷ࠭఻"),l1l111ll1l1ll_fwb_ (u"ࠪࡥࡩࡹ఼ࠧ"),l1l111ll1l1ll_fwb_ (u"ࠫࡨࢀࡡࡴࠩఽ"),l1l111ll1l1ll_fwb_ (u"ࠬࡶ࡯ࡴ࡫ࡷ࡭ࡴࡴࠧా"),l1l111ll1l1ll_fwb_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨి"),l1l111ll1l1ll_fwb_ (u"ࠧࡣࡱࡷࡸࡴࡳࠧీ"),l1l111ll1l1ll_fwb_ (u"ࠨࡷࡶࡩࡷࡇࡧࡦࡰࡷࠫు"),
                    l1l111ll1l1ll_fwb_ (u"ࠩࡰࡥࡹࡩࡨࠨూ"),l1l111ll1l1ll_fwb_ (u"ࠪࡴࡳ࡭ࠧృ"),l1l111ll1l1ll_fwb_ (u"ࠫࡳࡧࡶࡪࡩࡤࡸࡴࡸࠧౄ"),l1l111ll1l1ll_fwb_ (u"ࠬ࡯ࡤࠨ౅"), l1l111ll1l1ll_fwb_ (u"࠭࠳࠸ࠩె"), l1l111ll1l1ll_fwb_ (u"ࠧࡳࡧࡪ࡭ࡴࡴࡳࠨే"), l1l111ll1l1ll_fwb_ (u"ࠨ࠲࠼ࠫై"), l1l111ll1l1ll_fwb_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࡦࠪ౉"), l1l111ll1l1ll_fwb_ (u"ࠪࡷࡷࡩࠧొ"), l1l111ll1l1ll_fwb_ (u"ࠫࡲ࡫ࡤࡪࡣࠪో")]
            l11ll1ll11ll1l1ll_fwb_=[l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡴࡵࡲࠪౌ"), l1l111ll1l1ll_fwb_ (u"࠭࡬ࡰࡩࡲ్ࠫ"), l1l111ll1l1ll_fwb_ (u"ࠧࡸ࡫ࡧࡸ࡭࠭౎"), l1l111ll1l1ll_fwb_ (u"ࠨࡪࡨ࡭࡬࡮ࡴࠨ౏"), l1l111ll1l1ll_fwb_ (u"ࠩࡷࡶࡺ࡫ࠧ౐"), l1l111ll1l1ll_fwb_ (u"ࠪࡷࡹࡧࡴࡪࡥࠪ౑"), l1l111ll1l1ll_fwb_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪ౒"), l1l111ll1l1ll_fwb_ (u"ࠬࡼࡩࡥࡧࡲࠫ౓"), l1l111ll1l1ll_fwb_ (u"࠭ࡰ࡭ࡣࡼࡩࡷ࠭౔"),
                l1l111ll1l1ll_fwb_ (u"ࠧࡧ࡫࡯ࡩౕࠬ"), l1l111ll1l1ll_fwb_ (u"ࠨࡶࡼࡴࡪౖ࠭"), l1l111ll1l1ll_fwb_ (u"ࠩࡵࡩ࡬࡯࡯࡯ࡵࠪ౗"), l1l111ll1l1ll_fwb_ (u"ࠪࡲࡴࡴࡥࠨౘ"), l1l111ll1l1ll_fwb_ (u"ࠫࡨࢀࡡࡴࠩౙ"), l1l111ll1l1ll_fwb_ (u"ࠬ࡫࡮ࡢࡤ࡯ࡩࡩ࠭ౚ"), l1l111ll1l1ll_fwb_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ౛"), l1l111ll1l1ll_fwb_ (u"ࠧࡤࡱࡱࡸࡷࡵ࡬ࡣࡣࡵࠫ౜"), l1l111ll1l1ll_fwb_ (u"ࠨ࡯ࡤࡸࡨ࡮ࠧౝ"), l1l111ll1l1ll_fwb_ (u"ࠩࡥࡳࡹࡺ࡯࡮ࠩ౞"),
                l1l111ll1l1ll_fwb_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ౟"), l1l111ll1l1ll_fwb_ (u"ࠫࡵࡵࡳࡪࡶ࡬ࡳࡳ࠭ౠ"), l1l111ll1l1ll_fwb_ (u"ࠬࡻࡳࡦࡴࡄ࡫ࡪࡴࡴࠨౡ"), l1l111ll1l1ll_fwb_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺ࡯ࡳࠩౢ"), l1l111ll1l1ll_fwb_ (u"ࠧࡤࡱࡱࡪ࡮࡭ࠧౣ"), l1l111ll1l1ll_fwb_ (u"ࠨࡪࡷࡱࡱ࠭౤"), l1l111ll1l1ll_fwb_ (u"ࠩ࡫ࡸࡲࡲ࠵ࠨ౥"), l1l111ll1l1ll_fwb_ (u"ࠪࡴࡷࡵࡶࡪࡦࡨࡶࠬ౦"), l1l111ll1l1ll_fwb_ (u"ࠫࡧࡲࡡࡤ࡭ࠪ౧"),
                l1l111ll1l1ll_fwb_ (u"ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡃ࡯࡭࡬ࡴࠧ౨"), l1l111ll1l1ll_fwb_ (u"࠭ࡣࡢࡰࡉ࡭ࡷ࡫ࡅࡷࡧࡱࡸࡆࡖࡉࡄࡣ࡯ࡰࡸ࠭౩"), l1l111ll1l1ll_fwb_ (u"ࠧࡶࡵࡨ࡚࠷ࡇࡐࡊࡅࡤࡰࡱࡹࠧ౪"), l1l111ll1l1ll_fwb_ (u"ࠨࡸࡨࡶࡹ࡯ࡣࡢ࡮ࡄࡰ࡮࡭࡮ࠨ౫"), l1l111ll1l1ll_fwb_ (u"ࠩࡷ࡭ࡲ࡫ࡳ࡭࡫ࡧࡩࡷࡺ࡯ࡰ࡮ࡷ࡭ࡵࡶ࡬ࡶࡩ࡬ࡲࠬ౬"),
                l1l111ll1l1ll_fwb_ (u"ࠪࡳࡻ࡫ࡲ࡭ࡣࡼࡷࠬ౭"), l1l111ll1l1ll_fwb_ (u"ࠫࡧࡧࡣ࡬ࡩࡵࡳࡺࡴࡤࡄࡱ࡯ࡳࡷ࠭౮"), l1l111ll1l1ll_fwb_ (u"ࠬࡳࡡࡳࡩ࡬ࡲࡧࡵࡴࡵࡱࡰࠫ౯"), l1l111ll1l1ll_fwb_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡹࠧ౰"), l1l111ll1l1ll_fwb_ (u"ࠧ࡭࡫ࡱ࡯ࠬ౱"), l1l111ll1l1ll_fwb_ (u"ࠨࡵࡷࡶࡪࡺࡣࡩ࡫ࡱ࡫ࠬ౲"), l1l111ll1l1ll_fwb_ (u"ࠩࡸࡲ࡮࡬࡯ࡳ࡯ࠪ౳"), l1l111ll1l1ll_fwb_ (u"ࠪࡷࡹࡧࡴࡪࡥ࠴ࠫ౴"),
                l1l111ll1l1ll_fwb_ (u"ࠫࡸ࡫ࡴࡶࡲࠪ౵"), l1l111ll1l1ll_fwb_ (u"ࠬࡰࡷࡱ࡮ࡤࡽࡪࡸࠧ౶"), l1l111ll1l1ll_fwb_ (u"࠭ࡣࡩࡧࡦ࡯ࡋࡲࡡࡴࡪࠪ౷"), l1l111ll1l1ll_fwb_ (u"ࠧࡔ࡯ࡤࡶࡹ࡚ࡖࠨ౸"), l1l111ll1l1ll_fwb_ (u"ࠨࡸ࠳࠴࠶࠭౹"), l1l111ll1l1ll_fwb_ (u"ࠩࡦࡶࡪࡳࡥࠨ౺"), l1l111ll1l1ll_fwb_ (u"ࠪࡨࡴࡩ࡫ࠨ౻"), l1l111ll1l1ll_fwb_ (u"ࠫࡦࡻࡴࡰࡵࡷࡥࡷࡺࠧ౼"), l1l111ll1l1ll_fwb_ (u"ࠬ࡯ࡤ࡭ࡧ࡫࡭ࡩ࡫ࠧ౽"), l1l111ll1l1ll_fwb_ (u"࠭࡭ࡰࡦࡨࡷࠬ౾"),
               l1l111ll1l1ll_fwb_ (u"ࠧࡧ࡮ࡤࡷ࡭࠭౿"), l1l111ll1l1ll_fwb_ (u"ࠨࡱࡹࡩࡷ࠭ಀ"), l1l111ll1l1ll_fwb_ (u"ࠩ࡯ࡩ࡫ࡺࠧಁ"), l1l111ll1l1ll_fwb_ (u"ࠪ࡬࡮ࡪࡥࠨಂ"), l1l111ll1l1ll_fwb_ (u"ࠫࡵࡲࡡࡺࡧࡵ࠹ࠬಃ"), l1l111ll1l1ll_fwb_ (u"ࠬ࡯࡭ࡢࡩࡨࠫ಄"), l1l111ll1l1ll_fwb_ (u"࠭ࡋࡍࡋࡎࡒࡎࡐࠧಅ"), l1l111ll1l1ll_fwb_ (u"ࠧࡤࡱࡰࡴࡦࡴࡩࡰࡰࡶࠫಆ"), l1l111ll1l1ll_fwb_ (u"ࠨࡴࡨࡷࡹࡵࡲࡦࠩಇ"), l1l111ll1l1ll_fwb_ (u"ࠩࡦࡰ࡮ࡩ࡫ࡔ࡫ࡪࡲࠬಈ"),
                l1l111ll1l1ll_fwb_ (u"ࠪࡷࡨ࡮ࡥࡥࡷ࡯ࡩࠬಉ"), l1l111ll1l1ll_fwb_ (u"ࠫࡤࡩ࡯ࡶࡰࡷࡨࡴࡽ࡮ࡠࠩಊ"), l1l111ll1l1ll_fwb_ (u"ࠬࡩ࡯ࡶࡰࡷࡨࡴࡽ࡮ࠨಋ"), l1l111ll1l1ll_fwb_ (u"࠭ࡲࡦࡩ࡬ࡳࡳ࠭ಌ"), l1l111ll1l1ll_fwb_ (u"ࠧࡦ࡮ࡶࡩࠬ಍"), l1l111ll1l1ll_fwb_ (u"ࠨࡥࡲࡲࡹࡸ࡯࡭ࡵࠪಎ"), l1l111ll1l1ll_fwb_ (u"ࠩࡳࡶࡪࡲ࡯ࡢࡦࠪಏ"), l1l111ll1l1ll_fwb_ (u"ࠪࡳࡷࡿࡧࡪࡰࡤࡰࡳ࡫ࠧಐ"), l1l111ll1l1ll_fwb_ (u"ࠫࡸࡺࡹ࡭ࡧࠪ಑"),
                l1l111ll1l1ll_fwb_ (u"ࠬ࠼࠲࠱ࡲࡻࠫಒ"), l1l111ll1l1ll_fwb_ (u"࠭࠳࠹࠹ࡳࡼࠬಓ"), l1l111ll1l1ll_fwb_ (u"ࠧࡱࡱࡶࡸࡪࡸࠧಔ"), l1l111ll1l1ll_fwb_ (u"ࠨࡼࡱ࡭ࡰࡴࡩࡦࠩಕ"), l1l111ll1l1ll_fwb_ (u"ࠩࡶࡩࡰࡻ࡮ࡥࠩಖ"), l1l111ll1l1ll_fwb_ (u"ࠪࡷ࡭ࡵࡷࡂࡨࡷࡩࡷ࡙ࡥࡤࡱࡱࡨࡸ࠭ಗ"), l1l111ll1l1ll_fwb_ (u"ࠫ࡮ࡳࡡࡨࡧࡶࠫಘ"), l1l111ll1l1ll_fwb_ (u"ࠬࡘࡥ࡬࡮ࡤࡱࡦ࠭ಙ"), l1l111ll1l1ll_fwb_ (u"࠭ࡳ࡬࡫ࡳࡅࡩ࠭ಚ"),
                 l1l111ll1l1ll_fwb_ (u"ࠧ࡭ࡧࡹࡩࡱࡹࠧಛ"), l1l111ll1l1ll_fwb_ (u"ࠨࡲࡤࡨࡩ࡯࡮ࡨࠩಜ"), l1l111ll1l1ll_fwb_ (u"ࠩࡲࡴࡦࡩࡩࡵࡻࠪಝ"), l1l111ll1l1ll_fwb_ (u"ࠪࡨࡪࡨࡵࡨࠩಞ"), l1l111ll1l1ll_fwb_ (u"ࠫࡻ࡯ࡤࡦࡱ࠶ࠫಟ"), l1l111ll1l1ll_fwb_ (u"ࠬࡩ࡬ࡰࡵࡨࠫಠ"), l1l111ll1l1ll_fwb_ (u"࠭ࡳ࡮ࡣ࡯ࡰࡹ࡫ࡸࡵࠩಡ"), l1l111ll1l1ll_fwb_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨಢ"), l1l111ll1l1ll_fwb_ (u"ࠨࡥ࡯ࡥࡸࡹࠧಣ"), l1l111ll1l1ll_fwb_ (u"ࠩࡤࡰ࡮࡭࡮ࠨತ"),
                  l1l111ll1l1ll_fwb_ (u"ࠪࡲࡴࡺࡩࡤࡧࠪಥ"), l1l111ll1l1ll_fwb_ (u"ࠫࡲ࡫ࡤࡪࡣࠪದ")]
            for l1l11111ll1l1ll_fwb_ in l11ll1ll11ll1l1ll_fwb_:
                l11ll1l1l1ll1l1ll_fwb_=l11ll1l1l1ll1l1ll_fwb_.replace(l1l11111ll1l1ll_fwb_,l1l111ll1l1ll_fwb_ (u"ࠬ࠭ಧ"))
            cleanup=l11ll1l1l1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"࠭ࡼࠨನ"),l1l111ll1l1ll_fwb_ (u"ࠧࠡࠩ಩")).split()
            out={l1l111ll1l1ll_fwb_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࠨಪ"): l1l111ll1l1ll_fwb_ (u"ࠩࠪಫ"), l1l111ll1l1ll_fwb_ (u"ࠪࡩࠬಬ"): l1l111ll1l1ll_fwb_ (u"ࠫࠬಭ"), l1l111ll1l1ll_fwb_ (u"ࠬ࡬ࡩ࡭ࡧࠪಮ"): l1l111ll1l1ll_fwb_ (u"࠭ࠧಯ"), l1l111ll1l1ll_fwb_ (u"ࠧࡴࡶࠪರ"): l1l111ll1l1ll_fwb_ (u"ࠨࠩಱ")}
            if len(cleanup)==4:
                print l1l111ll1l1ll_fwb_ (u"ࠩࡏࡩࡳ࡭ࡴࡩࠢࡒࡏࠬಲ")
                for l1l11111ll1l1ll_fwb_ in cleanup:
                    if l1l11111ll1l1ll_fwb_.isdigit():
                        out[l1l111ll1l1ll_fwb_ (u"ࠪࡩࠬಳ")]=l1l11111ll1l1ll_fwb_
                    elif re.match(l1l111ll1l1ll_fwb_ (u"ࠫࡠࡧ࠭ࡻ࡟ࡾ࠶࠱ࢃ࡜ࡥࡽ࠶ࢁࠬ಴"),l1l11111ll1l1ll_fwb_) and len(l1l11111ll1l1ll_fwb_)<10:
                        out[l1l111ll1l1ll_fwb_ (u"ࠬࡹࡥࡳࡸࡨࡶࠬವ")] = l1l11111ll1l1ll_fwb_
                    elif len(l1l11111ll1l1ll_fwb_)==22:
                        out[l1l111ll1l1ll_fwb_ (u"࠭ࡳࡵࠩಶ")] = l1l11111ll1l1ll_fwb_
                    else:
                        out[l1l111ll1l1ll_fwb_ (u"ࠧࡧ࡫࡯ࡩࠬಷ")] = l1l11111ll1l1ll_fwb_
                src=l1l111ll1l1ll_fwb_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠧࡶ࠲ࡨࡪࡡ࠯ࡲ࡯࠳ࠪࡹ࠮࡮ࡲ࠷ࡃࡸࡺ࠽ࠦࡵࠩࡩࡂࠫࡳࠨಸ")%(out.get(l1l111ll1l1ll_fwb_ (u"ࠩࡶࡩࡷࡼࡥࡳࠩಹ")),out.get(l1l111ll1l1ll_fwb_ (u"ࠪࡪ࡮ࡲࡥࠨ಺")),out.get(l1l111ll1l1ll_fwb_ (u"ࠫࡸࡺࠧ಻")),out.get(l1l111ll1l1ll_fwb_ (u"ࠬ࡫಼ࠧ")))
    return src
def l11llll1l1ll1l1ll_fwb_(content):
    l1l111ll1l1ll_fwb_ (u"ࠨࠢࠣࠏࠍࠤࠥࠦࠠࡔࡥࡤࡲࡸࠦࡦࡰࡴࠣࡺ࡮ࡪࡥࡰࠢ࡯࡭ࡳࡱࠠࡪࡰࡦࡰࡺࡪࡥࡥࠢࡨࡲࡨࡵࡤࡦࡦࠣࡳࡳ࡫ࠍࠋࠢࠣࠤࠥࠨࠢࠣಽ")
    l11ll11ll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࠨಾ")
    l11lll11l1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠨࡨ࡬ࡰࡪࡀࠠ࡜࡞ࠪࠦࡢ࠮࠮ࠬࡁࠬ࡟ࡡ࠭ࠢ࡞࠮ࠪಿ"),  re.DOTALL).search(content)
    l11lll1l11ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠩࡸࡶࡱࡀࠠ࡜࡞ࠪࠦࡢ࠮࠮ࠬࡁࠬ࡟ࡡ࠭ࠢ࡞࠮ࠪೀ"),  re.DOTALL).search(content)
    if l11lll11l1ll1l1ll_fwb_:
        print l1l111ll1l1ll_fwb_ (u"ࠪࡪࡴࡻ࡮ࡥࠢࡕࡉࠥࡡࡦࡪ࡮ࡨ࠾ࡢ࠭ು")
        l11ll11ll1ll1l1ll_fwb_ = l11lll11l1ll1l1ll_fwb_.group(1)
    elif l11lll1l11ll1l1ll_fwb_:
        print l1l111ll1l1ll_fwb_ (u"ࠫ࡫ࡵࡵ࡯ࡦࠣࡖࡊ࡛ࠦࡶࡴ࡯࠾ࡢ࠭ೂ")
        l11ll11ll1ll1l1ll_fwb_ = l11lll1l11ll1l1ll_fwb_.group(1)
    else:
        print l1l111ll1l1ll_fwb_ (u"ࠬ࡫࡮ࡤࡱࡧࡩࡩࠦ࠺ࠡࡷࡱࡴࡦࡩ࡫ࡦࡴࠪೃ")
        l11ll11ll1ll1l1ll_fwb_ = _11l1ll111ll1l1ll_fwb_(content)
        if not l11ll11ll1ll1l1ll_fwb_:
            print l1l111ll1l1ll_fwb_ (u"࠭ࡥ࡯ࡥࡲࡨࡪࡪࠠ࠻ࠢࡩࡳࡷࡩࡥࠡࠩೄ")
            l11ll11ll1ll1l1ll_fwb_ = _11ll1l111ll1l1ll_fwb_(content)
    return l11ll11ll1ll1l1ll_fwb_
def l11l1ll1l1ll1l1ll_fwb_(url):
    l1l111ll1l1ll_fwb_ (u"ࠢࠣࠤࠐࠎࠥࠦࠠࠡࡴࡨࡸࡺࡸ࡮ࡴࠢࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥ࠳ࠠࡶ࡮ࡵࠤ࡭ࡺࡴࡱ࠼࠲࠳࠳࠴࠮࠯ࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠲ࠦ࡯ࡳࠢ࡯࡭ࡸࡺࠠࡰࡨࠣ࡟࠭࠭࠷࠳࠲ࡳࠫ࠱ࠦࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡨࡪࡡ࠯ࡲ࡯࠳ࡻ࡯ࡤࡦࡱ࠲࠵࠾࠺࠶࠺࠻࠴ࡪࡄࡽࡥࡳࡵ࡭ࡥࡂ࠽࠲࠱ࡲࠪ࠭࠱࠴࠮࠯࡟ࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠍࠋࠢࠣࠤࠥࠨࠢࠣ೅")
    l11l1l11l1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠨࡾࡆࡳࡴࡱࡩࡦ࠿ࠥࡔࡍࡖࡓࡆࡕࡖࡍࡉࡃ࠱ࠧࡔࡨࡪࡪࡸࡥࡳ࠿࡫ࡸࡹࡶ࠺࠰࠱ࡶࡸࡦࡺࡩࡤ࠰ࡦࡨࡦ࠴ࡰ࡭࠱ࡳࡰࡦࡿࡥࡳ࠷࠱࠽࠴ࡶ࡬ࡢࡻࡨࡶ࠳ࡹࡷࡧࠩೆ")
    l11l1l1l11ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠩࡿࡖࡪ࡬ࡥࡳࡧࡵࡁ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡺࡡࡵ࡫ࡦ࠲ࡨࡪࡡ࠯ࡲ࡯࠳ࡵࡲࡡࡺࡧࡵ࠹࠳࠿࠯ࡱ࡮ࡤࡽࡪࡸ࠮ࡴࡹࡩࠫೇ")
    print url
    content = l11ll11l11ll1l1ll_fwb_(url)
    src=[]
    if not l1l111ll1l1ll_fwb_ (u"ࠪࡃࡼ࡫ࡲࡴ࡬ࡤࠫೈ") in url:
         l11l1l1111ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠫࡁࡧࠠࡥࡣࡷࡥ࠲ࡷࡵࡢ࡮࡬ࡸࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࠩࡁࡓࡀࡍࡄ࠮ࠫࡁࠬࡂ࠭ࡅࡐ࠽ࡓࡁ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ೉"), re.DOTALL).findall(content)
         for quality in l11l1l1111ll1l1ll_fwb_:
             l111111l1ll1l1ll_fwb_ = re.search(l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫೊ"),quality[1])
             l11l1lll11ll1l1ll_fwb_ = quality[2]
             src.insert(0,(l11l1lll11ll1l1ll_fwb_,l11l1l1ll1ll1l1ll_fwb_+l111111l1ll1l1ll_fwb_.group(1)))
    if not src:
        src = l11llll1l1ll1l1ll_fwb_(content)
        if src:
            src+=l11l1l11l1ll1l1ll_fwb_+l11l1l1l11ll1l1ll_fwb_
    return src
def l11ll111l1ll1l1ll_fwb_(url,quality=0):
    l1l111ll1l1ll_fwb_ (u"ࠨࠢࠣࠏࠍࠤࠥࠦࠠࡳࡧࡷࡹࡷࡴࡳࠡࡷࡵࡰࠥࡺ࡯ࠡࡸ࡬ࡨࡪࡵࠍࠋࠢࠣࠤࠥࠨࠢࠣೋ")
    src = l11l1ll1l1ll1l1ll_fwb_(url)
    if type(src)==list:
        selected=src[quality]
        print l1l111ll1l1ll_fwb_ (u"ࠧࡒࡷࡤࡰ࡮ࡺࡹࠡ࠼ࠪೌ"),selected[0]
        src = l11l1ll1l1ll1l1ll_fwb_(selected[1])
    return src
