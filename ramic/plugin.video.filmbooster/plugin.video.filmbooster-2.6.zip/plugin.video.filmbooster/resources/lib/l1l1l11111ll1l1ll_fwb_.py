# -*- coding: utf-8 -*-
import sys
l1ll11ll1l1ll_fwb_ = sys.version_info [0] == 2
l1111ll1l1ll_fwb_ = 2048
l1l1l1ll1l1ll_fwb_ = 7
def l1l111ll1l1ll_fwb_ (keyedStringLiteral):
	global l11ll1ll1l1ll_fwb_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll1l1ll_fwb_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os
import json
import l1lllll1ll1ll1l1ll_fwb_ as l1111lll11ll1l1ll_fwb_
import cookielib
from urlparse import urlparse
l11l1l1ll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦࡨࡦࡾ࠮ࡵࡸ࠲್ࠫ")
l11lll1111ll1l1ll_fwb_ = 15
l1llll1ll11ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠶࠻࠲࠵࠴࠲࠶࠸࠷࠲࠾࠽ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧ೎")
l111111l11ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࡵࠫࡉࡀ࡜ࡤࡦࡤࡼ࠳ࡩ࡯ࡰ࡭࡬ࡩࠬ೏")
l1llllll111ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠫࠬ೐")
l111l11111ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠬ࠭೑")
l111l11111ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡦࡷࡧ࡭࡬ࡣ࠰ࡴࡷࡵࡸࡺ࠰ࡳࡰ࠴࠭೒")
l11l11l111ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࠨ೓")
def l11111ll11ll1l1ll_fwb_(url,header={}):
    l111111l1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠨࠩ೔")
    global l11l11l111ll1l1ll_fwb_
    if not l11l11l111ll1l1ll_fwb_:
        req = urllib2.Request(l111l11111ll1l1ll_fwb_,data=None,headers={l1l111ll1l1ll_fwb_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ೕ"): l1llll1ll11ll1l1ll_fwb_,l1l111ll1l1ll_fwb_ (u"࡙ࠪࡵ࡭ࡲࡢࡦࡨ࠱ࡎࡴࡳࡦࡥࡸࡶࡪ࠳ࡒࡦࡳࡸࡩࡸࡺࡳࠨೖ"):1})
        response = urllib2.urlopen(req,timeout=l11lll1111ll1l1ll_fwb_)
        cookies=response.headers.get(l1l111ll1l1ll_fwb_ (u"ࠫࡸ࡫ࡴ࠮ࡥࡲࡳࡰ࡯ࡥࠨ೗"),l1l111ll1l1ll_fwb_ (u"ࠬࠦࠧ೘")).split(l1l111ll1l1ll_fwb_ (u"࠭ࠠࠨ೙"))[0]
        response.close()
        l11l11l111ll1l1ll_fwb_ = cookies
    else:
        cookies=l11l11l111ll1l1ll_fwb_
    data = l1l111ll1l1ll_fwb_ (u"ࠧࡶ࠿ࠨࡷࠫࡧ࡬࡭ࡱࡺࡇࡴࡵ࡫ࡪࡧࡶࡁࡴࡴࠧ೚")%urllib.quote_plus(url)
    l1lllll11l1ll1l1ll_fwb_ = l111l11111ll1l1ll_fwb_+l1l111ll1l1ll_fwb_ (u"ࠨ࠱࡬ࡲࡨࡲࡵࡥࡧࡶ࠳ࡵࡸ࡯ࡤࡧࡶࡷ࠳ࡶࡨࡱࡁࡤࡧࡹ࡯࡯࡯࠿ࡸࡴࡩࡧࡴࡦࠩ೛")
    headers={l1l111ll1l1ll_fwb_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭೜"): l1llll1ll11ll1l1ll_fwb_,l1l111ll1l1ll_fwb_ (u"࡙ࠪࡵ࡭ࡲࡢࡦࡨ࠱ࡎࡴࡳࡦࡥࡸࡶࡪ࠳ࡒࡦࡳࡸࡩࡸࡺࡳࠨೝ"):1,l1l111ll1l1ll_fwb_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫೞ"):cookies}
    headers.update(header)
    req = urllib2.Request(l1lllll11l1ll1l1ll_fwb_,data,headers)
    response = urllib2.urlopen(req,timeout=l11lll1111ll1l1ll_fwb_)
    l111111l1ll1l1ll_fwb_=response.read()
    if l1l111ll1l1ll_fwb_ (u"ࠬࡹࡳ࡭ࡣࡪࡶࡪ࡫ࠧ೟") in l111111l1ll1l1ll_fwb_:
        l1lllll11l1ll1l1ll_fwb_ = l111l11111ll1l1ll_fwb_+l1l111ll1l1ll_fwb_ (u"࠭࠯ࡪࡰࡦࡰࡺࡪࡥࡴ࠱ࡳࡶࡴࡩࡥࡴࡵ࠱ࡴ࡭ࡶ࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࡴࡵ࡯ࡥ࡬ࡸࡥࡦࠩೠ")
        req = urllib2.Request(l1lllll11l1ll1l1ll_fwb_,data,headers)
        response = urllib2.urlopen(req,timeout=l11lll1111ll1l1ll_fwb_)
        l111111l1ll1l1ll_fwb_=response.read()
    response.close()
    print l1l111ll1l1ll_fwb_ (u"ࠧࡈࡃࡗࡉࠥ࡯࡮ࠡࡗࡖࡉࠬೡ")
    return l111111l1ll1l1ll_fwb_
def _11l111ll1ll1l1ll_fwb_(url,data=None,header={},cookies=None):
    headers={l1l111ll1l1ll_fwb_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬೢ"): l1llll1ll11ll1l1ll_fwb_,l1l111ll1l1ll_fwb_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪೣ"):l11l1l1ll1ll1l1ll_fwb_}
    headers.update(header)
    req = urllib2.Request(url,data,headers)
    l1111111l1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠪࠫ೤")
    if cookies:
        req.add_header(l1l111ll1l1ll_fwb_ (u"ࠦࡈࡵ࡯࡬࡫ࡨࠦ೥"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11lll1111ll1l1ll_fwb_)
        l1111111l1ll1l1ll_fwb_ = response.headers[l1l111ll1l1ll_fwb_ (u"ࠬࡹࡥࡵ࠯ࡦࡳࡴࡱࡩࡦࠩ೦")]
        response = urllib2.urlopen(req,timeout=l11lll1111ll1l1ll_fwb_)
        l111111l1ll1l1ll_fwb_ = response.read()
    except:
        l111111l1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"࠭ࠧ೧")
    return l111111l1ll1l1ll_fwb_
def l11ll11l11ll1l1ll_fwb_(url,data=None,header={}):
    cookies=l1111lll11ll1l1ll_fwb_.l1lllllll11ll1l1ll_fwb_(l111111l11ll1l1ll_fwb_)
    content=_11l111ll1ll1l1ll_fwb_(url,data,header,cookies)
    if not content or len(content)<100:
        l11l11l1l1ll1l1ll_fwb_=l11111lll1ll1l1ll_fwb_(url,l111111l11ll1l1ll_fwb_)
        cookies=l1111lll11ll1l1ll_fwb_.l1lllllll11ll1l1ll_fwb_(l111111l11ll1l1ll_fwb_)
        content=_11l111ll1ll1l1ll_fwb_(url,data,header,cookies)
        if not content:
            print l1l111ll1l1ll_fwb_ (u"ࠧࡷ࡫ࡤࠤࡌࡇࡔࡆ࠼ࠣࠩࡸ࠭೨")%url
            content=l11111ll11ll1l1ll_fwb_(url,header)
    return content
def l11111lll1ll1l1ll_fwb_(l111111l1ll1l1ll_fwb_,l1111ll1l1ll1l1ll_fwb_):
    l11l11l1l1ll1l1ll_fwb_ = cookielib.LWPCookieJar()
    l111l11ll1ll1l1ll_fwb_ = l1111lll11ll1l1ll_fwb_.l111lll111ll1l1ll_fwb_(l111111l1ll1l1ll_fwb_,l11l11l1l1ll1l1ll_fwb_,l1llll1ll11ll1l1ll_fwb_)
    l1l111l111ll1l1ll_fwb_=os.path.dirname(l1111ll1l1ll1l1ll_fwb_)
    if not os.path.exists(l1l111l111ll1l1ll_fwb_):
        os.makedirs(l1l111l111ll1l1ll_fwb_)
    if l11l11l1l1ll1l1ll_fwb_:
        l11l11l1l1ll1l1ll_fwb_.save(l1111ll1l1ll1l1ll_fwb_, ignore_discard = True)
    return l11l11l1l1ll1l1ll_fwb_
def l1111ll11ll1l1ll_fwb_(url,l111lll1ll1l1ll_fwb_=1,group=l1l111ll1l1ll_fwb_ (u"ࠨࠩ೩")):
    if l1l111ll1l1ll_fwb_ (u"ࠩࡂࡴࡦ࡭ࡥ࠾ࠩ೪") in url:
        url = re.sub(l1l111ll1l1ll_fwb_ (u"ࠪࠫࠬࡶࡡࡨࡧࡀࡠࡩ࠱ࠧࠨࠩ೫"),l1l111ll1l1ll_fwb_ (u"ࠫࠬ࠭ࡰࡢࡩࡨࡁࠪࡪࠧࠨࠩ೬")%l111lll1ll1l1ll_fwb_,url)
    else:
        url += l1l111ll1l1ll_fwb_ (u"ࠬ࠵ࠧ೭") if url[-1] != l1l111ll1l1ll_fwb_ (u"࠭࠯ࠨ೮") else l1l111ll1l1ll_fwb_ (u"ࠧࠨ೯")
        url = url + l1l111ll1l1ll_fwb_ (u"ࠨࡁࡳࡥ࡬࡫࠽ࠦࡦࠪ೰") %l111lll1ll1l1ll_fwb_
    content = l11ll11l11ll1l1ll_fwb_(url)
    content = urllib.unquote(content)
    l1111l1l11ll1l1ll_fwb_ = l1111lll11ll1l1ll_fwb_.l1lllllll11ll1l1ll_fwb_(l111111l11ll1l1ll_fwb_)
    l11111l111ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠤࡿࡇࡴࡵ࡫ࡪࡧࡀࠩࡸࠬࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠩࡸࠨೱ") % (l1111l1l11ll1l1ll_fwb_, l1llll1ll11ll1l1ll_fwb_) if l1111l1l11ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠪࠫೲ")
    if group:
        idx = [(m.start(0), m.end(0)) for m in re.finditer(group.decode(l1l111ll1l1ll_fwb_ (u"ࠫࡺࡺࡦ࠮࠺ࠪೳ")), content,re.IGNORECASE) ]
        if idx:
            idx = idx[0][0]
            l11ll1l1l1ll1l1ll_fwb_=content[idx:]
            ids = [(a.start(), a.end()) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠬࡂࡤࡪࡸࠣ࡭ࡩࡃࠢࡪࡶࡨࡱ࠲ࡲࡩࡴࡶࠥࠫ೴"), l11ll1l1l1ll1l1ll_fwb_)]
            if not ids:
                ids = [(a.start(), a.end()) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦ࡮ࡺࡥ࡮࠯࡯࡭ࡸࡺࠠࡳࡱࡺࠦࠬ೵"), l11ll1l1l1ll1l1ll_fwb_)]
            ids.append( (-1,-1) )
            if len(ids)>1: content = l11ll1l1l1ll1l1ll_fwb_[ ids[0][1]:ids[1][0] ]
    ids = [(a.start(), a.end()) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡭࠯ࡻࡷ࠲ࡢࡤࡼ࠳ࢀࠤࡨࡵ࡬࠮ࡵࡰ࠱ࡡࡪࡻ࠲ࡿ࡞ࡢࠧࡣࠪࠣࡀࠪ೶"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11l11ll11ll1l1ll_fwb_ = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile(l1l111ll1l1ll_fwb_ (u"ࠨࠩࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࠪࠫ೷")).search(l11l11ll11ll1l1ll_fwb_)
        title = re.compile(l1l111ll1l1ll_fwb_ (u"ࠩࠪࠫࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࠬ࠭೸"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
        l1111l11l1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠪࠫࠬࡪࡡࡵࡣ࠰ࡧࡴࡴࡴࡦࡰࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࠭ࠧ೹")).search(l11l11ll11ll1l1ll_fwb_)
        l111l1lll1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠫࠬ࠭࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࠪࠫ೺")).search(l11l11ll11ll1l1ll_fwb_)
        year =  re.compile(l1l111ll1l1ll_fwb_ (u"ࠬ࠭ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡿࡥࡢࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫࠬ࠭೻")).search(l11l11ll11ll1l1ll_fwb_)
        l1lllll1l11ll1l1ll_fwb_ =  re.compile(l1l111ll1l1ll_fwb_ (u"࠭ࠧࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡲࡢࡶࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ࠭ࠧ೼")).search(l11l11ll11ll1l1ll_fwb_)
        if href and title:
            l111l1lll1ll1l1ll_fwb_ = l111l1lll1ll1l1ll_fwb_.group(1) if l111l1lll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠧࠨ೽")
            l111l1lll1ll1l1ll_fwb_ = _111lllll1ll1l1ll_fwb_(l111l1lll1ll1l1ll_fwb_)
            l1l11111ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"ࠨࡪࡵࡩ࡫࠭೾")   : _111lllll1ll1l1ll_fwb_(href.group(1)),
                l1l111ll1l1ll_fwb_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ೿")  : l111l1l1l1ll1l1ll_fwb_(title.group(1)),
                l1l111ll1l1ll_fwb_ (u"ࠪࡴࡱࡵࡴࠨഀ")   : l111l1l1l1ll1l1ll_fwb_(l1111l11l1ll1l1ll_fwb_.group(1)) if l1111l11l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠫࠬഁ"),
                l1l111ll1l1ll_fwb_ (u"ࠬ࡯࡭ࡨࠩം")    : l111l1lll1ll1l1ll_fwb_,
                l1l111ll1l1ll_fwb_ (u"࠭ࡲࡢࡶ࡬ࡲ࡬࠭ഃ") : l1lllll1l11ll1l1ll_fwb_.group(1) if l1lllll1l11ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠧࠨഄ"),
                l1l111ll1l1ll_fwb_ (u"ࠨࡻࡨࡥࡷ࠭അ")   : year.group(1) if year else l1l111ll1l1ll_fwb_ (u"ࠩࠪആ"),
                    }
            out.append(l1l11111ll1l1ll_fwb_)
    l1llllllll1ll1l1ll_fwb_ = l111lll1ll1l1ll_fwb_+1 if  content.find(l1l111ll1l1ll_fwb_ (u"ࠪࡴࡦ࡭ࡥ࠾ࠧࡧࠫഇ") %(l111lll1ll1l1ll_fwb_+1))>-1 else False
    l11l111111ll1l1ll_fwb_ = l111lll1ll1l1ll_fwb_-1 if l111lll1ll1l1ll_fwb_>1 else False
    return (out, (l11l111111ll1l1ll_fwb_,l1llllllll1ll1l1ll_fwb_))
def l11111l1l1ll1l1ll_fwb_(url):
    content = l11ll11l11ll1l1ll_fwb_(url)
    l11l11ll11ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠫࠬ࠭࠼ࡶ࡮ࠣ࡭ࡩࡃࠢࡴࡧࡵ࡭ࡪࡹ࠭࡭࡫ࡶࡸࠧࠦࡣ࡭ࡣࡶࡷࡂࠨࡦࡪ࡮ࡷࡩࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫࠬ࠭ഈ"),re.DOTALL).findall(content)
    out=[]
    if l11l11ll11ll1l1ll_fwb_:
        l1111l1ll1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠬ࠭ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠪࠫࠬഉ"),re.MULTILINE).findall(l11l11ll11ll1l1ll_fwb_[0])
        for href,title in l1111l1ll1ll1l1ll_fwb_:
            l1l11111ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"࠭ࡨࡳࡧࡩࠫഊ")   : _111lllll1ll1l1ll_fwb_(href),
                l1l111ll1l1ll_fwb_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ഋ")  : l111l1l1l1ll1l1ll_fwb_(title),
                l1l111ll1l1ll_fwb_ (u"ࠨࡲ࡯ࡳࡹ࠭ഌ")   : l1l111ll1l1ll_fwb_ (u"ࠩࠪ഍"),
                    }
            out.append(l1l11111ll1l1ll_fwb_)
    return out
def _111lllll1ll1l1ll_fwb_(href):
    url = href.replace(l1l111ll1l1ll_fwb_ (u"ࠪ࠳ࡧࡸ࡯ࡸࡵࡨ࠲ࡵ࡮ࡰࡀࡷࡀࠫഎ"),l1l111ll1l1ll_fwb_ (u"ࠫࠬഏ"))
    url = url.split(l1l111ll1l1ll_fwb_ (u"ࠬࠬࡡ࡮ࡲ࠾ࠫഐ"))[0]
    return urllib.unquote(url)
url=l1l111ll1l1ll_fwb_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤࡦࡤࡼ࠳ࡺࡶ࠰ࡪࡸ࡫ࡴ࠳ࡩ࠮࡮ࡲࡻࡨࡿ࠭ࡥࡷࡦ࡬ࡴࡽࠧ഑")
def l1llllll1l1ll1l1ll_fwb_(url):
    content = l11ll11l11ll1l1ll_fwb_(url)
    out=[]
    l111llll11ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠧࠨࠩ࠿ࡸࡧࡵࡤࡺࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡦࡴࡪࡹ࠿ࠩࠪࠫഒ"),re.DOTALL).findall(content)
    for l111l1l111ll1l1ll_fwb_ in l111llll11ll1l1ll_fwb_:
        l1llll1lll1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠨࠩࠪࡀࡹࡸࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡳࡀࠪࠫࠬഓ"),re.DOTALL).findall(l111l1l111ll1l1ll_fwb_)
        for l1lll1ll1l1ll_fwb_ in l1llll1lll1ll1l1ll_fwb_:
            l111111ll1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠩࠪࠫࡁࡺࡤࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡦࡁࠫࠬ࠭ഔ"),re.DOTALL).findall(l1lll1ll1l1ll_fwb_)
            host = re.compile(l1l111ll1l1ll_fwb_ (u"ࠪࠫࠬࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࠫࠬക")).findall(l111111ll1ll1l1ll_fwb_[0]) if len(l111111ll1ll1l1ll_fwb_)>1 else l1l111ll1l1ll_fwb_ (u"ࠫࠬഖ")
            version = l111111ll1ll1l1ll_fwb_[1].strip(l1l111ll1l1ll_fwb_ (u"ࠬࡂ࠾ࠨഗ")) if len(l111111ll1ll1l1ll_fwb_)>2 else l1l111ll1l1ll_fwb_ (u"࠭ࠧഘ")
            quality = l111111ll1ll1l1ll_fwb_[2].strip(l1l111ll1l1ll_fwb_ (u"ࠧ࠽ࡀࠪങ")) if len(l111111ll1ll1l1ll_fwb_)>3 else l1l111ll1l1ll_fwb_ (u"ࠨࠩച")
            href = re.compile(l1l111ll1l1ll_fwb_ (u"ࠩࠪࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࠫࠬഛ")).findall(l111111ll1ll1l1ll_fwb_[3])if len(l111111ll1ll1l1ll_fwb_)>4 else l1l111ll1l1ll_fwb_ (u"ࠪࠫജ")
            if href:
                href=href[0]
                href = urllib.unquote(_111lllll1ll1l1ll_fwb_(href))
                if l1l111ll1l1ll_fwb_ (u"ࠫࡱ࡯࡮࡬࡫࠱ࡳࡳࡲࡩ࡯ࡧࠪഝ") in href:
                    data = l11ll11l11ll1l1ll_fwb_(href)
                    l1lllll1111ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠬ࠭ࠧ࠽࡫ࡩࡶࡦࡳࡥࠩ࠰࠭ࡃ࠮ࡂ࠯ࡪࡨࡵࡥࡲ࡫࠾ࠨࠩࠪഞ"),re.DOTALL).findall(data)
                    if l1lllll1111ll1l1ll_fwb_:
                        src = re.compile(l1l111ll1l1ll_fwb_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫട")).findall(l1lllll1111ll1l1ll_fwb_[0])
                        href = src[0] if src else href
                href = urllib.unquote(_111lllll1ll1l1ll_fwb_(href))
                host = host[0] if host else l1l111ll1l1ll_fwb_ (u"ࠧࠨഠ")
                l111l11l11ll1l1ll_fwb_ = urlparse(href).netloc
                l1l11111ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"ࠨࡷࡵࡰࠬഡ") : urllib.unquote(href),
                    l1l111ll1l1ll_fwb_ (u"ࠩࡷ࡭ࡹࡲࡥࠨഢ"): l1l111ll1l1ll_fwb_ (u"ࠥ࡟ࠪࡹ࡝ࠡࠧࡶ࠰ࠥࠫࡳࠣണ") %(host,version,quality),
                    l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡵࡳࡵࠩത"): host }
                out.append(l1l11111ll1l1ll_fwb_)
    return out
def l1l11l111ll1l1ll_fwb_(url):
    content = l11ll11l11ll1l1ll_fwb_(url)
    l1111l1l11ll1l1ll_fwb_ = l1111lll11ll1l1ll_fwb_.l1lllllll11ll1l1ll_fwb_(l111111l11ll1l1ll_fwb_)
    l11111l111ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠧࢂࡃࡰࡱ࡮࡭ࡪࡃࠥࡴࠨࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠥࡴࠤഥ") % (l1111l1l11ll1l1ll_fwb_, l1llll1ll11ll1l1ll_fwb_)
    l11l1111l1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"࠭ࠧࠨ࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࠬ࠭ദ")).findall(content)
    l111l1lll1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠧࠨധ")
    for l11l111l11ll1l1ll_fwb_ in l11l1111l1ll1l1ll_fwb_:
        if l1l111ll1l1ll_fwb_ (u"ࠨ࠰࡭ࡴ࡬࠭ന") in l11l111l11ll1l1ll_fwb_:
            l111l1lll1ll1l1ll_fwb_ = _111lllll1ll1l1ll_fwb_(l11l111l11ll1l1ll_fwb_)
            break
    l111l1lll1ll1l1ll_fwb_ = l111l1lll1ll1l1ll_fwb_ + l11111l111ll1l1ll_fwb_
    ids = [(a.start(), a.end()) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠩࠪࠫࡁࡪࡩࡷࠢ࡬ࡨࡂࠨࡳࡦࡣࡶࡳࡳ࠳࡜ࡥ࠭ࠪࠫࠬഩ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11l11ll11ll1l1ll_fwb_ = content[ ids[i][1]:ids[i+1][0] ]
        l111ll1l11ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠪࠫࠬࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡨࡃࡢࡳࠫ࠾ࡷࡨࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡤ࠿࡞ࡶ࠮ࡁࡺࡤ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࠫࠬപ"),re.DOTALL).findall(l11l11ll11ll1l1ll_fwb_)
        for l1111l1111ll1l1ll_fwb_,title,href in l111ll1l11ll1l1ll_fwb_:
            title = title.replace(l1l111ll1l1ll_fwb_ (u"ࠫࡡࡴࠧഫ"),l1l111ll1l1ll_fwb_ (u"ࠬࠦࠧബ"))
            title = re.sub(l1l111ll1l1ll_fwb_ (u"ࡸࠧࠨࠩࠩ࠲࠯ࡁࠧࠨࠩഭ"),l1l111ll1l1ll_fwb_ (u"ࠧࠨമ"),title)
            l1llll1l111ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠨࠩࠪࡷ࠭ࡢࡤࠬࡁࠬࡩ࠭ࡢࡤࠬࡁࠬࠫࠬ࠭യ")).findall(l1111l1111ll1l1ll_fwb_)
            if l1l111ll1l1ll_fwb_ (u"ࠩࡶࡩࡷ࡯ࡡ࡭ࡧࠪര") in href:
                l1l11111ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡷ࡫ࡦࠨറ")  : _111lllll1ll1l1ll_fwb_(href),
                    l1l111ll1l1ll_fwb_ (u"ࠫࡵࡲ࡯ࡵࠩല"): l1l111ll1l1ll_fwb_ (u"ࠬ࠭ള"),
                    l1l111ll1l1ll_fwb_ (u"࠭ࡴࡪࡶ࡯ࡩࠬഴ") : l1l111ll1l1ll_fwb_ (u"ࠧࠦࡵࠣࠩࡸ࠭വ")%(l1111l1111ll1l1ll_fwb_,l111l1l1l1ll1l1ll_fwb_(title.strip())),
                    l1l111ll1l1ll_fwb_ (u"ࠨ࡫ࡰ࡫ࠬശ"):l111l1lll1ll1l1ll_fwb_,
                    l1l111ll1l1ll_fwb_ (u"ࠩࡶࡩࡦࡹ࡯࡯ࠩഷ"): int(l1llll1l111ll1l1ll_fwb_[0][0]) if l1llll1l111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠪࠫസ"),
                    l1l111ll1l1ll_fwb_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࠬഹ"): int(l1llll1l111ll1l1ll_fwb_[0][1]) if l1llll1l111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠬ࠭ഺ"),
                    }
                out.append(l1l11111ll1l1ll_fwb_)
    return out
def l111lll1l1ll1l1ll_fwb_(m):
    return l1l111ll1l1ll_fwb_ (u"࠭ࡨࡳࡧࡩࡁ഻ࠧ࠭")+urllib.unquote(m.group(1))
def l111l1ll11ll1l1ll_fwb_(l111ll1111ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࡧ࡫࡯ࡱ഼ࠬ"),l111111111ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪഽ")):
    content = l11ll11l11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧࡩࡧࡸ࠯ࡶࡹ࠳࡫࡯࡬࡮ࡻ࠰ࡳࡳࡲࡩ࡯ࡧ࠲ࠫാ"))
    selected = []
    if l111ll1111ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠪࡪ࡮ࡲ࡭ࠨി"):
        if l111111111ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ീ"):
            l11l11ll11ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠬ࠭ࠧ࠽ࡷ࡯ࠤ࡮ࡪ࠽ࠣࡨ࡬ࡰࡹ࡫ࡲ࠮ࡥࡤࡸࡪ࡭࡯ࡳࡻࠥࠤࡨࡲࡡࡴࡵࡀࠦ࡫࡯࡬ࡵࡧࡵࠤࡲࡻ࡬ࡵ࡫ࡳࡰࡪ࠳ࡳࡦ࡮ࡨࡧࡹࠦࡴࡦࡴࡰ࠱ࡱ࡯ࡳࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧࠨࠩു"),re.DOTALL).findall(content)[0]
            selected = re.compile(l1l111ll1l1ll_fwb_ (u"࠭ࠧࠨ࠾࡯࡭ࠥࡪࡡࡵࡣ࠰࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࡛࡟ࡀࡠ࠮ࡃࡢࡳࠫ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀ࠿࠳ࡱ࡯࠾ࠨࠩࠪൂ"),re.MULTILINE).findall(l11l11ll11ll1l1ll_fwb_)
        elif l111111111ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠧࡺࡧࡤࡶࠬൃ"):
            l11l11ll11ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠨࠩࠪࡀࡺࡲࠠࡪࡦࡀࠦ࡫࡯࡬ࡵࡧࡵ࠱ࡾ࡫ࡡࡳࠤࠣࡧࡱࡧࡳࡴ࠿ࠥࡪ࡮ࡲࡴࡦࡴࠣࡱࡺࡲࡴࡪࡲ࡯ࡩ࠲ࡹࡥ࡭ࡧࡦࡸࠥࡺࡥࡳ࡯࠰ࡰ࡮ࡹࡴࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ࠧࠨൄ"),re.DOTALL).findall(content)[0]
            selected = re.compile(l1l111ll1l1ll_fwb_ (u"ࠩࠪࠫࡁࡲࡩࠡࡦࡤࡸࡦ࠳ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࡞ࡢࡃࡣࠪ࠿࡞ࡶ࠮ࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠮ࠫࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃࡂ࠯࡭࡫ࡁࠫࠬ࠭൅"),re.MULTILINE).findall(l11l11ll11ll1l1ll_fwb_)
        elif l111111111ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫെ"):
            l11l11ll11ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠫࠬ࠭࠼ࡶ࡮ࠣ࡭ࡩࡃࠢࡧ࡫࡯ࡸࡪࡸ࠭ࡤࡱࡸࡲࡹࡸࡹࠣࠢࡦࡰࡦࡹࡳ࠾ࠤࡩ࡭ࡱࡺࡥࡳࠢࡰࡹࡱࡺࡩࡱ࡮ࡨ࠱ࡸ࡫࡬ࡦࡥࡷࠤࡹ࡫ࡲ࡮࠯࡯࡭ࡸࡺࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬ࠭ࠧേ"),re.DOTALL).findall(content)[0]
            selected = re.compile(l1l111ll1l1ll_fwb_ (u"ࠬ࠭ࠧ࠽࡮࡬ࠤࡩࡧࡴࡢ࠯࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡡ࡞࠿࡟࠭ࡂࡡࡹࠪ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠱࠮ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠾࠲ࡰ࡮ࡄࠧࠨࠩൈ"),re.MULTILINE).findall(l11l11ll11ll1l1ll_fwb_)
    elif l111ll1111ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"࠭ࡳࡦࡴ࡬ࡥࡱ࠭൉"):
        if l111111111ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠧࡨࡣࡷࡹࡳ࡫࡫ࠨൊ"):
            selected = re.compile(l1l111ll1l1ll_fwb_ (u"ࠨࠩࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࡟ࡸࡣ࠺࠰࠱ࡦࡨࡦ࠳࡯࡯࡮࡬ࡲࡪ࠴ࡰ࡭࠱ࡶࡩࡷ࡯ࡡ࡭ࡧ࠰࡫ࡦࡺࡵ࡯ࡧ࡮࠳࠳࠰࠿ࠪࠤ࡞ࡠࡹࡢ࡮ࠡ࡟࠭ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧࠨࠩോ")).findall(content)
        elif l111111111ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠩࡵࡳࡰ࠭ൌ"):
            selected = re.compile(l1l111ll1l1ll_fwb_ (u"ࠪࠫࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵࡡࡳ࡞࠼࠲࠳ࡨࡪࡡ࠮ࡱࡱࡰ࡮ࡴࡥ࠯ࡲ࡯࠳ࡸ࡫ࡲࡪࡣ࡯ࡩ࠲ࡸ࡯࡬࠱࡟ࡨࢀ࠺ࡽ࠰ࠫࠥࡂ࠭ࡢࡤࡼ࠶ࢀ࠭ࡁ࠵ࡡ࠿്ࠩࠪࠫ")).findall(content)
    if selected:
        l1111llll1ll1l1ll_fwb_ = [x[0] for x in selected]
        l1llll1l1l1ll1l1ll_fwb_ = [l1l111ll1l1ll_fwb_ (u"ࠫࠥ࠭ൎ").join(x[1:]) for x in selected]
        return (l1llll1l1l1ll1l1ll_fwb_,l1111llll1ll1l1ll_fwb_)
    return False
def search(l111ll1ll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠬࡧ࡫ࡢࡦࡨࡱ࡮ࡧࠠࡱࡣࡱࡥࠬ൏")):
    url=l1l111ll1l1ll_fwb_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤࡦࡤࡼ࠳ࡺࡶ࠰ࡵࡽࡹࡰࡧࡪࠨ൐")
    content = l11ll11l11ll1l1ll_fwb_(url,data=l1l111ll1l1ll_fwb_ (u"ࠧࡱࡪࡵࡥࡸ࡫࠽ࠨ൑")+l111ll1ll1ll1l1ll_fwb_)
    l1111l1l11ll1l1ll_fwb_ = l1111lll11ll1l1ll_fwb_.l1lllllll11ll1l1ll_fwb_(l111111l11ll1l1ll_fwb_)
    l11111l111ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠣࡾࡆࡳࡴࡱࡩࡦ࠿ࠨࡷ࡛ࠫࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠨࡷࠧ൒") % (l1111l1l11ll1l1ll_fwb_, l1llll1ll11ll1l1ll_fwb_)
    ids = [(a.start(), a.end()) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡤࡱ࡯࠱ࡽࡹ࠭࡝ࡦࡾ࠵ࢂࡡ࡞ࠣ࡟࠭ࠦࡃ࠭൓"), content)]
    ids.append( (-1,-1) )
    l111l111l1ll1l1ll_fwb_=[]
    l111ll11l1ll1l1ll_fwb_=[]
    for i in range(len(ids[:-1])):
        l11l11ll11ll1l1ll_fwb_ = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile(l1l111ll1l1ll_fwb_ (u"ࠪࠫࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࠬ࠭ൔ")).search(l11l11ll11ll1l1ll_fwb_)
        title = re.compile(l1l111ll1l1ll_fwb_ (u"ࠫࠬ࠭ࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠧࠨൕ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
        l1111l11l1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠬ࠭ࠧࡥࡣࡷࡥ࠲ࡩ࡯࡯ࡶࡨࡲࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧࠨࠩൖ")).search(l11l11ll11ll1l1ll_fwb_)
        l111l1lll1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"࠭ࠧࠨ࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࠬ࠭ൗ")).search(l11l11ll11ll1l1ll_fwb_)
        year =  re.compile(l1l111ll1l1ll_fwb_ (u"ࠧࠨࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡺࡧࡤࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ࠧࠨ൘")).search(l11l11ll11ll1l1ll_fwb_)
        l1lllll1l11ll1l1ll_fwb_ =  re.compile(l1l111ll1l1ll_fwb_ (u"ࠨࠩࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡴࡤࡸࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧࠨࠩ൙")).search(l11l11ll11ll1l1ll_fwb_)
        if href and title:
            l111l1lll1ll1l1ll_fwb_ = l111l1lll1ll1l1ll_fwb_.group(1) if l111l1lll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠩࠪ൚")
            l111l1lll1ll1l1ll_fwb_ = l111l1lll1ll1l1ll_fwb_ + l11111l111ll1l1ll_fwb_
            l1l11111ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡷ࡫ࡦࠨ൛")   : href.group(1),
                l1l111ll1l1ll_fwb_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ൜")  : l111l1l1l1ll1l1ll_fwb_(title.group(1)),
                l1l111ll1l1ll_fwb_ (u"ࠬࡶ࡬ࡰࡶࠪ൝")   : l111l1l1l1ll1l1ll_fwb_(l1111l11l1ll1l1ll_fwb_.group(1)) if l1111l11l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"࠭ࠧ൞"),
                l1l111ll1l1ll_fwb_ (u"ࠧࡪ࡯ࡪࠫൟ")    : l111l1lll1ll1l1ll_fwb_,
                l1l111ll1l1ll_fwb_ (u"ࠨࡴࡤࡸ࡮ࡴࡧࠨൠ") : l1lllll1l11ll1l1ll_fwb_.group(1) if l1lllll1l11ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠩࠪൡ"),
                l1l111ll1l1ll_fwb_ (u"ࠪࡽࡪࡧࡲࠨൢ")   : year.group(1) if year else l1l111ll1l1ll_fwb_ (u"ࠫࠬൣ"),
                    }
            if l1l111ll1l1ll_fwb_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡥࡱ࡫࠯ࠨ൤") in l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡨࡳࡧࡩࠫ൥")]:
                l111ll11l1ll1l1ll_fwb_.append(l1l11111ll1l1ll_fwb_)
            else:
                l111l111l1ll1l1ll_fwb_.append(l1l11111ll1l1ll_fwb_)
    return l111l111l1ll1l1ll_fwb_,l111ll11l1ll1l1ll_fwb_
def search(l111ll1ll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࡥࡱ࡯࡭ࡳࡧࠧ൦")):
    l1111ll111ll1l1ll_fwb_ = {
        l1l111ll1l1ll_fwb_ (u"ࠨࡊࡲࡷࡹ࠭൧"):l1l111ll1l1ll_fwb_ (u"ࠩࡤࡴ࡮࠴ࡳࡦࡣࡵࡧ࡭࡯ࡱ࠯ࡺࡼࡾࠬ൨"),
        l1l111ll1l1ll_fwb_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ൩"):l1l111ll1l1ll_fwb_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠷࠰࠴࠿ࠥ࡝ࡏࡘ࠸࠷࠿ࠥࡸࡶ࠻࠷࠵࠲࠵࠯ࠠࡈࡧࡦ࡯ࡴ࠵࠲࠱࠳࠳࠴࠶࠶࠱ࠡࡈ࡬ࡶࡪ࡬࡯ࡹ࠱࠸࠶࠳࠶ࠧ൪"),
        l1l111ll1l1ll_fwb_ (u"ࠬࡇࡣࡤࡧࡳࡸࠬ൫"):l1l111ll1l1ll_fwb_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯࠮ࠣࡸࡪࡾࡴ࠰࡬ࡤࡺࡦࡹࡣࡳ࡫ࡳࡸ࠱ࠦࠪ࠰ࠬ࠾ࠤࡶࡃ࠰࠯࠲࠴ࠫ൬"),
        l1l111ll1l1ll_fwb_ (u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡍࡣࡱ࡫ࡺࡧࡧࡦࠩ൭"):l1l111ll1l1ll_fwb_ (u"ࠨࡧࡱ࠱࡚࡙ࠬࡦࡰ࠾ࡵࡂ࠶࠮࠶ࠩ൮"),
        l1l111ll1l1ll_fwb_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ൯"):l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨࡪࡡࡹ࠰ࡷࡺ࠴ࡽࡹࡴࡼࡸ࡯࡮ࡽࡡࡳ࡭ࡤࡃࡵ࡮ࡲࡢࡵࡨࡁࡩࡵ࡭ࠨ൰"),
        l1l111ll1l1ll_fwb_ (u"ࠫࡔࡸࡩࡨ࡫ࡱࠫ൱"):l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡥࡣࡻ࠲ࡹࡼࠧ൲"),
        l1l111ll1l1ll_fwb_ (u"࠭ࡃࡰࡰࡱࡩࡨࡺࡩࡰࡰࠪ൳"):l1l111ll1l1ll_fwb_ (u"ࠧ࡬ࡧࡨࡴ࠲ࡧ࡬ࡪࡸࡨࠫ൴"),
        l1l111ll1l1ll_fwb_ (u"ࠨࡒࡵࡥ࡬ࡳࡡࠨ൵"):l1l111ll1l1ll_fwb_ (u"ࠩࡱࡳ࠲ࡩࡡࡤࡪࡨࠫ൶")}
    url=l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡶࡩ࠯ࡵࡨࡥࡷࡩࡨࡪࡳ࠱ࡼࡾࢀ࠯ࡢࡲ࡬࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡷ࠽ࠦࡵࠩࡩࡳ࡭ࡩ࡯ࡧࡎࡩࡾࡃ࠳࠹࠷ࡦ࠴࠵ࡧࡦ࠲࠲࠹࠻࠻ࡧ࠳࠶࠹࠵ࡨ࠽࠾࠰࠶࠷ࡨ࠷࠷ࡩ࠴࠲ࡥ࠷ࠪࡵࡧࡧࡦ࠿࠳ࠪ࡮ࡺࡥ࡮ࡵࡓࡩࡷࡖࡡࡨࡧࡀ࠹࠵ࠬࡧࡳࡱࡸࡴࡂ࠷ࠧ൷")
    try:
        req = urllib2.Request(url%l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠫࠥ࠭൸"),l1l111ll1l1ll_fwb_ (u"ࠬ࠱ࠧ൹")),data=None,headers=l1111ll111ll1l1ll_fwb_)
        response = urllib2.urlopen(req,timeout=10)
        dd = json.loads(response.read())
    except:
        dd={}
    data = dd.get(l1l111ll1l1ll_fwb_ (u"࠭࡭ࡢ࡫ࡱࠫൺ"),{}).get(l1l111ll1l1ll_fwb_ (u"ࠧࡳࡧࡦࡳࡷࡪࡳࠨൻ"),[])
    l111l111l1ll1l1ll_fwb_=[]
    l111ll11l1ll1l1ll_fwb_=[]
    for item in data:
        href = item.get(l1l111ll1l1ll_fwb_ (u"ࠨࡷࡵࡰࠬർ"),l1l111ll1l1ll_fwb_ (u"ࠩࠪൽ"))
        title = item.get(l1l111ll1l1ll_fwb_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩൾ"),l1l111ll1l1ll_fwb_ (u"ࠫࠬൿ"))
        title = re.sub(l1l111ll1l1ll_fwb_ (u"ࡷ࠭ࠧࠨ࠾࡞࠳ࡢ࠰ࡥ࡮ࡀࠪࠫࠬ඀"),l1l111ll1l1ll_fwb_ (u"࠭ࠠࠨඁ"),title)
        l1111l11l1ll1l1ll_fwb_ = item.get(l1l111ll1l1ll_fwb_ (u"ࠧࡣࡱࡧࡽࠬං"),l1l111ll1l1ll_fwb_ (u"ࠨࠩඃ"))
        if href and title:
            year = re.search(l1l111ll1l1ll_fwb_ (u"ࠩ࡟ࡨࢀ࠺ࡽࠨ඄"),title)
        l1l11111ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡷ࡫ࡦࠨඅ") : href,
            l1l111ll1l1ll_fwb_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪආ") : l111l1l1l1ll1l1ll_fwb_(title),
            l1l111ll1l1ll_fwb_ (u"ࠬࡶ࡬ࡰࡶࠪඇ") : l111l1l1l1ll1l1ll_fwb_(l1111l11l1ll1l1ll_fwb_) if l1111l11l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"࠭ࠧඈ"),
            l1l111ll1l1ll_fwb_ (u"ࠧࡪ࡯ࡪࠫඉ") : l1l111ll1l1ll_fwb_ (u"ࠨࠩඊ"),
            l1l111ll1l1ll_fwb_ (u"ࠩࡼࡩࡦࡸࠧඋ") : year.group() if year else l1l111ll1l1ll_fwb_ (u"ࠪࠫඌ"),
                }
        if l1l111ll1l1ll_fwb_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡤࡰࡪ࠵ࠧඍ") in l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡲࡦࡨࠪඎ")]:
            l111ll11l1ll1l1ll_fwb_.append(l1l11111ll1l1ll_fwb_)
        else:
            l111l111l1ll1l1ll_fwb_.append(l1l11111ll1l1ll_fwb_)
    return l111l111l1ll1l1ll_fwb_,l111ll11l1ll1l1ll_fwb_
def l111l1l1l1ll1l1ll_fwb_(l111ll1ll1ll1l1ll_fwb_):
    return l111ll1ll1ll1l1ll_fwb_
