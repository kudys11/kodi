# -*- coding: utf-8 -*-
import sys
l1ll11ll1l1ll_fwb_ = sys.version_info [0] == 2
l1111ll1l1ll_fwb_ = 2048
l1l1l1ll1l1ll_fwb_ = 7
def l1l111ll1l1ll_fwb_ (keyedStringLiteral):
	global l11ll1ll1l1ll_fwb_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll1l1ll_fwb_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os,json,base64
import l1111lll11ll1l1ll_fwb_,cookielib
from urlparse import urlparse
l11l1l1ll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡰࡤࡷࡿ࡫࠭࡬࡫ࡱࡳ࠳ࡺࡶ࠰ࠩᒐ")
l11lll1111ll1l1ll_fwb_ = 10
l1llll1ll11ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠵࠺࠱࠴࠳࠸࠵࠷࠶࠱࠽࠼ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ᒑ")
try:
    import l1l1111ll1ll1l1ll_fwb_
except:
    pass
l111111l11ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࡴࠪࡲࡰࡺࡶ࠯ࡥࡲࡳࡰ࡯ࡥࠨᒒ")
l1llllll111ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠪࠫᒓ")
def l11ll11l11ll1l1ll_fwb_(url,data=None,header={}):
    l11l11l1l1ll1l1ll_fwb_ = cookielib.LWPCookieJar()
    cookies=l1l111ll1l1ll_fwb_ (u"ࠫࠬᒔ")
    try:
        if l111111l11ll1l1ll_fwb_ and os.path.exists(l111111l11ll1l1ll_fwb_):
            l11l11l1l1ll1l1ll_fwb_.load(l111111l11ll1l1ll_fwb_,True,True)
            cookies = l1l111ll1l1ll_fwb_ (u"ࠬࡁࠧᒕ").join([l1l111ll1l1ll_fwb_ (u"࠭ࠥࡴ࠿ࠨࡷࠬᒖ")%(c.name,c.value) for c in l11l11l1l1ll1l1ll_fwb_])
    except:
        l11l11l1l1ll1l1ll_fwb_ = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l11l11l1l1ll1l1ll_fwb_))
    urllib2.install_opener(opener)
    headers={l1l111ll1l1ll_fwb_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᒗ"): l1llll1ll11ll1l1ll_fwb_}
    headers.update(header)
    req = urllib2.Request(url,data,headers)
    if cookies:
        req.add_header(l1l111ll1l1ll_fwb_ (u"ࠣࡅࡲࡳࡰ࡯ࡥࠣᒘ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11lll1111ll1l1ll_fwb_)
        l111111l1ll1l1ll_fwb_ = response.read()
        response.close()
        l11l11l1l1ll1l1ll_fwb_.save(l111111l11ll1l1ll_fwb_, ignore_discard = True)
    except:
        l111111l1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠩࠪᒙ")
    return l111111l1ll1l1ll_fwb_
url=l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡳࡧࡳࡻࡧ࠰࡯࡮ࡴ࡯࠯ࡶࡹ࠳࡫࡯࡬࡮࠱ࡻࡼ࠲࠸࠰࠲࠹ࠪᒚ")
def l11111lll1ll1l1ll_fwb_(url,l1111ll1l1ll1l1ll_fwb_):
    l11l11l1l1ll1l1ll_fwb_ = cookielib.LWPCookieJar()
    try:
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l11l11l1l1ll1l1ll_fwb_))
        urllib2.install_opener(opener)
        req = urllib2.Request(url,None,{l1l111ll1l1ll_fwb_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᒛ"): l1llll1ll11ll1l1ll_fwb_})
        response = urllib2.urlopen(req,timeout=l11lll1111ll1l1ll_fwb_)
        l11111l111ll1l1ll_fwb_ = response.headers[l1l111ll1l1ll_fwb_ (u"ࠬࡹࡥࡵ࠯ࡦࡳࡴࡱࡩࡦࠩᒜ")]
        response.close()
        l1l111l111ll1l1ll_fwb_=os.path.dirname(l1111ll1l1ll1l1ll_fwb_)
        if not os.path.exists(l1l111l111ll1l1ll_fwb_):
            os.makedirs(l1l111l111ll1l1ll_fwb_)
        if l11l11l1l1ll1l1ll_fwb_:
            l11l11l1l1ll1l1ll_fwb_.save(l1111ll1l1ll1l1ll_fwb_, ignore_discard = True)
    except:
        l11111l111ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"࠭ࠧᒝ")
    return l11l11l1l1ll1l1ll_fwb_
def l1111ll11ll1l1ll_fwb_(url,l111lll1ll1l1ll_fwb_=1,group=l1l111ll1l1ll_fwb_ (u"ࠧࠨᒞ")):
    if l1l111ll1l1ll_fwb_ (u"ࠨࡁࡳࡥ࡬࡫࠽ࠨᒟ") in url:
        url = url.replace(l1l111ll1l1ll_fwb_ (u"ࠩࡂࡴࡦ࡭ࡥ࠾ࠩᒠ"),l1l111ll1l1ll_fwb_ (u"ࠪࡃࡵࡧࡧࡦ࠿ࠨࡨࠬᒡ") %l111lll1ll1l1ll_fwb_)
    else:
        url += l1l111ll1l1ll_fwb_ (u"ࠫ࠴࠭ᒢ") if url[-1] != l1l111ll1l1ll_fwb_ (u"ࠬ࠵ࠧᒣ") else l1l111ll1l1ll_fwb_ (u"࠭ࠧᒤ")
        url = url + l1l111ll1l1ll_fwb_ (u"ࠧࡀࡲࡤ࡫ࡪࡃࠥࡥࠩᒥ") %l111lll1ll1l1ll_fwb_
    content = l11ll11l11ll1l1ll_fwb_(url)
    out=[]
    l1llllllll1ll1l1ll_fwb_=False
    l11l111111ll1l1ll_fwb_=False
    ids = []
    if group:
        idx = [(m.start(0), m.end(0)) for m in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠨ࠾࡫࠷ࡃ࠭ᒦ"), content,re.IGNORECASE) ]
        idx.append( (content.find(l1l111ll1l1ll_fwb_ (u"ࠩ࠿ࡪࡴࡵࡴࡦࡴࡁࠫᒧ")),content.find(l1l111ll1l1ll_fwb_ (u"ࠪࡀ࡫ࡵ࡯ࡵࡧࡵࡂࠬᒨ"))) )
        for i in range(len(idx[:-1])):
            l11ll1l1l1ll1l1ll_fwb_=content[ idx[i][0]:idx[i+1][0] ]
            if group in l11ll1l1l1ll1l1ll_fwb_:
                print group
                content = l11ll1l1l1ll1l1ll_fwb_
                ids = [(a.start(), a.end()) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳ࡸࡴ࠯࡟ࡨ࠰࠭ᒩ"), content)]
                ids.append( (-1,-1) )
                break
        for i in range(len(ids[:-1])):
            l11l11ll11ll1l1ll_fwb_ = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile(l1l111ll1l1ll_fwb_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᒪ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
            title = re.compile(l1l111ll1l1ll_fwb_ (u"࠭ࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᒫ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
            l111l1lll1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠧ࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᒬ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
            l1111l1l1l1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡲࡢࡶࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪᒭ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
            year =  re.compile(l1l111ll1l1ll_fwb_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡺࡧࡤࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᒮ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
            if href and title:
                l111l1lll1ll1l1ll_fwb_ = l111l1lll1ll1l1ll_fwb_.group(1) if l111l1lll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠪࠫᒯ")
                if l111l1lll1ll1l1ll_fwb_.startswith(l1l111ll1l1ll_fwb_ (u"ࠫ࠴࠵ࠧᒰ")):
                    l111l1lll1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫᒱ")+l111l1lll1ll1l1ll_fwb_
                l1l11111ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"࠭ࡨࡳࡧࡩࠫᒲ")   : href.group(1),
                    l1l111ll1l1ll_fwb_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᒳ")  : l111l1l1l1ll1l1ll_fwb_(title.group(1)),
                    l1l111ll1l1ll_fwb_ (u"ࠨ࡫ࡰ࡫ࠬᒴ")    : l111l1lll1ll1l1ll_fwb_,
                    l1l111ll1l1ll_fwb_ (u"ࠩࡵࡥࡹ࡯࡮ࡨࠩᒵ") : l1111l1l1l1ll1l1ll_fwb_.group(1) if l1111l1l1l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠪࠫᒶ"),
                    l1l111ll1l1ll_fwb_ (u"ࠫࡾ࡫ࡡࡳࠩᒷ")   : year.group(1) if year else l1l111ll1l1ll_fwb_ (u"ࠬ࠭ᒸ"),
                        }
                out.append(l1l11111ll1l1ll_fwb_)
    else:
        l1lllll1l1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"࠭࠼ࡶ࡮ࠣࡧࡱࡧࡳࡴ࠿࡞ࠦࡡ࠭࡝ࡤ࡮ࡨࡥࡷ࡬ࡩࡹࠢࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࡡࠢ࡝ࠩࡠࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᒹ"),re.DOTALL).findall(content)
        l1lllll1l1ll1l1ll_fwb_ = urllib.unquote(l1lllll1l1ll1l1ll_fwb_[0]) if l1lllll1l1ll1l1ll_fwb_ else content
        l1llllllll1ll1l1ll_fwb_=False
        if l1lllll1l1ll1l1ll_fwb_.find( l1l111ll1l1ll_fwb_ (u"ࠧࡀࡲࡤ࡫ࡪࡃࠥࡥࠩᒺ") %(l111lll1ll1l1ll_fwb_+1))>-1:
            l1llllllll1ll1l1ll_fwb_ = l111lll1ll1l1ll_fwb_+1
        idx = content.find(l1l111ll1l1ll_fwb_ (u"ࠨ࠾࡫࠷ࡃ࠭ᒻ"))
        if idx: content = content[0:idx]
        ids = [(a.start(), a.end()) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡤࡱ࡯࠱ࡽࡹ࠭࡝ࡦࠣࡧࡴࡲ࠭ࡴ࡯࠰ࡠࡩࠦࡣࡰ࡮࠰ࡰ࡬࠳࡜ࡥࠩᒼ"), content)]
        ids.append( (-1,-1) )
        for i in range(len(ids[:-1])):
            l11l11ll11ll1l1ll_fwb_ = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile(l1l111ll1l1ll_fwb_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᒽ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
            title = re.compile(l1l111ll1l1ll_fwb_ (u"ࠫࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᒾ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
            l111l1lll1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠬࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᒿ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
            l1111l1l1l1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡷࡧࡴࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᓀ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
            year =  re.compile(l1l111ll1l1ll_fwb_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡿࡥࡢࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᓁ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
            if href and title:
                l111l1lll1ll1l1ll_fwb_ = l111l1lll1ll1l1ll_fwb_.group(1) if l111l1lll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠨࠩᓂ")
                if l111l1lll1ll1l1ll_fwb_.startswith(l1l111ll1l1ll_fwb_ (u"ࠩ࠲࠳ࠬᓃ")):
                    l111l1lll1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩᓄ")+l111l1lll1ll1l1ll_fwb_
                l1l11111ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡸࡥࡧࠩᓅ")   : href.group(1),
                    l1l111ll1l1ll_fwb_ (u"ࠬࡺࡩࡵ࡮ࡨࠫᓆ")  : l111l1l1l1ll1l1ll_fwb_(title.group(1)),
                    l1l111ll1l1ll_fwb_ (u"࠭ࡩ࡮ࡩࠪᓇ")    : l111l1lll1ll1l1ll_fwb_,
                    l1l111ll1l1ll_fwb_ (u"ࠧࡳࡣࡷ࡭ࡳ࡭ࠧᓈ") : l1111l1l1l1ll1l1ll_fwb_.group(1) if l1111l1l1l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠨࠩᓉ"),
                    l1l111ll1l1ll_fwb_ (u"ࠩࡼࡩࡦࡸࠧᓊ")   : year.group(1) if year else l1l111ll1l1ll_fwb_ (u"ࠪࠫᓋ"),
                        }
                out.append(l1l11111ll1l1ll_fwb_)
        l11l111111ll1l1ll_fwb_ = l111lll1ll1l1ll_fwb_-1 if l111lll1ll1l1ll_fwb_>1 else False
    return (out, (l11l111111ll1l1ll_fwb_,l1llllllll1ll1l1ll_fwb_))
def l1lllll11l11ll1l1ll_fwb_(url):
    content = l11ll11l11ll1l1ll_fwb_(url)
    token = re.search(l1l111ll1l1ll_fwb_ (u"ࠫࡳࡧ࡭ࡦ࠿ࠥࡣࡹࡵ࡫ࡦࡰࠥࠤࡹࡿࡰࡦ࠿ࠥ࡬࡮ࡪࡤࡦࡰࠥࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࠬᓌ"),content).group(1)
    l1lllll11ll1ll1l1ll_fwb_ = re.search(l1l111ll1l1ll_fwb_ (u"ࠬࡹࡩࡵࡧ࡮ࡩࡾࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨᓍ"),content).group(1)
    params = {l1l111ll1l1ll_fwb_ (u"࠭࡟ࡵࡱ࡮ࡩࡳ࠭ᓎ"):l1l111ll1l1ll_fwb_ (u"ࠧࡎࡩ࡝ࡑࡇ࠷ࡗࡧ࠶ࡘࡆࡌࡶࡨ࡚ࡈ࠴࡭࠻࠹࡭ࡐ࠶࠹࠻ࡼࡾࡇ࠹ࡕ࠸࡯࠺ࡩ࡫ࡱ࠶ࡐࡓ࡯࠭ᓏ"),
            l1l111ll1l1ll_fwb_ (u"ࠨࡩ࠰ࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡲࡦࡵࡳࡳࡳࡹࡥࠨᓐ"):l1l111ll1l1ll_fwb_ (u"ࠩ࠳࠷ࡆࡎࡊࡠࡘࡸࡺࡼࡽ࡫ࡌࡈ࠴ࡍ࠾ࡒࡎࡩࡗࡕࡖࡸࡖࡊࡴࡓࡒ࠹ࡤ࡙࡬ࡉࡳࡊࡵ࡛࠿ࡢࡰࡴࡅࡥ࡚࡝ࡱ࡮ࡰࡴࡒࡉ࡬ࡱࡉ࠳ࡳࡘࡎࡖࡹ࡮ࡳࡘࡻࡑࡒ࡫࡫࠶ࡻ࡬࠻ࡴࡗࡨࡃࡰࡆࡳࡽࡖࡤ࡜ࡅ࡚ࡺ࡭࡭ࡎࡌ࡬࡚ࡨࡶࡌ࠷࠯ࡗ࠶ࡨࡐࡇࡶ࠷ࡩࡈࡐࡳࡅࡴࡺࡤ࡞ࡸ࠷ࡏࡒࡉࡔࡼࡵ࠾ࡴࡐࡴ࠵࡝ࡵࡧࡖࡤࡃ࡙ࡴࡪࡖࡥࡵࡓ࡯ࡆ࡛࠶ࡹࡂ࠺ࡪࡘࡈࡗࡣࡱ࡯ࡱࡪ࡞ࡪࡏࡔࡥࡔ࡯ࡽ࡛࠹ࡰࡡࡶ࠹ࡖ࠺ࡳ࡫ࡒ࠷ࡌࡴࡼ࠲ࡒࡤࡥ࡬ࡌ࡜࠹ࡔࡋ࠷ࡓ࠽ࡧ࠭ࡗࡔࡄ࡚࡝ࡸࡕࡻࡲࡩ࠺ࡽࡿࡵࡦࡸ࡜ࡷࡺ࡞࠳ࡉࡺࡋࡥࡤࡈࡳ࡚ࡓࡆ࠽࡚࠽ࡄ࡙࠲࡭ࡪ࡯ࡈࡊࡅ࡯࡬ࡰࡏࡧࡢ࠷ࡗࡇࡖࡩ࡜ࡃ࡭ࡧࡊ࠱࡯ࡌࡷ࠸ࡔࡎࡴ࠼࠻ࡕࡖࡪ࡯ࡾ࡝ࡇࡌࡐࡈࡲ࡬࠸ࡏࡗࡢ࡜࡚࠽࡯ࡒࡥ࠱ࡈ࠶ࡱ࡛࡫࡭ࡗࡖࡔ࠱࠶࠹ࡰ࠱ࡑࡄࡽࡳࡽࡵࡰࡃࡗ࡞࡜ࡌࡴࡩࡇࡏ࠼ࡈ࠶ࡎࡌࡏࡘࡦࡩ࡜ࡧ࠶ࡦ࠰ࡣ࠻࠸࠸࡬ࡡࡅࡻࡉ࠷ࡒ࠷ࡍࡧ࠸࡝ࡰࡵࡂ࠻ࡩࡰࡖࡉࡅࡎࡩࡘ࠹࡭ࢀࡌ࡮࠺ࡕࡣࡐ࠹ࡆࡌࡣࡉ࡯ࡕࡶࡩࡶࡗࡖ࠷ࡲࡸ࠭ࡵ࡚ࡽ࠻ࡻࡹࡴࡍ࠻ࡅࡍࡕ࡞ࡪࡒࡹ࠹࠼࡞࠷ࡵ࡮࡭ࡢ࠻ࡷࡗࡶࡌࡌࡪࡍࡖࡇ࠲ࡏࡨࡥ࠹ࡼࡧࡔࡂࡆࡉ࠵࡬ࡧࡃࡶࡵ࡜ࡑ࠹ࡪ࠱࠵ࡐࡋ࠽ࡋ࠻࠲࡬ࡇ࠷ࡰࡷࡪࡢࡢ࡛࠵࡙ࡘ࠿ࡵࡪࡐࡆࡵࡊ࡬࡙ࡩࡃࡦࡾ࡝ࡿࡆࡨࡺࡻࡵࡇࡐ࠵࠹ࡄ࠹ࡔࡕࢀ࠰࡬࠵ࡐ࠻࠲࡞ࡱ࡛ࡕࡷࡔࡿࡧࡍࡑ࠶ࡐࡈࡗࡌࡲ࠵ࡻࡸࡎ࠶ࡇ࡮࠸ࡦࡲࡲ࠹࡯࡭࠷࠻ࡦࡓ࠽ࡶࡃ࠱ࡻࡹ࡫ࡦࡿࡗࡹࡵࡤࡰࡒ࠾ࡊࡍࡅࡇ࡭࡙࠽ࡖ࡮ࡕ࡮ࡥ࠼࠾ࡇ࡚ࡦ࠳ࡆࡩࡽࡓࡠࡦࡆ࠵࡙ࡾࡔࡪ࡭࡫࡚࠽ࡩࡈ࠺ࡣࡧࡎ࡝࡟࠵ࡂࡶࡆࡎࡈࡏ࠲ࡦ࡬ࡷࡅࡨࡩࡹ࡚࠷࡬ࡽࡨ࡯ࡥ࠮ࡼࡹࡒ࡟࡫ࡪࡷࡣࡆ࠼ࡌ࡟ࡉࡧࡹࡎࡒࡪ࡟ࡁ࠴ࡘ࡬࠺࠵࡭࡙ࡏࡩࡌࡩࡻ࠸ࡡ࠶ࡗࡐࡍࡖࡠࡦ࡚࠶ࡽ࡛࡫ࡥࡰ࡫ࡵ࠻ࡘ࠼ࡽࡄࡍࡳࡵ࠴࠽ࡱࡒࡉࡶࡕ࠻࡭ࡿࡢ࡮࡯ࡎࡷࡻ࡟ࡷࡈࡈ࡮࡭ࡉࡓࡶࡦࡧࡴࡕࡽ࠳ࡶࡻࡘࡇ࠸ࡨ࠿ࡴࡦ࠹࠼࡞ࡵࡕࡵࡓࡕࡰࡅࡓ࠾ࡩࡪ࠴ࡄࡶࡩ࡟ࡈࡘࡤࡢࡑ࠻࠿ࡡ࠱ࡊࡩࡪࡦ࡭ࡺࡑࡶࡘ࠼ࡒࡉࡣ࠷ࡎࡺࡹ࠽࡚࠶࠶ࡹ࠴ࡼࡶ࠽ࡉࡍࡰࡔࡖࡴࡩࡣࡱࡲࡐࡻࡈ࠿ࡂ࠹ࡖ࠻ࡰࡿࡪࡉࡲࡕ࠵ࡽࡑࡉࡳࡨࡍࡻࡾࡨࡒࡆࡐࡧࡴࡴࡹࡥࡑࡂࡋࡧࡒ࡬࡯ࡢࡺࡈ࠶ࡵ࠼ࡊ࡚ࡦࡥ࡯࠸࠶ࡸ࠲ࡩࡺࡑ࡯ࡍࡶ࠶࡮ࡖ࠴࡯࡯ࡱࡃ࠹ࡩࡺࡾࡈࡨࡧࡷࡌࡄࡳࡶ࠽ࡺࡶ࡜ࡘ࡜ࡻࡵࡑࡄࡷࡈࡉ࡚ࡔࡁࡶࡥࡌࡸࡍࡓ࠹ࡖࡥࡐࡈࡖ࠺ࡩࡎ࡛ࡓࡻࡇ࡝ࡢࡴࡗࡩࡩࡿࡇࡂࡪࡑ࡚ࡲࡪ࠶ࡆ࠸ࡓࡔࡧࡊࡥࡋࡗ࡛࠷ࡽࡊ࠺ࡒࡇࡕࡈࡲࡹ࡝࡬࠺ࡰࡼࡽ࡝࠿ࡏ࠳ࡑ࡜࠺࡭ࡋࡩ࠳ࡧ࠴ࡋ࠺ࡈࡁࡦ࡚ࡇࡣ࠶ࡿࡩࡍ࠻ࡶ࠱ࡸ࠼࠸ࡱ࡮࡬࡯ࡋࡌ࡟࡭ࡄࡵࡕ࡞࠶ࡶࡤࡣࡓࡲࡒ࠼࠹ࡒࡕࡩࡲࡷ࡛ࡁ࡯ࡈ࠸࡬࠼ࡈࡇࡸ࡮ࡗ࡯ࡶࡈࡧ࡭ࡹ࠹࠶ࡺࡕࡷ࠶ࡒࡱ࠶ࡰࡺࡹࡨࡔࡓ࠱ࡇ࡚ࡔࡱࡩࡘࡼ࡛ࡧ࠰ࡧࡶ࡫ࡼࡊࡰࡒࡠ࠵࠴࡚ࡈ࡛ࡶࡃ࡯ࡇ࠷ࡳࡽࡶࡪࡑࡒࡅࡗࡈ࡫ࡏࡺࡺࡾࡓࡒࡶࡻࡄ࠰ࡐࡍࡗ࠴ࡊࡹࡷ࠼ࡗ࡝ࡖ࡫࠳ࡋࡈ࠷࠸ࡑ࡚ࡃ࡚࡮ࡋ࡚ࡈࡖ࡜ࡑࡑ࡞ࡵࡧ࠴ࡴࡉࡖ࠶࠷ࡘࡪ࠴ࡢ࠻ࡋ࡛ࡣࡖࡥࡒࡋࡋࡓࡺࡻ࡭ࡆࡱࡎࡵࡦࡱ࡚࠻࠵࠸ࡲ࡫࠶ࡦࡨࡈࡲࡎࡩࡗࡼࡲࡒ࡝࡭࠲ࡶࡔ࡬ࡥࡉࡐࡱࡥࡆࡪࡰࡹ࡚࠷࠹ࡃ࡫ࡑࡘࡌࡍ࡛ࡪࡲࡑ࡮ࡳࡊࡖࡸࡋࡰࡺࡻࡂ࠱࠻ࡌࡊࡈࡱࡅ࠱ࡏࡢ࠺ࡩࢀࡐࡺ࡫࠵࠷࡬࡯ࡤ࡛ࡔ࡭࡝ࡴࡪ࠸ࡱࡳ࡙࠶࠵ࡍ࠴࡚࠳ࡥࡇ࠻ࡠࡺࡵࡶ࡯ࡈࡧࡩࡒࡤࡥࡇࡪࡐࡧࡤࡤࡌࡸ࠽ࡊࡶࡇࡎࡥ࡙ࡐࡖࡴ࡮ࡃࡼࡶࡩ࡙࡙࠰ࡄࡉࡰ࠼ࡓ࠷ࡎ࡭ࡷࡇࡧ࡯ࡓࡨࡸࡰࡽࡱ࠽ࡺࡥࡕࡌࡌࡩ࡬࡫ࡳࡪࡲࡶࡌ࠼ࡗ࡚࠹ࡗࡼࡪ࡬ࡩࡹࡇࡒࡧ࠴࠲࠾ࡣࡐ࡭࡮ࡱࡐ࡭࡬ࡦࡇࡘࡈ࡛࡞ࡃࡵࡃ࡮࡞ࡘࡨ࡙ࡕ࠲࠶ࡗ࠲ࡺࡕࡲࡍࡻ࡭ࡰࡗ࠷ࡒࡺࡍࡓࡊ࡜ࡲࡉࡏ࠳࡝࠺ࡽࡖ࡫ࡎࡑࡘࡸ࠶ࡔࡘࡈࡘࡉࡉࡋ࡯࠶࡫࡛ࡺ࠲࠼ࡱࡸ࠻࠻ࡾࡺ࠼ࡹࡪ࡙࡬ࡕ࠷ࡶࡆࡣ࠹ࡖࡦࡽࡼࡦ࡮࡚࡫ࡏ࠸ࡷࡆࡘࡸ࡮࡙ࡈࡲࡸ࡫ࡩࡅ࡬࠼ࡱࡖࡶ࠷ࡷ࡯ࡰࡊࡎ࠱࠳࠴ࡗࡇ࠻ࡒࡦࡱࡆࡎࡺࡒࡤࡧࡊࡏࡸࡔ࡮࠲ࡇࡳ࡝࠶ࡼ࠽ࡐࡩࡉࡎࡆ࡯࡫ࡶࡥࡃࡏ࠶࡫ࡉࡒࡆࡪ࡛࠵ࡏࡺ࡙ࡏ࠺ࡼࡅ࡚࡯ࡐࡏ࡬ࡻ࡯ࡆࡈࡴࡂࡤࡰࡽࡑ࠽ࡳ࠮ࡍࡳ࠶࡜ࡨࡶࡷࡔࡴࡐ࠹࠹࠵࠸ࡶࡗ࠺ࡲࡔࡘࡄࡳࡪ࠱࡫ࡴࡍ࠲࡫ࡔ࠽ࡴ࡟ࡁࡵࡒ࡬ࡱࡏࡵࡤࡷࡆ࠻࡞ࡈࡑ࡙࠶ࡄ࠼ࡱࡨ࠹ࡡࡐࡷࡇࡍࡖࢀࡶ࠷ࡎࡗࡣࡴࡶࡥࡷࡘࡤ࠽࠼ࡵࡆ࠱࡮ࡨࡨ࡮࡛࠸ࡨࡑ࠹࠷ࡊࡻࡱ࡮࠸ࡪࡍ࠺ࡑ࠰࡫࠷࡙ࡔࡪ࡜ࡶࡱࡥ࠳ࡾࡾࡧ࡙ࡗ࡚ࡉ࠽ࡹࡾ࠵ࡒࡼࡉࡏࡹࡕࡅࡂࡅࡢࡏࡦ࡚ࡨ࠮ࡕࡸ࠻࡚ࡐ࡮ࡘ࠶ࡔࡦࡍ࡛ࡩ࠺ࡒ࡯ࡷ࡬࡭ࡑࡑ࠲ࡍࡅ࠺࠼࡟ࡨࡪࡗࡓ࠽ࡈࡪࡑ࡛࠵ࡹ࠽ࡑ࠹࠺ࡊࡇ࡬ࡤࡪࡰ࠵ࡇࡥ࠵ࡊ࠶ࡔ࠺ࡃ࠴ࡼࡹࢀࡲࡣ࡚࠶࡞࡬ࡌ࠰࠶ࡹࡆࡉࡏ࡫࠵ࡍ࡯࠵ࡵ࡝࠶ࡕࡥ࡜࡛ࡽࡤࡇࡖࡶࡳ࠺ࡗ࠸ࡋࡍ࠴ࡏ࡭࡬ࡏࡏ࡚࠮ࡍࡥ࡮ࡪ࠽ࡐࡰࡨࡴࡰࡽࡍ࡭࠱࠻ࡌ࡬ࡏࡾࡒࡤࡦࡈ࠸࡯࡞࡚ࡨࡴ࡯ࡨ࠼ࡧࡐࡩࡸ࠳ࡆ࡙࠷ࡑ࠺࠳ࡇ࡜ࡷࡘ࠸࡭ࡎࡷ࡝࠻ࡔࡒࡃࡵ࡝ࡪࡰ࡮࠹ࡏࠩᓑ")
           }
    data=urllib.urlencode(params)
    a=l11ll11l11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡳࡺࡵ࠮ࡪࡱ࠲࡫ࡴ࠵ࡆ࡬ࡤࡦࡹࠬᓒ"),data)
def _1llll1l11l1ll1l1ll_fwb_(url,host=l1l111ll1l1ll_fwb_ (u"ࠫࠬᓓ")):
    l1lllll11111ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠬ࠭ᓔ")
    if url.startswith(l1l111ll1l1ll_fwb_ (u"࠭ࡨࡵࡶࡳࠫᓕ")):
        if l1l111ll1l1ll_fwb_ (u"ࠧ࡭࡫ࡱ࡯࡮࠴࡯࡯࡮࡬ࡲࡪ࠭ᓖ") in url:
            content = l11ll11l11ll1l1ll_fwb_(url)
            l1lll11111ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠨࡶࡲࡴ࠳ࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠠ࠾ࠢ࡞ࡠࠬࠨ࡝ࠩ࠰࠭ࡃ࠮ࡡ࡜ࠨࠤࡠ࠿ࠬᓗ")).search(content)
            if l1lll11111ll1l1ll_fwb_:
                l1lllll11111ll1l1ll_fwb_ = l1lll11111ll1l1ll_fwb_.group(1)
        if l1l111ll1l1ll_fwb_ (u"ࠩࡲࡹࡴ࠴ࡩࡰࠩᓘ") in url:
            l1lllll11111ll1l1ll_fwb_ = url
        else:
            req = urllib2.Request(url)
            req.add_header(l1l111ll1l1ll_fwb_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᓙ"), l1l111ll1l1ll_fwb_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡐ࡙࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠸࠽࠴࠰࠯࠴࠸࠺࠹࠴࠹࠸ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩᓚ"))
            try:
                response = urllib2.urlopen(req)
                if response:
                    l1lllll11111ll1l1ll_fwb_=response.url
                    if l1lllll11111ll1l1ll_fwb_==url:
                        content=response.read()
                        l1lll11111ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭࠭ࠧࠦࡣ࡭ࡣࡶࡷࠬᓛ")).findall(content)
                        for l in l1lll11111ll1l1ll_fwb_:
                            if host in l:
                                l1lllll11111ll1l1ll_fwb_ = l
                                break
                    response.close()
            except:
                pass
    return l1lllll11111ll1l1ll_fwb_
def l1llll1ll111ll1l1ll_fwb_(url,content=None):
    if not content:
        content = l11ll11l11ll1l1ll_fwb_(url)
    out  =[]
    l1lllll1111ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠠࠩ࠰࠭ࡃ࠮ࡂ࠯ࡪࡨࡵࡥࡲ࡫࠾ࠨᓜ"),re.DOTALL).findall(content)
    names = re.compile(l1l111ll1l1ll_fwb_ (u"ࠧ࠽ࡷ࡯ࠤࡨࡲࡡࡴࡵࡀࠦ࡮ࡪࡔࡢࡤࡶࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩᓝ"),re.DOTALL).findall(content)
    if names:
        names = [x.strip() for x in re.compile(l1l111ll1l1ll_fwb_ (u"ࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠩᓞ"),re.DOTALL).findall(names[0]) if x.strip()]
    else:
        names=[]
    for l1lllll111l1ll1l1ll_fwb_ in l1lllll1111ll1l1ll_fwb_:
        href = re.compile(l1l111ll1l1ll_fwb_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᓟ"),re.DOTALL).search(l1lllll111l1ll1l1ll_fwb_)
        if href:
            l1llll1ll1l1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡹࡺࡰࠨᓠ")+ urllib.unquote(href.group(1)).split(l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡺࡴࡱࠩᓡ"))[-1]
            if l1llll1ll1l1ll1l1ll_fwb_.startswith(l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡴࡵࡲࠪᓢ")) and not l1l111ll1l1ll_fwb_ (u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧᓣ") in l1llll1ll1l1ll1l1ll_fwb_ and not l1l111ll1l1ll_fwb_ (u"ࠧࡧࡣࡦࡩࡧࡵ࡯࡬ࠩᓤ") in l1llll1ll1l1ll1l1ll_fwb_:
                host = urlparse(l1llll1ll1l1ll1l1ll_fwb_).netloc
                l1l11111ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"ࠨࡷࡵࡰࠬᓥ") : l1llll1ll1l1ll1l1ll_fwb_,
                    l1l111ll1l1ll_fwb_ (u"ࠩࡷ࡭ࡹࡲࡥࠨᓦ"): l1l111ll1l1ll_fwb_ (u"ࠥ࡟ࠪࡹ࡝ࠣᓧ") %(host),
                    l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡵࡳࡵࠩᓨ"): host    }
                out.append(l1l11111ll1l1ll_fwb_)
    if len(names)==len(out):
        for l1l11111ll1l1ll_fwb_,name in zip(out,names):
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬࡺࡩࡵ࡮ࡨࠫᓩ")] += l1l111ll1l1ll_fwb_ (u"࠭ࠠࠦࡵࠪᓪ")%name
    return out
url=l1l111ll1l1ll_fwb_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡰࡤࡷࡿ࡫࠭࡬࡫ࡱࡳ࠳ࡺࡶ࠰ࡨ࡬ࡰࡲ࠵ࡸࡹ࠯࠵࠴࠶࠽ࠧᓫ")
def l1llll1lll11ll1l1ll_fwb_(url,content):
    data = l11ll11l11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡱࡥࡸࢀࡥ࠮࡭࡬ࡲࡴ࠴ࡴࡷ࠱ࡦࡥࡵࡺࡣࡩࡣ࠱࡮ࡵ࡭ࠧᓬ"))
    r=l1l1111ll1ll1l1ll_fwb_.l1l1111l11ll1l1ll_fwb_(data)
    l1llll1l1111ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠩࡦࡥࡵࡺࡣࡩࡣࡀࠩࡸࠬࡳࡶࡤࡰ࡭ࡹࡃࠧᓭ")%(r)
    data = l11ll11l11ll1l1ll_fwb_(url,l1llll1l1111ll1l1ll_fwb_)
    content = l11ll11l11ll1l1ll_fwb_(url)
    if content.find(l1l111ll1l1ll_fwb_ (u"ࠪࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࡨࡵࡶࡳࡷ࠿࠵࠯࡯ࡣࡶࡾࡪ࠳࡫ࡪࡰࡲ࠲ࡹࡼ࠯ࡤࡣࡳࡸࡨ࡮ࡡ࠯࡬ࡳ࡫ࠧࡄࠧᓮ"))>0:
        l1l1111ll1ll1l1ll_fwb_.l11lllll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞ࡄॅउࡩࠦࡣࡢࡲࡷࡧ࡭ࡧ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨᓯ"),l1l111ll1l1ll_fwb_ (u"ࠬࡔࡩࡦࠢࡲࠤࡹࡧ࡫ࡪࠢࡷࡩࡰࡹࡴࠡࡥ࡫ࡳࡩࢀࡩृࡱࠤࠫᓰ"),l1l111ll1l1ll_fwb_ (u"࠭ࡃࡻࡻࠣࡲࡦࠦࡰࡦࡹࡱࡳࠥࡰࡥࡴࡶࡨࡷࠥࡩࡺृࡱࡺ࡭ࡪࡱࡩࡦ࡯ࡂࠫᓱ"))
        content=l1l111ll1l1ll_fwb_ (u"ࠧࠨᓲ")
    return content
def l1llllll1l1ll1l1ll_fwb_(url):
    content = l11ll11l11ll1l1ll_fwb_(url)
    if content.find(l1l111ll1l1ll_fwb_ (u"ࠨ࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡴࡡࡴࡼࡨ࠱ࡰ࡯࡮ࡰ࠰ࡷࡺ࠴ࡩࡡࡱࡶࡦ࡬ࡦ࠴ࡪࡱࡩࠥࡂࠬᓳ"))>0:
        content = l1llll1lll11ll1l1ll_fwb_(url,content)
    l111llll111ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠩ࠿ࡸࡧࡵࡤࡺࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡦࡴࡪࡹ࠿ࠩᓴ"),re.DOTALL).findall(content)
    l111llll111ll1l1ll_fwb_ = l111llll111ll1l1ll_fwb_[0] if l111llll111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠪࠫᓵ")
    ids = [(a.start(), a.end()) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠫࡁࡺࡲ࠿ࠩᓶ"), l111llll111ll1l1ll_fwb_)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11l11ll11ll1l1ll_fwb_ = l111llll111ll1l1ll_fwb_[ ids[i][1]:ids[i+1][0] ]
        href=re.compile(l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᓷ")).search(l11l11ll11ll1l1ll_fwb_)
        l1lllll1l111ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"࠭ࡤࡢࡶࡤ࠱࡮࡬ࡲࡢ࡯ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᓸ")).search(l11l11ll11ll1l1ll_fwb_)
        info = l1l111ll1l1ll_fwb_ (u"ࠧࠨᓹ").join(re.compile(l1l111ll1l1ll_fwb_ (u"ࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠩᓺ"),re.DOTALL).findall(l11l11ll11ll1l1ll_fwb_))
        info = re.sub(l1l111ll1l1ll_fwb_ (u"ࠩࠣ࠯ࠬᓻ"),l1l111ll1l1ll_fwb_ (u"ࠪࠤࠬᓼ"),l111l1l1l1ll1l1ll_fwb_(info)).strip()
        if href:
            l1l11111ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"ࠫࡺࡸ࡬ࠨᓽ") : href.group(1),l1l111ll1l1ll_fwb_ (u"ࠬࡺࡩࡵ࡮ࡨࠫᓾ"): info,}
            out.append(l1l11111ll1l1ll_fwb_)
    return out
def l1l11l111ll1l1ll_fwb_(url):
    content = l11ll11l11ll1l1ll_fwb_(url)
    l111l1lll1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"࠭࠼ࡥ࡫ࡹࠤ࡮ࡪ࠽ࠣ࡫ࡷࡩࡲ࠳ࡨࡦࡣࡧࡰ࡮ࡴࡥࠣ࠰࠭ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩᓿ")).findall(content)
    l111l1lll1ll1l1ll_fwb_ = l111l1lll1ll1l1ll_fwb_[-1] if l111l1lll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠧࠨᔀ")
    out=[]
    l11l1llll1ll1l1ll_fwb_= content.find(l1l111ll1l1ll_fwb_ (u"ࠨࡑࡧࡧ࡮ࡴ࡫ࡪࠩᔁ"))
    l11ll11111ll1l1ll_fwb_= content.find(l1l111ll1l1ll_fwb_ (u"ࠩࡇࡳࡩࡧࡪࠡࡱࡧࡧ࡮ࡴࡥ࡬ࠩᔂ"))
    l1l11l1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᔃ"),re.DOTALL).findall(content[l11l1llll1ll1l1ll_fwb_:l11ll11111ll1l1ll_fwb_])
    for h,t in l1l11l1ll1l1ll_fwb_:
        t= l111l1l1l1ll1l1ll_fwb_(t.strip())
        t=re.sub(l1l111ll1l1ll_fwb_ (u"ࠫࠥ࠱ࠧᔄ"),l1l111ll1l1ll_fwb_ (u"ࠬࠦࠧᔅ"),t)
        l1llll1l111ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"࡛࠭ࡴࡕࡠࠬࡡࡪࠫࠪ࡝ࡈࡩࡢ࠮࡜ࡥ࠭ࠬࠫᔆ")).findall(t)
        l1l11111ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"ࠧࡩࡴࡨࡪࠬᔇ")  : h.strip(),
            l1l111ll1l1ll_fwb_ (u"ࠨࡲ࡯ࡳࡹ࠭ᔈ"): t,
            l1l111ll1l1ll_fwb_ (u"ࠩࡷ࡭ࡹࡲࡥࠨᔉ") : t,
            l1l111ll1l1ll_fwb_ (u"ࠪ࡭ࡲ࡭ࠧᔊ"):l111l1lll1ll1l1ll_fwb_,
            l1l111ll1l1ll_fwb_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࠫᔋ"): int(l1llll1l111ll1l1ll_fwb_[0][0]) if l1llll1l111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠬ࠭ᔌ"),
            l1l111ll1l1ll_fwb_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࠧᔍ"): int(l1llll1l111ll1l1ll_fwb_[0][1]) if l1llll1l111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠧࠨᔎ"),
            l1l111ll1l1ll_fwb_ (u"ࠨࡣ࡬ࡶࡪࡪࠧᔏ") : l1l111ll1l1ll_fwb_ (u"ࠩࠪᔐ")}
        out.append(l1l11111ll1l1ll_fwb_)
    return out
def l1llll1l1l11ll1l1ll_fwb_(out):
    l1llll1l1ll1ll1l1ll_fwb_={}
    l1l1l1lll1ll1l1ll_fwb_ = [x.get(l1l111ll1l1ll_fwb_ (u"ࠪࡷࡪࡧࡳࡰࡰࠪᔑ")) for x in out]
    for s in set(l1l1l1lll1ll1l1ll_fwb_):
        l1llll1l1ll1ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡘ࡫ࡺࡰࡰࠣࠩ࠵࠸ࡤࠨᔒ")%s]=[out[i] for i, j in enumerate(l1l1l1lll1ll1l1ll_fwb_) if j == s]
    return l1llll1l1ll1ll1l1ll_fwb_
def l11l1l11ll1l1ll_fwb_(url=l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡮ࡢࡵࡽࡩ࠲ࡱࡩ࡯ࡱ࠱ࡸࡻ࠵ࡳࡦࡴ࡬ࡥࡱ࡫࠭ࡰࡰ࡯࡭ࡳ࡫࠯ࠨᔓ")):
    content = l11ll11l11ll1l1ll_fwb_(url)
    l1llll1llll1ll1l1ll_fwb_=re.compile(l1l111ll1l1ll_fwb_ (u"࠭࠼ࡶ࡮ࠣ࡭ࡩࡃࠢࡴࡧࡵ࡭ࡪࡹ࠭࡭࡫ࡶࡸࠧࠦࡣ࡭ࡣࡶࡷࡂࠨࡦࡪ࡮ࡷࡩࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࠪᔔ"),re.DOTALL).findall(content)
    l1111l1ll1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠰ࡅࠩࠣ࡝࡟ࡶࡡࡴࠠ࡝ࡶࡠ࠮ࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠫࡀࠫࠥࠫᔕ")).findall(l1llll1llll1ll1l1ll_fwb_[0])
    out=[]
    for href,title in l1111l1ll1ll1l1ll_fwb_:
        l1l11111ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"ࠨࡪࡵࡩ࡫࠭ᔖ")  : href,
            l1l111ll1l1ll_fwb_ (u"ࠩࡳࡰࡴࡺࠧᔗ"): l1l111ll1l1ll_fwb_ (u"ࠪࠫᔘ"),
            l1l111ll1l1ll_fwb_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪᔙ") : l111l1l1l1ll1l1ll_fwb_(title),
            l1l111ll1l1ll_fwb_ (u"ࠬ࡯࡭ࡨࠩᔚ"):l1l111ll1l1ll_fwb_ (u"࠭ࠧᔛ")}
        out.append(l1l11111ll1l1ll_fwb_)
    return (out, (False,False))
def l111lll1l1ll1l1ll_fwb_(m):
    return l1l111ll1l1ll_fwb_ (u"ࠧࡩࡴࡨࡪࡂࠨࠧᔜ")+urllib.unquote(m.group(1))
def l111l1ll11ll1l1ll_fwb_(l111ll1111ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠨࡨ࡬ࡰࡲ࠭ᔝ"),l111111111ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫᔞ")):
    label=[]
    value=[]
    if l111ll1111ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠪࡪ࡮ࡲ࡭ࠨᔟ"):
        content = l11ll11l11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡴࡡࡴࡼࡨ࠱ࡰ࡯࡮ࡰ࠰ࡷࡺ࠴࡬ࡩ࡭࡯ࡼ࠱ࡴࡴ࡬ࡪࡰࡨ࠳ࠬᔠ"))
        if l111111111ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧᔡ"):
            l1llll1llll1ll1l1ll_fwb_=re.compile(l1l111ll1l1ll_fwb_ (u"࠭࠼ࡶ࡮ࠣ࡭ࡩࡃࠢࡧ࡫࡯ࡸࡪࡸ࠭ࡤࡣࡷࡩ࡬ࡵࡲࡺࠤࠣࡧࡱࡧࡳࡴ࠿ࠥࡪ࡮ࡲࡴࡦࡴࠣࡱࡺࡲࡴࡪࡲ࡯ࡩ࠲ࡹࡥ࡭ࡧࡦࡸࠥࡺࡥࡳ࡯࠰ࡰ࡮ࡹࡴࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࠬᔢ"),re.DOTALL).findall(content)[0]
            value=re.compile(l1l111ll1l1ll_fwb_ (u"ࠧࡥࡣࡷࡥ࠲࡯ࡤ࠾ࠤࠫࡠࡩ࠱ࠩࠣࠩᔣ")).findall(l1llll1llll1ll1l1ll_fwb_)
            label=re.compile(l1l111ll1l1ll_fwb_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠧࠧࡄࠨ࠯࠭ࡂ࠭ࡁ࠭ᔤ")).findall(l1llll1llll1ll1l1ll_fwb_)
        elif l111111111ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠩࡼࡩࡦࡸࠧᔥ"):
            l1llll1llll1ll1l1ll_fwb_=re.compile(l1l111ll1l1ll_fwb_ (u"ࠪࡀࡺࡲࠠࡪࡦࡀࠦ࡫࡯࡬ࡵࡧࡵ࠱ࡾ࡫ࡡࡳࠤࠣࡧࡱࡧࡳࡴ࠿ࠥࡪ࡮ࡲࡴࡦࡴࠣࡱࡺࡲࡴࡪࡲ࡯ࡩ࠲ࡹࡥ࡭ࡧࡦࡸࠥࡺࡥࡳ࡯࠰ࡰ࡮ࡹࡴࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࠬᔦ"),re.DOTALL).findall(content)[0]
            value=re.compile(l1l111ll1l1ll_fwb_ (u"ࠫࡩࡧࡴࡢ࠯࡬ࡨࡂࠨࠨ࡝ࡦ࠮࠭ࠧ࠭ᔧ")).findall(l1llll1llll1ll1l1ll_fwb_)
            label=re.compile(l1l111ll1l1ll_fwb_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠤࠤࡁࠬ࠳࠱࠿ࠪ࠾ࠪᔨ")).findall(l1llll1llll1ll1l1ll_fwb_)
        elif l111111111ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧᔩ"):
            l1llll1llll1ll1l1ll_fwb_=re.compile(l1l111ll1l1ll_fwb_ (u"ࠧ࠽ࡷ࡯ࠤ࡮ࡪ࠽ࠣࡨ࡬ࡰࡹ࡫ࡲ࠮ࡥࡲࡹࡳࡺࡲࡺࠤࠣࡧࡱࡧࡳࡴ࠿ࠥࡪ࡮ࡲࡴࡦࡴࠣࡱࡺࡲࡴࡪࡲ࡯ࡩ࠲ࡹࡥ࡭ࡧࡦࡸࠥࡺࡥࡳ࡯࠰ࡰ࡮ࡹࡴࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࠬᔪ"),re.DOTALL).findall(content)[0]
            value=re.compile(l1l111ll1l1ll_fwb_ (u"ࠨࡦࡤࡸࡦ࠳ࡩࡥ࠿ࠥࠬࡡࡪࠫࠪࠤࠪᔫ")).findall(l1llll1llll1ll1l1ll_fwb_)
            label=re.compile(l1l111ll1l1ll_fwb_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦࠨࠨ࠾ࠩ࠰࠮ࡃ࠮ࡂࠧᔬ")).findall(l1llll1llll1ll1l1ll_fwb_)
    elif l111ll1111ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠪࡷࡪࡸࡩࡢ࡮ࠪᔭ"):
        pass
    return (label,value)
def l111l1l1l1ll1l1ll_fwb_(l111ll1ll1ll1l1ll_fwb_):
    if isinstance(l111ll1ll1ll1l1ll_fwb_, unicode):
        l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.encode(l1l111ll1l1ll_fwb_ (u"ࠫࡺࡺࡦ࠮࠺ࠪᔮ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠬࠬ࡬ࡵ࠽ࡥࡶ࠴ࠬࡧࡵ࠽ࠪᔯ"),l1l111ll1l1ll_fwb_ (u"࠭ࠠࠨᔰ"))
    s=l1l111ll1l1ll_fwb_ (u"ࠧࡋ࡫ࡑࡧ࡟ࡉࡳ࠸ࠩᔱ")
    l111ll1ll1ll1l1ll_fwb_ = re.sub(s.decode(l1l111ll1l1ll_fwb_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨᔲ")),l1l111ll1l1ll_fwb_ (u"ࠩࠪᔳ"),l111ll1ll1ll1l1ll_fwb_)
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠪࡠࡳ࠭ᔴ"),l1l111ll1l1ll_fwb_ (u"ࠫࠬᔵ")).replace(l1l111ll1l1ll_fwb_ (u"ࠬࡢࡲࠨᔶ"),l1l111ll1l1ll_fwb_ (u"࠭ࠧᔷ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠧࠧࡰࡥࡷࡵࡁࠧᔸ"),l1l111ll1l1ll_fwb_ (u"ࠨࠩᔹ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠩࠩࡵࡺࡵࡴ࠼ࠩᔺ"),l1l111ll1l1ll_fwb_ (u"ࠪࠦࠬᔻ")).replace(l1l111ll1l1ll_fwb_ (u"ࠫࠫࡧ࡭ࡱ࠽ࡴࡹࡴࡺ࠻ࠨᔼ"),l1l111ll1l1ll_fwb_ (u"ࠬࠨࠧᔽ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"࠭ࠦࡰࡣࡦࡹࡹ࡫࠻ࠨᔾ"),l1l111ll1l1ll_fwb_ (u"ࠧࣴࠩᔿ")).replace(l1l111ll1l1ll_fwb_ (u"ࠨࠨࡒࡥࡨࡻࡴࡦ࠽ࠪᕀ"),l1l111ll1l1ll_fwb_ (u"ࠩࣖࠫᕁ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠪࠪࡦࡳࡰ࠼ࡱࡤࡧࡺࡺࡥ࠼ࠩᕂ"),l1l111ll1l1ll_fwb_ (u"ࠫࣸ࠭ᕃ")).replace(l1l111ll1l1ll_fwb_ (u"ࠬࠬࡡ࡮ࡲ࠾ࡓࡦࡩࡵࡵࡧ࠾ࠫᕄ"),l1l111ll1l1ll_fwb_ (u"࣓࠭ࠨᕅ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠧࠧࡣࡰࡴࡀ࠭ᕆ"),l1l111ll1l1ll_fwb_ (u"ࠨࠨࠪᕇ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠩ࡟ࡹ࠵࠷࠰࠶ࠩᕈ"),l1l111ll1l1ll_fwb_ (u"ࠪउࠬᕉ")).replace(l1l111ll1l1ll_fwb_ (u"ࠫࡡࡻ࠰࠲࠲࠷ࠫᕊ"),l1l111ll1l1ll_fwb_ (u"ࠬऊࠧᕋ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"࠭࡜ࡶ࠲࠴࠴࠼࠭ᕌ"),l1l111ll1l1ll_fwb_ (u"ࠧईࠩᕍ")).replace(l1l111ll1l1ll_fwb_ (u"ࠨ࡞ࡸ࠴࠶࠶࠶ࠨᕎ"),l1l111ll1l1ll_fwb_ (u"ࠩउࠫᕏ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠪࡠࡺ࠶࠱࠲࠻ࠪᕐ"),l1l111ll1l1ll_fwb_ (u"ࠫञ࠭ᕑ")).replace(l1l111ll1l1ll_fwb_ (u"ࠬࡢࡵ࠱࠳࠴࠼ࠬᕒ"),l1l111ll1l1ll_fwb_ (u"࠭घࠨᕓ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠧ࡝ࡷ࠳࠵࠹࠸ࠧᕔ"),l1l111ll1l1ll_fwb_ (u"ࠨॄࠪᕕ")).replace(l1l111ll1l1ll_fwb_ (u"ࠩ࡟ࡹ࠵࠷࠴࠲ࠩᕖ"),l1l111ll1l1ll_fwb_ (u"ࠪॅࠬᕗ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠫࡡࡻ࠰࠲࠶࠷ࠫᕘ"),l1l111ll1l1ll_fwb_ (u"ࠬॊࠧᕙ")).replace(l1l111ll1l1ll_fwb_ (u"࠭࡜ࡶ࠲࠴࠸࠹࠭ᕚ"),l1l111ll1l1ll_fwb_ (u"ࠧॄࠩᕛ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠨ࡞ࡸ࠴࠵࡬࠳ࠨᕜ"),l1l111ll1l1ll_fwb_ (u"ࣶࠩࠫᕝ")).replace(l1l111ll1l1ll_fwb_ (u"ࠪࡠࡺ࠶࠰ࡥ࠵ࠪᕞ"),l1l111ll1l1ll_fwb_ (u"ࠫࣘ࠭ᕟ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠬࡢࡵ࠱࠳࠸ࡦࠬᕠ"),l1l111ll1l1ll_fwb_ (u"࠭ज़ࠨᕡ")).replace(l1l111ll1l1ll_fwb_ (u"ࠧ࡝ࡷ࠳࠵࠺ࡧࠧᕢ"),l1l111ll1l1ll_fwb_ (u"ࠨड़ࠪᕣ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠩ࡟ࡹ࠵࠷࠷ࡢࠩᕤ"),l1l111ll1l1ll_fwb_ (u"ࠪॾࠬᕥ")).replace(l1l111ll1l1ll_fwb_ (u"ࠫࡡࡻ࠰࠲࠹࠼ࠫᕦ"),l1l111ll1l1ll_fwb_ (u"ࠬॿࠧᕧ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"࠭࡜ࡶ࠲࠴࠻ࡨ࠭ᕨ"),l1l111ll1l1ll_fwb_ (u"ࠧॽࠩᕩ")).replace(l1l111ll1l1ll_fwb_ (u"ࠨ࡞ࡸ࠴࠶࠽ࡢࠨᕪ"),l1l111ll1l1ll_fwb_ (u"ࠩॾࠫᕫ"))
    return l111ll1ll1ll1l1ll_fwb_
def search(l111ll1ll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠪࡨࡴࡳࠧᕬ")):
    url=l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡴࡡࡴࡼࡨ࠱ࡰ࡯࡮ࡰ࠰ࡷࡺ࠴ࡽࡹࡴࡼࡸ࡯࡮ࡽࡡࡳ࡭ࡤࡃࡵ࡮ࡲࡢࡵࡨࡁࠬᕭ")+l111ll1ll1ll1l1ll_fwb_
    content=l11ll11l11ll1l1ll_fwb_(url)
    l111l111l1ll1l1ll_fwb_=[]
    l111ll11l1ll1l1ll_fwb_=[]
    ids = [(a.start(), a.end()) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡲ࠭ࡴ࡯࠰ࡠࡩ࠱ࠧᕮ"), content)]
    ids.append( (-1,-1) )
    for i in range(len(ids[:-1])):
        l11l11ll11ll1l1ll_fwb_ = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile(l1l111ll1l1ll_fwb_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᕯ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
        title = re.compile(l1l111ll1l1ll_fwb_ (u"ࠧࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᕰ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
        l1111l11l1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࠦࡴࡦࡺࡷ࠱࡯ࡻࡳࡵ࡫ࡩࡽࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᕱ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
        l111l1lll1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᕲ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
        l1111l1l1l1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠪࡀ࠴ࡨ࠾࡝ࡵ࠭ࠬࡡࡪ࡜࠯࡞ࡧ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬᕳ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
        year =  re.compile(l1l111ll1l1ll_fwb_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡼࡩࡦࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᕴ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
        if href and title:
            l111l1lll1ll1l1ll_fwb_ = l111l1lll1ll1l1ll_fwb_.group(1).replace(l1l111ll1l1ll_fwb_ (u"ࠬ࠵ࡴࡩࡷࡰࡦ࠴࠭ᕵ"),l1l111ll1l1ll_fwb_ (u"࠭࠯ࡣ࡫ࡪ࠳ࠬᕶ")) if l111l1lll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠧࠨᕷ")
            l1l11111ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"ࠨࡪࡵࡩ࡫࠭ᕸ")   : href.group(1),
                l1l111ll1l1ll_fwb_ (u"ࠩࡷ࡭ࡹࡲࡥࠨᕹ")  : l111l1l1l1ll1l1ll_fwb_(title.group(1)),
                l1l111ll1l1ll_fwb_ (u"ࠪࡴࡱࡵࡴࠨᕺ")   : l111l1l1l1ll1l1ll_fwb_(l1111l11l1ll1l1ll_fwb_.group(1)) if l1111l11l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠫࠬᕻ"),
                l1l111ll1l1ll_fwb_ (u"ࠬ࡯࡭ࡨࠩᕼ")    : l111l1lll1ll1l1ll_fwb_,
                l1l111ll1l1ll_fwb_ (u"࠭ࡲࡢࡶ࡬ࡲ࡬࠭ᕽ") : l1111l1l1l1ll1l1ll_fwb_.group(1) if l1111l1l1l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠧࠨᕾ"),
                l1l111ll1l1ll_fwb_ (u"ࠨࡻࡨࡥࡷ࠭ᕿ")   : year.group(1) if year else l1l111ll1l1ll_fwb_ (u"ࠩࠪᖀ"),
                    }
            if l1l111ll1l1ll_fwb_ (u"ࠪ࠳࡫࡯࡬࡮ࠩᖁ") in l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡸࡥࡧࠩᖂ")]:
                l111l111l1ll1l1ll_fwb_.append(l1l11111ll1l1ll_fwb_)
            elif l1l111ll1l1ll_fwb_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡥࡱ࠭ᖃ")in l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡨࡳࡧࡩࠫᖄ")]:
                l111ll11l1ll1l1ll_fwb_.append(l1l11111ll1l1ll_fwb_)
    return l111l111l1ll1l1ll_fwb_,l111ll11l1ll1l1ll_fwb_
