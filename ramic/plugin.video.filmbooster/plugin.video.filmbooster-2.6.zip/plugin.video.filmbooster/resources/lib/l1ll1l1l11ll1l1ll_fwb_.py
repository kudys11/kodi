# -*- coding: utf-8 -*-
import sys
l1ll11ll1l1ll_fwb_ = sys.version_info [0] == 2
l1111ll1l1ll_fwb_ = 2048
l1l1l1ll1l1ll_fwb_ = 7
def l1l111ll1l1ll_fwb_ (keyedStringLiteral):
	global l11ll1ll1l1ll_fwb_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll1l1ll_fwb_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib
import urllib2
import hashlib
import json
import re
import datetime
l11l111lll1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠦ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡳ࡭࠰ࡩ࡭ࡱࡳࡷࡦࡤ࠱ࡴࡱ࠵ࡡࡱ࡫ࡂࠦཀྵ");
l11l1111l11ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠧࡷࡪࡤࡉ࡫࡛࠷ࡐ࡮ࡷࡉࡗ࠽ࡩ࡬ࡃࡵ࠵ࡸࡘࡤࡰ࡯ࡻࡔ࠶ࡷࠧཪ");
l11l1llll11ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠨࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡪ࡮ࡲ࡭ࡸࡧࡥ࠲ࡵࡲࠢཫ");
VERSION = l1l111ll1l1ll_fwb_ (u"ࠢ࠳࠰࠵ࠦཬ");
l11llll11l1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠣࡣࡱࡨࡷࡵࡩࡥࠤ཭");
l11ll111l11ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡦࡪ࡮ࡰࡻࡪࡨ࠮ࡱ࡮࠲ࡷࡪࡧࡲࡤࡪ࠲ࡰ࡮ࡼࡥࡀࡳࡀࠦ཮");
l11lllll1l1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠥࡠࡡࡩࠢ཯");
l11lll1l111ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠦࡡࡢࡡࠣ཰");
l1l11111111ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠧ࡮ࡴࡵࡲ࠽࠳࠴࠷࠮ࡧࡹࡦࡨࡳ࠴ࡰ࡭࠱ࡳࡳཱࠧ")
l11lll1111ll1l1ll_fwb_=10
from ramic import go
def l111llll1l1ll1l1ll_fwb_(l111ll1ll1ll1l1ll_fwb_):
    if type(l111ll1ll1ll1l1ll_fwb_) is not str:
        l111ll1ll1ll1l1ll_fwb_=l111ll1ll1ll1l1ll_fwb_.encode(l1l111ll1l1ll_fwb_ (u"࠭ࡵࡵࡨ࠰࠼ིࠬ"))
    s=l1l111ll1l1ll_fwb_ (u"ࠧࡋ࡫ࡑࡧ࡟ࡉࡳ࠸ཱིࠩ")
    l111ll1ll1ll1l1ll_fwb_ = re.sub(s.decode(l1l111ll1l1ll_fwb_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨུ")),l1l111ll1l1ll_fwb_ (u"ཱུࠩࠪ"),l111ll1ll1ll1l1ll_fwb_)
    l111ll1ll1ll1l1ll_fwb_ = re.sub(l1l111ll1l1ll_fwb_ (u"ࠪࡀࡧࡸ࡜ࡴࠬ࠲ࡂࠬྲྀ"),l1l111ll1l1ll_fwb_ (u"ࠫࡡࡴࠧཷ"),l111ll1ll1ll1l1ll_fwb_)
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠬࠬ࡮ࡣࡵࡳ࠿ࠬླྀ"),l1l111ll1l1ll_fwb_ (u"࠭ࠧཹ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠧࠧ࡮ࡷ࠿ࡧࡸ࠯ࠧࡩࡷ࠿ེࠬ"),l1l111ll1l1ll_fwb_ (u"ࠨཻࠢࠪ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠩࠩࡲࡩࡧࡳࡩ࠽ོࠪ"),l1l111ll1l1ll_fwb_ (u"ࠪ࠱ཽࠬ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠫࠫࡷࡵࡰࡶ࠾ࠫཾ"),l1l111ll1l1ll_fwb_ (u"ࠬࠨࠧཿ")).replace(l1l111ll1l1ll_fwb_ (u"࠭ࠦࡢ࡯ࡳ࠿ࡶࡻ࡯ࡵ࠽ྀࠪ"),l1l111ll1l1ll_fwb_ (u"ཱྀࠧࠣࠩ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠨࠨࡲࡥࡨࡻࡴࡦ࠽ࠪྂ"),l1l111ll1l1ll_fwb_ (u"ࣶࠩࠫྃ")).replace(l1l111ll1l1ll_fwb_ (u"ࠪࠪࡔࡧࡣࡶࡶࡨ࠿྄ࠬ"),l1l111ll1l1ll_fwb_ (u"ࠫࣘ࠭྅"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠬࠬࡡ࡮ࡲ࠾ࡳࡦࡩࡵࡵࡧ࠾ࠫ྆"),l1l111ll1l1ll_fwb_ (u"࠭ࣳࠨ྇")).replace(l1l111ll1l1ll_fwb_ (u"ࠧࠧࡣࡰࡴࡀࡕࡡࡤࡷࡷࡩࡀ࠭ྈ"),l1l111ll1l1ll_fwb_ (u"ࠨࣕࠪྉ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠩࠩࡥࡲࡶ࠻ࠨྊ"),l1l111ll1l1ll_fwb_ (u"ࠪࠪࠬྋ"))
    l111ll1ll1ll1l1ll_fwb_ = re.sub(l1l111ll1l1ll_fwb_ (u"ࠫࠫ࠴ࠫ࠼ࠩྌ"),l1l111ll1l1ll_fwb_ (u"ࠬ࠭ྍ"),l111ll1ll1ll1l1ll_fwb_)
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"࠭࡜ࡶ࠲࠴࠴࠺࠭ྎ"),l1l111ll1l1ll_fwb_ (u"ࠧआࠩྏ")).replace(l1l111ll1l1ll_fwb_ (u"ࠨ࡞ࡸ࠴࠶࠶࠴ࠨྐ"),l1l111ll1l1ll_fwb_ (u"ࠩइࠫྑ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠪࡠࡺ࠶࠱࠱࠹ࠪྒ"),l1l111ll1l1ll_fwb_ (u"ࠫऌ࠭ྒྷ")).replace(l1l111ll1l1ll_fwb_ (u"ࠬࡢࡵ࠱࠳࠳࠺ࠬྔ"),l1l111ll1l1ll_fwb_ (u"࠭आࠨྕ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠧ࡝ࡷ࠳࠵࠶࠿ࠧྖ"),l1l111ll1l1ll_fwb_ (u"ࠨछࠪྗ")).replace(l1l111ll1l1ll_fwb_ (u"ࠩ࡟ࡹ࠵࠷࠱࠹ࠩ྘"),l1l111ll1l1ll_fwb_ (u"ࠪजࠬྙ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠫࡡࡻ࠰࠲࠶࠵ࠫྚ"),l1l111ll1l1ll_fwb_ (u"ࠬैࠧྛ")).replace(l1l111ll1l1ll_fwb_ (u"࠭࡜ࡶ࠲࠴࠸࠶࠭ྜ"),l1l111ll1l1ll_fwb_ (u"ࠧूࠩྜྷ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠨ࡞ࡸ࠴࠶࠺࠴ࠨྞ"),l1l111ll1l1ll_fwb_ (u"ࠩेࠫྟ")).replace(l1l111ll1l1ll_fwb_ (u"ࠪࡠࡺ࠶࠱࠵࠶ࠪྠ"),l1l111ll1l1ll_fwb_ (u"ࠫै࠭ྡ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠬࡢࡵ࠱࠲ࡩ࠷ࠬྡྷ"),l1l111ll1l1ll_fwb_ (u"࠭ࣳࠨྣ")).replace(l1l111ll1l1ll_fwb_ (u"ࠧ࡝ࡷ࠳࠴ࡩ࠹ࠧྤ"),l1l111ll1l1ll_fwb_ (u"ࠨࣕࠪྥ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠩ࡟ࡹ࠵࠷࠵ࡣࠩྦ"),l1l111ll1l1ll_fwb_ (u"ࠪय़ࠬྦྷ")).replace(l1l111ll1l1ll_fwb_ (u"ࠫࡡࡻ࠰࠲࠷ࡤࠫྨ"),l1l111ll1l1ll_fwb_ (u"ࠬॠࠧྩ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"࠭࡜ࡶ࠲࠴࠻ࡦ࠭ྪ"),l1l111ll1l1ll_fwb_ (u"ࠧॻࠩྫ")).replace(l1l111ll1l1ll_fwb_ (u"ࠨ࡞ࡸ࠴࠶࠽࠹ࠨྫྷ"),l1l111ll1l1ll_fwb_ (u"ࠩॼࠫྭ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠪࡠࡺ࠶࠱࠸ࡥࠪྮ"),l1l111ll1l1ll_fwb_ (u"ࠫঁ࠭ྯ")).replace(l1l111ll1l1ll_fwb_ (u"ࠬࡢࡵ࠱࠳࠺ࡦࠬྰ"),l1l111ll1l1ll_fwb_ (u"࠭ॻࠨྱ"))
    return l111ll1ll1ll1l1ll_fwb_
l11l1l1l1l1ll1l1ll_fwb_ = go.get(l1l111ll1l1ll_fwb_ (u"ࠧࡥࡧࡦࡳࡩ࡫ࡈࡕࡏࡏࡩࡳࡺࡲࡪࡧࡶࠫྲ"),l111llll1l1ll1l1ll_fwb_)
def _11l111ll1ll1l1ll_fwb_(url,data=None):
    l1l111ll1l1ll_fwb_ (u"ࠣࠤࠥࠑࠏࠦࠠࠡࠢࡊࡩࡹࠦࡕࡳ࡮ࠣࡧࡴࡴࡴ࡯ࡧࡷࡲࡹࠓࠊࠡࠢࠣࠤࡷ࡫ࡴࡶࡴࡱ࠾ࠥࡹࡴࡳ࡫ࡱ࡫ࠒࠐࠠࠡࠢࠣࠦࠧࠨླ")
    headers = {l1l111ll1l1ll_fwb_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ྴ"): l1l111ll1l1ll_fwb_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰ࠡࠪࡏ࡭ࡳࡻࡸ࠼ࠢࡄࡲࡩࡸ࡯ࡪࡦࠣ࠸࠳࠷࠮࠲࠽ࠣࡋࡦࡲࡡࡹࡻࠣࡒࡪࡾࡵࡴࠢࡅࡹ࡮ࡲࡤ࠰ࡌࡕࡓ࠵࠹ࡃࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠸࠲࠶࠿ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠱࠹࠰࠳࠲࠶࠶࠲࠶࠰࠴࠺࠻ࠦࡍࡰࡤ࡬ࡰࡪࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠷࠱࠵࠾࠭ྵ"),
            }
    req = urllib2.Request(url, data, headers)
    response = urllib2.urlopen(req,timeout=l11lll1111ll1l1ll_fwb_)
    l111111l1ll1l1ll_fwb_ = response.read()
    response.close()
    return l111111l1ll1l1ll_fwb_
def l1111111ll1l1ll_fwb_(url=l1l111ll1l1ll_fwb_ (u"ࠫ࠴ࡶࡥࡳࡵࡲࡲ࠴ࡐࡡࡤ࡭࠱ࡒ࡮ࡩࡨࡰ࡮ࡶࡳࡳ࠭ྶ")):
    content = _11l111ll1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡩ࡭ࡱࡳࡷࡦࡤ࠱ࡴࡱ࠭ྷ")+url)
    out = []
    for item in re.findall(l1l111ll1l1ll_fwb_ (u"࠭࠼࡭࡫ࠣ࡭ࡩࡃࠢࡩ࡫ࡷࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄࠧྸ"),content,re.DOTALL):
        l1l11111ll1l1ll_fwb_={}
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡤࡱࡧࡩࠬྐྵ")]=l1l111ll1l1ll_fwb_ (u"ࠨ࡝ࡅࡡ࡟ࡴࡡ࡯ࡻࠣࡾ࠳࠴࠮࡜࠱ࡅࡡࠬྺ")
        year = re.findall(l1l111ll1l1ll_fwb_ (u"ࠩࠫࠬࡄࡀ࠱࠺ࡾ࠵࠴࠮ࡢࡤࡼ࠴ࢀ࠭ࠬྻ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪࡽࡪࡧࡲࠨྼ")]=year[0] if year else l1l111ll1l1ll_fwb_ (u"ࠫࠬ྽")
        l11l11l1111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠬࡪࡡࡵࡣ࠰ࠬࡄࡀࡦࡪ࡮ࡰࢀ࡮ࡪࠩ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ྾"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡤࡢࡶࡤࡣ࡫࡯࡬࡮ࠩ྿")] = l11l11l1111ll1l1ll_fwb_[0] if l11l11l1111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠧࠨ࿀")
        l111l1lll1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠨࡵࡵࡧࡂࠨࠨࡩࡶࡷࡴ࠳࠰࠿ࠪࠤࠪ࿁"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩ࡬ࡱ࡬࠭࿂")] = l111l1lll1ll1l1ll_fwb_[0][:-5]+l1l111ll1l1ll_fwb_ (u"ࠪ࠷࠳ࡰࡰࡨࠩ࿃") if l111l1lll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠫࠬ࿄")
        l1111l1ll1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࡝ࡡࠦࡢ࠱ࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ࿅"),item)
        if l1111l1ll1ll1l1ll_fwb_:
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡨࡳࡧࡩ࿆ࠫ")]  =l1111l1ll1ll1l1ll_fwb_[0][0]
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭࿇")] = l11l1l1l1l1ll1l1ll_fwb_(l1111l1ll1ll1l1ll_fwb_[0][1].strip() )
        if l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡪࡵࡩ࡫࠭࿈")] and l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ࿉")]:
            out.append(l1l11111ll1l1ll_fwb_)
    l11l111ll11ll1l1ll_fwb_ = [(l1l111ll1l1ll_fwb_ (u"ࠪࡥࡨࡺ࡯ࡳࡵࠪ࿊"),l1l111ll1l1ll_fwb_ (u"ࠫࡆࡱࡴࡰࡴࠪ࿋")),(l1l111ll1l1ll_fwb_ (u"ࠬࡪࡩࡳࡧࡦࡸࡴࡸࠧ࿌"),l1l111ll1l1ll_fwb_ (u"࠭ࡒࡦॾࡼࡷࡪࡸࠧ࿍")),(l1l111ll1l1ll_fwb_ (u"ࠧࡴࡥࡵࡩࡪࡴࡷࡳ࡫ࡷࡩࡷ࠭࿎"),l1l111ll1l1ll_fwb_ (u"ࠨࡕࡦࡩࡳࡧࡲࡻࡻࡶࡸࡦ࠭࿏"))]
    for l111lll11l1ll1l1ll_fwb_,code in l11l111ll11ll1l1ll_fwb_:
        l111llll111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠩ࠿ࡸࡧࡵࡤࡺࠢࡧࡥࡹࡧ࠭ࡱࡴࡲࡪࡪࡹࡳࡪࡱࡱࡁࠧࠫࡳࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡥࡳࡩࡿ࠾ࠨ࿐")%l111lll11l1ll1l1ll_fwb_,content,re.DOTALL)
        if l111llll111ll1l1ll_fwb_:
            l1llll1lll1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠪࡀࡹࡸࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡳࡀࠪ࿑"),l111llll111ll1l1ll_fwb_[0],re.DOTALL)
            for l1lll1ll1l1ll_fwb_ in l1llll1lll1ll1l1ll_fwb_:
                l1l11111ll1l1ll_fwb_={}
                l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡨࡵࡤࡦࠩ࿒")]=code
                year = re.findall(l1l111ll1l1ll_fwb_ (u"ࠬࡂࡳࡱࡣࡱࠤࡨࡲࡡࡴࡵࡀࠦ࡫࡯࡬࡮࡛ࡨࡥࡷࠨ࠾ࠩ࡞ࡧ࠯࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭࿓"),l1lll1ll1l1ll_fwb_)
                l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡹࡦࡣࡵࠫ࿔")]=year[0] if year else l1l111ll1l1ll_fwb_ (u"ࠧࠨ࿕")
                l11l11l1111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠨࡦࡤࡸࡦ࠳ࠨࡀ࠼ࡩ࡭ࡱࡳࡼࡪࡦࠬࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࿖"),l1lll1ll1l1ll_fwb_)
                l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡧࡥࡹࡧ࡟ࡧ࡫࡯ࡱࠬ࿗")] = l11l11l1111ll1l1ll_fwb_[0] if l11l11l1111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠪࠫ࿘")
                l111l1lll1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭࿙"),l1lll1ll1l1ll_fwb_)
                l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬ࡯࡭ࡨࠩ࿚")] = l111l1lll1ll1l1ll_fwb_[0][:-5]+l1l111ll1l1ll_fwb_ (u"࠭࠳࠯࡬ࡳ࡫ࠬ࿛") if l111l1lll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠧࠨ࿜")
                l1111l1ll1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬࡠࡤࠢ࡞࠭ࠬࠦࠥࡩ࡬ࡢࡵࡶࡁࠧࡲࡩ࡯࡭ࠣࡷ࠲࠷࠶ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ࿝"),l1lll1ll1l1ll_fwb_)
                if l1111l1ll1ll1l1ll_fwb_:
                    l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩ࡫ࡶࡪ࡬ࠧ࿞")]  =l1111l1ll1ll1l1ll_fwb_[0][0]
                    l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ࿟")] =l1111l1ll1ll1l1ll_fwb_[0][1].strip()
                l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡵࡲ࡯ࡵࠩ࿠")]=l1l111ll1l1ll_fwb_ (u"ࠬ࠭࿡")
                l111lll1ll1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"࠭࠼ࡱࠢࡦࡰࡦࡹࡳ࠾ࠤࡵࡳࡱ࡫ࡔࡦࡺࡷࠤࡹ࡫ࡸࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡴࡃ࠭࿢"),l1lll1ll1l1ll_fwb_)
                l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡱ࡮ࡲࡸࠬ࿣")] += l1l111ll1l1ll_fwb_ (u"ࠨࡔࡲࡰࡦࡀࠠࠦࡵ࡟ࡲࠬ࿤")%l111lll1ll1ll1l1ll_fwb_[0] if l111lll1ll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠩࠪ࿥")
                if l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡷ࡫ࡦࠨ࿦")] and l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ࿧")]:
                    out.append(l1l11111ll1l1ll_fwb_)
    return out
url=l1l111ll1l1ll_fwb_ (u"ࠬ࠵ࡲࡢࡰ࡮࡭ࡳ࡭࠯ࡱࡧࡵࡷࡴࡴ࠯ࡥ࡫ࡵࡩࡨࡺ࡯ࡳࠩ࿨")
def l1ll1lll11ll1l1ll_fwb_(url):
    content = _11l111ll1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡭࠯ࡨ࡬ࡰࡲࡽࡥࡣ࠰ࡳࡰࠬ࿩")+url)
    ids = [(a.start(), a.end()) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡴࡦ࡯ࠣࡴࡱࡧࡣࡦࠤࠪ࿪"), content)]
    if not ids:
        ids = [(a.start(), a.end()) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠨ࠾࡯࡭ࠬ࿫"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        item = l11l1l1l1l1ll1l1ll_fwb_(content[ ids[i][1]:ids[i+1][0] ])
        l1l11111ll1l1ll_fwb_={}
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩ࡬ࡷࡋࡵ࡬ࡥࡧࡵࠫ࿬")]=True
        l1lllll1l11ll1l1ll_fwb_= re.findall(l1l111ll1l1ll_fwb_ (u"ࠪࡀࡸࡶࡡ࡯ࠢࡦࡰࡦࡹࡳ࠾ࠤࡵࡥࡹ࡫࡟ࡠࡸࡤࡰࡺ࡫ࠢ࠿ࠪ࠱࠯ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ࿭"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡷࡧࡴࡪࡰࡪࠫ࿮")] = l1lllll1l11ll1l1ll_fwb_[0].replace(l1l111ll1l1ll_fwb_ (u"ࠬ࠲ࠧ࿯"),l1l111ll1l1ll_fwb_ (u"࠭࠮ࠨ࿰")) if l1lllll1l11ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠧࠨ࿱")
        l1l1111l111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠨ࠾ࡶࡴࡦࡴࠠࡤ࡮ࡤࡷࡸࡃࠢࡳࡣࡷࡩࡤࡥࡣࡰࡷࡱࡸࠧࡄࠨ࠯ࠬࡂ࠭࡬࠴ࠪ࠽࠱ࡶࡴࡦࡴ࠾ࠨ࿲"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡹࡳࡹ࡫ࡳࠨ࿳")] = l1l1111l111ll1l1ll_fwb_[0].replace(l1l111ll1l1ll_fwb_ (u"ࠪࠤࠬ࿴"),l1l111ll1l1ll_fwb_ (u"ࠫࠬ࿵")) if l1l1111l111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠬ࠭࿶")
        l1111l1ll1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽࡜ࠤ࡟ࠫࡢ࠮࠯ࡱࡧࡵࡷࡴࡴ࡛࡟ࠤ࡟ࠫࡢ࠱࠿ࠪ࡝ࠥࡠࠬࡣࠠࡤ࡮ࡤࡷࡸࡃࠢࠩࡁ࠽ࡶࡦࡺࡥࡠࡡࡵࡳࡱ࡫ࡼࡧ࡫࡯ࡱࡤࡥ࡬ࡪࡰ࡮࠭ࠧࡄࠨ࡜ࡠ࠿ࡡ࠰࠯࠼࠰ࡣࡁࠫ࿷"),item)
        if l1111l1ll1ll1l1ll_fwb_:
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡩࡴࡨࡪࠬ࿸")]  =l1111l1ll1ll1l1ll_fwb_[0][0]
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ࿹")] =l1111l1ll1ll1l1ll_fwb_[0][1].strip()
        l111l1lll1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠴ࡶࡥࡳࡵࡲࡲ࠴࠴ࠫࡀࠤ࠱࠯ࡄࡹࡲࡤ࠿ࠥࠬࡠࡤ࠼࡞࠭ࠬࠦࠬ࿺"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪ࡭ࡲ࡭ࠧ࿻")] = l111l1lll1ll1l1ll_fwb_[0] if l111l1lll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠫࠬ࿼")
        if l1l11111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡲࡦࡨࠪ࿽"),False):
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡰ࡭ࡱࡷࠫ࿾")]=l1l111ll1l1ll_fwb_ (u"ࠧࠨ࿿")
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡲ࡯ࡳࡹ࠭က")] +=l1l111ll1l1ll_fwb_ (u"ࠩࡒࡧࡪࡴࡡ࠻ࠢࠨࡷࡡࡴࠧခ")%l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪࡶࡦࡺࡩ࡯ࡩࠪဂ")] if l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡷࡧࡴࡪࡰࡪࠫဃ")] else l1l111ll1l1ll_fwb_ (u"ࠬ࠭င")
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡰ࡭ࡱࡷࠫစ")] +=l1l111ll1l1ll_fwb_ (u"ࠧࡈॄࡲࡷࡾࡀࠠࠦࡵ࡟ࡲࠬဆ")%l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡸࡲࡸࡪࡹࠧဇ")] if l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡹࡳࡹ࡫ࡳࠨဈ")] else l1l111ll1l1ll_fwb_ (u"ࠪࠫဉ")
            out.append(l1l11111ll1l1ll_fwb_)
    next = re.findall(l1l111ll1l1ll_fwb_ (u"ࠫࡁࡲࡩࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࡤࡥࡩࡵࡧࡰࠤࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࡠࡡ࡬ࡸࡪࡳ࠭࠮ࡰࡨࡼࡹࠨ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠳ࡷࡧ࡮࡬࡫ࡱ࡫࠴࠴ࠪࡀࠫࠥࠫည"),content,re.DOTALL)
    next = next[0] if next else False
    prev = re.findall(l1l111ll1l1ll_fwb_ (u"ࠬࡂ࡬ࡪࠢࡦࡰࡦࡹࡳ࠾ࠤࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࡥ࡟ࡪࡶࡨࡱࠥࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࡡࡢ࡭ࡹ࡫࡭࠮࠯ࡳࡶࡪࡼࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠴ࡸࡡ࡯࡭࡬ࡲ࡬࠵࠮ࠫࡁࠬࠦࠬဋ"),content,re.DOTALL)
    prev = prev[0] if prev else False
    return out,(prev,next)
def l111l1l1ll1l1ll_fwb_(url):
    content = _11l111ll1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡪ࡮ࡲ࡭ࡸࡧࡥ࠲ࡵࡲࠧဌ")+url)
    ids = [(a.start(), a.end()) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧ࡯ࡴࡦ࡯ࠣࡴࡱࡧࡣࡦࠤࠪဍ"), content)]
    if not ids:
        ids = [(a.start(), a.end()) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠨ࠾࡯࡭ࠬဎ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        item = l11l1l1l1l1ll1l1ll_fwb_(content[ ids[i][1]:ids[i+1][0] ])
        l1l11111ll1l1ll_fwb_={}
        l1l111111l1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡵࡥࡳࡱࡩ࡯ࡩࡓࡳࡸ࡯ࡴࡪࡱࡱࠦࡃ࠮࠮ࠫࡁࠬࡀࠬဏ"),item,re.DOTALL)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪࡸࡴࡶ࠲࠶࠲ࠪတ")] = l1l111111l1ll1l1ll_fwb_[0].strip() if l1l111111l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠫࠬထ")
        l1111l1ll1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࡝ࡡࠦࡢ࠱ࠩࠣࠢࡦࡰࡦࡹࡳ࠾ࠤࡩ࡭ࡱࡳ࡟ࡠ࡮࡬ࡲࡰࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪဒ"),item)
        if l1111l1ll1ll1l1ll_fwb_:
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡨࡳࡧࡩࠫဓ")]  =l1111l1ll1ll1l1ll_fwb_[0][0]
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭န")] =l1111l1ll1ll1l1ll_fwb_[0][1].strip()
        else:
            href = re.findall(l1l111ll1l1ll_fwb_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧပ"),item)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩ࡫ࡶࡪ࡬ࠧဖ")] = href[0] if href else l1l111ll1l1ll_fwb_ (u"ࠪࠫဗ")
            title = re.findall(l1l111ll1l1ll_fwb_ (u"ࠫࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫဘ"),item)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬࡺࡩࡵ࡮ࡨࠫမ")] = title[-1].strip() if title else l1l111ll1l1ll_fwb_ (u"࠭ࠧယ")
        l111l1lll1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠧࡴࡴࡦࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࠩရ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨ࡫ࡰ࡫ࠬလ")] = l111l1lll1ll1l1ll_fwb_[0][:-5]+l1l111ll1l1ll_fwb_ (u"ࠩ࠶࠲࡯ࡶࡧࠨဝ") if l111l1lll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠪࠫသ")
        year = re.findall(l1l111ll1l1ll_fwb_ (u"ࠫࡡ࠮ࠨ࡝ࡦࡾ࠸ࢂ࠯࡜ࠪࠩဟ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬࡿࡥࡢࡴࠪဠ")] = year[0] if year else l1l111ll1l1ll_fwb_ (u"࠭ࠧအ")
        if not l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡺࡧࡤࡶࠬဢ")] and l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡪࡵࡩ࡫࠭ဣ")]:
            year = re.findall(l1l111ll1l1ll_fwb_ (u"ࠩ࠰ࠬࡡࡪࡻ࠵ࡿࠬ࠱ࠬဤ"),l1l11111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡷ࡫ࡦࠨဥ"),l1l111ll1l1ll_fwb_ (u"ࠫࠬဦ")))
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬࡿࡥࡢࡴࠪဧ")] = year[0] if year else l1l111ll1l1ll_fwb_ (u"࠭ࠧဨ")
        l111lllll11ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧ࡬ࡩ࡭࡯ࡢࡣࡴࡸࡩࡨ࡫ࡱࡥࡱࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬဩ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡱࡵ࡭࡬࡯࡮ࡢ࡮ࡷ࡭ࡹࡲࡥࠨဪ")] = l111lllll11ll1l1ll_fwb_[0] if l111lllll11ll1l1ll_fwb_ else l1l11111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠩࡷ࡭ࡹࡲࡥࠨါ"))
        l11l11l1111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠪࡨࡦࡺࡡ࠮ࠪࡂ࠾࡫࡯࡬࡮ࡾ࡬ࡨ࠮ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧာ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡩࡧࡴࡢࡡࡩ࡭ࡱࡳࠧိ")] = l11l11l1111ll1l1ll_fwb_[0] if l11l11l1111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠬ࠭ီ")
        l1lllll1l11ll1l1ll_fwb_= re.findall(l1l111ll1l1ll_fwb_ (u"࠭࠼ࡴࡲࡤࡲࠥࡩ࡬ࡢࡵࡶࡁࠧࡹ࠭࠲࠸ࠣࡺࡪࡸࡴࡪࡥࡤࡰ࠲ࡧ࡬ࡪࡩࡱࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫု"),item)
        l1lllll1l11ll1l1ll_fwb_= re.findall(l1l111ll1l1ll_fwb_ (u"ࠧ࠽ࡵࡳࡥࡳࠦࡣ࡭ࡣࡶࡷࡂࠨࡲࡢࡶࡨࡣࡤࡼࡡ࡭ࡷࡨࠦࡃ࠮࠮ࠬࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫူ"),item) if not l1lllll1l11ll1l1ll_fwb_ else []
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡴࡤࡸ࡮ࡴࡧࠨေ")] = l1lllll1l11ll1l1ll_fwb_[0].replace(l1l111ll1l1ll_fwb_ (u"ࠩ࠯ࠫဲ"),l1l111ll1l1ll_fwb_ (u"ࠪ࠲ࠬဳ")) if l1lllll1l11ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠫࠬဴ")
        try:
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬࡸࡡࡵ࡫ࡱ࡫ࠬဵ")] = float(l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡲࡢࡶ࡬ࡲ࡬࠭ံ")])
        except:
            pass
        l1l1111l111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡴ࡯ࡸࡴࡤࡴࠥࡺ࡯ࡱ࠯࠶ࠦࡃ࠮࠮ࠫࡁࠬ࡫࠳࠰࠼࠰ࡦ࡬ࡺ့ࠬ"),item)
        l1l1111l111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠨ࠾ࡶࡴࡦࡴࠠࡤ࡮ࡤࡷࡸࡃࠢࡳࡣࡷࡩࡤࡥࡣࡰࡷࡱࡸࠧࡄࠨ࠯ࠬࡂ࠭࡬࠴ࠪ࠽࠱ࡶࡴࡦࡴ࠾ࠨး"),item) if not l1l1111l111ll1l1ll_fwb_ else []
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡹࡳࡹ࡫ࡳࠨ္")] = l1l1111l111ll1l1ll_fwb_[0].replace(l1l111ll1l1ll_fwb_ (u"ࠪࠤ်ࠬ"),l1l111ll1l1ll_fwb_ (u"ࠫࠬျ")) if l1l1111l111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠬ࠭ြ")
        l111llllll1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"࠭࠼ࡵࡦࠣࡧࡱࡧࡳࡴ࠿ࠥࡴࡱࡧࡣࡦࠢࡶ࠱࠶࠼ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡧࡂࠬွ"),item,re.DOTALL)
        l111llllll1ll1l1ll_fwb_ = l111llllll1ll1l1ll_fwb_[0].strip().replace(l1l111ll1l1ll_fwb_ (u"ࠧࠧࡰࡥࡷࡵࡁࠧှ"),l1l111ll1l1ll_fwb_ (u"ࠨ࠮ࠪဿ")) if l111llllll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠩࠪ၀")
        l11l111l1l1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠪࡀࡸࡶࡡ࡯ࠢࡦࡰࡦࡹࡳ࠾ࠤࡶ࠱࠶࠼ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠠࡰࡵ࠱࠯ࡧࡡࡹ࡞ࠬ࠿࠳ࡸࡶࡡ࡯ࡀࠪ၁"),item)
        l11l111l1l1ll1l1ll_fwb_ = l11l111l1l1ll1l1ll_fwb_[0].replace(l1l111ll1l1ll_fwb_ (u"ࠫࠥ࠭၂"),l1l111ll1l1ll_fwb_ (u"ࠬ࠴ࠧ၃"))+l1l111ll1l1ll_fwb_ (u"࠭ࠠࡰࡵࣶࡦࠬ၄") if l11l111l1l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠧࠨ၅")
        l111ll1l1l1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠨ࠾ࡶࡴࡦࡴࠠࡤ࡮ࡤࡷࡸࡃࠢࡤࡣࡳࠦࡃࡶࡲࡦ࡯࡬ࡩࡷࡧ࠺࠽࠱ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ၆"),item)
        l111ll1l1l1ll1l1ll_fwb_ = l111ll1l1l1ll1l1ll_fwb_[0].strip() if l111ll1l1l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠩࠪ၇")
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪࡴࡱࡵࡴࠨ၈")] =l1l111ll1l1ll_fwb_ (u"ࠫࠬ၉")
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬࡶ࡬ࡰࡶࠪ၊")] += l1l111ll1l1ll_fwb_ (u"࡛࠭ࡃ࡟ࠪ။")+l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡰࡴ࡬࡫࡮ࡴࡡ࡭ࡶ࡬ࡸࡱ࡫ࠧ၌")]+l1l111ll1l1ll_fwb_ (u"ࠨ࡝࠲ࡆࡢࡢ࡮࡝ࡰࠪ၍") if l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡲࡶ࡮࡭ࡩ࡯ࡣ࡯ࡸ࡮ࡺ࡬ࡦࠩ၎")] else l1l111ll1l1ll_fwb_ (u"ࠪࠫ၏")
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡵࡲ࡯ࡵࠩၐ")] += l1l111ll1l1ll_fwb_ (u"ࠬࡕࡣࡦࡰࡤ࠾ࠥ࠭ၑ")+str(l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡲࡢࡶ࡬ࡲ࡬࠭ၒ")])+l1l111ll1l1ll_fwb_ (u"ࠧ࡝ࡰࠪၓ") if l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡴࡤࡸ࡮ࡴࡧࠨၔ")] else l1l111ll1l1ll_fwb_ (u"ࠩࠪၕ")
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪࡴࡱࡵࡴࠨၖ")] += l1l111ll1l1ll_fwb_ (u"ࠫࡌै࡯ࡴࡻ࠽ࠤࠬၗ")+str(l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬࡼ࡯ࡵࡧࡶࠫၘ")])+l1l111ll1l1ll_fwb_ (u"࠭࡜࡯ࠩၙ") if l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡷࡱࡷࡩࡸ࠭ၚ")] else l1l111ll1l1ll_fwb_ (u"ࠨࠩၛ")
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡳࡰࡴࡺࠧၜ")] += l1l111ll1l1ll_fwb_ (u"ࠪࡆࡴࡾ࡯ࡧࡨ࡬ࡧࡪࡀࠠࠨၝ")+l111llllll1ll1l1ll_fwb_+l1l111ll1l1ll_fwb_ (u"ࠫࡡࡴࠧၞ") if l111llllll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠬ࠭ၟ")
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡰ࡭ࡱࡷࠫၠ")] += l1l111ll1l1ll_fwb_ (u"ࠧࡄࡪजࡸࡳࡿࡣࡩ࠼ࠣࠫၡ")+l11l111l1l1ll1l1ll_fwb_+l1l111ll1l1ll_fwb_ (u"ࠨ࡞ࡱࠫၢ") if l11l111l1l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠩࠪၣ")
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪࡴࡱࡵࡴࠨၤ")] += l1l111ll1l1ll_fwb_ (u"ࠫࡕࡸࡥ࡮࡫ࡨࡶࡦࡀࠠࠨၥ")+l111ll1l1l1ll1l1ll_fwb_+l1l111ll1l1ll_fwb_ (u"ࠬࡢ࡮ࠨၦ") if l111ll1l1l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"࠭ࠧၧ")
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧ࡮ࡧࡧ࡭ࡦࡺࡹࡱࡧࠪၨ")]=l1l111ll1l1ll_fwb_ (u"ࠨ࡯ࡲࡺ࡮࡫ࠧၩ")
        if l1l111ll1l1ll_fwb_ (u"ࠩ࠲ࡷࡪࡸࡩࡢ࡮ࠪၪ") in url or l1l111ll1l1ll_fwb_ (u"ࠪ࠳ࡹࡼࡳࡩࡱࡺࠫၫ") in url:
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫ࡮ࡹࡆࡰ࡮ࡧࡩࡷ࠭ၬ")]=True
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬࡳࡥࡥ࡫ࡤࡸࡾࡶࡥࠨၭ")]=l1l111ll1l1ll_fwb_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࠧၮ")
        elif l1l111ll1l1ll_fwb_ (u"ࠧ࠰ࡲࡨࡶࡸࡵ࡮࠰ࠩၯ") in url:
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨ࡫ࡶࡊࡴࡲࡤࡦࡴࠪၰ")]=True
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡰࡩࡩ࡯ࡡࡵࡻࡳࡩࠬၱ")]=l1l111ll1l1ll_fwb_ (u"ࠪࡴࡪࡸࡳࡰࡰࠪၲ")
        if l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡸࡥࡧࠩၳ")] and l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬࡺࡩࡵ࡮ࡨࠫၴ")]:
            out.append(l1l11111ll1l1ll_fwb_)
    return out
def l1lll1lll1ll1l1ll_fwb_(url,out=[]):
    content = _11l111ll1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡪ࡮ࡲ࡭ࡸࡧࡥ࠲ࡵࡲࠧၵ")+url)
    ids = [(a.start(), a.end()) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠧ࠽࡮࡬ࠫၶ"), content)]
    ids.append( (-1,-1) )
    for i in range(len(ids[:-1])):
        item = l11l1l1l1l1ll1l1ll_fwb_(content[ ids[i][1]:ids[i+1][0] ])
        l1l11111ll1l1ll_fwb_={}
        href = re.findall(l1l111ll1l1ll_fwb_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧၷ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩ࡫ࡶࡪ࡬ࠧၸ")] = href[0] if href else l1l111ll1l1ll_fwb_ (u"ࠪࠫၹ")
        l111l1lll1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠭ၺ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬ࡯࡭ࡨࠩၻ")] = l111l1lll1ll1l1ll_fwb_[0][:-5]+l1l111ll1l1ll_fwb_ (u"࠭࠳࠯࡬ࡳ࡫ࠬၼ")  if l111l1lll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠧࠨၽ")
        title = re.findall(l1l111ll1l1ll_fwb_ (u"ࠨ࠾࡫࠷ࠥࡩ࡬ࡢࡵࡶࡁࠧ࡮ࡥࡢࡦࡨࡶࠥ࡫࡮ࡵ࡫ࡷࡽࡤࡥࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠴ࡀࠪၾ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡷ࡭ࡹࡲࡥࠨၿ")] = title[-1].strip() if title else l1l111ll1l1ll_fwb_ (u"ࠪࠫႀ")
        year = re.findall(l1l111ll1l1ll_fwb_ (u"ࠫࡡ࠮ࠨ࡝ࡦࡾ࠸ࢂ࠯࡜ࠪࠩႁ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬࡿࡥࡢࡴࠪႂ")] = year[0] if year else l1l111ll1l1ll_fwb_ (u"࠭ࠧႃ")
        if not l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡺࡧࡤࡶࠬႄ")] and l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡪࡵࡩ࡫࠭ႅ")]:
            year = re.findall(l1l111ll1l1ll_fwb_ (u"ࠩ࠰ࠬࡡࡪࡻ࠵ࡿࠬ࠱ࠬႆ"),l1l11111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡷ࡫ࡦࠨႇ"),l1l111ll1l1ll_fwb_ (u"ࠫࠬႈ")))
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬࡿࡥࡢࡴࠪႉ")] = year[0] if year else l1l111ll1l1ll_fwb_ (u"࠭ࠧႊ")
        code = re.findall(l1l111ll1l1ll_fwb_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡴࡲ࡫ࡷࡧ࡭ࡠࡡࡱࡥࡲ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡂࡴࡪ࡯ࡨࠤࡨࡲࡡࡴࡵࡀࠦࡩࡧࡴࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡸ࡮ࡳࡥ࠿࠾࠲ࡨ࡮ࡼ࠾ࠨႋ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡥࡲࡨࡪ࠭ႌ")] = l1l111ll1l1ll_fwb_ (u"ႍࠩࠣࠫ").join(code[0]) if code else l1l111ll1l1ll_fwb_ (u"ࠪࠫႎ")
        l11l11l1111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠫࡩࡧࡴࡢ࠯ࠫࡃ࠿࡬ࡩ࡭࡯ࡿ࡭ࡩ࠯࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨႏ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬࡪࡡࡵࡣࡢࡪ࡮ࡲ࡭ࠨ႐")] = l11l11l1111ll1l1ll_fwb_[0] if l11l11l1111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"࠭ࠧ႑")
        if not l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡺࡧࡤࡶࠬ႒")] and l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡦࡤࡸࡦࡥࡦࡪ࡮ࡰࠫ႓")]:
            l1lll1l1l1ll1l1ll_fwb_ = getFilmInfoFull(l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡧࡥࡹࡧ࡟ࡧ࡫࡯ࡱࠬ႔")])
            l1l11111ll1l1ll_fwb_.update(l1lll1l1l1ll1l1ll_fwb_)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪࡱࡪࡪࡩࡢࡶࡼࡴࡪ࠭႕")]=l1l111ll1l1ll_fwb_ (u"ࠫࡲࡵࡶࡪࡧࠪ႖")
        if l1l111ll1l1ll_fwb_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡥࡱ࠭႗") in url:
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡩࡴࡈࡲࡰࡩ࡫ࡲࠨ႘")]=True
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧ࡮ࡧࡧ࡭ࡦࡺࡹࡱࡧࠪ႙")]=l1l111ll1l1ll_fwb_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࠩႚ")
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡳࡰࡴࡺࠧႛ")] = l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪࡧࡴࡪࡥࠨႜ")] +l1l111ll1l1ll_fwb_ (u"ࠫࡡࡴࠧႝ")+l1l11111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠬࡶ࡬ࡰࡶࠪ႞"),l1l111ll1l1ll_fwb_ (u"࠭ࠧ႟"))
        if l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡩࡴࡨࡪࠬႠ")] and l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧႡ")]:
            out.append(l1l11111ll1l1ll_fwb_)
    return out
from l11l11l11l1ll1l1ll_fwb_ import *
def l1l111l1ll1l1ll_fwb_(_1ll111l11ll1l1ll_fwb_):
    d={}
    if   _1ll111l11ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠩࡥࡥࡿࡧࡦࡪ࡮ࡰࡳࡼࡥࡳࡰࡴࡷࠫႢ"): return l11lll11l11ll1l1ll_fwb_()
    elif _1ll111l11ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠪࡦࡦࢀࡡࡧ࡫࡯ࡱࡴࡽ࡟ࡴࡱࡵࡸࡆࡹࡣࡦࡰࡧ࡭ࡳ࡭ࠧႣ"): return l11lllll111ll1l1ll_fwb_()
    elif _1ll111l11ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠫࡧࡧࡺࡢࡨ࡬ࡰࡲࡵࡷࡠࡦࡤࡸࡦࡖࡲࡰࡦࡸ࡯ࡨࡰࡩࠨႤ"): return l11lll1ll11ll1l1ll_fwb_()
    elif _1ll111l11ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠬࡨࡡࡻࡣࡩ࡭ࡱࡳ࡯ࡸࡡࡒࡧࡪࡴࡡࠨႥ"): return l11l11111l1ll1l1ll_fwb_()
    elif _1ll111l11ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"࠭ࡢࡢࡼࡤࡪ࡮ࡲ࡭ࡰࡹࡢ࡫ࡪࡴࡲࡦࡋࡧࡷࠬႦ"):      return l11ll1l1l11ll1l1ll_fwb_()
    elif _1ll111l11ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠧࡣࡣࡽࡥ࡫࡯࡬࡮ࡱࡺࡣ࡬࡫࡮ࡳࡧࡗ࡚ࡸ࡮࡯ࡸࡵࠪႧ"):      return l11lllllll1ll1l1ll_fwb_()
    elif _1ll111l11ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠨࡤࡤࡾࡦ࡬ࡩ࡭࡯ࡲࡻࡤࡩ࡯ࡶࡰࡷࡶࡾࡏࡤࡴࠩႨ"):    return l11llll1111ll1l1ll_fwb_()
    elif _1ll111l11ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠩࡵࡥࡳࡱࡩ࡯ࡩࡷࡳࡵࡥ࡫ࡳࡣ࡭ࡩࠬႩ"):     return l11llll1l11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠪࡏࡷࡧࡪࡦࠩႪ"))
    elif _1ll111l11ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠫࡷࡧ࡮࡬࡫ࡱ࡫ࡹࡵࡰࡠࡩࡤࡸࡺࡴ࡫ࡪࠩႫ"):   return l11llll1l11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠬࡍࡡࡵࡷࡱ࡯࡮࠭Ⴌ"))
    elif _1ll111l11ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"࠭ࡲࡢࡰ࡮࡭ࡳ࡭ࡴࡰࡲࡢࡰࡦࡺࡡࠨႭ"):      return l11llll1l11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠧࡳࡱ࡮ࠫႮ"))
    elif _1ll111l11ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠨࡤࡲࡼࡴ࡬ࡦࡪࡥࡨࡣࡰࡸࡡ࡫ࡧࠪႯ"):     return l11llll1l11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠩࡎࡶࡦࡰࡥࠨႰ"))
    elif _1ll111l11ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠪࡦࡴࡾ࡯ࡧࡨ࡬ࡧࡪࡥࡧࡢࡶࡸࡲࡰ࡯ࠧႱ"):   return l11llll1l11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠫࡌࡧࡴࡶࡰ࡮࡭ࠬႲ"))
    elif _1ll111l11ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠬࡨ࡯ࡹࡱࡩࡪ࡮ࡩࡥࡠ࡮ࡤࡸࡦ࠭Ⴓ"):      return l11llll1l11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"࠭ࡲࡰ࡭ࠪႴ"))
    elif _1ll111l11ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠧࡍࡷࡧࡾ࡮࡫࡟ࡇ࡫࡯ࡱࡺ࠭Ⴕ"):      return l11l1l111l1ll1l1ll_fwb_()
    elif _1ll111l11ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠨࡤࡤࡾࡦࡕࡳࡰࡤࡢࡧࡴࡻ࡮ࡵࡴࡼࠫႶ"): return l11l1l11l11ll1l1ll_fwb_()
    elif _1ll111l11ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠩࡥࡥࡿࡧࡏࡴࡱࡥࡣࡸࡵࡲࡵࠩႷ"): return l11llll1ll1ll1l1ll_fwb_()
    elif _1ll111l11ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠪࡦࡦࢀࡡࡐࡵࡲࡦࡤࡹ࡯ࡳࡶࡄࡷࡨ࡫࡮ࡥ࡫ࡱ࡫ࠬႸ"): return l11lllll111ll1l1ll_fwb_()
    elif _1ll111l11ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠫࡧࡧࡺࡢࡑࡶࡳࡧࡥࡰ࡭ࡧࡦࠫႹ"): return l11lll111l1ll1l1ll_fwb_()
    elif _1ll111l11ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠬࡨࡡࡻࡣࡒࡷࡴࡨ࡟ࡻࡣࡺࡳࡩ࠭Ⴚ"): return l11ll1l1111ll1l1ll_fwb_()
    elif _1ll111l11ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"࠭ࡢࡢࡼࡤࡓࡸࡵࡢࡠࡦࡤࡸࡦ࡛ࡲࡰࡦࡽࡩࡳ࡯ࡡࠨႻ"): return l11l1l1ll11ll1l1ll_fwb_()
    return (d.keys(),d.values())
url=l1l111ll1l1ll_fwb_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲࡫࡯࡬࡮ࡹࡨࡦ࠳ࡶ࡬࠰ࡵࡨࡥࡷࡩࡨ࠰ࡶࡹࡷ࡭ࡵࡷࠨႼ")
url=l1l111ll1l1ll_fwb_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡬ࡩ࡭࡯ࡺࡩࡧ࠴ࡰ࡭࠱ࡳࡩࡷࡹ࡯࡯ࡵ࠲ࡷࡪࡧࡲࡤࡪࠪႽ")
def l1l1lll1ll1l1ll_fwb_(url):
    content = _11l111ll1ll1l1ll_fwb_(url)
    if l1l111ll1l1ll_fwb_ (u"ࠩ࠲ࡴࡪࡸࡳࡰࡰࡶࠫႾ") in url:
        return _11l1l1lll1ll1l1ll_fwb_(content)
    else:
        return _11ll11l1l1ll1l1ll_fwb_(content,url)
def _11l1l1lll1ll1l1ll_fwb_(content):
    ids = [(a.start(), a.end()) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠪࡀࡱ࡯ࠠࡤ࡮ࡤࡷࡸࡃࠢࡩ࡫ࡷࡷࡤࡥࡩࡵࡧࡰࠦࠬႿ"), content)]
    ids.append( (-1,-1) )
    out=[]
    isFolder = True
    for i in range(len(ids[:-1])):
        item = l11l1l1l1l1ll1l1ll_fwb_(content[ ids[i][1]:ids[i+1][0] ])
        l1l11111ll1l1ll_fwb_={l1l111ll1l1ll_fwb_ (u"ࠫ࡮ࡹࡆࡰ࡮ࡧࡩࡷ࠭Ⴠ"):isFolder}
        href = re.findall(l1l111ll1l1ll_fwb_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠱ࡳࡩࡷࡹ࡯࡯࠱࠱࠯ࡄ࠯ࠢࠨჁ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡨࡳࡧࡩࠫჂ")] = href[0].strip() if href else l1l111ll1l1ll_fwb_ (u"ࠧࠨჃ")
        title = re.findall(l1l111ll1l1ll_fwb_ (u"ࠨࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠯ࡄ࠯ࠢࠨჄ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡷ࡭ࡹࡲࡥࠨჅ")] = title[0].strip() if title else l1l111ll1l1ll_fwb_ (u"ࠪࠫ჆")
        l111l1lll1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩჇ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬ࡯࡭ࡨࠩ჈")] = l111l1lll1ll1l1ll_fwb_[0] if l111l1lll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"࠭ࠧ჉")
        l1lllll1l11ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡩ࡫ࡷࡣࡤࡧࡶࡦࡴࡤ࡫ࡪࡘࡡࡵ࡫ࡱ࡫ࠧࡄࠨ࠯࠭ࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬ჊"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡴࡤࡸ࡮ࡴࡧࠨ჋")] = l1lllll1l11ll1l1ll_fwb_[-1].replace(l1l111ll1l1ll_fwb_ (u"ࠩ࠯ࠫ჌"),l1l111ll1l1ll_fwb_ (u"ࠪ࠲ࠬჍ")).strip() if l1lllll1l11ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠫࠬ჎")
        l1l1111l111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡮ࡩࡵࡡࡢࡺࡴࡺࡥࡴࠤࡁࠬ࠳࠱࠿ࠪࡩ࠱࠯ࡄࡂ࠯ࡴࡲࡤࡲࡃ࠭჏"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡶࡰࡶࡨࡷࠬა")] = l1l1111l111ll1l1ll_fwb_[-1].strip() if l1l1111l111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠧࠨბ")
        if l1l11111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠨࡪࡵࡩ࡫࠭გ")):
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡳࡰࡴࡺࠧდ")]=l1l111ll1l1ll_fwb_ (u"ࠪࠫე")
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡵࡲ࡯ࡵࠩვ")] +=l1l111ll1l1ll_fwb_ (u"ࠬࡕࡣࡦࡰࡤ࠾ࠥࠫࡳ࡝ࡰࠪზ")%l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡲࡢࡶ࡬ࡲ࡬࠭თ")] if l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡳࡣࡷ࡭ࡳ࡭ࠧი")] else l1l111ll1l1ll_fwb_ (u"ࠨࠩკ")
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡳࡰࡴࡺࠧლ")] +=l1l111ll1l1ll_fwb_ (u"ࠪࡋेࡵࡳࡺ࠼ࠣࠩࡸࡢ࡮ࠨმ")%l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡻࡵࡴࡦࡵࠪნ")] if l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬࡼ࡯ࡵࡧࡶࠫო")] else l1l111ll1l1ll_fwb_ (u"࠭ࠧპ")
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ჟ")] += l1l111ll1l1ll_fwb_ (u"ࠨࠢࠫࠩࡸ࠯ࠧრ")%(l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡵࡥࡹ࡯࡮ࡨࠩს")]) if l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪࡶࡦࡺࡩ࡯ࡩࠪტ")] else l1l111ll1l1ll_fwb_ (u"ࠫࠬუ")
            out.append(l1l11111ll1l1ll_fwb_)
    return out
def _11ll11l1l1ll1l1ll_fwb_(content,url):
    ids = [(a.start(), a.end()) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠬࡂ࡬ࡪࠢ࡬ࡨࡂࠨࠨࡀ࠼࡫࡭ࡹࢂࡦࡪ࡮ࡰ࠭ࠬფ"), content)]
    ids.append( (-1,-1) )
    out=[]
    if l1l111ll1l1ll_fwb_ (u"࠭࠯ࡴࡧࡵ࡭ࡦࡲࡳࠨქ") in url or l1l111ll1l1ll_fwb_ (u"ࠧ࠰ࡶࡹࡷ࡭ࡵࡷࡴࠩღ") in url:
        isFolder = True
    else:
        isFolder = False
    for i in range(len(ids[:-1])):
        item = l11l1l1l1l1ll1l1ll_fwb_(content[ ids[i][1]:ids[i+1][0] ])
        l1l11111ll1l1ll_fwb_={}
        l11l1l1l111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠨ࠾ࡶࡧࡷ࡯ࡰࡵࠢࡧࡥࡹࡧ࠭ࡵࡻࡳࡩࡂࠨࡳࡦࡶࡩ࡭ࡱࡳࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩყ"),item)
        if l11l1l1l111ll1l1ll_fwb_:
            l11l1l1l111ll1l1ll_fwb_ = l11l1l1l111ll1l1ll_fwb_[0] if l11l1l1l111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠩࠪშ")
            href = re.findall(l1l111ll1l1ll_fwb_ (u"ࠪࡰ࡮ࡴ࡫࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩჩ"),l11l1l1l111ll1l1ll_fwb_)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡸࡥࡧࠩც")] = href[0] if href else l1l111ll1l1ll_fwb_ (u"ࠬ࠭ძ")
            year = re.findall(l1l111ll1l1ll_fwb_ (u"࠭ࡹࡦࡣࡵ࠾࠭ࡢࡤࠬࠫࠪწ"),l11l1l1l111ll1l1ll_fwb_)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡺࡧࡤࡶࠬჭ")] = year[0] if year else l1l111ll1l1ll_fwb_ (u"ࠨࠩხ")
            l11ll1lll11ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬჯ"),l11l1l1l111ll1l1ll_fwb_)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬჰ")] = int(l11ll1lll11ll1l1ll_fwb_[0])*60 if l11ll1lll11ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠫࠬჱ")
            l111ll11ll1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠬࡶࡲࡦ࡯࡬ࡩࡷ࡫ࡃࡰࡷࡱࡸࡷࡿ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨჲ"),l11l1l1l111ll1l1ll_fwb_)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡰࡳࡧࡰ࡭ࡪࡸࡥࡥࠩჳ")] = l111ll11ll1ll1l1ll_fwb_[0] if l111ll11ll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠧࠨჴ")
            l1lllll1l11ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠨࡴࡤࡸࡪࡀࠨ࠯ࠬࡂ࠭࠱࠭ჵ"),l11l1l1l111ll1l1ll_fwb_)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡵࡥࡹ࡯࡮ࡨࠩჶ")] = round(float(l1lllll1l11ll1l1ll_fwb_[-1]),1) if l1lllll1l11ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠪࠫჷ")
            l1l1111l111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠫࡷࡧࡴࡪࡰࡪࡇࡴࡻ࡮ࡵ࠼ࠫ࠲࠯ࡅࠩ࠭ࠩჸ"),l11l1l1l111ll1l1ll_fwb_)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬࡼ࡯ࡵࡧࡶࠫჹ")] = int(l1l1111l111ll1l1ll_fwb_[-1]) if l1l1111l111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"࠭ࠧჺ")
            l111l1lll1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ჻"),item)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨ࡫ࡰ࡫ࠬჼ")] = l111l1lll1ll1l1ll_fwb_[0][:-5]+l1l111ll1l1ll_fwb_ (u"ࠩ࠶࠲࡯ࡶࡧࠨჽ") if l111l1lll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠪࠫჾ")
            title = re.findall(l1l111ll1l1ll_fwb_ (u"ࠫࡹ࡯ࡴ࡭ࡧ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫჿ"),item)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬࡺࡩࡵ࡮ࡨࠫᄀ")] = title[0] if title else l1l111ll1l1ll_fwb_ (u"࠭ࠧᄁ")
            l111lllll11ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠧ࠽ࡵࡳࡥࡳࠦࡣ࡭ࡣࡶࡷࡂࠨࡦࡪ࡮ࡰࡗࡺࡨࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᄂ"),item)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡱࡵ࡭࡬࡯࡮ࡢ࡮ࡷ࡭ࡹࡲࡥࠨᄃ")] = l111lllll11ll1l1ll_fwb_[0].strip() if l111lllll11ll1l1ll_fwb_ else title
            l11l1ll11l1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠴ࡹࡥࡢࡴࡦ࡬࠴࡬ࡩ࡭࡯࡟ࡃ࡬࡫࡮ࡳࡧࡌࡨࡸࡃ࡜ࡥ࠭ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧᄄ"),item)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪ࡫ࡪࡴࡲࡦࠩᄅ")] = l1l111ll1l1ll_fwb_ (u"ࠫ࠱࠭ᄆ").join([x.strip() for x in l11l1ll11l1ll1l1ll_fwb_]) if l11l1ll11l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠬ࠭ᄇ")
            l11l1lll111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣ࠱ࡶࡩࡦࡸࡣࡩ࠱ࡩ࡭ࡱࡳ࡜ࡀࡥࡲࡹࡳࡺࡲࡺࡋࡧࡷࡂࡢࡤࠬࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᄈ"),item)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨᄉ")] = l1l111ll1l1ll_fwb_ (u"ࠨ࠮ࠪᄊ").join([x.strip() for x in l11l1lll111ll1l1ll_fwb_]) if l11l1lll111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠩࠪᄋ")
            l1111l11l1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡨ࡬ࡰࡲࡖ࡬ࡰࡶࠥࡂࡡࡹࠪ࠽ࡲࡁࠬ࠳࠰࠿ࠪ࠾ࠪᄌ"),item,re.DOTALL)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡵࡲ࡯ࡵࠩᄍ")] = l1111l11l1ll1l1ll_fwb_[0].strip() if l1111l11l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠬ࠭ᄎ")
            l11l1lllll1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"࠭ࡹࡴࡧࡵ࡟࡮ࡧ࡝ࠫ࡞ࡶ࠮࠿ࡢࡳࠫ࠾࠲ࡨࡹࡄ࡜ࡴࠬ࠿ࡨࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡥࡀࠪᄏ"),item,re.DOTALL)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡥ࡫ࡵࡩࡨࡺ࡯ࡳࠩᄐ")] = l1l111ll1l1ll_fwb_ (u"ࠨ࠮ࠪᄑ").join([x for x in re.findall(l1l111ll1l1ll_fwb_ (u"ࠩࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᄒ"),l11l1lllll1ll1l1ll_fwb_[0])]) if l11l1lllll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠪࠫᄓ")
            l11l1111ll1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠫࡴࡨࡳࡢࡦࡤࡠࡸ࠰࠺࡝ࡵ࠭ࡀ࠴ࡪࡴ࠿࡞ࡶ࠮ࡁࡪࡤ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦࡧࡂࠬᄔ"),item,re.DOTALL)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬࡩࡡࡴࡶࠪᄕ")] = [x for x in re.findall(l1l111ll1l1ll_fwb_ (u"࠭ࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᄖ"),l11l1111ll1ll1l1ll_fwb_[0])] if l11l1111ll1ll1l1ll_fwb_ else []
            l11l11l1111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠧࡥࡣࡷࡥ࠲࠮࠿࠻ࡨ࡬ࡰࡲࢂࡩࡥࠫࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᄗ"),item)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡦࡤࡸࡦࡥࡦࡪ࡮ࡰࠫᄘ")] = l11l11l1111ll1l1ll_fwb_[0] if l11l11l1111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠩࠪᄙ")
        else:
            href = re.findall(l1l111ll1l1ll_fwb_ (u"ࠪࡀࡦࠦࡣ࡭ࡣࡶࡷࡂࠨࡦࡪ࡮ࡰࡔࡷ࡫ࡶࡪࡧࡺࡣࡤࡲࡩ࡯࡭ࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᄚ"),item)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡸࡥࡧࠩᄛ")] = href[0] if href else l1l111ll1l1ll_fwb_ (u"ࠬ࠭ᄜ")
            year = re.findall(l1l111ll1l1ll_fwb_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡦࡪ࡮ࡰࡔࡷ࡫ࡶࡪࡧࡺࡣࡤࡿࡥࡢࡴࠥࡂࡡࡹࠪࠩ࡞ࡧ࠯࠮ࡢࡳࠫࠩᄝ"),item)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡺࡧࡤࡶࠬᄞ")] = year[0] if year else l1l111ll1l1ll_fwb_ (u"ࠨࠩᄟ")
            l11ll1lll11ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡩ࡭ࡱࡳࡐࡳࡧࡹ࡭ࡪࡽ࡟ࡠࡨ࡬ࡰࡲ࡚ࡩ࡮ࡧࠥࠤࡩࡧࡴࡢ࠯ࡧࡹࡷࡧࡴࡪࡱࡱࡁࠧ࠮࡜ࡥ࠭ࠬࠦࠬᄠ"),item)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬᄡ")] = int(l11ll1lll11ll1l1ll_fwb_[0])*60 if l11ll1lll11ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠫࠬᄢ")
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬࡶࡲࡦ࡯࡬ࡩࡷ࡫ࡤࠨᄣ")] = l1l111ll1l1ll_fwb_ (u"࠭ࠧᄤ")
            try:
                l1lllll1l11ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡳࡣࡷࡩࡇࡵࡸࡠࡡࡵࡥࡹ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᄥ"),item)
                l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡴࡤࡸ࡮ࡴࡧࠨᄦ")] = round(float(l1lllll1l11ll1l1ll_fwb_[-1].replace(l1l111ll1l1ll_fwb_ (u"ࠩ࠯ࠫᄧ"),l1l111ll1l1ll_fwb_ (u"ࠪ࠲ࠬᄨ"))),1) if l1lllll1l11ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠫࠬᄩ")
                l1l1111l111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡸࡡࡵࡧࡅࡳࡽࡥ࡟ࡷࡱࡷࡩࡸࠨ࠾ࠩ࠰࠭ࡃ࠮࡭ࠧᄪ"),item)
                l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡶࡰࡶࡨࡷࠬᄫ")] = int(l1l1111l111ll1l1ll_fwb_[-1].replace(l1l111ll1l1ll_fwb_ (u"ࠧࠡࠩᄬ"),l1l111ll1l1ll_fwb_ (u"ࠨࠩᄭ"))) if l1l1111l111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠩࠪᄮ")
            except:
                pass
            l111l1lll1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᄯ"),item)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫ࡮ࡳࡧࠨᄰ")] = l111l1lll1ll1l1ll_fwb_[0][:-5]+l1l111ll1l1ll_fwb_ (u"ࠬ࠹࠮࡫ࡲࡪࠫᄱ") if l111l1lll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"࠭ࠧᄲ")
            title = re.findall(l1l111ll1l1ll_fwb_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡧ࡫࡯ࡱࡕࡸࡥࡷ࡫ࡨࡻࡤࡥࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᄳ"),item)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᄴ")] = title[0] if title else l1l111ll1l1ll_fwb_ (u"ࠩࠪᄵ")
            l111lllll11ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡪ࡮ࡲ࡭ࡑࡴࡨࡺ࡮࡫ࡷࡠࡡࡲࡶ࡮࡭ࡩ࡯ࡣ࡯ࡘ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᄶ"),item)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡴࡸࡩࡨ࡫ࡱࡥࡱࡺࡩࡵ࡮ࡨࠫᄷ")] = l111lllll11ll1l1ll_fwb_[0].strip() if l111lllll11ll1l1ll_fwb_ else title
            l11l1ll11l1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡨ࡬ࡰࡲࡢ࠿ࡨࡧࡱࡶࡪࡏࡤࡴ࠿࡟ࡨ࠰ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪᄸ"),item)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡧࡦࡰࡵࡩࠬᄹ")] = l1l111ll1l1ll_fwb_ (u"ࠧ࠭ࠩᄺ").join([x.strip() for x in l11l1ll11l1ll1l1ll_fwb_]) if l11l1ll11l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠨࠩᄻ")
            l11l1lll111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠴ࡹࡥࡢࡴࡦ࡬࠴࡬ࡩ࡭࡯࡟ࡃࡨࡵࡵ࡯ࡶࡵࡽࡎࡪࡳ࠾࡞ࡧ࠯ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᄼ"),item)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫᄽ")] = l1l111ll1l1ll_fwb_ (u"ࠫ࠱࠭ᄾ").join([x.strip() for x in l11l1lll111ll1l1ll_fwb_]) if l11l1lll111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠬ࠭ᄿ")
            l1111l11l1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡦࡪ࡮ࡰࡔࡷ࡫ࡶࡪࡧࡺࡣࡤࡪࡥࡴࡥࡵ࡭ࡵࡺࡩࡰࡰࠥࡂࡁࡶ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᅀ"),item,re.DOTALL)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡱ࡮ࡲࡸࠬᅁ")] = l1111l11l1ll1l1ll_fwb_[0].strip() if l1111l11l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠨࠩᅂ")
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡧ࡭ࡷ࡫ࡣࡵࡱࡵࠫᅃ")] = l1l111ll1l1ll_fwb_ (u"ࠪࠫᅄ")
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡨࡧࡳࡵࠩᅅ")] = []
            l11l11l1111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠬࡪࡡࡵࡣ࠰ࠬࡄࡀࡦࡪ࡮ࡰࢀ࡮ࡪࠩ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᅆ"),item)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡤࡢࡶࡤࡣ࡫࡯࡬࡮ࠩᅇ")] = l11l11l1111ll1l1ll_fwb_[0] if l11l11l1111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠧࠨᅈ")
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨ࡯ࡨࡨ࡮ࡧࡴࡺࡲࡨࠫᅉ")]=l1l111ll1l1ll_fwb_ (u"ࠩࡰࡳࡻ࡯ࡥࠨᅊ")
        if isFolder or l1l111ll1l1ll_fwb_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡣ࡯࠳ࠬᅋ") in l1l11111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡸࡥࡧࠩᅌ"),False):
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬ࡯ࡳࡇࡱ࡯ࡨࡪࡸࠧᅍ")] = True
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭࡭ࡦࡦ࡬ࡥࡹࡿࡰࡦࠩᅎ")]=l1l111ll1l1ll_fwb_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࠨᅏ")
        if l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡪࡵࡩ࡫࠭ᅐ")]:
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡱࡩࡽࡺ࡟ࡶࡴ࡯ࠫᅑ")]=url
            out.append(l1l11111ll1l1ll_fwb_)
    return out
def l11l1lll1l1ll1l1ll_fwb_(p=l1l111ll1l1ll_fwb_ (u"ࠪ࠴࠻࠵࠰࠸࠱࠵࠴࠶࠽ࠧᅒ")):
    if p==l1l111ll1l1ll_fwb_ (u"ࠫࠬᅓ"):
        return l1l111ll1l1ll_fwb_ (u"ࠬ࠭ᅔ")
    l11l11ll111ll1l1ll_fwb_ = datetime.datetime.strptime(p, l1l111ll1l1ll_fwb_ (u"ࠨࠥࡥ࠱ࠨࡱ࠴࡙ࠫࠣᅕ"))
    today = datetime.datetime.today()
    l11l11l1l11ll1l1ll_fwb_ = today - l11l11ll111ll1l1ll_fwb_
    if abs(l11l11l1l11ll1l1ll_fwb_.days)>31:
        l111ll11l11ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࠦࡦࠣࠩࡸ࠭ᅖ") %(l11l11ll111ll1l1ll_fwb_.day, l11lll1lll1ll1l1ll_fwb_[l11l11ll111ll1l1ll_fwb_.month-1])
        if l11l11ll111ll1l1ll_fwb_.year != today.year:
            l111ll11l11ll1l1ll_fwb_ += l1l111ll1l1ll_fwb_ (u"ࠨࠢࠨࡨࠬᅗ")%l11l11ll111ll1l1ll_fwb_.year
    elif l11l11l1l11ll1l1ll_fwb_.days>0:
        l111ll11l11ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠩࠨࡨࠥࡪ࡮ࡪࠢࡷࡩࡲࡻࠧᅘ") %abs(l11l11l1l11ll1l1ll_fwb_.days)
    elif l11l11l1l11ll1l1ll_fwb_.days<0:
        l111ll11l11ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠪࡾࡦࠦࠥࡥࠢࡧࡲ࡮࠭ᅙ") %abs(l11l11l1l11ll1l1ll_fwb_.days)
    else:
        l111ll11l11ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠫࡩࢀࡩड़ࠩᅚ")
    return l111ll11l11ll1l1ll_fwb_
l11lll1lll1ll1l1ll_fwb_ = [l1l111ll1l1ll_fwb_ (u"࡙ࠬࡴࡺࡥࡽࡩॉ࠭ᅛ"),l1l111ll1l1ll_fwb_ (u"࠭ࡌࡶࡶࡼࠫᅜ"),l1l111ll1l1ll_fwb_ (u"ࠧࡎࡣࡵࡾࡪࡩࠧᅝ"),l1l111ll1l1ll_fwb_ (u"ࠨࡍࡺ࡭ࡪࡩࡩࡦॆࠪᅞ"),l1l111ll1l1ll_fwb_ (u"ࠩࡐࡥ࡯࠭ᅟ"),l1l111ll1l1ll_fwb_ (u"ࠪࡇࡿ࡫ࡲࡸ࡫ࡨࡧࠬᅠ"),l1l111ll1l1ll_fwb_ (u"ࠫࡑ࡯ࡰࡪࡧࡦࠫᅡ"),l1l111ll1l1ll_fwb_ (u"࡙ࠬࡩࡦࡴࡳ࡭ࡪॊࠧᅢ"),l1l111ll1l1ll_fwb_ (u"࠭ࡗࡳࡼࡨࡷ࡮࡫ॄࠨᅣ"),l1l111ll1l1ll_fwb_ (u"ࠧࡑࡣॽࡨࡿ࡯ࡥࡳࡰ࡬࡯ࠬᅤ"),l1l111ll1l1ll_fwb_ (u"ࠨࡎ࡬ࡷࡹࡵࡰࡢࡦࠪᅥ"),l1l111ll1l1ll_fwb_ (u"ࠩࡊࡶࡺࡪࡺࡪࡧेࠫᅦ")]
def l1l11111ll1ll1l1ll_fwb_(d=l1l111ll1l1ll_fwb_ (u"ࠪ࠶࠵࠷࠷࠮࠲࠹࠱࠶࠻ࠧᅧ")):
    now = datetime.datetime.now()
    try:
        year,month,day = d.split(l1l111ll1l1ll_fwb_ (u"ࠫ࠲࠵ࠧᅨ"))
        l111ll11l11ll1l1ll_fwb_ = l11lll1lll1ll1l1ll_fwb_[int(month)-1]
        l111ll11l11ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠬࡡࡂ࡞ࠪࠨࡷ࠱ࠦࠥࡴࠫ࡞࠳ࡇࡣࠧᅩ")%(l111ll11l11ll1l1ll_fwb_,year)
    except:
        l111ll11l11ll1l1ll_fwb_= l11lll1lll1ll1l1ll_fwb_[now.month]
    return l111ll11l11ll1l1ll_fwb_
def l1llll1111ll1l1ll_fwb_(month=l1l111ll1l1ll_fwb_ (u"࠭࠱࠳ࠩᅪ")):
    try:
        l111ll11l11ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠧ࡜ࡄࡠࠤࠪࡹ࡛࠰ࡄࡠࠫᅫ")%(l11lll1lll1ll1l1ll_fwb_[int(month)-1])
    except:
        now = datetime.datetime.now()
        l111ll11l11ll1l1ll_fwb_= l11lll1lll1ll1l1ll_fwb_[now.month]
    return l111ll11l11ll1l1ll_fwb_
def l1lll1ll1ll1l1ll_fwb_(url):
    content = _11l111ll1ll1l1ll_fwb_(url)
    ids = [(a.start(), a.end()) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠨ࠾࡯࡭ࠥࡩ࡬ࡢࡵࡶࡁࠧࡶࡲࡦ࡯࡬ࡩࡷ࡫ࡳࡍ࡫ࡶࡸࡤࡥࡢࡰࡺࠪᅬ"), content)]
    ids.append( (-1,-1) )
    l11l111l111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠩ࠿ࡹࡱࠦࡣ࡭ࡣࡶࡷࡂࠨ࡬ࡪࡵࡷࠤࡱ࡯ࡳࡵࡡࡢ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࠠࡕࡣࡥࡷࡓࡧࡶࠡࡵࡸࡦࡍ࡫ࡡࡥࡧࡵࡣࡤࡳ࡯࡯ࡶ࡫ࡷࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪᅭ"),content,re.DOTALL)
    if l11l111l111ll1l1ll_fwb_:
        l11l111l111ll1l1ll_fwb_=l11l111l111ll1l1ll_fwb_[0].split(l1l111ll1l1ll_fwb_ (u"ࠪࡀࡱ࡯ࠠࡤ࡮ࡤࡷࡸࡃࠢࠨᅮ"))
        current = [n for n, l in enumerate(l11l111l111ll1l1ll_fwb_) if l.startswith(l1l111ll1l1ll_fwb_ (u"ࠫ࡮ࡺࡥ࡮ࠢ࡬ࡸࡪࡳ࡟ࡠ࡫ࡶ࠱ࡦࡩࡴࡪࡸࡨࠫᅯ"))]
        if current:
            prev = re.findall(l1l111ll1l1ll_fwb_ (u"ࠬ࡯ࡴࡦ࡯ࠣࠦࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠱ࡧࡺࡩ࠵ࡰࡳࡧࡰ࡭ࡪࡸࡥ࠯ࠬࡂ࠭ࠧࡄ࠮ࠫࡁ࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠬᅰ"),l11l111l111ll1l1ll_fwb_[current[0]-1])
            next = re.findall(l1l111ll1l1ll_fwb_ (u"࠭ࡩࡵࡧࡰࠤࠧࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠲ࡨࡻࡪ࠯ࡱࡴࡨࡱ࡮࡫ࡲࡦ࠰࠭ࡃ࠮ࠨ࠾࠯ࠬࡂࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃ࠭ᅱ"),l11l111l111ll1l1ll_fwb_[current[0]+1])
            prev = l1l111ll1l1ll_fwb_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲࡫࡯࡬࡮ࡹࡨࡦ࠳ࡶ࡬ࠨᅲ")+prev[0] if prev else False
            next = l1l111ll1l1ll_fwb_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡬ࡩ࡭࡯ࡺࡩࡧ࠴ࡰ࡭ࠩᅳ")+next[0] if next else False
    out=[]
    for i in range(len(ids[:-1])):
        item = l11l1l1l1l1ll1l1ll_fwb_(content[ ids[i][1]:ids[i+1][0] ])
        l1l11111ll1l1ll_fwb_={}
        href = re.findall(l1l111ll1l1ll_fwb_ (u"ࠩ࠿ࡥࠥࡩ࡬ࡢࡵࡶࡁࠧ࡬ࡩ࡭࡯ࡓࡶࡪࡼࡩࡦࡹࡢࡣࡱ࡯࡮࡬ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᅴ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡷ࡫ࡦࠨᅵ")] = href[0] if href else l1l111ll1l1ll_fwb_ (u"ࠫࠬᅶ")
        year = re.findall(l1l111ll1l1ll_fwb_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡬ࡩ࡭࡯ࡓࡶࡪࡼࡩࡦࡹࡢࡣࡾ࡫ࡡࡳࠤࡁࡠࡸ࠰ࠨ࡝ࡦ࠮࠭ࡡࡹࠪࠨᅷ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡹࡦࡣࡵࠫᅸ")] = year[0] if year else l1l111ll1l1ll_fwb_ (u"ࠧࠨᅹ")
        l11ll1lll11ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡨ࡬ࡰࡲࡖࡲࡦࡸ࡬ࡩࡼࡥ࡟ࡧ࡫࡯ࡱ࡙࡯࡭ࡦࠤࠣࡨࡦࡺࡡ࠮ࡦࡸࡶࡦࡺࡩࡰࡰࡀࠦ࠭ࡢࡤࠬࠫࠥࠫᅺ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫᅻ")] = int(l11ll1lll11ll1l1ll_fwb_[0])*60 if l11ll1lll11ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠪࠫᅼ")
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡵࡸࡥ࡮࡫ࡨࡶࡪࡪࠧᅽ")] = l1l111ll1l1ll_fwb_ (u"ࠬ࠭ᅾ")
        try:
            l1lllll1l11ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡲࡢࡶࡨࡆࡴࡾ࡟ࡠࡴࡤࡸࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᅿ"),item)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡳࡣࡷ࡭ࡳ࡭ࠧᆀ")] = round(float(l1lllll1l11ll1l1ll_fwb_[-1].replace(l1l111ll1l1ll_fwb_ (u"ࠨ࠮ࠪᆁ"),l1l111ll1l1ll_fwb_ (u"ࠩ࠱ࠫᆂ"))),1) if l1lllll1l11ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠪࠫᆃ")
            l1l1111l111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡷࡧࡴࡦࡄࡲࡼࡤࡥࡶࡰࡶࡨࡷࠧࡄࠨ࠯ࠬࡂ࠭࡬࠭ᆄ"),item)
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬࡼ࡯ࡵࡧࡶࠫᆅ")] = int(l1l1111l111ll1l1ll_fwb_[-1].replace(l1l111ll1l1ll_fwb_ (u"࠭ࠠࠨᆆ"),l1l111ll1l1ll_fwb_ (u"ࠧࠨᆇ"))) if l1l1111l111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠨࠩᆈ")
        except:
            pass
        l111l1lll1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᆉ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪ࡭ࡲ࡭ࠧᆊ")] = l111l1lll1ll1l1ll_fwb_[0][:-5]+l1l111ll1l1ll_fwb_ (u"ࠫ࠸࠴ࡪࡱࡩࠪᆋ") if l111l1lll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠬ࠭ᆌ")
        title = re.findall(l1l111ll1l1ll_fwb_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡦࡪ࡮ࡰࡔࡷ࡫ࡶࡪࡧࡺࡣࡤࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᆍ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᆎ")] = title[0] if title else l1l111ll1l1ll_fwb_ (u"ࠨࠩᆏ")
        l111lllll11ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡩ࡭ࡱࡳࡐࡳࡧࡹ࡭ࡪࡽ࡟ࡠࡱࡵ࡭࡬࡯࡮ࡢ࡮ࡗ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩᆐ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪࡳࡷ࡯ࡧࡪࡰࡤࡰࡹ࡯ࡴ࡭ࡧࠪᆑ")] = l111lllll11ll1l1ll_fwb_[0].strip() if l111lllll11ll1l1ll_fwb_ else title
        l11l1ll11l1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠯ࡴࡧࡤࡶࡨ࡮࠯ࡧ࡫࡯ࡱࡡࡅࡧࡦࡰࡵࡩࡎࡪࡳ࠾࡞ࡧ࠯ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩᆒ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬ࡭ࡥ࡯ࡴࡨࠫᆓ")] = l1l111ll1l1ll_fwb_ (u"࠭ࠬࠨᆔ").join([x.strip() for x in l11l1ll11l1ll1l1ll_fwb_]) if l11l1ll11l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠧࠨᆕ")
        l11l1lll111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳ࡸ࡫ࡡࡳࡥ࡫࠳࡫࡯࡬࡮࡞ࡂࡧࡴࡻ࡮ࡵࡴࡼࡍࡩࡹ࠽࡝ࡦ࠮ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨᆖ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪᆗ")] = l1l111ll1l1ll_fwb_ (u"ࠪ࠰ࠬᆘ").join([x.strip() for x in l11l1lll111ll1l1ll_fwb_]) if l11l1lll111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠫࠬᆙ")
        l1111l11l1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡬ࡩ࡭࡯ࡓࡶࡪࡼࡩࡦࡹࡢࡣࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠤࡁࡀࡵࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᆚ"),item,re.DOTALL)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡰ࡭ࡱࡷࠫᆛ")] = l1111l11l1ll1l1ll_fwb_[0].strip() if l1111l11l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠧࠨᆜ")
        l11l11l1111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠨࡦࡤࡸࡦ࠳ࠨࡀ࠼ࡩ࡭ࡱࡳࡼࡪࡦࠬࡁࠧ࠮࠮ࠫࡁࠬࠦࠬᆝ"),item)
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡧࡥࡹࡧ࡟ࡧ࡫࡯ࡱࠬᆞ")] = l11l11l1111ll1l1ll_fwb_[0] if l11l11l1111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠪࠫᆟ")
        l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡲ࡫ࡤࡪࡣࡷࡽࡵ࡫ࠧᆠ")]= l1l111ll1l1ll_fwb_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫᆡ")
        if l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡨࡳࡧࡩࠫᆢ")]:
            if l1l111ll1l1ll_fwb_ (u"ࠧ࠰ࡵࡨࡶ࡮ࡧ࡬࠰ࠩᆣ") in l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡪࡵࡩ࡫࠭ᆤ")]:
                l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩ࡬ࡷࡋࡵ࡬ࡥࡧࡵࠫᆥ")] = True
                l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪࡱࡪࡪࡩࡢࡶࡼࡴࡪ࠭ᆦ")]=l1l111ll1l1ll_fwb_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࠬᆧ")
            out.append(l1l11111ll1l1ll_fwb_)
    return out,(prev,next)
l11lllll1ll1l1ll_fwb_ = lambda (t) : t.encode(l1l111ll1l1ll_fwb_ (u"ࠬࡻࡴࡧ࠯࠻ࠫᆨ")) if isinstance(t,unicode) else t
def l11l1l111ll1l1ll_fwb_(title=l1l111ll1l1ll_fwb_ (u"࠭ࡄࡰࡴࡺࡥऌ࠭ᆩ"),l111lll1ll1l1ll_fwb_=1,url=l1l111ll1l1ll_fwb_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲࡫࡯࡬࡮ࡹࡨࡦ࠳ࡶ࡬࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡀࠫᆪ")):
    extra =l1l111ll1l1ll_fwb_ (u"ࠨࠨࡲࡶࡩ࡫ࡲࡃࡻࡀࡣࡸࡩ࡯ࡳࡧࠩࡨࡪࡹࡣࡦࡰࡧ࡭ࡳ࡭࠽ࡵࡴࡸࡩࠫࡶࡡࡨࡧࡀࠫᆫ")+str(l111lll1ll1l1ll_fwb_)
    l111ll1ll11ll1l1ll_fwb_=url+urllib.quote_plus(l11lllll1ll1l1ll_fwb_(title))+extra
    content = _11l111ll1ll1l1ll_fwb_(l111ll1ll11ll1l1ll_fwb_)
    if l1l111ll1l1ll_fwb_ (u"ࠩ࠲ࡴࡪࡸࡳࡰࡰࡶࠫᆬ") in url:
        out = _11l1l1lll1ll1l1ll_fwb_(content)
    else:
        out = _11ll11l1l1ll1l1ll_fwb_(content,url)
    if l1l111ll1l1ll_fwb_ (u"ࠪ࠲ࡵࡲ࠯ࡴࡧࡤࡶࡨ࡮࠿ࡲ࠿ࠪᆭ") in url:
        extra = []
        l11l11l1ll1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࡺࡥ࡮ࡡࡢࡸ࡮ࡺ࡬ࡦࠤࡁࡠࡸ࠰ࡦࡪ࡮ࡰࡽࡡࡹࠪ࠽࠱ࡶࡴࡦࡴ࠾࡝ࡵ࠭ࡀࡸࡶࡡ࡯ࠢࡦࡰࡦࡹࡳ࠾ࠤࡗࡥࡧࡹࡎࡢࡸࡢࡣ࡭࡯ࡴࡴࠤࡁࡠࡸ࠰ࠨ࡝ࡦ࠮࠭ࡡࡹࠪ࠽࠱ࡶࡴࡦࡴ࠾ࠨᆮ"),content)
        if l11l11l1ll1ll1l1ll_fwb_:
            extra.append({l1l111ll1l1ll_fwb_ (u"ࠬࡥࡴࡪࡶ࡯ࡩࠬᆯ"):l1l111ll1l1ll_fwb_ (u"࡛࠭ࡃ࡟࡚࡭ࡪࡩࡥ࡫ࠢࡉ࡭ࡱࡳࡹ࡜࠱ࡅࡡࠬᆰ"),l1l111ll1l1ll_fwb_ (u"ࠧࡤࡱࡧࡩࠬᆱ"):l11l11l1ll1ll1l1ll_fwb_[0],l1l111ll1l1ll_fwb_ (u"ࠨࡡ࡫ࡶࡪ࡬ࠧᆲ"):title,l1l111ll1l1ll_fwb_ (u"ࠩࡱࡩࡽࡺ࡟ࡶࡴ࡯ࠫᆳ"):l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡧ࡫࡯ࡱࡼ࡫ࡢ࠯ࡲ࡯࠳࡫࡯࡬࡮ࡵ࠲ࡷࡪࡧࡲࡤࡪࡂࡵࡂ࠭ᆴ")})
        l11lll1l1l1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࡺࡥ࡮ࡡࡢࡸ࡮ࡺ࡬ࡦࠤࡁࡠࡸ࠰ࡳࡦࡴ࡬ࡥࡱ࡫࡜ࡴࠬ࠿࠳ࡸࡶࡡ࡯ࡀ࡟ࡷ࠯ࡂࡳࡱࡣࡱࠤࡨࡲࡡࡴࡵࡀ࡙ࠦࡧࡢࡴࡐࡤࡺࡤࡥࡨࡪࡶࡶࠦࡃࡢࡳࠫࠪ࡟ࡨ࠰࠯࡜ࡴࠬ࠿࠳ࡸࡶࡡ࡯ࡀࠪᆵ"),content)
        if l11lll1l1l1ll1l1ll_fwb_:
            extra.append({l1l111ll1l1ll_fwb_ (u"ࠬࡥࡴࡪࡶ࡯ࡩࠬᆶ"):l1l111ll1l1ll_fwb_ (u"࡛࠭ࡃ࡟࡚࡭ࡪࡩࡥ࡫ࠢࡖࡩࡷ࡯ࡡ࡭ࡧ࡞࠳ࡇࡣࠧᆷ"),l1l111ll1l1ll_fwb_ (u"ࠧࡤࡱࡧࡩࠬᆸ"):l11lll1l1l1ll1l1ll_fwb_[0], l1l111ll1l1ll_fwb_ (u"ࠨࡡ࡫ࡶࡪ࡬ࠧᆹ"):title,l1l111ll1l1ll_fwb_ (u"ࠩࡱࡩࡽࡺ࡟ࡶࡴ࡯ࠫᆺ"):l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡧ࡫࡯ࡱࡼ࡫ࡢ࠯ࡲ࡯࠳ࡸ࡫ࡲࡪࡣ࡯ࡷ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷ࠽ࠨᆻ")})
        l11l11lll11ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࡺࡥ࡮ࡡࡢࡸ࡮ࡺ࡬ࡦࠤࡁࡠࡸ࠰ࡐࡳࡱࡪࡶࡦࡳࡹࠡࡖ࡙ࡠࡸ࠰࠼࠰ࡵࡳࡥࡳࡄ࡜ࡴࠬ࠿ࡷࡵࡧ࡮ࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡖࡤࡦࡸࡔࡡࡷࡡࡢ࡬࡮ࡺࡳࠣࡀ࡟ࡷ࠯࠮࡜ࡥ࠭ࠬࡠࡸ࠰࠼࠰ࡵࡳࡥࡳࡄࠧᆼ"),content)
        if l11l11lll11ll1l1ll_fwb_ :
            extra.append({l1l111ll1l1ll_fwb_ (u"ࠬࡥࡴࡪࡶ࡯ࡩࠬᆽ"):l1l111ll1l1ll_fwb_ (u"࡛࠭ࡃ࡟࡚࡭ࡪࡩࡥ࡫ࠢࡓࡶࡴ࡭ࡲࡢ࡯ࡼࡘ࡛ࡡ࠯ࡃ࡟ࠪᆾ"),l1l111ll1l1ll_fwb_ (u"ࠧࡤࡱࡧࡩࠬᆿ"):l11l11lll11ll1l1ll_fwb_[0], l1l111ll1l1ll_fwb_ (u"ࠨࡡ࡫ࡶࡪ࡬ࠧᇀ"):title,l1l111ll1l1ll_fwb_ (u"ࠩࡱࡩࡽࡺ࡟ࡶࡴ࡯ࠫᇁ"):l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡧ࡫࡯ࡱࡼ࡫ࡢ࠯ࡲ࡯࠳ࡹࡼࡳࡩࡱࡺࡷ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷ࠽ࠨᇂ")})
        l11l1ll1111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࡺࡥ࡮ࡡࡢࡸ࡮ࡺ࡬ࡦࠤࡁࡠࡸ࠰࡬ࡶࡦࡽ࡭ࡪࠦ࡫ࡪࡰࡤࡠࡸ࠰࠼࠰ࡵࡳࡥࡳࡄ࡜ࡴࠬ࠿ࡷࡵࡧ࡮ࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡖࡤࡦࡸࡔࡡࡷࡡࡢ࡬࡮ࡺࡳࠣࡀ࡟ࡷ࠯࠮࡜ࡥ࠭ࠬࡠࡸ࠰࠼࠰ࡵࡳࡥࡳࡄࠧᇃ"),content)
        if l11l1ll1111ll1l1ll_fwb_ :
            extra.append({l1l111ll1l1ll_fwb_ (u"ࠬࡥࡴࡪࡶ࡯ࡩࠬᇄ"):l1l111ll1l1ll_fwb_ (u"࡛࠭ࡃ࡟࡚࡭ࡪࡩࡥ࡫ࠢࡏࡹࡩࢀࡩࡦ࡝࠲ࡆࡢ࠭ᇅ"),l1l111ll1l1ll_fwb_ (u"ࠧࡤࡱࡧࡩࠬᇆ"):l11l1ll1111ll1l1ll_fwb_[0], l1l111ll1l1ll_fwb_ (u"ࠨࡡ࡫ࡶࡪ࡬ࠧᇇ"):title,l1l111ll1l1ll_fwb_ (u"ࠩࡱࡩࡽࡺ࡟ࡶࡴ࡯ࠫᇈ"):l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡧ࡫࡯ࡱࡼ࡫ࡢ࠯ࡲ࡯࠳ࡵ࡫ࡲࡴࡱࡱࡷ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷ࠽ࠨᇉ")})
    else:
        extra=[]
    return out,extra
def l1l1111l1ll1l1ll_fwb_(url,l1ll1ll111ll1l1ll_fwb_={}):
    l111ll1ll11ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡨ࡬ࡰࡲࡽࡥࡣ࠰ࡳࡰࠬᇊ")+url
    l111ll1ll11ll1l1ll_fwb_ += l1l111ll1l1ll_fwb_ (u"ࠬ࠭ᇋ") if l111ll1ll11ll1l1ll_fwb_.endswith(l1l111ll1l1ll_fwb_ (u"࠭࠯ࠨᇌ")) else l1l111ll1l1ll_fwb_ (u"ࠧ࠰ࠩᇍ")
    l111ll1ll11ll1l1ll_fwb_ += l1l111ll1l1ll_fwb_ (u"ࠨࠩᇎ") if l1l111ll1l1ll_fwb_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨࡷࠬᇏ") in l111ll1ll11ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬᇐ")
    try:
        content = _11l111ll1ll1l1ll_fwb_(l111ll1ll11ll1l1ll_fwb_)
    except:
        l111ll1ll11ll1l1ll_fwb_=re.sub(l1l111ll1l1ll_fwb_ (u"ࠫࡁࡡ࠯࡝࠭ࡠ࠮ࡡࡽ࠾ࠨᇑ"),l1l111ll1l1ll_fwb_ (u"ࠬ࠭ᇒ"),urllib.unquote(l111ll1ll11ll1l1ll_fwb_))
        l111ll1ll11ll1l1ll_fwb_=urllib.quote(l111ll1ll11ll1l1ll_fwb_).replace(l1l111ll1l1ll_fwb_ (u"࠭ࠥ࠴ࡃࠪᇓ"),l1l111ll1l1ll_fwb_ (u"ࠧ࠻ࠩᇔ")).replace(l1l111ll1l1ll_fwb_ (u"ࠨࠧ࠵ࡆࠬᇕ"),l1l111ll1l1ll_fwb_ (u"ࠩ࠮ࠫᇖ"))
        content = _11l111ll1ll1l1ll_fwb_(l111ll1ll11ll1l1ll_fwb_)
    year = re.findall(l1l111ll1l1ll_fwb_ (u"ࠪࡀࡸࡶࡡ࡯ࠢࡦࡰࡦࡹࡳ࠾ࠤ࡫ࡥࡱ࡬ࡓࡪࡼࡨࠦࡃࡢࠨࠩ࡞ࡧࡿ࠹ࢃࠩ࡜࡞ࡶ࠱ࡢ࠰ࠧᇗ"),content)
    year = year[0] if year else l1l111ll1l1ll_fwb_ (u"ࠫࠬᇘ")
    l11l11l1111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠬࡪࡡࡵࡣ࠰ࡪ࡮ࡲ࡭࡜࡫ࡧࡡ࠯ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᇙ"),content)
    l11l11l1111ll1l1ll_fwb_ = l11l11l1111ll1l1ll_fwb_[0] if l11l11l1111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"࠭ࠧᇚ")
    href = l111ll1ll11ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩᇛ"),l1l111ll1l1ll_fwb_ (u"ࠨࠩᇜ"))
    ids = [(a.start(), a.group(1)) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠩ࠿ࡨࡹࠦࡤࡢࡶࡤ࠱࡫࡯࡬࡮࡫ࡧࡁࠧࡢࡤࠬࠤࠣ࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᇝ"), content)]
    ids.append( (-1,l1l111ll1l1ll_fwb_ (u"ࠪࠫᇞ")) )
    out={}
    for i in range(len(ids[:-1])):
        l1111l1111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠫ࠭ࡢࡤࡼ࠳࠯࠶ࢂ࠯ࠧᇟ"),ids[i][1])
        l1111l1111ll1l1ll_fwb_ = int(l1111l1111ll1l1ll_fwb_[0]) if l1111l1111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠬ࠭ᇠ")
        if l1111l1111ll1l1ll_fwb_:
            out[l1l111ll1l1ll_fwb_ (u"࠭ࡓࡦࡼࡲࡲࠥࠫ࠰࠳ࡦࠪᇡ")%l1111l1111ll1l1ll_fwb_]=[]
            item = l11l1l1l1l1ll1l1ll_fwb_(content[ ids[i][0]:ids[i+1][0] ])
            l1l11l1ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠧ࠽࡮࡬ࠤࡩࡧࡴࡢ࠯࡬ࡨࡂࠨ࡜ࡥ࠭ࠥࠤࡨࡲࡡࡴࡵࡀࠦࡪࡶࡩࡴࡱࡧࡩࠥ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩᇢ"),item,re.DOTALL)
            for l11l11ll1l1ll1l1ll_fwb_ in l1l11l1ll1l1ll_fwb_:
                l1l11111ll1l1ll_fwb_={}
                l1l11111ll1l1ll_fwb_.update(l1ll1ll111ll1l1ll_fwb_)
                l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡶࡹࡷ࡭ࡵࡷࡵ࡫ࡷࡰࡪ࠭ᇣ")]=l1l11111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠩࡷ࡭ࡹࡲࡥࠨᇤ"))
                l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪࡳࡷ࡯ࡧࡪࡰࡤࡰࡹ࡯ࡴ࡭ࡧࠪᇥ")]=l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡹࡼࡳࡩࡱࡺࡸ࡮ࡺ࡬ࡦࠩᇦ")]
                l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬࡹࡥࡢࡵࡲࡲࠬᇧ")]=l1111l1111ll1l1ll_fwb_
                l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡹࡦࡣࡵࠫᇨ")]=year if not l1ll1ll111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠧࡺࡧࡤࡶࠬᇩ")) else l1ll1ll111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠨࡻࡨࡥࡷ࠭ᇪ"),year)
                l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡧࡥࡹࡧ࡟ࡧ࡫࡯ࡱࠬᇫ")]=l11l11l1111ll1l1ll_fwb_  if not l1ll1ll111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠪࡨࡦࡺࡡࡠࡨ࡬ࡰࡲ࠭ᇬ")) else l1ll1ll111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠫࡩࡧࡴࡢࡡࡩ࡭ࡱࡳࠧᇭ"),l11l11l1111ll1l1ll_fwb_)
                l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡲࡦࡨࠪᇮ")]=href  if not l1ll1ll111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"࠭ࡨࡳࡧࡩࠫᇯ")) else l1ll1ll111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠧࡩࡴࡨࡪࠬᇰ"),href)
                l11ll1ll111ll1l1ll_fwb_=re.findall(l1l111ll1l1ll_fwb_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡰࡶ࡮࡯࠱ࡱ࡫ࡦࡵࠢࡱࡳࡷࡳࡡ࡭ࠤࡁࠬࡡࡪࠫࠪࠩᇱ"),l11l11ll1l1ll1l1ll_fwb_)
                l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࠪᇲ")] = int(l11ll1ll111ll1l1ll_fwb_[0]) if l11ll1ll111ll1l1ll_fwb_ else 0
                l111ll11ll1ll1l1ll_fwb_ =re.findall(l1l111ll1l1ll_fwb_ (u"ࠪࡨࡦࡺࡡ࠮ࡦࡤࡸࡪ࠳ࡰࡳࡧࡰ࡭ࡪࡸࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᇳ"),l11l11ll1l1ll1l1ll_fwb_)
                l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡵࡸࡥ࡮࡫ࡨࡶࡪࡪࠧᇴ")] = l111ll11ll1ll1l1ll_fwb_[0] if l111ll11ll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠬ࠭ᇵ")
                l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡡࡪࡴࡨࡨࠬᇶ")] = l111ll11ll1ll1l1ll_fwb_[0] if len(l111ll11ll1ll1l1ll_fwb_)>1 else l1l111ll1l1ll_fwb_ (u"ࠧࠨᇷ")
                title= re.findall(l1l111ll1l1ll_fwb_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨ࡮ࡰࡴࡰࡥࡱࠦࡴࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᇸ"),l11l11ll1l1ll1l1ll_fwb_)
                l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡷ࡭ࡹࡲࡥࠨᇹ")] = title[0].strip() if title else l1l111ll1l1ll_fwb_ (u"ࠪࠫᇺ")
                l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪᇻ")] = l1l111ll1l1ll_fwb_ (u"࡙ࠬࠥ࠱࠴ࡧࡉࠪ࠶࠲ࡥࠢࠪᇼ")%(l1111l1111ll1l1ll_fwb_,l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࠧᇽ")]) + l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᇾ")]
                if l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࠩᇿ")]:
                    out[l1l111ll1l1ll_fwb_ (u"ࠩࡖࡩࡿࡵ࡮ࠡࠧ࠳࠶ࡩ࠭ሀ")%l1111l1111ll1l1ll_fwb_].append(l1l11111ll1l1ll_fwb_)
    return out
def _11lll11111ll1l1ll_fwb_(method):
    signature = method + l1l111ll1l1ll_fwb_ (u"ࠥࡠࡳࠨሁ") + l11llll11l1ll1l1ll_fwb_ + l11l1111l11ll1l1ll_fwb_;
    signature = VERSION + l1l111ll1l1ll_fwb_ (u"ࠦ࠱ࠨሂ") + hashlib.md5(signature).hexdigest();
    return signature;
def _11l1l11ll1ll1l1ll_fwb_(method):
    signature = _11lll11111ll1l1ll_fwb_(method);
    method += l1l111ll1l1ll_fwb_ (u"ࠧࡢ࡮ࠣሃ");
    qs={    l1l111ll1l1ll_fwb_ (u"࠭࡭ࡦࡶ࡫ࡳࡩࡹࠧሄ"):method,
            l1l111ll1l1ll_fwb_ (u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࠪህ"):signature,
            l1l111ll1l1ll_fwb_ (u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩሆ"):VERSION,
            l1l111ll1l1ll_fwb_ (u"ࠩࡤࡴࡵࡏࡤࠨሇ"):l11llll11l1ll1l1ll_fwb_}
    return urllib.urlencode(qs)
def _111ll1lll1ll1l1ll_fwb_(response,_11ll1llll1ll1l1ll_fwb_):
    _11ll11ll11ll1l1ll_fwb_ = response.split(l1l111ll1l1ll_fwb_ (u"ࠪࠤࡹࡀࠧለ"))[0].split(l1l111ll1l1ll_fwb_ (u"ࠫࡡࡴࠧሉ"))
    status = _11ll11ll11ll1l1ll_fwb_[0]
    data = _11ll11ll11ll1l1ll_fwb_[1]
    out={}
    if data==l1l111ll1l1ll_fwb_ (u"ࠬࡴࡵ࡭࡮ࠪሊ"): pass
    else:
        l11ll111111ll1l1ll_fwb_=json.loads(data)
        N=len(l11ll111111ll1l1ll_fwb_)
        for k,v in _11ll1llll1ll1l1ll_fwb_.iteritems():
            if l11ll111111ll1l1ll_fwb_[k]==None:
                l11ll111111ll1l1ll_fwb_[k]=l1l111ll1l1ll_fwb_ (u"࠭ࠧላ")
            if N>= k: out[v]=l11ll111111ll1l1ll_fwb_[k]
    return out
def getFilmInfoFull(filmID=l1l111ll1l1ll_fwb_ (u"ࠧ࠳࠵࠶ࠫሌ")):
    method = l1l111ll1l1ll_fwb_ (u"ࠨࡩࡨࡸࡋ࡯࡬࡮ࡋࡱࡪࡴࡌࡵ࡭࡮ࠣ࡟ࠬል") + filmID + l1l111ll1l1ll_fwb_ (u"ࠩࡠࠫሎ")
    _11ll1llll1ll1l1ll_fwb_ ={
        0 :  l1l111ll1l1ll_fwb_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩሏ"),
        1 :  l1l111ll1l1ll_fwb_ (u"ࠫࡴࡸࡩࡨ࡫ࡱࡥࡱࡺࡩࡵ࡮ࡨࠫሐ"),
        2 :  l1l111ll1l1ll_fwb_ (u"ࠬࡸࡡࡵ࡫ࡱ࡫ࠬሑ"),
        3 :  l1l111ll1l1ll_fwb_ (u"࠭ࡶࡰࡶࡨࡷࠬሒ"),
        4 :  l1l111ll1l1ll_fwb_ (u"ࠧࡨࡧࡱࡶࡪ࠭ሓ"),
        5 :  l1l111ll1l1ll_fwb_ (u"ࠨࡻࡨࡥࡷ࠭ሔ"),
        6 :  l1l111ll1l1ll_fwb_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫሕ"),
        7 :  l1l111ll1l1ll_fwb_ (u"ࠪࡧࡴࡳ࡭ࡦࡰࡷࡷࡈࡵࡵ࡯ࡶࠪሖ"),
        8 :  l1l111ll1l1ll_fwb_ (u"ࠫ࡫ࡵࡲࡶ࡯ࡘࡶࡱ࠭ሗ"),
        9 :  l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡡࡴࡔࡨࡺ࡮࡫ࡷࠨመ"),
        10 :  l1l111ll1l1ll_fwb_ (u"࠭ࡨࡢࡵࡇࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠧሙ"),
        11 :  l1l111ll1l1ll_fwb_ (u"ࠧࡪ࡯ࡪࠫሚ"),
        12 :  l1l111ll1l1ll_fwb_ (u"ࠨࡸ࡬ࡨࡪࡵࠧማ"),
        13 :  l1l111ll1l1ll_fwb_ (u"ࠩࡳࡶࡪࡳࡩࡦࡴࡨ࡛ࡴࡸ࡬ࡥࠩሜ"),
        14 :  l1l111ll1l1ll_fwb_ (u"ࠪࡨࡦࡺࡥࠨም"),
        15 :  l1l111ll1l1ll_fwb_ (u"ࠫ࡫࡯࡬࡮ࡖࡼࡴࡪ࠭ሞ"),
        16 :  l1l111ll1l1ll_fwb_ (u"ࠬࡹࡥࡢࡵࡲࡲࡸࡉ࡯ࡶࡰࡷࠫሟ"),
        17 :  l1l111ll1l1ll_fwb_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࡄࡱࡸࡲࡹ࠭ሠ"),
        18 :  l1l111ll1l1ll_fwb_ (u"ࠧࡴࡶࡸࡨ࡮ࡵࠧሡ"),
        19 :  l1l111ll1l1ll_fwb_ (u"ࠨࡲ࡯ࡳࡹ࠭ሢ")
    }
    try:
        response = _11l111ll1ll1l1ll_fwb_( l11l111lll1ll1l1ll_fwb_ + _11l1l11ll1ll1l1ll_fwb_(method))
        out = {}
        if response[:2]==l1l111ll1l1ll_fwb_ (u"ࠩࡲ࡯ࠬሣ"):
            out =_111ll1lll1ll1l1ll_fwb_(response,_11ll1llll1ll1l1ll_fwb_)
            out[l1l111ll1l1ll_fwb_ (u"ࠪࡪ࡮ࡲ࡭ࡸࡧࡥࠫሤ")]=filmID
            if out.get(l1l111ll1l1ll_fwb_ (u"ࠫࡻ࡯ࡤࡦࡱࠪሥ")):
                l111ll1l111ll1l1ll_fwb_ = [ x for x in out.get(l1l111ll1l1ll_fwb_ (u"ࠬࡼࡩࡥࡧࡲࠫሦ")) if l1l111ll1l1ll_fwb_ (u"࠭࡭ࡱ࠶ࠪሧ") in str(x) ]
                pattern = [l1l111ll1l1ll_fwb_ (u"ࠧ࠯࠵࠹࠴ࡵ࠴ࠧረ"), l1l111ll1l1ll_fwb_ (u"ࠨ࠰࠷࠼࠵ࡶ࠮ࠨሩ"), l1l111ll1l1ll_fwb_ (u"ࠩ࠱࠻࠷࠶ࡰ࠯ࠩሪ")]
                l11lll11ll1ll1l1ll_fwb_ = l111ll1l111ll1l1ll_fwb_[0]
                for p in pattern:
                    for t in l111ll1l111ll1l1ll_fwb_:
                        if p in t: l11lll11ll1ll1l1ll_fwb_ = t
                out[l1l111ll1l1ll_fwb_ (u"ࠪࡸࡷࡧࡩ࡭ࡧࡵࠫራ")]=l11lll11ll1ll1l1ll_fwb_
            if out.get(l1l111ll1l1ll_fwb_ (u"ࠫ࡮ࡳࡧࠨሬ")): out[l1l111ll1l1ll_fwb_ (u"ࠬ࡯࡭ࡨࠩር")]=l1l11111111ll1l1ll_fwb_ + out.get(l1l111ll1l1ll_fwb_ (u"࠭ࡩ࡮ࡩࠪሮ")).replace(l1l111ll1l1ll_fwb_ (u"ࠧ࠯࠴࠱ࠫሯ"),l1l111ll1l1ll_fwb_ (u"ࠨ࠰࠶࠲ࠬሰ"))
            if out.get(l1l111ll1l1ll_fwb_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫሱ")): out[l1l111ll1l1ll_fwb_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬሲ")] = float(out.get(l1l111ll1l1ll_fwb_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭ሳ")))*60
    except:
        out = {}
    return out
def l1l1111l1l1ll1l1ll_fwb_(filmID=l1l111ll1l1ll_fwb_ (u"ࠬ࠸࠲࠱࠲࠻࠶ࠬሴ")):
    method = l1l111ll1l1ll_fwb_ (u"࠭ࡧࡦࡶࡉ࡭ࡱࡳࡳࡊࡰࡩࡳࡘ࡮࡯ࡳࡶࠣ࡟ࡠ࠭ስ") + filmID + l1l111ll1l1ll_fwb_ (u"ࠧ࡞࡟ࠪሶ")
    _11ll1llll1ll1l1ll_fwb_ = {
        0 :  l1l111ll1l1ll_fwb_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧሷ"),
        1 :  l1l111ll1l1ll_fwb_ (u"ࠩࡼࡩࡦࡸࠧሸ"),
        2 :  l1l111ll1l1ll_fwb_ (u"ࠪࡶࡦࡺࡩ࡯ࡩࠪሹ"),
        3 :  l1l111ll1l1ll_fwb_ (u"ࠫࡤ࠭ሺ"),
        4 :  l1l111ll1l1ll_fwb_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧሻ"),
        5 :  l1l111ll1l1ll_fwb_ (u"࠭ࡩ࡮ࡩࠪሼ"),
        6 :  l1l111ll1l1ll_fwb_ (u"ࠧࡪࡦࠪሽ")}
    response = _11l111ll1ll1l1ll_fwb_( l11l111lll1ll1l1ll_fwb_ + _11l1l11ll1ll1l1ll_fwb_(method))
    out = {}
    if response[:2]==l1l111ll1l1ll_fwb_ (u"ࠨࡱ࡮ࠫሾ"): out =_111ll1lll1ll1l1ll_fwb_(response.replace(l1l111ll1l1ll_fwb_ (u"ࠩ࡞࡟ࠬሿ"),l1l111ll1l1ll_fwb_ (u"ࠪ࡟ࠬቀ")).replace(l1l111ll1l1ll_fwb_ (u"ࠫࡢࡣࠧቁ"),l1l111ll1l1ll_fwb_ (u"ࠬࡣࠧቂ")),_11ll1llll1ll1l1ll_fwb_)
    return out
def l11ll1l11l1ll1l1ll_fwb_(filmID=l1l111ll1l1ll_fwb_ (u"࠭࠵࠺࠶࠶࠹࠼࠭ቃ"), t=l1l111ll1l1ll_fwb_ (u"ࠧࡢࡥࡷࡳࡷࡹࠧቄ")):
    l11ll1111l1ll1l1ll_fwb_ = { l1l111ll1l1ll_fwb_ (u"ࠨࡦ࡬ࡶࡪࡩࡴࡰࡴࡶࠫቅ"): l1l111ll1l1ll_fwb_ (u"ࠩ࠴ࠫቆ"), l1l111ll1l1ll_fwb_ (u"ࠪࡷࡨ࡫࡮ࡢࡴ࡬ࡷࡹࡹࠧቇ"): l1l111ll1l1ll_fwb_ (u"ࠫ࠷࠭ቈ"), l1l111ll1l1ll_fwb_ (u"ࠬࡳࡵࡴ࡫ࡦࡷࠬ቉"): l1l111ll1l1ll_fwb_ (u"࠭࠳ࠨቊ"), l1l111ll1l1ll_fwb_ (u"ࠧࡱࡪࡲࡸࡴࡹࠧቋ"): l1l111ll1l1ll_fwb_ (u"ࠨ࠶ࠪቌ"), l1l111ll1l1ll_fwb_ (u"ࠩࡤࡧࡹࡵࡲࡴࠩቍ"): l1l111ll1l1ll_fwb_ (u"ࠪ࠺ࠬ቎"), l1l111ll1l1ll_fwb_ (u"ࠫࡵࡸ࡯ࡥࡷࡦࡩࡷࡹࠧ቏"): l1l111ll1l1ll_fwb_ (u"ࠬ࠿ࠧቐ") }
    l11ll11lll1ll1l1ll_fwb_ = [l1l111ll1l1ll_fwb_ (u"࠭ࡩࡥࠩቑ"), l1l111ll1l1ll_fwb_ (u"ࠧࡳࡱ࡯ࡩࠬቒ"), l1l111ll1l1ll_fwb_ (u"ࠨࡴࡲࡰࡪࡥࡴࡺࡲࡨࠫቓ"), l1l111ll1l1ll_fwb_ (u"ࠩࡱࡥࡲ࡫ࠧቔ"), l1l111ll1l1ll_fwb_ (u"ࠪ࡭ࡲ࡭ࠧቕ")]
    l11ll1l1ll1ll1l1ll_fwb_ = {}
    if t in l11ll1111l1ll1l1ll_fwb_.keys():
        method = l1l111ll1l1ll_fwb_ (u"ࠫ࡬࡫ࡴࡇ࡫࡯ࡱࡕ࡫ࡲࡴࡱࡱࡷࠥࡡࠧቖ") + str(filmID) + l1l111ll1l1ll_fwb_ (u"ࠬ࠲ࠠࠨ቗") + l11ll1111l1ll1l1ll_fwb_[t] + l1l111ll1l1ll_fwb_ (u"࠭ࠬࠡ࠲࠯ࠤ࠺࠶࡝ࠨቘ")
        response = _11l111ll1ll1l1ll_fwb_( l11l111lll1ll1l1ll_fwb_ + _11l1l11ll1ll1l1ll_fwb_(method))
        l11llllll11ll1l1ll_fwb_ = re.search(l1l111ll1l1ll_fwb_ (u"ࠧࠩ࡞࡞࠲࠯ࡢ࡝ࠪࠩ቙"), response)
        l111lll1111ll1l1ll_fwb_ = json.loads(l11llllll11ll1l1ll_fwb_.group(1))
        for data in l111lll1111ll1l1ll_fwb_:
            l11ll1l1ll1ll1l1ll_fwb_[data[0]] = {}
            for i in range(0, len(l11ll11lll1ll1l1ll_fwb_)):
                if l11ll11lll1ll1l1ll_fwb_[i] == l1l111ll1l1ll_fwb_ (u"ࠨ࡫ࡰ࡫ࠬቚ"): l11ll1l1ll1ll1l1ll_fwb_[data[0]][l11ll11lll1ll1l1ll_fwb_[i]] = l1l111ll1l1ll_fwb_ (u"ࠩࠪቛ") if data[i] == None else l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠳࡬ࡷࡤࡦࡱ࠲ࡵࡲ࠯ࡱࠩቜ") + data[i].encode(l1l111ll1l1ll_fwb_ (u"ࠫࡺࡺࡦ࠮࠺ࠪቝ")).replace(l1l111ll1l1ll_fwb_ (u"ࠬ࠴࠱࠯࡬ࡳ࡫ࠬ቞"), l1l111ll1l1ll_fwb_ (u"࠭࠮࠴࠰࡭ࡴ࡬࠭቟"))
                else: l11ll1l1ll1ll1l1ll_fwb_[data[0]][l11ll11lll1ll1l1ll_fwb_[i]] = data[i].encode(l1l111ll1l1ll_fwb_ (u"ࠧࡶࡶࡩ࠱࠽࠭በ")) if type(data[i]) == unicode else data[i]
    return l11ll1l1ll1ll1l1ll_fwb_
def l11ll1ll1l1ll1l1ll_fwb_ ():
    method = l1l111ll1l1ll_fwb_ (u"ࠨࡩࡨࡸࡆࡲ࡬ࡄࡪࡤࡲࡳ࡫࡬ࡴࠢ࡞ࠦࠧࡣࠧቡ")
    _11ll1llll1ll1l1ll_fwb_ = {0 :  l1l111ll1l1ll_fwb_ (u"ࠩࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠧቢ")}
    response = _11l111ll1ll1l1ll_fwb_( l11l111lll1ll1l1ll_fwb_ + _11l1l11ll1ll1l1ll_fwb_(method))
    out = {}
    if response[:2]==l1l111ll1l1ll_fwb_ (u"ࠪࡳࡰ࠭ባ"): out =_111ll1lll1ll1l1ll_fwb_(response,_11ll1llll1ll1l1ll_fwb_)
    return out
def l11l1ll1ll1ll1l1ll_fwb_(filmID=l1l111ll1l1ll_fwb_ (u"ࠫ࠷࠸࠰࠱࠺࠵ࠫቤ")):
    method = l1l111ll1l1ll_fwb_ (u"ࠬ࡭ࡥࡵࡒࡲࡴࡺࡲࡡࡳࡈ࡬ࡰࡲࡹࠠ࡜ࡰࡸࡰࡱ࠲࡮ࡶ࡮࡯ࡡࠬብ")
    _11ll1llll1ll1l1ll_fwb_ = {0 :  l1l111ll1l1ll_fwb_ (u"࠭ࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠫቦ")}
    response = _11l111ll1ll1l1ll_fwb_( l11l111lll1ll1l1ll_fwb_ + _11l1l11ll1ll1l1ll_fwb_(method))
    out = {}
    if response[:2]==l1l111ll1l1ll_fwb_ (u"ࠧࡰ࡭ࠪቧ"): out =_111ll1lll1ll1l1ll_fwb_(response,_11ll1llll1ll1l1ll_fwb_)
    return out
def l11ll111ll1ll1l1ll_fwb_(filmID=l1l111ll1l1ll_fwb_ (u"ࠨ࠳࠻࠶࠵࠺࠰ࠨቨ")):
    method = l1l111ll1l1ll_fwb_ (u"ࠩࡪࡩࡹࡌࡩ࡭࡯࡙࡭ࡩ࡫࡯ࡴࠢ࡞࠹࠻࠾࠲࠲࠸࠯࠵࠱࠸࡝ࠨቩ")
    _11ll1llll1ll1l1ll_fwb_ = {0 :  l1l111ll1l1ll_fwb_ (u"ࠪࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠨቪ")}
    response = _11l111ll1ll1l1ll_fwb_( l11l111lll1ll1l1ll_fwb_ + _11l1l11ll1ll1l1ll_fwb_(method))
    out = {}
    if response[:2]==l1l111ll1l1ll_fwb_ (u"ࠫࡴࡱࠧቫ"): out =_111ll1lll1ll1l1ll_fwb_(response,_11ll1llll1ll1l1ll_fwb_)
    return out
def l11l1l11111ll1l1ll_fwb_(filmID=l1l111ll1l1ll_fwb_ (u"ࠬ࠷ࠧቬ")):
    method = l1l111ll1l1ll_fwb_ (u"࠭ࡧࡦࡶࡉ࡭ࡱࡳࡄࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠤࡠ࠭ቭ") + filmID + l1l111ll1l1ll_fwb_ (u"ࠧ࡞ࠩቮ")
    _11ll1llll1ll1l1ll_fwb_ = {0 :  l1l111ll1l1ll_fwb_ (u"ࠨࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠭ቯ")}
    response = _11l111ll1ll1l1ll_fwb_( l11l111lll1ll1l1ll_fwb_ + _11l1l11ll1ll1l1ll_fwb_(method))
    out = {}
    if response[:2]==l1l111ll1l1ll_fwb_ (u"ࠩࡲ࡯ࠬተ"): out =_111ll1lll1ll1l1ll_fwb_(response,_11ll1llll1ll1l1ll_fwb_)
    return out
def _11l11llll1ll1l1ll_fwb_(result):
    l11l1ll1l11ll1l1ll_fwb_ = result.split(l11lll1l111ll1l1ll_fwb_);
    element=l11l1ll1l11ll1l1ll_fwb_[0]
    l1l1111ll11ll1l1ll_fwb_=[]
    for element in l11l1ll1l11ll1l1ll_fwb_:
        l1l11111ll1l1ll_fwb_=_111lll1l11ll1l1ll_fwb_(element)
        if l1l11111ll1l1ll_fwb_: l1l1111ll11ll1l1ll_fwb_.append(l1l11111ll1l1ll_fwb_)
    return l1l1111ll11ll1l1ll_fwb_
def _111lll1l11ll1l1ll_fwb_(element):
    l1l1111lll1ll1l1ll_fwb_ = element.split(l11lllll1l1ll1l1ll_fwb_);
    type = l1l1111lll1ll1l1ll_fwb_[0]
    if type == l1l111ll1l1ll_fwb_ (u"ࠪࡪࠬቱ") or type == l1l111ll1l1ll_fwb_ (u"ࠫࡸ࠭ቲ"):
        result = _11ll11l111ll1l1ll_fwb_(l1l1111lll1ll1l1ll_fwb_);
    elif type == l1l111ll1l1ll_fwb_ (u"ࠬࡶࠧታ"):
        result=None
    else :
        result=None
    return result
def _11ll11l111ll1l1ll_fwb_(l1l1111lll1ll1l1ll_fwb_):
    item={}
    if len(l1l1111lll1ll1l1ll_fwb_):
        item[l1l111ll1l1ll_fwb_ (u"࠭ࡴࡺࡲࡨࠫቴ")] = l1l1111lll1ll1l1ll_fwb_[0]
        item[l1l111ll1l1ll_fwb_ (u"ࠧࡪࡦࠪት")] = l1l1111lll1ll1l1ll_fwb_[1]
        item[l1l111ll1l1ll_fwb_ (u"ࠨ࡫ࡰ࡫ࠬቶ")] = l1l11111111ll1l1ll_fwb_ + l1l1111lll1ll1l1ll_fwb_[2]
        item[l1l111ll1l1ll_fwb_ (u"ࠩࡷ࡭ࡹࡲࡥࡠࡨࠪቷ")] = l1l1111lll1ll1l1ll_fwb_[3]
        item[l1l111ll1l1ll_fwb_ (u"ࠪࡸ࡮ࡺ࡬ࡦࡡࡳࠫቸ")] = l1l1111lll1ll1l1ll_fwb_[4]
        item[l1l111ll1l1ll_fwb_ (u"ࠫࡹ࡯ࡴ࡭ࡧࡢࡩࠬቹ")] = l1l1111lll1ll1l1ll_fwb_[5]
        item[l1l111ll1l1ll_fwb_ (u"ࠬࡿࡥࡢࡴࠪቺ")] = l1l1111lll1ll1l1ll_fwb_[6]
        item[l1l111ll1l1ll_fwb_ (u"࠭ࡣࡢࡵࡷࠫቻ")] = l1l1111lll1ll1l1ll_fwb_[7]
    return item
def l1l11111l11ll1l1ll_fwb_(param=l1l111ll1l1ll_fwb_ (u"ࡵࠨ࠵࠴࠴ࠥࡪ࡯ࠡࡻࡸࡱࡾࠦ࠲࠱࠲࠺ࠫቼ")):
    result = _11l111ll1ll1l1ll_fwb_( l11ll111l11ll1l1ll_fwb_ + urllib.quote_plus(param.encode(l1l111ll1l1ll_fwb_ (u"ࠨࡷࡷࡪ࠲࠾ࠧች")).lower()) )
    out = _11l11llll1ll1l1ll_fwb_(result) if result else []
    return out
def searchFilmweb(title=l1l111ll1l1ll_fwb_ (u"ࠩ࡬ࡲࡩ࡯ࡡ࡯ࡣࠣ࡮ࡴࡴࠧቾ"),year=l1l111ll1l1ll_fwb_ (u"ࠪࠫቿ"),itemType=l1l111ll1l1ll_fwb_ (u"ࠫ࡫࠭ኀ")):
    l1lll1l1l1ll1l1ll_fwb_={}
    l111ll1ll11ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡩ࡭ࡱࡳࡷࡦࡤ࠱ࡴࡱ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡦࡪ࡮ࡰࡃࡶࡃࠧኁ")+urllib.quote_plus(title)
    result = _11l111ll1ll1l1ll_fwb_(l111ll1ll11ll1l1ll_fwb_)
    data = re.compile(l1l111ll1l1ll_fwb_ (u"࠭࠼࡭࡫ࠣ࡭ࡩࡃࠢࡧ࡫࡯ࡱࡤ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩኂ"),re.DOTALL).findall(result)
    if len(data)==1:
        l1lll1l1l1ll1l1ll_fwb_ = getFilmInfoFull(data[0][0])
    if not l1lll1l1l1ll1l1ll_fwb_:
        for id,l111ll1ll1ll1l1ll_fwb_ in data:
            l11l1111111ll1l1ll_fwb_ = re.search(l1l111ll1l1ll_fwb_ (u"ࠧ࡝ࠪࠫࡠࡩࢁ࠴ࡾࠫ࡟࠭ࠬኃ"),l111ll1ll1ll1l1ll_fwb_)
            l11l1111111ll1l1ll_fwb_ = l11l1111111ll1l1ll_fwb_.group(1) if l11l1111111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠨࠩኄ")
            if l11l1111111ll1l1ll_fwb_ == year:
                l1lll1l1l1ll1l1ll_fwb_ = getFilmInfoFull(id)
                break
    return l1lll1l1l1ll1l1ll_fwb_
if __name__==l1l111ll1l1ll_fwb_ (u"ࠤࡢࡣࡲࡧࡩ࡯ࡡࡢࠦኅ"):
    pass
