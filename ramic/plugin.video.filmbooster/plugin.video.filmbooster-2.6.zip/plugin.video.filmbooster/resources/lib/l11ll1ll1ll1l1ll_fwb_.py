# -*- coding: utf-8 -*-
import sys
l1ll11ll1l1ll_fwb_ = sys.version_info [0] == 2
l1111ll1l1ll_fwb_ = 2048
l1l1l1ll1l1ll_fwb_ = 7
def l1l111ll1l1ll_fwb_ (keyedStringLiteral):
	global l11ll1ll1l1ll_fwb_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll1l1ll_fwb_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import sys
from Queue import Queue
from threading import Thread
class l1lll1l1ll11ll1l1ll_fwb_(Thread):
    l1l111ll1l1ll_fwb_ (u"ࠥࠦࠧࠦࡔࡩࡴࡨࡥࡩࠦࡥࡹࡧࡦࡹࡹ࡯࡮ࡨࠢࡷࡥࡸࡱࡳࠡࡨࡵࡳࡲࠦࡡࠡࡩ࡬ࡺࡪࡴࠠࡵࡣࡶ࡯ࡸࠦࡱࡶࡧࡸࡩࠥࠨࠢࠣᛊ")
    def __init__(self, l1lll1l1lll1ll1l1ll_fwb_):
        Thread.__init__(self)
        self.l1lll1l1lll1ll1l1ll_fwb_ = l1lll1l1lll1ll1l1ll_fwb_
        self.daemon = True
        self.start()
    def run(self):
        while True:
            func, args, kargs = self.l1lll1l1lll1ll1l1ll_fwb_.get()
            try:
                func(*args, **kargs)
            except Exception as e:
                print(e)
            finally:
                self.l1lll1l1lll1ll1l1ll_fwb_.task_done()
class ThreadPool:
    l1l111ll1l1ll_fwb_ (u"ࠦࠧࠨࠠࡑࡱࡲࡰࠥࡵࡦࠡࡶ࡫ࡶࡪࡧࡤࡴࠢࡦࡳࡳࡹࡵ࡮࡫ࡱ࡫ࠥࡺࡡࡴ࡭ࡶࠤ࡫ࡸ࡯࡮ࠢࡤࠤࡶࡻࡥࡶࡧࠣࠦࠧࠨᛋ")
    def __init__(self, l1lll1ll1111ll1l1ll_fwb_):
        self.l1lll1l1lll1ll1l1ll_fwb_ = Queue(l1lll1ll1111ll1l1ll_fwb_)
        for _ in range(l1lll1ll1111ll1l1ll_fwb_):
            l1lll1l1ll11ll1l1ll_fwb_(self.l1lll1l1lll1ll1l1ll_fwb_)
    def add_task(self, func, *args, **kargs):
        l1l111ll1l1ll_fwb_ (u"ࠧࠨࠢࠡࡃࡧࡨࠥࡧࠠࡵࡣࡶ࡯ࠥࡺ࡯ࠡࡶ࡫ࡩࠥࡷࡵࡦࡷࡨࠤࠧࠨࠢᛌ")
        self.l1lll1l1lll1ll1l1ll_fwb_.put((func, args, kargs))
    def map(self, func, l1lll1l1l1l1ll1l1ll_fwb_):
        l1l111ll1l1ll_fwb_ (u"ࠨࠢࠣࠢࡄࡨࡩࠦࡡࠡ࡮࡬ࡷࡹࠦ࡯ࡧࠢࡷࡥࡸࡱࡳࠡࡶࡲࠤࡹ࡮ࡥࠡࡳࡸࡩࡺ࡫ࠠࠣࠤࠥᛍ")
        for args in l1lll1l1l1l1ll1l1ll_fwb_:
            self.add_task(func, args)
    def wait_completion(self):
        l1l111ll1l1ll_fwb_ (u"ࠢࠣࠤ࡛ࠣࡦ࡯ࡴࠡࡨࡲࡶࠥࡩ࡯࡮ࡲ࡯ࡩࡹ࡯࡯࡯ࠢࡲࡪࠥࡧ࡬࡭ࠢࡷ࡬ࡪࠦࡴࡢࡵ࡮ࡷࠥ࡯࡮ࠡࡶ࡫ࡩࠥࡷࡵࡦࡷࡨࠤࠧࠨࠢᛎ")
        self.l1lll1l1lll1ll1l1ll_fwb_.join()
