# -*- coding: utf-8 -*-
import sys
l1ll11ll1l1ll_fwb_ = sys.version_info [0] == 2
l1111ll1l1ll_fwb_ = 2048
l1l1l1ll1l1ll_fwb_ = 7
def l1l111ll1l1ll_fwb_ (keyedStringLiteral):
	global l11ll1ll1l1ll_fwb_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll1l1ll_fwb_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os,json,base64
import l1111lll11ll1l1ll_fwb_,cookielib
from urlparse import urlparse
l11l1l1ll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡰ࡯࡮ࡰࡵࡷࡥࡨࡰࡡ࠯ࡲ࡯࠳ࠬᖅ")
l11lll1111ll1l1ll_fwb_ = 10
l1llll1ll11ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠵࠺࠱࠴࠳࠸࠵࠷࠶࠱࠽࠼ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ᖆ")
l111111l11ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࡴࠪࡧࡴࡵ࡫ࡪࡧ࠱ࡧࡩࡧࠧᖇ")
l1llllll111ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠪࠫᖈ")
def _11l111ll1ll1l1ll_fwb_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l1l111ll1l1ll_fwb_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨᖉ"), l1llll1ll11ll1l1ll_fwb_)
    if cookies:
        req.add_header(l1l111ll1l1ll_fwb_ (u"ࠧࡉ࡯ࡰ࡭࡬ࡩࠧᖊ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11lll1111ll1l1ll_fwb_)
        l111111l1ll1l1ll_fwb_ = response.read()
        response.close()
    except:
        l111111l1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"࠭ࠧᖋ")
    return l111111l1ll1l1ll_fwb_
def l11ll11l11ll1l1ll_fwb_(url,data=None):
    cookies=l1111lll11ll1l1ll_fwb_.l1lllllll11ll1l1ll_fwb_(l111111l11ll1l1ll_fwb_)
    content=_11l111ll1ll1l1ll_fwb_(url,data,cookies)
    if not content:
        l11l11l1l1ll1l1ll_fwb_=l11111lll1ll1l1ll_fwb_(l11l1l1ll1ll1l1ll_fwb_,l111111l11ll1l1ll_fwb_)
        cookies=l1111lll11ll1l1ll_fwb_.l1lllllll11ll1l1ll_fwb_(l111111l11ll1l1ll_fwb_)
        content=_11l111ll1ll1l1ll_fwb_(url,data,cookies)
    return content
def l11111lll1ll1l1ll_fwb_(l111111l1ll1l1ll_fwb_,l1111ll1l1ll1l1ll_fwb_):
    l11l11l1l1ll1l1ll_fwb_ = cookielib.LWPCookieJar()
    l111l11ll1ll1l1ll_fwb_ = l1111lll11ll1l1ll_fwb_.l111lll111ll1l1ll_fwb_(l111111l1ll1l1ll_fwb_,l11l11l1l1ll1l1ll_fwb_,l1llll1ll11ll1l1ll_fwb_)
    l1l111l111ll1l1ll_fwb_=os.path.dirname(l1111ll1l1ll1l1ll_fwb_)
    if not os.path.exists(l1l111l111ll1l1ll_fwb_):
        os.makedirs(l1l111l111ll1l1ll_fwb_)
    if l11l11l1l1ll1l1ll_fwb_:
        l11l11l1l1ll1l1ll_fwb_.save(l1111ll1l1ll1l1ll_fwb_, ignore_discard = True)
    return l11l11l1l1ll1l1ll_fwb_
def l1111ll11ll1l1ll_fwb_(url,l111lll1ll1l1ll_fwb_=1,group=l1l111ll1l1ll_fwb_ (u"ࠧࠨᖌ")):
    if l1l111ll1l1ll_fwb_ (u"ࠨࡁࡳࡥ࡬࡫࠽ࠨᖍ") in url:
        url = url.replace(l1l111ll1l1ll_fwb_ (u"ࠩࡂࡴࡦ࡭ࡥ࠾ࠩᖎ"),l1l111ll1l1ll_fwb_ (u"ࠪࡃࡵࡧࡧࡦ࠿ࠨࡨࠬᖏ") %l111lll1ll1l1ll_fwb_)
    else:
        url += l1l111ll1l1ll_fwb_ (u"ࠫ࠴࠭ᖐ") if url[-1] != l1l111ll1l1ll_fwb_ (u"ࠬ࠵ࠧᖑ") else l1l111ll1l1ll_fwb_ (u"࠭ࠧᖒ")
        url = url + l1l111ll1l1ll_fwb_ (u"ࠧࡀࡲࡤ࡫ࡪࡃࠥࡥࠩᖓ") %l111lll1ll1l1ll_fwb_
    content = l11ll11l11ll1l1ll_fwb_(url)
    out=[]
    l1llllllll1ll1l1ll_fwb_=False
    l11l111111ll1l1ll_fwb_=False
    ids = []
    if group:
        idx = [(m.start(0), m.end(0)) for m in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠨ࠾࡫࠷ࡃ࠭ᖔ"), content,re.IGNORECASE) ]
        idx.append( (content.find(l1l111ll1l1ll_fwb_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡱࡩ࡯ࡱࡶࡸࡦࡩࡪࡢ࠰ࡳࡰ࠴ࡸࡥ࡫ࡧࡶࡸࡷࡧࡣ࡫ࡣࠥࠫᖕ")),content.find(l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴࡫ࡪࡰࡲࡷࡹࡧࡣ࡫ࡣ࠱ࡴࡱ࠵ࡲࡦ࡬ࡨࡷࡹࡸࡡࡤ࡬ࡤࠦࠬᖖ"))) )
        for i in range(len(idx[:-1])):
            print i
            l11ll1l1l1ll1l1ll_fwb_=content[ idx[i][0]:idx[i+1][0] ]
            if group in l11ll1l1l1ll1l1ll_fwb_:
                print group
                content = l11ll1l1l1ll1l1ll_fwb_
                ids = [(a.start(), a.end()) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳ࡸࡴ࠯࡟ࡨ࠰࠭ᖗ"), content)]
                ids.append( (-1,-1) )
                break
        for i in range(len(ids[:-1])):
            print content[ ids[i][1]:ids[i][1]+100 ]
            l11l11ll11ll1l1ll_fwb_ = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile(l1l111ll1l1ll_fwb_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᖘ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
            title = re.compile(l1l111ll1l1ll_fwb_ (u"࠭ࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᖙ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
            l111l1lll1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠧ࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᖚ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
            l1111l1l1l1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠨ࠾࠲ࡦࡃࡢࡳࠫࠪ࡟ࡨࡡ࠴࡜ࡥࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪᖛ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
            year =  re.compile(l1l111ll1l1ll_fwb_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡺࡧࡤࡶࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᖜ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
            if href and title:
                l111l1lll1ll1l1ll_fwb_ = l111l1lll1ll1l1ll_fwb_.group(1) if l111l1lll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠪࠫᖝ")
                if l111l1lll1ll1l1ll_fwb_.startswith(l1l111ll1l1ll_fwb_ (u"ࠫ࠴࠵ࠧᖞ")):
                    l111l1lll1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫᖟ")+l111l1lll1ll1l1ll_fwb_
                l1l11111ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"࠭ࡨࡳࡧࡩࠫᖠ")   : href.group(1),
                    l1l111ll1l1ll_fwb_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᖡ")  : l111l1l1l1ll1l1ll_fwb_(title.group(1)),
                    l1l111ll1l1ll_fwb_ (u"ࠨ࡫ࡰ࡫ࠬᖢ")    : l111l1lll1ll1l1ll_fwb_,
                    l1l111ll1l1ll_fwb_ (u"ࠩࡵࡥࡹ࡯࡮ࡨࠩᖣ") : l1111l1l1l1ll1l1ll_fwb_.group(1) if l1111l1l1l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠪࠫᖤ"),
                    l1l111ll1l1ll_fwb_ (u"ࠫࡾ࡫ࡡࡳࠩᖥ")   : year.group(1) if year else l1l111ll1l1ll_fwb_ (u"ࠬ࠭ᖦ"),
                        }
                out.append(l1l11111ll1l1ll_fwb_)
    else:
        l1lllll1l1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"࠭࠼ࡶ࡮ࠣࡧࡱࡧࡳࡴ࠿࡞ࠦࡡ࠭࡝ࡤ࡮ࡨࡥࡷ࡬ࡩࡹࠢࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳࡡࠢ࡝ࠩࡠࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᖧ"),re.DOTALL).findall(content)
        l1lllll1l1ll1l1ll_fwb_ = urllib.unquote(l1lllll1l1ll1l1ll_fwb_[0]) if l1lllll1l1ll1l1ll_fwb_ else content
        l1llllllll1ll1l1ll_fwb_=False
        if l1lllll1l1ll1l1ll_fwb_.find( l1l111ll1l1ll_fwb_ (u"ࠧࡀࡲࡤ࡫ࡪࡃࠥࡥࠩᖨ") %(l111lll1ll1l1ll_fwb_+1))>-1:
            l1llllllll1ll1l1ll_fwb_ = l111lll1ll1l1ll_fwb_+1
        ids = [(a.start(), a.end()) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡣࡰ࡮࠰ࡼࡸ࠳࡜ࡥࠩᖩ"), content)]
        ids.append( (-1,-1) )
        for i in range(len(ids[:-1])):
            l11l11ll11ll1l1ll_fwb_ = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile(l1l111ll1l1ll_fwb_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫᖪ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
            title = re.compile(l1l111ll1l1ll_fwb_ (u"ࠪࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᖫ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
            l111l1lll1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠫࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᖬ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
            l1111l1l1l1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠬࡂ࠯ࡣࡀ࡟ࡷ࠯࠮࡜ࡥ࡞࠱ࡠࡩ࠯࠼࠰ࡵࡳࡥࡳࡄࠧᖭ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
            year =  re.compile(l1l111ll1l1ll_fwb_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡾ࡫ࡡࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪᖮ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
            if href and title:
                l111l1lll1ll1l1ll_fwb_ = l111l1lll1ll1l1ll_fwb_.group(1) if l111l1lll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠧࠨᖯ")
                if l111l1lll1ll1l1ll_fwb_.startswith(l1l111ll1l1ll_fwb_ (u"ࠨ࠱࠲ࠫᖰ")):
                    l111l1lll1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨᖱ")+l111l1lll1ll1l1ll_fwb_
                l1l11111ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡷ࡫ࡦࠨᖲ")   : href.group(1),
                    l1l111ll1l1ll_fwb_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪᖳ")  : l111l1l1l1ll1l1ll_fwb_(title.group(1)),
                    l1l111ll1l1ll_fwb_ (u"ࠬ࡯࡭ࡨࠩᖴ")    : l111l1lll1ll1l1ll_fwb_,
                    l1l111ll1l1ll_fwb_ (u"࠭ࡲࡢࡶ࡬ࡲ࡬࠭ᖵ") : l1111l1l1l1ll1l1ll_fwb_.group(1) if l1111l1l1l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠧࠨᖶ"),
                    l1l111ll1l1ll_fwb_ (u"ࠨࡻࡨࡥࡷ࠭ᖷ")   : year.group(1) if year else l1l111ll1l1ll_fwb_ (u"ࠩࠪᖸ"),
                        }
                out.append(l1l11111ll1l1ll_fwb_)
        l11l111111ll1l1ll_fwb_ = l111lll1ll1l1ll_fwb_-1 if l111lll1ll1l1ll_fwb_>1 else False
    return (out, (l11l111111ll1l1ll_fwb_,l1llllllll1ll1l1ll_fwb_))
def l1lllll11l11ll1l1ll_fwb_(url):
    content = l11ll11l11ll1l1ll_fwb_(url)
    token = re.search(l1l111ll1l1ll_fwb_ (u"ࠪࡲࡦࡳࡥ࠾ࠤࡢࡸࡴࡱࡥ࡯ࠤࠣࡸࡾࡶࡥ࠾ࠤ࡫࡭ࡩࡪࡥ࡯ࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠫᖹ"),content).group(1)
    l1lllll11ll1ll1l1ll_fwb_ = re.search(l1l111ll1l1ll_fwb_ (u"ࠫࡸ࡯ࡴࡦ࡭ࡨࡽ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧᖺ"),content).group(1)
    params = {l1l111ll1l1ll_fwb_ (u"ࠬࡥࡴࡰ࡭ࡨࡲࠬᖻ"):l1l111ll1l1ll_fwb_ (u"࠭ࡍࡨ࡜ࡐࡆ࠶࡝ࡦ࠵ࡗࡅࡋࡵ࡮࡙ࡇ࠳࡬࠺࠸ࡳࡏ࠵࠸࠺ࡻࡽࡍ࠸ࡔ࠷࡮࠹ࡨࡱࡰ࠵ࡏࡒ࡮ࠬᖼ"),
            l1l111ll1l1ll_fwb_ (u"ࠧࡨ࠯ࡵࡩࡨࡧࡰࡵࡥ࡫ࡥ࠲ࡸࡥࡴࡲࡲࡲࡸ࡫ࠧᖽ"):l1l111ll1l1ll_fwb_ (u"ࠨ࠲࠶ࡅࡍࡐ࡟ࡗࡷࡹࡻࡼࡱࡋࡇ࠳ࡌ࠽ࡑࡔࡨࡖࡔࡕࡷࡕࡐࡳࡒࡑ࠸ࡣࡘࡲࡈࡲࡉࡴ࡚࠾ࡨ࡯ࡳࡄࡤ࡙࡜ࡷ࡭࡯ࡳࡑࡈ࡫ࡷࡈ࠲ࡲࡗࡍࡕࡿ࡭ࡲࡗࡺࡐࡑࡱࡪ࠵ࡺ࡫࠺ࡳ࡝ࡧࡂ࡯ࡅࡲࡼ࡜ࡣ࡛ࡄ࡙ࡹ࡬ࡳࡍࡋ࡫࡙ࡧࡵࡒ࠶࠮ࡖ࠵ࡧࡏࡍࡵ࠶ࡨࡇࡏࡲࡋࡳࡹࡣ࡝ࡷ࠶ࡕࡑࡈࡓࡻࡴ࠽ࡺࡏࡳ࠴࡜ࡴࡦ࡜ࡣࡂࡘࡳࡩࡕ࡫ࡴࡒ࡮ࡅ࡚࠵ࡿࡁ࠹ࡩࡗࡇࡖࡩࡰ࡮ࡰࡩ࡝ࡩࡕࡓࡤࡓ࡮ࡼ࡚࠿࡯ࡠࡵ࠸ࡕ࠹ࡹࡪࡑ࠶ࡋࡳࡻ࠸ࡑࡣࡤ࡫ࡋ࡛࠿ࡓࡊ࠶ࡒ࠼ࡦ࠳ࡖࡓࡃ࡙࡜ࡷ࡛ࡺࡱࡨ࠹ࡼࡾࡻࡥࡷ࡛ࡶࡹ࡝࠹ࡈࡹࡊࡤࡣࡇࡹ࡙ࡒࡅ࠼࡙࠼ࡊࡘ࠱࡬ࡩ࡮ࡇࡐࡄ࡮࡫࡯ࡎࡦࡨ࠶ࡖࡆࡕࡨ࡛ࡉ࡬ࡦࡉ࠰࡮ࡋࡽ࠷ࡓࡍࡳ࠻࠺࡛ࡕࡩ࡮ࡽ࡜ࡆࡒࡏࡇࡱ࡫࠷ࡎ࡝ࡡ࡛࡙࠼࡮ࡑ࡫࠰ࡇ࠵ࡰ࡚ࡪࡳࡖࡕࡓ࠰࠵࠸ࡶ࠰ࡐࡃࡼࡲࡼࡻ࡯ࡂࡖ࡝࡛ࡋࡺࡨࡆࡎ࠻ࡇ࠵ࡔࡋࡎࡗࡥࡨ࡛࡭࠵ࡥ࠯ࡢ࠺࠷࠾࡫ࡠࡄࡺࡈ࠶ࡘ࠶ࡌࡦ࠷࡜࡯ࡻࡁ࠺ࡨ࡯ࡕࡈࡋࡍࡨࡗ࠸࡬ࡿࡒ࡭࠹ࡔࡢࡏ࠸ࡌࡋࡢࡈ࡮ࡔࡵ࡯ࡵࡖࡕ࠶ࡱࡷ࠳ࡴ࡙ࡼ࠺ࡺࡸࡺࡌ࠺ࡄࡌࡔ࡝ࡰࡑࡸ࠸࠻࡝࠶ࡻ࡭࡬ࡡ࠺ࡶࡖࡼࡋࡋࡩࡌࡕࡆ࠸ࡎࡧࡤ࠸ࡻࡦ࡚ࡁࡅࡈ࠴࡫ࡦࡉࡵࡴ࡛ࡐ࠸ࡩ࠷࠴ࡏࡊ࠼ࡊ࠺࠸࡫ࡆ࠶࡯ࡶࡩࡨࡡ࡚࠴ࡘࡗ࠾ࡻࡩࡏࡅࡴࡉ࡫࡟ࡨࡂࡥࡽ࡜ࡾࡌࡧࡹࡺࡴࡆࡏ࠻࠸ࡃ࠸ࡓࡔࡿ࠶࡫࠴ࡏ࠺࠱࡝ࡷ࡚ࡔࡶࡓࡾࡦࡓࡐ࠵ࡏࡇࡖࡋࡸ࠴ࡺࡷࡍ࠵ࡆࡴ࠷ࡥࡱࡱ࠸࡮ࡳ࠶࠺ࡥࡒ࠼ࡵࡉ࠰ࡺࡸࡪࡥࡾ࡝ࡸࡴࡣ࡯ࡑ࠽ࡐࡌࡄࡆ࡬ࡘ࠼࡜࡭ࡔ࡭ࡤ࠻࠽ࡍ࡙ࡥ࠲ࡅࡨࡼ࡙࡟ࡥࡅ࠴ࡘࡽ࡚ࡩ࡬ࡪ࡙࠼ࡨࡎ࠹ࡢࡦࡍ࡜࡞࠻ࡁࡵࡅࡍࡇࡎ࠸ࡥ࡫ࡶࡄࡧࡨࡿ࡙࠶࡫ࡼࡧ࡮࡫࠭ࡻࡸࡑ࡞ࡪࡰࡶࡢࡅ࠻ࡋ࡞ࡏࡦࡸࡍࡑࡩ࡞ࡇ࠳ࡗ࡫࠹࠴࡬࡟ࡎࡨࡋࡨࡺ࠷ࡧ࠵ࡖࡏࡌࡕ࡟࡬࡙࠵ࡼ࡚ࡪࡤࡶࡪࡴ࠺ࡗ࠻ࡼࡊࡌࡲࡴ࠳࠼ࡰࡘࡈࡵࡔ࠺࡬ࡾࡨ࡭࡮ࡍࡶࡺ࡞ࡽࡇࡇ࡭࡬ࡈࡒࡼࡥࡦࡳࡔࡼ࠲ࡼࡺࡗࡆ࠷ࡧ࠾ࡺࡥ࠸࠻࡝ࡴࡔࡻࡒࡔ࡯ࡄࡒ࠽࡯ࡩ࠳ࡃࡵࡨ࡞ࡎࡗࡣࡡࡐ࠺࠾ࡧ࠰ࡉࡨࡩࡥ࡬ࢀࡐࡵࡗ࠻ࡑࡈࡩ࠶ࡍࡹࡸ࠼࡙࠼࠵ࡸ࠳ࡻࡵ࠼ࡏࡌ࡯ࡓࡕࡳࡨࡩࡰࡱࡏࡺࡇ࠾ࡈ࠸ࡕ࠺࡯ࡾࡩࡏࡱࡔ࠴ࡼࡐࡈࡹࡧࡌࡺࡽࡧࡑࡌࡏࡦࡳࡳࡸࡤࡗࡁࡊࡦࡑ࡫࡮ࡨࡹࡇ࠵ࡴ࠻ࡉࡠࡥࡤ࡮࠷࠵ࡷ࠸ࡨࡹࡐ࡮ࡌࡵ࠼࡭ࡕ࠳࡮࡮ࡰࡉ࠸ࡨࡹࡽࡇࡧ࡭ࡶࡋࡃࡲࡵ࠼ࢀࡵ࡛ࡗ࡛ࡺࡴࡗࡃࡶࡇࡈ࡙ࡓࡇࡵࡤࡋࡷࡌࡒ࠿ࡕࡤࡏࡇࡕ࠹࡯ࡍ࡚ࡒࡺࡆ࡜ࡨࡳࡖࡨࡨࡾࡆࡈࡩࡐ࡙ࡱࡩ࠵ࡌ࠷ࡒࡓࡦࡉࡤࡑࡖ࡚࠶ࡼࡉ࠹ࡘࡆࡔࡇࡱࡸ࡜ࡲ࠹࡯ࡻࡼ࡜࠾ࡕ࠲ࡐ࡛࠹࡬ࡊ࡯࠲ࡦ࠳ࡊ࠹ࡇࡇࡥ࡙ࡆࡢ࠵ࡾ࡯ࡌ࠺ࡵ࠰ࡷ࠻࠾ࡰ࡭࡫࡮ࡊࡋࡥ࡬ࡃࡴࡔ࡝࠵ࡼࡣࡢࡒࡱࡑ࠻࠿ࡑࡔࡨࡱࡶ࡚ࡇ࡮ࡇ࠷࡫࠻ࡇࡍࡷ࡭ࡖ࡮ࡵࡇ࡭࡬ࡸ࠸࠵ࡹࡔࡽ࠵ࡑࡰ࠵࡯ࡹࡿࡧࡓࡒ࠰ࡆ࡙࡚ࡰࡨࡗࡻ࡚ࡦ࠶ࡦࡵࡪࡻࡉ࡯ࡘ࡟࠴࠳࡙ࡇ࡚ࡼࡂ࡮ࡆ࠶ࡲࡼࡼࡩࡐࡑࡄࡖࡇࡱࡎࡹࡹࡽࡒࡑࡼࡺࡃ࠯ࡏࡌࡖ࠺ࡉࡸࡶ࠻ࡖ࡜࡜ࡪ࠲ࡊࡇ࠶࠷ࡗ࡙ࡂ࡙࡭ࡊ࡙ࡎࡕ࡛ࡐࡐ࡝ࡴ࡭࠳ࡳࡈࡕ࠵࠶࡞ࡩ࠳ࡡ࠺ࡊ࡚ࡩࡕࡤࡑࡊࡊࡒࢀࡺ࡬ࡅࡰࡍࡴ࡬ࡰ࡙࠺࠴࠷ࡱࡱ࠵ࡥࡧࡇࡱࡍ࡯ࡖࡻࡱࡑ࡜࡬࠸ࡵࡓ࡫ࡤࡈࡏࡷࡤࡅࡩ࡯ࡸ࡙࠽࠸ࡂࡪࡐࡗࡋࡓ࡚ࡩࡱࡐ࡭ࡲࡐࡕࡷࡊ࡯ࡹࡺࡈ࠰࠺ࡋࡉࡇࡰࡋ࠰ࡎࡡ࠹ࡨࡿࡖࡹࡪ࠴࠶࡫࡮ࡪ࡚ࡓ࡬࡜ࡳࡩ࠾ࡰࡲࡘ࠵࠴ࡌ࠺࡙࠲ࡤࡆ࠺࡟ࢀࡴࡵ࡮ࡇࡦࡨࡘࡣࡤࡆࡩࡏࡦࡪࡣࡋࡷ࠼ࡉࡵࡍࡍࡤࡘࡏࡕࡳࡴࡂࡻࡵࡨࡘࡘ࠶ࡃࡈ࡯࠻ࡒ࠶ࡔ࡬ࡶࡆࡦ࡮ࡒ࡮ࡷ࡯ࡼࡰ࠼ࡹ࡫ࡔࡋࡋࡨ࡫ࡪࡹࡩࡱࡵࡋ࠻ࡖࡠ࠸ࡖࡻࡩ࡫ࡨࡿࡆࡑࡦ࠳࠱࠽ࡩࡏ࡬࡭ࡰࡏ࡬ࡲࡥࡆࡗࡇ࡚࡝ࡉࡴࡂ࡭࡝ࡗࡧ࡟ࡔ࠱࠵ࡖ࠱ࡹ࡛ࡱࡌࡺ࡬࡯ࡖ࠽ࡑࡹࡌࡒࡉ࡛ࡸࡈࡎ࠲࡜࠹ࡼ࡜ࡪࡍࡐࡗࡷ࠵࡚ࡗࡇࡗࡈࡈࡊࡵ࠵ࡪ࡚ࡹ࠱࠻ࡷࡷ࠺࠺ࡽࡹ࠻ࡿࡩࡘ࡫ࡔ࠶ࡵࡌࡢ࠸ࡕࡥࡼࡻ࡬࡭࡙ࡪࡎ࠷ࡶࡌࡗࡷ࡭ࡘࡇࡱࡾࡪࡨࡄ࡫࠻ࡰ࡜ࡵ࠶ࡶ࡮࡯ࡉࡔ࠰࠲࠳ࡖࡆ࠺ࡘࡥࡰࡅࡍࡹࡑࡪࡦࡉࡎࡷࡓ࡭࠸ࡆࡲ࡜࠵ࡻ࠼ࡖࡨࡈࡍࡅ࡮ࡪࡼࡤࡂࡎ࠵ࡪࡈࡘࡅࡩ࡚࠴ࡎࡹ࡟ࡎ࠹ࡻࡄ࡙࡮ࡖࡎ࡫ࡺ࡮ࡅࡇࡺࡁࡣ࡯ࡼࡐ࠼ࡹ࠭ࡌࡲ࠵࡛ࡧࡼࡶࡓࡳࡏ࠸࠸࠻࠷ࡵࡖ࠹ࡱࡓ࡞ࡃࡲࡩ࠰ࡪࡳࡓ࠱ࡪࡓ࠼ࡳ࡞ࡇࡴࡑ࡫ࡰࡎࡴࡪࡶࡅ࠺࡝ࡇࡐ࡟࠵ࡃ࠻ࡰࡧ࠸ࡧࡏࡶࡆࡌࡕࡿࡼ࠶ࡍࡖࡢࡳࡵ࡫ࡶࡗࡣ࠼࠻ࡴࡌ࠰࡭ࡧࡧ࡭࡚࠾ࡧࡐ࠸࠶ࡉࡺࡷ࡭࠷ࡩࡌ࠹ࡐ࠶ࡪ࠶ࡘࡓࡩ࡛ࡼࡰࡤ࠲ࡽࡽࡦ࡟ࡖ࡙ࡈ࠼ࡸࡽ࠻ࡑࡻࡈࡎࡸࡔࡋࡁࡄࡡࡎࡥ࡙࡮࠭ࡔࡷ࠺࡙ࡏࡴࡗ࠵ࡓࡥࡌ࡚࡯࠹ࡑ࡮ࡶ࡫࡬ࡗࡐ࠱ࡌࡄ࠹࠻ࡥࡧࡩࡖࡒ࠼ࡇࡰࡐ࡚࠴ࡸ࠼ࡐ࠿࠹ࡉࡆ࡫ࡣࡩࡶ࠴ࡆࡤ࠴ࡉ࠵࡚࠹ࡂ࠳ࡻࡸࡿࡸࡢ࡙࠵࡝࡫ࡋ࠶࠵ࡸࡅࡈࡎࡪ࠻ࡌ࡮࠴ࡴ࡜࠵࡛ࡤ࡛࡚ࡼࡣࡆ࡜ࡵࡲ࠹ࡖ࠷ࡊࡓ࠳ࡎ࡬࡫ࡎࡎࡠ࠭ࡌࡤ࡭ࡩ࠼ࡖ࡯ࡧࡳ࡯ࡼࡌࡳ࠰࠺ࡋ࡫ࡎࡽࡘࡣࡥࡇ࠷࡮࡝ࡠࡧࡳ࡮ࡧ࠻ࡦࡖࡨࡷ࠲ࡅࡘ࠶ࡗ࠹࠲ࡆ࡛ࡶࡗ࠾࡬ࡍࡶ࡜࠺ࡓࡘࡂࡴ࡜ࡩ࡯࡭࠿ࡎࠨᖾ")
           }
    data=urllib.urlencode(params)
    a=l11ll11l11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡲࡹࡴ࠴ࡩࡰ࠱ࡪࡳ࠴ࡌ࡫ࡣࡥࡸࠫᖿ"),data)
    print a
def _1llll1l11l1ll1l1ll_fwb_(url,host=l1l111ll1l1ll_fwb_ (u"ࠪࠫᗀ")):
    l1lllll11111ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠫࠬᗁ")
    if url.startswith(l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡴࡵࡲࠪᗂ")):
        if l1l111ll1l1ll_fwb_ (u"࠭࡬ࡪࡰ࡮࡭࠳ࡵ࡮࡭࡫ࡱࡩࠬᗃ") in url:
            content = l11ll11l11ll1l1ll_fwb_(url)
            l1lll11111ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠧࡵࡱࡳ࠲ࡱࡵࡣࡢࡶ࡬ࡳࡳࠦ࠽ࠡ࡝࡟ࠫࠧࡣࠨ࠯ࠬࡂ࠭ࡠࡢࠧࠣ࡟࠾ࠫᗄ")).search(content)
            if l1lll11111ll1l1ll_fwb_:
                l1lllll11111ll1l1ll_fwb_ = l1lll11111ll1l1ll_fwb_.group(1)
        if l1l111ll1l1ll_fwb_ (u"ࠨࡱࡸࡳ࠳࡯࡯ࠨᗅ") in url:
            l1lllll11111ll1l1ll_fwb_ = url
        else:
            req = urllib2.Request(url)
            req.add_header(l1l111ll1l1ll_fwb_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ᗆ"), l1l111ll1l1ll_fwb_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡏࡘ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠷࠼࠳࠶࠮࠳࠷࠹࠸࠳࠿࠷ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨᗇ"))
            try:
                response = urllib2.urlopen(req)
                if response:
                    l1lllll11111ll1l1ll_fwb_=response.url
                    if l1lllll11111ll1l1ll_fwb_==url:
                        content=response.read()
                        l1lll11111ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࠬࠦࠥࡩ࡬ࡢࡵࡶࠫᗈ")).findall(content)
                        for l in l1lll11111ll1l1ll_fwb_:
                            if host in l:
                                l1lllll11111ll1l1ll_fwb_ = l
                                break
                    response.close()
            except:
                pass
    return l1lllll11111ll1l1ll_fwb_
def l1llll1ll111ll1l1ll_fwb_(url,content=None):
    if not content:
        content = l11ll11l11ll1l1ll_fwb_(url)
    out  =[]
    l1lllll1111ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪࠦࠨ࠯ࠬࡂ࠭ࡁ࠵ࡩࡧࡴࡤࡱࡪࡄࠧᗉ"),re.DOTALL).findall(content)
    names = re.compile(l1l111ll1l1ll_fwb_ (u"࠭࠼ࡶ࡮ࠣࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡩ࡚ࡡࡣࡵࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨᗊ"),re.DOTALL).findall(content)
    if names:
        names = [x.strip() for x in re.compile(l1l111ll1l1ll_fwb_ (u"ࠧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᗋ"),re.DOTALL).findall(names[0]) if x.strip()]
    else:
        names=[]
    for l1lllll111l1ll1l1ll_fwb_ in l1lllll1111ll1l1ll_fwb_:
        href = re.compile(l1l111ll1l1ll_fwb_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᗌ"),re.DOTALL).search(l1lllll111l1ll1l1ll_fwb_)
        if href:
            l1llll1ll1l1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠩ࡫ࡸࡹࡶࠧᗍ")+ urllib.unquote(href.group(1)).split(l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡹࡺࡰࠨᗎ"))[-1]
            if l1llll1ll1l1ll1l1ll_fwb_.startswith(l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡺࡴࡱࠩᗏ")) and not l1l111ll1l1ll_fwb_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠭ᗐ") in l1llll1ll1l1ll1l1ll_fwb_ and not l1l111ll1l1ll_fwb_ (u"࠭ࡦࡢࡥࡨࡦࡴࡵ࡫ࠨᗑ") in l1llll1ll1l1ll1l1ll_fwb_:
                host = urlparse(l1llll1ll1l1ll1l1ll_fwb_).netloc
                l1l11111ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"ࠧࡶࡴ࡯ࠫᗒ") : l1llll1ll1l1ll1l1ll_fwb_,
                    l1l111ll1l1ll_fwb_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᗓ"): l1l111ll1l1ll_fwb_ (u"ࠤ࡞ࠩࡸࡣࠢᗔ") %(host),
                    l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡴࡹࡴࠨᗕ"): host    }
                out.append(l1l11111ll1l1ll_fwb_)
    if len(names)==len(out):
        for l1l11111ll1l1ll_fwb_,name in zip(out,names):
            l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪᗖ")] += l1l111ll1l1ll_fwb_ (u"ࠬࠦࠥࡴࠩᗗ")%name
    return out
url=l1l111ll1l1ll_fwb_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱࡯࡮ࡴ࡯ࡴࡶࡤࡧ࡯ࡧ࠮ࡱ࡮࠲ࡪ࡮ࡲ࡭࠮ࡱࡱࡰ࡮ࡴࡥ࠰࠳࠺࠽࠵࠺࠯ࡥࡼ࡬ࡩࡳ࠳ࡰࡢࡶࡵ࡭ࡴࡺ࡯ࡸ࠯ࡳࡥࡹࡸࡩࡰࡶࡶ࠱ࡩࡧࡹࠨᗘ")
def l1llllll1l1ll1l1ll_fwb_(url):
    content = l11ll11l11ll1l1ll_fwb_(url)
    l111llll111ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠧ࠽ࡶࡥࡳࡩࡿ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡤࡲࡨࡾࡄࠧᗙ"),re.DOTALL).findall(content)
    l111llll111ll1l1ll_fwb_ = l111llll111ll1l1ll_fwb_[0] if l111llll111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠨࠩᗚ")
    ids = [(a.start(), a.end()) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠩ࠿ࡸࡷࡄࠧᗛ"), l111llll111ll1l1ll_fwb_)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11l11ll11ll1l1ll_fwb_ = l111llll111ll1l1ll_fwb_[ ids[i][1]:ids[i+1][0] ]
        href=re.compile(l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᗜ")).search(l11l11ll11ll1l1ll_fwb_)
        l1lllll1l111ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠫࡩࡧࡴࡢ࠯࡬ࡪࡷࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᗝ")).search(l11l11ll11ll1l1ll_fwb_)
        info = l1l111ll1l1ll_fwb_ (u"ࠬ࠭ᗞ").join(re.compile(l1l111ll1l1ll_fwb_ (u"࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᗟ"),re.DOTALL).findall(l11l11ll11ll1l1ll_fwb_))
        info = re.sub(l1l111ll1l1ll_fwb_ (u"ࠧࠡ࠭ࠪᗠ"),l1l111ll1l1ll_fwb_ (u"ࠨࠢࠪᗡ"),l111l1l1l1ll1l1ll_fwb_(info)).strip()
        if href:
            l1l11111ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"ࠩࡸࡶࡱ࠭ᗢ") : href.group(1),l1l111ll1l1ll_fwb_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩᗣ"): info,}
            out.append(l1l11111ll1l1ll_fwb_)
    return out
def l1l11l111ll1l1ll_fwb_(url):
    content = l11ll11l11ll1l1ll_fwb_(url)
    l111l1lll1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠫࡁࡪࡩࡷࠢ࡬ࡨࡂࠨࡩࡵࡧࡰ࠱࡭࡫ࡡࡥ࡮࡬ࡲࡪࠨ࠮ࠫࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧᗤ")).findall(content)
    l111l1lll1ll1l1ll_fwb_ = l111l1lll1ll1l1ll_fwb_[-1] if l111l1lll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠬ࠭ᗥ")
    out=[]
    l11l1llll1ll1l1ll_fwb_= content.find(l1l111ll1l1ll_fwb_ (u"࠭ࡏࡥࡥ࡬ࡲࡰ࡯ࠧᗦ"))
    l11ll11111ll1l1ll_fwb_= content.find(l1l111ll1l1ll_fwb_ (u"ࠧࡅࡱࡧࡥ࡯ࠦ࡯ࡥࡥ࡬ࡲࡪࡱࠧᗧ"))
    l1l11l1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ᗨ"),re.DOTALL).findall(content[l11l1llll1ll1l1ll_fwb_:l11ll11111ll1l1ll_fwb_])
    for h,t in l1l11l1ll1l1ll_fwb_:
        t= l111l1l1l1ll1l1ll_fwb_(t.strip())
        t=re.sub(l1l111ll1l1ll_fwb_ (u"ࠩࠣ࠯ࠬᗩ"),l1l111ll1l1ll_fwb_ (u"ࠪࠤࠬᗪ"),t)
        l1llll1l111ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠫࡠࡹࡓ࡞ࠪ࡟ࡨ࠰࠯࡛ࡆࡧࡠࠬࡡࡪࠫࠪࠩᗫ")).findall(t)
        l1l11111ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡲࡦࡨࠪᗬ")  : h.strip(),
            l1l111ll1l1ll_fwb_ (u"࠭ࡰ࡭ࡱࡷࠫᗭ"): t,
            l1l111ll1l1ll_fwb_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᗮ") : t,
            l1l111ll1l1ll_fwb_ (u"ࠨ࡫ࡰ࡫ࠬᗯ"):l111l1lll1ll1l1ll_fwb_,
            l1l111ll1l1ll_fwb_ (u"ࠩࡶࡩࡦࡹ࡯࡯ࠩᗰ"): int(l1llll1l111ll1l1ll_fwb_[0][0]) if l1llll1l111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠪࠫᗱ"),
            l1l111ll1l1ll_fwb_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࠬᗲ"): int(l1llll1l111ll1l1ll_fwb_[0][1]) if l1llll1l111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠬ࠭ᗳ"),
            l1l111ll1l1ll_fwb_ (u"࠭ࡡࡪࡴࡨࡨࠬᗴ") : l1l111ll1l1ll_fwb_ (u"ࠧࠨᗵ")}
        out.append(l1l11111ll1l1ll_fwb_)
    return out
def l1llll1l1l11ll1l1ll_fwb_(out):
    l1llll1l1ll1ll1l1ll_fwb_={}
    l1l1l1lll1ll1l1ll_fwb_ = [x.get(l1l111ll1l1ll_fwb_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࠨᗶ")) for x in out]
    for s in set(l1l1l1lll1ll1l1ll_fwb_):
        l1llll1l1ll1ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡖࡩࡿࡵ࡮ࠡࠧ࠳࠶ࡩ࠭ᗷ")%s]=[out[i] for i, j in enumerate(l1l1l1lll1ll1l1ll_fwb_) if j == s]
    return l1llll1l1ll1ll1l1ll_fwb_
def l11l1l11ll1l1ll_fwb_(url=l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮࡬࡫ࡱࡳࡸࡺࡡࡤ࡬ࡤ࠲ࡵࡲ࠯ࡴࡧࡵ࡭ࡦࡲࡥ࠮ࡱࡱࡰ࡮ࡴࡥ࠰ࠩᗸ")):
    content = l11ll11l11ll1l1ll_fwb_(url)
    l1llll1llll1ll1l1ll_fwb_=re.compile(l1l111ll1l1ll_fwb_ (u"ࠫࡁࡻ࡬ࠡ࡫ࡧࡁࠧࡹࡥࡳ࡫ࡨࡷ࠲ࡲࡩࡴࡶࠥࠤࡨࡲࡡࡴࡵࡀࠦ࡫࡯࡬ࡵࡧࡵࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬ࠨᗹ"),re.DOTALL).findall(content)
    l1111l1ll1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠮ࡃ࠮ࠨ࡛࡝ࡴ࡟ࡲࠥࡢࡴ࡞ࠬࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠰ࡅࠩࠣࠩᗺ")).findall(l1llll1llll1ll1l1ll_fwb_[0])
    out=[]
    for href,title in l1111l1ll1ll1l1ll_fwb_:
        l1l11111ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"࠭ࡨࡳࡧࡩࠫᗻ")  : href,
            l1l111ll1l1ll_fwb_ (u"ࠧࡱ࡮ࡲࡸࠬᗼ"): l1l111ll1l1ll_fwb_ (u"ࠨࠩᗽ"),
            l1l111ll1l1ll_fwb_ (u"ࠩࡷ࡭ࡹࡲࡥࠨᗾ") : l111l1l1l1ll1l1ll_fwb_(title),
            l1l111ll1l1ll_fwb_ (u"ࠪ࡭ࡲ࡭ࠧᗿ"):l1l111ll1l1ll_fwb_ (u"ࠫࠬᘀ")}
        out.append(l1l11111ll1l1ll_fwb_)
    return (out, (False,False))
def l111lll1l1ll1l1ll_fwb_(m):
    return l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡲࡦࡨࡀࠦࠬᘁ")+urllib.unquote(m.group(1))
def l111l1ll11ll1l1ll_fwb_(l111ll1111ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"࠭ࡦࡪ࡮ࡰࠫᘂ"),l111111111ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩᘃ")):
    label=[]
    value=[]
    if l111ll1111ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠨࡨ࡬ࡰࡲ࠭ᘄ"):
        content = l11ll11l11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴࡫ࡪࡰࡲࡷࡹࡧࡣ࡫ࡣ࠱ࡴࡱ࠵ࡦࡪ࡮ࡰࡽ࠲ࡵ࡮࡭࡫ࡱࡩ࠴࠭ᘅ"))
        if l111111111ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬᘆ"):
            l1llll1llll1ll1l1ll_fwb_=re.compile(l1l111ll1l1ll_fwb_ (u"ࠫࡁࡻ࡬ࠡ࡫ࡧࡁࠧ࡬ࡩ࡭ࡶࡨࡶ࠲ࡩࡡࡵࡧࡪࡳࡷࡿࠢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡨ࡬ࡰࡹ࡫ࡲࠡ࡯ࡸࡰࡹ࡯ࡰ࡭ࡧ࠰ࡷࡪࡲࡥࡤࡶࠣࡸࡪࡸ࡭࠮࡮࡬ࡷࡹࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࠪᘇ"),re.DOTALL).findall(content)[0]
            value=re.compile(l1l111ll1l1ll_fwb_ (u"ࠬࡪࡡࡵࡣ࠰࡭ࡩࡃࠢࠩ࡞ࡧ࠯࠮ࠨࠧᘈ")).findall(l1llll1llll1ll1l1ll_fwb_)
            label=re.compile(l1l111ll1l1ll_fwb_ (u"࠭࠾ࠩ࠰࠮ࡃ࠮ࡂࠧᘉ")).findall(l1llll1llll1ll1l1ll_fwb_)
            label[0]=l1l111ll1l1ll_fwb_ (u"ࠧࠨᘊ")
        elif l111111111ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠨࡻࡨࡥࡷ࠭ᘋ"):
            l1llll1llll1ll1l1ll_fwb_=re.compile(l1l111ll1l1ll_fwb_ (u"ࠩ࠿ࡹࡱࠦࡩࡥ࠿ࠥࡪ࡮ࡲࡴࡦࡴ࠰ࡽࡪࡧࡲࠣࠢࡦࡰࡦࡹࡳ࠾ࠤࡩ࡭ࡱࡺࡥࡳࠢࡰࡹࡱࡺࡩࡱ࡮ࡨ࠱ࡸ࡫࡬ࡦࡥࡷࠤࡹ࡫ࡲ࡮࠯࡯࡭ࡸࡺࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࠫᘌ"),re.DOTALL).findall(content)[0]
            value=re.compile(l1l111ll1l1ll_fwb_ (u"ࠪࡨࡦࡺࡡ࠮࡫ࡧࡁࠧ࠮࡜ࡥ࠭ࠬࠦࠬᘍ")).findall(l1llll1llll1ll1l1ll_fwb_)
            label=re.compile(l1l111ll1l1ll_fwb_ (u"ࠫࡃ࠮࠮ࠬࡁࠬࡀࠬᘎ")).findall(l1llll1llll1ll1l1ll_fwb_)
        elif l111111111ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭ᘏ"):
            l1llll1llll1ll1l1ll_fwb_=re.compile(l1l111ll1l1ll_fwb_ (u"࠭࠼ࡶ࡮ࠣ࡭ࡩࡃࠢࡧ࡫࡯ࡸࡪࡸ࠭ࡤࡱࡸࡲࡹࡸࡹࠣࠢࡦࡰࡦࡹࡳ࠾ࠤࡩ࡭ࡱࡺࡥࡳࠢࡰࡹࡱࡺࡩࡱ࡮ࡨ࠱ࡸ࡫࡬ࡦࡥࡷࠤࡹ࡫ࡲ࡮࠯࡯࡭ࡸࡺࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࠫᘐ"),re.DOTALL).findall(content)[0]
            value=re.compile(l1l111ll1l1ll_fwb_ (u"ࠧࡥࡣࡷࡥ࠲࡯ࡤ࠾ࠤࠫࡠࡩ࠱ࠩࠣࠩᘑ")).findall(l1llll1llll1ll1l1ll_fwb_)
            label=re.compile(l1l111ll1l1ll_fwb_ (u"ࠨࡀࠫ࠲࠰ࡅࠩ࠽ࠩᘒ")).findall(l1llll1llll1ll1l1ll_fwb_)
    elif l111ll1111ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠩࡶࡩࡷ࡯ࡡ࡭ࠩᘓ"):
        pass
    return (label,value)
def l111l1l1l1ll1l1ll_fwb_(l111ll1ll1ll1l1ll_fwb_):
    if isinstance(l111ll1ll1ll1l1ll_fwb_, unicode):
        l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.encode(l1l111ll1l1ll_fwb_ (u"ࠪࡹࡹ࡬࠭࠹ࠩᘔ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠫࠫࡲࡴ࠼ࡤࡵ࠳ࠫ࡭ࡴ࠼ࠩᘕ"),l1l111ll1l1ll_fwb_ (u"ࠬࠦࠧᘖ"))
    s=l1l111ll1l1ll_fwb_ (u"࠭ࡊࡪࡐࡦ࡞ࡈࡹ࠷ࠨᘗ")
    l111ll1ll1ll1l1ll_fwb_ = re.sub(s.decode(l1l111ll1l1ll_fwb_ (u"ࠧࡣࡣࡶࡩ࠻࠺ࠧᘘ")),l1l111ll1l1ll_fwb_ (u"ࠨࠩᘙ"),l111ll1ll1ll1l1ll_fwb_)
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠩ࡟ࡲࠬᘚ"),l1l111ll1l1ll_fwb_ (u"ࠪࠫᘛ")).replace(l1l111ll1l1ll_fwb_ (u"ࠫࡡࡸࠧᘜ"),l1l111ll1l1ll_fwb_ (u"ࠬ࠭ᘝ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"࠭ࠦ࡯ࡤࡶࡴࡀ࠭ᘞ"),l1l111ll1l1ll_fwb_ (u"ࠧࠨᘟ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠨࠨࡴࡹࡴࡺ࠻ࠨᘠ"),l1l111ll1l1ll_fwb_ (u"ࠩࠥࠫᘡ")).replace(l1l111ll1l1ll_fwb_ (u"ࠪࠪࡦࡳࡰ࠼ࡳࡸࡳࡹࡁࠧᘢ"),l1l111ll1l1ll_fwb_ (u"ࠫࠧ࠭ᘣ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠬࠬ࡯ࡢࡥࡸࡸࡪࡁࠧᘤ"),l1l111ll1l1ll_fwb_ (u"࠭ࣳࠨᘥ")).replace(l1l111ll1l1ll_fwb_ (u"ࠧࠧࡑࡤࡧࡺࡺࡥ࠼ࠩᘦ"),l1l111ll1l1ll_fwb_ (u"ࠨࣕࠪᘧ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠩࠩࡥࡲࡶ࠻ࡰࡣࡦࡹࡹ࡫࠻ࠨᘨ"),l1l111ll1l1ll_fwb_ (u"ࠪࣷࠬᘩ")).replace(l1l111ll1l1ll_fwb_ (u"ࠫࠫࡧ࡭ࡱ࠽ࡒࡥࡨࡻࡴࡦ࠽ࠪᘪ"),l1l111ll1l1ll_fwb_ (u"ࠬࣙࠧᘫ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"࠭ࠦࡢ࡯ࡳ࠿ࠬᘬ"),l1l111ll1l1ll_fwb_ (u"ࠧࠧࠩᘭ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠨ࡞ࡸ࠴࠶࠶࠵ࠨᘮ"),l1l111ll1l1ll_fwb_ (u"ࠩईࠫᘯ")).replace(l1l111ll1l1ll_fwb_ (u"ࠪࡠࡺ࠶࠱࠱࠶ࠪᘰ"),l1l111ll1l1ll_fwb_ (u"ࠫउ࠭ᘱ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠬࡢࡵ࠱࠳࠳࠻ࠬᘲ"),l1l111ll1l1ll_fwb_ (u"࠭इࠨᘳ")).replace(l1l111ll1l1ll_fwb_ (u"ࠧ࡝ࡷ࠳࠵࠵࠼ࠧᘴ"),l1l111ll1l1ll_fwb_ (u"ࠨईࠪᘵ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠩ࡟ࡹ࠵࠷࠱࠺ࠩᘶ"),l1l111ll1l1ll_fwb_ (u"ࠪझࠬᘷ")).replace(l1l111ll1l1ll_fwb_ (u"ࠫࡡࡻ࠰࠲࠳࠻ࠫᘸ"),l1l111ll1l1ll_fwb_ (u"ࠬञࠧᘹ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"࠭࡜ࡶ࠲࠴࠸࠷࠭ᘺ"),l1l111ll1l1ll_fwb_ (u"ࠧृࠩᘻ")).replace(l1l111ll1l1ll_fwb_ (u"ࠨ࡞ࡸ࠴࠶࠺࠱ࠨᘼ"),l1l111ll1l1ll_fwb_ (u"ࠩॄࠫᘽ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠪࡠࡺ࠶࠱࠵࠶ࠪᘾ"),l1l111ll1l1ll_fwb_ (u"ࠫॉ࠭ᘿ")).replace(l1l111ll1l1ll_fwb_ (u"ࠬࡢࡵ࠱࠳࠷࠸ࠬᙀ"),l1l111ll1l1ll_fwb_ (u"࠭ृࠨᙁ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠧ࡝ࡷ࠳࠴࡫࠹ࠧᙂ"),l1l111ll1l1ll_fwb_ (u"ࠨࣵࠪᙃ")).replace(l1l111ll1l1ll_fwb_ (u"ࠩ࡟ࡹ࠵࠶ࡤ࠴ࠩᙄ"),l1l111ll1l1ll_fwb_ (u"ࠪࣗࠬᙅ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠫࡡࡻ࠰࠲࠷ࡥࠫᙆ"),l1l111ll1l1ll_fwb_ (u"ࠬॡࠧᙇ")).replace(l1l111ll1l1ll_fwb_ (u"࠭࡜ࡶ࠲࠴࠹ࡦ࠭ᙈ"),l1l111ll1l1ll_fwb_ (u"ࠧज़ࠩᙉ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠨ࡞ࡸ࠴࠶࠽ࡡࠨᙊ"),l1l111ll1l1ll_fwb_ (u"ࠩॽࠫᙋ")).replace(l1l111ll1l1ll_fwb_ (u"ࠪࡠࡺ࠶࠱࠸࠻ࠪᙌ"),l1l111ll1l1ll_fwb_ (u"ࠫॾ࠭ᙍ"))
    l111ll1ll1ll1l1ll_fwb_ = l111ll1ll1ll1l1ll_fwb_.replace(l1l111ll1l1ll_fwb_ (u"ࠬࡢࡵ࠱࠳࠺ࡧࠬᙎ"),l1l111ll1l1ll_fwb_ (u"࠭ॼࠨᙏ")).replace(l1l111ll1l1ll_fwb_ (u"ࠧ࡝ࡷ࠳࠵࠼ࡨࠧᙐ"),l1l111ll1l1ll_fwb_ (u"ࠨॽࠪᙑ"))
    return l111ll1ll1ll1l1ll_fwb_
def search(l111ll1ll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠩ࡬ࡲࡩ࡯ࡡ࡯ࡣ࠮࡮ࡴ࠭ᙒ")):
    url=l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮࡬࡫ࡱࡳࡸࡺࡡࡤ࡬ࡤ࠲ࡵࡲ࠯ࡸࡻࡶࡾࡺࡱࡩࡸࡣࡵ࡯ࡦࡅࡰࡩࡴࡤࡷࡪࡃࠧᙓ")+l111ll1ll1ll1l1ll_fwb_
    content=l11ll11l11ll1l1ll_fwb_(url)
    l111l111l1ll1l1ll_fwb_=[]
    l111ll11l1ll1l1ll_fwb_=[]
    ids = [(a.start(), a.end()) for a in re.finditer(l1l111ll1l1ll_fwb_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳ࡳ࡮࠯࡟ࡨ࠰࠭ᙔ"), content)]
    ids.append( (-1,-1) )
    for i in range(len(ids[:-1])):
        l11l11ll11ll1l1ll_fwb_ = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile(l1l111ll1l1ll_fwb_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᙕ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
        title = re.compile(l1l111ll1l1ll_fwb_ (u"࠭ࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᙖ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
        l1111l11l1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠥࡺࡥࡹࡶ࠰࡮ࡺࡹࡴࡪࡨࡼࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᙗ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
        l111l1lll1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᙘ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
        l1111l1l1l1ll1l1ll_fwb_ = re.compile(l1l111ll1l1ll_fwb_ (u"ࠩ࠿࠳ࡧࡄ࡜ࡴࠬࠫࡠࡩࡢ࠮࡝ࡦࠬࡀ࠴ࡹࡰࡢࡰࡁࠫᙙ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
        year =  re.compile(l1l111ll1l1ll_fwb_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡻࡨࡥࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᙚ"),re.DOTALL).search(l11l11ll11ll1l1ll_fwb_)
        if href and title:
            l111l1lll1ll1l1ll_fwb_ = l111l1lll1ll1l1ll_fwb_.group(1).replace(l1l111ll1l1ll_fwb_ (u"ࠫ࠴ࡺࡨࡶ࡯ࡥ࠳ࠬᙛ"),l1l111ll1l1ll_fwb_ (u"ࠬ࠵ࡢࡪࡩ࠲ࠫᙜ")) if l111l1lll1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"࠭ࠧᙝ")
            l1l11111ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"ࠧࡩࡴࡨࡪࠬᙞ")   : href.group(1),
                l1l111ll1l1ll_fwb_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᙟ")  : l111l1l1l1ll1l1ll_fwb_(title.group(1)),
                l1l111ll1l1ll_fwb_ (u"ࠩࡳࡰࡴࡺࠧᙠ")   : l111l1l1l1ll1l1ll_fwb_(l1111l11l1ll1l1ll_fwb_.group(1)) if l1111l11l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠪࠫᙡ"),
                l1l111ll1l1ll_fwb_ (u"ࠫ࡮ࡳࡧࠨᙢ")    : l111l1lll1ll1l1ll_fwb_,
                l1l111ll1l1ll_fwb_ (u"ࠬࡸࡡࡵ࡫ࡱ࡫ࠬᙣ") : l1111l1l1l1ll1l1ll_fwb_.group(1) if l1111l1l1l1ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"࠭ࠧᙤ"),
                l1l111ll1l1ll_fwb_ (u"ࠧࡺࡧࡤࡶࠬᙥ")   : year.group(1) if year else l1l111ll1l1ll_fwb_ (u"ࠨࠩᙦ"),
                    }
            if l1l111ll1l1ll_fwb_ (u"ࠩ࠲ࡪ࡮ࡲ࡭࠮ࡱࡱࡰ࡮ࡴࡥ࠰ࠩᙧ") in l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡷ࡫ࡦࠨᙨ")]:
                l111l111l1ll1l1ll_fwb_.append(l1l11111ll1l1ll_fwb_)
            elif l1l111ll1l1ll_fwb_ (u"ࠫࡸ࡫ࡲࡪࡣ࡯࠱ࡴࡴ࡬ࡪࡰࡨࠫᙩ")in l1l11111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡲࡦࡨࠪᙪ")]:
                l111ll11l1ll1l1ll_fwb_.append(l1l11111ll1l1ll_fwb_)
    return l111l111l1ll1l1ll_fwb_,l111ll11l1ll1l1ll_fwb_
