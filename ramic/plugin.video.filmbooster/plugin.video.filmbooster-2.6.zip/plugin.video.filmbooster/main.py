# -*- coding: utf-8 -*-
import sys
l1ll11ll1l1ll_fwb_ = sys.version_info [0] == 2
l1111ll1l1ll_fwb_ = 2048
l1l1l1ll1l1ll_fwb_ = 7
def l1l111ll1l1ll_fwb_ (keyedStringLiteral):
	global l11ll1ll1l1ll_fwb_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll1l1ll_fwb_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1111ll1l1ll_fwb_ - (charIndex + stringNr) % l1l1l1ll1l1ll_fwb_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import urlresolver
import check
try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
cache = StorageServer.StorageServer(l1l111ll1l1ll_fwb_ (u"ࠥࡲࡰࡺࡶࠣࠩ"))
import ramic as l1lllll11ll1l1ll_fwb_
l1lllll1ll1l1ll_fwb_        = sys.argv[0]
l1l1lll11ll1l1ll_fwb_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l1ll1ll11ll1l1ll_fwb_        = xbmcaddon.Addon()
l1l11ll111ll1l1ll_fwb_     = l1ll1ll11ll1l1ll_fwb_.getAddonInfo(l1l111ll1l1ll_fwb_ (u"ࠫ࡮ࡪࠧࠪ"))
l11l11111ll1l1ll_fwb_       = l1ll1ll11ll1l1ll_fwb_.getAddonInfo(l1l111ll1l1ll_fwb_ (u"ࠬࡴࡡ࡮ࡧࠪࠫ"))
PATH        = l1ll1ll11ll1l1ll_fwb_.getAddonInfo(l1l111ll1l1ll_fwb_ (u"࠭ࡰࡢࡶ࡫ࠫࠬ"))
l111ll1l1ll1l1ll_fwb_    = xbmc.translatePath(l1ll1ll11ll1l1ll_fwb_.getAddonInfo(l1l111ll1l1ll_fwb_ (u"ࠧࡱࡴࡲࡪ࡮ࡲࡥࠨ࠭"))).decode(l1l111ll1l1ll_fwb_ (u"ࠨࡷࡷࡪ࠲࠾ࠧ࠮"))
l1l11lll11ll1l1ll_fwb_   = PATH+l1l111ll1l1ll_fwb_ (u"ࠩ࠲ࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ࠵ࠧ࠯")
l1l1l1l111ll1l1ll_fwb_=l1l11lll11ll1l1ll_fwb_+l1l111ll1l1ll_fwb_ (u"ࠪࡪࡦࡴࡡࡳࡶ࠱ࡴࡳ࡭ࠧ࠰")
l1l11ll1l1ll1l1ll_fwb_ = urllib2.urlopen
l1ll11l11ll1l1ll_fwb_ = urllib2.Request
l1l1ll1l1ll1l1ll_fwb_ = xbmcgui.Dialog()
import time,threading
try: from shutil import rmtree
except: rmtree = False
if not os.path.exists(os.path.join(PATH.decode(l1l111ll1l1ll_fwb_ (u"ࠫࡺࡺࡦ࠮࠺ࠪ࠱")),l1l111ll1l1ll_fwb_ (u"ࠬࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠨ࠲"),l1l111ll1l1ll_fwb_ (u"࠭࡬ࡪࡤࠪ࠳"),l1l111ll1l1ll_fwb_ (u"ࠧࡠࡡ࡬ࡲ࡮ࡺ࡟ࡠ࠰ࡳࡽࡴ࠭࠴"))):
    print l1l111ll1l1ll_fwb_ (u"ࠨࡋࡐࡔࡔࡘࡔࠨ࠵")
    import resources.lib.l1l1l1l11ll1l1ll_fwb_
    import resources.lib.l1l1l11111ll1l1ll_fwb_
    import resources.lib.l11111ll1ll1l1ll_fwb_
    import resources.lib.l11l1ll11ll1l1ll_fwb_
    import resources.lib.l11l1ll1ll1l1ll_fwb_
    import resources.lib.l11lll111ll1l1ll_fwb_
    import resources.lib.l11ll1ll1ll1l1ll_fwb_
    import resources.lib.l1lll11l11ll1l1ll_fwb_
    import resources.lib.l1ll1l11ll1l1ll_fwb_
import resources.lib
def l1l1ll1l1ll_fwb_(l11111ll1l1ll_fwb_,l1llll1ll1l1ll_fwb_=[l1l111ll1l1ll_fwb_ (u"ࠩࠪ࠶")]):
    out=0
    l111ll1l1ll_fwb_ =  os.listdir(l11111ll1l1ll_fwb_)
    for l111l1ll1l1ll_fwb_ in l111ll1l1ll_fwb_:
        out += sum([1 for x in l1llll1ll1l1ll_fwb_ if x in l111l1ll1l1ll_fwb_.lower()])
    return out
def l11ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠪࠫ࠷")):
    debug=1
def l1ll1ll1l1ll_fwb_(top):
    debug=1
def l1ll1lll1ll1l1ll_fwb_():
    l11111ll1l1ll_fwb_ = os.path.join(xbmc.translatePath(l1l111ll1l1ll_fwb_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭ࡀ")),l1l111ll1l1ll_fwb_ (u"࠭ࡡࡥࡦࡲࡲࡸ࠭ࡁ"))
    xbmc.log(l11111ll1l1ll_fwb_)
    if l1l1ll1l1ll_fwb_(l11111ll1l1ll_fwb_,[l1l111ll1l1ll_fwb_ (u"ࠧࡢ࡮࡬ࡩࡳࡽࡩࡻࡣࡵࡨࠬࡂ"),l1l111ll1l1ll_fwb_ (u"ࠨࡧࡻࡸࡪࡴࡤࡦࡴ࠱ࡥࡱ࡯ࡥ࡯ࠩࡃ")])>0:
        l11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠩࡺ࡭ࡿࡧࡲࡥࠩࡄ"))
        return
    l1l11ll1l1ll_fwb_ = os.path.join(xbmc.translatePath(l1l111ll1l1ll_fwb_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡵࡴࡧࡵࡨࡦࡺࡡࠨࡅ")),l1l111ll1l1ll_fwb_ (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨࡆ"),l1l111ll1l1ll_fwb_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡥࡪࡵ࡮࠯ࡰࡲࡼ࠳࠻ࠧࡇ"),l1l111ll1l1ll_fwb_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬࡈ"))
    if os.path.exists(l1l11ll1l1ll_fwb_):
        data = open(l1l11ll1l1ll_fwb_,l1l111ll1l1ll_fwb_ (u"ࠧࡳࠩࡉ")).read()
        data= re.sub(l1l111ll1l1ll_fwb_ (u"ࠨ࡞࡞࠲࠯ࡢ࡝ࠨࡊ"),l1l111ll1l1ll_fwb_ (u"ࠩࠪࡋ"),data)
        if len(re.compile(l1l111ll1l1ll_fwb_ (u"ࠪࡂ࠳࠰ࠨࡱࡱ࡯ࡷࡰࡧ࡜ࡴࠬࡷࡠࡸ࠰ࡶࠪࠩࡌ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠫࡸࡱࡩ࡯࠰ࡤࡩࡴࡴ࠮࡯ࡱࡻ࠲࠺࠭ࡍ"))
            return
        if len(re.compile(l1l111ll1l1ll_fwb_ (u"ࠬࡄ࠮ࠫࠪࡧࡥࡷࡳ࡯ࡸࡣ࡟ࡷ࠯ࡺ࡜ࡴࠬࡹ࠭ࠬࡎ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡦ࡫࡯࡯࠰ࡱࡳࡽ࠴࠵ࠨࡏ"))
            return
    l1l11ll1l1ll_fwb_ = os.path.join(xbmc.translatePath(l1l111ll1l1ll_fwb_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡹࡸ࡫ࡲࡥࡣࡷࡥࠬࡐ")),l1l111ll1l1ll_fwb_ (u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬࡑ"),l1l111ll1l1ll_fwb_ (u"ࠩࡶ࡯࡮ࡴ࠮ࡹࡱࡱࡪࡱࡻࡥ࡯ࡥࡨࠫࡒ"),l1l111ll1l1ll_fwb_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩࡓ"))
    if os.path.exists(l1l11ll1l1ll_fwb_):
        data = open(l1l11ll1l1ll_fwb_,l1l111ll1l1ll_fwb_ (u"ࠫࡷ࠭ࡔ")).read()
        data= re.sub(l1l111ll1l1ll_fwb_ (u"ࠬࡢ࡛࠯ࠬ࡟ࡡࠬࡕ"),l1l111ll1l1ll_fwb_ (u"࠭ࠧࡖ"),data)
        if len(re.compile(l1l111ll1l1ll_fwb_ (u"ࠧ࠿࠰࠭ࠬࡵࡵ࡬ࡴ࡭ࡤࡠࡸ࠰ࡴ࡝ࡵ࠭ࡺ࠮࠭ࡗ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠨࡵ࡮࡭ࡳ࠴ࡸࡰࡰࡩࡰࡺ࡫࡮ࡤࡧࠪࡘ"))
            return
    l11111ll1l1ll_fwb_ = os.path.join(xbmc.translatePath(l1l111ll1l1ll_fwb_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡻࡳࡦࡴࡧࡥࡹࡧ࡙ࠧ")),l1l111ll1l1ll_fwb_ (u"ࠪࡴࡷࡵࡦࡪ࡮ࡨࡷ࡚ࠬ"))
    if os.path.exists(l11111ll1l1ll_fwb_):
        if l1l1ll1l1ll_fwb_(l11111ll1l1ll_fwb_,[l1l111ll1l1ll_fwb_ (u"ࠫࡰ࡯ࡤࡴ࡛ࠩ")])>0:
            l11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠬࡽࡩࡻࡣࡵࡨࠬ࡜"))
            return
    l11l11ll1l1ll_fwb_ = xbmc.translatePath(l1l111ll1l1ll_fwb_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧ࡝"))
    for f in os.listdir(l11l11ll1l1ll_fwb_):
        if f.startswith(l1l111ll1l1ll_fwb_ (u"ࠧࡎࡏࡈࡗࠬ࡞")):
            l11ll1l1ll_fwb_()
            return
try:
    debug=1
except: pass
l11l11ll1ll1l1ll_fwb_ = lambda x,y: ord(x)+4*y if ord(x)%2 else ord(x)
l11111l1ll1l1ll_fwb_ = lambda l11l11l11ll1l1ll_fwb_: l1l111ll1l1ll_fwb_ (u"ࠩࠪࡠ").join([chr(l11l11ll1ll1l1ll_fwb_(x,1) ) for x in l11l11l11ll1l1ll_fwb_.encode(l1l111ll1l1ll_fwb_ (u"ࠪࡦࡦࡹࡥ࠷࠶ࠪࡡ")).strip()])
l1lll1l111ll1l1ll_fwb_ = lambda l11l11l11ll1l1ll_fwb_: l1l111ll1l1ll_fwb_ (u"ࠫࠬࡢ").join([chr(l11l11ll1ll1l1ll_fwb_(x,-1) ) for x in l11l11l11ll1l1ll_fwb_]).decode(l1l111ll1l1ll_fwb_ (u"ࠬࡨࡡࡴࡧ࠹࠸ࠬࡣ"))
if not os.path.exists(l1l111ll1l1ll_fwb_ (u"࠭࠯ࡩࡱࡰࡩ࠴ࡵࡳ࡮ࡥࠪࡤ")):
    tm=time.gmtime()
    try:    l11l1l1l1ll1l1ll_fwb_,l11llll1ll1l1ll_fwb_,l11lll1l1ll1l1ll_fwb_ = l1lll1l111ll1l1ll_fwb_(l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠧ࡬ࡱࡧࠫࡥ"))).split(l1l111ll1l1ll_fwb_ (u"ࠨ࠼ࠪࡦ"))
    except: l11l1l1l1ll1l1ll_fwb_,l11llll1ll1l1ll_fwb_,l11lll1l1ll1l1ll_fwb_ =  [l1l111ll1l1ll_fwb_ (u"ࠩ࠰࠵ࠬࡧ"),l1l111ll1l1ll_fwb_ (u"ࠪࠫࡨ"),l1l111ll1l1ll_fwb_ (u"ࠫ࠲࠷ࠧࡩ")]
    if int(l11l1l1l1ll1l1ll_fwb_) != tm.tm_hour:
        try:    l1111l111ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠬࡑࡏࡅ࠼ࠣࠬ࠳࠰࠿ࠪ࡞ࡱࠫࡪ"),l1l11ll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡳࡣࡺ࠲࡬࡯ࡴࡩࡷࡥࡹࡸ࡫ࡲࡤࡱࡱࡸࡪࡴࡴ࠯ࡥࡲࡱ࠴ࡸࡡ࡮࡫ࡦࡷࡵࡧ࠯࡬ࡱࡧ࡭࠴ࡳࡡࡴࡶࡨࡶ࠴ࡘࡅࡂࡆࡐࡉ࠳ࡳࡤࠨ࡫")).read())[0].strip(l1l111ll1l1ll_fwb_ (u"ࠧࠫࠩ࡬"))
        except: l1111l111ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠨࠩ࡭")
def l1l1lll1l1ll1l1ll_fwb_(name, url, mode, l111lll1ll1l1ll_fwb_=1, l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹࡌ࡯࡭ࡦࡨࡶ࠳ࡶ࡮ࡨࠩࡸ"), infoLabels={}, IsPlayable=True, fanart=l1l1l1l111ll1l1ll_fwb_,l1ll11111ll1l1ll_fwb_=1):
    u = l1l1ll1ll1l1ll_fwb_({l1l111ll1l1ll_fwb_ (u"࠭࡭ࡰࡦࡨࠫࡹ"): mode, l1l111ll1l1ll_fwb_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫࡺ"): name, l1l111ll1l1ll_fwb_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩࡻ") : url, l1l111ll1l1ll_fwb_ (u"ࠩࡳࡥ࡬࡫ࠧࡼ"):l111lll1ll1l1ll_fwb_,l1l111ll1l1ll_fwb_ (u"ࠪࡱ࡮ࡴࡦࡰࠩࡽ"):str(infoLabels)})
    isFolder = infoLabels.get(l1l111ll1l1ll_fwb_ (u"ࠫ࡮ࡹࡆࡰ࡮ࡧࡩࡷ࠭ࡾ"),False)
    if isFolder and infoLabels.get(l1l111ll1l1ll_fwb_ (u"ࠬࡿࡥࡢࡴࠪࡿ"),False):
        name += l1l111ll1l1ll_fwb_ (u"࠭ࠠࠩࠧࡶ࠭ࠬࢀ")%infoLabels.get(l1l111ll1l1ll_fwb_ (u"ࠧࡺࡧࡤࡶࠬࢁ"))
    l1ll111ll1ll1l1ll_fwb_ = xbmcgui.ListItem(name)
    l1l11l1l11ll1l1ll_fwb_=[l1l111ll1l1ll_fwb_ (u"ࠨࡶ࡫ࡹࡲࡨࠧࢂ"),l1l111ll1l1ll_fwb_ (u"ࠩࡳࡳࡸࡺࡥࡳࠩࢃ"),l1l111ll1l1ll_fwb_ (u"ࠪࡦࡦࡴ࡮ࡦࡴࠪࢄ"),l1l111ll1l1ll_fwb_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫࢅ"),l1l111ll1l1ll_fwb_ (u"ࠬࡩ࡬ࡦࡣࡵࡥࡷࡺࠧࢆ"),l1l111ll1l1ll_fwb_ (u"࠭ࡣ࡭ࡧࡤࡶࡱࡵࡧࡰࠩࢇ"),l1l111ll1l1ll_fwb_ (u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪ࢈"),l1l111ll1l1ll_fwb_ (u"ࠨ࡫ࡦࡳࡳ࠭ࢉ")]
    l1111ll1ll1l1ll_fwb_ = dict(zip(l1l11l1l11ll1l1ll_fwb_,[infoLabels.get(x,l1ll11lll1ll1l1ll_fwb_) for x in l1l11l1l11ll1l1ll_fwb_]))
    l1111ll1ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬࢊ")] = fanart if fanart else l1111ll1ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭ࢋ")]
    l1ll111ll1ll1l1ll_fwb_.setArt(l1111ll1ll1l1ll_fwb_)
    l1ll111ll1ll1l1ll_fwb_.setInfo(type=l1l111ll1l1ll_fwb_ (u"ࠦࡻ࡯ࡤࡦࡱࠥࢌ"), infoLabels=infoLabels)
    if IsPlayable and not isFolder:
        l1ll111ll1ll1l1ll_fwb_.setProperty(l1l111ll1l1ll_fwb_ (u"ࠬࡏࡳࡑ࡮ࡤࡽࡦࡨ࡬ࡦࠩࢍ"), l1l111ll1l1ll_fwb_ (u"࠭ࡴࡳࡷࡨࠫࢎ"))
    if url:
        l1l11llll1ll1l1ll_fwb_ = []
        l11ll1l1ll1l1ll_fwb_=l1l1ll1ll1l1ll_fwb_({l1l111ll1l1ll_fwb_ (u"ࠧ࡮ࡱࡧࡩࠬ࢏"): l1l111ll1l1ll_fwb_ (u"ࠨࡃࡧࡨ࡙ࡵࡌࡪࡤࡵࡥࡷࡿࠧ࢐"), l1l111ll1l1ll_fwb_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭࢑"): name, l1l111ll1l1ll_fwb_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫ࢒") : url, l1l111ll1l1ll_fwb_ (u"ࠫࡵࡧࡧࡦࠩ࢓"):l111lll1ll1l1ll_fwb_,l1l111ll1l1ll_fwb_ (u"ࠬࡳࡩ࡯ࡨࡲࠫ࢔"):str(infoLabels)})
        l1l11llll1ll1l1ll_fwb_.append((l1l111ll1l1ll_fwb_ (u"࠭ࡄࡰࡦࡤ࡮ࠥࡪ࡯ࠡࡄ࡬ࡦࡱ࡯࡯ࡵࡧ࡮࡭ࠬ࢕"), l1l111ll1l1ll_fwb_ (u"ࠧࡓࡷࡱࡔࡱࡻࡧࡪࡰࠫࠩࡸ࠯ࠧ࢖")%l11ll1l1ll1l1ll_fwb_))
        l1ll111ll1ll1l1ll_fwb_.addContextMenuItems(l1l11llll1ll1l1ll_fwb_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l1l1lll11ll1l1ll_fwb_, url=u, listitem=l1ll111ll1ll1l1ll_fwb_,isFolder=isFolder,totalItems=l1ll11111ll1l1ll_fwb_)
    xbmcplugin.addSortMethod(l1l1lll11ll1l1ll_fwb_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1l111ll1l1ll_fwb_ (u"ࠣࠧࡕ࠰࡙ࠥࠫ࠭ࠢࠨࡔࠧࢗ"))
    return ok
def l1ll11ll1ll1l1ll_fwb_(name,ex_link=None, l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ࢘"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭࢙ࠧ"), infoLabels={}, fanart=l1l1l1l111ll1l1ll_fwb_,contextmenu=None):
    url = l1l1ll1ll1l1ll_fwb_({l1l111ll1l1ll_fwb_ (u"ࠫࡲࡵࡤࡦ࢚ࠩ"): mode, l1l111ll1l1ll_fwb_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࡳࡧ࡭ࡦ࢛ࠩ"): name, l1l111ll1l1ll_fwb_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧ࢜") : ex_link, l1l111ll1l1ll_fwb_ (u"ࠧࡱࡣࡪࡩࠬ࢝") : l111lll1ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠨ࡯࡬ࡲ࡫ࡵࠧ࢞"):str(infoLabels)})
    l1lll1l1ll1l1ll_fwb_ = xbmcgui.ListItem(name)
    if infoLabels:
        l1lll1l1ll1l1ll_fwb_.setInfo(type=l1l111ll1l1ll_fwb_ (u"ࠤࡹ࡭ࡩ࡫࡯ࠣ࢟"), infoLabels=infoLabels)
    l1l11l1l11ll1l1ll_fwb_=[l1l111ll1l1ll_fwb_ (u"ࠪࡸ࡭ࡻ࡭ࡣࠩࢠ"),l1l111ll1l1ll_fwb_ (u"ࠫࡵࡵࡳࡵࡧࡵࠫࢡ"),l1l111ll1l1ll_fwb_ (u"ࠬࡨࡡ࡯ࡰࡨࡶࠬࢢ"),l1l111ll1l1ll_fwb_ (u"࠭ࡣ࡭ࡧࡤࡶࡦࡸࡴࠨࢣ"),l1l111ll1l1ll_fwb_ (u"ࠧࡤ࡮ࡨࡥࡷࡲ࡯ࡨࡱࠪࢤ"),l1l111ll1l1ll_fwb_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫࢥ"),l1l111ll1l1ll_fwb_ (u"ࠩ࡬ࡧࡴࡴࠧࢦ")]
    l1111ll1ll1l1ll_fwb_ = dict(zip(l1l11l1l11ll1l1ll_fwb_,[infoLabels.get(x,iconImage) for x in l1l11l1l11ll1l1ll_fwb_]))
    l1111ll1ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭ࢧ")] = fanart if fanart else l1111ll1ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫ࠧࢨ")]
    l1lll1l1ll1l1ll_fwb_.setArt(l1111ll1ll1l1ll_fwb_)
    if contextmenu:
        l1l11llll1ll1l1ll_fwb_=contextmenu
        l1lll1l1ll1l1ll_fwb_.addContextMenuItems(l1l11llll1ll1l1ll_fwb_, replaceItems=True)
    else:
        l1l11llll1ll1l1ll_fwb_ = []
        l1l11llll1ll1l1ll_fwb_.append((l1l111ll1l1ll_fwb_ (u"ࠬࡏ࡮ࡧࡱࡵࡱࡦࡩࡪࡢࠩࢩ"), l1l111ll1l1ll_fwb_ (u"࠭ࡘࡃࡏࡆ࠲ࡆࡩࡴࡪࡱࡱࠬࡎࡴࡦࡰࠫࠪࢪ")),)
        l1lll1l1ll1l1ll_fwb_.addContextMenuItems(l1l11llll1ll1l1ll_fwb_, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=l1l1lll11ll1l1ll_fwb_, url=url,listitem=l1lll1l1ll1l1ll_fwb_, isFolder=True)
    xbmcplugin.addSortMethod(l1l1lll11ll1l1ll_fwb_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1l111ll1l1ll_fwb_ (u"ࠢࠦࡔ࠯ࠤࠪ࡟ࠬࠡࠧࡓࠦࢫ"))
def l1ll1111l1ll1l1ll_fwb_(name, url=l1l111ll1l1ll_fwb_ (u"ࠨࠩࢬ"), mode=l1l111ll1l1ll_fwb_ (u"ࠩࠪࢭ"), l1ll11lll1ll1l1ll_fwb_=None, fanart=l1l1l1l111ll1l1ll_fwb_):
    u = l1l1ll1ll1l1ll_fwb_({l1l111ll1l1ll_fwb_ (u"ࠪࡱࡴࡪࡥࠨࢮ"): mode, l1l111ll1l1ll_fwb_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨࢯ"): name, l1l111ll1l1ll_fwb_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭ࢰ") : url, l1l111ll1l1ll_fwb_ (u"࠭ࡰࡢࡩࡨࠫࢱ"):1})
    l1ll111ll1ll1l1ll_fwb_ = xbmcgui.ListItem(name, iconImage=l1ll11lll1ll1l1ll_fwb_, thumbnailImage=l1ll11lll1ll1l1ll_fwb_)
    l1ll111ll1ll1l1ll_fwb_.setProperty(l1l111ll1l1ll_fwb_ (u"ࠧࡊࡵࡓࡰࡦࡿࡡࡣ࡮ࡨࠫࢲ"), l1l111ll1l1ll_fwb_ (u"ࠨࡨࡤࡰࡸ࡫ࠧࢳ"))
    if fanart:
        l1ll111ll1ll1l1ll_fwb_.setProperty(l1l111ll1l1ll_fwb_ (u"ࠩࡩࡥࡳࡧࡲࡵࡡ࡬ࡱࡦ࡭ࡥࠨࢴ"),fanart)
    ok = xbmcplugin.addDirectoryItem(handle=l1l1lll11ll1l1ll_fwb_, url=u, listitem=l1ll111ll1ll1l1ll_fwb_,isFolder=False)
    return ok
def l111l11ll1l1ll_fwb_(l111llll1ll1l1ll_fwb_):
    l11111111ll1l1ll_fwb_ = {}
    for k, v in l111llll1ll1l1ll_fwb_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l1l111ll1l1ll_fwb_ (u"ࠪࡹࡹ࡬࠸ࠨࢵ"))
        elif isinstance(v, str):
            v.decode(l1l111ll1l1ll_fwb_ (u"ࠫࡺࡺࡦ࠹ࠩࢶ"))
        l11111111ll1l1ll_fwb_[k] = v
    return l11111111ll1l1ll_fwb_
def l1l1ll1ll1l1ll_fwb_(query):
    return l1lllll1ll1l1ll_fwb_ + l1l111ll1l1ll_fwb_ (u"ࠬࡅࠧࢷ") + urllib.urlencode(l111l11ll1l1ll_fwb_(query))
def l1ll11l1ll1l1ll_fwb_(ex_link,l111lll1ll1l1ll_fwb_):
    l111lll1ll1l1ll_fwb_ = int(l111lll1ll1l1ll_fwb_) if l111lll1ll1l1ll_fwb_ else 1
    group=l1l111ll1l1ll_fwb_ (u"࠭ࠧࢸ")
    if l1l111ll1l1ll_fwb_ (u"ࠧࡽࠩࢹ")in ex_link:
        ex_link,group = ex_link.split(l1l111ll1l1ll_fwb_ (u"ࠨࡾࠪࢺ"))
    l111l11l1ll1l1ll_fwb_,l1lllll1l1ll1l1ll_fwb_ = l1ll11l1l1ll1l1ll_fwb_.l1111ll11ll1l1ll_fwb_(ex_link,l111lll1ll1l1ll_fwb_,group)
    if l1lllll1l1ll1l1ll_fwb_[0]:
        l1l1lll1l1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡪࡳࡱࡪ࡝࠽࠾ࠣࡴࡴࡶࡲࡻࡧࡧࡲ࡮ࡧࠠࡴࡶࡵࡳࡳࡧࠠ࠽࠾࡞࠳ࡈࡕࡌࡐࡔࡠࠫࢻ"), url=ex_link, mode=l1l111ll1l1ll_fwb_ (u"ࠪࡣࡤࡶࡡࡨࡧࡢࡣࡒ࠭ࢼ"), l111lll1ll1l1ll_fwb_=l1lllll1l1ll1l1ll_fwb_[0], IsPlayable=False)
    items=len(l111l11l1ll1l1ll_fwb_)
    for f in l111l11l1ll1l1ll_fwb_:
        l1l1lll1l1ll1l1ll_fwb_(name=f.get(l1l111ll1l1ll_fwb_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪࢽ")), url=f.get(l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡲࡦࡨࠪࢾ")), mode=l1l111ll1l1ll_fwb_ (u"࠭ࡧࡦࡶࡏ࡭ࡳࡱࡳࠨࢿ"), l1ll11lll1ll1l1ll_fwb_=f.get(l1l111ll1l1ll_fwb_ (u"ࠧࡪ࡯ࡪࠫࣀ")), infoLabels=f, IsPlayable=True,l1ll11111ll1l1ll_fwb_=items)
    if l1lllll1l1ll1l1ll_fwb_[1]:
        l1l1lll1l1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡩࡲࡰࡩࡣ࠾࠿ࠢࡱࡥࡸࡺङࡱࡰࡤࠤࡸࡺࡲࡰࡰࡤࠤࡃࡄ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨࣁ"), url=ex_link, mode=l1l111ll1l1ll_fwb_ (u"ࠩࡢࡣࡵࡧࡧࡦࡡࡢࡑࠬࣂ"), l111lll1ll1l1ll_fwb_=l1lllll1l1ll1l1ll_fwb_[1], IsPlayable=False)
def l111l111ll1l1ll_fwb_(ex_link,l111lll1ll1l1ll_fwb_):
    l111lll1ll1l1ll_fwb_ = int(l111lll1ll1l1ll_fwb_) if l111lll1ll1l1ll_fwb_ else 1
    group=l1l111ll1l1ll_fwb_ (u"ࠪࠫࣃ")
    if l1l111ll1l1ll_fwb_ (u"ࠫࢁ࠭ࣄ")in ex_link:
        ex_link,group = ex_link.split(l1l111ll1l1ll_fwb_ (u"ࠬࢂࠧࣅ"))
    if group:
        l111l11l1ll1l1ll_fwb_,l1lllll1l1ll1l1ll_fwb_ = l1ll11l1l1ll1l1ll_fwb_.l1111ll11ll1l1ll_fwb_(ex_link,int(l111lll1ll1l1ll_fwb_),group)
    else:
        l111l11l1ll1l1ll_fwb_,l1lllll1l1ll1l1ll_fwb_ = l1ll11l1l1ll1l1ll_fwb_.l11l1l11ll1l1ll_fwb_(ex_link)
    l1111lll1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"࠭ࡧࡦࡶࡈࡴ࡮ࡹ࡯ࡥࡧࡶࠫࣆ")
    if l1l111ll1l1ll_fwb_ (u"ࠧࡵࡴࡸࡩࠬࣇ") in l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠨࡩࡵࡳࡺࡶࡅࡱ࡫ࡶࡳࡩ࡫ࡳࠨࣈ")):
        l1111lll1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠩࡪࡩࡹ࡙ࡥࡢࡵࡲࡲࡸ࠭ࣉ")
    if l1lllll1l1ll1l1ll_fwb_[0]:
        l1l1lll1l1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡴࡲࡤ࡞࠾࠿ࠤࡵࡵࡰࡳࡼࡨࡨࡳ࡯ࡡࠡࡵࡷࡶࡴࡴࡡࠡ࠾࠿࡟࠴ࡉࡏࡍࡑࡕࡡࠬ࣊"), url=ex_link, mode=l1l111ll1l1ll_fwb_ (u"ࠫࡤࡥࡰࡢࡩࡨࡣࡤ࡙ࠧ࣋"), l111lll1ll1l1ll_fwb_=l1lllll1l1ll1l1ll_fwb_[0], IsPlayable=False)
    items=len(l111l11l1ll1l1ll_fwb_)
    for f in l111l11l1ll1l1ll_fwb_:
        l1ll11ll1ll1l1ll_fwb_(name=f.get(l1l111ll1l1ll_fwb_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ࣌")), ex_link=f.get(l1l111ll1l1ll_fwb_ (u"࠭ࡨࡳࡧࡩࠫ࣍")), mode=l1111lll1ll1l1ll_fwb_, iconImage=f.get(l1l111ll1l1ll_fwb_ (u"ࠧࡪ࡯ࡪࠫ࣎")), infoLabels=f)
    if l1lllll1l1ll1l1ll_fwb_[1]:
        l1l1lll1l1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡩࡲࡰࡩࡣ࠾࠿ࠢࡱࡥࡸࡺङࡱࡰࡤࠤࡸࡺࡲࡰࡰࡤࠤࡃࡄ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ࣏"), url=ex_link, mode=l1l111ll1l1ll_fwb_ (u"ࠩࡢࡣࡵࡧࡧࡦࡡࡢࡗ࣐ࠬ"), l111lll1ll1l1ll_fwb_=l1lllll1l1ll1l1ll_fwb_[1], IsPlayable=False)
def l1ll1l111ll1l1ll_fwb_(ex_link):
    l1l11l1ll1l1ll_fwb_ = l1ll11l1l1ll1l1ll_fwb_.l1l11l111ll1l1ll_fwb_(ex_link)
    for f in l1l11l1ll1l1ll_fwb_:
        l1l1lll1l1ll1l1ll_fwb_(name=f.get(l1l111ll1l1ll_fwb_ (u"ࠪࡸ࡮ࡺ࡬ࡦ࣑ࠩ")), url=f.get(l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡸࡥࡧ࣒ࠩ")), mode=l1l111ll1l1ll_fwb_ (u"ࠬ࡭ࡥࡵࡎ࡬ࡲࡰࡹ࣓ࠧ"), l1ll11lll1ll1l1ll_fwb_=f.get(l1l111ll1l1ll_fwb_ (u"࠭ࡩ࡮ࡩࠪࣔ")), infoLabels=f, IsPlayable=True)
def l1llllll1ll1l1ll_fwb_(ex_link):
    l111l11l1ll1l1ll_fwb_,l11ll11l1ll1l1ll_fwb_ = l1ll11l1l1ll1l1ll_fwb_.search(ex_link)
    for f in l111l11l1ll1l1ll_fwb_:
        l1l1lll1l1ll1l1ll_fwb_(name=f.get(l1l111ll1l1ll_fwb_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࣕ")), url=f.get(l1l111ll1l1ll_fwb_ (u"ࠨࡪࡵࡩ࡫࠭ࣖ")), mode=l1l111ll1l1ll_fwb_ (u"ࠩࡪࡩࡹࡒࡩ࡯࡭ࡶࠫࣗ"), l1ll11lll1ll1l1ll_fwb_=f.get(l1l111ll1l1ll_fwb_ (u"ࠪ࡭ࡲ࡭ࠧࣘ")), infoLabels=f, IsPlayable=True,l1ll11111ll1l1ll_fwb_=len(l111l11l1ll1l1ll_fwb_))
    for f in l11ll11l1ll1l1ll_fwb_:
        l1ll11ll1ll1l1ll_fwb_(name=f.get(l1l111ll1l1ll_fwb_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪࣙ")), ex_link=f.get(l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡲࡦࡨࠪࣚ")), mode=l1l111ll1l1ll_fwb_ (u"࠭ࡧࡦࡶࡈࡴ࡮ࡹ࡯ࡥࡧࡶࠫࣛ"), iconImage=f.get(l1l111ll1l1ll_fwb_ (u"ࠧࡪ࡯ࡪࠫࣜ")), infoLabels=f)
def l1l1111l1ll1l1ll_fwb_(ex_link,l1lll1l1l1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠨࡽࢀࠫࣝ")):
    l1lll1l1l1ll1l1ll_fwb_=eval(l1lll1l1l1ll1l1ll_fwb_)
    import resources.lib.l1ll1l1l11ll1l1ll_fwb_ as l1l111l11ll1l1ll_fwb_
    l1ll1ll111ll1l1ll_fwb_ = {l1l111ll1l1ll_fwb_ (u"ࠩࡷ࡭ࡹࡲࡥࠨࣞ"):l1lll1l1l1ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩࣟ")), l1l111ll1l1ll_fwb_ (u"ࠫࡾ࡫ࡡࡳࠩ࣠"):l1lll1l1l1ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠬࡿࡥࡢࡴࠪ࣡")),l1l111ll1l1ll_fwb_ (u"࠭࡯ࡳ࡫ࡪ࡭ࡳࡧ࡬ࡵ࡫ࡷࡰࡪ࠭࣢"):l1lll1l1l1ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠧࡰࡴ࡬࡫࡮ࡴࡡ࡭ࡶ࡬ࡸࡱ࡫ࣣࠧ")),l1l111ll1l1ll_fwb_ (u"ࠨ࡫ࡰ࡫ࠬࣤ"):l1lll1l1l1ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠩ࡬ࡱ࡬࠭ࣥ")),l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡷ࡫ࡦࠨࣦ"):l1lll1l1l1ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡸࡥࡧࠩࣧ")),l1l111ll1l1ll_fwb_ (u"ࠬࡪࡡࡵࡣࡢࡪ࡮ࡲ࡭ࠨࣨ"):l1lll1l1l1ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"࠭ࡤࡢࡶࡤࡣ࡫࡯࡬࡮ࣩࠩ")),l1l111ll1l1ll_fwb_ (u"ࠧࡱ࡮ࡲࡸࠬ࣪"):l1lll1l1l1ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠨࡲ࡯ࡳࡹ࠭࣫"))}
    l1l1l1lll1ll1l1ll_fwb_ =l1l111l11ll1l1ll_fwb_.l1l1111l1ll1l1ll_fwb_(ex_link,l1ll1ll111ll1l1ll_fwb_)
    for l11lll1ll1l1ll_fwb_ in sorted(l1l1l1lll1ll1l1ll_fwb_.keys()):
        l1ll11ll1ll1l1ll_fwb_(l11lll1ll1l1ll_fwb_,urllib.quote(str(l1l1l1lll1ll1l1ll_fwb_[l11lll1ll1l1ll_fwb_])),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠩࡪࡩࡹࡋࡰࡪࡵࡲࡨࡪࡹ࠲ࠨ࣬"),iconImage=l1lll1l1l1ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠪ࡭ࡲ࡭࣭ࠧ")),infoLabels=l1lll1l1l1ll1l1ll_fwb_)
    xbmcplugin.setContent(l1l1lll11ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠫࡸ࡫ࡡࡴࡱࡱ࣮ࠫ"))
def l1l11l11ll1l1ll_fwb_(ex_link):
    l1l11l1ll1l1ll_fwb_ = eval(urllib.unquote(ex_link))
    for f in l1l11l1ll1l1ll_fwb_:
        f[l1l111ll1l1ll_fwb_ (u"ࠬ࡯ࡳࡇࡱ࡯ࡨࡪࡸ࣯ࠧ")]=False
        l1l1lll1l1ll1l1ll_fwb_(name=f.get(l1l111ll1l1ll_fwb_ (u"࠭ࡴࡪࡶ࡯ࡩࣰࠬ")), url=f.get(l1l111ll1l1ll_fwb_ (u"ࠧࡩࡴࡨࡪࣱࠬ")), mode=l1l111ll1l1ll_fwb_ (u"ࠨࡩࡨࡸࡑ࡯࡮࡬ࡵࣲࠪ"), l1ll11lll1ll1l1ll_fwb_=f.get(l1l111ll1l1ll_fwb_ (u"ࠩ࡬ࡱ࡬࠭ࣳ")), infoLabels=f, IsPlayable=True,fanart=f.get(l1l111ll1l1ll_fwb_ (u"ࠪ࡭ࡲ࡭ࠧࣴ")))
    xbmcplugin.setContent(l1l1lll11ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭ࣵ"))
def l1l1l111l1ll1l1ll_fwb_(l1lll11111ll1l1ll_fwb_,l11l11l1ll1l1ll_fwb_):
    if len(l1lll11111ll1l1ll_fwb_)==0:
        return l1l111ll1l1ll_fwb_ (u"ࠬࡳ࡯ࡳࡧࣶࠪ")
    elif len(l1lll11111ll1l1ll_fwb_)==1:
        l111111l1ll1l1ll_fwb_ = l1lll11111ll1l1ll_fwb_[0]
    elif len(l1lll11111ll1l1ll_fwb_)>1:
        l1lll11ll1l1ll_fwb_ = l1l1ll1l1ll1l1ll_fwb_.select(l1l111ll1l1ll_fwb_ (u"ࠨॹࡳࣵࡧॆࡦࠦࠢࣷ"), l11l11l1ll1l1ll_fwb_)
        l111111l1ll1l1ll_fwb_ = l1lll11111ll1l1ll_fwb_[l1lll11ll1l1ll_fwb_] if l1lll11ll1l1ll_fwb_>-1 else False
    if l111111l1ll1l1ll_fwb_==False:
        return True
    elif l111111l1ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"ࠧࠨࣸ"):
        return l1l111ll1l1ll_fwb_ (u"ࠨ࡯ࡲࡶࡪࣹ࠭")
    else:
        try:
            l1l1lll111ll1l1ll_fwb_ = urlresolver.resolve(l111111l1ll1l1ll_fwb_)
        except Exception,e:
            if l1l111ll1l1ll_fwb_ (u"ࠩࡆࡥࡳࡩࡥ࡭࡮ࡨࡨࣺࠬ") in str(e): return True
            l1l1lll111ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠪࠫࣻ")
        if l1l1lll111ll1l1ll_fwb_: xbmcplugin.setResolvedUrl(l1l1lll11ll1l1ll_fwb_, True, xbmcgui.ListItem(path=l1l1lll111ll1l1ll_fwb_))
        else: return l1l111ll1l1ll_fwb_ (u"ࠫࡲࡵࡲࡦࠩࣼ")
    return True
def l1l1l1ll1ll1l1ll_fwb_(l1lll1l1l1ll1l1ll_fwb_):
    l11111l11ll1l1ll_fwb_=eval(l1lll1l1l1ll1l1ll_fwb_)
    l1l1lll111ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠬ࠭ࣽ")
    l1lll11111ll1l1ll_fwb_,l11l11l1ll1l1ll_fwb_ = l11ll1111ll1l1ll_fwb_(l11111l11ll1l1ll_fwb_,1)
    l1ll1llll1ll1l1ll_fwb_ = l1l1l111l1ll1l1ll_fwb_(l1lll11111ll1l1ll_fwb_,l11l11l1ll1l1ll_fwb_)
    if l1ll1llll1ll1l1ll_fwb_==l1l111ll1l1ll_fwb_ (u"࠭࡭ࡰࡴࡨࠫࣾ"):
        l1lll11111ll1l1ll_fwb_,l11l11l1ll1l1ll_fwb_ = l11ll1111ll1l1ll_fwb_(l11111l11ll1l1ll_fwb_,0)
        if not l1lll11111ll1l1ll_fwb_:
            l1l1ll1l1ll1l1ll_fwb_.notification(l1l111ll1l1ll_fwb_ (u"ࠧࡇ࡫࡯ࡱࡼ࡫ࡢࡃࡱࡲࡷࡹ࡫ࡲࠨࣿ"), l1l111ll1l1ll_fwb_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡴࡨࡨࡢࡡࡂ࡞ࡄࡵࡥࡰࠦॺࡳࣵࡧࡩेࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫऀ") , xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1l111ll1l1ll_fwb_ (u"ࠩࡳࡥࡹ࡮ࠧँ")))+l1l111ll1l1ll_fwb_ (u"ࠪ࠳࡮ࡩ࡯࡯࠰ࡳࡲ࡬࠭ं"), 5000, False)
        else:
            l1ll1llll1ll1l1ll_fwb_ = l1l1l111l1ll1l1ll_fwb_(l1lll11111ll1l1ll_fwb_,l11l11l1ll1l1ll_fwb_)
    elif not l1ll1llll1ll1l1ll_fwb_==True:
        xbmcplugin.setResolvedUrl(l1l1lll11ll1l1ll_fwb_, False, xbmcgui.ListItem(path=l1l111ll1l1ll_fwb_ (u"ࠫࠬः")))
        l1l1ll1l1ll1l1ll_fwb_.notification(l1l111ll1l1ll_fwb_ (u"ࠬࡌࡩ࡭࡯ࡺࡩࡧࡈ࡯ࡰࡵࡷࡩࡷ࠭ऄ"), l1l111ll1l1ll_fwb_ (u"࡛࠭ࡃ࡟ࡄࡲࡺࡲ࡯ࡸࡣࡱࡳࡠ࠵ࡂ࡞ࠩअ") , xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1l111ll1l1ll_fwb_ (u"ࠧࡱࡣࡷ࡬ࠬआ")))+l1l111ll1l1ll_fwb_ (u"ࠨ࠱࡬ࡧࡴࡴ࠮ࡱࡰࡪࠫइ"), 5000, False)
def l111l1111ll1l1ll_fwb_():
    return cache.get(l1l111ll1l1ll_fwb_ (u"ࠩ࡫࡭ࡸࡺ࡯ࡳࡻࠪई")).split(l1l111ll1l1ll_fwb_ (u"ࠪ࠿ࠬउ"))
def l1l11ll1ll1l1ll_fwb_(entry):
    l1lll11ll1ll1l1ll_fwb_ = l111l1111ll1l1ll_fwb_()
    if l1lll11ll1ll1l1ll_fwb_ == [l1l111ll1l1ll_fwb_ (u"ࠫࠬऊ")]:
        l1lll11ll1ll1l1ll_fwb_ = []
    l1lll11ll1ll1l1ll_fwb_.insert(0, l11lllll1ll1l1ll_fwb_(entry))
    try:
        cache.set(l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡩࡴࡶࡲࡶࡾ࠭ऋ"),l1l111ll1l1ll_fwb_ (u"ࡻࠧ࠼ࠩऌ").join(l1lll11ll1ll1l1ll_fwb_[:50]))
    except:
        pass
def l1l1l1ll11ll1l1ll_fwb_(entry):
    l1lll11ll1ll1l1ll_fwb_ = l111l1111ll1l1ll_fwb_()
    if l1lll11ll1ll1l1ll_fwb_:
        try:
            cache.set(l1l111ll1l1ll_fwb_ (u"ࠧࡩ࡫ࡶࡸࡴࡸࡹࠨऍ"),l1l111ll1l1ll_fwb_ (u"ࠨ࠽ࠪऎ").join(l1lll11ll1ll1l1ll_fwb_[:50]))
        except:
            pass
    else:
        l1l1llll11ll1l1ll_fwb_()
def l1l1llll11ll1l1ll_fwb_():
    cache.delete(l1l111ll1l1ll_fwb_ (u"ࠩ࡫࡭ࡸࡺ࡯ࡳࡻࠪए"))
def _1l11ll11ll1l1ll_fwb_(l1lll1ll11ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠪࠫऐ"),l111ll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠫࠬऑ")):
    v = l1ll1ll11ll1l1ll_fwb_.getSetting(l1lll1ll11ll1l1ll_fwb_+l1l111ll1l1ll_fwb_ (u"ࠬ࡜ࠧऒ"))
    n = l1ll1ll11ll1l1ll_fwb_.getSetting(l1lll1ll11ll1l1ll_fwb_+l1l111ll1l1ll_fwb_ (u"࠭ࡎࠨओ")) if v else l111ll1ll1l1ll_fwb_
    return {l1lll1ll11ll1l1ll_fwb_+l1l111ll1l1ll_fwb_ (u"ࠧࡗࠩऔ"): v, l1lll1ll11ll1l1ll_fwb_+l1l111ll1l1ll_fwb_ (u"ࠨࡐࠪक") : n}
params = dict(urlparse.parse_qsl(sys.argv[2].replace(l1l111ll1l1ll_fwb_ (u"ࠩࡂࠫख"),l1l111ll1l1ll_fwb_ (u"ࠪࠫग"))))
class l1lllllll1ll1l1ll_fwb_:
    def l11llll11ll1l1ll_fwb_(self):
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠦࡇࡧࡺࡢࠢࡉ࡭ࡱࡳࣳࡸ࠱ࡖࡩࡷ࡯ࡡ࡭࡫࠲ࡔࡷࡵࡧࡳࡣࡰࣷࡼࠨघ"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠬ࠭ङ"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"࠭ࡢࡢࡼࡤࡪ࡮ࡲ࡭ࡰࡹࡢࡲࡦࡼࡩࠨच"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫछ"),fanart=l1l1l1l111ll1l1ll_fwb_)
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠣࡄࡤࡾࡦࠦࡏࡴࣵࡥࠦज"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠩࠪझ"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠪࡦࡦࢀࡡࡐࡵࡲࡦࡤࡴࡡࡷ࡫ࠪञ"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠨट"),fanart=l1l1l1l111ll1l1ll_fwb_)
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠧࡘࡡ࡯࡭࡬ࡲ࡬ࠨठ"),ex_link=l1l111ll1l1ll_fwb_ (u"࠭ࠧड"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠧࡳࡣࡱ࡯࡮ࡴࡧࡵࡱࡳࡣࡳࡧࡶࡪࠩढ"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬण"),fanart=l1l1l1l111ll1l1ll_fwb_)
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠤࡅࡳࡽࠦࡏࡧࡨ࡬ࡧࡪࠨत"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠪࠫथ"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠫࡧࡵࡸࡰࡨࡩ࡭ࡨ࡫࡟࡯ࡣࡹ࡭ࠬद"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹࡌ࡯࡭ࡦࡨࡶ࠳ࡶ࡮ࡨࠩध"),fanart=l1l1l1l111ll1l1ll_fwb_)
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠨࡎࡢ࡬ࡥࡥࡷࡪࡺࡪࡧ࡭ࠤࡨ࡮ࡣࡦࡥ࡬ࡩࠥࡵࡢࡦ࡬ࡵࡾࡪऍࠢन"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠧࠨऩ"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠨࡥ࡫ࡩࡨࡵࡢࡦ࡬ࡵࡾࡪࡩ࡟࡯ࡣࡹ࡭ࠬप"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬࠭फ"),fanart=l1l1l1l111ll1l1ll_fwb_)
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠥࡔࡷ࡫࡭ࡪࡧࡵࡽࠥࡊࡖࡅ࠱ࡅࡰࡺ࠳ࡲࡢࡻࠥब"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡨ࡬ࡰࡲࡽࡥࡣ࠰ࡳࡰ࠴ࡪࡶࡥ࠱ࡳࡶࡪࡳࡩࡦࡴࡨࡷࠬभ"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠬࡪࡶࡥࡤ࡯ࡹࡪࡸࡡࡺࡡࡶ࡬ࡴࡽࠧम"),iconImage=l1l111ll1l1ll_fwb_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࠪय"),fanart=l1l1l1l111ll1l1ll_fwb_)
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠢࡑࡱࡳࡹࡱࡧࡲ࡯ࡧࠣࡊ࡮ࡲ࡭ࡺࠤर"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡩࡱࡰࡩ࠴ࡶ࡯ࡱࡷ࡯ࡥࡷ࠵ࡦࡪ࡮ࡰ࠳ࠪࡪࠧऱ"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠩࡳࡳࡵࡻ࡬ࡢࡴࡱࡩ࡫࡯࡬࡮ࡻࡢࡷ࡭ࡵࡷࠨल"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧळ"),fanart=l1l1l1l111ll1l1ll_fwb_)
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠦࡕࡵࡰࡶ࡮ࡤࡶࡳ࡫ࠠࡔࡧࡵ࡭ࡦࡲࡥࠣऴ"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠬ࠵ࡡ࡫ࡣࡻ࠳࡭ࡵ࡭ࡦ࠱ࡳࡳࡵࡻ࡬ࡢࡴ࠲ࡷࡪࡸࡩࡢ࡮࠲ࠩࡩ࠭व"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"࠭ࡰࡰࡲࡸࡰࡦࡸ࡮ࡦࡨ࡬ࡰࡲࡿ࡟ࡴࡪࡲࡻࠬश"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫष"),fanart=l1l1l1l111ll1l1ll_fwb_)
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠣࡆࡽ࡭ॠࠦࡷࠡࡖ࡙ࠤࡋ࡯࡬࡮ࠤस"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠩ࠲ࡥ࡯ࡧࡸ࠰ࡪࡲࡱࡪ࠵ࡴࡷࡔࡨࡧࡴࡳ࡭ࡦࡰࡧࡥࡹ࡯࡯࡯ࡵ࠲ࡪ࡮ࡲ࡭ࡀࡲࡤ࡫ࡪࡃࠥࡥࠩह"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠪࡨࡿ࡯ࡳࡧ࡫࡯ࡱࡾࡽࡴࡷࡡࡶ࡬ࡴࡽࠧऺ"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠨऻ"),fanart=l1l1l1l111ll1l1ll_fwb_)
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠧࡊࡺࡪढ़ࠣࡻ࡚ࠥࡖࠡࡕࡨࡶ࡮ࡧ࡬़ࠣ"),ex_link=l1l111ll1l1ll_fwb_ (u"࠭࠯ࡢ࡬ࡤࡼ࠴࡮࡯࡮ࡧ࠲ࡸࡻࡘࡥࡤࡱࡰࡱࡪࡴࡤࡢࡶ࡬ࡳࡳࡹ࠯ࡴࡧࡵ࡭ࡦࡲ࠿ࡱࡣࡪࡩࡂࠫࡤࠨऽ"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠧࡥࡼ࡬ࡷ࡫࡯࡬࡮ࡻࡺࡸࡻࡥࡳࡩࡱࡺࠫा"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬि"),fanart=l1l1l1l111ll1l1ll_fwb_)
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢ࡯࡭࡬࡮ࡴࡣ࡮ࡸࡩࡢ࡙ࡺࡶ࡭ࡤ࡮ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ी"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠪࠫु"),mode=l1l111ll1l1ll_fwb_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭ࠫू"))
    def l1l1ll11l1ll1l1ll_fwb_(self,ex_link,l111lll1ll1l1ll_fwb_):
        l111lll1ll1l1ll_fwb_ = int(l111lll1ll1l1ll_fwb_)
        import resources.lib.l1ll1l1l11ll1l1ll_fwb_ as l1l111l11ll1l1ll_fwb_
        import resources.lib.l11ll1ll1ll1l1ll_fwb_ as l1l1llll1ll1l1ll_fwb_
        pool = l1l1llll1ll1l1ll_fwb_.ThreadPool(3)
        l111l11l1ll1l1ll_fwb_=[]
        try:
            for l11l111l1ll1l1ll_fwb_ in range(3):
                time.sleep(0.1)
                pool.add_task(l1l111l11ll1l1ll_fwb_.l1lll1lll1ll1l1ll_fwb_, *(ex_link%(l11l111l1ll1l1ll_fwb_+l111lll1ll1l1ll_fwb_),l111l11l1ll1l1ll_fwb_))
            pool.wait_completion()
        except:
            pass
        if l1l111ll1l1ll_fwb_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡥࡱ࠭ृ") in ex_link:
            l111ll111ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"࠭ࡧࡦࡶࡖࡩࡦࡹ࡯࡯ࡵࠪॄ")
            xbmcplugin.setContent(l1l1lll11ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠧࡵࡸࡶ࡬ࡴࡽࡳࠨॅ"))
        else:
            l111ll111ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠨࡩࡨࡸࡑ࡯࡮࡬ࡵࠪॆ")
            xbmcplugin.setContent(l1l1lll11ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩे"))
        if l111lll1ll1l1ll_fwb_>1:
            l1l1lll1l1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡴࡲࡤ࡞࠾࠿ࠤࡵࡵࡰࡳࡼࡨࡨࡳ࡯ࡡࠡࡵࡷࡶࡴࡴࡡࠡ࠾࠿࡟࠴ࡉࡏࡍࡑࡕࡡࠬै"), url=ex_link, mode=l1l111ll1l1ll_fwb_ (u"ࠫࡤࡥࡰࡢࡩࡨࡣࡤࡀࡤࡻ࡫ࡶࡪ࡮ࡲ࡭ࡺࡹࡷࡺࡤࡹࡨࡰࡹࠪॉ"), l111lll1ll1l1ll_fwb_=l111lll1ll1l1ll_fwb_-3, IsPlayable=False)
        for f in l111l11l1ll1l1ll_fwb_:
            l1l1lll1l1ll1l1ll_fwb_(name=f.get(l1l111ll1l1ll_fwb_ (u"ࠬࡺࡩࡵ࡮ࡨࠫॊ")), url=f.get(l1l111ll1l1ll_fwb_ (u"࠭ࡨࡳࡧࡩࠫो")), mode=l111ll111ll1l1ll_fwb_, l1ll11lll1ll1l1ll_fwb_=f.get(l1l111ll1l1ll_fwb_ (u"ࠧࡪ࡯ࡪࠫौ")), infoLabels=f, IsPlayable=True,l1ll11111ll1l1ll_fwb_=len(l111l11l1ll1l1ll_fwb_))
        if l111lll1ll1l1ll_fwb_<10:
            l1l1lll1l1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡩࡲࡰࡩࡣ࠾࠿ࠢࡱࡥࡸࡺङࡱࡰࡤࠤࡸࡺࡲࡰࡰࡤࠤࡃࡄ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ्"), url=ex_link, mode=l1l111ll1l1ll_fwb_ (u"ࠩࡢࡣࡵࡧࡧࡦࡡࡢ࠾ࡩࢀࡩࡴࡨ࡬ࡰࡲࡿࡷࡵࡸࡢࡷ࡭ࡵࡷࠨॎ"), l111lll1ll1l1ll_fwb_=l111lll1ll1l1ll_fwb_+3, IsPlayable=False)
    def l1llll1l1ll1l1ll_fwb_(self,ex_link,l111lll1ll1l1ll_fwb_):
        l111lll1ll1l1ll_fwb_ = int(l111lll1ll1l1ll_fwb_)
        import resources.lib.l1ll1l1l11ll1l1ll_fwb_ as l1l111l11ll1l1ll_fwb_
        l111l11l1ll1l1ll_fwb_= l1l111l11ll1l1ll_fwb_.l111l1l1ll1l1ll_fwb_(ex_link%l111lll1ll1l1ll_fwb_)
        if l1l111ll1l1ll_fwb_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡣ࡯ࠫॏ") in ex_link:
            l111ll111ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠫ࡬࡫ࡴࡔࡧࡤࡷࡴࡴࡳࠨॐ")
            xbmcplugin.setContent(l1l1lll11ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠬࡺࡶࡴࡪࡲࡻࡸ࠭॑"))
        else:
            l111ll111ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"࠭ࡧࡦࡶࡏ࡭ࡳࡱࡳࠨ॒")
            xbmcplugin.setContent(l1l1lll11ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ॓"))
        if l111lll1ll1l1ll_fwb_>1:
            l1l1lll1l1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡩࡲࡰࡩࡣ࠼࠽ࠢࡳࡳࡵࡸࡺࡦࡦࡱ࡭ࡦࠦࡳࡵࡴࡲࡲࡦࠦ࠼࠽࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ॔"), url=ex_link, mode=l1l111ll1l1ll_fwb_ (u"ࠩࡢࡣࡵࡧࡧࡦࡡࡢ࠾ࡵࡵࡰࡶ࡮ࡤࡶࡳ࡫ࡦࡪ࡮ࡰࡽࡤࡹࡨࡰࡹࠪॕ"), l111lll1ll1l1ll_fwb_=l111lll1ll1l1ll_fwb_-1, IsPlayable=False)
        for f in l111l11l1ll1l1ll_fwb_:
            l1l1lll1l1ll1l1ll_fwb_(name=f.get(l1l111ll1l1ll_fwb_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩॖ")), url=f.get(l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡸࡥࡧࠩॗ")), mode=l111ll111ll1l1ll_fwb_, l1ll11lll1ll1l1ll_fwb_=f.get(l1l111ll1l1ll_fwb_ (u"ࠬ࡯࡭ࡨࠩक़")), infoLabels=f, IsPlayable=True,l1ll11111ll1l1ll_fwb_=len(l111l11l1ll1l1ll_fwb_))
        if l111lll1ll1l1ll_fwb_<10:
            l1l1lll1l1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡧࡰ࡮ࡧࡡࡃࡄࠠ࡯ࡣࡶࡸञࡶ࡮ࡢࠢࡶࡸࡷࡵ࡮ࡢࠢࡁࡂࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ख़"), url=ex_link, mode=l1l111ll1l1ll_fwb_ (u"ࠧࡠࡡࡳࡥ࡬࡫࡟ࡠ࠼ࡳࡳࡵࡻ࡬ࡢࡴࡱࡩ࡫࡯࡬࡮ࡻࡢࡷ࡭ࡵࡷࠨग़"), l111lll1ll1l1ll_fwb_=l111lll1ll1l1ll_fwb_+1, IsPlayable=False)
    def l1ll1l1111ll1l1ll_fwb_(self,ex_link):
        import resources.lib.l1ll1l1l11ll1l1ll_fwb_ as l1l111l11ll1l1ll_fwb_
        l111l11l1ll1l1ll_fwb_,l1lllll1l1ll1l1ll_fwb_ = l1l111l11ll1l1ll_fwb_.l1lll1ll1ll1l1ll_fwb_(ex_link)
        if l1lllll1l1ll1l1ll_fwb_[0]:
            l1l1lll1l1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡩࡲࡰࡩࡣ࠼࠽ࠢࡺࡧࡿ࡫ज़࡯࡫ࡨ࡮ࠥࠫࡳࠡ࠾࠿࡟࠴ࡉࡏࡍࡑࡕࡡࠬज़")%l1l111l11ll1l1ll_fwb_.l1llll1111ll1l1ll_fwb_(l1lllll1l1ll1l1ll_fwb_[0].split(l1l111ll1l1ll_fwb_ (u"ࠩ࠲ࠫड़"))[-1]), url=l1lllll1l1ll1l1ll_fwb_[0], mode=l1l111ll1l1ll_fwb_ (u"ࠪࡣࡤࡶࡡࡨࡧࡢࡣ࠿ࡪࡶࡥࡤ࡯ࡹࡪࡸࡡࡺࡡࡶ࡬ࡴࡽࠧढ़"), l111lll1ll1l1ll_fwb_=0, IsPlayable=False)
        for f in l111l11l1ll1l1ll_fwb_:
            l111ll111ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠫ࡬࡫ࡴࡔࡧࡤࡷࡴࡴࡳࠨफ़") if l1l111ll1l1ll_fwb_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡥࡱ࠭य़") in f.get(l1l111ll1l1ll_fwb_ (u"࠭ࡨࡳࡧࡩࠫॠ")) else l1l111ll1l1ll_fwb_ (u"ࠧࡨࡧࡷࡐ࡮ࡴ࡫ࡴࠩॡ")
            l1l1lll1l1ll1l1ll_fwb_(name=f.get(l1l111ll1l1ll_fwb_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧॢ")), url=f.get(l1l111ll1l1ll_fwb_ (u"ࠩ࡫ࡶࡪ࡬ࠧॣ")), mode=l111ll111ll1l1ll_fwb_, l1ll11lll1ll1l1ll_fwb_=f.get(l1l111ll1l1ll_fwb_ (u"ࠪ࡭ࡲ࡭ࠧ।")), infoLabels=f, IsPlayable=True,l1ll11111ll1l1ll_fwb_=len(l111l11l1ll1l1ll_fwb_))
        if l1lllll1l1ll1l1ll_fwb_[1]:
            l1l1lll1l1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤ࡬ࡵ࡬ࡥ࡟ࡁࡂࠥࡶࣳॻࡰ࡬ࡩ࡯ࠦࠥࡴࠢࡁࡂࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭॥")%l1l111l11ll1l1ll_fwb_.l1llll1111ll1l1ll_fwb_(l1lllll1l1ll1l1ll_fwb_[1].split(l1l111ll1l1ll_fwb_ (u"ࠬ࠵ࠧ०"))[-1]), url=l1lllll1l1ll1l1ll_fwb_[1], mode=l1l111ll1l1ll_fwb_ (u"࠭࡟ࡠࡲࡤ࡫ࡪࡥ࡟࠻ࡦࡹࡨࡧࡲࡵࡦࡴࡤࡽࡤࡹࡨࡰࡹࠪ१"), l111lll1ll1l1ll_fwb_=0, IsPlayable=False)
        xbmcplugin.setContent(l1l1lll11ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ२"))
    def l1ll111l1ll1l1ll_fwb_(self):
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠣࡐࡲࡻࡴॡࡣࡪࠢࡺࠤࡕࡵ࡬ࡴࡥࡨࠤࡴࡹࡴࡢࡶࡱ࡭ࡪ࡭࡯ࠡ࡯࡬ࡩࡸ࡯अࡤࡣࠥ३"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠩ࠲ࡶࡦࡴ࡫ࡪࡰࡪ࠳ࡼࡧ࡮ࡵࡖࡲࡗࡪ࡫࠯࡭ࡣࡶࡸ࠸࠶ࡤࡢࡻࡶࡔࡴࡲࡡ࡯ࡦࠪ४"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠪࡶࡦࡴ࡫ࡪࡰࡪࡸࡴࡶ࡟ࡴࡪࡲࡻࠬ५"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠨ६"),fanart=l1l1l1l111ll1l1ll_fwb_,infoLabels={l1l111ll1l1ll_fwb_ (u"ࠬࡶ࡬ࡰࡶࠪ७"):l1l111ll1l1ll_fwb_ (u"࠭ࡆࡪ࡮ࡰࡽ࠱ࠦ࡫ࡵࣵࡵࡩࠥࡴࡡ࡫ࡥ࡫झࡹࡴࡩࡦ࡬ࠣࡳࡧ࡫ࡪࡳࡼࡨࡰ࡮ࡨࡹࠡࡷॿࡽࡹࡱ࡯ࡸࡰ࡬ࡧࡾࠦࡺࠡࡱࡶࡸࡦࡺ࡮ࡪࡧࡪࡳࠥࡳࡩࡦ࡫ࡶ࡭ࡦࡩࡡࠡࡹࠣࡴࡴࡲࡳࡤࡧࠪ८")})
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠢࡏࡱࡺࡳॠࡩࡩࠡࡹࠣࡔࡴࡲࡳࡤࡧࠣࡳࡸࡺࡡࡵࡰ࡬ࡧ࡭ࠦ࠹࠱ࠢࡧࡲ࡮ࠨ९"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠨ࠱ࡵࡥࡳࡱࡩ࡯ࡩ࠲ࡻࡦࡴࡴࡕࡱࡖࡩࡪ࠵࡬ࡢࡵࡷ࠽࠵ࡪࡡࡺࡵࡓࡳࡱࡧ࡮ࡥࠩ॰"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠩࡵࡥࡳࡱࡩ࡯ࡩࡷࡳࡵࡥࡳࡩࡱࡺࠫॱ"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧॲ"),fanart=l1l1l1l111ll1l1ll_fwb_,infoLabels={l1l111ll1l1ll_fwb_ (u"ࠫࡵࡲ࡯ࡵࠩॳ"):l1l111ll1l1ll_fwb_ (u"ࠬࡌࡩ࡭࡯ࡼ࠰ࠥࡱࡴࣴࡴࡨࠤࡳࡧࡪࡤࡪजࡸࡳ࡯ࡥ࡫ࠢࡲࡦࡪࡰࡲࡻࡧ࡯࡭ࡧࡿࠠࡶॾࡼࡸࡰࡵࡷ࡯࡫ࡦࡽࠥࢀࠠࡰࡵࡷࡥࡹࡴࡩࡤࡪࠣ࠷ࠥࡳ࠭ࡤࡻࠣࡻࠥࡶ࡯࡭ࡵࡦࡩࠬॴ")})
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠨࡎࡢ࡬ࡥࡥࡷࡪࡺࡪࡧ࡭ࠤࡴࡩࡺࡦ࡭࡬ࡻࡦࡴࡥࠡࡱࡶࡸࡦࡺ࡮ࡪࡥ࡫ࠤ࠸ࠦ࡭࠮ࡥࡼࠦॵ"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠧ࠰ࡴࡤࡲࡰ࡯࡮ࡨ࠱ࡺࡥࡳࡺࡔࡰࡕࡨࡩ࠴ࡲࡡࡴࡶ࠼࠴ࡩࡧࡹࡴ࡙ࡲࡶࡱࡪࠧॶ"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠨࡴࡤࡲࡰ࡯࡮ࡨࡶࡲࡴࡤࡹࡨࡰࡹࠪॷ"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬࠭ॸ"),fanart=l1l1l1l111ll1l1ll_fwb_,infoLabels={l1l111ll1l1ll_fwb_ (u"ࠪࡴࡱࡵࡴࠨॹ"):l1l111ll1l1ll_fwb_ (u"ࠫࡋ࡯࡬࡮ࡻ࠯ࠤࡰࡺࣳࡳࡧࠣࡲࡦࡰࡣࡩछࡷࡲ࡮࡫ࡪࠡࡱࡥࡩ࡯ࡸࡺࡦ࡮࡬ࡦࡾࠦࡵॽࡻࡷ࡯ࡴࡽ࡮ࡪࡥࡼࠤࡿࠦ࡯ࡴࡶࡤࡸࡳ࡯ࡣࡩࠢ࠶ࠤࡲ࠳ࡣࡺࠢࡱࡥࠥॡࡷࡪࡧࡦ࡭ࡪ࠭ॺ")})
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠧࡔࡡ࡫ࡤࡤࡶࡩࢀࡩࡦ࡬ࠣࡳࡨࢀࡥ࡬࡫ࡺࡥࡳ࡫ࠠࡰࡵࡷࡥࡹࡴࡩࡤࡪࠣ࠺ࠥࡳ࠭ࡤࡻࠥॻ"),ex_link=l1l111ll1l1ll_fwb_ (u"࠭࠯ࡳࡣࡱ࡯࡮ࡴࡧ࠰ࡹࡤࡲࡹ࡚࡯ࡔࡧࡨ࠳ࡱࡧࡳࡵ࠸ࡰࡳࡳࡺࡨࡴ࡙ࡲࡶࡱࡪࠧॼ"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠧࡳࡣࡱ࡯࡮ࡴࡧࡵࡱࡳࡣࡸ࡮࡯ࡸࠩॽ"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬॾ"),fanart=l1l1l1l111ll1l1ll_fwb_,infoLabels={l1l111ll1l1ll_fwb_ (u"ࠩࡳࡰࡴࡺࠧॿ"):l1l111ll1l1ll_fwb_ (u"ࠪࡊ࡮ࡲ࡭ࡺ࠮ࠣ࡯ࡹࣹࡲࡦࠢࡱࡥ࡯ࡩࡨचࡶࡱ࡭ࡪࡰࠠࡰࡤࡨ࡮ࡷࢀࡥ࡭࡫ࡥࡽࠥࡻॼࡺࡶ࡮ࡳࡼࡴࡩࡤࡻࠣࡾࠥࡵࡳࡵࡣࡷࡲ࡮ࡩࡨࠡ࠸ࠣࡱ࠲ࡩࡹࠡࡰࡤࠤॠࡽࡩࡦࡥ࡬ࡩࠬঀ")})
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠦࡓࡧࡪࡣࡣࡵࡨࡿ࡯ࡥ࡫ࠢࡲࡧࡿ࡫࡫ࡪࡹࡤࡲࡪࠦ࡯ࡴࡶࡤࡸࡳ࡯ࡥࡨࡱࠣࡶࡴࡱࡵࠣঁ"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠬ࠵ࡲࡢࡰ࡮࡭ࡳ࡭࠯ࡸࡣࡱࡸ࡙ࡵࡓࡦࡧ࠲ࡰࡦࡹࡴ࠲࠴ࡰࡳࡳࡺࡨࡴ࡙ࡲࡶࡱࡪࠧং"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"࠭ࡲࡢࡰ࡮࡭ࡳ࡭ࡴࡰࡲࡢࡷ࡭ࡵࡷࠨঃ"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫ঄"),fanart=l1l1l1l111ll1l1ll_fwb_,infoLabels={l1l111ll1l1ll_fwb_ (u"ࠨࡲ࡯ࡳࡹ࠭অ"):l1l111ll1l1ll_fwb_ (u"ࠩࡉ࡭ࡱࡳࡹ࠭ࠢ࡮ࡸࣸࡸࡥࠡࡰࡤ࡮ࡨ࡮ङࡵࡰ࡬ࡩ࡯ࠦ࡯ࡣࡧ࡭ࡶࡿ࡫࡬ࡪࡤࡼࠤࡺংࡹࡵ࡭ࡲࡻࡳ࡯ࡣࡺࠢࡽࠤࡴࡹࡴࡢࡶࡱ࡭ࡨ࡮ࠠ࠲࠴ࠣࡱ࠲ࡩࡹࠡࡰࡤࠤॠࡽࡩࡦࡥ࡬ࡩࠬআ")})
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠥࡘࡴࡶࠠࡐࡵࡷࡥࡹࡴࡩࡦࠢࡧࡩࡰࡧࡤࡺࠤই"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠫ࠴ࡸࡡ࡯࡭࡬ࡲ࡬࠵ࡷࡢࡰࡷࡘࡴ࡙ࡥࡦ࠱࡯ࡥࡸࡺࡄࡦࡥࡤࡨࡪࡌࡩ࡭࡯ࡶࠫঈ"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠬࡸࡡ࡯࡭࡬ࡲ࡬ࡺ࡯ࡱࡡࡶ࡬ࡴࡽࠧউ"),iconImage=l1l111ll1l1ll_fwb_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࠪঊ"),fanart=l1l1l1l111ll1l1ll_fwb_,infoLabels={l1l111ll1l1ll_fwb_ (u"ࠧࡱ࡮ࡲࡸࠬঋ"):l1l111ll1l1ll_fwb_ (u"ࠨࡈ࡬ࡰࡲࡿࠠࡰࡵࡷࡥࡹࡴࡩࡦ࡬ࠣࡨࡪࡱࡡࡥࡻ࠯ࠤࡰࡺࣳࡳࡧࠣࡹঁࡿࡴ࡬ࡱࡺࡲ࡮ࡩࡹࠡࡥ࡫झࡹࡴࡩࡦࠢࡥࡽࠥࡵࡢࡦ࡬ࡵࡾࡪࡲࡩࠨঌ")})
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠤࡗࡳࡵࠦࡋ࡭ࡣࡶࡽࡰ࡯ࠢ঍"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠪ࠳ࡷࡧ࡮࡬࡫ࡱ࡫࠴ࡽࡡ࡯ࡶࡗࡳࡘ࡫ࡥ࠰ࡥ࡯ࡥࡸࡹࡩࡤࡣ࡯ࡊ࡮ࡲ࡭ࡴࠩ঎"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠫࡷࡧ࡮࡬࡫ࡱ࡫ࡹࡵࡰࡠࡵ࡫ࡳࡼ࠭এ"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹࡌ࡯࡭ࡦࡨࡶ࠳ࡶ࡮ࡨࠩঐ"),fanart=l1l1l1l111ll1l1ll_fwb_,infoLabels={l1l111ll1l1ll_fwb_ (u"࠭ࡰ࡭ࡱࡷࠫ঑"):l1l111ll1l1ll_fwb_ (u"ࠧࡇ࡫࡯ࡱࡾࠦ࡫࡭ࡣࡶࡽࡨࢀ࡮ࡦ࠮ࠣ࡯ࡹࣹࡲࡦࠢࡸঀࡾࡺ࡫ࡰࡹࡱ࡭ࡨࡿࠠࡤࡪजࡸࡳ࡯ࡥࠡࡤࡼࠤࡴࡨࡥ࡫ࡴࡽࡩࡱ࡯ࠧ঒")})
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠣࡖࡲࡴࠥࡔ࡯ࡸࡱफ़ࡧ࡮ࠨও"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠩ࠲ࡶࡦࡴ࡫ࡪࡰࡪ࠳ࡵࡸࡥ࡮࡫ࡨࡶࡪ࠭ঔ"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠪࡶࡦࡴ࡫ࡪࡰࡪࡸࡴࡶ࡟ࡴࡪࡲࡻࠬক"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠨখ"),fanart=l1l1l1l111ll1l1ll_fwb_,infoLabels={l1l111ll1l1ll_fwb_ (u"ࠬࡶ࡬ࡰࡶࠪগ"):l1l111ll1l1ll_fwb_ (u"࠭ࡔࡰࡲࠣࡒࡴࡽ࡯ड़ࡥ࡬ࠤࡿ࡫ࠠड़ࡹ࡬ࡥࡹࡧࠧঘ")})
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠢࡕࡱࡳࠤय़ࡽࡩࡢࡶࠥঙ"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠨ࠱ࡵࡥࡳࡱࡩ࡯ࡩ࠲ࡪ࡮ࡲ࡭ࠨচ"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠩࡵࡥࡳࡱࡩ࡯ࡩࡷࡳࡵࡥࡳࡩࡱࡺࠫছ"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧজ"),fanart=l1l1l1l111ll1l1ll_fwb_,infoLabels={l1l111ll1l1ll_fwb_ (u"ࠫࡵࡲ࡯ࡵࠩঝ"):l1l111ll1l1ll_fwb_ (u"ࠬࡘࡡ࡯࡭࡬ࡲ࡬ࠦࡆࡪ࡯ࣶࡻࠥࢀࡥࠡढ़ࡺ࡭ࡦࡺࡡࠨঞ")})
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠨࡔࡰࡲࠣࡔࡴࡲࡳ࡬ࡣࠥট"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠧ࠰ࡴࡤࡲࡰ࡯࡮ࡨ࠱ࡩ࡭ࡱࡳ࠯ࡑࡱ࡯ࡷࡰࡧ࠯࠵࠴ࠪঠ"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠨࡴࡤࡲࡰ࡯࡮ࡨࡶࡲࡴࡤࡹࡨࡰࡹࠪড"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬࠭ঢ"),fanart=l1l1l1l111ll1l1ll_fwb_,infoLabels={l1l111ll1l1ll_fwb_ (u"ࠪࡴࡱࡵࡴࠨণ"):l1l111ll1l1ll_fwb_ (u"ࠫࡗࡧ࡮࡬࡫ࡱ࡫ࠥࡌࡩ࡮ࣵࡺࠤࡿࠦࡰࡰ࡮ࡶ࡯࡮࠭ত")})
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"࡚ࠧ࡯ࡱࠢࡅࡳࡽࡕࡦࡧ࡫ࡦࡩࠧথ"),ex_link=l1l111ll1l1ll_fwb_ (u"࠭࠯ࡳࡣࡱ࡯࡮ࡴࡧ࠰ࡤࡲࡼࡔ࡬ࡦࡪࡥࡨࠫদ"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠧࡳࡣࡱ࡯࡮ࡴࡧࡵࡱࡳࡣࡸ࡮࡯ࡸࠩধ"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬন"),fanart=l1l1l1l111ll1l1ll_fwb_,infoLabels={l1l111ll1l1ll_fwb_ (u"ࠩࡳࡰࡴࡺࠧ঩"):l1l111ll1l1ll_fwb_ (u"ࠪࡖࡦࡴ࡫ࡪࡰࡪࠤࡧࡵࡸࠡࡱࡩࡪ࡮ࡩࡥࡶ࠰ࠪপ")})
    def l1l111ll1ll1l1ll_fwb_(self):
        d = {}
        d.update(_1l11ll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠫࡷࡧ࡮࡬࡫ࡱ࡫ࡹࡵࡰࡠ࡭ࡵࡥ࡯࡫ࠧফ"),l1l111ll1l1ll_fwb_ (u"ࠬ࡝ࡳࡻࡻࡶࡸࡰ࡯ࡥࠨব")))
        d.update(_1l11ll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"࠭ࡲࡢࡰ࡮࡭ࡳ࡭ࡴࡰࡲࡢ࡫ࡦࡺࡵ࡯࡭࡬ࠫভ"),l1l111ll1l1ll_fwb_ (u"ࠧࡘࡵࡽࡽࡸࡺ࡫ࡪࡧࠪম")))
        d.update(_1l11ll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠨࡴࡤࡲࡰ࡯࡮ࡨࡶࡲࡴࡤࡲࡡࡵࡣࠪয"),l1l111ll1l1ll_fwb_ (u"࡚ࠩࡷࡿࡿࡳࡵ࡭࡬ࡩࠬর")))
        d.update(_1l11ll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠪࡐࡺࡪࡺࡪࡧࡢࡊ࡮ࡲ࡭ࡶࠩ঱"),l1l111ll1l1ll_fwb_ (u"ࠫࡦࡱࡴࡰࡴࣶࡻࠬল")))
        return d
    def l1llll1ll1ll1l1ll_fwb_(self):
        l11l111ll1l1ll_fwb_ = self.l1l111ll1ll1l1ll_fwb_()
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠧࡡࡃࡐࡎࡒࡖࠥࡲࡩࡨࡪࡷࡦࡱࡻࡥ࡞ࡍࡵࡥ࡯࡫࠺࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࡞ࡆࡢࠨ঳")+l11l111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"࠭ࡲࡢࡰ࡮࡭ࡳ࡭ࡴࡰࡲࡢ࡯ࡷࡧࡪࡦࡐࠪ঴"),l1l111ll1l1ll_fwb_ (u"ࠧࠨ঵"))+l1l111ll1l1ll_fwb_ (u"ࠣ࡝࠲ࡆࡢࠨশ"),l1l111ll1l1ll_fwb_ (u"ࠩࠪষ"),mode=l1l111ll1l1ll_fwb_ (u"ࠪࡷࡪࡲࡥࡤࡶ࠽ࡶࡦࡴ࡫ࡪࡰࡪࡸࡴࡶ࡟࡬ࡴࡤ࡮ࡪ࠭স"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠫࠬহ"),IsPlayable=False)
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠧࡡࡃࡐࡎࡒࡖࠥࡲࡩࡨࡪࡷࡦࡱࡻࡥ࡞ࡉࡤࡸࡺࡴ࡫ࡪ࠼࡞࠳ࡈࡕࡌࡐࡔࡠࠤࡠࡈ࡝ࠣ঺")+l11l111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"࠭ࡲࡢࡰ࡮࡭ࡳ࡭ࡴࡰࡲࡢ࡫ࡦࡺࡵ࡯࡭࡬ࡒࠬ঻"),l1l111ll1l1ll_fwb_ (u"ࠧࠨ়"))+l1l111ll1l1ll_fwb_ (u"ࠣ࡝࠲ࡆࡢࠨঽ"),l1l111ll1l1ll_fwb_ (u"ࠩࠪা"),mode=l1l111ll1l1ll_fwb_ (u"ࠪࡷࡪࡲࡥࡤࡶ࠽ࡶࡦࡴ࡫ࡪࡰࡪࡸࡴࡶ࡟ࡨࡣࡷࡹࡳࡱࡩࠨি"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠫࠬী"),IsPlayable=False)
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠧࡡࡃࡐࡎࡒࡖࠥࡲࡩࡨࡪࡷࡦࡱࡻࡥ࡞ࡎࡤࡸࡦࡀ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠡ࡝ࡅࡡࠧু")+l11l111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"࠭ࡲࡢࡰ࡮࡭ࡳ࡭ࡴࡰࡲࡢࡰࡦࡺࡡࡏࠩূ"),l1l111ll1l1ll_fwb_ (u"ࠧࠨৃ"))+l1l111ll1l1ll_fwb_ (u"ࠣ࡝࠲ࡆࡢࠨৄ"),l1l111ll1l1ll_fwb_ (u"ࠩࠪ৅"),mode=l1l111ll1l1ll_fwb_ (u"ࠪࡷࡪࡲࡥࡤࡶ࠽ࡶࡦࡴ࡫ࡪࡰࡪࡸࡴࡶ࡟࡭ࡣࡷࡥࠬ৆"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠫࠬে"),IsPlayable=False)
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠧࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࡘࡡ࡯࡭࡬ࡲ࡬ࠦࡦࡪ࡮ࡰࣷࡼࡡ࠯ࡄࡑࡏࡓࡗࡣࠢৈ"),ex_link=l1l111ll1l1ll_fwb_ (u"࠭ࠧ৉"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠧࡳࡣࡱ࡯࡮ࡴࡧࡵࡱࡳࡣࡸ࡮࡯ࡸࠩ৊"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬো"),fanart=l1l1l1l111ll1l1ll_fwb_)
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠤࠣࠤࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟ࡕࡥࡳࡱࡩ࡯ࡩࠣࡷࡪࡸࡩࡢ࡮࡬࡟࠴ࡉࡏࡍࡑࡕࡡࠧৌ"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠪ࠳ࡷࡧ࡮࡬࡫ࡱ࡫ࡸ࠵ࡳࡦࡴ࡬ࡥࡱ࠵ࡣࡰࡷࡱࡸࡷࡿ࠿ࠨ্"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠫࡷࡧ࡮࡬࡫ࡱ࡫ࡸ࡫ࡲࡪࡣ࡯࡭ࡤࡹࡨࡰࡹࠪৎ"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹࡌ࡯࡭ࡦࡨࡶ࠳ࡶ࡮ࡨࠩ৏"),fanart=l1l1l1l111ll1l1ll_fwb_)
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠨ࡛ࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸࡧࡲࡵࡦ࡟ࡏࡹࡩࢀࡩࡦࠢࡉ࡭ࡱࡳࡵ࠻࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣ࡟ࡇࡣࠢ৐")+l11l111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠧࡍࡷࡧࡾ࡮࡫࡟ࡇ࡫࡯ࡱࡺࡔࠧ৑"),l1l111ll1l1ll_fwb_ (u"ࠨࠩ৒"))+l1l111ll1l1ll_fwb_ (u"ࠤ࡞࠳ࡇࡣࠢ৓"),l1l111ll1l1ll_fwb_ (u"ࠪࠫ৔"),mode=l1l111ll1l1ll_fwb_ (u"ࠫࡸ࡫࡬ࡦࡥࡷ࠾ࡑࡻࡤࡻ࡫ࡨࡣࡋ࡯࡬࡮ࡷࠪ৕"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠬ࠭৖"),IsPlayable=False)
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠨࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣࡌࡶࡦࡽ࡭ࠥࡌࡩ࡭࡯ࡸࠤࡠ࠵ࡃࡐࡎࡒࡖࡢࠨৗ"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠧ࠰ࡴࡤࡲࡰ࡯࡮ࡨ࠱ࡳࡩࡷࡹ࡯࡯࠱ࡤࡧࡹࡵࡲࡴ࠱ࡰࡥࡱ࡫ࠧ৘"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠨࡴࡤࡲࡰ࡯࡮ࡨࡲࡨࡶࡸࡵ࡮ࡠࡵ࡫ࡳࡼ࠭৙"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬࠭৚"),fanart=l1l1l1l111ll1l1ll_fwb_)
    def l111ll11ll1l1ll_fwb_(self,ex_link):
        import resources.lib.l1ll1l1l11ll1l1ll_fwb_ as l1l111l11ll1l1ll_fwb_
        if ex_link==l1l111ll1l1ll_fwb_ (u"ࠪࠫ৛"):
            l1l1ll111ll1l1ll_fwb_ = l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠫࡷࡧ࡮࡬࡫ࡱ࡫ࡹࡵࡰࡠࡩࡤࡸࡺࡴ࡫ࡪࡘࠪড়"))
            l1111l11ll1l1ll_fwb_ = l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠬࡸࡡ࡯࡭࡬ࡲ࡬ࡺ࡯ࡱࡡ࡮ࡶࡦࡰࡥࡗࠩঢ়"))
            l1l1111ll1l1ll_fwb_ = l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"࠭ࡲࡢࡰ࡮࡭ࡳ࡭ࡴࡰࡲࡢࡰࡦࡺࡡࡗࠩ৞"))
            ex_link=l1l111ll1l1ll_fwb_ (u"ࠧ࠰ࡴࡤࡲࡰ࡯࡮ࡨ࠱ࡩ࡭ࡱࡳࠧয়")+l1111l11ll1l1ll_fwb_+l1l1ll111ll1l1ll_fwb_+l1l1111ll1l1ll_fwb_
        l111l11l1ll1l1ll_fwb_ = l1l111l11ll1l1ll_fwb_.l111l1l1ll1l1ll_fwb_(ex_link)
        for f in l111l11l1ll1l1ll_fwb_:
            l1l1lll1l1ll1l1ll_fwb_(name=f.get(l1l111ll1l1ll_fwb_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧৠ")), url=f.get(l1l111ll1l1ll_fwb_ (u"ࠩ࡫ࡶࡪ࡬ࠧৡ")), mode=l1l111ll1l1ll_fwb_ (u"ࠪ࡫ࡪࡺࡌࡪࡰ࡮ࡷࠬৢ"), l1ll11lll1ll1l1ll_fwb_=f.get(l1l111ll1l1ll_fwb_ (u"ࠫ࡮ࡳࡧࠨৣ")), infoLabels=f, IsPlayable=True,l1ll11111ll1l1ll_fwb_=len(l111l11l1ll1l1ll_fwb_))
        xbmcplugin.setContent(l1l1lll11ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࠬ৤"))
    def l111l1l11ll1l1ll_fwb_(self,ex_link):
        import resources.lib.l1ll1l1l11ll1l1ll_fwb_ as l1l111l11ll1l1ll_fwb_
        l1lllll111ll1l1ll_fwb_ = l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"࠭ࡌࡶࡦࡽ࡭ࡪࡥࡆࡪ࡮ࡰࡹ࡛࠭৥"))
        if not l1lllll111ll1l1ll_fwb_: l1lllll111ll1l1ll_fwb_ = ex_link
        l111l11l1ll1l1ll_fwb_,l1lllll1l1ll1l1ll_fwb_ = l1l111l11ll1l1ll_fwb_.l1ll1lll11ll1l1ll_fwb_(l1lllll111ll1l1ll_fwb_)
        if l1lllll1l1ll1l1ll_fwb_[0]:
            l1l1lll1l1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡨࡱ࡯ࡨࡢࡂ࠼ࠡࡲࡲࡴࡷࢀࡥࡥࡰ࡬ࡥࠥࡹࡴࡳࡱࡱࡥࠥࡂ࠼࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ০"), url=l1lllll1l1ll1l1ll_fwb_[0], mode=l1l111ll1l1ll_fwb_ (u"ࠨࡡࡢࡴࡦ࡭ࡥࡠࡡ࠽ࡶࡦࡴ࡫ࡪࡰࡪࡴࡪࡸࡳࡰࡰࡢࡷ࡭ࡵࡷࠨ১"), l111lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠩࠪ২"), IsPlayable=False)
        for f in l111l11l1ll1l1ll_fwb_:
            l1l1lll1l1ll1l1ll_fwb_(name=f.get(l1l111ll1l1ll_fwb_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ৩")), url=f.get(l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡸࡥࡧࠩ৪")), mode=l1l111ll1l1ll_fwb_ (u"ࠬࡹࡨࡰࡹࡓࡩࡴࡶ࡬ࡦࡏࡲࡺ࡮࡫ࡳࠨ৫"), l1ll11lll1ll1l1ll_fwb_=f.get(l1l111ll1l1ll_fwb_ (u"࠭ࡩ࡮ࡩࠪ৬")), infoLabels=f, IsPlayable=False,l1ll11111ll1l1ll_fwb_=len(l111l11l1ll1l1ll_fwb_))
        if l1lllll1l1ll1l1ll_fwb_[1]:
            l1l1lll1l1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡨࡱ࡯ࡨࡢࡄ࠾ࠡࡰࡤࡷࡹटࡰ࡯ࡣࠣࡷࡹࡸ࡯࡯ࡣࠣࡂࡃࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ৭"), url=l1lllll1l1ll1l1ll_fwb_[1], mode=l1l111ll1l1ll_fwb_ (u"ࠨࡡࡢࡴࡦ࡭ࡥࡠࡡ࠽ࡶࡦࡴ࡫ࡪࡰࡪࡴࡪࡸࡳࡰࡰࡢࡷ࡭ࡵࡷࠨ৮"), l111lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠩࠪ৯"), IsPlayable=False)
        xbmcplugin.setContent(l1l1lll11ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪৰ"))
    def l111lll11ll1l1ll_fwb_(self,ex_link):
        import resources.lib.l1ll1l1l11ll1l1ll_fwb_ as l1l111l11ll1l1ll_fwb_
        l111l11l1ll1l1ll_fwb_ = l1l111l11ll1l1ll_fwb_.l1111111ll1l1ll_fwb_(ex_link)
        for f in l111l11l1ll1l1ll_fwb_:
            l1l1lll1l1ll1l1ll_fwb_(name=f.get(l1l111ll1l1ll_fwb_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪৱ")), url=f.get(l1l111ll1l1ll_fwb_ (u"ࠬ࡮ࡲࡦࡨࠪ৲")), mode=l1l111ll1l1ll_fwb_ (u"࠭ࡧࡦࡶࡏ࡭ࡳࡱࡳࠨ৳"), l1ll11lll1ll1l1ll_fwb_=f.get(l1l111ll1l1ll_fwb_ (u"ࠧࡪ࡯ࡪࠫ৴")), infoLabels=f, IsPlayable=True,l1ll11111ll1l1ll_fwb_=len(l111l11l1ll1l1ll_fwb_))
    def l1l1ll1ll1ll1l1ll_fwb_(self,ex_link):
        import resources.lib.l1ll1l1l11ll1l1ll_fwb_ as l1l111l11ll1l1ll_fwb_
        l1l1ll111ll1l1ll_fwb_ = l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠨࡴࡤࡲࡰ࡯࡮ࡨࡶࡲࡴࡤ࡭ࡡࡵࡷࡱ࡯࡮࡜ࠧ৵"))
        l1111l11ll1l1ll_fwb_ = l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠩࡵࡥࡳࡱࡩ࡯ࡩࡷࡳࡵࡥ࡫ࡳࡣ࡭ࡩ࡛࠭৶"))
        l1l1111ll1l1ll_fwb_ = l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠪࡶࡦࡴ࡫ࡪࡰࡪࡸࡴࡶ࡟࡭ࡣࡷࡥ࡛࠭৷"))
        ex_link=l1l111ll1l1ll_fwb_ (u"ࠫ࠴ࡸࡡ࡯࡭࡬ࡲ࡬࠵ࡳࡦࡴ࡬ࡥࡱ࠭৸")+l1111l11ll1l1ll_fwb_+l1l1ll111ll1l1ll_fwb_+l1l1111ll1l1ll_fwb_
        l111l11l1ll1l1ll_fwb_ = l1l111l11ll1l1ll_fwb_.l111l1l1ll1l1ll_fwb_(ex_link)
        for f in l111l11l1ll1l1ll_fwb_:
            l1l1lll1l1ll1l1ll_fwb_(name=f.get(l1l111ll1l1ll_fwb_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ৹")), url=f.get(l1l111ll1l1ll_fwb_ (u"࠭ࡨࡳࡧࡩࠫ৺")), mode=l1l111ll1l1ll_fwb_ (u"ࠧࡨࡧࡷࡗࡪࡧࡳࡰࡰࡶࠫ৻"), l1ll11lll1ll1l1ll_fwb_=f.get(l1l111ll1l1ll_fwb_ (u"ࠨ࡫ࡰ࡫ࠬৼ")), infoLabels=f, IsPlayable=True,l1ll11111ll1l1ll_fwb_=len(l111l11l1ll1l1ll_fwb_))
        xbmcplugin.setContent(l1l1lll11ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠩࡷࡺࡸ࡮࡯ࡸࡵࠪ৽"))
    def l1ll111111ll1l1ll_fwb_(self):
        l11l111ll1l1ll_fwb_ = self.l1l1ll11ll1l1ll_fwb_()
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠥ࡟ࡈࡕࡌࡐࡔࠣࡰ࡮࡭ࡨࡵࡤ࡯ࡹࡪࡣࡋࡳࡣ࡭ࡩ࠿ࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࡜ࡄࡠࠦ৾")+l11l111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠫࡧࡵࡸࡰࡨࡩ࡭ࡨ࡫࡟࡬ࡴࡤ࡮ࡪࡔࠧ৿"),l1l111ll1l1ll_fwb_ (u"ࠬ࠭਀"))+l1l111ll1l1ll_fwb_ (u"ࠨ࡛࠰ࡄࡠࠦਁ"),l1l111ll1l1ll_fwb_ (u"ࠧࠨਂ"),mode=l1l111ll1l1ll_fwb_ (u"ࠨࡵࡨࡰࡪࡩࡴ࠻ࡤࡲࡼࡴ࡬ࡦࡪࡥࡨࡣࡰࡸࡡ࡫ࡧࠪਃ"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠩࠪ਄"),IsPlayable=False)
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠥ࡟ࡈࡕࡌࡐࡔࠣࡰ࡮࡭ࡨࡵࡤ࡯ࡹࡪࡣࡇࡢࡶࡸࡲࡰ࡯࠺࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࡞ࡆࡢࠨਅ")+l11l111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠫࡧࡵࡸࡰࡨࡩ࡭ࡨ࡫࡟ࡨࡣࡷࡹࡳࡱࡩࡏࠩਆ"),l1l111ll1l1ll_fwb_ (u"ࠬ࠭ਇ"))+l1l111ll1l1ll_fwb_ (u"ࠨ࡛࠰ࡄࡠࠦਈ"),l1l111ll1l1ll_fwb_ (u"ࠧࠨਉ"),mode=l1l111ll1l1ll_fwb_ (u"ࠨࡵࡨࡰࡪࡩࡴ࠻ࡤࡲࡼࡴ࡬ࡦࡪࡥࡨࡣ࡬ࡧࡴࡶࡰ࡮࡭ࠬਊ"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠩࠪ਋"),IsPlayable=False)
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠥ࡟ࡈࡕࡌࡐࡔࠣࡰ࡮࡭ࡨࡵࡤ࡯ࡹࡪࡣࡌࡢࡶࡤ࠾ࡠ࠵ࡃࡐࡎࡒࡖࡢ࡛ࠦࡃ࡟ࠥ਌")+l11l111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠫࡧࡵࡸࡰࡨࡩ࡭ࡨ࡫࡟࡭ࡣࡷࡥࡓ࠭਍"),l1l111ll1l1ll_fwb_ (u"ࠬ࠭਎"))+l1l111ll1l1ll_fwb_ (u"ࠨ࡛࠰ࡄࡠࠦਏ"),l1l111ll1l1ll_fwb_ (u"ࠧࠨਐ"),mode=l1l111ll1l1ll_fwb_ (u"ࠨࡵࡨࡰࡪࡩࡴ࠻ࡤࡲࡼࡴ࡬ࡦࡪࡥࡨࡣࡱࡧࡴࡢࠩ਑"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠩࠪ਒"),IsPlayable=False)
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠥࠤࠥࡡࡃࡐࡎࡒࡖࠥࡨ࡬ࡶࡧࡠࡆࡴࡾࠠࡐࡨࡩ࡭ࡨ࡫࡛࠰ࡅࡒࡐࡔࡘ࡝ࠣਓ"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠫࠬਔ"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠬࡨ࡯ࡹࡱࡩࡪ࡮ࡩࡥࡠࡵ࡫ࡳࡼ࠭ਕ"),iconImage=l1l111ll1l1ll_fwb_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࠪਖ"),fanart=l1l1l1l111ll1l1ll_fwb_)
    def l1l1ll11ll1l1ll_fwb_(self):
        d = {}
        d.update(_1l11ll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠧࡣࡱࡻࡳ࡫࡬ࡩࡤࡧࡢ࡯ࡷࡧࡪࡦࠩਗ"),l1l111ll1l1ll_fwb_ (u"ࠨ࡙ࡶࡾࡾࡹࡴ࡬࡫ࡨࠫਘ")))
        d.update(_1l11ll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠩࡥࡳࡽࡵࡦࡧ࡫ࡦࡩࡤ࡭ࡡࡵࡷࡱ࡯࡮࠭ਙ"),l1l111ll1l1ll_fwb_ (u"࡛ࠪࡸࢀࡹࡴࡶ࡮࡭ࡪ࠭ਚ")))
        d.update(_1l11ll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠫࡧࡵࡸࡰࡨࡩ࡭ࡨ࡫࡟࡭ࡣࡷࡥࠬਛ"),l1l111ll1l1ll_fwb_ (u"ࠬ࡝ࡳࡻࡻࡶࡸࡰ࡯ࡥࠨਜ")))
        return d
    def l1l11lll1ll1l1ll_fwb_(self,ex_link):
        import resources.lib.l1ll1l1l11ll1l1ll_fwb_ as l1l111l11ll1l1ll_fwb_
        l1l1ll111ll1l1ll_fwb_ = l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"࠭ࡢࡰࡺࡲࡪ࡫࡯ࡣࡦࡡࡪࡥࡹࡻ࡮࡬࡫࡙ࠫਝ"))
        l1111l11ll1l1ll_fwb_ = l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠧࡣࡱࡻࡳ࡫࡬ࡩࡤࡧࡢ࡯ࡷࡧࡪࡦࡘࠪਞ"))
        l1l1111ll1l1ll_fwb_ = l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠨࡤࡲࡼࡴ࡬ࡦࡪࡥࡨࡣࡱࡧࡴࡢࡘࠪਟ"))
        ex_link=l1l111ll1l1ll_fwb_ (u"ࠩ࠲ࡶࡦࡴ࡫ࡪࡰࡪ࠳ࡧࡵࡸࡐࡨࡩ࡭ࡨ࡫ࠧਠ")+l1111l11ll1l1ll_fwb_+l1l1ll111ll1l1ll_fwb_+l1l1111ll1l1ll_fwb_
        l111l11l1ll1l1ll_fwb_ = l1l111l11ll1l1ll_fwb_.l111l1l1ll1l1ll_fwb_(ex_link)
        for f in l111l11l1ll1l1ll_fwb_:
            l1l1lll1l1ll1l1ll_fwb_(name=f.get(l1l111ll1l1ll_fwb_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩਡ")), url=f.get(l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡸࡥࡧࠩਢ")), mode=l1l111ll1l1ll_fwb_ (u"ࠬ࡭ࡥࡵࡎ࡬ࡲࡰࡹࠧਣ"), l1ll11lll1ll1l1ll_fwb_=f.get(l1l111ll1l1ll_fwb_ (u"࠭ࡩ࡮ࡩࠪਤ")), infoLabels=f, IsPlayable=True,l1ll11111ll1l1ll_fwb_=len(l111l11l1ll1l1ll_fwb_))
        xbmcplugin.setContent(l1l1lll11ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧਥ"))
    def l111111ll1l1ll_fwb_(self):
        d = {}
        d.update(_1l11ll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠨࡤࡤࡾࡦ࡬ࡩ࡭࡯ࡲࡻࡤࡹ࡯ࡳࡶࠪਦ"),l1l111ll1l1ll_fwb_ (u"ࠩ࡯࡭ࡨࢀࡢࡺࠢࡪॆࡴࡹࣳࡸࠩਧ")))
        d.update(_1l11ll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠪࡦࡦࢀࡡࡧ࡫࡯ࡱࡴࡽ࡟ࡴࡱࡵࡸࡆࡹࡣࡦࡰࡧ࡭ࡳ࡭ࠧਨ"),l1l111ll1l1ll_fwb_ (u"ࠫࡴࡪࠠ࡯ࡣ࡭ࡻ࡮ट࡫ࡴࡼࡨ࡮ࠬ਩")))
        d.update(_1l11ll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠬࡨࡡࡻࡣࡩ࡭ࡱࡳ࡯ࡸࡡࡧࡥࡹࡧࡐࡳࡱࡧࡹࡰࡩࡪࡪࠩਪ"),l1l111ll1l1ll_fwb_ (u"࠭࡫ࡪࡧࡧࡽࡰࡵ࡬ࡸ࡫ࡨ࡯ࠬਫ")))
        d.update(_1l11ll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠧࡣࡣࡽࡥ࡫࡯࡬࡮ࡱࡺࡣࡔࡩࡥ࡯ࡣࠪਬ"),l1l111ll1l1ll_fwb_ (u"ࠨࡤࡵࡥࡰ࠭ਭ")))
        d.update(_1l11ll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠩࡥࡥࡿࡧࡦࡪ࡮ࡰࡳࡼࡥࡧࡦࡰࡵࡩࡎࡪࡳࠨਮ"),l1l111ll1l1ll_fwb_ (u"ࠪࡻࡸࢀࡹࡴࡶ࡮࡭ࡪ࠭ਯ")))
        d.update(_1l11ll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠫࡧࡧࡺࡢࡨ࡬ࡰࡲࡵࡷࡠࡩࡨࡲࡷ࡫ࡔࡗࡵ࡫ࡳࡼࡹࠧਰ"),l1l111ll1l1ll_fwb_ (u"ࠬࡽࡳࡻࡻࡶࡸࡰ࡯ࡥࠨ਱")))
        d.update(_1l11ll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"࠭ࡢࡢࡼࡤࡪ࡮ࡲ࡭ࡰࡹࡢࡧࡴࡻ࡮ࡵࡴࡼࡍࡩࡹࠧਲ"),l1l111ll1l1ll_fwb_ (u"ࠧࡸࡵࡽࡽࡸࡺ࡫ࡪࡧࠪਲ਼")))
        return d
    def l1ll1ll1l1ll1l1ll_fwb_(self):
        d={l1l111ll1l1ll_fwb_ (u"ࠨࡤࡤࡾࡦ࡬ࡩ࡭࡯ࡲࡻࡤ࡭ࡥ࡯ࡴࡨࡘ࡛ࡹࡨࡰࡹࡶࡒࠬ਴"):l1l111ll1l1ll_fwb_ (u"ࠩࡺࡷࡿࡿࡳࡵ࡭࡬ࡩࠬਵ"),l1l111ll1l1ll_fwb_ (u"ࠪࡦࡦࢀࡡࡧ࡫࡯ࡱࡴࡽ࡟ࡨࡧࡱࡶࡪ࡚ࡖࡴࡪࡲࡻࡸ࡜ࠧਸ਼"):l1l111ll1l1ll_fwb_ (u"ࠫࠬ਷"),l1l111ll1l1ll_fwb_ (u"ࠬࡨࡡࡻࡣࡩ࡭ࡱࡳ࡯ࡸࡡࡪࡩࡳࡸࡥࡊࡦࡶࡒࠬਸ"): l1l111ll1l1ll_fwb_ (u"࠭ࡷࡴࡼࡼࡷࡹࡱࡩࡦࠩਹ"), l1l111ll1l1ll_fwb_ (u"ࠧࡣࡣࡽࡥ࡫࡯࡬࡮ࡱࡺࡣࡸࡵࡲࡵࡃࡶࡧࡪࡴࡤࡪࡰࡪ࡚ࠬ਺"): l1l111ll1l1ll_fwb_ (u"ࠨࡶࡵࡹࡪ࠭਻"), l1l111ll1l1ll_fwb_ (u"ࠩࡥࡥࡿࡧࡦࡪ࡮ࡰࡳࡼࡥࡏࡤࡧࡱࡥࡓ਼࠭"): l1l111ll1l1ll_fwb_ (u"ࠪࡦࡷࡧ࡫ࠨ਽"), l1l111ll1l1ll_fwb_ (u"ࠫࡧࡧࡺࡢࡨ࡬ࡰࡲࡵࡷࡠࡥࡲࡹࡳࡺࡲࡺࡋࡧࡷ࡛࠭ਾ"): l1l111ll1l1ll_fwb_ (u"ࠬ࠭ਿ"), l1l111ll1l1ll_fwb_ (u"࠭ࡢࡢࡼࡤࡪ࡮ࡲ࡭ࡰࡹࡢࡷࡴࡸࡴࡗࠩੀ"): l1l111ll1l1ll_fwb_ (u"ࠧࡤࡱࡸࡲࡹ࠭ੁ"), l1l111ll1l1ll_fwb_ (u"ࠨࡤࡤࡾࡦ࡬ࡩ࡭࡯ࡲࡻࡤࡪࡡࡵࡣࡓࡶࡴࡪࡵ࡬ࡥ࡭࡭࡛࠭ੂ"): l1l111ll1l1ll_fwb_ (u"ࠩࠪ੃"), l1l111ll1l1ll_fwb_ (u"ࠪࡦࡦࢀࡡࡧ࡫࡯ࡱࡴࡽ࡟ࡨࡧࡱࡶࡪࡏࡤࡴࡘࠪ੄"): l1l111ll1l1ll_fwb_ (u"ࠫࠬ੅"), l1l111ll1l1ll_fwb_ (u"ࠬࡨࡡࡻࡣࡩ࡭ࡱࡳ࡯ࡸࡡࡶࡳࡷࡺࡁࡴࡥࡨࡲࡩ࡯࡮ࡨࡐࠪ੆"): l1l111ll1l1ll_fwb_ (u"࠭࡯ࡥࠢࡱࡥ࡯ࡽࡩ࡝ࡺࡦ࠸ࡡࡾ࠹࠺࡭ࡶࡾࡪࡰࠧੇ"), l1l111ll1l1ll_fwb_ (u"ࠧࡣࡣࡽࡥ࡫࡯࡬࡮ࡱࡺࡣࡸࡵࡲࡵࡐࠪੈ"): l1l111ll1l1ll_fwb_ (u"ࠨ࡮࡬ࡧࡿࡨࡹࠡࡩ࡟ࡼࡨ࠻࡜ࡹ࠺࠵ࡳࡸࡢࡸࡤ࠵࡟ࡼࡧ࠹ࡷࠨ੉"), l1l111ll1l1ll_fwb_ (u"ࠩࡥࡥࡿࡧࡦࡪ࡮ࡰࡳࡼࡥࡏࡤࡧࡱࡥ࡛࠭੊"): l1l111ll1l1ll_fwb_ (u"ࠪࠫੋ"), l1l111ll1l1ll_fwb_ (u"ࠫࡧࡧࡺࡢࡨ࡬ࡰࡲࡵࡷࡠࡥࡲࡹࡳࡺࡲࡺࡋࡧࡷࡓ࠭ੌ"): l1l111ll1l1ll_fwb_ (u"ࠬࡽࡳࡻࡻࡶࡸࡰ࡯ࡥࠨ੍"), l1l111ll1l1ll_fwb_ (u"࠭ࡢࡢࡼࡤࡪ࡮ࡲ࡭ࡰࡹࡢࡨࡦࡺࡡࡑࡴࡲࡨࡺࡱࡣ࡫࡫ࡑࠫ੎"): l1l111ll1l1ll_fwb_ (u"ࠧ࡬࡫ࡨࡨࡾࡱ࡯࡭ࡹ࡬ࡩࡰ࠭੏")}
        for k,v in d.items(): l1ll1ll11ll1l1ll_fwb_.setSetting(k,v)
        xbmc.executebuiltin(l1l111ll1l1ll_fwb_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ੐"))
    def l1l1l1l1l1ll1l1ll_fwb_(self):
        l11l111ll1l1ll_fwb_ = self.l111111ll1l1ll_fwb_()
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠤࡇࡳࡲࡿज़࡭ࡰࡨࠤ࡚ࡹࡴࡢࡹ࡬ࡩࡳ࡯ࡡࠣੑ"),l1l111ll1l1ll_fwb_ (u"ࠪࠫ੒"),mode=l1l111ll1l1ll_fwb_ (u"ࠫࡧࡧࡺࡢࡨ࡬ࡰࡲࡵࡷࡠࡵࡨࡸࡹ࡯࡮ࡨࡵࡢࡷࡪࡺࡤࡦࡨࡤࡹࡱࡺࠧ੓"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠬ࠭੔"),IsPlayable=False)
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠨ࡛ࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸࡧࡲࡵࡦ࡟ࡖࡳࡷࡺ࡯ࡸࡣࡱ࡭ࡪࡀ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠡ࡝ࡅࡡࠧ੕")+l11l111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠧࡣࡣࡽࡥ࡫࡯࡬࡮ࡱࡺࡣࡸࡵࡲࡵࡐࠪ੖"),l1l111ll1l1ll_fwb_ (u"ࠨࠩ੗"))+l1l111ll1l1ll_fwb_ (u"ࠤ࡞࠳ࡇࡣࠢ੘"),l1l111ll1l1ll_fwb_ (u"ࠪࠫਖ਼"),mode=l1l111ll1l1ll_fwb_ (u"ࠫࡸ࡫࡬ࡦࡥࡷ࠾ࡧࡧࡺࡢࡨ࡬ࡰࡲࡵࡷࡠࡵࡲࡶࡹ࠭ਗ਼"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠬ࠭ਜ਼"),IsPlayable=False)
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠨ࡛ࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸࡧࡲࡵࡦ࡟ࡎࡳࡱ࡫ࡪ࡯ࡱफ़ऋ࠿ࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࡜ࡄࡠࠦੜ")+l11l111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠧࡣࡣࡽࡥ࡫࡯࡬࡮ࡱࡺࡣࡸࡵࡲࡵࡃࡶࡧࡪࡴࡤࡪࡰࡪࡒࠬ੝"),l1l111ll1l1ll_fwb_ (u"ࠨࠩਫ਼"))+l1l111ll1l1ll_fwb_ (u"ࠤ࡞࠳ࡇࡣࠢ੟"),l1l111ll1l1ll_fwb_ (u"ࠪࠫ੠"),mode=l1l111ll1l1ll_fwb_ (u"ࠫࡸ࡫࡬ࡦࡥࡷ࠾ࡧࡧࡺࡢࡨ࡬ࡰࡲࡵࡷࡠࡵࡲࡶࡹࡇࡳࡤࡧࡱࡨ࡮ࡴࡧࠨ੡"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠬ࠭੢"),IsPlayable=False)
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠨ࡛ࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸࡧࡲࡵࡦ࡟ࡇࡥࡹࡧࠠࡑࡴࡲࡨࡺࡱࡣ࡫࡫࠽࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡡࡂ࡞ࠤ੣")+l11l111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠧࡣࡣࡽࡥ࡫࡯࡬࡮ࡱࡺࡣࡩࡧࡴࡢࡒࡵࡳࡩࡻ࡫ࡤ࡬࡬ࡒࠬ੤"),l1l111ll1l1ll_fwb_ (u"ࠨࠩ੥"))+l1l111ll1l1ll_fwb_ (u"ࠤ࡞࠳ࡇࡣࠢ੦"),l1l111ll1l1ll_fwb_ (u"ࠪࠫ੧"),mode=l1l111ll1l1ll_fwb_ (u"ࠫࡸ࡫࡬ࡦࡥࡷ࠾ࡧࡧࡺࡢࡨ࡬ࡰࡲࡵࡷࡠࡦࡤࡸࡦࡖࡲࡰࡦࡸ࡯ࡨࡰࡩࠨ੨"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠬ࠭੩"),IsPlayable=False)
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠨ࡛ࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸࡧࡲࡵࡦ࡟ࡐ࡭ࡳ࡯࡭ࡢ࡮ࡱࡥࠥࡕࡣࡦࡰࡤ࠾ࡠ࠵ࡃࡐࡎࡒࡖࡢ࡛ࠦࡃ࡟ࠥ੪")+l11l111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠧࡣࡣࡽࡥ࡫࡯࡬࡮ࡱࡺࡣࡔࡩࡥ࡯ࡣࡑࠫ੫"),l1l111ll1l1ll_fwb_ (u"ࠨࠩ੬"))+l1l111ll1l1ll_fwb_ (u"ࠤ࡞࠳ࡇࡣࠢ੭"),l1l111ll1l1ll_fwb_ (u"ࠪࠫ੮"),mode=l1l111ll1l1ll_fwb_ (u"ࠫࡸ࡫࡬ࡦࡥࡷ࠾ࡧࡧࡺࡢࡨ࡬ࡰࡲࡵࡷࡠࡑࡦࡩࡳࡧࠧ੯"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠬ࠭ੰ"),IsPlayable=False)
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠨ࡛ࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸࡧࡲࡵࡦ࡟ࡊࡥࡹࡻ࡮ࡦ࡭࠽࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡡࡂ࡞ࠤੱ")+l11l111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠧࡣࡣࡽࡥ࡫࡯࡬࡮ࡱࡺࡣ࡬࡫࡮ࡳࡧࡌࡨࡸࡔࠧੲ"),l1l111ll1l1ll_fwb_ (u"ࠨࠩੳ"))+l1l111ll1l1ll_fwb_ (u"ࠤ࡞࠳ࡇࡣࠢੴ"),l1l111ll1l1ll_fwb_ (u"ࠪࠫੵ"),mode=l1l111ll1l1ll_fwb_ (u"ࠫࡲࡻ࡬ࡵ࡫ࡶࡩࡱ࡫ࡣࡵ࠼ࡥࡥࡿࡧࡦࡪ࡮ࡰࡳࡼࡥࡧࡦࡰࡵࡩࡎࡪࡳࠨ੶"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠬ࠭੷"),IsPlayable=False)
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠨ࡛ࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸࡧࡲࡵࡦ࡟ࡎࡶࡦࡰ࠺࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࡞ࡆࡢࠨ੸")+l11l111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠧࡣࡣࡽࡥ࡫࡯࡬࡮ࡱࡺࡣࡨࡵࡵ࡯ࡶࡵࡽࡎࡪࡳࡏࠩ੹"),l1l111ll1l1ll_fwb_ (u"ࠨࠩ੺"))+l1l111ll1l1ll_fwb_ (u"ࠤ࡞࠳ࡇࡣࠢ੻"),l1l111ll1l1ll_fwb_ (u"ࠪࠫ੼"),mode=l1l111ll1l1ll_fwb_ (u"ࠫࡲࡻ࡬ࡵ࡫ࡶࡩࡱ࡫ࡣࡵ࠼ࡥࡥࡿࡧࡦࡪ࡮ࡰࡳࡼࡥࡣࡰࡷࡱࡸࡷࡿࡉࡥࡵࠪ੽"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠬ࠭੾"),IsPlayable=False)
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠨࠠࠡ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣࡆࡪ࡮ࡰࡽࡠ࠵ࡃࡐࡎࡒࡖࡢࠨ੿"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲࡫࡯࡬࡮ࡹࡨࡦ࠳ࡶ࡬࠰ࡨ࡬ࡰࡲࡹ࠯ࡴࡧࡤࡶࡨ࡮ࠧ઀"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠨࡤࡤࡾࡦ࡬ࡩ࡭࡯ࡲࡻࡤࡹࡨࡰࡹࠪઁ"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬࠭ં"),fanart=l1l1l1l111ll1l1ll_fwb_)
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠥࠤࠥࡡࡃࡐࡎࡒࡖࠥࡨ࡬ࡶࡧࡠࡗࡪࡸࡩࡢ࡮ࡨ࡟࠴ࡉࡏࡍࡑࡕࡡࠧઃ"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡨ࡬ࡰࡲࡽࡥࡣ࠰ࡳࡰ࠴ࡹࡥࡳ࡫ࡤࡰࡸ࠵ࡳࡦࡣࡵࡧ࡭࠭઄"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠬࡨࡡࡻࡣࡩ࡭ࡱࡳ࡯ࡸࡡࡶ࡬ࡴࡽࠧઅ"),iconImage=l1l111ll1l1ll_fwb_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࠪઆ"),fanart=l1l1l1l111ll1l1ll_fwb_)
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠢ࡜ࡅࡒࡐࡔࡘࠠ࡭࡫ࡪ࡬ࡹࡨ࡬ࡶࡧࡠࡋࡦࡺࡵ࡯ࡧ࡮ࠤ࡙࡜࠺࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࡞ࡆࡢࠨઇ")+l11l111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠨࡤࡤࡾࡦ࡬ࡩ࡭࡯ࡲࡻࡤ࡭ࡥ࡯ࡴࡨࡘ࡛ࡹࡨࡰࡹࡶࡒࠬઈ"),l1l111ll1l1ll_fwb_ (u"ࠩࠪઉ"))+l1l111ll1l1ll_fwb_ (u"ࠥ࡟࠴ࡈ࡝ࠣઊ"),l1l111ll1l1ll_fwb_ (u"ࠫࠬઋ"),mode=l1l111ll1l1ll_fwb_ (u"ࠬࡳࡵ࡭ࡶ࡬ࡷࡪࡲࡥࡤࡶ࠽ࡦࡦࢀࡡࡧ࡫࡯ࡱࡴࡽ࡟ࡨࡧࡱࡶࡪ࡚ࡖࡴࡪࡲࡻࡸ࠭ઌ"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"࠭ࠧઍ"),IsPlayable=False)
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠢࠡࠢ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࡑࡴࡲ࡫ࡷࡧ࡭ࡺࠢࡗ࡚ࡠ࠵ࡃࡐࡎࡒࡖࡢࠨ઎"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡬ࡩ࡭࡯ࡺࡩࡧ࠴ࡰ࡭࠱ࡷࡺࡸ࡮࡯ࡸࡵ࠲ࡷࡪࡧࡲࡤࡪࠪએ"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠩࡥࡥࡿࡧࡦࡪ࡮ࡰࡳࡼࡥࡳࡩࡱࡺࠫઐ"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧઑ"),fanart=l1l1l1l111ll1l1ll_fwb_)
    def l1l1l11l11ll1l1ll_fwb_(self,ex_link,l111lll1ll1l1ll_fwb_):
        l111lll1ll1l1ll_fwb_=int(l111lll1ll1l1ll_fwb_)
        import resources.lib.l1ll1l1l11ll1l1ll_fwb_ as l1l111l11ll1l1ll_fwb_
        l1lll1111ll1l1ll_fwb_ = l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠫࡧࡧࡺࡢࡨ࡬ࡰࡲࡵࡷࡠࡦࡤࡸࡦࡖࡲࡰࡦࡸ࡯ࡨࡰࡩࡗࠩ઒"))
        l1lll1111ll1l1ll_fwb_ = int(l1lll1111ll1l1ll_fwb_) if l1lll1111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠬ࠭ઓ")
        l1lll111ll1l1ll_fwb_ = l1lll1111ll1l1ll_fwb_+9 if l1lll1111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"࠭ࠧઔ")
        if l1l111ll1l1ll_fwb_ (u"ࠧࡵࡸࡶ࡬ࡴࡽࡳࠨક") in ex_link:
            l1l1l11ll1l1ll_fwb_ = l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠨࡤࡤࡾࡦ࡬ࡩ࡭࡯ࡲࡻࡤ࡭ࡥ࡯ࡴࡨࡘ࡛ࡹࡨࡰࡹࡶ࡚ࠬખ"))
            l1l11l1l1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠩࡷࡺࡸ࡮࡯ࡸࡉࡨࡲࡷ࡫ࡳࠨગ")
        else:
             l1l1l11ll1l1ll_fwb_ = l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠪࡦࡦࢀࡡࡧ࡫࡯ࡱࡴࡽ࡟ࡨࡧࡱࡶࡪࡏࡤࡴࡘࠪઘ"))
             l1l11l1l1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠫ࡬࡫࡮ࡳࡧࡶࠫઙ")
        l1l111111ll1l1ll_fwb_={
            l1l111ll1l1ll_fwb_ (u"ࠬࡹࡴࡢࡴࡷ࡝ࡪࡧࡲࠨચ"):l1lll1111ll1l1ll_fwb_,
            l1l111ll1l1ll_fwb_ (u"࠭ࡥ࡯ࡦ࡜ࡩࡦࡸࠧછ"):l1lll111ll1l1ll_fwb_,
            l1l111ll1l1ll_fwb_ (u"ࠧࡤࡱࡸࡲࡹࡸࡩࡦࡵࠪજ"):l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠨࡤࡤࡾࡦ࡬ࡩ࡭࡯ࡲࡻࡤࡩ࡯ࡶࡰࡷࡶࡾࡏࡤࡴࡘࠪઝ")),
            l1l11l1l1ll1l1ll_fwb_:l1l1l11ll1l1ll_fwb_,
            l1l111ll1l1ll_fwb_ (u"ࠩࡲࡶࡩ࡫ࡲࡃࡻࠪઞ"):l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠪࡦࡦࢀࡡࡧ࡫࡯ࡱࡴࡽ࡟ࡴࡱࡵࡸ࡛࠭ટ")) ,
            l1l111ll1l1ll_fwb_ (u"ࠫࡩ࡫ࡳࡤࡧࡱࡨ࡮ࡴࡧࠨઠ"):l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠬࡨࡡࡻࡣࡩ࡭ࡱࡳ࡯ࡸࡡࡶࡳࡷࡺࡁࡴࡥࡨࡲࡩ࡯࡮ࡨࡘࠪડ")),
            l1l111ll1l1ll_fwb_ (u"࠭ࡰࡢࡩࡨࠫઢ"):l111lll1ll1l1ll_fwb_
            }
        url = ex_link+l1l111ll1l1ll_fwb_ (u"ࠧࡀࠩણ")+urllib.urlencode(l1l111111ll1l1ll_fwb_)
        l111l11l1ll1l1ll_fwb_ = l1l111l11ll1l1ll_fwb_.l1l1lll1ll1l1ll_fwb_(url)
        l1l1l1111ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠨࡡࡢࡴࡦ࡭ࡥࡠࡡ࠽ࡦࡦࢀࡡࡧ࡫࡯ࡱࡴࡽ࡟ࡴࡪࡲࡻࠬત")
        l111ll111ll1l1ll_fwb_ =l1l111ll1l1ll_fwb_ (u"ࠩࡪࡩࡹࡒࡩ࡯࡭ࡶࠫથ")
        xbmcplugin.setContent(l1l1lll11ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠪࡱࡴࡼࡩࡦࡵࠪદ"))
        if l1l111ll1l1ll_fwb_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡤࡰࡸ࠭ધ") in ex_link or l1l111ll1l1ll_fwb_ (u"ࠬ࠵ࡴࡷࡵ࡫ࡳࡼࡹࠧન") in ex_link:
            l111ll111ll1l1ll_fwb_ =l1l111ll1l1ll_fwb_ (u"࠭ࡧࡦࡶࡖࡩࡦࡹ࡯࡯ࡵࠪ઩")
            xbmcplugin.setContent(l1l1lll11ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠧࡵࡸࡶ࡬ࡴࡽࡳࠨપ"))
        if l111lll1ll1l1ll_fwb_>1:
            l1l1lll1l1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡩࡲࡰࡩࡣ࠼࠽ࠢࡳࡳࡵࡸࡺࡦࡦࡱ࡭ࡦࠦࡳࡵࡴࡲࡲࡦࠦ࠼࠽࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪફ"), url=ex_link, mode=l1l1l1111ll1l1ll_fwb_, l111lll1ll1l1ll_fwb_=l111lll1ll1l1ll_fwb_-1, IsPlayable=False)
        items=len(l111l11l1ll1l1ll_fwb_)
        for f in l111l11l1ll1l1ll_fwb_:
            l1l1lll1l1ll1l1ll_fwb_(name=f.get(l1l111ll1l1ll_fwb_ (u"ࠩࡷ࡭ࡹࡲࡥࠨબ")), url=f.get(l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡷ࡫ࡦࠨભ")), mode=l111ll111ll1l1ll_fwb_, l1ll11lll1ll1l1ll_fwb_=f.get(l1l111ll1l1ll_fwb_ (u"ࠫ࡮ࡳࡧࠨમ")), infoLabels=f, IsPlayable=True,l1ll11111ll1l1ll_fwb_=items)
        if len(l111l11l1ll1l1ll_fwb_)>5:
            l1l1lll1l1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࡭࡯࡭ࡦࡠࡂࡃࠦ࡮ࡢࡵࡷझࡵࡴࡡࠡࡵࡷࡶࡴࡴࡡࠡࡀࡁ࡟࠴ࡉࡏࡍࡑࡕࡡࠬય"), url=ex_link, mode=l1l1l1111ll1l1ll_fwb_, l111lll1ll1l1ll_fwb_=l111lll1ll1l1ll_fwb_+1, IsPlayable=False)
    def l11ll1l11ll1l1ll_fwb_(self):
        d = {}
        d.update(_1l11ll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"࠭ࡢࡢࡼࡤࡓࡸࡵࡢࡠࡵࡲࡶࡹ࠭ર"),l1l111ll1l1ll_fwb_ (u"ࠧࡱࡱࡳࡹࡱࡧࡲ࡯ࡱफ़ऋࠬ઱")))
        d.update(_1l11ll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠨࡤࡤࡾࡦࡕࡳࡰࡤࡢࡷࡴࡸࡴࡂࡵࡦࡩࡳࡪࡩ࡯ࡩࠪલ"),l1l111ll1l1ll_fwb_ (u"ࠩࡲࡨࠥࡴࡡ࡫ࡹ࡬झࡰࡹࡺࡦ࡬ࠪળ")))
        d.update(_1l11ll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠪࡦࡦࢀࡡࡐࡵࡲࡦࡤࡶ࡬ࡦࡥࠪ઴"),l1l111ll1l1ll_fwb_ (u"ࠫࡩࡵࡷࡰ࡮ࡱࡥࠥࡶूࡦउࠪવ")))
        d.update(_1l11ll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠬࡨࡡࡻࡣࡒࡷࡴࡨ࡟ࡻࡣࡺࡳࡩ࠭શ"),l1l111ll1l1ll_fwb_ (u"࠭ࡤࡰࡹࡲࡰࡳࡿࠧષ")))
        d.update(_1l11ll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠧࡣࡣࡽࡥࡔࡹ࡯ࡣࡡࡦࡳࡺࡴࡴࡳࡻࠪસ"),l1l111ll1l1ll_fwb_ (u"ࠨࡹࡶࡾࡾࡹࡴ࡬࡫ࡨࠫહ")))
        d.update(_1l11ll11ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠩࡥࡥࡿࡧࡏࡴࡱࡥࡣࡩࡧࡴࡢࡗࡵࡳࡩࢀࡥ࡯࡫ࡤࠫ઺"),l1l111ll1l1ll_fwb_ (u"ࠪࡻࡸࢀࡹࡴࡶ࡮࡭ࡪࠦ࡬ࡢࡶࡤࠫ઻")))
        return d
    def l11l1l1ll1l1ll_fwb_(self):
        d={l1l111ll1l1ll_fwb_ (u"ࠫࡧࡧࡺࡢࡑࡶࡳࡧࡥࡤࡢࡶࡤ࡙ࡷࡵࡤࡻࡧࡱ࡭ࡦࡔ઼ࠧ"):l1l111ll1l1ll_fwb_ (u"ࠬࡽࡳࡻࡻࡶࡸࡰ࡯ࡥࠡ࡮ࡤࡸࡦ࠭ઽ"),l1l111ll1l1ll_fwb_ (u"࠭ࡢࡢࡼࡤࡓࡸࡵࡢࡠࡦࡤࡸࡦ࡛ࡲࡰࡦࡽࡩࡳ࡯ࡡࡗࠩા"):l1l111ll1l1ll_fwb_ (u"ࠧࠨિ"),
            l1l111ll1l1ll_fwb_ (u"ࠨࡤࡤࡾࡦࡕࡳࡰࡤࡢࡾࡦࡽ࡯ࡥࡐࠪી"):l1l111ll1l1ll_fwb_ (u"ࠩࡧࡳࡼࡵ࡬࡯ࡻࠪુ"),l1l111ll1l1ll_fwb_ (u"ࠪࡦࡦࢀࡡࡐࡵࡲࡦࡤࢀࡡࡸࡱࡧ࡚ࠬૂ"):l1l111ll1l1ll_fwb_ (u"ࠫࠬૃ"),
            l1l111ll1l1ll_fwb_ (u"ࠬࡨࡡࡻࡣࡒࡷࡴࡨ࡟ࡱ࡮ࡨࡧࡓ࠭ૄ"):l1l111ll1l1ll_fwb_ (u"࠭ࡤࡰࡹࡲࡰࡳࡧࠠࡱॄࡨऋࠬૅ"),l1l111ll1l1ll_fwb_ (u"ࠧࡣࡣࡽࡥࡔࡹ࡯ࡣࡡࡳࡰࡪࡩࡖࠨ૆"):l1l111ll1l1ll_fwb_ (u"ࠨࠩે"),
            l1l111ll1l1ll_fwb_ (u"ࠩࡥࡥࡿࡧࡏࡴࡱࡥࡣࡸࡵࡲࡵࡃࡶࡧࡪࡴࡤࡪࡰࡪࠫૈ"):l1l111ll1l1ll_fwb_ (u"ࠪࡳࡩࠦ࡮ࡢ࡬ࡺ࡭ञࡱࡳࡻࡧ࡭ࠫૉ"),l1l111ll1l1ll_fwb_ (u"ࠫࡧࡧࡺࡢࡑࡶࡳࡧࡥࡳࡰࡴࡷࡅࡸࡩࡥ࡯ࡦ࡬ࡲ࡬࡜ࠧ૊"): l1l111ll1l1ll_fwb_ (u"ࠬࡺࡲࡶࡧࠪો"),
            l1l111ll1l1ll_fwb_ (u"࠭ࡢࡢࡼࡤࡓࡸࡵࡢࡠࡵࡲࡶࡹࡔࠧૌ"): l1l111ll1l1ll_fwb_ (u"ࠧࡱࡱࡳࡹࡱࡧࡲ࡯ࡱफ़ऋ્ࠬ"),l1l111ll1l1ll_fwb_ (u"ࠨࡤࡤࡾࡦࡕࡳࡰࡤࡢࡷࡴࡸࡴࡗࠩ૎"): l1l111ll1l1ll_fwb_ (u"ࠩࡳࡳࡵࡻ࡬ࡢࡴ࡬ࡸࡾ࠭૏")
            }
        for k,v in d.items(): l1ll1ll11ll1l1ll_fwb_.setSetting(k,v)
        xbmc.executebuiltin(l1l111ll1l1ll_fwb_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬ࠬૐ"))
    def l1llll11l1ll1l1ll_fwb_(self):
        l11l111ll1l1ll_fwb_ = self.l11ll1l11ll1l1ll_fwb_()
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠦࡉࡵ࡭ࡺढ़࡯ࡲࡪࠦࡕࡴࡶࡤࡻ࡮࡫࡮ࡪࡣࠥ૑"),l1l111ll1l1ll_fwb_ (u"ࠬ࠭૒"),mode=l1l111ll1l1ll_fwb_ (u"࠭ࡢࡢࡼࡤࡓࡸࡵࡢࡠࡵࡨࡸࡹ࡯࡮ࡨࡵࡢࡷࡪࡺࡤࡦࡨࡤࡹࡱࡺࠧ૓"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࠨ૔"),IsPlayable=False)
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠣ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬࡫࡭ࡺࡢ࡭ࡷࡨࡡࡘࡵࡲࡵࡱࡺࡥࡳ࡯ࡥ࠻࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣ࡟ࡇࡣࠢ૕")+l11l111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠩࡥࡥࡿࡧࡏࡴࡱࡥࡣࡸࡵࡲࡵࡐࠪ૖"),l1l111ll1l1ll_fwb_ (u"ࠪࠫ૗"))+l1l111ll1l1ll_fwb_ (u"ࠦࡠ࠵ࡂ࡞ࠤ૘"),l1l111ll1l1ll_fwb_ (u"ࠬ࠭૙"),mode=l1l111ll1l1ll_fwb_ (u"࠭ࡳࡦ࡮ࡨࡧࡹࡀࡢࡢࡼࡤࡓࡸࡵࡢࡠࡵࡲࡶࡹ࠭૚"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࠨ૛"),IsPlayable=False)
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠣ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬࡫࡭ࡺࡢ࡭ࡷࡨࡡࡐࡵ࡬ࡦ࡬ࡱࡳॠऍ࠺࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࡞ࡆࡢࠨ૜")+l11l111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠩࡥࡥࡿࡧࡏࡴࡱࡥࡣࡸࡵࡲࡵࡃࡶࡧࡪࡴࡤࡪࡰࡪࡒࠬ૝"),l1l111ll1l1ll_fwb_ (u"ࠪࠫ૞"))+l1l111ll1l1ll_fwb_ (u"ࠦࡠ࠵ࡂ࡞ࠤ૟"),l1l111ll1l1ll_fwb_ (u"ࠬ࠭ૠ"),mode=l1l111ll1l1ll_fwb_ (u"࠭ࡳࡦ࡮ࡨࡧࡹࡀࡢࡢࡼࡤࡓࡸࡵࡢࡠࡵࡲࡶࡹࡇࡳࡤࡧࡱࡨ࡮ࡴࡧࠨૡ"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࠨૢ"),IsPlayable=False)
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠣ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬࡫࡭ࡺࡢ࡭ࡷࡨࡡࡕैࡥई࠼࡞࠳ࡈࡕࡌࡐࡔࡠࠤࡠࡈ࡝ࠣૣ")+l11l111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠩࡥࡥࡿࡧࡏࡴࡱࡥࡣࡵࡲࡥࡤࡐࠪ૤"),l1l111ll1l1ll_fwb_ (u"ࠪࠫ૥"))+l1l111ll1l1ll_fwb_ (u"ࠦࡠ࠵ࡂ࡞ࠤ૦"),l1l111ll1l1ll_fwb_ (u"ࠬ࠭૧"),mode=l1l111ll1l1ll_fwb_ (u"࠭ࡳࡦ࡮ࡨࡧࡹࡀࡢࡢࡼࡤࡓࡸࡵࡢࡠࡲ࡯ࡩࡨ࠭૨"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࠨ૩"),IsPlayable=False)
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠣ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬࡫࡭ࡺࡢ࡭ࡷࡨࡡ࡟ࡧࡷࣴࡦ࠽࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡡࡂ࡞ࠤ૪")+l11l111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠩࡥࡥࡿࡧࡏࡴࡱࡥࡣࡿࡧࡷࡰࡦࡑࠫ૫"),l1l111ll1l1ll_fwb_ (u"ࠪࠫ૬"))+l1l111ll1l1ll_fwb_ (u"ࠦࡠ࠵ࡂ࡞ࠤ૭"),l1l111ll1l1ll_fwb_ (u"ࠬ࠭૮"),mode=l1l111ll1l1ll_fwb_ (u"࠭ࡳࡦ࡮ࡨࡧࡹࡀࡢࡢࡼࡤࡓࡸࡵࡢࡠࡼࡤࡻࡴࡪࠧ૯"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࠨ૰"),IsPlayable=False)
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠣ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬࡫࡭ࡺࡢ࡭ࡷࡨࡡࡐࡸࡡ࡫ࠢࡸࡶࡴࡪࡺࡦࡰ࡬ࡥ࠿ࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࡜ࡄࡠࠦ૱")+l11l111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠩࡥࡥࡿࡧࡏࡴࡱࡥࡣࡨࡵࡵ࡯ࡶࡵࡽࡓ࠭૲"),l1l111ll1l1ll_fwb_ (u"ࠪࠫ૳"))+l1l111ll1l1ll_fwb_ (u"ࠦࡠ࠵ࡂ࡞ࠤ૴"),l1l111ll1l1ll_fwb_ (u"ࠬ࠭૵"),mode=l1l111ll1l1ll_fwb_ (u"࠭ࡳࡦ࡮ࡨࡧࡹࡀࡢࡢࡼࡤࡓࡸࡵࡢࡠࡥࡲࡹࡳࡺࡲࡺࠩ૶"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࠨ૷"),IsPlayable=False)
        l1l1lll1l1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠣ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬࡫࡭ࡺࡢ࡭ࡷࡨࡡࡉࡧࡴࡢࠢࡸࡶࡴࡪࡺࡦࡰ࡬ࡥ࠿ࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࡜ࡄࡠࠦ૸")+l11l111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠩࡥࡥࡿࡧࡏࡴࡱࡥࡣࡩࡧࡴࡢࡗࡵࡳࡩࢀࡥ࡯࡫ࡤࡒࠬૹ"),l1l111ll1l1ll_fwb_ (u"ࠪࠫૺ"))+l1l111ll1l1ll_fwb_ (u"ࠦࡠ࠵ࡂ࡞ࠤૻ"),l1l111ll1l1ll_fwb_ (u"ࠬ࠭ૼ"),mode=l1l111ll1l1ll_fwb_ (u"࠭ࡳࡦ࡮ࡨࡧࡹࡀࡢࡢࡼࡤࡓࡸࡵࡢࡠࡦࡤࡸࡦ࡛ࡲࡰࡦࡽࡩࡳ࡯ࡡࠨ૽"),l1ll11lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠧࠨ૾"),IsPlayable=False)
        l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠣࠢࠣ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞ࡑࡶࡳࡧࡿ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠣ૿"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡦࡪ࡮ࡰࡻࡪࡨ࠮ࡱ࡮࠲ࡴࡪࡸࡳࡰࡰࡶ࠳ࡸ࡫ࡡࡳࡥ࡫ࠫ଀"),l111lll1ll1l1ll_fwb_=1, mode=l1l111ll1l1ll_fwb_ (u"ࠪࡦࡦࢀࡡࡐࡵࡲࡦࡤࡹࡨࡰࡹࠪଁ"),iconImage=l1l111ll1l1ll_fwb_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠨଂ"),fanart=l1l1l1l111ll1l1ll_fwb_)
    def l11ll111ll1l1ll_fwb_(self,ex_link,l111lll1ll1l1ll_fwb_):
        l111lll1ll1l1ll_fwb_=int(l111lll1ll1l1ll_fwb_)
        import resources.lib.l1ll1l1l11ll1l1ll_fwb_ as l1l111l11ll1l1ll_fwb_
        l1lll1111ll1l1ll_fwb_ = l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠬࡨࡡࡻࡣࡒࡷࡴࡨ࡟ࡥࡣࡷࡥ࡚ࡸ࡯ࡥࡼࡨࡲ࡮ࡧࡖࠨଃ"))
        l1lll1111ll1l1ll_fwb_ = int(l1lll1111ll1l1ll_fwb_) if l1lll1111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"࠭ࠧ଄")
        l1lll111ll1l1ll_fwb_ = l1lll1111ll1l1ll_fwb_+9 if l1lll1111ll1l1ll_fwb_ else l1l111ll1l1ll_fwb_ (u"ࠧࠨଅ")
        l1l111111ll1l1ll_fwb_={
            l1l111ll1l1ll_fwb_ (u"ࠨࡱࡵࡨࡪࡸࡂࡺࠩଆ"):l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠩࡥࡥࡿࡧࡏࡴࡱࡥࡣࡸࡵࡲࡵࡘࠪଇ")) ,
            l1l111ll1l1ll_fwb_ (u"ࠪࡨࡪࡹࡣࡦࡰࡧ࡭ࡳ࡭ࠧଈ"):l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠫࡧࡧࡺࡢࡑࡶࡳࡧࡥࡳࡰࡴࡷࡅࡸࡩࡥ࡯ࡦ࡬ࡲ࡬࡜ࠧଉ")),
            l1l111ll1l1ll_fwb_ (u"ࠬࡶࡡࡨࡧࠪଊ"):l111lll1ll1l1ll_fwb_}
        if l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"࠭ࡢࡢࡼࡤࡓࡸࡵࡢࡠࡼࡤࡻࡴࡪࡖࠨଋ")) : l1l111111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠧ࡮ࡣ࡬ࡲࡕࡸ࡯ࡧࡧࡶࡷ࡮ࡵ࡮ࠨଌ")] = l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠨࡤࡤࡾࡦࡕࡳࡰࡤࡢࡾࡦࡽ࡯ࡥࡘࠪ଍"))
        if l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠩࡥࡥࡿࡧࡏࡴࡱࡥࡣࡨࡵࡵ࡯ࡶࡵࡽ࡛࠭଎")):l1l111111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠪࡧࡴࡻ࡮ࡵࡴࡼࠫଏ")] = l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠫࡧࡧࡺࡢࡑࡶࡳࡧࡥࡣࡰࡷࡱࡸࡷࡿࡖࠨଐ"))
        if l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠬࡨࡡࡻࡣࡒࡷࡴࡨ࡟ࡱ࡮ࡨࡧ࡛࠭଑")): l1l111111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"࠭ࡳࡦࡺࠪ଒")]=l1ll1ll11ll1l1ll_fwb_.getSetting(l1l111ll1l1ll_fwb_ (u"ࠧࡣࡣࡽࡥࡔࡹ࡯ࡣࡡࡳࡰࡪࡩࡖࠨଓ"))
        if l1lll1111ll1l1ll_fwb_: l1l111111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠨࡵࡷࡥࡷࡺࡂࡪࡴࡷ࡬࡞࡫ࡡࡳࠩଔ")]=l1lll1111ll1l1ll_fwb_
        if l1lll111ll1l1ll_fwb_: l1l111111ll1l1ll_fwb_[l1l111ll1l1ll_fwb_ (u"ࠩࡨࡲࡩࡈࡩࡳࡶ࡫࡝ࡪࡧࡲࠨକ")]=l1lll111ll1l1ll_fwb_
        url = ex_link+l1l111ll1l1ll_fwb_ (u"ࠪࡃࠬଖ")+urllib.urlencode(l1l111111ll1l1ll_fwb_)
        l111l11l1ll1l1ll_fwb_ = l1l111l11ll1l1ll_fwb_.l1l1lll1ll1l1ll_fwb_(url)
        l1l1l1111ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠫࡤࡥࡰࡢࡩࡨࡣࡤࡀࡢࡢࡼࡤࡓࡸࡵࡢࡠࡵ࡫ࡳࡼ࠭ଗ")
        l111ll111ll1l1ll_fwb_ =l1l111ll1l1ll_fwb_ (u"ࠬࡹࡨࡰࡹࡓࡩࡴࡶ࡬ࡦࡏࡲࡺ࡮࡫ࡳࠨଘ")
        xbmcplugin.setContent(l1l1lll11ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭ଙ"))
        if l111lll1ll1l1ll_fwb_>1: l1l1lll1l1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡨࡱ࡯ࡨࡢࡂ࠼ࠡࡲࡲࡴࡷࢀࡥࡥࡰ࡬ࡥࠥࡹࡴࡳࡱࡱࡥࠥࡂ࠼࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩଚ"), url=ex_link, mode=l1l1l1111ll1l1ll_fwb_, l111lll1ll1l1ll_fwb_=l111lll1ll1l1ll_fwb_-1, IsPlayable=False)
        items=len(l111l11l1ll1l1ll_fwb_)
        for f in l111l11l1ll1l1ll_fwb_: l1l1lll1l1ll1l1ll_fwb_(name=f.get(l1l111ll1l1ll_fwb_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧଛ")), url=f.get(l1l111ll1l1ll_fwb_ (u"ࠩ࡫ࡶࡪ࡬ࠧଜ")), mode=l111ll111ll1l1ll_fwb_, l1ll11lll1ll1l1ll_fwb_=f.get(l1l111ll1l1ll_fwb_ (u"ࠪ࡭ࡲ࡭ࠧଝ")), infoLabels=f, IsPlayable=True,l1ll11111ll1l1ll_fwb_=items)
        if len(l111l11l1ll1l1ll_fwb_)>5: l1l1lll1l1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤ࡬ࡵ࡬ࡥ࡟ࡁࡂࠥࡴࡡࡴࡶजࡴࡳࡧࠠࡴࡶࡵࡳࡳࡧࠠ࠿ࡀ࡞࠳ࡈࡕࡌࡐࡔࡠࠫଞ"), url=ex_link, mode=l1l1l1111ll1l1ll_fwb_, l111lll1ll1l1ll_fwb_=l111lll1ll1l1ll_fwb_+1, IsPlayable=False)
def l1ll1l1ll1l1ll_fwb_(url,data=None):
    try:
        headers = {l1l111ll1l1ll_fwb_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩଟ"):l1l111ll1l1ll_fwb_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡ࡬ࡲ࠻࠺࠻ࠡࡺ࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠺࠶࠴࠰࠯࠵࠴࠺࠸࠴࠱࠱࠲ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪଠ"),
        l1l111ll1l1ll_fwb_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨଡ"):l1l111ll1l1ll_fwb_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡬ࡩ࡭࡯ࡺࡩࡧ࠴ࡰ࡭࠱ࠪଢ"),
        l1l111ll1l1ll_fwb_ (u"ࠩࡒࡶ࡮࡭ࡩ࡯ࠩଣ"):l1l111ll1l1ll_fwb_ (u"ࠪࡧ࡭ࡸ࡯࡮ࡧ࠰ࡩࡽࡺࡥ࡯ࡵ࡬ࡳࡳࡀ࠯࠰ࡨࡪࡨࡴࡰ࡮࡭࡬࡫࡬ࡳࡳ࡯࡬࡬ࡥࡴࡧ࡮࡭࡯ࡩࡰࡱ࡫ࡴࡨࡰ࡭ࡪ࡭࡯࠭ତ"),}
        data = urllib.urlencode(data) if isinstance(data,dict) else data
        l1ll111ll1l1ll_fwb_ = l1ll11l11ll1l1ll_fwb_(url, data, headers)
        l1llllll11ll1l1ll_fwb_ = l1l11ll1l1ll1l1ll_fwb_(l1ll111ll1l1ll_fwb_)
        l1l11l1ll1ll1l1ll_fwb_ = l1llllll11ll1l1ll_fwb_.read()
        l1llllll11ll1l1ll_fwb_.close()
    except:
        l1l11l1ll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠫࠬଥ")
    return l1l11l1ll1ll1l1ll_fwb_
l11lllll1ll1l1ll_fwb_ = lambda (t) : t.encode(l1l111ll1l1ll_fwb_ (u"ࠬࡻࡴࡧ࠯࠻ࠫଦ")) if isinstance(t,unicode) else t
def l11ll1111ll1l1ll_fwb_(l1l11111ll1l1ll_fwb_,l111l1ll1ll1l1ll_fwb_=1):
    l11lll11ll1l1ll_fwb_, l1l1l11l1ll1l1ll_fwb_ = [],[]
    title=l11lllll1ll1l1ll_fwb_(l1l11111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"࠭ࡴࡪࡶ࡯ࡩࠬଧ"),l1l111ll1l1ll_fwb_ (u"ࠧࠨନ")))
    l11l1111ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠨࠩ଩")#l11lllll1ll1l1ll_fwb_(l1l11111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠩࡲࡶ࡮࡭ࡩ࡯ࡣ࡯ࡸ࡮ࡺ࡬ࡦࠩପ"),l1l111ll1l1ll_fwb_ (u"ࠪࠫଫ")))
    l1l1111ll1l1ll_fwb_=l1l11111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠫࡾ࡫ࡡࡳࠩବ"),l1l111ll1l1ll_fwb_ (u"ࠬ࠭ଭ"))
    l1l1lllll1ll1l1ll_fwb_=l11lllll1ll1l1ll_fwb_(l1l11111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"࠭ࡴࡷࡵ࡫ࡳࡼࡺࡩࡵ࡮ࡨࠫମ")))
    l1l1ll1111ll1l1ll_fwb_ = l1l11111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠧࡴࡧࡤࡷࡴࡴࠧଯ"))
    l1ll11l111ll1l1ll_fwb_ = l1l11111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࠩର"))
    l1ll11ll11ll1l1ll_fwb_ = l1l1ll1111ll1l1ll_fwb_ and l1ll11l111ll1l1ll_fwb_ and l1l1lllll1ll1l1ll_fwb_
    if l111l1ll1ll1l1ll_fwb_:
        if l1ll11ll11ll1l1ll_fwb_:
            data={l1l111ll1l1ll_fwb_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ଱"):l1l1lllll1ll1l1ll_fwb_,l1l111ll1l1ll_fwb_ (u"ࠪࡷࡪࢀ࡯࡯ࠩଲ"):l1l1ll1111ll1l1ll_fwb_,l1l111ll1l1ll_fwb_ (u"ࠫࡴࡪࡣࡪࡰࡨ࡯ࠬଳ"):l1ll11l111ll1l1ll_fwb_,l1l111ll1l1ll_fwb_ (u"ࠬ࡬ࡩ࡭࡯࡬ࡨࠬ଴"):l1l11111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"࠭ࡤࡢࡶࡤࡣ࡫࡯࡬࡮ࠩଵ"),l1l111ll1l1ll_fwb_ (u"ࠧࠨଶ")),l1l111ll1l1ll_fwb_ (u"ࠨࡷࡵࡰࡸࡺࡲࡰࡰࡼࠫଷ"):l1l11111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠩ࡫ࡶࡪ࡬ࠧସ"),l1l111ll1l1ll_fwb_ (u"ࠪࠫହ"))}
            l11l1lll1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠽࠸࠯࠳࠼࠲࠶࠷࠰࠯࠴࠴࠼࠴࡬ࡩ࡭࡯ࡺࡩࡧ࠵ࡳࡦࡣࡵࡧ࡭ࡥࡳࡦࡴ࡬ࡥࡱ࠴ࡰࡩࡲࠪ଺")
        else:
            data={l1l111ll1l1ll_fwb_ (u"ࠬࡹࡺࡶ࡭ࡤࡲࡾ࠭଻"):title,l1l111ll1l1ll_fwb_ (u"࠭ࡥ࡯ࡩࡗ࡭ࡹࡲࡥࠨ଼"):l11l1111ll1l1ll_fwb_,l1l111ll1l1ll_fwb_ (u"ࠧࡳࡱ࡮ࠫଽ"):l1l1111ll1l1ll_fwb_,l1l111ll1l1ll_fwb_ (u"ࠨࡥࡽࡥࡸࡺࡲࡸࡣࡱ࡭ࡦ࠭ା"):l1l111ll1l1ll_fwb_ (u"ࠩࠪି"),l1l111ll1l1ll_fwb_ (u"ࠪࡪ࡮ࡲ࡭ࡪࡦࠪୀ"):l1l11111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠫࡩࡧࡴࡢࡡࡩ࡭ࡱࡳࠧୁ"),l1l111ll1l1ll_fwb_ (u"ࠬ࠭ୂ")),l1l111ll1l1ll_fwb_ (u"࠭ࡵࡳ࡮ࡶࡸࡷࡵ࡮ࡺࠩୃ"):l1l11111ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠧࡩࡴࡨࡪࠬୄ"),l1l111ll1l1ll_fwb_ (u"ࠨࠩ୅"))}
            l11l1lll1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠤ࡫ࡸࡹࡶ࠺࠰࠱࠴࠻࠽࠴࠱࠺࠰࠴࠵࠵࠴࠲࠲࠺࠲ࡪ࡮ࡲ࡭ࡸࡧࡥ࠳ࡸ࡫ࡡࡳࡥ࡫ࡣ࡫࡯࡬࡮࠰ࡳ࡬ࡵࠨ୆")
        l1llll11ll1l1ll_fwb_=l1ll1l1ll1l1ll_fwb_(l11l1lll1ll1l1ll_fwb_,data)
        if l1llll11ll1l1ll_fwb_.startswith(l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡹࡺࡰࠨେ")):
            l1l1l11l1ll1l1ll_fwb_ = [urlparse.urlparse(l1llll11ll1l1ll_fwb_).netloc]
            l11lll11ll1l1ll_fwb_ = [l1llll11ll1l1ll_fwb_]
    else:
        if l1ll11ll11ll1l1ll_fwb_:
            data={l1l111ll1l1ll_fwb_ (u"ࠫࡹࡿࡴࡶ࡮ࠪୈ"):l1l1lllll1ll1l1ll_fwb_,l1l111ll1l1ll_fwb_ (u"ࠬ࡫࡮ࡨࡖ࡬ࡸࡱ࡫ࠧ୉"):l11l1111ll1l1ll_fwb_,l1l111ll1l1ll_fwb_ (u"࠭ࡳࡦࠩ୊"):l1l111ll1l1ll_fwb_ (u"ࠧࠦࡵ࠰ࠩࡸ࠭ୋ")%(l1l1ll1111ll1l1ll_fwb_,l1ll11l111ll1l1ll_fwb_),l1l111ll1l1ll_fwb_ (u"ࠨࡴࡲ࡯ࠬୌ"):l1l1111ll1l1ll_fwb_}
            l11l1lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠤ࡫ࡸࡹࡶ࠺࠰࠱࠴࠻࠽࠴࠱࠺࠰࠴࠵࠵࠴࠲࠲࠺࠲ࡪ࡮ࡲ࡭ࡸࡧࡥ࠳ࡼ࡯ࡥࡤࡧ࡭ࡾࡷࡵࡤࡦ࡮࠱ࡴ࡭ࡶ୍ࠢ")
        else:
            data={l1l111ll1l1ll_fwb_ (u"ࠪࡸࡾࡺࡵ࡭ࠩ୎"):title,l1l111ll1l1ll_fwb_ (u"ࠫࡪࡴࡧࡕ࡫ࡷࡰࡪ࠭୏"):l11l1111ll1l1ll_fwb_,l1l111ll1l1ll_fwb_ (u"ࠬࡸ࡯࡬ࠩ୐"):l1l1111ll1l1ll_fwb_}
            l11l1lll1ll1l1ll_fwb_=l1l111ll1l1ll_fwb_ (u"ࠨࡨࡵࡶࡳ࠾࠴࠵࠱࠸࠺࠱࠵࠾࠴࠱࠲࠲࠱࠶࠶࠾࠯ࡧ࡫࡯ࡱࡼ࡫ࡢ࠰ࡹ࡬ࡩࡨ࡫ࡪࡻࡴࡲࡨࡪࡲ࠮ࡱࡪࡳࠦ୑")
        l1ll1ll1ll1l1ll_fwb_=l1ll1l1ll1l1ll_fwb_(l11l1lll1ll1l1ll_fwb_,data)
        l1lll1l11ll1l1ll_fwb_ = re.findall(l1l111ll1l1ll_fwb_ (u"ࠢ࠽ࡣࠣࡸࡦࡸࡧࡦࡶࡀ࡟ࡡࠨࠧ࡞ࡡࡥࡰࡦࡴ࡫࡜࡞ࠥࠫࡢࠦࡨࡳࡧࡩࡁࡠࡢࠢࠨ࡟ࠫ࠲࠯ࡅࠩ࡜࡞ࠥࠫࡢࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠤ୒"),l1ll1ll1ll1l1ll_fwb_)
        if l1lll1l11ll1l1ll_fwb_:
            l11lll11ll1l1ll_fwb_, l1l1l11l1ll1l1ll_fwb_ = zip(*l1lll1l11ll1l1ll_fwb_)
    return l11lll11ll1l1ll_fwb_, l1l1l11l1ll1l1ll_fwb_
mode    = params.get(l1l111ll1l1ll_fwb_ (u"ࠨ࡯ࡲࡨࡪ࠭୓"), None)
fname   = params.get(l1l111ll1l1ll_fwb_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭୔"),l1l111ll1l1ll_fwb_ (u"ࠪࠫ୕"))
ex_link = params.get(l1l111ll1l1ll_fwb_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬୖ"),l1l111ll1l1ll_fwb_ (u"ࠬ࠭ୗ"))
l111lll1ll1l1ll_fwb_    = params.get(l1l111ll1l1ll_fwb_ (u"࠭ࡰࡢࡩࡨࠫ୘"),1)
l1lll1l1l1ll1l1ll_fwb_   = params.get(l1l111ll1l1ll_fwb_ (u"ࠧ࡮࡫ࡱࡪࡴ࠭୙"),{})
if mode is None:
    l1ll11ll1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠨࡋࡱࡪࡴࡸ࡭ࡢࡥ࡭ࡥࠬ୚"),mode=l1l111ll1l1ll_fwb_ (u"ࠩࡢ࡭ࡳ࡬࡯ࡠࠩ୛"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1l111ll1l1ll_fwb_ (u"ࠪࡴࡦࡺࡨࠨଡ଼")))+l1l111ll1l1ll_fwb_ (u"ࠫ࠴࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧଢ଼"),infoLabels={})
    l1lllllll1ll1l1ll_fwb_().l11llll11ll1l1ll_fwb_()
elif mode.startswith(l1l111ll1l1ll_fwb_ (u"ࠬࡥࡩ࡯ࡨࡲࡣࠬ୞"))  : l1lllll11ll1l1ll_fwb_.__myinfo__.go(sys.argv)
elif mode==l1l111ll1l1ll_fwb_ (u"࠭ࡢࡢࡼࡤࡪ࡮ࡲ࡭ࡰࡹࡢࡲࡦࡼࡩࠨୟ")    : l1lllllll1ll1l1ll_fwb_().l1l1l1l1l1ll1l1ll_fwb_()
elif mode==l1l111ll1l1ll_fwb_ (u"ࠧࡣࡣࡽࡥ࡫࡯࡬࡮ࡱࡺࡣࡸ࡮࡯ࡸࠩୠ")    : l1lllllll1ll1l1ll_fwb_().l1l1l11l11ll1l1ll_fwb_(ex_link,l111lll1ll1l1ll_fwb_)
elif mode == l1l111ll1l1ll_fwb_ (u"ࠨࡤࡤࡾࡦ࡬ࡩ࡭࡯ࡲࡻࡤࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࡟ࡴࡧࡷࡨࡪ࡬ࡡࡶ࡮ࡷࠫୡ"): l1lllllll1ll1l1ll_fwb_(). l1ll1ll1l1ll1l1ll_fwb_()
elif mode==l1l111ll1l1ll_fwb_ (u"ࠩࡵࡥࡳࡱࡩ࡯ࡩࡷࡳࡵࡥ࡮ࡢࡸ࡬ࠫୢ")    : l1lllllll1ll1l1ll_fwb_().l1llll1ll1ll1l1ll_fwb_()
elif mode==l1l111ll1l1ll_fwb_ (u"ࠪࡶࡦࡴ࡫ࡪࡰࡪࡸࡴࡶ࡟ࡴࡪࡲࡻࠬୣ")    : l1lllllll1ll1l1ll_fwb_().l111ll11ll1l1ll_fwb_(ex_link)
elif mode==l1l111ll1l1ll_fwb_ (u"ࠫࡷࡧ࡮࡬࡫ࡱ࡫ࡸ࡫ࡲࡪࡣ࡯࡭ࡤࡹࡨࡰࡹࠪ୤"): l1lllllll1ll1l1ll_fwb_().l1l1ll1ll1ll1l1ll_fwb_(ex_link)
elif mode==l1l111ll1l1ll_fwb_ (u"ࠬࡸࡡ࡯࡭࡬ࡲ࡬ࡶࡥࡳࡵࡲࡲࡤࡹࡨࡰࡹࠪ୥") : l1lllllll1ll1l1ll_fwb_().l111l1l11ll1l1ll_fwb_(ex_link)
elif mode==l1l111ll1l1ll_fwb_ (u"࠭ࡳࡩࡱࡺࡔࡪࡵࡰ࡭ࡧࡐࡳࡻ࡯ࡥࡴࠩ୦")   : l1lllllll1ll1l1ll_fwb_().l111lll11ll1l1ll_fwb_(ex_link)
elif mode==l1l111ll1l1ll_fwb_ (u"ࠧࡣࡱࡻࡳ࡫࡬ࡩࡤࡧࡢࡲࡦࡼࡩࠨ୧")     : l1lllllll1ll1l1ll_fwb_().l1ll111111ll1l1ll_fwb_()
elif mode==l1l111ll1l1ll_fwb_ (u"ࠨࡤࡲࡼࡴ࡬ࡦࡪࡥࡨࡣࡸ࡮࡯ࡸࠩ୨")     : l1lllllll1ll1l1ll_fwb_().l1l11lll1ll1l1ll_fwb_(ex_link)
elif mode==l1l111ll1l1ll_fwb_ (u"ࠩࡦ࡬ࡪࡩ࡯ࡣࡧ࡭ࡶࡿ࡫ࡣࡠࡰࡤࡺ࡮࠭୩")  : l1lllllll1ll1l1ll_fwb_().l1ll111l1ll1l1ll_fwb_()
elif mode==l1l111ll1l1ll_fwb_ (u"ࠪࡨࡻࡪࡢ࡭ࡷࡨࡶࡦࡿ࡟ࡴࡪࡲࡻࠬ୪")    : l1lllllll1ll1l1ll_fwb_().l1ll1l1111ll1l1ll_fwb_(ex_link)
elif mode==l1l111ll1l1ll_fwb_ (u"ࠫࡵࡵࡰࡶ࡮ࡤࡶࡳ࡫ࡦࡪ࡮ࡰࡽࡤࡹࡨࡰࡹࠪ୫"): l1lllllll1ll1l1ll_fwb_().l1llll1l1ll1l1ll_fwb_(ex_link,l111lll1ll1l1ll_fwb_)
elif mode==l1l111ll1l1ll_fwb_ (u"ࠬࡪࡺࡪࡵࡩ࡭ࡱࡳࡹࡸࡶࡹࡣࡸ࡮࡯ࡸࠩ୬")  : l1lllllll1ll1l1ll_fwb_().l1l1ll11l1ll1l1ll_fwb_(ex_link,l111lll1ll1l1ll_fwb_)
elif mode==l1l111ll1l1ll_fwb_ (u"࠭ࡢࡢࡼࡤࡓࡸࡵࡢࡠࡰࡤࡺ࡮࠭୭")    : l1lllllll1ll1l1ll_fwb_().l1llll11l1ll1l1ll_fwb_()
elif mode==l1l111ll1l1ll_fwb_ (u"ࠧࡣࡣࡽࡥࡔࡹ࡯ࡣࡡࡶ࡬ࡴࡽࠧ୮")    : l1lllllll1ll1l1ll_fwb_().l11ll111ll1l1ll_fwb_(ex_link,l111lll1ll1l1ll_fwb_)
elif mode == l1l111ll1l1ll_fwb_ (u"ࠨࡤࡤࡾࡦࡕࡳࡰࡤࡢࡷࡪࡺࡴࡪࡰࡪࡷࡤࡹࡥࡵࡦࡨࡪࡦࡻ࡬ࡵࠩ୯"): l1lllllll1ll1l1ll_fwb_().l11l1l1ll1l1ll_fwb_()
elif mode == l1l111ll1l1ll_fwb_ (u"ࠩࡄࡨࡩ࡚࡯ࡍ࡫ࡥࡶࡦࡸࡹࠨ୰"):
    import resources.lib.l1ll1l1l11ll1l1ll_fwb_ as l1l111l11ll1l1ll_fwb_
    from resources.lib import l1ll1l11ll1l1ll_fwb_
    l1lll1l1l1ll1l1ll_fwb_ = eval(l1lll1l1l1ll1l1ll_fwb_)
    if l1lll1l1l1ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠪࡱࡪࡪࡩࡢࡶࡼࡴࡪ࠭ୱ"),l1l111ll1l1ll_fwb_ (u"ࠫࠬ୲"))==l1l111ll1l1ll_fwb_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ୳") or l1l111ll1l1ll_fwb_ (u"࠭࠯ࡧ࡫࡯ࡱ࠴࠭୴") in ex_link:
        l1ll1ll111ll1l1ll_fwb_ = l1l111l11ll1l1ll_fwb_.getFilmInfoFull(l1lll1l1l1ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠧࡥࡣࡷࡥࡤ࡬ࡩ࡭࡯ࠪ୵"),l1l111ll1l1ll_fwb_ (u"ࠨࠩ୶")))
        l1lll1l1l1ll1l1ll_fwb_.update(l1ll1ll111ll1l1ll_fwb_)
        l1ll1l11ll1l1ll_fwb_.l11ll11ll1l1ll_fwb_().add(l1lll1l1l1ll1l1ll_fwb_)
    elif l1lll1l1l1ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠩࡰࡩࡩ࡯ࡡࡵࡻࡳࡩࠬ୷"),l1l111ll1l1ll_fwb_ (u"ࠪࠫ୸"))==l1l111ll1l1ll_fwb_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࠬ୹") or l1l111ll1l1ll_fwb_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡥࡱ࠵ࠧ୺") in ex_link:
        l1ll1ll111ll1l1ll_fwb_ = l1l111l11ll1l1ll_fwb_.getFilmInfoFull(l1lll1l1l1ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"࠭ࡤࡢࡶࡤࡣ࡫࡯࡬࡮ࠩ୻"),l1l111ll1l1ll_fwb_ (u"ࠧࠨ୼")))
        l1lll1l1l1ll1l1ll_fwb_.update(l1ll1ll111ll1l1ll_fwb_)
        l1l1l1lll1ll1l1ll_fwb_ =l1l111l11ll1l1ll_fwb_.l1l1111l1ll1l1ll_fwb_(ex_link,l1lll1l1l1ll1l1ll_fwb_)
        l1l1lllll1ll1l1ll_fwb_=l1lll1l1l1ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠨࡱࡵ࡭࡬࡯࡮ࡢ࡮ࡷ࡭ࡹࡲࡥࠨ୽"))
        if not l1l1lllll1ll1l1ll_fwb_:
            l1l1lllll1ll1l1ll_fwb_=l1lll1l1l1ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ୾"))
        year = l1lll1l1l1ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠪࡽࡪࡧࡲࠨ୿"))
        if not l1l1l1lll1ll1l1ll_fwb_:
            l1l1ll1l1ll1l1ll_fwb_.notification(l1l111ll1l1ll_fwb_ (u"ࠫࡋ࡯࡬࡮ࡹࡨࡦࡇࡵ࡯ࡴࡶࡨࡶࠬ஀"), l1l111ll1l1ll_fwb_ (u"ࠬࡈࡲࡢ࡭ࠣࡩࡵ࡯ࡺࡰࡦࣶࡻࠬ஁") , xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1l111ll1l1ll_fwb_ (u"࠭ࡰࡢࡶ࡫ࠫஂ")))+l1l111ll1l1ll_fwb_ (u"ࠧ࠰࡫ࡦࡳࡳ࠴ࡰ࡯ࡩࠪஃ"), 5000, False)
        elif l1l1lllll1ll1l1ll_fwb_ and year:
            l1ll1l11ll1l1ll_fwb_.l1lll11l1ll1l1ll_fwb_().add(l1l1lllll1ll1l1ll_fwb_, year, l1l1l1lll1ll1l1ll_fwb_)
        else:
            l1l1ll1l1ll1l1ll_fwb_.notification(l1l111ll1l1ll_fwb_ (u"ࠨࡈ࡬ࡰࡲࡽࡥࡣࡄࡲࡳࡸࡺࡥࡳࠩ஄"), l1l111ll1l1ll_fwb_ (u"ࠩࡍࡥࡰ࡯ज़ࠡࡲࡵࡳࡧࡲࡥ࡮ࠣࠪஅ") , xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1l111ll1l1ll_fwb_ (u"ࠪࡴࡦࡺࡨࠨஆ")))+l1l111ll1l1ll_fwb_ (u"ࠫ࠴࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧஇ"), 5000, False)
    else:
        l1l1ll1l1ll1l1ll_fwb_.notification(l1l111ll1l1ll_fwb_ (u"ࠬࡌࡩ࡭࡯ࡺࡩࡧࡈ࡯ࡰࡵࡷࡩࡷ࠭ஈ"), l1l111ll1l1ll_fwb_ (u"࠭ࡔࡢࠢࡲࡴࡨࡰࡡࠡࡰ࡬ࡩࠥࡰࡥࡴࡶࠣࠬ࡯࡫ࡳࡻࡥࡽࡩ࠮ࠦࡤࡰࡵࡷझࡵࡴࡡࠨஉ") , xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1l111ll1l1ll_fwb_ (u"ࠧࡱࡣࡷ࡬ࠬஊ")))+l1l111ll1l1ll_fwb_ (u"ࠨ࠱࡬ࡧࡴࡴ࠮ࡱࡰࡪࠫ஋"), 5000, False)
elif mode.startswith(l1l111ll1l1ll_fwb_ (u"ࠩࡢࡣࡵࡧࡧࡦࡡࡢ࠾ࠬ஌")):
    _1ll1l1l1ll1l1ll_fwb_=mode.split(l1l111ll1l1ll_fwb_ (u"ࠥ࠾ࠧ஍"))[-1]
    url = l1l1ll1ll1l1ll_fwb_({l1l111ll1l1ll_fwb_ (u"ࠫࡲࡵࡤࡦࠩஎ"): _1ll1l1l1ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࡳࡧ࡭ࡦࠩஏ"): l1l111ll1l1ll_fwb_ (u"࠭ࠧஐ"), l1l111ll1l1ll_fwb_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨ஑") : ex_link, l1l111ll1l1ll_fwb_ (u"ࠨࡲࡤ࡫ࡪ࠭ஒ"): l111lll1ll1l1ll_fwb_,l1l111ll1l1ll_fwb_ (u"ࠩࡰ࡭ࡳ࡬࡯ࠨஓ"):l1lll1l1l1ll1l1ll_fwb_})
    xbmc.executebuiltin(l1l111ll1l1ll_fwb_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬࠭ࠫࡳࠪࠩஔ")% url)
elif mode.startswith(l1l111ll1l1ll_fwb_ (u"ࠫࡤࡥࡰࡢࡩࡨࡖࡤࡥ࠺ࠨக")):
    _1ll1l1l1ll1l1ll_fwb_=mode.split(l1l111ll1l1ll_fwb_ (u"ࠧࡀࠢ஖"))[-1]
    url = l1l1ll1ll1l1ll_fwb_({l1l111ll1l1ll_fwb_ (u"࠭࡭ࡰࡦࡨࠫ஗"): _1ll1l1l1ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫ஘"): l1l111ll1l1ll_fwb_ (u"ࠨࠩங"), l1l111ll1l1ll_fwb_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪச") : ex_link, l1l111ll1l1ll_fwb_ (u"ࠪࡴࡦ࡭ࡥࠨ஛"): l111lll1ll1l1ll_fwb_,l1l111ll1l1ll_fwb_ (u"ࠫࡲ࡯࡮ࡧࡱࠪஜ"):l1lll1l1l1ll1l1ll_fwb_})
    xbmc.executebuiltin(l1l111ll1l1ll_fwb_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠥࡴࠫࠪ஝")% url)
elif mode.startswith(l1l111ll1l1ll_fwb_ (u"࠭ࡳࡦ࡮ࡨࡧࡹ࠭ஞ")):
    _1ll111l11ll1l1ll_fwb_ = mode.split(l1l111ll1l1ll_fwb_ (u"ࠢ࠻ࠤட"))[-1]
    import resources.lib.l1ll1l1l11ll1l1ll_fwb_ as l1l111l11ll1l1ll_fwb_
    label,value = l1l111l11ll1l1ll_fwb_.l1l111l1ll1l1ll_fwb_(_1ll111l11ll1l1ll_fwb_)
    s = l1l1ll1l1ll1l1ll_fwb_.select(l1l111ll1l1ll_fwb_ (u"ࠨ࡙ࡼࡦ࡮࡫ࡲࡻࠩ஠"),label)
    if s>-1:
        l1ll1ll11ll1l1ll_fwb_.setSetting(_1ll111l11ll1l1ll_fwb_+l1l111ll1l1ll_fwb_ (u"࡙ࠩࠫ஡"),str(value[s]))
        l1ll1ll11ll1l1ll_fwb_.setSetting(_1ll111l11ll1l1ll_fwb_+l1l111ll1l1ll_fwb_ (u"ࠪࡒࠬ஢"),str(label[s]) )
        xbmc.executebuiltin(l1l111ll1l1ll_fwb_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠭ண"))
elif mode.startswith(l1l111ll1l1ll_fwb_ (u"ࠬࡳࡵ࡭ࡶ࡬ࡷࡪࡲࡥࡤࡶࠪத")):
    _1ll111l11ll1l1ll_fwb_ = mode.split(l1l111ll1l1ll_fwb_ (u"ࠨ࠺ࠣ஥"))[-1]
    import resources.lib.l1ll1l1l11ll1l1ll_fwb_ as l1l111l11ll1l1ll_fwb_
    label,value = l1l111l11ll1l1ll_fwb_.l1l111l1ll1l1ll_fwb_(_1ll111l11ll1l1ll_fwb_)
    s = l1l1ll1l1ll1l1ll_fwb_.multiselect(l1l111ll1l1ll_fwb_ (u"ࠧࡘࡻࡥ࡭ࡪࡸࡺࠡࠪ࡮࡭ࡱࡱࡡࠪࠩ஦"),label)
    if isinstance(s,list):
        if 0 in s:
            n = label[0]
            v = l1l111ll1l1ll_fwb_ (u"ࠨࠩ஧")
        else:
            _1l1l11ll1ll1l1ll_fwb_=_1ll111l11ll1l1ll_fwb_.split(l1l111ll1l1ll_fwb_ (u"ࠩࡢࠫந"))[-1]
            v = l1l111ll1l1ll_fwb_ (u"ࠪ࠰ࠬன").join( [value[i] for i in s])
            n = l1l111ll1l1ll_fwb_ (u"ࠫ࠱࠭ப").join( [label[i] for i in s])
        l1ll1ll11ll1l1ll_fwb_.setSetting(_1ll111l11ll1l1ll_fwb_+l1l111ll1l1ll_fwb_ (u"ࠬ࡜ࠧ஫"),v)
        l1ll1ll11ll1l1ll_fwb_.setSetting(_1ll111l11ll1l1ll_fwb_+l1l111ll1l1ll_fwb_ (u"࠭ࡎࠨ஬"),n)
        xbmc.executebuiltin(l1l111ll1l1ll_fwb_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠩ஭"))
elif mode.startswith(l1l111ll1l1ll_fwb_ (u"ࠨࡶࡨࡼࡹࡪࡩࡢ࡮ࡲ࡫ࠬம")):
    _1ll111l11ll1l1ll_fwb_ = mode.split(l1l111ll1l1ll_fwb_ (u"ࠤ࠽ࠦய"))[-1]
    d = l1l1ll1l1ll1l1ll_fwb_.input(l1l111ll1l1ll_fwb_ (u"ࡸࠫࡘࢀࡵ࡬ࡣ࡭ࠫர"), type=xbmcgui.INPUT_ALPHANUM)
    l1ll1ll11ll1l1ll_fwb_.setSetting(_1ll111l11ll1l1ll_fwb_+l1l111ll1l1ll_fwb_ (u"࡛ࠫ࠭ற"),d)
    l1ll1ll11ll1l1ll_fwb_.setSetting(_1ll111l11ll1l1ll_fwb_+l1l111ll1l1ll_fwb_ (u"ࠬࡔࠧல"),d)
    xbmc.executebuiltin(l1l111ll1l1ll_fwb_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨள"))
elif mode == l1l111ll1l1ll_fwb_ (u"ࠧࡍ࡫ࡶࡸࡒࡵࡶࡪࡧࡶࠫழ"):
    l1ll1111ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠨ࠱ࠪவ").join([x for x in [l1llll111ll1l1ll_fwb_,l1l1l1l1ll1l1ll_fwb_,l1111l1l1ll1l1ll_fwb_] if x]) if l1l111ll1l1ll_fwb_ (u"ࠩ࠲ࡪ࡮ࡲ࡭ࡺ࠯ࡲࡲࡱ࡯࡮ࡦ࠱ࠪஶ") in ex_link else l1l111ll1l1ll_fwb_ (u"ࠪࠫஷ")
    l1ll11l1ll1l1ll_fwb_(ex_link+l1ll1111ll1l1ll_fwb_,l111lll1ll1l1ll_fwb_)
    xbmcplugin.setContent(l1l1lll11ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫஸ"))
elif mode == l1l111ll1l1ll_fwb_ (u"ࠬࡒࡩࡴࡶࡐࡳࡻ࡯ࡥࡴࡍ࡬ࡨࡸ࠭ஹ"):
    l1ll11l1ll1l1ll_fwb_(ex_link,l111lll1ll1l1ll_fwb_)
    xbmcplugin.setContent(l1l1lll11ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭஺"))
elif mode == l1l111ll1l1ll_fwb_ (u"ࠧࡐࡲࡦ࡮ࡪ࠭஻"):
    l1ll1ll11ll1l1ll_fwb_.openSettings()
elif mode == l1l111ll1l1ll_fwb_ (u"ࠨࡡࡢࡴࡦ࡭ࡥࡠࡡࡐࠫ஼"):
    url = l1l1ll1ll1l1ll_fwb_({l1l111ll1l1ll_fwb_ (u"ࠩࡰࡳࡩ࡫ࠧ஽"): l1l111ll1l1ll_fwb_ (u"ࠪࡐ࡮ࡹࡴࡎࡱࡹ࡭ࡪࡹࠧா"), l1l111ll1l1ll_fwb_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨி"): l1l111ll1l1ll_fwb_ (u"ࠬ࠭ீ"), l1l111ll1l1ll_fwb_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧு") : ex_link, l1l111ll1l1ll_fwb_ (u"ࠧࡱࡣࡪࡩࠬூ"): l111lll1ll1l1ll_fwb_})
    xbmc.executebuiltin(l1l111ll1l1ll_fwb_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠫࠩࡸ࠯ࠧ௃")% url)
elif mode == l1l111ll1l1ll_fwb_ (u"ࠩࡢࡣࡵࡧࡧࡦࡡࡢࡗࠬ௄"):
    url = l1l1ll1ll1l1ll_fwb_({l1l111ll1l1ll_fwb_ (u"ࠪࡱࡴࡪࡥࠨ௅"): l1l111ll1l1ll_fwb_ (u"ࠫࡑ࡯ࡳࡵࡕࡨࡶ࡮ࡧ࡬ࡦࠩெ"), l1l111ll1l1ll_fwb_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࡳࡧ࡭ࡦࠩே"): l1l111ll1l1ll_fwb_ (u"࠭ࠧை"), l1l111ll1l1ll_fwb_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨ௉") : ex_link, l1l111ll1l1ll_fwb_ (u"ࠨࡲࡤ࡫ࡪ࠭ொ"): l111lll1ll1l1ll_fwb_})
    xbmc.executebuiltin(l1l111ll1l1ll_fwb_ (u"࡛ࠩࡆࡒࡉ࠮ࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠬࠪࡹࠩࠨோ")% url)
elif mode == l1l111ll1l1ll_fwb_ (u"ࠪ࡫ࡪࡺࡅࡱ࡫ࡶࡳࡩ࡫ࡳࠨௌ"):
    l1ll1l111ll1l1ll_fwb_(ex_link)
    xbmcplugin.setContent(l1l1lll11ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ்࠭"))
elif mode == l1l111ll1l1ll_fwb_ (u"ࠬ࡭ࡥࡵࡇࡳ࡭ࡸࡵࡤࡦࡵ࠵ࠫ௎"):
    l1l11l11ll1l1ll_fwb_(ex_link)
    xbmcplugin.setContent(l1l1lll11ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ௏"))
elif mode == l1l111ll1l1ll_fwb_ (u"ࠧࡍ࡫ࡶࡸࡘ࡫ࡲࡪࡣ࡯ࡩࠬௐ"):
    l111l111ll1l1ll_fwb_(ex_link,l111lll1ll1l1ll_fwb_)
    xbmcplugin.setContent(l1l1lll11ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠨࡶࡹࡷ࡭ࡵࡷࡴࠩ௑"))
elif mode == l1l111ll1l1ll_fwb_ (u"ࠩࡪࡩࡹ࡙ࡥࡢࡵࡲࡲࡸ࠭௒"):
    l1l1111l1ll1l1ll_fwb_(ex_link,l1lll1l1l1ll1l1ll_fwb_)
    xbmcplugin.setContent(l1l1lll11ll1l1ll_fwb_, l1l111ll1l1ll_fwb_ (u"ࠪࡸࡻࡹࡨࡰࡹࡶࠫ௓"))
elif mode == l1l111ll1l1ll_fwb_ (u"ࠫࡑ࡯ࡳࡵࡈࡖࠫ௔"):
    l111lll1ll1l1ll_fwb_=int(l111lll1ll1l1ll_fwb_)
elif mode == l1l111ll1l1ll_fwb_ (u"ࠬ࡭ࡥࡵࡎ࡬ࡲࡰࡹࠧ௕"):
    l1l1l1ll1ll1l1ll_fwb_(l1lll1l1l1ll1l1ll_fwb_)
elif mode == l1l111ll1l1ll_fwb_ (u"࠭࡬ࡱ࡮ࡤࡽࠬ௖"):
    l1l1l1ll1ll1l1ll_fwb_(l1lll1l1l1ll1l1ll_fwb_)
elif mode == l1l111ll1l1ll_fwb_ (u"ࠧࡐࡲࡦ࡮ࡪ࠭ௗ"):
    l1ll1ll11ll1l1ll_fwb_.openSettings()
elif mode ==l1l111ll1l1ll_fwb_ (u"ࠨࡕࡽࡹࡰࡧࡪࠨ௘"):
    l1ll11ll1ll1l1ll_fwb_(l1l111ll1l1ll_fwb_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢ࡯࡭࡬࡮ࡴࡨࡴࡨࡩࡳࡣࡎࡰࡹࡨࠤࡘࢀࡵ࡬ࡣࡱ࡭ࡪࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ௙"),ex_link=l1l111ll1l1ll_fwb_ (u"ࠪࠫ௚"),mode=l1l111ll1l1ll_fwb_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭ࡒࡴࡽࡥࠨ௛"))
    l1l1l111ll1l1ll_fwb_ = l111l1111ll1l1ll_fwb_()
    if not l1l1l111ll1l1ll_fwb_ == [l1l111ll1l1ll_fwb_ (u"ࠬ࠭௜")]:
        for entry in l1l1l111ll1l1ll_fwb_:
            contextmenu = []
            contextmenu.append((l1l111ll1l1ll_fwb_ (u"ࡻࠧࡖࡵࡸࡲࠬ௝"), l1l111ll1l1ll_fwb_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠪࠨࡷ࠮࠭௞")% l1l1ll1ll1l1ll_fwb_({l1l111ll1l1ll_fwb_ (u"ࠨ࡯ࡲࡨࡪ࠭௟"): l1l111ll1l1ll_fwb_ (u"ࠩࡖࡾࡺࡱࡡ࡫ࡗࡶࡹࡳ࠭௠"), l1l111ll1l1ll_fwb_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫ௡") : entry})),)
            contextmenu.append((l1l111ll1l1ll_fwb_ (u"ࡹ࡛ࠬࡳࡶࡰࠣࡧࡦैࡡࠡࡪ࡬ࡷࡹࡵࡲࡪࡧࠪ௢"), l1l111ll1l1ll_fwb_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠥࡴࠫࠪ௣") % l1l1ll1ll1l1ll_fwb_({l1l111ll1l1ll_fwb_ (u"࠭࡭ࡰࡦࡨࠫ௤"): l1l111ll1l1ll_fwb_ (u"ࠧࡔࡼࡸ࡯ࡦࡰࡕࡴࡷࡱࡅࡱࡲࠧ௥")})),)
            l1ll11ll1ll1l1ll_fwb_(name=entry, ex_link=entry.replace(l1l111ll1l1ll_fwb_ (u"ࠨࠢࠪ௦"),l1l111ll1l1ll_fwb_ (u"ࠩ࠮ࠫ௧")), mode=l1l111ll1l1ll_fwb_ (u"ࠪࡗࡿࡻ࡫ࡢ࡬ࡑࡳࡼ࡫ࠧ௨"), fanart=None, contextmenu=contextmenu)
elif mode ==l1l111ll1l1ll_fwb_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭ࡒࡴࡽࡥࠨ௩"):
    if not ex_link:
        l1llll1l11ll1l1ll_fwb_ = l1l1ll1l1ll1l1ll_fwb_.input(l1l111ll1l1ll_fwb_ (u"ࡺ࠭ࡓࡻࡷ࡮ࡥ࡯࠲ࠠࡑࡱࡧࡥ࡯ࠦࡴࡺࡶࡸॆࠥ࡬ࡩ࡭࡯ࡸ࠳ࡸ࡫ࡲࡪࡣ࡯ࡹࠬ௪"), type=xbmcgui.INPUT_ALPHANUM)
        if l1llll1l11ll1l1ll_fwb_: l1l11ll1ll1l1ll_fwb_(l1llll1l11ll1l1ll_fwb_)
    else:
        l1llll1l11ll1l1ll_fwb_ = ex_link
    if l1llll1l11ll1l1ll_fwb_:
        l111lll1ll1l1ll_fwb_ = int(l111lll1ll1l1ll_fwb_)
        import resources.lib.l1ll1l1l11ll1l1ll_fwb_ as l1l111l11ll1l1ll_fwb_
        l1lll1l1l1ll1l1ll_fwb_ = eval(l1lll1l1l1ll1l1ll_fwb_)
        l1111l1ll1l1ll_fwb_ = l1lll1l1l1ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"࠭࡮ࡦࡺࡷࡣࡺࡸ࡬ࠨ௫"),l1l111ll1l1ll_fwb_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲࡫࡯࡬࡮ࡹࡨࡦ࠳ࡶ࡬࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡀࠫ௬"))
        l111l11l1ll1l1ll_fwb_,extra = l1l111l11ll1l1ll_fwb_.l11l1l111ll1l1ll_fwb_(l1llll1l11ll1l1ll_fwb_,l111lll1ll1l1ll_fwb_,l1111l1ll1l1ll_fwb_)
        if l111lll1ll1l1ll_fwb_>1       : l1l1lll1l1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡩࡲࡰࡩࡣ࠼࠽ࠢࡳࡳࡵࡸࡺࡦࡦࡱ࡭ࡦࠦࡳࡵࡴࡲࡲࡦࠦ࠼࠽࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ௭"), url=l1llll1l11ll1l1ll_fwb_, mode=l1l111ll1l1ll_fwb_ (u"ࠩࡢࡣࡵࡧࡧࡦࡡࡢ࠾ࡘࢀࡵ࡬ࡣ࡭ࡒࡴࡽࡥࠨ௮"), l111lll1ll1l1ll_fwb_=l111lll1ll1l1ll_fwb_-1, infoLabels=l1lll1l1l1ll1l1ll_fwb_, IsPlayable=False)
        for f in l111l11l1ll1l1ll_fwb_  :
            l1lll111l1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠪ࡫ࡪࡺࡓࡦࡣࡶࡳࡳࡹࠧ௯") if f.get(l1l111ll1l1ll_fwb_ (u"ࠫ࡮ࡹࡆࡰ࡮ࡧࡩࡷ࠭௰"),False) else l1l111ll1l1ll_fwb_ (u"ࠬ࡭ࡥࡵࡎ࡬ࡲࡰࡹࠧ௱")
            if l1l111ll1l1ll_fwb_ (u"࠭࠯ࡱࡧࡵࡷࡴࡴ࠯ࠨ௲") in f.get(l1l111ll1l1ll_fwb_ (u"ࠧࡩࡴࡨࡪࠬ௳")): l1lll111l1ll1l1ll_fwb_ = l1l111ll1l1ll_fwb_ (u"ࠨࡵ࡫ࡳࡼࡖࡥࡰࡲ࡯ࡩࡒࡵࡶࡪࡧࡶࠫ௴")
            l1l1lll1l1ll1l1ll_fwb_(name=f.get(l1l111ll1l1ll_fwb_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ௵")), url=f.get(l1l111ll1l1ll_fwb_ (u"ࠪ࡬ࡷ࡫ࡦࠨ௶")), mode=l1lll111l1ll1l1ll_fwb_, l1ll11lll1ll1l1ll_fwb_=f.get(l1l111ll1l1ll_fwb_ (u"ࠫ࡮ࡳࡧࠨ௷")), infoLabels=f, IsPlayable=True,l1ll11111ll1l1ll_fwb_=len(l111l11l1ll1l1ll_fwb_))
        if len(l111l11l1ll1l1ll_fwb_)>8 : l1l1lll1l1ll1l1ll_fwb_(name=l1l111ll1l1ll_fwb_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࡭࡯࡭ࡦࡠࡂࡃࠦ࡮ࡢࡵࡷझࡵࡴࡡࠡࡵࡷࡶࡴࡴࡡࠡࡀࡁ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ௸"), url=l1llll1l11ll1l1ll_fwb_, mode=l1l111ll1l1ll_fwb_ (u"࠭࡟ࡠࡲࡤ࡫ࡪࡥ࡟࠻ࡕࡽࡹࡰࡧࡪࡏࡱࡺࡩࠬ௹"), l111lll1ll1l1ll_fwb_=l111lll1ll1l1ll_fwb_+1, infoLabels=l1lll1l1l1ll1l1ll_fwb_, IsPlayable=False)
        for l1l1ll1l11ll1l1ll_fwb_ in extra:
            l1l1lll1l1ll1l1ll_fwb_(name=l1l1ll1l11ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠧࡠࡶ࡬ࡸࡱ࡫ࠧ௺")), url=l1l1ll1l11ll1l1ll_fwb_.get(l1l111ll1l1ll_fwb_ (u"ࠨࡡ࡫ࡶࡪ࡬ࠧ௻")), mode=l1l111ll1l1ll_fwb_ (u"ࠩࡢࡣࡵࡧࡧࡦࡔࡢࡣ࠿࡙ࡺࡶ࡭ࡤ࡮ࡓࡵࡷࡦࠩ௼"), l111lll1ll1l1ll_fwb_=l111lll1ll1l1ll_fwb_, infoLabels=l1l1ll1l11ll1l1ll_fwb_, IsPlayable=False)
elif mode ==l1l111ll1l1ll_fwb_ (u"ࠪࡗࡿࡻ࡫ࡢ࡬ࡘࡷࡺࡴࠧ௽"):
    l1l1l1ll11ll1l1ll_fwb_(ex_link)
    xbmc.executebuiltin(l1l111ll1l1ll_fwb_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠮ࠥࡴࠫࠪ௾")%  l1l1ll1ll1l1ll_fwb_({l1l111ll1l1ll_fwb_ (u"ࠬࡳ࡯ࡥࡧࠪ௿"): l1l111ll1l1ll_fwb_ (u"࠭ࡓࡻࡷ࡮ࡥ࡯࠭ఀ")}))
elif mode == l1l111ll1l1ll_fwb_ (u"ࠧࡔࡼࡸ࡯ࡦࡰࡕࡴࡷࡱࡅࡱࡲࠧఁ"):
    l1l1llll11ll1l1ll_fwb_()
    xbmc.executebuiltin(l1l111ll1l1ll_fwb_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠫࠩࡸ࠯ࠧం")%  l1l1ll1ll1l1ll_fwb_({l1l111ll1l1ll_fwb_ (u"ࠩࡰࡳࡩ࡫ࠧః"): l1l111ll1l1ll_fwb_ (u"ࠪࡗࡿࡻ࡫ࡢ࡬ࠪఄ")}))
elif mode == l1l111ll1l1ll_fwb_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫఅ"):
    pass
else:
    xbmcplugin.setResolvedUrl(l1l1lll11ll1l1ll_fwb_, False, xbmcgui.ListItem(path=l1l111ll1l1ll_fwb_ (u"ࠬ࠭ఆ")))
xbmcplugin.endOfDirectory(l1l1lll11ll1l1ll_fwb_)
