# -*- coding: utf-8 -*-
import sys
l1l1l11ll1l1l1_tvp_ = sys.version_info [0] == 2
l1lllll1l1l1l1_tvp_ = 2048
l1l1lllll1l1l1_tvp_ = 7
def l11l1l1l1l1_tvp_ (keyedStringLiteral):
    global l111111l1l1l1_tvp_
    stringNr = ord (keyedStringLiteral [-1])
    rotatedStringLiteral = keyedStringLiteral [:-1]
    rotationDistance = stringNr % len (rotatedStringLiteral)
    recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
    if l1l1l11ll1l1l1_tvp_:
        stringLiteral = unicode () .join ([unichr (ord (char) - l1lllll1l1l1l1_tvp_ - (charIndex + stringNr) % l1l1lllll1l1l1_tvp_) for charIndex, char in enumerate (recodedStringLiteral)])
    else:
        stringLiteral = str () .join ([chr (ord (char) - l1lllll1l1l1l1_tvp_ - (charIndex + stringNr) % l1l1lllll1l1l1_tvp_) for charIndex, char in enumerate (recodedStringLiteral)])
    return eval (stringLiteral)
import os,sys
import urllib,urllib2
import re,json
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import check
import resources.lib.l11l1lll1l1l1_tvp_ as l1ll1l1ll1l1l1_tvp_
import time
l1l1ll1l1l1_tvp_        = sys.argv[0]
l1l11llll1l1l1_tvp_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l1llllll1l1l1_tvp_        = xbmcaddon.Addon()
l11lll1ll1l1l1_tvp_     = l1llllll1l1l1_tvp_.getAddonInfo(l11l1l1l1l1_tvp_ (u"ࠫ࡮ࡪࠧࠀ"))
PATH        = l1llllll1l1l1_tvp_.getAddonInfo(l11l1l1l1l1_tvp_ (u"ࠬࡶࡡࡵࡪࠪࠁ"))
l1111l1l1l1l1_tvp_    = xbmc.translatePath(l1llllll1l1l1_tvp_.getAddonInfo(l11l1l1l1l1_tvp_ (u"࠭ࡰࡳࡱࡩ࡭ࡱ࡫ࠧࠂ"))).decode(l11l1l1l1l1_tvp_ (u"ࠧࡶࡶࡩ࠱࠽࠭ࠃ"))
l11lll11l1l1l1_tvp_   = PATH+l11l1l1l1l1_tvp_ (u"ࠨ࠱ࡵࡩࡸࡵࡵࡳࡥࡨࡷ࠴࠭ࠄ")
l1lll1ll1l1l1_tvp_    = os.path.join(l1111l1l1l1l1_tvp_,l11l1l1l1l1_tvp_ (u"ࠩࡩࡥࡻࡵࡲࡪࡶࡨࡷ࠳ࡰࡳࡰࡰࠪࠅ"))
tm=time.gmtime()
def l1ll111l1l1l1_tvp_(url):
    req = urllib2.Request(url)
    req.add_header(l11l1l1l1l1_tvp_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧࠆ"), l11l1l1l1l1_tvp_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠷࠰࠴࠿ࠥࡸࡶ࠻࠴࠵࠲࠵࠯ࠠࡈࡧࡦ࡯ࡴ࠵࠲࠱࠳࠳࠴࠶࠶࠱ࠡࡈ࡬ࡶࡪ࡬࡯ࡹ࠱࠵࠶࠳࠶ࠧࠇ"))
    response = urllib2.urlopen(req)
    l1llll11l1l1l1_tvp_ = response.read()
    response.close()
    return l1llll11l1l1l1_tvp_
def l1l1llll1l1l1_tvp_(name, url, mode, l1llll1l1l1l1_tvp_=None, infoLabels=False, IsPlayable=True,fanart=None):
    u = l1ll1l1l1_tvp_({l11l1l1l1l1_tvp_ (u"ࠬࡳ࡯ࡥࡧࠪࠈ"): mode, l11l1l1l1l1_tvp_ (u"࠭ࡦࡰ࡮ࡧࡩࡷࡴࡡ࡮ࡧࠪࠉ"): name, l11l1l1l1l1_tvp_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨࠊ") : url})
    if l1llll1l1l1l1_tvp_==None:
        l1llll1l1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬࠋ")
    l1l1l1l1l1l1l1_tvp_ = xbmcgui.ListItem(name, iconImage=l1llll1l1l1l1_tvp_, thumbnailImage=l1llll1l1l1l1_tvp_)
    l1l1l1l1l1l1l1_tvp_.setArt({ l11l1l1l1l1_tvp_ (u"ࠩ࡬ࡧࡴࡴࠧࠌ") : l1llll1l1l1l1_tvp_})
    if not infoLabels:
        infoLabels={l11l1l1l1l1_tvp_ (u"ࠥࡘ࡮ࡺ࡬ࡦࠤࠍ"): name}
    l1l1l1l1l1l1l1_tvp_.setInfo(type=l11l1l1l1l1_tvp_ (u"࡛ࠦ࡯ࡤࡦࡱࠥࠎ"), infoLabels=infoLabels)
    if IsPlayable:
        l1l1l1l1l1l1l1_tvp_.setProperty(l11l1l1l1l1_tvp_ (u"ࠬࡏࡳࡑ࡮ࡤࡽࡦࡨ࡬ࡦࠩࠏ"), l11l1l1l1l1_tvp_ (u"࠭ࡴࡳࡷࡨࠫࠐ"))
    if fanart:
        l1l1l1l1l1l1l1_tvp_.setProperty(l11l1l1l1l1_tvp_ (u"ࠧࡧࡣࡱࡥࡷࡺ࡟ࡪ࡯ࡤ࡫ࡪ࠭ࠑ"),fanart)
        l1l1l1l1l1l1l1_tvp_.setArt({ l11l1l1l1l1_tvp_ (u"ࠨࡲࡲࡷࡹ࡫ࡲࠨࠒ"): fanart, l11l1l1l1l1_tvp_ (u"ࠩࡩࡥࡳࡧࡲࡵࠩࠓ"):fanart,l11l1l1l1l1_tvp_ (u"ࠪࡦࡦࡴ࡮ࡦࡴࠪࠔ"):fanart})
    ok = xbmcplugin.addDirectoryItem(handle=l1l11llll1l1l1_tvp_, url=u, listitem=l1l1l1l1l1l1l1_tvp_)
    return ok
l111llll1l1l1_tvp_ = lambda x,y: ord(x)+6*y if ord(x)%2 else ord(x)
l11l11l1l1l1_tvp_ = lambda l111ll1l1l1l1_tvp_: l11l1l1l1l1_tvp_ (u"ࠫࠬࠕ").join([chr(l111llll1l1l1_tvp_(x,1) ) for x in l111ll1l1l1l1_tvp_.encode(l11l1l1l1l1_tvp_ (u"ࠬࡨࡡࡴࡧ࠹࠸ࠬࠖ")).strip()])
l1ll1ll1l1l1l1_tvp_ = lambda l111ll1l1l1l1_tvp_: l11l1l1l1l1_tvp_ (u"࠭ࠧࠗ").join([chr(l111llll1l1l1_tvp_(x,-1) ) for x in l111ll1l1l1l1_tvp_]).decode(l11l1l1l1l1_tvp_ (u"ࠧࡣࡣࡶࡩ࠻࠺ࠧ࠘"))
def l1lll11l1l1l1_tvp_(name,ex_link=None,l11llll1l1l1_tvp_=1,mode=l11l1l1l1l1_tvp_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࠙"),contextO=[l11l1l1l1l1_tvp_ (u"ࠩࡉࡣࡆࡊࡄࠨࠚ")],iconImage=l11l1l1l1l1_tvp_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧࠛ"),fanart=l11l1l1l1l1_tvp_ (u"ࠫࠬࠜ")):
    url = l1ll1l1l1_tvp_({l11l1l1l1l1_tvp_ (u"ࠬࡳ࡯ࡥࡧࠪࠝ"): mode, l11l1l1l1l1_tvp_ (u"࠭ࡦࡰ࡮ࡧࡩࡷࡴࡡ࡮ࡧࠪࠞ"): name, l11l1l1l1l1_tvp_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨࠟ") : ex_link,l11l1l1l1l1_tvp_ (u"ࠨࡲࡤ࡫ࡪ࠭ࠠ") :l11llll1l1l1_tvp_})
    l11lll1l1l1_tvp_ = xbmcgui.ListItem(name, iconImage=iconImage)
    l11lll1l1l1_tvp_.setArt({ l11l1l1l1l1_tvp_ (u"ࠩ࡬ࡧࡴࡴࠧࠡ") : iconImage})
    if fanart:
        l11lll1l1l1_tvp_.setProperty(l11l1l1l1l1_tvp_ (u"ࠪࡪࡦࡴࡡࡳࡶࡢ࡭ࡲࡧࡧࡦࠩࠢ"), fanart )
        l11lll1l1l1_tvp_.setArt({ l11l1l1l1l1_tvp_ (u"ࠫࡵࡵࡳࡵࡧࡵࠫࠣ"): fanart, l11l1l1l1l1_tvp_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࠬࠤ"):fanart,l11l1l1l1l1_tvp_ (u"࠭ࡢࡢࡰࡱࡩࡷ࠭ࠥ"):iconImage})
    content=urllib.quote_plus(json.dumps({l11l1l1l1l1_tvp_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࠦ"):name,l11l1l1l1l1_tvp_ (u"ࠨ࡫ࡧࠫࠧ"):ex_link,l11l1l1l1l1_tvp_ (u"ࠩ࡬ࡱ࡬࠭ࠨ"):iconImage}))
    l11llll1l1l1l1_tvp_=[]
    if l11l1l1l1l1_tvp_ (u"ࠪࡊࡤࡇࡄࡅࠩࠩ") in contextO:
        l11llll1l1l1l1_tvp_.append((l11l1l1l1l1_tvp_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡱ࡯ࡧࡩࡶࡥࡰࡺ࡫࡝ࡅࡱࡧࡥ࡯ࠦࡤࡰ࡚ࠢࡽࡧࡸࡡ࡯ࡻࡦ࡬ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠪ"), l11l1l1l1l1_tvp_ (u"ࠬࡘࡵ࡯ࡒ࡯ࡹ࡬࡯࡮ࠩࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࠩࡸࡅ࡭ࡰࡦࡨࡁ࡫ࡧࡶࡰࡴ࡬ࡸࡪࡹࡁࡅࡆࠩࡩࡽࡥ࡬ࡪࡰ࡮ࡁࠪࡹࠩࠨࠫ")%(l11lll1ll1l1l1_tvp_,content)))
    if l11l1l1l1l1_tvp_ (u"࠭ࡆࡠࡔࡈࡑࠬࠬ") in contextO:
        l11llll1l1l1l1_tvp_.append((l11l1l1l1l1_tvp_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡ࡚ࡹࡵॅࠢࡽࠤ࡜ࡿࡢࡳࡣࡱࡽࡨ࡮࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ࠭"), l11l1l1l1l1_tvp_ (u"ࠨࡔࡸࡲࡕࡲࡵࡨ࡫ࡱࠬࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴࡁࡰࡳࡩ࡫࠽ࡧࡣࡹࡳࡷ࡯ࡴࡦࡵࡕࡉࡒࠬࡥࡹࡡ࡯࡭ࡳࡱ࠽ࠦࡵࠬࠫ࠮")%(l11lll1ll1l1l1_tvp_,content)))
    if l11l1l1l1l1_tvp_ (u"ࠩࡉࡣࡉࡋࡌࠨ࠯") in contextO:
        l11llll1l1l1l1_tvp_.append((l11l1l1l1l1_tvp_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࡖࡵࡸैࠥ࡝ࡳࡻࡻࡶࡸࡰࡵ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ࠰"), l11l1l1l1l1_tvp_ (u"ࠫࡗࡻ࡮ࡑ࡮ࡸ࡫࡮ࡴࠨࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷࡄࡳ࡯ࡥࡧࡀࡪࡦࡼ࡯ࡳ࡫ࡷࡩࡸࡘࡅࡎࠨࡨࡼࡤࡲࡩ࡯࡭ࡀࡥࡱࡲࠩࠨ࠱")%(l11lll1ll1l1l1_tvp_)))
    l11lll1l1l1_tvp_.addContextMenuItems(l11llll1l1l1l1_tvp_, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=l1l11llll1l1l1_tvp_, url=url,listitem=l11lll1l1l1_tvp_, isFolder=True)
if not os.path.exists(l11l1l1l1l1_tvp_ (u"ࠬ࠵ࡨࡰ࡯ࡨ࠳ࡴࡹ࡭ࡤࠩ࠲")):
    try:    l1l11l1l1l1_tvp_,l1l1l1l1l1l1_tvp_,l1ll1l1l1l1_tvp_ = l1ll1ll1l1l1l1_tvp_(l1llllll1l1l1_tvp_.getSetting(l11l1l1l1l1_tvp_ (u"࠭࡫ࡰࡦࠪ࠳"))).split(l11l1l1l1l1_tvp_ (u"ࠧ࠻ࠩ࠴"))
    except: l1l11l1l1l1_tvp_,l1l1l1l1l1l1_tvp_,l1ll1l1l1l1_tvp_ =  [l11l1l1l1l1_tvp_ (u"ࠨ࠯࠴ࠫ࠵"),l11l1l1l1l1_tvp_ (u"ࠩࠪ࠶"),l11l1l1l1l1_tvp_ (u"ࠪ࠱࠶࠭࠷")]
    if int(l1l11l1l1l1_tvp_) != tm.tm_hour:
        try:    l1lllllll1l1l1_tvp_ = re.findall(l11l1l1l1l1_tvp_ (u"ࠫࡐࡕࡄ࠻ࠢࠫ࠲࠯ࡅࠩ࡝ࡰࠪ࠸"),urllib2.urlopen(l11l1l1l1l1_tvp_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡲࡢࡹ࠱࡫࡮ࡺࡨࡶࡤࡸࡷࡪࡸࡣࡰࡰࡷࡩࡳࡺ࠮ࡤࡱࡰ࠳ࡷࡧ࡭ࡪࡥࡶࡴࡦ࠵࡫ࡰࡦ࡬࠳ࡲࡧࡳࡵࡧࡵ࠳ࡗࡋࡁࡅࡏࡈ࠲ࡲࡪࠧ࠹")).read())[0].strip(l11l1l1l1l1_tvp_ (u"࠭ࠪࠨ࠺"))
        except: l1lllllll1l1l1_tvp_ = l11l1l1l1l1_tvp_ (u"ࠧࠨ࠻")
        l1l1lll1l1l1l1_tvp_ = l11l11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠩࠨࡨ࠿ࠫࡳ࠻ࠧࡧࠫ࠽")%(tm.tm_hour,l1lllllll1l1l1_tvp_,tm.tm_min))
        l1llllll1l1l1_tvp_.setSetting(l11l1l1l1l1_tvp_ (u"ࠪ࡯ࡴࡪࠧ࠾"),l1l1lll1l1l1l1_tvp_)
import ramic as l1111ll1l1l1_tvp_
def l1ll1l1l1_tvp_(query):
    return l1l1ll1l1l1_tvp_ + l11l1l1l1l1_tvp_ (u"ࠨࡁࠪࡃ") + urllib.urlencode(query)
def l11l1ll1l1l1_tvp_(name,l1lll1l1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺ࡭ࡦࡪ࡯࡮ࡱࡶࡧ࡮࠴ࡴࡷࡲ࠱ࡴࡱ࠵ࠧࡄ")):
    content = l1ll111l1l1l1_tvp_(l1lll1l1l1l1_tvp_)
    l1lll1l1l1l1l1_tvp_ = re.compile(l11l1l1l1l1_tvp_ (u"ࠪࡨࡦࡺࡡ࠮ࡸ࡬ࡨࡪࡵ࠭ࡪࡦࡀࠦ࠭࠴ࠫࡀࠫࠥࠫࡅ"), re.DOTALL).findall(content)[0]
    l111lll1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼ࡯ࡡࡥࡱࡰࡳࡸࡩࡩ࠯ࡶࡹࡴ࠳ࡶ࡬࠰ࡵࡨࡷࡸ࠵ࡴࡷࡲ࡯ࡥࡾ࡫ࡲ࠯ࡲ࡫ࡴࡄࠬ࡯ࡣ࡬ࡨࡧࡹࡥࡩࡥ࠿ࠪࡆ") + l1lll1l1l1l1l1_tvp_
    content = l1ll111l1l1l1_tvp_(l111lll1l1l1_tvp_)
    l1l1111l1l1l1_tvp_ = re.compile(l11l1l1l1l1_tvp_ (u"ࠧࡶ࡯ࡴࡶࡨࡶ࠿࠭ࠨ࠯࠭ࡂ࠭ࡡ࠭ࠢࡇ"), re.DOTALL).findall(content)
    l1l1111l1l1l1_tvp_ = l1l1111l1l1l1_tvp_[0] if l1l1111l1l1l1_tvp_ else l11l1l1l1l1_tvp_ (u"࠭ࠧࡈ")
    l11llllll1l1l1_tvp_ = re.compile(l11l1l1l1l1_tvp_ (u"ࠧࡵ࡫ࡷࡰࡪࡀࠠࠣࠪ࠱࠯ࡄ࠯ࠢ࠭ࠩࡉ"), re.DOTALL).findall(content)
    l11llllll1l1l1_tvp_ = l11llllll1l1l1_tvp_[0] if l11llllll1l1l1_tvp_ else l11l1l1l1l1_tvp_ (u"ࠨࠩࡊ")
    l1ll1l11l1l1l1_tvp_ = re.compile(l11l1l1l1l1_tvp_ (u"ࠤ࠴࠾ࢀࡹࡲࡤ࠼࡟ࠫ࠭࠴ࠫࡀࠫ࡟ࠫࠧࡋ"), re.DOTALL).findall(content)
    if not l1ll1l11l1l1l1_tvp_:
        l1ll1l11l1l1l1_tvp_ = re.compile(l11l1l1l1l1_tvp_ (u"ࠥ࠴࠿ࢁࡳࡳࡥ࠽ࡠࠬ࠮࠮ࠬࡁࠬࡠࠬࠨࡌ"), re.DOTALL).findall(content)
        if l1ll1l11l1l1l1_tvp_:
           l1ll1l11l1l1l1_tvp_ = l1ll1l1ll1l1l1_tvp_.l1lll1lll1l1l1_tvp_(l1ll1l11l1l1l1_tvp_[0])
        l11llllll1l1l1_tvp_ += l11l1l1l1l1_tvp_ (u"ࠫࠥ࠮ࡌࡪࡸࡨ࠭ࠥ࠭ࡍ")
    for l1ll11l1l1l1l1_tvp_ in l1ll1l11l1l1l1_tvp_:
        url = l1ll11l1l1l1l1_tvp_
        l1l1l1ll1l1l1_tvp_ = l11l1l1l1l1_tvp_ (u"ࠬ࠭ࡎ")
        if isinstance(l1ll11l1l1l1l1_tvp_,dict):
            url = l1ll11l1l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"࠭ࡵࡳ࡮ࠪࡏ"),l1ll11l1l1l1l1_tvp_)
            l1l1l1ll1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠧ࡜ࡄࡠࠫࡐ")+l1ll11l1l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࡑ"),l11l1l1l1l1_tvp_ (u"ࠩࠪࡒ"))+l11l1l1l1l1_tvp_ (u"ࠪ࡟࠴ࡈ࡝ࠨࡓ")
        l11lll1l1l1_tvp_ = xbmcgui.ListItem(name +l11l1l1l1l1_tvp_ (u"ࠫࠥ࠭ࡔ") + l11llllll1l1l1_tvp_ + l1l1l1ll1l1l1_tvp_, iconImage=l1l1111l1l1l1_tvp_)
        l11lll1l1l1_tvp_.setArt({ l11l1l1l1l1_tvp_ (u"ࠬࡶ࡯ࡴࡶࡨࡶࠬࡕ"): l1l1111l1l1l1_tvp_, l11l1l1l1l1_tvp_ (u"࠭ࡴࡩࡷࡰࡦࠬࡖ") : l1l1111l1l1l1_tvp_, l11l1l1l1l1_tvp_ (u"ࠧࡪࡥࡲࡲࠬࡗ") : l1l1111l1l1l1_tvp_ ,l11l1l1l1l1_tvp_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨࡘ"):l1l1111l1l1l1_tvp_,l11l1l1l1l1_tvp_ (u"ࠩࡥࡥࡳࡴࡥࡳ࡙ࠩ"):l1l1111l1l1l1_tvp_})
        xbmcplugin.addDirectoryItem(handle=l1l11llll1l1l1_tvp_, url=url, listitem=l11lll1l1l1_tvp_)
    if fname.startswith(l11l1l1l1l1_tvp_ (u"࡛ࠪ࡮ࡧࡤࡰ࡯࡚ࠪ")):
        l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠫࡆࡸࡣࡩ࡫ࡺࡹࡲࠦࡗࡪࡣࡧࡳࡲࡵज़ࡤ࡫࡛ࠪ"),ex_link=l11l1l1l1l1_tvp_ (u"ࠬ࠹࠰࠺࠲࠷࠸࠻࠻ࠧ࡜"),mode=l11l1l1l1l1_tvp_ (u"࠭ࡶࡰࡦࡗ࡚ࡕ࠭࡝"),iconImage=l11l1l1l1l1_tvp_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࠱ࡸࡻࡶ࠮ࡱ࡮࠲࡭ࡲࡧࡧࡦࡵ࠲࠷࠴࠽࠯ࡣ࠱ࡸ࡭ࡩࡥ࠳࠸ࡤࡥ࠷࠷ࡧࡦ࠶ࡦ࠹ࡥ࠼࠾ࡥࡣ࠳࠴ࡪ࠵ࡩࡥࡣ࠺࠸ࡩ࠷࡫࠶ࡢࡥ࠳࠵࠹࠺࠷࠺࠶࠹࠼࠵࠿࠴࠲࠵ࡢࡻ࡮ࡪࡴࡩࡡ࠵࠵࠽ࡥࡰ࡭ࡣࡼࡣ࠵ࡥࡰࡰࡵࡢ࠴ࡤ࡭ࡳࡠ࠲࠱࡮ࡵ࡭ࠧ࡞"))
    elif fname.startswith(l11l1l1l1l1_tvp_ (u"ࠨࡖࡨࡰࡪ࡫ࠧ࡟")):
        l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠩࡄࡶࡨ࡮ࡩࡸࡷࡰࠤ࡙࡫࡬ࡦࡧࡻࡴࡷ࡫ࡳࡴࠩࡠ"),ex_link=l11l1l1l1l1_tvp_ (u"ࠪ࠷࠵࠿࠰࠵࠶࠹࠽ࠬࡡ"),mode=l11l1l1l1l1_tvp_ (u"ࠫࡻࡵࡤࡕࡘࡓࠫࡢ"),iconImage=l11l1l1l1l1_tvp_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳ࠯ࡶࡹࡴ࠳ࡶ࡬࠰࡫ࡰࡥ࡬࡫ࡳ࠰࠶࠲࠵࠴࠺࠯ࡶ࡫ࡧࡣ࠹࠷࠴࠷࠵࠳࠴࠶࠶ࡦࡥࡤ࠵࠼࡫ࡨࡡ࠴ࡣ࠴ࡨࡦࡨ࠵ࡤ࠳࠶ࡨ࠸࠷࠱࠱࠳࠷࠸࠽࠶࠱࠱࠴࠸࠽࠽࠺࠱ࡠࡹ࡬ࡨࡹ࡮࡟࠳࠳࠻ࡣࡵࡲࡡࡺࡡ࠳ࡣࡵࡵࡳࡠ࠲ࡢ࡫ࡸࡥ࠰࠯࡬ࡳ࡫ࠬࡣ"))
    elif fname.startswith(l11l1l1l1l1_tvp_ (u"࠭ࡐࡢࡰࡲࡶࠬࡤ")):
        l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠧࡂࡴࡦ࡬࡮ࡽࡵ࡮ࠢࡓࡥࡳࡵࡲࡢ࡯ࡤࠫࡥ"),ex_link=l11l1l1l1l1_tvp_ (u"ࠨ࠵࠳࠽࠵࠺࠴࠸࠷ࠪࡦ"),mode=l11l1l1l1l1_tvp_ (u"ࠩࡹࡳࡩ࡚ࡖࡑࠩࡧ"),iconImage=l11l1l1l1l1_tvp_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࠴ࡴࡷࡲ࠱ࡴࡱ࠵ࡩ࡮ࡣࡪࡩࡸ࠵࠰࠰࠲࠲࠺࠴ࡻࡩࡥࡡ࠳࠴࠻࠿࠳࠴ࡤ࠵ࡨ࠻࠶࠳࠶࠷࠳ࡪ࠵ࡪࡣ࠱ࡧ࠻ࡦ࠽࠼ࡢࡧ࠸࠳࠸࠼࠻࠱࠵࠶࠻࠴࠶࠶࠱࠳࠻࠹࠺࠶ࡥࡷࡪࡦࡷ࡬ࡤ࠸࠱࠹ࡡࡳࡰࡦࡿ࡟࠱ࡡࡳࡳࡸࡥ࠰ࡠࡩࡶࡣ࠵࠴ࡪࡱࡩࠪࡨ"))
def l1ll11l1l1l1_tvp_(url=l11l1l1l1l1_tvp_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹࡼࡰࡴࡶࡵࡩࡦࡳ࠮ࡷࡱࡧ࠲ࡹࡼࡰ࠯ࡲ࡯ࠫࡩ")):
    data=l1ll111l1l1l1_tvp_(url)
    l1ll1llll1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡺࡶࡱࡵࡷࡶࡪࡧ࡭࠯ࡸࡲࡨ࠳ࡺࡶࡱ࠰ࡳࡰ࠴ࡹࡥࡴࡵ࠲ࡸࡻࡶ࡬ࡢࡻࡨࡶ࠳ࡶࡨࡱࡁࡲࡦ࡯࡫ࡣࡵࡡ࡬ࡨࡂࠫࡳࠣࡪ")
    l1ll1l1l1l1l1_tvp_ = re.compile(l11l1l1l1l1_tvp_ (u"࠭ࡤࡢࡶࡤ࠱ࡻ࡯ࡤࡦࡱ࠰࡭ࡩࡃ࡛࡝ࠩࠥࡡ࠭ࡢࡤࠬࠫ࡞ࡠࠬࠨ࡝࡝ࡵ࠮ࡸ࡮ࡺ࡬ࡦ࠿࡞ࡠࠬࠨ࡝ࠩ࠰࠭ࡃ࠮ࡡ࡜ࠨࠤࡠ࠲࠰ࡅ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾࡝࡟ࠫࠧࡣࠨ࠯ࠬࡂ࠭ࡠࡢࠧࠣ࡟ࠪ࡫"),re.DOTALL).findall(data)
    out=[]
    for id,title,l111l1l1l1_tvp_ in l1ll1l1l1l1l1_tvp_:
        out.append({l11l1l1l1l1_tvp_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭࡬"):title.decode(l11l1l1l1l1_tvp_ (u"ࠨࡷࡷࡪ࠲࠾ࠧ࡭")),l11l1l1l1l1_tvp_ (u"ࠩ࡬ࡱ࡬࠭࡮"):l111l1l1l1_tvp_,
                    l11l1l1l1l1_tvp_ (u"ࠪࡹࡷࡲࠧ࡯"):l1ll1llll1l1l1_tvp_ % id})
    return out
def l1ll11lll1l1l1_tvp_(ex_link=l11l1l1l1l1_tvp_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹࡼࡰࡴࡶࡵࡩࡦࡳ࠮ࡷࡱࡧ࠲ࡹࡼࡰ࠯ࡲ࡯࠳ࡸ࡫ࡳࡴ࠱ࡷࡺࡵࡲࡡࡺࡧࡵ࠲ࡵ࡮ࡰࡀࡱࡥ࡮ࡪࡩࡴࡠ࡫ࡧࡁ࠸࠺࠸࠴࠴࠹࠼࠻࠭ࡰ")):
    data=l1ll111l1l1l1_tvp_(ex_link)
    l1ll1ll1l1l1_tvp_ = re.compile(l11l1l1l1l1_tvp_ (u"ࠧ࠶࠺ࡼࡵࡵࡧ࠿࠭ࠨ࠯ࠬࡂ࠭ࠬࠨࡱ"), re.DOTALL).findall(data)
    if l1ll1ll1l1l1_tvp_:
        listitem = xbmcgui.ListItem(path=l1ll1ll1l1l1_tvp_[0])
        xbmcplugin.setResolvedUrl(l1l11llll1l1l1_tvp_, True, listitem)
def l11l1l1l1l1l1_tvp_():
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"࠭ࡗࡪࡣࡧࡳࡲࡵज़ࡤ࡫ࠪࡲ"),ex_link=l11l1l1l1l1_tvp_ (u"ࠧ࠳࠴࠹࠻࠷࠶࠲࠺ࠩࡳ"),mode=l11l1l1l1l1_tvp_ (u"ࠨࡸࡲࡨ࡙࡜ࡐࠨࡴ"),iconImage=l11l1l1l1l1_tvp_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࠳ࡺࡶࡱ࠰ࡳࡰ࠴࡯࡭ࡢࡩࡨࡷ࠴࠹࠯࠸࠱ࡥ࠳ࡺ࡯ࡤࡠ࠵࠺ࡦࡧ࠹࠲ࡢࡨ࠸ࡨ࠻ࡧ࠷࠹ࡧࡥ࠵࠶࡬࠰ࡤࡧࡥ࠼࠺࡫࠲ࡦ࠸ࡤࡧ࠵࠷࠴࠵࠹࠼࠸࠻࠾࠰࠺࠶࠴࠷ࡤࡽࡩࡥࡶ࡫ࡣ࠷࠷࠸ࡠࡲ࡯ࡥࡾࡥ࠰ࡠࡲࡲࡷࡤ࠶࡟ࡨࡵࡢ࠴࠳ࡰࡰࡨࠩࡵ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠪࡔࡦࡴ࡯ࡳࡣࡰࡥࠬࡶ"),ex_link=l11l1l1l1l1_tvp_ (u"ࠫ࠷࠸࠶࠸࠴࠳࠵࠼࠭ࡷ"),mode=l11l1l1l1l1_tvp_ (u"ࠬࡼ࡯ࡥࡖ࡙ࡔࠬࡸ"),iconImage=l11l1l1l1l1_tvp_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴ࠰ࡷࡺࡵ࠴ࡰ࡭࠱࡬ࡱࡦ࡭ࡥࡴ࠱࠳࠳࠵࠵࠶࠰ࡷ࡬ࡨࡤ࠶࠰࠷࠻࠶࠷ࡧ࠸ࡤ࠷࠲࠶࠹࠺࠶ࡦ࠱ࡦࡦ࠴ࡪ࠾ࡢ࠹࠸ࡥࡪ࠻࠶࠴࠸࠷࠴࠸࠹࠾࠰࠲࠲࠴࠶࠾࠼࠶࠲ࡡࡺ࡭ࡩࡺࡨࡠ࠴࠴࠼ࡤࡶ࡬ࡢࡻࡢ࠴ࡤࡶ࡯ࡴࡡ࠳ࡣ࡬ࡹ࡟࠱࠰࡭ࡴ࡬࠭ࡹ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠧࡕࡧ࡯ࡩࡪࡾࡰࡳࡧࡶࡷࠬࡺ"),ex_link=l11l1l1l1l1_tvp_ (u"ࠨ࠴࠵࠺࠼࠸࠰࠵࠳ࠪࡻ"),mode=l11l1l1l1l1_tvp_ (u"ࠩࡹࡳࡩ࡚ࡖࡑࠩࡼ"),iconImage=l11l1l1l1l1_tvp_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࠴ࡴࡷࡲ࠱ࡴࡱ࠵ࡩ࡮ࡣࡪࡩࡸ࠵࠴࠰࠳࠲࠸࠴ࡻࡩࡥࡡ࠷࠵࠹࠼࠳࠱࠲࠴࠴࡫ࡪࡢ࠳࠺ࡩࡦࡦ࠹ࡡ࠲ࡦࡤࡦ࠺ࡩ࠱࠴ࡦ࠶࠵࠶࠶࠱࠵࠶࠻࠴࠶࠶࠲࠶࠻࠻࠸࠶ࡥࡷࡪࡦࡷ࡬ࡤ࠸࠱࠹ࡡࡳࡰࡦࡿ࡟࠱ࡡࡳࡳࡸࡥ࠰ࡠࡩࡶࡣ࠵࠴ࡪࡱࡩࠪࡽ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠫࡘ࡫ࡲࡸ࡫ࡶࠤࡎࡴࡦࡰࠩࡾ"),ex_link=l11l1l1l1l1_tvp_ (u"ࠬ࠸࠲࠷࠹࠵࠴࠼࠿ࠧࡿ"),mode=l11l1l1l1l1_tvp_ (u"࠭ࡶࡰࡦࡗ࡚ࡕ࠭ࢀ"),iconImage=l11l1l1l1l1_tvp_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࠱ࡸࡻࡶ࠮ࡱ࡮࠲࡭ࡲࡧࡧࡦࡵ࠲࠹࠴ࡩ࠯࠴࠱ࡸ࡭ࡩࡥ࠵ࡤ࠵࠻ࡪ࠶ࡪࡤࡥࡦࡥࡨ࠺࠽࠶ࡤ࠲ࡧ࠷ࡧ࠹ࡤ࠱ࡦࡨ࠷࠸ࡨࡥ࠷ࡥ࠷࠵࠹࠺࠸࠱࠳࠳࠸࠵࠽࠱࠹࠳ࡢࡻ࡮ࡪࡴࡩࡡ࠵࠵࠽ࡥࡰ࡭ࡣࡼࡣ࠵ࡥࡰࡰࡵࡢ࠴ࡤ࡭ࡳࡠ࠲࠱ࡴࡳ࡭ࠧࢁ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠨࡃࡪࡶࡴࡨࡩࡻࡰࡨࡷࠬࢂ"),ex_link=l11l1l1l1l1_tvp_ (u"ࠩ࠵࠶࠻࠽࠲࠲࠲࠸ࠫࢃ"),mode=l11l1l1l1l1_tvp_ (u"ࠪࡺࡴࡪࡔࡗࡒࠪࢄ"),iconImage=l11l1l1l1l1_tvp_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹ࠮ࡵࡸࡳ࠲ࡵࡲ࠯ࡪ࡯ࡤ࡫ࡪࡹ࠯ࡣ࠱࠺࠳࠽࠵ࡵࡪࡦࡢࡦ࠼࠾ࡤ࠹ࡤ࠷࠺࠺࠾ࡢࡢ࠷࠳࠼࠼࠻࠸࠲࠳࠹࠶࠹࠸ࡤ࠵࠻ࡧ࠺ࡪ࠼ࡢ࠲࠶࠷࠼࠵࠷࠰࠶࠵࠺࠸࠻࠶࡟ࡸ࡫ࡧࡸ࡭ࡥ࠲࠲࠺ࡢࡴࡱࡧࡹࡠ࠲ࡢࡴࡴࡹ࡟࠱ࡡࡪࡷࡤ࠶࠮࡫ࡲࡪࠫࢅ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠬࡓࡩ࡯छॅࡥࠥࡪࡷࡶࡦࡽ࡭ࡪࡹࡴࡢࠩࢆ"),ex_link=l11l1l1l1l1_tvp_ (u"࠭࠲࠳࠸࠺࠷࠾࠽࠱ࠨࢇ"),mode=l11l1l1l1l1_tvp_ (u"ࠧࡷࡱࡧࡘ࡛ࡖࠧ࢈"),iconImage=l11l1l1l1l1_tvp_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࠲ࡹࡼࡰ࠯ࡲ࡯࠳࡮ࡳࡡࡨࡧࡶ࠳࡫࠵࠹࠰࠳࠲ࡹ࡮ࡪ࡟ࡧ࠻࠴ࡪ࠸࠸ࡥ࠺࠸࠴ࡩࡧ࠶࠳࠱࠻࠴࠼࠷࡬࠶࠱࠳࠷࠺ࡩ࠶࠷࠺࠻ࡧ࠴࠶࠺࠴࠹࠲࠴࠴࠼࠷࠹࠷࠴࠸ࡣࡼ࡯ࡤࡵࡪࡢ࠶࠶࠾࡟ࡱ࡮ࡤࡽࡤ࠶࡟ࡱࡱࡶࡣ࠵ࡥࡧࡴࡡ࠳࠲ࡵࡴࡧࠨࢉ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠩࡓࡳࠥࡶࡲࡰࡵࡷࡹ࠳ࠦࡐࡳࡱࡪࡶࡦࡳࠠࡕࡱࡰࡥࡸࢀࡡࠡࡕࡨ࡯࡮࡫࡬ࡴ࡭࡬ࡩ࡬ࡵࠧࢊ"),ex_link=l11l1l1l1l1_tvp_ (u"ࠪ࠽࠺࠸࠵࠺࠲࠸ࠫࢋ"),mode=l11l1l1l1l1_tvp_ (u"ࠫࡻࡵࡤࡕࡘࡓࠫࢌ"),iconImage=l11l1l1l1l1_tvp_ (u"ࠬ࠭ࢍ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"࠭ࡐࡰ࡮࡬ࡸࡾࡱࡡࠡࡲࡵࡾࡾࠦ࡫ࡢࡹ࡬ࡩࠬࢎ"),ex_link=l11l1l1l1l1_tvp_ (u"ࠧ࠳࠸࠵࠹࠹࠽࠶ࠨ࢏"),mode=l11l1l1l1l1_tvp_ (u"ࠨࡸࡲࡨ࡙࡜ࡐࠨ࢐"),iconImage=l11l1l1l1l1_tvp_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶ࠲ࡹࡼࡰ࠯ࡲ࡯࠳࡮ࡳࡡࡨࡧࡶ࠳࠷࠵࠱࠰࠹࠲ࡹ࡮ࡪ࡟࠳࠳࠺ࡧࡧ࡬࠳࠱࠹ࡤ࠻࠾ࡧࡣ࠶࠷ࡨ࠻ࡧ࠻ࡣ࠵࠺࠶࠼࠾ࡧ࠵࠺ࡤ࠹ࡦ࠶࠸࠸࠷࠶࠹࠷࠵࠺࠶࠹࠵࠷ࡣࡼ࡯ࡤࡵࡪࡢ࠶࠶࠾࡟ࡱ࡮ࡤࡽࡤ࠶࡟ࡱࡱࡶࡣ࠵ࡥࡧࡴࡡ࠳࠲࡯ࡶࡧࠨ࢑"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠪࡔࡺࡨ࡬ࡪࡥࡼࡷࡹࡿ࡫ࡢࠢࡑࡥ࡯ࡴ࡯ࡸࡵࡽࡩࠬ࢒"),ex_link=l11l1l1l1l1_tvp_ (u"ࠫ࠽࠹࠰࠷࠶࠴࠹ࠬ࢓"),mode=l11l1l1l1l1_tvp_ (u"ࠬࡼ࡯ࡥࡖ࡙ࡔࠬ࢔"),iconImage=l11l1l1l1l1_tvp_ (u"࠭ࠧ࢕"))
def l1ll1lll1l1l1_tvp_():
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠧࡕࡑࡓࠤ࠶࠶ࠧ࢖"),ex_link=l11l1l1l1l1_tvp_ (u"ࠨ࠳࠶࠸࠷࠶࠳࠺ࠩࢗ"),mode=l11l1l1l1l1_tvp_ (u"ࠩࡹࡳࡩ࡚ࡖࡑࠩ࢘"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠪࡗࡰ࡫ࡣࡻࡧ࢙ࠪ"),ex_link=l11l1l1l1l1_tvp_ (u"ࠫ࠽࠾࠳ࠨ࢚"),mode=l11l1l1l1l1_tvp_ (u"ࠬࡼ࡯ࡥࡖ࡙ࡔ࢛ࠬ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"࠭ࡆࡦࡵࡷ࡭ࡼࡧ࡬ࡦࠩ࢜"),ex_link=l11l1l1l1l1_tvp_ (u"ࠧ࠵࠻࠻࠶࠵࠸࠴ࠨ࢝"),mode=l11l1l1l1l1_tvp_ (u"ࠨࡸࡲࡨ࡙࡜ࡐࠨ࢞"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠩࡗࡩࡷࡧࡺࠡࡑࡪࡰࡦࡪࡡ࡯ࡧࠪ࢟"),ex_link=l11l1l1l1l1_tvp_ (u"ࠪ࠹࠷࠼࠴࠳࠺࠺ࠫࢠ"),mode=l11l1l1l1l1_tvp_ (u"ࠫࡻࡵࡤࡕࡘࡓࠫࢡ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠬࡑࡡࡣࡣࡵࡩࡹࡵࡷࡺࠢࡎࡰࡺࡨࠠࡅࡹࣶ࡮ࡰ࡯ࠧࢢ"),ex_link=l11l1l1l1l1_tvp_ (u"࠭࠴࠱࠸࠹࠽࠶࠼ࠧࢣ"),mode=l11l1l1l1l1_tvp_ (u"ࠧࡷࡱࡧࡘ࡛ࡖࠧࢤ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠨࡆࡽ࡭ञࡱࡩࠡࡄࡲ࡫ࡺࠦࡪࡶॾࠣࡻࡪ࡫࡫ࡦࡰࡧࠫࢥ"),ex_link=l11l1l1l1l1_tvp_ (u"ࠩ࠴࠴࠷࠹࠷࠳࠹࠼ࠫࢦ"),mode=l11l1l1l1l1_tvp_ (u"ࠪࡺࡴࡪࡔࡗࡒࠪࢧ"),iconImage=l11l1l1l1l1_tvp_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸ࠴ࡴࡷࡲ࠱ࡴࡱ࠵ࡩ࡮ࡣࡪࡩࡸ࠵ࡢ࠰࠸࠲࠺࠴ࡻࡩࡥࡡࡥ࠺࠻࠶࠰࠷ࡧ࠼࠴࠶࠸࠹ࡢ࠶࠷ࡪ࠷࠸࠸ࡣࡣࡦࡧࡪࡨࡦࡢ࠴࠼࠹࠷࠺࠱࠵࠷࠹࠽࠸࠼࠱࠲࠴࠴࠵࠼ࡥࡷࡪࡦࡷ࡬ࡤ࠸࠱࠹ࡡࡳࡰࡦࡿ࡟࠱ࡡࡳࡳࡸࡥ࠰ࡠࡩࡶࡣ࠵࠴ࡪࡱࡩࠪࢨ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠬࡔࠠ࡫ࡣ࡮ࠤࡓ࡫࡯࡯ࣵࡺ࡯ࡦ࠭ࢩ"),ex_link=l11l1l1l1l1_tvp_ (u"࠭࠵࠸࠹࠸࠴࠷࠿ࠧࢪ"),mode=l11l1l1l1l1_tvp_ (u"ࠧࡷࡱࡧࡘ࡛ࡖࠧࢫ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠨࡍࡤࡦࡦࡸࡥࡵࡱॿࡩࡷࡩࡹࠨࢬ"),ex_link=l11l1l1l1l1_tvp_ (u"ࠩ࠵࠺࠷࠻࠷࠵࠵ࠪࢭ"),mode=l11l1l1l1l1_tvp_ (u"ࠪࡺࡴࡪࡔࡗࡒࠪࢮ"))
def l1ll1111l1l1l1_tvp_():
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"࡙ࠫࡸࡡ࡯ࡵࡰ࡭ࡸࡰࡥࠨࢯ"),ex_link=l11l1l1l1l1_tvp_ (u"ࠬ࠸࠳࠶࠹࠻࠸࠾࠹ࠧࢰ"),mode=l11l1l1l1l1_tvp_ (u"࠭ࡶࡰࡦࡗ࡚ࡕ࠭ࢱ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠧࡘ࡫ࡧࡩࡴ࠭ࢲ"),ex_link=l11l1l1l1l1_tvp_ (u"ࠨ࠴࠶࠹࠼࠾࠵࠱࠻ࠪࢳ"),mode=l11l1l1l1l1_tvp_ (u"ࠩࡹࡳࡩ࡚ࡖࡑࠩࢴ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠪࡈࡾࡹࡣࡺࡲ࡯࡭ࡳࡿࠧࢵ"),ex_link=l11l1l1l1l1_tvp_ (u"ࠫ࠷࠺࠰࠴࠷࠴࠹࠼࠭ࢶ"),mode=l11l1l1l1l1_tvp_ (u"ࠬࡼ࡯ࡥࡖ࡙ࡔࠬࢷ"))
def l111ll1l1l1_tvp_():
    protocol =  l1llllll1l1l1_tvp_.getSetting(l11l1l1l1l1_tvp_ (u"࠭ࡰࡳࡱࡷࡳࡨࡵ࡬ࠨࢸ"))
    l1l11l11l1l1l1_tvp_ = l1llllll1l1l1_tvp_.getSetting(l11l1l1l1l1_tvp_ (u"ࠧࡪࡲࡤࡨࡩࡸࡥࡴࡵࠪࢹ"))
    l11ll11l1l1l1_tvp_ = l1llllll1l1l1_tvp_.getSetting(l11l1l1l1l1_tvp_ (u"ࠨ࡫ࡳࡴࡴࡸࡴࠨࢺ"))
    if l11l1l1l1l1_tvp_ (u"ࠩ࡫ࡸࡹࡶࠧࢻ") in protocol and l11ll11l1l1l1_tvp_ and l1l11l11l1l1l1_tvp_:
        return {protocol: l11l1l1l1l1_tvp_ (u"ࠪࠩࡸࡀࠥࡴࠩࢼ")%(l1l11l11l1l1l1_tvp_,l11ll11l1l1l1_tvp_)}
    else:
        return {}
def l1llll1ll1l1l1_tvp_(proxy={l11l1l1l1l1_tvp_ (u"ࠫ࡭ࡺࡴࡱࠩࢽ"):l11l1l1l1l1_tvp_ (u"ࠬ࠷࠰࠯࠳࠳࠲࠶࠶࠮࠲࠲࠽࠹࠵࠭ࢾ")}):
    protocol = proxy.keys()[0]
    l1l11l11l1l1l1_tvp_,l11ll11l1l1l1_tvp_ = proxy[protocol].split(l11l1l1l1l1_tvp_ (u"࠭࠺ࠨࢿ"))
    l1llllll1l1l1_tvp_.setSetting(l11l1l1l1l1_tvp_ (u"ࠧࡱࡴࡲࡸࡴࡩ࡯࡭ࠩࣀ"),protocol)
    l1llllll1l1l1_tvp_.setSetting(l11l1l1l1l1_tvp_ (u"ࠨ࡫ࡳࡥࡩࡪࡲࡦࡵࡶࠫࣁ"),l1l11l11l1l1l1_tvp_)
    l1llllll1l1l1_tvp_.setSetting(l11l1l1l1l1_tvp_ (u"ࠩ࡬ࡴࡵࡵࡲࡵࠩࣂ"),l11ll11l1l1l1_tvp_)
def l1l11111l1l1l1_tvp_(lll1l1l1_tvp_):
    if os.path.exists(lll1l1l1_tvp_):
        with open(lll1l1l1_tvp_,l11l1l1l1l1_tvp_ (u"ࠪࡶࠬࣃ")) as f:
            content = f.read()
            if not content:
                content =l11l1l1l1l1_tvp_ (u"ࠫࡠࡣࠧࣄ")
    else:
        content = l11l1l1l1l1_tvp_ (u"ࠬࡡ࡝ࠨࣅ")
    data=json.loads(content)
    return data
xbmcplugin.setContent(l1l11llll1l1l1_tvp_, l11l1l1l1l1_tvp_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨࣆ"))
import resources.lib.l1lllll1l1l1_tvp_ as l1lll11ll1l1l1_tvp_
l1llllll1l1l1_tvp_.setSetting(l11l1l1l1l1_tvp_ (u"ࠧࡴࡧࡷࠫࣇ"),l11l1l1l1l1_tvp_ (u"ࠨࡵࡨࡸࠬࣈ"))
mode = args.get(l11l1l1l1l1_tvp_ (u"ࠩࡰࡳࡩ࡫ࠧࣉ"), None)
fname = args.get(l11l1l1l1l1_tvp_ (u"ࠪࡪࡴࡲࡤࡦࡴࡱࡥࡲ࡫ࠧ࣊"),[l11l1l1l1l1_tvp_ (u"ࠫࠬ࣋")])[0]
ex_link = args.get(l11l1l1l1l1_tvp_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭࣌"),[l11l1l1l1l1_tvp_ (u"࠭ࠧ࣍")])[0]
l11llll1l1l1_tvp_ = args.get(l11l1l1l1l1_tvp_ (u"ࠧࡱࡣࡪࡩࠬ࣎"),[l11l1l1l1l1_tvp_ (u"ࠨ࠳࣏ࠪ")])[0]
def l1ll11ll1l1l1_tvp_(label,l1l11lll1l1l1_tvp_):
    try:
        quality = int(l1llllll1l1l1_tvp_.getSetting(l11l1l1l1l1_tvp_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻ࣐ࠪ")))
    except:
        quality=0
    l11ll1l1l1_tvp_ = [-2,-1,91000,54200,28500,17500,12500][quality]
    if l11ll1l1l1_tvp_==-1:
        s = len(label)-1
    elif l11ll1l1l1_tvp_ in l1l11lll1l1l1_tvp_:
        s = l1l11lll1l1l1_tvp_.index(l11ll1l1l1_tvp_)
    else:
        s = xbmcgui.Dialog().select(l11l1l1l1l1_tvp_ (u"ࡸࠫ࡜ࡿࡢࡪࡧࡵࡾࠥࡰࡡ࡬ࡱफ़ऋࠥࡼࡩࡥࡧࡲࠤࡠࡧ࡬ࡣࡱࠣࡹࡸࡺࡡࡸࠢࡤࡹࡹࡵ࡭ࡢࡶࠣࡻࠥࡵࡰࡤ࡬ࡤࡧ࡭ࡣ࣑ࠧ"), label)
    return s
if mode is None:
    l1lll11l1l1l1_tvp_(name=l11l1l1l1l1_tvp_ (u"ࠫࡎࡴࡦࡰࡴࡰࡥࡨࡰࡡࠨ࣒"),mode=l11l1l1l1l1_tvp_ (u"ࠬࡥࡩ࡯ࡨࡲࡣ࣓ࠬ"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l11l1l1l1l1_tvp_ (u"࠭ࡰࡢࡶ࡫ࠫࣔ")))+l11l1l1l1l1_tvp_ (u"ࠧ࠰࡫ࡦࡳࡳ࠴ࡰ࡯ࡩࠪࣕ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠨ࡝ࡅࡡࡕࡰ࡯࡯ࡩࡦࡾࡦࡴࡧࠡ࠴࠳࠵࠽ࡡ࠯ࡃ࡟ࠪࣖ"),l11l1l1l1l1_tvp_ (u"ࠩ࠶࠹࠽࠷࠱࠹࠲࠷ࠫࣗ"),mode=l11l1l1l1l1_tvp_ (u"ࠪࡺࡴࡪࡔࡗࡒࠪࣘ"),contextO=[],iconImage=l11l1l1l1l1_tvp_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡲ࡫ࡤࡪࡣ࠱࡬ࡴࡺ࡮ࡦࡹࡶ࠲ࡷࡵ࠯࡮ࡧࡧ࡭ࡦࡥࡳࡦࡴࡹࡩࡷ࠷࠯ࡪ࡯ࡤ࡫ࡪ࠳࠲࠱࠳࠺࠱࠶࠸࠭࠺࠯࠵࠶࠶࠼࠷࠺࠴࠸࠱࠹࠼࠭࡭ࡱࡪࡳ࠲࡯ࡡࡳࡰࡤ࠱࠷࠶࠱࠹࠰ࡳࡲ࡬࠭ࣙ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠬ࡝ࡩࡢࡦࡲࡱࡴॡࡣࡪࠩࣚ"),l11l1l1l1l1_tvp_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡪࡣࡧࡳࡲࡵࡳࡤ࡫࠱ࡸࡻࡶ࠮ࡱ࡮࠲ࠫࣛ"),mode=l11l1l1l1l1_tvp_ (u"ࠧࡠࡰࡨࡻࡸࡥࠧࣜ"),contextO=[],iconImage=l11lll11l1l1l1_tvp_+l11l1l1l1l1_tvp_ (u"ࠨࡹ࡬ࡥࡩࡵ࡭ࡰࡵࡦ࡭࠳ࡶ࡮ࡨࠩࣝ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠩࡗࡩࡱ࡫ࡥࡹࡲࡵࡩࡸࡹࠧࣞ"),l11l1l1l1l1_tvp_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸࡪࡲࡥࡦࡺࡳࡶࡪࡹࡳ࠯ࡶࡹࡴ࠳ࡶ࡬࠰ࠩࣟ"),mode=l11l1l1l1l1_tvp_ (u"ࠫࡤࡴࡥࡸࡵࡢࠫ࣠"),contextO=[],iconImage=l11lll11l1l1l1_tvp_+l11l1l1l1l1_tvp_ (u"ࠬࡺࡥ࡭ࡧࡨࡼࡵࡸࡥࡴࡵ࠱ࡴࡳ࡭ࠧ࣡"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"࠭ࡐࡢࡰࡲࡶࡦࡳࡡࠨ࣢"),l11l1l1l1l1_tvp_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡱࡣࡱࡳࡷࡧ࡭ࡢ࠰ࡷࡺࡵ࠴ࡰ࡭࠱ࣣࠪ"),mode=l11l1l1l1l1_tvp_ (u"ࠨࡡࡱࡩࡼࡹ࡟ࠨࣤ"),contextO=[],iconImage=l11lll11l1l1l1_tvp_+l11l1l1l1l1_tvp_ (u"ࠩࡳࡥࡳࡵࡲࡢ࡯ࡤ࠲ࡵࡴࡧࠨࣥ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠪࡘ࡛ࡖࠠࡪࡰࡩࡳࠥࡒࡩࡷࡧࣦࠪ"),l11l1l1l1l1_tvp_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹࡼࡰࡴࡶࡵࡩࡦࡳ࠮ࡷࡱࡧ࠲ࡹࡼࡰ࠯ࡲ࡯ࠫࣧ"),contextO=[],iconImage=l11lll11l1l1l1_tvp_+l11l1l1l1l1_tvp_ (u"ࠬࡺࡶࡱ࠯࡬ࡲ࡫ࡵ࠮ࡱࡰࡪࠫࣨ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"࠭ࡋࡢࡤࡤࡶࡪࡺࡹࠡࡖ࡙ࡔࣩࠬ"),ex_link=l11l1l1l1l1_tvp_ (u"ࠧࠨ࣪"),mode=l11l1l1l1l1_tvp_ (u"ࠨࡡࡎࡥࡧࡧࡲࡦࡶࡼࠫ࣫"),contextO=[],iconImage=l11lll11l1l1l1_tvp_+l11l1l1l1l1_tvp_ (u"ࠩ࡮ࡥࡧࡧࡲࡦࡶࡼࡸࡻࡶ࠮ࡱࡰࡪࠫ࣬"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠪࡅࡸࡺࡲࡰࡰࡤࡶ࡮ࡻ࡭ࠨ࣭"),ex_link=l11l1l1l1l1_tvp_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡣࡶࡸࡷࡵ࡮ࡢࡴ࡬ࡹࡲ࠴ࡰ࡭࠱ࡲࡨࡨ࡯࡮࡬࡫࠲࣮ࠫ"),mode=l11l1l1l1l1_tvp_ (u"ࠬࡇࡳࡵࡴࡲࡲࡦࡸࡩࡶ࡯࣯ࠪ"),contextO=[],iconImage=l11l1l1l1l1_tvp_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡥࡸࡺࡲࡰࡰࡤࡶ࡮ࡻ࡭࠯ࡲ࡯࠳ࡵࡲࡩ࡬࡫࠲ࡥࡸࡺࡲࡰࡰࡤࡶ࡮ࡻ࡭ࡠ࡮ࡲ࡫ࡴࡥࡳ࡮ࡣ࡯ࡰ࠳ࡰࡰࡨࣰࠩ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠧࡑࡴࡽࡩ࡬ࡧࡰࡪॄࡨय़ࠥࡽࠠࡕࡘࣱࠪ"),mode=l11l1l1l1l1_tvp_ (u"ࠨࡸࡲࡨ࡙࡜ࡐࡠࡲࡵࡾࡪ࡭ࡡࡱ࡫࡯ࡩࡸࣲ࠭"),contextO=[],iconImage=l11lll11l1l1l1_tvp_+l11l1l1l1l1_tvp_ (u"ࠩࡹࡳࡩࡺࡶࡱ࠰ࡳࡲ࡬࠭ࣳ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠪࡖࡪ࡭ࡩࡰࡰࡤࡰࡳ࡫ࠧࣴ"),contextO=[],iconImage=l11lll11l1l1l1_tvp_+l11l1l1l1l1_tvp_ (u"ࠫࡻࡵࡤࡵࡸࡳ࠲ࡵࡴࡧࠨࣵ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡨ࡬ࡶࡧࡠࡺࡴࡪ࠮ࡕࡘࡓ࠲ࡵࡲ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨࣶ"),contextO=[],iconImage=l11lll11l1l1l1_tvp_+l11l1l1l1l1_tvp_ (u"࠭ࡶࡰࡦࡷࡺࡵ࠴ࡰ࡯ࡩࠪࣷ"))
    l1lll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠ࡭࡫ࡪ࡬ࡹࡨ࡬ࡶࡧࡠࡺࡴࡪ࠮ࡘࡻࡥࡶࡦࡴࡥ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࣸ"),ex_link=l1lll1ll1l1l1_tvp_, mode=l11l1l1l1l1_tvp_ (u"ࠨࡨࡤࡺࡴࡸࡩࡵࡧࡶࣹࠫ"),contextO=[],iconImage=l11lll11l1l1l1_tvp_+l11l1l1l1l1_tvp_ (u"ࠩࡺࡽࡧࡸࡡ࡯ࡧ࠱ࡴࡳ࡭ࣺࠧ"))
elif mode[0].startswith(l11l1l1l1l1_tvp_ (u"ࠪࡣ࡮ࡴࡦࡰࡡࠪࣻ")):
    l1111ll1l1l1_tvp_.__myinfo__.go(sys.argv)
elif mode[0] == l11l1l1l1l1_tvp_ (u"ࠫࡆࡹࡴࡳࡱࡱࡥࡷ࡯ࡵ࡮ࠩࣼ"):
    import resources.lib.l11111l1l1l1_tvp_ as l11111l1l1l1_tvp_
    out=l11111l1l1l1_tvp_.l1lll1l1l1_tvp_(ex_link)
    for l11l11ll1l1l1_tvp_ in out:
        l1l1llll1l1l1_tvp_(l11l11ll1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠬࡺࡩࡵ࡮ࡨࠫࣽ")], l11l11ll1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"࠭ࡵࡳ࡮ࠪࣾ")], l11l1l1l1l1_tvp_ (u"ࠧࡂࡵࡷࡶࡴࡴࡡࡳ࡫ࡸࡱࡤࡶ࡬ࡢࡻࠪࣿ"), l1llll1l1l1l1_tvp_=l11l11ll1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠨ࡫ࡰ࡫ࠬऀ")])
elif mode[0] == l11l1l1l1l1_tvp_ (u"ࠩࡄࡷࡹࡸ࡯࡯ࡣࡵ࡭ࡺࡳ࡟ࡱ࡮ࡤࡽࠬँ"):
    import resources.lib.l11111l1l1l1_tvp_ as l11111l1l1l1_tvp_
    src = l11111l1l1l1_tvp_.l1l111ll1l1l1_tvp_(ex_link)
    if src:
        xbmcplugin.setResolvedUrl(l1l11llll1l1l1_tvp_, True, xbmcgui.ListItem(path=src))
    else:
        xbmcplugin.setResolvedUrl(l1l11llll1l1l1_tvp_, False, xbmcgui.ListItem(path=l11l1l1l1l1_tvp_ (u"ࠪࠫं")))
elif mode[0] == l11l1l1l1l1_tvp_ (u"ࠫࡤࡴࡥࡸࡵࡢࠫः"):
    l11l1ll1l1l1_tvp_(fname,ex_link)
elif mode[0] == l11l1l1l1l1_tvp_ (u"ࠬࡥࡩ࡯ࡨࡲࡔࠬऄ"):
    l11l1l1l1l1l1_tvp_()
elif mode[0] == l11l1l1l1l1_tvp_ (u"࠭࡟ࡌࡣࡥࡥࡷ࡫ࡴࡺࠩअ"):
    l1ll1lll1l1l1_tvp_()
elif mode[0] == l11l1l1l1l1_tvp_ (u"ࠧࡱࡣ࡯ࡽࡑ࡯ࡶࡦࡘ࡬ࡨࡪࡵࠧआ"):
    l1ll11lll1l1l1_tvp_(ex_link)
elif mode[0] == l11l1l1l1l1_tvp_ (u"ࠨࡨࡤࡺࡴࡸࡩࡵࡧࡶࠫइ"):
    l1l11ll1l1l1l1_tvp_ = l1l11111l1l1l1_tvp_(l1lll1ll1l1l1_tvp_)
    for k in l1l11ll1l1l1l1_tvp_:
        l1lll11l1l1l1_tvp_(k.get(l11l1l1l1l1_tvp_ (u"ࠩࡷ࡭ࡹࡲࡥࠨई"),l11l1l1l1l1_tvp_ (u"ࠪࠫउ")).title().encode(l11l1l1l1l1_tvp_ (u"ࠫࡺࡺࡦ࠮࠺ࠪऊ")),str(k.get(l11l1l1l1l1_tvp_ (u"ࠬ࡯ࡤࠨऋ"),l11l1l1l1l1_tvp_ (u"࠭ࠧऌ"))),mode=l11l1l1l1l1_tvp_ (u"ࠧࡷࡱࡧࡘ࡛ࡖࠧऍ"),contextO=[l11l1l1l1l1_tvp_ (u"ࠨࡈࡢࡖࡊࡓࠧऎ"),l11l1l1l1l1_tvp_ (u"ࠩࡉࡣࡉࡋࡌࠨए")],iconImage=k.get(l11l1l1l1l1_tvp_ (u"ࠪ࡭ࡲ࡭ࠧऐ"),l11l1l1l1l1_tvp_ (u"ࠫࠬऑ")))
elif mode[0] == l11l1l1l1l1_tvp_ (u"ࠬ࡬ࡡࡷࡱࡵ࡭ࡹ࡫ࡳࡂࡆࡇࠫऒ"):
    l1l11ll1l1l1l1_tvp_ = l1l11111l1l1l1_tvp_(l1lll1ll1l1l1_tvp_)
    l111l1ll1l1l1_tvp_=json.loads(ex_link)
    l1l11l1ll1l1l1_tvp_ = [x for x in l1l11ll1l1l1l1_tvp_ if l111l1ll1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"࠭ࡴࡪࡶ࡯ࡩࠬओ")]== x.get(l11l1l1l1l1_tvp_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭औ"),l11l1l1l1l1_tvp_ (u"ࠨࠩक"))]
    if l1l11l1ll1l1l1_tvp_:
        xbmc.executebuiltin(l11l1l1l1l1_tvp_ (u"ࠩࡑࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࠩ࡝ࡆࡓࡑࡕࡒࠡࡲ࡬ࡲࡰࡣࡊࡶॾࠣ࡮ࡪࡹࡴࠡࡹ࡛ࠣࡾࡨࡲࡢࡰࡼࡧ࡭ࡡ࠯ࡄࡑࡏࡓࡗࡣࠬࠡࠩख") + l111l1ll1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩग"),l11l1l1l1l1_tvp_ (u"ࠫࠬघ")).encode(l11l1l1l1l1_tvp_ (u"ࠬࡻࡴࡧ࠯࠻ࠫङ")) + l11l1l1l1l1_tvp_ (u"࠭ࠬࠡ࠴࠳࠴࠮࠭च"))
    else:
        l1l11ll1l1l1l1_tvp_.append(l111l1ll1l1l1_tvp_)
        with open(l1lll1ll1l1l1_tvp_, l11l1l1l1l1_tvp_ (u"ࠧࡸࠩछ")) as l1l1ll1l1l1l1_tvp_:
            json.dump(l1l11ll1l1l1l1_tvp_, l1l1ll1l1l1l1_tvp_, indent=2, sort_keys=True)
            xbmc.executebuiltin(l11l1l1l1l1_tvp_ (u"ࠨࡐࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠨࡅࡱࡧࡥࡳࡵࠠࡅࡱ࡛ࠣࡾࡨࡲࡢࡰࡼࡧ࡭࠲ࠠࠨज") + l111l1ll1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠩࡷ࡭ࡹࡲࡥࠨझ"),l11l1l1l1l1_tvp_ (u"ࠪࠫञ")).encode(l11l1l1l1l1_tvp_ (u"ࠫࡺࡺࡦ࠮࠺ࠪट")) + l11l1l1l1l1_tvp_ (u"ࠬ࠲ࠠ࠳࠲࠳࠭ࠬठ"))
elif mode[0] == l11l1l1l1l1_tvp_ (u"࠭ࡦࡢࡸࡲࡶ࡮ࡺࡥࡴࡔࡈࡑࠬड"):
    if ex_link==l11l1l1l1l1_tvp_ (u"ࠧࡢ࡮࡯ࠫढ"):
        l1l1l1l1l1_tvp_ = xbmcgui.Dialog().yesno(l11l1l1l1l1_tvp_ (u"ࠣࡁࡂࠦण"),l11l1l1l1l1_tvp_ (u"ࠤࡘࡷࡺॊࠠࡸࡵࡽࡽࡸࡺ࡫ࡪࡧࠣࡪ࡮ࡲ࡭ࡺࠢࡽࠤ࡜ࡿࡢࡳࡣࡱࡽࡨ࡮࠿ࠣत"))
        if l1l1l1l1l1_tvp_:
            debug=1
    else:
        l1l11ll1l1l1l1_tvp_ = l1l11111l1l1l1_tvp_(l1lll1ll1l1l1_tvp_)
        l111l11l1l1l1_tvp_=json.loads(ex_link)
        l1l1111ll1l1l1_tvp_=[]
        for i in xrange(len(l1l11ll1l1l1l1_tvp_)):
            if int(l1l11ll1l1l1l1_tvp_[i].get(l11l1l1l1l1_tvp_ (u"ࠪ࡭ࡩ࠭थ"))) == int(l111l11l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠫ࡮ࡪࠧद"))):
                l1l1111ll1l1l1_tvp_.append(i)
        if len(l1l1111ll1l1l1_tvp_)>1:
            l1l1l1l1l1_tvp_ = xbmcgui.Dialog().yesno(l11l1l1l1l1_tvp_ (u"ࠧࡅ࠿ࠣध"),l111l11l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"࠭ࡴࡪࡶ࡯ࡩࠬन")),l11l1l1l1l1_tvp_ (u"ࠢࡖࡵࡸैࠥࠫࡤࠡࡲࡲࡾࡾࡩࡪࡪࠢࡽࠤ࡜ࡿࡢࡳࡣࡱࡽࡨ࡮࠿ࠣऩ") % len(l1l1111ll1l1l1_tvp_))
        else:
            l1l1l1l1l1_tvp_ = True
        if l1l1l1l1l1_tvp_:
            for i in reversed(l1l1111ll1l1l1_tvp_):
                l1l11ll1l1l1l1_tvp_.pop(i)
            with open(l1lll1ll1l1l1_tvp_, l11l1l1l1l1_tvp_ (u"ࠨࡹࠪप")) as l1l1ll1l1l1l1_tvp_:
                json.dump(l1l11ll1l1l1l1_tvp_, l1l1ll1l1l1l1_tvp_, indent=2, sort_keys=True)
    xbmc.executebuiltin(l11l1l1l1l1_tvp_ (u"࡛ࠩࡆࡒࡉ࠮ࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫफ"))
elif mode[0]==l11l1l1l1l1_tvp_ (u"ࠪࡺࡴࡪࡔࡗࡒࡢࡴࡱࡧࡹࠨब"):
    import resources.lib.l1lllll1l1l1_tvp_ as decoder
    decoder.run(ex_link)
    l11ll1ll1l1l1_tvp_ = l1ll1l1ll1l1l1_tvp_.l111l1l1l1l1_tvp_(ex_link)
    if l11l1l1l1l1_tvp_ (u"ࠫࡲࡧࡴࡦࡴ࡬ࡥࡱࡥ࡮ࡪࡧࡧࡳࡸࡺࡥࡱࡰࡼࠫभ") in l11ll1ll1l1l1_tvp_:
        if l1llllll1l1l1_tvp_.getSetting(l11l1l1l1l1_tvp_ (u"ࠬࡶࡲࡰࡺࡼࡋࠬम"))==l11l1l1l1l1_tvp_ (u"࠭ࡴࡳࡷࡨࠫय"):
            xbmc.executebuiltin(l11l1l1l1l1_tvp_ (u"ࠧࡏࡱࡷ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠮࡭ࡢࡶࡨࡶ࡮ࡧ࡬ࡠࡰ࡬ࡩࡩࡵࡳࡵࡧࡳࡲࡾ࠲ࠠࠨर") + l11l1l1l1l1_tvp_ (u"ࠨࡵࡽࡹࡰࡧ࡭ࠡࡲࡵࡾࡪࢀࠠࡱࡴࡲࡼࡾ࠭ऱ") + l11l1l1l1l1_tvp_ (u"ࠩ࠯ࠤ࠶࠸࠰࠱ࠫࠪल"))
            l11ll1ll1l1l1_tvp_ = l1ll1l1ll1l1l1_tvp_.l111l1l1l1l1_tvp_(ex_link,pgate=True)
        if l11l1l1l1l1_tvp_ (u"ࠪࡱࡦࡺࡥࡳ࡫ࡤࡰࡤࡴࡩࡦࡦࡲࡷࡹ࡫ࡰ࡯ࡻࠪळ") in l11ll1ll1l1l1_tvp_ or not l11ll1ll1l1l1_tvp_:
            y=xbmcgui.Dialog().yesno(l11l1l1l1l1_tvp_ (u"ࠦࡠࡉࡏࡍࡑࡕࠤࡴࡸࡡ࡯ࡩࡨࡡࡕࡸ࡯ࡣ࡮ࡨࡱࡠ࠵ࡃࡐࡎࡒࡖࡢࠨऴ"), l11l1l1l1l1_tvp_ (u"ࠬࡡࡂ࡞ࡑࡪࡶࡦࡴࡩࡤࡼࡨࡲ࡮ࡧࠠࡍ࡫ࡦࡩࡳࡩࡹ࡫ࡰࡨ࠰ࠥࡳࡡࡵࡧࡵ࡭ࡦࡲࠠ࡫ࡧࡶࡸࠥࡴࡩࡦࡦࡲࡷࡹटࡰ࡯ࡻ࡞࠳ࡇࡣࠧव"),l11l1l1l1l1_tvp_ (u"࠭ࡓࡱࡴࣶࡦࡴࡽࡡࡤࠢࡸঀࡾऍࠠࡴࡧࡵࡻࡪࡸࡡࠡࡲࡵࡳࡽࡿࠠࡀࡁ࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟࡚ࠤࡴࡶࡣ࡫ࡣࡦ࡬ࠥࡪ࡯ࡴࡶजࡴࡳࡧࠠࡢ࡮ࡷࡩࡷࡴࡡࡵࡻࡺࡲࡦࠦ࡯ࡱࡥ࡭ࡥࠦࡡ࠯ࡄࡑࡏࡓࡗࡣࠧश"))
            if y:
                import resources.lib.l1l1l1l1_tvp_ as l1llll1l1l1_tvp_
                l11ll1ll1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠧࠨष")
                timeout=  int(l1llllll1l1l1_tvp_.getSetting(l11l1l1l1l1_tvp_ (u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩस")))
                l11lll1l1l1l1_tvp_  = xbmcgui.DialogProgress()
                l11lll1l1l1l1_tvp_.create(l11l1l1l1l1_tvp_ (u"ࠩࡖࡾࡺࡱࡡ࡮ࠢࡧࡥࡷࡳ࡯ࡸࡻࡦ࡬ࠥࡹࡥࡳࡹࡨࡶࣸࡽࠠࡱࡴࡲࡼࡾࠦ࠮࠯࠰ࠪह"))
                proxies=l1ll1l1ll1l1l1_tvp_.l1l11l1l1l1l1_tvp_()
                proxy = l111ll1l1l1_tvp_()
                if proxy:
                    proxies.insert(0,proxy)
                l11lll1l1l1l1_tvp_.create(l11l1l1l1l1_tvp_ (u"ࠪ࡞ࡳࡧ࡬ࡢࡼॅࡩࡲࠦࠥࡥࠢࡶࡩࡷࡽࡥࡳࣵࡺࠤࡵࡸ࡯ࡹࡻࠪऺ")%len(proxies))
                l1l1l11l1l1l1_tvp_ = [l1llll1l1l1_tvp_.Thread(l1ll1l1ll1l1l1_tvp_.l111l1l1l1l1_tvp_, ex_link,proxy,timeout) for proxy in proxies ]
                [i.start() for i in l1l1l11l1l1l1_tvp_]
                l11lll1l1l1l1_tvp_.update(0,l11l1l1l1l1_tvp_ (u"ࠫࡘࡶࡲࡢࡹࡧࡾࡦࡳࠠࠦࡦࠣࡷࡪࡸࡷࡦࡴࡼࠤ࠳࠴࠮ࠡࠩऻ")%(len(l1l1l11l1l1l1_tvp_)))
                while any([i.isAlive() for i in l1l1l11l1l1l1_tvp_]):
                    xbmc.sleep(1000)
                    l11l111l1l1l1_tvp_ = [t for t in l1l1l11l1l1l1_tvp_ if not t.isAlive()]
                    l11lll1l1l1l1_tvp_.update(int(1.0*len(l11l111l1l1l1_tvp_)/len(proxies)*100),l11l1l1l1l1_tvp_ (u"࡙ࠬࡰࡳࡣࡺࡨࡿࡧ࡭࠭ࠢࡱࡩ࡬ࡧࡴࡺࡹࡱ࡭ࡪࠦ࡯ࡥࡲࡲࡻ࡮࡫ࡤࡻ࡫ࡤॆࡴࡀࠠࠦࡦ࠯ࠤࡵࡸ࡯ࡴࡼजࠤࡨࢀࡥ࡬ࡣऊ़ࠫ")%(len(l11l111l1l1l1_tvp_)))
                    for t in l11l111l1l1l1_tvp_:
                        l11ll1ll1l1l1_tvp_ = t.result
                        if isinstance(l11ll1ll1l1l1_tvp_,list) or (l11ll1ll1l1l1_tvp_ and not l11l1l1l1l1_tvp_ (u"࠭࡭ࡢࡶࡨࡶ࡮ࡧ࡬ࡠࡰ࡬ࡩࡩࡵࡳࡵࡧࡳࡲࡾ࠭ऽ") in l11ll1ll1l1l1_tvp_):
                            l1llll1ll1l1l1_tvp_(t._1111lll1l1l1_tvp_[1])
                            break
                        else:
                            l11ll1ll1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠧࠨा")
                    if l11ll1ll1l1l1_tvp_ or l11lll1l1l1l1_tvp_.iscanceled():
                        break
                l11lll1l1l1l1_tvp_.close()
    if isinstance(l11ll1ll1l1l1_tvp_,list):
        label= [x.get(l11l1l1l1l1_tvp_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧि")) for x in l11ll1ll1l1l1_tvp_]
        l1l11lll1l1l1_tvp_ = [x.get(l11l1l1l1l1_tvp_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪी")) for x in l11ll1ll1l1l1_tvp_]
        if len(label)>1:
            s =l1ll11ll1l1l1_tvp_(label,l1l11lll1l1l1_tvp_)
            l11ll1ll1l1l1_tvp_ = l11ll1ll1l1l1_tvp_[s].get(l11l1l1l1l1_tvp_ (u"ࠪࡹࡷࡲࠧु")) if s>-1 else l11l1l1l1l1_tvp_ (u"ࠫࠬू")
        else:
            l11ll1ll1l1l1_tvp_ = l11ll1ll1l1l1_tvp_[0].get(l11l1l1l1l1_tvp_ (u"ࠬࡻࡲ࡭ࠩृ"))
    if l11ll1ll1l1l1_tvp_:
        if l11l1l1l1l1_tvp_ (u"࠭ࡍࡢࡰ࡬ࡪࡪࡹࡴ࠯࡫ࡶࡱࠬॄ") in l11ll1ll1l1l1_tvp_:
            l11111ll1l1l1_tvp_,l1l1ll1ll1l1l1_tvp_=l11ll1ll1l1l1_tvp_.split(l11l1l1l1l1_tvp_ (u"ࠧࡽࠩॅ"))
            xbmc.executebuiltin(l11l1l1l1l1_tvp_ (u"ࠨࡐࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠨࡔࡶࡵࡹࡲ࡯ࡥॅࠢࡇࡅࡘࡎࠬࠡࠩॆ") + l11l1l1l1l1_tvp_ (u"ࠩࡎࡓࡉࡏࠠ࠲࠺ࠣ࠱ࠥࡳࡡࡵࡧࡵ࡭ࡦैࠠࡻࠢࡇࡖࡒ࠭े") + l11l1l1l1l1_tvp_ (u"ࠪ࠰ࠥ࠷࠲࠱࠲ࠬࠫै"))
            listitem = xbmcgui.ListItem(path=l11111ll1l1l1_tvp_)
            listitem.setProperty(l11l1l1l1l1_tvp_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮ࡣࡧࡨࡴࡴࠧॉ"), l11l1l1l1l1_tvp_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬॊ"))
            listitem.setProperty(l11l1l1l1l1_tvp_ (u"࠭ࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡦࡪࡡࡱࡶ࡬ࡺࡪ࠴࡬ࡪࡥࡨࡲࡸ࡫࡟ࡵࡻࡳࡩࠬो"), l11l1l1l1l1_tvp_ (u"ࠧࡤࡱࡰ࠲ࡼ࡯ࡤࡦࡸ࡬ࡲࡪ࠴ࡡ࡭ࡲ࡫ࡥࠬौ"))
            listitem.setProperty(l11l1l1l1l1_tvp_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥ࠯࡯ࡤࡲ࡮࡬ࡥࡴࡶࡢࡸࡾࡶࡥࠨ्"), l11l1l1l1l1_tvp_ (u"ࠩ࡬ࡷࡲ࠭ॎ"))
            listitem.setProperty(l11l1l1l1l1_tvp_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧ࠱ࡰ࡮ࡩࡥ࡯ࡵࡨࡣࡰ࡫ࡹࠨॏ"), l1l1ll1ll1l1l1_tvp_)
            listitem.l1l1ll11l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡧࡥࡸ࡮ࠫࡹ࡯࡯ࠫॐ"))
        else:
            listitem = xbmcgui.ListItem(path=l11ll1ll1l1l1_tvp_)
        xbmcplugin.setResolvedUrl(l1l11llll1l1l1_tvp_, True, listitem)
    else:
        xbmcplugin.setResolvedUrl(l1l11llll1l1l1_tvp_, False, xbmcgui.ListItem(path=l11l1l1l1l1_tvp_ (u"ࠬ࠭॑")))
elif mode[0]==l11l1l1l1l1_tvp_ (u"࠭ࡶࡰࡦࡗ࡚ࡕࡥࡰࡳࡼࡨ࡫ࡦࡶࡩ࡭ࡧࡶ॒ࠫ"):
    l1l111l1l1l1l1_tvp_ = l1llllll1l1l1_tvp_.getSetting(l11l1l1l1l1_tvp_ (u"ࠧࡢࡰࡷࡩࡳࡧࡖࠨ॓"))
    l1l111lll1l1l1_tvp_ = l1llllll1l1l1_tvp_.getSetting(l11l1l1l1l1_tvp_ (u"ࠨࡣࡱࡸࡪࡴࡡࡏࠩ॔")) if l1l111l1l1l1l1_tvp_ else l11l1l1l1l1_tvp_ (u"࡚ࠩࡷࡿࡿࡳࡵ࡭࡬ࡩࠥࡧ࡮ࡵࡧࡱࡽࠬॕ")
    l11l1l1l1_tvp_ = l1ll1l1ll1l1l1_tvp_.l1l11ll1l1l1_tvp_(l1l111l1l1l1l1_tvp_)
    if len(l11l1l1l1_tvp_):
        l1l1llll1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠥ࡟ࡈࡕࡌࡐࡔࠣࡰ࡮࡭ࡨࡵࡤ࡯ࡹࡪࡣࡗࡺࡤ࡬ࡩࡷࢀࠠࡢࡰࡷࡩࡳट࠺࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࡞ࡆࡢࠨॖ")+l1l111lll1l1l1_tvp_+l11l1l1l1l1_tvp_ (u"ࠦࡠ࠵ࡂ࡞ࠤॗ"),l11l1l1l1l1_tvp_ (u"ࠬ࠭क़"),mode=l11l1l1l1l1_tvp_ (u"࠭ࡦࡪ࡮ࡷࡶ࠿ࡧ࡮ࡵࡧࡱࡥࠬख़"),l1llll1l1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠧࠨग़"),IsPlayable=False)
        for e in l11l1l1l1_tvp_:
            l1l1llll1l1l1_tvp_(e.get(l11l1l1l1l1_tvp_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧज़"),l11l1l1l1l1_tvp_ (u"ࠩࠪड़")), e.get(l11l1l1l1l1_tvp_ (u"ࠪ࡭ࡩ࠭ढ़"),l11l1l1l1l1_tvp_ (u"ࠫࠬफ़")), l11l1l1l1l1_tvp_ (u"ࠬࡼ࡯ࡥࡖ࡙ࡔࡤࡶ࡬ࡢࡻࠪय़"),
                        infoLabels=e,l1llll1l1l1l1_tvp_=e.get(l11l1l1l1l1_tvp_ (u"࠭ࡩ࡮ࡩࠪॠ"),None),fanart=e.get(l11l1l1l1l1_tvp_ (u"ࠧࡧࡣࡱࡥࡷࡺࠧॡ"),None))
elif l11l1l1l1l1_tvp_ (u"ࠨࡨ࡬ࡰࡹࡸࠧॢ") in mode[0]:
    _1l1l111l1l1l1_tvp_ = mode[0].split(l11l1l1l1l1_tvp_ (u"ࠤ࠽ࠦॣ"))[-1]
    if _1l1l111l1l1l1_tvp_==l11l1l1l1l1_tvp_ (u"ࠪࡥࡳࡺࡥ࡯ࡣࠪ।"):
        label=l1ll1l1ll1l1l1_tvp_.l1lll111l1l1l1_tvp_
        value=l1ll1l1ll1l1l1_tvp_.l1111l1l1l1_tvp_
        msg = l11l1l1l1l1_tvp_ (u"ࠫ࡜ࡿࡢࡪࡧࡵࡾࠥࡧ࡮ࡵࡧࡱझ࠿࠭॥")
    else:
        label=l11l1l1l1l1_tvp_ (u"ࠬ࠭०")
    if label:
        s = xbmcgui.Dialog().select(msg,label)
        s = s if s>-1 else 0
        l1llllll1l1l1_tvp_.setSetting(_1l1l111l1l1l1_tvp_+l11l1l1l1l1_tvp_ (u"࠭ࡖࠨ१"),value[s])
        l1llllll1l1l1_tvp_.setSetting(_1l1l111l1l1l1_tvp_+l11l1l1l1l1_tvp_ (u"ࠧࡏࠩ२"),label[s])
        xbmc.executebuiltin(l11l1l1l1l1_tvp_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠪ३"))
elif mode[0]==l11l1l1l1l1_tvp_ (u"ࠩࡹࡳࡩ࡚ࡖࡑࠩ४"):
    (l1l111l1l1l1_tvp_,l11l1l1l1_tvp_) = l1ll1l1ll1l1l1_tvp_.l11l1lll1l1l1_tvp_(ex_link,l11llll1l1l1_tvp_)
    for e in l11l1l1l1_tvp_:
        l1l1llll1l1l1_tvp_(e.get(l11l1l1l1l1_tvp_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ५"),l11l1l1l1l1_tvp_ (u"ࠫࠬ६")), e.get(l11l1l1l1l1_tvp_ (u"ࠬ࡬ࡩ࡭ࡧࡱࡥࡲ࡫ࠧ७"),l11l1l1l1l1_tvp_ (u"࠭ࠧ८")), l11l1l1l1l1_tvp_ (u"ࠧࡷࡱࡧࡘ࡛ࡖ࡟ࡱ࡮ࡤࡽࠬ९"),
                    infoLabels=e,l1llll1l1l1l1_tvp_=e.get(l11l1l1l1l1_tvp_ (u"ࠨ࡫ࡰ࡫ࠬ॰"),None),fanart=e.get(l11l1l1l1l1_tvp_ (u"ࠩࡩࡥࡳࡧࡲࡵࠩॱ"),None))
    for l11l11ll1l1l1_tvp_ in l1l111l1l1l1_tvp_:
        l1lll11l1l1l1_tvp_(l11l11ll1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩॲ")],ex_link=l11l11ll1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠫ࡮ࡪࠧॳ")],l11llll1l1l1_tvp_=l11l11ll1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠬࡶࡡࡨࡧࠪॴ"),1),mode=l11l1l1l1l1_tvp_ (u"࠭ࡶࡰࡦࡗ࡚ࡕ࠭ॵ"),iconImage=l11l11ll1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠧࡪ࡯ࡪࠫॶ")))
elif mode[0] == l11l1l1l1l1_tvp_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨॷ"):
    if fname == l11l1l1l1l1_tvp_ (u"ࠩࡗ࡚ࡕࠦࡩ࡯ࡨࡲࠤࡑ࡯ࡶࡦࠩॸ"):
        out = l1ll11l1l1l1_tvp_(ex_link)
        for l11l11ll1l1l1_tvp_ in out:
           l1l1llll1l1l1_tvp_(l11l11ll1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩॹ")].encode(l11l1l1l1l1_tvp_ (u"ࠫࡺࡺࡦ࠮࠺ࠪॺ")), l11l11ll1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠬࡻࡲ࡭ࠩॻ")], l11l1l1l1l1_tvp_ (u"࠭ࡰࡢ࡮ࡼࡐ࡮ࡼࡥࡗ࡫ࡧࡩࡴ࠭ॼ"), l1llll1l1l1l1_tvp_=l11l11ll1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠧࡪ࡯ࡪࠫॽ")])
    elif fname == l11l1l1l1l1_tvp_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣࡶࡰࡦ࠱ࡘ࡛ࡖ࠮ࡱ࡮࡞࠳ࡈࡕࡌࡐࡔࡠࠫॾ"):
        l1l1lll1l1l1_tvp_ = l1ll1l1ll1l1l1_tvp_.l1ll111ll1l1l1_tvp_()
        for k in l1l1lll1l1l1_tvp_:
            l1lll11l1l1l1_tvp_(k.get(l11l1l1l1l1_tvp_ (u"ࠩࡷ࡭ࡹࡲࡥࠨॿ"),l11l1l1l1l1_tvp_ (u"ࠪࠫঀ")).title().encode(l11l1l1l1l1_tvp_ (u"ࠫࡺࡺࡦ࠮࠺ࠪঁ")),str(k.get(l11l1l1l1l1_tvp_ (u"ࠬ࡯ࡤࠨং"),l11l1l1l1l1_tvp_ (u"࠭ࠧঃ"))),mode=l11l1l1l1l1_tvp_ (u"ࠧࡷࡱࡧࡘ࡛ࡖࠧ঄"))
    elif fname == l11l1l1l1l1_tvp_ (u"ࠨࡔࡨ࡫࡮ࡵ࡮ࡢ࡮ࡱࡩࠬঅ"):
        l1l1lll1l1l1_tvp_ = l1ll1l1ll1l1l1_tvp_.l11lllll1l1l1_tvp_()
        for k in l1l1lll1l1l1_tvp_:
            l1lll11l1l1l1_tvp_(k.get(l11l1l1l1l1_tvp_ (u"ࠩࡷ࡭ࡹࡲࡥࠨআ"),l11l1l1l1l1_tvp_ (u"ࠪࠫই")).title().encode(l11l1l1l1l1_tvp_ (u"ࠫࡺࡺࡦ࠮࠺ࠪঈ")),str(k.get(l11l1l1l1l1_tvp_ (u"ࠬ࡯ࡤࠨউ"),l11l1l1l1l1_tvp_ (u"࠭ࠧঊ"))),mode=l11l1l1l1l1_tvp_ (u"ࠧࡷࡱࡧࡘ࡛ࡖࠧঋ"))
    else:
        l11ll1l1l1l1_tvp_(ex_link)
xbmcplugin.addSortMethod( handle=l1l11llll1l1l1_tvp_, sortMethod=xbmcplugin.SORT_METHOD_TITLE, label2Mask = l11l1l1l1l1_tvp_ (u"ࠣࠧࡕ࠰࡙ࠥࠫ࠭ࠢࠨࡔࠧঌ"))
xbmcplugin.addSortMethod( handle=l1l11llll1l1l1_tvp_, sortMethod=xbmcplugin.SORT_METHOD_VIDEO_YEAR, label2Mask = l11l1l1l1l1_tvp_ (u"ࠤࠨࡖ࠱࡚ࠦࠥ࠮ࠣࠩࡕࠨ঍"))
xbmcplugin.addSortMethod( handle=l1l11llll1l1l1_tvp_, sortMethod=xbmcplugin.SORT_METHOD_UNSORTED, label2Mask = l11l1l1l1l1_tvp_ (u"ࠥࠩࡗ࠲࡛ࠠࠦ࠯ࠤࠪࡖࠢ঎"))
xbmcplugin.endOfDirectory(l1l11llll1l1l1_tvp_)
