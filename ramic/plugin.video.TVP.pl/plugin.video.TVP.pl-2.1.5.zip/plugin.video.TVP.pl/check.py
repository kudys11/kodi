# -*- coding: utf-8 -*-
import sys
l1l1l11ll1l1l1_tvp_ = sys.version_info [0] == 2
l1lllll1l1l1l1_tvp_ = 2048
l1l1lllll1l1l1_tvp_ = 7
def l11l1l1l1l1_tvp_ (keyedStringLiteral):
    global l111111l1l1l1_tvp_
    stringNr = ord (keyedStringLiteral [-1])
    rotatedStringLiteral = keyedStringLiteral [:-1]
    rotationDistance = stringNr % len (rotatedStringLiteral)
    recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
    if l1l1l11ll1l1l1_tvp_:
        stringLiteral = unicode () .join ([unichr (ord (char) - l1lllll1l1l1l1_tvp_ - (charIndex + stringNr) % l1l1lllll1l1l1_tvp_) for charIndex, char in enumerate (recodedStringLiteral)])
    else:
        stringLiteral = str () .join ([chr (ord (char) - l1lllll1l1l1l1_tvp_ - (charIndex + stringNr) % l1l1lllll1l1l1_tvp_) for charIndex, char in enumerate (recodedStringLiteral)])
    return eval (stringLiteral)
import xbmc,xbmcgui
import time,re,os,sys,threading
try: from shutil import rmtree
except: rmtree = False
def l11ll11ll1l1l1_tvp_(l11l11l1l1l1l1_tvp_,l11l111ll1l1l1_tvp_=[l11l1l1l1l1_tvp_ (u"ࠫࠬএ")]):
    debug=1
def l11ll1l1l1l1l1_tvp_(name=l11l1l1l1l1_tvp_ (u"ࠬ࠭ঐ")):
    debug=1
def l11l1llll1l1l1_tvp_(top):
    debug=1
def check():
    debug=1
try:
    debug=1
except: pass
def run():
    try:
        debug=1
    except: pass
