# -*- coding: utf-8 -*-
import sys
l1l1l11ll1l1l1_tvp_ = sys.version_info [0] == 2
l1lllll1l1l1l1_tvp_ = 2048
l1l1lllll1l1l1_tvp_ = 7
def l11l1l1l1l1_tvp_ (keyedStringLiteral):
    global l111111l1l1l1_tvp_
    stringNr = ord (keyedStringLiteral [-1])
    rotatedStringLiteral = keyedStringLiteral [:-1]
    rotationDistance = stringNr % len (rotatedStringLiteral)
    recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
    if l1l1l11ll1l1l1_tvp_:
        stringLiteral = unicode () .join ([unichr (ord (char) - l1lllll1l1l1l1_tvp_ - (charIndex + stringNr) % l1l1lllll1l1l1_tvp_) for charIndex, char in enumerate (recodedStringLiteral)])
    else:
        stringLiteral = str () .join ([chr (ord (char) - l1lllll1l1l1l1_tvp_ - (charIndex + stringNr) % l1l1lllll1l1l1_tvp_) for charIndex, char in enumerate (recodedStringLiteral)])
    return eval (stringLiteral)
import xbmc,xbmcgui
import time,re,os,sys,threading
try: from shutil import rmtree
except: rmtree = False
import ramic
def l11ll11ll1l1l1_tvp_(l11l11l1l1l1l1_tvp_,l11l111ll1l1l1_tvp_=[l11l1l1l1l1_tvp_ (u"ࠫࠬহ")]):
    debug=1
def l11ll1l1l1l1l1_tvp_(name=l11l1l1l1l1_tvp_ (u"ࠬ࠭঺")):
    debug=1
def l111l1l1l1l1l1_tvp_(name=l11l1l1l1l1_tvp_ (u"࠭ࠧূ")):
    debug=1
def l11l1llll1l1l1_tvp_(top):
    debug=1
def l111l1lll1l1l1_tvp_():
    l11l11l1l1l1l1_tvp_ = os.path.join(xbmc.translatePath(l11l1l1l1l1_tvp_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧ৉")),l11l1l1l1l1_tvp_ (u"ࠧࡢࡦࡧࡳࡳࡹࠧ৊"))
    xbmc.log(l11l11l1l1l1l1_tvp_)
    if l11ll11ll1l1l1_tvp_(l11l11l1l1l1l1_tvp_,[l11l1l1l1l1_tvp_ (u"ࠨࡣ࡯࡭ࡪࡴࡷࡪࡼࡤࡶࡩ࠭ো"),l11l1l1l1l1_tvp_ (u"ࠩࡨࡼࡹ࡫࡮ࡥࡧࡵ࠲ࡦࡲࡩࡦࡰࠪৌ")])>0:
        l11ll1l1l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠪࡻ࡮ࢀࡡࡳࡦ্ࠪ"))
        return
    l11l11lll1l1l1_tvp_ = xbmc.translatePath(l11l1l1l1l1_tvp_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡩࡱࡰࡩࠬৎ"))
    for f in os.listdir(l11l11lll1l1l1_tvp_):
        if f.startswith(l11l1l1l1l1_tvp_ (u"ࠬࡓࡍࡆࡕࠪ৏")):
            l11ll1l1l1l1l1_tvp_()
            return
def run(l111l11ll1l1l1_tvp_):
    try:
        debug=1
    except: pass
def l111lll1l1l1l1_tvp_(fname):
    try:
        debug=1
    except:
        pass
def l111ll1ll1l1l1_tvp_():
    debug=1

