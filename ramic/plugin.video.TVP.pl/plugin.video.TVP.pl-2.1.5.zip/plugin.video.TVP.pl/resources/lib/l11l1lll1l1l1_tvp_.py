# -*- coding: utf-8 -*-
import sys
l1l1l11ll1l1l1_tvp_ = sys.version_info [0] == 2
l1lllll1l1l1l1_tvp_ = 2048
l1l1lllll1l1l1_tvp_ = 7
def l11l1l1l1l1_tvp_ (keyedStringLiteral):
    global l111111l1l1l1_tvp_
    stringNr = ord (keyedStringLiteral [-1])
    rotatedStringLiteral = keyedStringLiteral [:-1]
    rotationDistance = stringNr % len (rotatedStringLiteral)
    recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
    if l1l1l11ll1l1l1_tvp_:
        stringLiteral = unicode () .join ([unichr (ord (char) - l1lllll1l1l1l1_tvp_ - (charIndex + stringNr) % l1l1lllll1l1l1_tvp_) for charIndex, char in enumerate (recodedStringLiteral)])
    else:
        stringLiteral = str () .join ([chr (ord (char) - l1lllll1l1l1l1_tvp_ - (charIndex + stringNr) % l1l1lllll1l1l1_tvp_) for charIndex, char in enumerate (recodedStringLiteral)])
    return eval (stringLiteral)
l11l1l1l1l1_tvp_ (u"ࠤࠥࠦࠒࠐࡃࡳࡧࡤࡸࡪࡪࠠࡰࡰࠣࡊࡷ࡯ࠠࡎࡣࡼࠤ࠷࠿ࠠ࠳࠴࠽࠵࠵ࡀ࠵࠵ࠢ࠵࠴࠶࠻ࠍࠋࠏࠍࡄࡦࡻࡴࡩࡱࡵ࠾ࠥࡓࡩࡤࡪࡤࡰࠒࠐࠢࠣࠤਠ")
import urllib2
import json
import re
from time import localtime, strftime
import urllib
l11111lll1l1l1_tvp_ = 10
l1l111l1ll1l1l1_tvp_ = l11l1l1l1l1_tvp_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠶࠯࠳࠾ࠤࡷࡼ࠺࠳࠴࠱࠴࠮ࠦࡇࡦࡥ࡮ࡳ࠴࠸࠰࠲࠲࠳࠵࠵࠷ࠠࡇ࡫ࡵࡩ࡫ࡵࡸ࠰࠴࠵࠲࠵࠭ਡ")
def l1ll111l1l1l1_tvp_(url,proxy={},timeout=l11111lll1l1l1_tvp_):
    if proxy:
        urllib2.install_opener(
            urllib2.build_opener(
                urllib2.ProxyHandler(proxy)
            )
        )
    req = urllib2.Request(url)
    req.add_header(l11l1l1l1l1_tvp_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨਢ"), l11l1l1l1l1_tvp_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠸࠱࠵ࡀࠦࡲࡷ࠼࠵࠶࠳࠶ࠩࠡࡉࡨࡧࡰࡵ࠯࠳࠲࠴࠴࠵࠷࠰࠲ࠢࡉ࡭ࡷ࡫ࡦࡰࡺ࠲࠶࠷࠴࠰ࠨਣ"))
    try:
        response = urllib2.urlopen(req,timeout=timeout)
        l1llll11l1l1l1_tvp_ = response.read()
        response.close()
    except:
        l1llll11l1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"࠭ࡻࡾࠩਤ")
    return l1llll11l1l1l1_tvp_
import cookielib
l1ll1l1l1l1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠧࠨਥ")
l1ll1l1l1l1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡳࡶࡴࡾࡩࡢ࡭࠱ࡩࡺ࠭ਦ")
l1lllll1ll1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠩࠪਧ")
def l1l1l1l1ll1l1l1_tvp_(url,header={}):
    l1llll11l1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠪࡿࢂ࠭ਨ")
    global l1lllll1ll1l1l1_tvp_
    try:
        if not l1lllll1ll1l1l1_tvp_:
            req = urllib2.Request(l1ll1l1l1l1l1l1_tvp_,data=None,headers={l11l1l1l1l1_tvp_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ਩"): l1l111l1ll1l1l1_tvp_,l11l1l1l1l1_tvp_ (u"࡛ࠬࡰࡨࡴࡤࡨࡪ࠳ࡉ࡯ࡵࡨࡧࡺࡸࡥ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡵࠪਪ"):1})
            response = urllib2.urlopen(req,timeout=l11111lll1l1l1_tvp_)
            cookies=response.headers.get(l11l1l1l1l1_tvp_ (u"࠭ࡳࡦࡶ࠰ࡧࡴࡵ࡫ࡪࡧࠪਫ"),l11l1l1l1l1_tvp_ (u"ࠧࠡࠩਬ")).split(l11l1l1l1l1_tvp_ (u"ࠨࠢࠪਭ"))[0]
            response.close()
            l1lllll1ll1l1l1_tvp_ = cookies
        else:
            cookies=l1lllll1ll1l1l1_tvp_
        data = l11l1l1l1l1_tvp_ (u"ࠩࡸࡁࠪࡹࠦࡣ࠿࠵࠶࠶ࠬࡦ࠾ࡰࡲࡶࡪ࡬ࡥࡳࠩਮ")%urllib.quote_plus(url)
        l1l11ll11l1l1l1_tvp_ = l1ll1l1l1l1l1l1_tvp_+l11l1l1l1l1_tvp_ (u"ࠪ࠳࡮ࡴࡣ࡭ࡷࡧࡩࡸ࠵ࡰࡳࡱࡦࡩࡸࡹ࠮ࡱࡪࡳࡃࡦࡩࡴࡪࡱࡱࡁࡺࡶࡤࡢࡶࡨࠫਯ")
        headers={l11l1l1l1l1_tvp_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨਰ"): l1l111l1ll1l1l1_tvp_,l11l1l1l1l1_tvp_ (u"࡛ࠬࡰࡨࡴࡤࡨࡪ࠳ࡉ࡯ࡵࡨࡧࡺࡸࡥ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡵࠪ਱"):1,l11l1l1l1l1_tvp_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭ਲ"):cookies}
        headers.update(header)
        req = urllib2.Request(l1l11ll11l1l1l1_tvp_,data,headers)
        response = urllib2.urlopen(req,timeout=l11111lll1l1l1_tvp_)
        l1llll11l1l1l1_tvp_=response.read()
        if l11l1l1l1l1_tvp_ (u"ࠧࡴࡵ࡯ࡥ࡬ࡸࡥࡦࠩਲ਼") in l1llll11l1l1l1_tvp_:
            l1l11ll11l1l1l1_tvp_ = l1ll1l1l1l1l1l1_tvp_+l11l1l1l1l1_tvp_ (u"ࠨ࠱࡬ࡲࡨࡲࡵࡥࡧࡶ࠳ࡵࡸ࡯ࡤࡧࡶࡷ࠳ࡶࡨࡱࡁࡤࡧࡹ࡯࡯࡯࠿ࡶࡷࡱࡧࡧࡳࡧࡨࠫ਴")
            req = urllib2.Request(l1l11ll11l1l1l1_tvp_,data,headers)
            response = urllib2.urlopen(req,timeout=l11111lll1l1l1_tvp_)
            l1llll11l1l1l1_tvp_=response.read()
        response.close()
        print l11l1l1l1l1_tvp_ (u"ࠩࡊࡅ࡙ࡋࠠࡪࡰ࡙ࠣࡘࡋࠧਵ")
    except:
        print l11l1l1l1l1_tvp_ (u"ࠪࡋࡆ࡚ࡅࠡ࡫ࡱࠤ࡚࡙ࡅࠡࡇࡕࡖࡔࡘࠧਸ਼")
        l1llll11l1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠫࢀࢃࠧ਷")
    return l1llll11l1l1l1_tvp_
def l1l11ll1ll1l1l1_tvp_(url):
    try:
        l1ll11llll1l1l1_tvp_ =l11l1l1l1l1_tvp_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡨࡲࡢ࡯࡮ࡥ࠳ࡶࡲࡰࡺࡼ࠲ࡳ࡫ࡴ࠯ࡲ࡯࠳࡮ࡴࡤࡦࡺ࠱ࡴ࡭ࡶ࠿ࡲ࠿ࠨࡷࠫ࡮࡬࠾࠲ࠪਸ")%urllib.quote_plus(url)
        headers={l11l1l1l1l1_tvp_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪਹ"): l11l1l1l1l1_tvp_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢ࡭ࡳ࠼࠴࠼ࠢࡻ࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠻࠷࠮࠱࠰࠶࠵࠻࠹࠮࠲࠲࠳ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫ਺"),l11l1l1l1l1_tvp_ (u"ࠨࡗࡳ࡫ࡷࡧࡤࡦ࠯ࡌࡲࡸ࡫ࡣࡶࡴࡨ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡸ࠭਻"):1,
        l11l1l1l1l1_tvp_ (u"ࠩࡄࡧࡨ࡫ࡰࡵ਼ࠩ"):l11l1l1l1l1_tvp_ (u"ࠪࡸࡪࡾࡴ࠰ࡪࡷࡱࡱ࠲ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࡮ࡴ࡮࡮࠮ࡼࡲࡲࠬࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࡭࡭࠽ࡴࡁ࠵࠴࠹࠭࡫ࡰࡥ࡬࡫࠯ࡸࡧࡥࡴ࠱࡯࡭ࡢࡩࡨ࠳ࡦࡶ࡮ࡨ࠮࠭࠳࠯ࡁࡱ࠾࠲࠱࠼ࠬ਽")}
        req = urllib2.Request(l1ll11llll1l1l1_tvp_,None,headers)
        response = urllib2.urlopen(req,timeout=l11111lll1l1l1_tvp_)
        l1llll11l1l1l1_tvp_=response.read()
        response.close()
        print l11l1l1l1l1_tvp_ (u"ࠫࡌࡇࡔࡆ࠴ࠣ࡭ࡳࠦࡕࡔࡇࠪਾ")
    except:
        print l11l1l1l1l1_tvp_ (u"ࠬࡍࡁࡕࡇࠣ࡭ࡳࠦࡕࡔࡇࠣࡉࡗࡘࡏࡓࠩਿ")
        l1llll11l1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"࠭ࠧੀ")
    return l1llll11l1l1l1_tvp_
def l1ll111lll1l1l1_tvp_(l1llll11l1l1l1_tvp_):
    formats = re.compile(l11l1l1l1l1_tvp_ (u"ࠧࠩࡽࠥࡱ࡮ࡳࡥࡕࡻࡳࡩࠧࡀࠢࡷ࡫ࡧࡩ࠳࠰࠿ࡾࠫࠪੁ"),re.DOTALL).findall(l1llll11l1l1l1_tvp_)
    l1l11l111l1l1l1_tvp_ = l11l1l1l1l1_tvp_ (u"ࠨࡽࠥࡪࡴࡸ࡭ࡢࡶࡶࠦ࠿ࡡࠥࡴ࡟ࢀࠫੂ")%l11l1l1l1l1_tvp_ (u"ࠩ࠯ࠫ੃").join(formats) if formats else l11l1l1l1l1_tvp_ (u"ࠪࠫ੄")
    return l1l11l111l1l1l1_tvp_
def l1l11l1l1l1l1_tvp_():
    content=l1ll111l1l1l1_tvp_(l11l1l1l1l1_tvp_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯࡫ࡧࡧࡱࡵࡡ࡬࠰ࡦࡳࡲ࠵ࡰࡳࡱࡻࡽࡱ࡯ࡳࡵ࠱ࡩࡶࡪ࡫࠭ࡱࡴࡲࡼࡾ࠳࡬ࡪࡵࡷ࠱ࡵࡵ࡬ࡢࡰࡧ࠲࡭ࡺ࡭࡭ࠩ੅"))
    l1lll11lll1l1l1_tvp_ = re.compile(l11l1l1l1l1_tvp_ (u"ࠬࡂࡤࡪࡸࠣࡷࡹࡿ࡬ࡦ࠿ࠥࡻ࡮ࡪࡴࡩ࠼࡟ࡨ࠰ࠫࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࡟ࡨ࠰࠯ࠥࠣࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩ੆")).findall(content)
    l1l111llll1l1l1_tvp_ = re.compile(l11l1l1l1l1_tvp_ (u"࠭࠼ࡵࡦࡁࠬ࡭ࡺࡴࡱ࡝ࡶࡡ࠯࠯࠼࠰ࡶࡧࡂࡁࡺࡤ࠿ࠪ࡟ࡨ࠰࠯࠼࠰ࡶࡧࡂࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡧࡂࠬੇ"),re.DOTALL).findall(content)
    proxies=[{x[0]: l11l1l1l1l1_tvp_ (u"ࠧࠦࡵ࠽ࠩࡸ࠭ੈ")%(x[2],x[1])} for x in l1l111llll1l1l1_tvp_]
    return proxies
def l1llll11ll1l1l1_tvp_(l1ll1l1lll1l1l1_tvp_,count=10):
    l1llll1lll1l1l1_tvp_ = l11l1l1l1l1_tvp_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡧࡰࡪ࠰ࡹ࠷࠳ࡺࡶࡱ࠰ࡳࡰ࠴ࡹࡨࡢࡴࡨࡨ࠴ࡲࡩࡴࡶ࡬ࡲ࡬࠴ࡰࡩࡲࡂࡨࡺࡳࡰ࠾࡬ࡶࡳࡳ࠭੉")
    url = l1llll1lll1l1l1_tvp_ + l11l1l1l1l1_tvp_ (u"ࠩࠩࡨ࡮ࡸࡥࡤࡶࡀࡸࡷࡻࡥࠧࡥࡲࡹࡳࡺ࠽ࠦࡦࠩࡴࡦࡸࡥ࡯ࡶࡢ࡭ࡩࡃࠥࡴࠩ੊")% (count,l1ll1l1lll1l1l1_tvp_)
    response = urllib2.urlopen(url)
    l1l1llllll1l1l1_tvp_ = json.loads(response.read())
    response.close()
    return l1l1llllll1l1l1_tvp_
def l1ll1ll1ll1l1l1_tvp_(seconds):
    try:
        seconds=int(seconds)
        m, s = divmod(seconds, 60)
        h, m = divmod(m, 60)
        if h>0:
            out = l11l1l1l1l1_tvp_ (u"ࠥࠩࡩࡀࠥ࠱࠴ࡧ࠾ࠪ࠶࠲ࡥࠤੋ") % (h, m, s)
        else:
            out = l11l1l1l1l1_tvp_ (u"ࠦࠪ࠶࠲ࡥ࠼ࠨ࠴࠷ࡪࠢੌ") % (h, m, s)
    except:
        out=l11l1l1l1l1_tvp_ (u"੍ࠬ࠭")
    return out
def _1ll11l1ll1l1l1_tvp_(l1l1l1l11l1l1l1_tvp_):
    l1ll11l11l1l1l1_tvp_={}
    l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"࠭ࡦࡪ࡮ࡨࡲࡦࡳࡥࠨ੎")] = str(l1l1l1l11l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠧࡠ࡫ࡧࠫ੏"),l11l1l1l1l1_tvp_ (u"ࠨࠩ੐")))
    if l11l1l1l1l1_tvp_ (u"ࠩࡹ࡭ࡩ࡫࡯࠰࡯ࡳ࠸ࠬੑ") in (l1l1l1l11l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠪࡺ࡮ࡪࡥࡰࡈࡲࡶࡲࡧࡴࡎ࡫ࡰࡩࡸ࠭੒")) or []):
        l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠫ࡫࡯࡬ࡦࡰࡤࡱࡪ࠭੓")] = l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠬ࡬ࡩ࡭ࡧࡱࡥࡲ࡫ࠧ੔")]+l11l1l1l1l1_tvp_ (u"࠭ࠦ࡮࡫ࡰࡩࡤࡺࡹࡱࡧࡀࡺ࡮ࡪࡥࡰ࠱ࡰࡴ࠹࠭੕")
    l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠧࡧࡣࡱࡥࡷࡺࠧ੖")] = l1l11l1l1l1l1l1_tvp_(l1l1l1l11l1l1l1_tvp_,[l11l1l1l1l1_tvp_ (u"ࠨ࡫ࡰࡥ࡬࡫࡟࠲࠸ࡻ࠽ࠬ੗"),l11l1l1l1l1_tvp_ (u"ࠩ࡬ࡱࡦ࡭ࡥࠨ੘")])
    l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠪ࡭ࡲ࡭ࠧਖ਼")] = l1l11l1l1l1l1l1_tvp_(l1l1l1l11l1l1l1_tvp_,[l11l1l1l1l1_tvp_ (u"ࠫ࡮ࡳࡡࡨࡧࠪਗ਼")])
    l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠬࡺࡶࡴࡪࡲࡻࡹ࡯ࡴ࡭ࡧࠪਜ਼")] =l11l1l1l1l1_tvp_ (u"࠭ࠧੜ")
    if l1l1l1l11l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠧࡸࡧࡥࡷ࡮ࡺࡥࡠࡶ࡬ࡸࡱ࡫ࠧ੝"),None):
        l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠨࡶࡹࡷ࡭ࡵࡷࡵ࡫ࡷࡰࡪ࠭ਫ਼")] =  l1l1l1l11l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠩࡺࡩࡧࡹࡩࡵࡧࡢࡸ࡮ࡺ࡬ࡦࠩ੟"),l11l1l1l1l1_tvp_ (u"ࠪࠫ੠")).encode(l11l1l1l1l1_tvp_ (u"ࠫࡺࡺࡦ࠮࠺ࠪ੡"))
    l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ੢")]=l11l1l1l1l1_tvp_ (u"࠭ࠧ੣")
    if l1l1l1l11l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠧࡸࡧࡥࡷ࡮ࡺࡥࡠࡶ࡬ࡸࡱ࡫ࠧ੤"),None):
        l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ੥")] =  l1l1l1l11l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠩࡺࡩࡧࡹࡩࡵࡧࡢࡸ࡮ࡺ࡬ࡦࠩ੦"),l11l1l1l1l1_tvp_ (u"ࠪࠫ੧")).encode(l11l1l1l1l1_tvp_ (u"ࠫࡺࡺࡦ࠮࠺ࠪ੨")) + l11l1l1l1l1_tvp_ (u"ࠬ࠲ࠠࠨ੩")
    l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ੪")] += l1l1l1l11l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭੫"),l11l1l1l1l1_tvp_ (u"ࠨࠩ੬")).encode(l11l1l1l1l1_tvp_ (u"ࠩࡸࡸ࡫࠳࠸ࠨ੭"))
    l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠪࡳࡷ࡯ࡧࡪࡰࡤࡰࡹ࡯ࡴ࡭ࡧࠪ੮")] = l1l1l1l11l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠫࡴࡸࡩࡨ࡫ࡱࡥࡱࡥࡴࡪࡶ࡯ࡩࠬ੯"),l11l1l1l1l1_tvp_ (u"ࠬ࠭ੰ")).encode(l11l1l1l1l1_tvp_ (u"࠭ࡵࡵࡨ࠰࠼ࠬੱ"))
    l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠧࡱ࡮ࡲࡸࠬੲ")] =  l1l1l1l11l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠨࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳࡥࡲࡰࡱࡷࠫੳ"),l11l1l1l1l1_tvp_ (u"ࠩࠪੴ")).encode(l11l1l1l1l1_tvp_ (u"ࠪࡹࡹ࡬࠭࠹ࠩੵ"))
    l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠫࡦ࡯ࡲࡦࡦࠪ੶")] =  l1l1l1l11l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠬࡶࡵࡣ࡮࡬ࡧࡦࡺࡩࡰࡰࡢࡷࡹࡧࡲࡵࡡࡧࡸࠬ੷"),l11l1l1l1l1_tvp_ (u"࠭ࠧ੸")).encode(l11l1l1l1l1_tvp_ (u"ࠧࡶࡶࡩ࠱࠽࠭੹"))
    l1l1l1111l1l1l1_tvp_ = l1l1l1l11l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦࡡࡧࡥࡹ࡫ࠧ੺"),l11l1l1l1l1_tvp_ (u"ࠩࠪ੻"))
    l1lll1l1ll1l1l1_tvp_ = l1l1l1111l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠪࡷࡪࡩࠧ੼"),l11l1l1l1l1_tvp_ (u"ࠫࠬ੽")) if l1l1l1111l1l1l1_tvp_ else l11l1l1l1l1_tvp_ (u"ࠬ࠭੾")
    l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ੿")] = l1l1l1l11l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩ઀"),0)
    l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠨࡥࡲࡨࡪ࠭ઁ")]=l1ll1ll1ll1l1l1_tvp_(l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫં")]) if l1l1l1l11l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬઃ"),0) else l11l1l1l1l1_tvp_ (u"ࠫࠬ઄")
    if l1lll1l1ll1l1l1_tvp_:
        l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠬࡧࡩࡳࡧࡧࠫઅ")] =  strftime(l11l1l1l1l1_tvp_ (u"ࠨࠥࡥ࠰ࠨࡱ࠳࡙ࠫࠡࠧࡋ࠾ࠪࡓࠢઆ"), localtime(l1lll1l1ll1l1l1_tvp_))
        l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠧࡱ࡮ࡲࡸࠬઇ")] += l11l1l1l1l1_tvp_ (u"ࠨ࡞ࡱࡠࡳࡖࡵࡣ࡮࡬࡯ࡦࡩࡪࡢ࠼ࠣࠩࡸ࠭ઈ")%l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠩࡤ࡭ࡷ࡫ࡤࠨઉ")]
    else:
        l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠪࡥ࡮ࡸࡥࡥࠩઊ")]= l11l1l1l1l1_tvp_ (u"ࠫࡄ࠭ઋ")
    l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠬࡶࡲࡦ࡯࡬ࡩࡷ࡫ࡤࠨઌ")]=l1ll11l11l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"࠭ࡡࡪࡴࡨࡨࠬઍ"),l11l1l1l1l1_tvp_ (u"ࠧࠨ઎"))
    l1ll11l11l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠨࡲ࡯ࡳࡹ࠭એ")] += l11l1l1l1l1_tvp_ (u"ࠩ࡟ࡲࡡࡴࠥࡴࠩઐ")%l1ll11l11l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠪࡳࡷ࡯ࡧࡪࡰࡤࡰࡹ࡯ࡴ࡭ࡧࠪઑ"),l11l1l1l1l1_tvp_ (u"ࠫࠬ઒")) if l1ll11l11l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠬࡵࡲࡪࡩ࡬ࡲࡦࡲࡴࡪࡶ࡯ࡩࠬઓ"),l11l1l1l1l1_tvp_ (u"࠭ࠧઔ")) else l11l1l1l1l1_tvp_ (u"ࠧࠨક")
    return l1ll11l11l1l1l1_tvp_
l1lll111ll1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠨ࠵࠸࠽࠸࠿࠵࠲࠵ࠩࡱ࡮ࡳࡥࡠࡶࡼࡴࡪࡃࡶࡪࡦࡨࡳ࠴ࡳࡰ࠵ࠩખ")
l1lll1ll1l1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡴࡷࡲ࠱ࡴࡱ࠵ࡰࡶࡤ࠲ࡷࡹࡧࡴ࠰ࡸ࡬ࡨࡪࡵࡦࡪ࡮ࡨ࡭ࡳ࡬࡯ࡀࡸ࡬ࡨࡪࡵ࡟ࡪࡦࡀࠫગ")
l1ll1ll11l1l1l1_tvp_ = l11l1l1l1l1_tvp_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡵࡸࡳ࠲ࡵࡲ࠯ࡴࡪࡤࡶࡪࡪ࠯ࡤࡦࡱ࠳ࡹࡵ࡫ࡦࡰ࡬ࡾࡪࡸ࡟ࡷ࠴࠱ࡴ࡭ࡶ࠿ࡰࡤ࡭ࡩࡨࡺ࡟ࡪࡦࡀࠫઘ")
l1ll11111l1l1l1_tvp_= l11l1l1l1l1_tvp_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹࡼࡰࡴࡶࡵࡩࡦࡳ࠮ࡷࡱࡧ࠲ࡹࡼࡰ࠯ࡲ࡯࠳ࡸ࡫ࡳࡴ࠱ࡷࡺࡵࡲࡡࡺࡧࡵ࠲ࡵ࡮ࡰࡀࡱࡥ࡮ࡪࡩࡴࡠ࡫ࡧࡁࠬઙ")
l1l1l11l1l1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠬ࠭ચ")
def _1l1l1ll1l1l1l1_tvp_(url=l11l1l1l1l1_tvp_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷࡱࡧ࠲ࡹࡼࡰ࠯ࡲ࡯࠳ࡵࡸࡺࡦࡩࡤࡴ࡮ࡲࡥࡴ࠯ࡺ࠱ࡹࡼࠧછ")):
    content = l1ll111l1l1l1_tvp_(url)
    l1l1l111ll1l1l1_tvp_ = re.compile(l11l1l1l1l1_tvp_ (u"ࠧ࠽ࡵࡨࡧࡹ࡯࡯࡯ࠢࡦࡰࡦࡹࡳ࠾ࠤࡤࡩࡷ࡯ࡡ࡭ࡵࡗࡻࡴࠦࡳ࡭࡫ࡧࡩࡷ࠳ࡷࡪࡶ࡫࠱ࡹࡼ࠭ࡴࡶࡤࡸ࡮ࡵ࡮ࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡨࡺࡩࡰࡰࡁࠫજ"),re.DOTALL).findall(content)
    x= re.findall(l11l1l1l1l1_tvp_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳ࡵࡸࡺࡦࡩࡤࡴ࡮ࡲࡥࡴ࠯ࡺ࠱ࡹࡼࠨ࡝ࡁࡤࡲࡹ࡫࡮ࡢ࠿࠱࠯ࡄ࠯ࠢ࠿࠰࠮ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠱࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩઝ"),content,re.DOTALL)
    value,key= zip(*x)
l1lll111l1l1l1_tvp_ = (l11l1l1l1l1_tvp_ (u"࡚ࠩࡷࡿࡿࡳࡵ࡭࡬ࡩࠥࡧ࡮ࡵࡧࡱࡽࠬઞ"), l11l1l1l1l1_tvp_ (u"ࠪࡘ࡛ࡖࠠࡂࡄࡆࠫટ"), l11l1l1l1l1_tvp_ (u"࡙ࠫ࡜ࡐࠡࡋࡱࡪࡴ࠭ઠ"), l11l1l1l1l1_tvp_ (u"࡚ࠬࡖࡑࠢࡋࡈࠬડ"), l11l1l1l1l1_tvp_ (u"࠭ࡔࡗࡒࠣ࠵ࠥࡎࡄࠨઢ"), l11l1l1l1l1_tvp_ (u"ࠧࡕࡘࡓࠤ࠷ࠦࡈࡅࠩણ"), l11l1l1l1l1_tvp_ (u"ࠨࡖ࡙ࡔࠥࡑࡵ࡭ࡶࡸࡶࡦ࠭ત"), l11l1l1l1l1_tvp_ (u"ࠩࡗ࡚ࡕࠦࡈࡪࡵࡷࡳࡷ࡯ࡡࠨથ"), l11l1l1l1l1_tvp_ (u"ࠪࡘ࡛ࡖࠠࡓࡱࡽࡶࡾࡽ࡫ࡢࠩદ"), l11l1l1l1l1_tvp_ (u"࡙ࠫ࡜ࡐࠡࡕࡨࡶ࡮ࡧ࡬ࡦࠩધ"), l11l1l1l1l1_tvp_ (u"࡚ࠬࡖࡑࠢࡄࡆࡈ࠭ન"), l11l1l1l1l1_tvp_ (u"࠭ࡔࡗࡒࠣࡍࡳ࡬࡯ࠨ઩"), l11l1l1l1l1_tvp_ (u"ࠧࡕࡘࡓࠤࡍࡊࠧપ"), l11l1l1l1l1_tvp_ (u"ࠨࡖ࡙ࡔࠥ࠷ࠠࡉࡆࠪફ"), l11l1l1l1l1_tvp_ (u"ࠩࡗ࡚ࡕࠦ࠲ࠡࡊࡇࠫબ"), l11l1l1l1l1_tvp_ (u"ࠪࡘ࡛ࡖࠠࡌࡷ࡯ࡸࡺࡸࡡࠨભ"), l11l1l1l1l1_tvp_ (u"࡙ࠫ࡜ࡐࠡࡊ࡬ࡷࡹࡵࡲࡪࡣࠪમ"), l11l1l1l1l1_tvp_ (u"࡚ࠬࡖࡑࠢࡕࡳࡿࡸࡹࡸ࡭ࡤࠫય"), l11l1l1l1l1_tvp_ (u"࠭ࡔࡗࡒࠣࡗࡪࡸࡩࡢ࡮ࡨࠫર"))
l1111l1l1l1_tvp_ = (l11l1l1l1l1_tvp_ (u"ࠧࠨ઱"),l11l1l1l1l1_tvp_ (u"ࠨࡁࡤࡲࡹ࡫࡮ࡢ࠿ࡄࡆࡈ࠭લ"), l11l1l1l1l1_tvp_ (u"ࠩࡂࡥࡳࡺࡥ࡯ࡣࡀࡍࡓࡌࠧળ"), l11l1l1l1l1_tvp_ (u"ࠪࡃࡦࡴࡴࡦࡰࡤࡁࡐࡎࡓࡉࠩ઴"), l11l1l1l1l1_tvp_ (u"ࠫࡄࡧ࡮ࡵࡧࡱࡥࡂ࡚࠱ࡅࠩવ"), l11l1l1l1l1_tvp_ (u"ࠬࡅࡡ࡯ࡶࡨࡲࡦࡃࡔ࠳ࡆࠪશ"), l11l1l1l1l1_tvp_ (u"࠭࠿ࡢࡰࡷࡩࡳࡧ࠽ࡕ࠷ࡇࠫષ"), l11l1l1l1l1_tvp_ (u"ࠧࡀࡣࡱࡸࡪࡴࡡ࠾ࡖࡎࡌࠬસ"), l11l1l1l1l1_tvp_ (u"ࠨࡁࡤࡲࡹ࡫࡮ࡢ࠿ࡗࡖࡔ࠭હ"), l11l1l1l1l1_tvp_ (u"ࠩࡂࡥࡳࡺࡥ࡯ࡣࡀࡘࡗ࡙ࠧ઺"), l11l1l1l1l1_tvp_ (u"ࠪࡃࡦࡴࡴࡦࡰࡤࡁࡆࡈࡃࠨ઻"), l11l1l1l1l1_tvp_ (u"ࠫࡄࡧ࡮ࡵࡧࡱࡥࡂࡏࡎࡇ઼ࠩ"), l11l1l1l1l1_tvp_ (u"ࠬࡅࡡ࡯ࡶࡨࡲࡦࡃࡋࡉࡕࡋࠫઽ"), l11l1l1l1l1_tvp_ (u"࠭࠿ࡢࡰࡷࡩࡳࡧ࠽ࡕ࠳ࡇࠫા"), l11l1l1l1l1_tvp_ (u"ࠧࡀࡣࡱࡸࡪࡴࡡ࠾ࡖ࠵ࡈࠬિ"), l11l1l1l1l1_tvp_ (u"ࠨࡁࡤࡲࡹ࡫࡮ࡢ࠿ࡗ࠹ࡉ࠭ી"), l11l1l1l1l1_tvp_ (u"ࠩࡂࡥࡳࡺࡥ࡯ࡣࡀࡘࡐࡎࠧુ"), l11l1l1l1l1_tvp_ (u"ࠪࡃࡦࡴࡴࡦࡰࡤࡁ࡙ࡘࡏࠨૂ"), l11l1l1l1l1_tvp_ (u"ࠫࡄࡧ࡮ࡵࡧࡱࡥࡂ࡚ࡒࡔࠩૃ"))
def l1l11ll1l1l1_tvp_(l1ll1111ll1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠬ࠭ૄ")):
    l1l11l1lll1l1l1_tvp_ = l11l1l1l1l1_tvp_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡷࡱࡧ࠲ࡹࡼࡰ࠯ࡲ࡯࠳ࡵࡸࡺࡦࡩࡤࡴ࡮ࡲࡥࡴ࠯ࡺ࠱ࡹࡼࠧૅ")+l1ll1111ll1l1l1_tvp_
    content = l1ll111l1l1l1_tvp_(l1l11l1lll1l1l1_tvp_)
    l1l1l111ll1l1l1_tvp_ = re.compile(l11l1l1l1l1_tvp_ (u"ࠧ࠽ࡵࡨࡧࡹ࡯࡯࡯ࠢࡦࡰࡦࡹࡳ࠾ࠤࡤࡩࡷ࡯ࡡ࡭ࡵࡗࡻࡴࠦࡳ࡭࡫ࡧࡩࡷ࠳ࡷࡪࡶ࡫࠱ࡹࡼ࠭ࡴࡶࡤࡸ࡮ࡵ࡮ࡴࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡩࡨࡺࡩࡰࡰࡁࠫ૆"),re.DOTALL).findall(content)
    out=[]
    for l1llll111l1l1l1_tvp_ in l1l1l111ll1l1l1_tvp_:
        l1ll1lllll1l1l1_tvp_=re.findall(l11l1l1l1l1_tvp_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠳ࡵࡸࡺࡦࡩࡤࡴ࡮ࡲࡥࡴ࠯ࡺ࠱ࡹࡼ࡛࡟ࠤࡠ࠮ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ે"),l1llll111l1l1l1_tvp_)
        l1ll1lllll1l1l1_tvp_=l1ll1lllll1l1l1_tvp_[0].strip() if l1ll1lllll1l1l1_tvp_ else l11l1l1l1l1_tvp_ (u"ࠩࠪૈ")
        out.append({l11l1l1l1l1_tvp_ (u"ࠪ࡭ࡩ࠭ૉ"): l11l1l1l1l1_tvp_ (u"ࠫࠬ૊"), l11l1l1l1l1_tvp_ (u"ࠬ࡯࡭ࡨࠩો"): l11l1l1l1l1_tvp_ (u"࠭ࠧૌ"), l11l1l1l1l1_tvp_ (u"ࠧࡵ࡫ࡷࡰࡪ્࠭"): l11l1l1l1l1_tvp_ (u"ࠨ࡝ࡅࡡࡂࡡࠥࡴ࡟ࡀ࡟࠴ࡈ࡝ࠨ૎")%l1ll1lllll1l1l1_tvp_})
        ids = [(a.start(), a.end()) for a in re.finditer(l11l1l1l1l1_tvp_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡪࡶࡨࡱࠧࠦࡤࡢࡶࡤ࠱ࠬ૏"), l1llll111l1l1l1_tvp_,re.IGNORECASE)]
        ids.append( (-1,-1) )
        for i in range(len(ids[:-1])):
            l1111111l1l1l1_tvp_ = l1llll111l1l1l1_tvp_[ ids[i][1]:ids[i+1][0] ]
            id = re.findall(l11l1l1l1l1_tvp_ (u"ࠪ࡭ࡩࡃࠢࠩ࡞ࡧ࠯࠮ࠨࠧૐ"),l1111111l1l1l1_tvp_)
            href = re.compile(l11l1l1l1l1_tvp_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭૑"),re.DOTALL).findall(l1111111l1l1l1_tvp_)
            l1l1lll1ll1l1l1_tvp_ = re.compile(l11l1l1l1l1_tvp_ (u"ࠬࡂࡨ࠳ࠢࡦࡰࡦࡹࡳ࠾ࠤࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠸࠾ࠨ૒"),re.DOTALL).findall(l1111111l1l1l1_tvp_)
            l1l1l1ll1l1l1_tvp_ = re.compile(l11l1l1l1l1_tvp_ (u"࠭࠼ࡩ࡞ࡧ࠯ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࡜ࡥ࠭ࡁࠫ૓"),re.DOTALL).findall(l1111111l1l1l1_tvp_)
            l111l1l1l1_tvp_ = re.compile(l11l1l1l1l1_tvp_ (u"ࠧࡥࡣࡷࡥ࠲ࡲࡡࡻࡻࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡦࡲࡴ࠾ࠩ૔"),re.DOTALL).findall(l1111111l1l1l1_tvp_)
            l111l1l1l1_tvp_ = l111l1l1l1_tvp_[0] if l111l1l1l1_tvp_ else l11l1l1l1l1_tvp_ (u"ࠨࠩ૕")
            if id and l1l1lll1ll1l1l1_tvp_:
                l111l1l1l1_tvp_ = l11l1l1l1l1_tvp_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ૖")+l111l1l1l1_tvp_ if l111l1l1l1_tvp_.startswith(l11l1l1l1l1_tvp_ (u"ࠪ࠳࠴࠭૗")) else l111l1l1l1_tvp_
                title = l1l1lll1ll1l1l1_tvp_[0].strip()
                title += l11l1l1l1l1_tvp_ (u"ࠫࠥ࠭૘")+l1l1l1ll1l1l1_tvp_[0].strip() if l1l1l1ll1l1l1_tvp_ else l11l1l1l1l1_tvp_ (u"ࠬ࠭૙")
                out.append({l11l1l1l1l1_tvp_ (u"࠭ࡩࡥࠩ૚"): id[0], l11l1l1l1l1_tvp_ (u"ࠧࡪ࡯ࡪࠫ૛"): l111l1l1l1_tvp_, l11l1l1l1l1_tvp_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ૜"): title})
    return out
def l1l11l11ll1l1l1_tvp_(l1lll111ll1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠩ࠶࠹࠾࠻࠹࠶࠵࠺ࠪࡲ࡯࡭ࡦࡡࡷࡽࡵ࡫࠽ࡷ࡫ࡧࡩࡴ࠵࡭ࡱ࠶ࠪ૝"),proxy={},timeout=l11111lll1l1l1_tvp_,l1lll1111l1l1l1_tvp_=False):
    l1ll1lll1l1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠪࠫ૞")
    content=l11l1l1l1l1_tvp_ (u"ࠫࢀࢃࠧ૟")
    if l1lll1111l1l1l1_tvp_:
        content=l1l1l1l1ll1l1l1_tvp_(l1ll1ll11l1l1l1_tvp_+ l1lll111ll1l1l1_tvp_)
        content=l1ll111lll1l1l1_tvp_(content)
        print (l11l1l1l1l1_tvp_ (u"ࠬ࡭ࡥࡵࡗࡵࡰࡤࡍࡁࡕࡇࠫࡘࡔࡑࡅࡏࡋ࡝ࡉࡗࡥࡕࡓࡎ࠮ࠤ࠮࠭ૠ"),l1lll111ll1l1l1_tvp_,content)
        if not content or l11l1l1l1l1_tvp_ (u"࠭࡭ࡢࡶࡨࡶ࡮ࡧ࡬ࡠࡰ࡬ࡩࡩࡵࡳࡵࡧࡳࡲࡾ࠭ૡ") in content:
            content = l1l11ll1ll1l1l1_tvp_(l1ll1ll11l1l1l1_tvp_+ l1lll111ll1l1l1_tvp_)
            content = l1ll111lll1l1l1_tvp_(content)
            if not content or l11l1l1l1l1_tvp_ (u"ࠧ࡮ࡣࡷࡩࡷ࡯ࡡ࡭ࡡࡱ࡭ࡪࡪ࡯ࡴࡶࡨࡴࡳࡿࠧૢ") in content:
                content = l1l11ll1ll1l1l1_tvp_(l1ll11111l1l1l1_tvp_+ l1lll111ll1l1l1_tvp_)
                print(l11l1l1l1l1_tvp_ (u"ࠨࡸࡲࡨ࡙࡜ࡐࡠࡉࡨࡸࡘࡺࡲࡦࡣࡰࡘࡴࡱࡥ࡯࡫ࡽࡩࡷࡀࠠࡨࡧࡷ࡙ࡷࡲ࡟ࡈࡃࡗࡉ࠷࠭ૣ"),l1ll11111l1l1l1_tvp_+ l1lll111ll1l1l1_tvp_)
                src = re.compile(l11l1l1l1l1_tvp_ (u"ࠤ࠳࠾ࢀࡹࡲࡤ࠼ࠪࠬ࠳࠰࠿ࠪࠩࠥ૤"), re.DOTALL).findall(content)
                l1lll11l1l1l1l1_tvp_ = re.compile(l11l1l1l1l1_tvp_ (u"ࠪࠦࡼ࡯ࡤࡦࡸ࡬ࡲࡪࠨ࠺ࠣࠪ࡫ࡸࡹࡶࡳ࠯࠭ࡂ࠭ࠧ࠭૥"), re.DOTALL).findall(content)
                l1lll11l1l1l1l1_tvp_ = l1lll11l1l1l1l1_tvp_[0].replace(l11l1l1l1l1_tvp_ (u"ࠫࡡࡢࠧ૦"),l11l1l1l1l1_tvp_ (u"ࠬ࠭૧")) if l1lll11l1l1l1l1_tvp_ else l11l1l1l1l1_tvp_ (u"࠭ࠧ૨")
                if src:
                    l1ll1lll1l1l1l1_tvp_ = src[0]
                    if l1lll11l1l1l1l1_tvp_: l1ll1lll1l1l1l1_tvp_ +=l11l1l1l1l1_tvp_ (u"ࠢࡽࠤ૩")+l1lll11l1l1l1l1_tvp_
                    content=l11l1l1l1l1_tvp_ (u"ࠨࡽࢀࠫ૪")
    else:
        content=l1ll111l1l1l1_tvp_(l1ll1ll11l1l1l1_tvp_+ l1lll111ll1l1l1_tvp_,proxy,timeout)
        if l11l1l1l1l1_tvp_ (u"ࠩࡰࡥࡹ࡫ࡲࡪࡣ࡯ࡣࡳ࡯ࡥࡥࡱࡶࡸࡪࡶ࡮ࡺࠩ૫") in content:
            return l11l1l1l1l1_tvp_ (u"ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡷ࠳ࡼ࠳࠯ࡶࡹࡴ࠳ࡶ࡬࠰ࡨ࡬ࡰࡪࡹ࠯ࡱ࡮ࡤࡽࡪࡸ࠯ࡷ࡫ࡧࡩࡴ࠵࡭ࡢࡶࡨࡶ࡮ࡧ࡬ࡠࡰ࡬ࡩࡩࡵࡳࡵࡧࡳࡲࡾ࠴࡭ࡱ࠶ࠥ૬")
        content = l1ll111lll1l1l1_tvp_(content)
        if not content:
            content = l1ll111l1l1l1_tvp_(l1ll11111l1l1l1_tvp_+l1lll111ll1l1l1_tvp_,proxy,timeout)
            src = re.compile(l11l1l1l1l1_tvp_ (u"ࠦ࠵ࡀࡻࡴࡴࡦ࠾ࠬ࠮࠮ࠫࡁࠬࠫࠧ૭"), re.DOTALL).findall(content)
            l1lll11l1l1l1l1_tvp_ = re.compile(l11l1l1l1l1_tvp_ (u"ࠬࠨࡷࡪࡦࡨࡺ࡮ࡴࡥࠣ࠼ࠥࠬ࡭ࡺࡴࡱࡵ࠱࠯ࡄ࠯ࠢࠨ૮"), re.DOTALL).findall(content)
            l1lll11l1l1l1l1_tvp_ = l1lll11l1l1l1l1_tvp_[0].replace(l11l1l1l1l1_tvp_ (u"࠭࡜࡝ࠩ૯"),l11l1l1l1l1_tvp_ (u"ࠧࠨ૰")) if l1lll11l1l1l1l1_tvp_ else l11l1l1l1l1_tvp_ (u"ࠨࠩ૱")
            if src:
                l1ll1lll1l1l1l1_tvp_ = src[0]
                if l1lll11l1l1l1l1_tvp_: l1ll1lll1l1l1l1_tvp_ +=l11l1l1l1l1_tvp_ (u"ࠤࡿࠦ૲")+l1lll11l1l1l1l1_tvp_
                content=l11l1l1l1l1_tvp_ (u"ࠪࡿࢂ࠭૳")
    try:
        l1l1llllll1l1l1_tvp_ = json.loads(content)
    except:
        l1l1llllll1l1l1_tvp_={}
    if l1l1llllll1l1l1_tvp_.has_key(l11l1l1l1l1_tvp_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬ૴")):
        formats = l1l1llllll1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸࡸ࠭૵"))
        if isinstance(formats,list):
            l1ll1lll1l1l1l1_tvp_=[]
            for l11l11ll1l1l1_tvp_ in formats:
                if l11l1l1l1l1_tvp_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡻࡴࡤ࠯࡯ࡶ࠱ࡸࡹࠧ૶") in l11l11ll1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠧ࡮࡫ࡰࡩ࡙ࡿࡰࡦࠩ૷"),l11l1l1l1l1_tvp_ (u"ࠨࠩ૸")):
                    continue
                l1llllllll1l1l1_tvp_ =  l11l11ll1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠩࡷࡳࡹࡧ࡬ࡃ࡫ࡷࡶࡦࡺࡥࠨૹ"),l11l1l1l1l1_tvp_ (u"ࠪࠫૺ"))/100
                quality = l11l1l1l1l1_tvp_ (u"ࠫࡘࡊࠧૻ")
                if    2000 < l1llllllll1l1l1_tvp_ <= 5000  : quality = l11l1l1l1l1_tvp_ (u"࡙ࠬࡄࠨૼ")
                elif  5000 < l1llllllll1l1l1_tvp_ <= 10000 : quality = l11l1l1l1l1_tvp_ (u"࠭࠷࠳࠲ࡳࠫ૽")
                elif 10000 < l1llllllll1l1l1_tvp_ <= 20000 : quality = l11l1l1l1l1_tvp_ (u"ࠧ࠲࠲࠻࠴ࡵ࠭૾")
                elif 20000 < l1llllllll1l1l1_tvp_ <= 30000 : quality = l11l1l1l1l1_tvp_ (u"ࠨ࠴ࡎࠫ૿")
                elif l1llllllll1l1l1_tvp_ >= 30000 : quality = l11l1l1l1l1_tvp_ (u"ࠩ࠷ࡏࠬ଀")
                label = l11l1l1l1l1_tvp_ (u"ࠪࡆ࡮ࡺࡲࡢࡶࡨࠤࠪࡪࠠࡕࡻࡳࡩ࠿࠭ଁ")%l1llllllll1l1l1_tvp_ + l11l11ll1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠫࡲ࡯࡭ࡦࡖࡼࡴࡪ࠭ଂ"),l11l1l1l1l1_tvp_ (u"ࠬ࠭ଃ")).split(l11l1l1l1l1_tvp_ (u"࠭࠯ࠨ଄"))[-1]
                l1ll1lll1l1l1l1_tvp_.append({l11l1l1l1l1_tvp_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ଅ"):label,l11l1l1l1l1_tvp_ (u"ࠨࡷࡵࡰࠬଆ"):l11l11ll1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠩࡸࡶࡱ࠭ଇ"),l11l1l1l1l1_tvp_ (u"ࠪࠫଈ")),l11l1l1l1l1_tvp_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬଉ"):l1llllllll1l1l1_tvp_})
            l1ll1lll1l1l1l1_tvp_ = sorted(l1ll1lll1l1l1l1_tvp_, key=lambda k: k[l11l1l1l1l1_tvp_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭ଊ")])
        else:
            l1ll1lll1l1l1l1_tvp_ = formats.get(l11l1l1l1l1_tvp_ (u"࠭ࡵࡳ࡮ࠪଋ"),l11l1l1l1l1_tvp_ (u"ࠧࠨଌ"))
    return l1ll1lll1l1l1l1_tvp_
def l111l1l1l1l1_tvp_(l1lll111ll1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠨ࠵࠸࠺࠻࠻࠱࠱࠺ࠪ଍"),proxy={},timeout=l11111lll1l1l1_tvp_,pgate=False):
    l1ll1lll1l1l1l1_tvp_ = l1l11l11ll1l1l1_tvp_(l1lll111ll1l1l1_tvp_,proxy,timeout,pgate)
    if len(l1ll1lll1l1l1l1_tvp_)>0:
        return l1ll1lll1l1l1l1_tvp_
    l1l1llllll1l1l1_tvp_ = json.loads(l1ll111l1l1l1_tvp_(l1lll1ll1l1l1l1_tvp_+ l1lll111ll1l1l1_tvp_,proxy,timeout))
    if l1l1llllll1l1l1_tvp_.has_key(l11l1l1l1l1_tvp_ (u"ࠩࡹ࡭ࡩ࡫࡯ࡠࡷࡵࡰࠬ଎")):
        return l1l1llllll1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠪࡺ࡮ࡪࡥࡰࡡࡸࡶࡱ࠭ଏ"))
    else:
        l1l1llllll1l1l1_tvp_ = json.loads(l1ll111l1l1l1_tvp_(l1lll1ll1l1l1l1_tvp_+ l1lll111ll1l1l1_tvp_.split(l11l1l1l1l1_tvp_ (u"ࠫࠫ࠭ଐ"))[0],proxy,timeout))
        if l1l1llllll1l1l1_tvp_.has_key(l11l1l1l1l1_tvp_ (u"ࠬࡩ࡯ࡱࡻࡢࡳ࡫ࡥ࡯ࡣ࡬ࡨࡧࡹࡥࡩࡥࠩ଑")):
            l1lll111ll1l1l1_tvp_ = l1l1llllll1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"࠭ࡣࡰࡲࡼࡣࡴ࡬࡟ࡰࡤ࡭ࡩࡨࡺ࡟ࡪࡦࠪ଒")) + l11l1l1l1l1_tvp_ (u"ࠧࠧ࡯࡬ࡱࡪࡥࡴࡺࡲࡨࠫଓ")+ l1l1llllll1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠨ࡯࡬ࡱࡪࡥࡴࡺࡲࡨࠫଔ"),l11l1l1l1l1_tvp_ (u"ࠩࡹ࡭ࡩ࡫࡯࠰࡯ࡳ࠸ࠬକ"))
            l1ll1lll1l1l1l1_tvp_ = l1l11l11ll1l1l1_tvp_(l1lll111ll1l1l1_tvp_,proxy,timeout)
            return l1ll1lll1l1l1l1_tvp_
        elif l1l1llllll1l1l1_tvp_.has_key(l11l1l1l1l1_tvp_ (u"ࠪࡺ࡮ࡪࡥࡰࡡࡸࡶࡱ࠭ଖ")):
            return l1l1llllll1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠫࡻ࡯ࡤࡦࡱࡢࡹࡷࡲࠧଗ"))
    return l11l1l1l1l1_tvp_ (u"ࠬ࠭ଘ")
def l1l11l1l1l1l1l1_tvp_(item,l1l1l11lll1l1l1_tvp_=[l11l1l1l1l1_tvp_ (u"࠭ࡩ࡮ࡣࡪࡩࡤ࠷࠶ࡹ࠻ࠪଙ"),l11l1l1l1l1_tvp_ (u"ࠧࡪ࡯ࡤ࡫ࡪ࠭ଚ")]):
    l1ll1l11ll1l1l1_tvp_ = l11l1l1l1l1_tvp_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵ࠱ࡺ࠸࠴ࡴࡷࡲ࠱ࡴࡱ࠵ࡩ࡮ࡣࡪࡩࡸ࠵ࠥࡴ࠱ࠨࡷ࠴ࠫࡳ࠰ࡷ࡬ࡨࡤࠫࡳࡠࡹ࡬ࡨࡹ࡮࡟ࠦࡦࡢ࡫ࡸࡥ࠰࠯࡬ࡳ࡫ࠬଛ")
    l1llll1l1l1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠩࠪଜ")
    for key in l1l1l11lll1l1l1_tvp_:
        if key in item:
            l1lll1llll1l1l1_tvp_ = item[key][0].get(l11l1l1l1l1_tvp_ (u"ࠪࡪ࡮ࡲࡥࡠࡰࡤࡱࡪ࠭ଝ"),None)
            l1ll11ll1l1l1l1_tvp_ = item[key][0].get(l11l1l1l1l1_tvp_ (u"ࠫࡼ࡯ࡤࡵࡪࠪଞ"),None)
            if l1lll1llll1l1l1_tvp_ and l1ll11ll1l1l1l1_tvp_:
                l1llll1l1l1l1l1_tvp_ = l1ll1l11ll1l1l1_tvp_ %(l1lll1llll1l1l1_tvp_[0],l1lll1llll1l1l1_tvp_[1],l1lll1llll1l1l1_tvp_[2],l1lll1llll1l1l1_tvp_[:-4],l1ll11ll1l1l1l1_tvp_)
            break
    return l1llll1l1l1l1l1_tvp_
def l1ll111ll1l1l1_tvp_(l1ll1l1lll1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠬ࠷࠷࠹࠷࠷࠹࠹࠭ଟ")):
    l1ll1l111l1l1l1_tvp_=[
          {l11l1l1l1l1_tvp_ (u"࠭ࡩࡥࠩଠ"): 4934948, l11l1l1l1l1_tvp_ (u"ࠧࡪ࡯ࡪࠫଡ"): l11l1l1l1l1_tvp_ (u"ࠨࠩଢ"), l11l1l1l1l1_tvp_ (u"ࠩࡷ࡭ࡹࡲࡥࠨଣ"): l11l1l1l1l1_tvp_ (u"ࠪࡔࡷࡵࡧࡳࡣࡰࡽࠬତ")},
          {l11l1l1l1l1_tvp_ (u"ࠫ࡮ࡪࠧଥ"): 1649941, l11l1l1l1l1_tvp_ (u"ࠬ࡯࡭ࡨࠩଦ"): l11l1l1l1l1_tvp_ (u"࠭ࠧଧ"), l11l1l1l1l1_tvp_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ନ"): l11l1l1l1l1_tvp_ (u"ࠨࡕࡨࡶ࡮ࡧ࡬ࡦࠩ଩")},
          {l11l1l1l1l1_tvp_ (u"ࠩ࡬ࡨࠬପ"): 1627183, l11l1l1l1l1_tvp_ (u"ࠪ࡭ࡲ࡭ࠧଫ"): l11l1l1l1l1_tvp_ (u"ࠫࠬବ"), l11l1l1l1l1_tvp_ (u"ࠬࡺࡩࡵ࡮ࡨࠫଭ"): l11l1l1l1l1_tvp_ (u"࠭ࡆࡪ࡮ࡰࡽࠥࡌࡡࡣࡷ࡯ࡥࡷࡴࡥࠨମ")},
          {l11l1l1l1l1_tvp_ (u"ࠧࡪࡦࠪଯ"): 4190012, l11l1l1l1l1_tvp_ (u"ࠨ࡫ࡰ࡫ࠬର"): l11l1l1l1l1_tvp_ (u"ࠩࠪ଱"), l11l1l1l1l1_tvp_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩଲ"): l11l1l1l1l1_tvp_ (u"ࠫࡋ࡯࡬࡮ࡻࠣࡈࡴࡱࡵ࡮ࡧࡱࡸࡦࡲ࡮ࡦࠩଳ")},
          {l11l1l1l1l1_tvp_ (u"ࠬ࡯ࡤࠨ଴"): 4934932,l11l1l1l1l1_tvp_ (u"࠭ࡩ࡮ࡩࠪଵ"): l11l1l1l1l1_tvp_ (u"ࠧࠨଶ"), l11l1l1l1l1_tvp_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧଷ"): l11l1l1l1l1_tvp_ (u"ࠩࡇࡰࡦࠦࡄࡻ࡫ࡨࡧ࡮࠭ସ")},
          {l11l1l1l1l1_tvp_ (u"ࠪ࡭ࡩ࠭ହ"): 30904461,l11l1l1l1l1_tvp_ (u"ࠫ࡮ࡳࡧࠨ଺"): l11l1l1l1l1_tvp_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹ࠮ࡷ࠵࠱ࡸࡻࡶ࠮ࡱ࡮࠲࡭ࡲࡧࡧࡦࡵ࠲࠻࠴࡫࠯࠹࠱ࡸ࡭ࡩࡥ࠷ࡦ࠺࠴࠼࡫ࡩ࠵ࡦࡦ࠹ࡪ࠶࠿࠷࠷ࡣ࠼࠺࠵࡫࠲ࡦ࠷࠸࠷࠵࠺࠳࠱࠵࠹࠵࠹࠿࠵࠶࠵࠴࠼࠽࠻࠹࠳࠷ࡢࡻ࡮ࡪࡴࡩࡡ࠻࠴࠵ࡥࡧࡴࡡ࠳࠲࡯ࡶࡧࠨ଻"), l11l1l1l1l1_tvp_ (u"࠭ࡴࡪࡶ࡯ࡩ଼ࠬ"): l11l1l1l1l1_tvp_ (u"ࠧࡊࡰࡩࡳࡷࡳࡡࡤ࡬ࡨࠫଽ")},
          {l11l1l1l1l1_tvp_ (u"ࠨ࡫ࡧࠫା"): 4934956,l11l1l1l1l1_tvp_ (u"ࠩ࡬ࡱ࡬࠭ି"): l11l1l1l1l1_tvp_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷ࠳ࡼ࠳࠯ࡶࡹࡴ࠳ࡶ࡬࠰࡫ࡰࡥ࡬࡫ࡳ࠰࠴࠲࠸࠴࠽࠯ࡶ࡫ࡧࡣ࠷࠺࠷࠱࠴ࡤ࠵ࡧ࠻ࡥ࠸ࡣࡨࡧ࠽࠻ࡤ࠱ࡧࡩ࠹࠼ࡨ࠵࠲ࡥ࠷࠵࠻࠹࠰࠸࠳࠷࠽࠺࠻࠴࠱࠶࠹࠶࠻࠶࠳ࡠࡹ࡬ࡨࡹ࡮࡟࠹࠲࠳ࡣ࡬ࡹ࡟࠱࠰࡭ࡴ࡬࠭ୀ"), l11l1l1l1l1_tvp_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪୁ"): l11l1l1l1l1_tvp_ (u"ࠬࡖࡵࡣ࡮࡬ࡧࡾࡹࡴࡺ࡭ࡤࠫୂ")},
          {l11l1l1l1l1_tvp_ (u"࠭ࡩࡥࠩୃ"): 4190017, l11l1l1l1l1_tvp_ (u"ࠧࡪ࡯ࡪࠫୄ"): l11l1l1l1l1_tvp_ (u"ࠨࠩ୅"), l11l1l1l1l1_tvp_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ୆"): l11l1l1l1l1_tvp_ (u"ࠪࡖࡪࡺࡲࡰࠩେ")},
          {l11l1l1l1l1_tvp_ (u"ࠫ࡮ࡪࠧୈ"): 6442748, l11l1l1l1l1_tvp_ (u"ࠬ࡯࡭ࡨࠩ୉"): l11l1l1l1l1_tvp_ (u"࠭ࠧ୊"), l11l1l1l1l1_tvp_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ୋ"): l11l1l1l1l1_tvp_ (u"ࠨࡒࡲࡰࡪࡩࡡ࡯ࡧࠪୌ")} ,
          {l11l1l1l1l1_tvp_ (u"ࠩ࡬ࡨ୍ࠬ"): 35561705, l11l1l1l1l1_tvp_ (u"ࠪ࡭ࡲ࡭ࠧ୎"): l11l1l1l1l1_tvp_ (u"ࠫࠬ୏"), l11l1l1l1l1_tvp_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ୐"): l11l1l1l1l1_tvp_ (u"࠭ࡒࡦ࡭ࡲࡲࡸࡺࡲࡶ࡭ࡦ࡮ࡦࠦࡆࡪ࡮ࡰࡳࡼࡧࠧ୑")} ,
        ]
    return l1ll1l111l1l1l1_tvp_
def l11lllll1l1l1_tvp_():
    out=[{l11l1l1l1l1_tvp_ (u"ࠧࡪࡦࠪ୒"): 459028,l11l1l1l1l1_tvp_ (u"ࠨ࡫ࡰ࡫ࠬ୓"): l11l1l1l1l1_tvp_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶ࠲ࡹࡼࡰ࠯ࡲ࡯࠳࡫࡯࡬ࡦࡵ࠲ࡸࡻࡶࡲࡦࡩ࡬ࡳࡳࡧ࡬࡯ࡣ࠲ࡲࡪࡽࡧࡧࡺ࠲ࡰࡴ࡭࡯࠰ࡤ࡬ࡥࡱࡿࡳࡵࡱ࡮࠲ࡵࡴࡧࠨ୔"),l11l1l1l1l1_tvp_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ୕"): l11l1l1l1l1_tvp_ (u"ࡹࠬࡈࡩࡢ࡞ࡸ࠴࠶࠺࠲ࡺࡵࡷࡳࡰ࠭ୖ")},
        {l11l1l1l1l1_tvp_ (u"ࠬ࡯ࡤࠨୗ"): 458968,l11l1l1l1l1_tvp_ (u"࠭ࡩ࡮ࡩࠪ୘"): l11l1l1l1l1_tvp_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴ࠰ࡷࡺࡵ࠴ࡰ࡭࠱ࡩ࡭ࡱ࡫ࡳ࠰ࡶࡹࡴࡷ࡫ࡧࡪࡱࡱࡥࡱࡴࡡ࠰ࡰࡨࡻ࡬࡬ࡸ࠰࡮ࡲ࡫ࡴ࠵ࡢࡺࡦࡪࡳࡸࢀࡣࡻ࠰ࡳࡲ࡬࠭୙"),l11l1l1l1l1_tvp_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ୚"): l11l1l1l1l1_tvp_ (u"ࡷࠪࡆࡾࡪࡧࡰࡵࡽࡧࡿ࠭୛")},
        {l11l1l1l1l1_tvp_ (u"ࠪ࡭ࡩ࠭ଡ଼"): 272459,l11l1l1l1l1_tvp_ (u"ࠫ࡮ࡳࡧࠨଢ଼"): l11l1l1l1l1_tvp_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹ࠮ࡵࡸࡳ࠲ࡵࡲ࠯ࡧ࡫࡯ࡩࡸ࠵ࡴࡷࡲࡵࡩ࡬࡯࡯࡯ࡣ࡯ࡲࡦ࠵࡮ࡦࡹࡪࡪࡽ࠵࡬ࡰࡩࡲ࠳࡬ࡪࡡ࡯ࡵ࡮࠲ࡵࡴࡧࠨ୞"),l11l1l1l1l1_tvp_ (u"࠭ࡴࡪࡶ࡯ࡩࠬୟ"): l11l1l1l1l1_tvp_ (u"ࡵࠨࡉࡧࡥࡡࡻ࠰࠲࠶࠷ࡷࡰ࠭ୠ")},
        {l11l1l1l1l1_tvp_ (u"ࠨ࡫ࡧࠫୡ"): 459184,l11l1l1l1l1_tvp_ (u"ࠩ࡬ࡱ࡬࠭ୢ"): l11l1l1l1l1_tvp_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷ࠳ࡺࡶࡱ࠰ࡳࡰ࠴࡬ࡩ࡭ࡧࡶ࠳ࡹࡼࡰࡳࡧࡪ࡭ࡴࡴࡡ࡭ࡰࡤ࠳ࡳ࡫ࡷࡨࡨࡻ࠳ࡱࡵࡧࡰ࠱ࡪࡳࡷࢀ࡯ࡸ࠰ࡳࡲ࡬࠭ୣ"),l11l1l1l1l1_tvp_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ୤"): l11l1l1l1l1_tvp_ (u"ࡺ࠭ࡇࡰࡴࡽࡠࡽ࡬࠳ࡸ࡚ࠢࡰࡰࡶ࠮ࠨ୥")},
        {l11l1l1l1l1_tvp_ (u"࠭ࡩࡥࠩ୦"): 459149,l11l1l1l1l1_tvp_ (u"ࠧࡪ࡯ࡪࠫ୧"): l11l1l1l1l1_tvp_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵ࠱ࡸࡻࡶ࠮ࡱ࡮࠲ࡪ࡮ࡲࡥࡴ࠱ࡷࡺࡵࡸࡥࡨ࡫ࡲࡲࡦࡲ࡮ࡢ࠱ࡱࡩࡼ࡭ࡦࡹ࠱࡯ࡳ࡬ࡵ࠯࡬ࡣࡷࡳࡼ࡯ࡣࡦ࠰ࡳࡲ࡬࠭୨"),l11l1l1l1l1_tvp_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ୩"): l11l1l1l1l1_tvp_ (u"ࡸࠫࡐࡧࡴࡰࡹ࡬ࡧࡪ࠭୪")},
        {l11l1l1l1l1_tvp_ (u"ࠫ࡮ࡪࠧ୫"): 459175,l11l1l1l1l1_tvp_ (u"ࠬ࡯࡭ࡨࠩ୬"): l11l1l1l1l1_tvp_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳ࠯ࡶࡹࡴ࠳ࡶ࡬࠰ࡨ࡬ࡰࡪࡹ࠯ࡵࡸࡳࡶࡪ࡭ࡩࡰࡰࡤࡰࡳࡧ࠯࡯ࡧࡺ࡫࡫ࡾ࠯࡭ࡱࡪࡳ࠴ࡱࡩࡦ࡮ࡦࡩ࠳ࡶ࡮ࡨࠩ୭"),l11l1l1l1l1_tvp_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭୮"): l11l1l1l1l1_tvp_ (u"ࡶࠩࡎ࡭ࡪࡲࡣࡦࠩ୯")},
        {l11l1l1l1l1_tvp_ (u"ࠩ࡬ࡨࠬ୰"): 554276,l11l1l1l1l1_tvp_ (u"ࠪ࡭ࡲ࡭ࠧୱ"): l11l1l1l1l1_tvp_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸ࠴ࡴࡷࡲ࠱ࡴࡱ࠵ࡦࡪ࡮ࡨࡷ࠴ࡺࡶࡱࡴࡨ࡫࡮ࡵ࡮ࡢ࡮ࡱࡥ࠴ࡴࡥࡸࡩࡩࡼ࠴ࡲ࡯ࡨࡱ࠲࡯ࡷࡧ࡫ࡰࡹ࠱ࡴࡳ࡭ࠧ୲"),l11l1l1l1l1_tvp_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ୳"): l11l1l1l1l1_tvp_ (u"ࡻࠧࡌࡴࡤ࡯ࡡࡾࡦ࠴ࡹࠪ୴")},
        {l11l1l1l1l1_tvp_ (u"ࠧࡪࡦࠪ୵"): 459226,l11l1l1l1l1_tvp_ (u"ࠨ࡫ࡰ࡫ࠬ୶"): l11l1l1l1l1_tvp_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶ࠲ࡹࡼࡰ࠯ࡲ࡯࠳࡫࡯࡬ࡦࡵ࠲ࡸࡻࡶࡲࡦࡩ࡬ࡳࡳࡧ࡬࡯ࡣ࠲ࡲࡪࡽࡧࡧࡺ࠲ࡰࡴ࡭࡯࠰࡮ࡸࡦࡱ࡯࡮࠯ࡲࡱ࡫ࠬ୷"),l11l1l1l1l1_tvp_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ୸"): l11l1l1l1l1_tvp_ (u"ࡹࠬࡒࡵࡣ࡮࡬ࡲࠬ୹")},
        {l11l1l1l1l1_tvp_ (u"ࠬ࡯ࡤࠨ୺"): 459145,l11l1l1l1l1_tvp_ (u"࠭ࡩ࡮ࡩࠪ୻"): l11l1l1l1l1_tvp_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴ࠰ࡷࡺࡵ࠴ࡰ࡭࠱ࡩ࡭ࡱ࡫ࡳ࠰ࡶࡹࡴࡷ࡫ࡧࡪࡱࡱࡥࡱࡴࡡ࠰ࡰࡨࡻ࡬࡬ࡸ࠰࡮ࡲ࡫ࡴ࠵࡬ࡰࡦࡽ࠲ࡵࡴࡧࠨ୼"),l11l1l1l1l1_tvp_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ୽"): l11l1l1l1l1_tvp_ (u"ࡷࠪࡠࡺ࠶࠱࠵࠳࡟ࡼ࡫࠹ࡤ࡝ࡷ࠳࠵࠼ࡧࠧ୾")},
        {l11l1l1l1l1_tvp_ (u"ࠪ࡭ࡩ࠭୿"): 623642,l11l1l1l1l1_tvp_ (u"ࠫ࡮ࡳࡧࠨ஀"): l11l1l1l1l1_tvp_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹ࠮ࡵࡸࡳ࠲ࡵࡲ࠯ࡧ࡫࡯ࡩࡸ࠵ࡴࡷࡲࡵࡩ࡬࡯࡯࡯ࡣ࡯ࡲࡦ࠵࡮ࡦࡹࡪࡪࡽ࠵࡬ࡰࡩࡲ࠳ࡴࡲࡳࡻࡶࡼࡲ࠳ࡶ࡮ࡨࠩ஁"),l11l1l1l1l1_tvp_ (u"࠭ࡴࡪࡶ࡯ࡩࠬஂ"): l11l1l1l1l1_tvp_ (u"ࡵࠨࡑ࡯ࡷࡿࡺࡹ࡯ࠩஃ")},
        {l11l1l1l1l1_tvp_ (u"ࠨ࡫ࡧࠫ஄"): 1194632,l11l1l1l1l1_tvp_ (u"ࠩ࡬ࡱ࡬࠭அ"): l11l1l1l1l1_tvp_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡷ࠳ࡺࡶࡱ࠰ࡳࡰ࠴࡬ࡩ࡭ࡧࡶ࠳ࡹࡼࡰࡳࡧࡪ࡭ࡴࡴࡡ࡭ࡰࡤ࠳ࡳ࡫ࡷࡨࡨࡻ࠳ࡱࡵࡧࡰ࠱ࡲࡴࡴࡲࡥ࠯ࡲࡱ࡫ࠬஆ"),l11l1l1l1l1_tvp_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪஇ"): l11l1l1l1l1_tvp_ (u"ࡺ࠭ࡏࡱࡱ࡯ࡩࠬஈ")},
        {l11l1l1l1l1_tvp_ (u"࠭ࡩࡥࠩஉ"): 459083,l11l1l1l1l1_tvp_ (u"ࠧࡪ࡯ࡪࠫஊ"): l11l1l1l1l1_tvp_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵ࠱ࡸࡻࡶ࠮ࡱ࡮࠲ࡪ࡮ࡲࡥࡴ࠱ࡷࡺࡵࡸࡥࡨ࡫ࡲࡲࡦࡲ࡮ࡢ࠱ࡱࡩࡼ࡭ࡦࡹ࠱࡯ࡳ࡬ࡵ࠯ࡱࡱࡽࡲࡦࡴ࠮ࡱࡰࡪࠫ஋"),l11l1l1l1l1_tvp_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ஌"): l11l1l1l1l1_tvp_ (u"ࡸࠫࡕࡵࡺ࡯ࡣ࡟ࡹ࠵࠷࠴࠵ࠩ஍")},
        {l11l1l1l1l1_tvp_ (u"ࠫ࡮ࡪࠧஎ"): 459133,l11l1l1l1l1_tvp_ (u"ࠬ࡯࡭ࡨࠩஏ"): l11l1l1l1l1_tvp_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡳ࠯ࡶࡹࡴ࠳ࡶ࡬࠰ࡨ࡬ࡰࡪࡹ࠯ࡵࡸࡳࡶࡪ࡭ࡩࡰࡰࡤࡰࡳࡧ࠯࡯ࡧࡺ࡫࡫ࡾ࠯࡭ࡱࡪࡳ࠴ࡸࡺࡦࡵࡽࡳࡼ࠴ࡰ࡯ࡩࠪஐ"),l11l1l1l1l1_tvp_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭஑"): l11l1l1l1l1_tvp_ (u"ࡶࠩࡕࡾࡪࡹࡺ࡝ࡺࡩ࠷ࡼ࠭ஒ")},
        {l11l1l1l1l1_tvp_ (u"ࠩ࡬ࡨࠬஓ"): 1277569,l11l1l1l1l1_tvp_ (u"ࠪ࡭ࡲ࡭ࠧஔ"): l11l1l1l1l1_tvp_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸ࠴ࡴࡷࡲ࠱ࡴࡱ࠵ࡦࡪ࡮ࡨࡷ࠴ࡺࡶࡱࡴࡨ࡫࡮ࡵ࡮ࡢ࡮ࡱࡥ࠴ࡴࡥࡸࡩࡩࡼ࠴ࡲ࡯ࡨࡱ࠲ࡷࡿࡩࡺࡦࡥ࡬ࡲ࠳ࡶ࡮ࡨࠩக"),l11l1l1l1l1_tvp_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ஖"): l11l1l1l1l1_tvp_ (u"ࡻࠧࡔࡼࡦࡾࡪࡩࡩ࡯ࠩ஗")},
        {l11l1l1l1l1_tvp_ (u"ࠧࡪࡦࠪ஘"): 459190, l11l1l1l1l1_tvp_ (u"ࠨ࡫ࡰ࡫ࠬங"): l11l1l1l1l1_tvp_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶ࠲ࡹࡼࡰ࠯ࡲ࡯࠳࡫࡯࡬ࡦࡵ࠲ࡸࡻࡶࡲࡦࡩ࡬ࡳࡳࡧ࡬࡯ࡣ࠲ࡲࡪࡽࡧࡧࡺ࠲ࡰࡴ࡭࡯࠰ࡹࡤࡶࡸࢀࡡࡸࡣ࠱ࡴࡳ࡭ࠧச"), l11l1l1l1l1_tvp_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ஛"): l11l1l1l1l1_tvp_ (u"ࡹࠬ࡝ࡡࡳࡵࡽࡥࡼࡧࠧஜ")},
        {l11l1l1l1l1_tvp_ (u"ࠬ࡯ࡤࠨ஝"): 553964,l11l1l1l1l1_tvp_ (u"࠭ࡩ࡮ࡩࠪஞ"): l11l1l1l1l1_tvp_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡴ࠰ࡷࡺࡵ࠴ࡰ࡭࠱ࡩ࡭ࡱ࡫ࡳ࠰ࡶࡹࡴࡷ࡫ࡧࡪࡱࡱࡥࡱࡴࡡ࠰ࡰࡨࡻ࡬࡬ࡸ࠰࡮ࡲ࡫ࡴ࠵ࡷࡳࡱࡦࡰࡦࡽ࠮ࡱࡰࡪࠫட"),l11l1l1l1l1_tvp_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ஠"): l11l1l1l1l1_tvp_ (u"ࡷ࡛ࠪࡷࡵࡣ࡝ࡷ࠳࠵࠹࠸ࡡࡸࠩ஡")}]
    return out
def _1l11lllll1l1l1_tvp_():
    _1l1ll1lll1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠪࠫࠬࡂࡵ࡭ࠢࡦࡰࡦࡹࡳ࠾ࠤࡩࡼ࠲࡬ࡡࡥࡧ࠰ࡲࡴࡸ࡭ࡢ࡮ࠣࡪࡽ࠳ࡳࡱࡧࡨࡨ࠲࠸࠰࠱ࠤࠣࡨࡦࡺࡡ࠮ࡰࡪ࠱ࡸ࡮࡯ࡸ࠿ࠥࡱࡪࡴࡵ࠯ࡧࡻࡴࡦࡴࡤࡦࡦࡀࡁࠬࡸࡥࡨ࡫ࡲࡲࡦࡲࠧࠣࡀࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡢࡪࡣ࡯ࡽࡸࡺ࡯࡬࠰ࡷࡺࡵ࠴ࡰ࡭ࠤࡁࡆ࡮ࡧूࡺࡵࡷࡳࡰࡂ࠯ࡢࡀ࠿࠳ࡱ࡯࠾ࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡧࡿࡤࡨࡱࡶࡾࡨࢀ࠮ࡵࡸࡳ࠲ࡵࡲࠢ࠿ࡄࡼࡨ࡬ࡵࡳࡻࡥࡽࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡪࡨࡦࡴࡳ࡬࠰ࡷࡺࡵ࠴ࡰ࡭ࠤࡁࡋࡩࡧॄࡴ࡭࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡩࡲࡶࡿࡵࡷ࠯ࡶࡹࡴ࠳ࡶ࡬ࠣࡀࡊࡳࡷࢀࣳࡸ࡚ࠢࡰࡰࡶ࠮࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠾࠴࠵࡫ࡢࡶࡲࡻ࡮ࡩࡥ࠯ࡶࡹࡴ࠳ࡶ࡬ࠣࡀࡎࡥࡹࡵࡷࡪࡥࡨࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱࡮࡭ࡪࡲࡣࡦ࠰ࡷࡺࡵ࠴ࡰ࡭ࠤࡁࡏ࡮࡫࡬ࡤࡧ࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࡪࡷࡸࡵࡀ࠯࠰࡭ࡵࡥࡰࡵࡷ࠯ࡶࡹࡴ࠳ࡶ࡬ࠣࡀࡎࡶࡦࡱࣳࡸ࠾࠲ࡥࡃࡂ࠯࡭࡫ࡁࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࡩࡶࡷࡴ࠿࠵࠯࡭ࡷࡥࡰ࡮ࡴ࠮ࡵࡸࡳ࠲ࡵࡲࠢ࠿ࡎࡸࡦࡱ࡯࡮࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠾࠴࠵࡬ࡰࡦࡽ࠲ࡹࡼࡰ࠯ࡲ࡯ࠦࡃेࣳࡥॼ࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࡪࡷࡸࡵࡀ࠯࠰ࡱ࡯ࡷࡿࡺࡹ࡯࠰ࡷࡺࡵ࠴ࡰ࡭ࠤࡁࡓࡱࡹࡺࡵࡻࡱࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡲࡴࡴࡲࡥ࠯ࡶࡹࡴ࠳ࡶ࡬ࠣࡀࡒࡴࡴࡲࡥ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡰࡰࡼࡱࡥࡳ࠴ࡴࡷࡲ࠱ࡴࡱࠨ࠾ࡑࡱࡽࡲࡦॊ࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡸࡺࡦࡵࡽࡳࡼ࠴ࡴࡷࡲ࠱ࡴࡱࠨ࠾ࡓࡼࡨࡷࡿࣹࡷ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠾࠴࠵ࡳࡻࡥࡽࡩࡨ࡯࡮࠯ࡶࡹࡴ࠳ࡶ࡬ࠣࡀࡖࡾࡨࢀࡥࡤ࡫ࡱࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡥࡷࡹࡺࡢࡹࡤ࠲ࡹࡼࡰ࠯ࡲ࡯ࠦࡃ࡝ࡡࡳࡵࡽࡥࡼࡧ࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦ࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡲࡰࡥ࡯ࡥࡼ࠴ࡴࡷࡲ࠱ࡴࡱࠨ࠾ࡘࡴࡲࡧेࡧࡷ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࡂ࠯ࡶ࡮ࡁࠫࠬ࠭஢")
    out=[]
    l1l11lll1l1l1l1_tvp_ = re.findall(l11l1l1l1l1_tvp_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪண"),_1l1ll1lll1l1l1_tvp_)
    for href, name in l1l11lll1l1l1l1_tvp_:
        l1llllll1l1l1l1_tvp_=l1ll111l1l1l1_tvp_(href)
        id = re.findall(l11l1l1l1l1_tvp_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡵࡻࡢ࠰ࡵࡨࡷࡸ࠵ࡶࡪࡧࡺࡶࡪࡷࡵࡦࡵࡷࡠࡄࡵࡢ࡫ࡧࡦࡸࡤ࡯ࡤ࠾ࠪ࡟ࡨ࠰࠯ࠢࠨத"),l1llllll1l1l1l1_tvp_)
        l111l1l1l1_tvp_ = re.findall(l11l1l1l1l1_tvp_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡬ࡰࡩࡲࠦࡃࡡ࡜ࡴ࡞ࡱࡡ࠯ࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡣ࡯ࡸࡂ࠭஥"),l1llllll1l1l1l1_tvp_,re.DOTALL)
        l111l1l1l1_tvp_ = l11l1l1l1l1_tvp_ (u"ࠧࡩࡶࡷࡴ࠿࠭஦")+l111l1l1l1_tvp_[0] if l111l1l1l1_tvp_ else l11l1l1l1l1_tvp_ (u"ࠨࠩ஧")
        if id:
            l1lll1l11l1l1l1_tvp_=id[0]
            l1l1llllll1l1l1_tvp_=l1llll11ll1l1l1_tvp_(l1lll1l11l1l1l1_tvp_,l1l1llll1l1l1l1_tvp_)
            items = l1l1llllll1l1l1_tvp_.pop(l11l1l1l1l1_tvp_ (u"ࠩ࡬ࡸࡪࡳࡳࠨந"))
            for i in items:
                if i[l11l1l1l1l1_tvp_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩன")].lower()==l11l1l1l1l1_tvp_ (u"ࠫࡸ࡫ࡲࡸ࡫ࡶࡽࠬப"):
                    l1lll1l11l1l1l1_tvp_ = i[l11l1l1l1l1_tvp_ (u"ࠬࡥࡩࡥࠩ஫")]
                    break
            out.append( {l11l1l1l1l1_tvp_ (u"࠭ࡩࡥࠩ஬"): l1lll1l11l1l1l1_tvp_, l11l1l1l1l1_tvp_ (u"ࠧࡪ࡯ࡪࠫ஭"): l111l1l1l1_tvp_, l11l1l1l1l1_tvp_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧம"): name.decode(l11l1l1l1l1_tvp_ (u"ࠩࡸࡸ࡫࠳࠸ࠨய"))} )
    return out
def l11l1lll1l1l1_tvp_(l1ll1l1lll1l1l1_tvp_=34932047,l11llll1l1l1_tvp_=1,l1l1llll1l1l1l1_tvp_=500):
    l11llll1l1l1_tvp_=int(l11llll1l1l1_tvp_)
    l1l1llll1l1l1l1_tvp_=int(l1l1llll1l1l1l1_tvp_)
    l1l1llllll1l1l1_tvp_=l1llll11ll1l1l1_tvp_(l1ll1l1lll1l1l1_tvp_,l1l1llll1l1l1l1_tvp_)
    l1l1l1llll1l1l1_tvp_=False
    if l1l1llllll1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠪࡸࡴࡺࡡ࡭ࡡࡦࡳࡺࡴࡴࠨர"),l1l1llll1l1l1l1_tvp_) > l1l1llll1l1l1l1_tvp_:
        l1l1l1llll1l1l1_tvp_ = {l11l1l1l1l1_tvp_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪற"):l11l1l1l1l1_tvp_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࡭࡯࡭ࡦࡠࠤࡃࡄࠠ࡯ࡣࡶࡸञࡶ࡮ࡦࠢࠨࡨࠥ࠵ࠠࠦࡦࠣࡂࡃࡡ࠯ࡄࡑࡏࡓࡗࡣࠧல")%(l1l1llll1l1l1l1_tvp_*l11llll1l1l1_tvp_,l1l1llllll1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"࠭ࡴࡰࡶࡤࡰࡤࡩ࡯ࡶࡰࡷࠫள"),l1l1llll1l1l1l1_tvp_)),l11l1l1l1l1_tvp_ (u"ࠧࡪࡦࠪழ"):l1ll1l1lll1l1l1_tvp_,l11l1l1l1l1_tvp_ (u"ࠨࡲࡤ࡫ࡪ࠭வ"):int(l11llll1l1l1_tvp_)+1,l11l1l1l1l1_tvp_ (u"ࠩ࡬ࡱ࡬࠭ஶ"):l11l1l1l1l1_tvp_ (u"ࠪࠫஷ")}
        if l11llll1l1l1_tvp_>1:
            l1lllll11l1l1l1_tvp_ = l1l1llll1l1l1l1_tvp_*l11llll1l1l1_tvp_
            l1l1llllll1l1l1_tvp_=l1llll11ll1l1l1_tvp_(l1ll1l1lll1l1l1_tvp_,l1lllll11l1l1l1_tvp_)
    items = l1l1llllll1l1l1_tvp_.pop(l11l1l1l1l1_tvp_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠪஸ"))
    l1l1lll11l1l1l1_tvp_=[]
    l1l111l11l1l1l1_tvp_=[]
    if int(l11llll1l1l1_tvp_)>1 and len(items) > l1l1llll1l1l1l1_tvp_: items = items[(l11llll1l1l1_tvp_-1)*l1l1llll1l1l1l1_tvp_ :]
    l1l1ll1l1l1l1l1_tvp_=False
    if l1l1llllll1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠬ࡬࡯ࡶࡰࡧࡣࡦࡴࡹࠨஹ")):
        for item in items:
            if len(item.get(l11l1l1l1l1_tvp_ (u"࠭ࡶࡪࡦࡨࡳࡋࡵࡲ࡮ࡣࡷࡑ࡮ࡳࡥࡴࠩ஺"),[])):
                l1l1ll111l1l1l1_tvp_=_1ll11l1ll1l1l1_tvp_(item)
                if l1l1ll111l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠧࡧ࡫࡯ࡩࡳࡧ࡭ࡦࠩ஻"),l11l1l1l1l1_tvp_ (u"ࠨࠩ஼")):
                    l1l111l11l1l1l1_tvp_.append(l1l1ll111l1l1l1_tvp_)
            elif item.get(l11l1l1l1l1_tvp_ (u"ࠩࡳࡰࡦࡿࡡࡣ࡮ࡨࠫ஽"),False):
                l1l1ll111l1l1l1_tvp_=_1ll11l1ll1l1l1_tvp_(item)
                if l1l1ll111l1l1l1_tvp_.get(l11l1l1l1l1_tvp_ (u"ࠪࡪ࡮ࡲࡥ࡯ࡣࡰࡩࠬா"),l11l1l1l1l1_tvp_ (u"ࠫࠬி")):
                    l1l1ll111l1l1l1_tvp_[l11l1l1l1l1_tvp_ (u"ࠬ࡬ࡩ࡭ࡧࡱࡥࡲ࡫ࠧீ")]=str(item.get(l11l1l1l1l1_tvp_ (u"࠭ࡡࡴࡵࡨࡸࡤ࡯ࡤࠨு"),l11l1l1l1l1_tvp_ (u"ࠧࠨூ")))
                    l1l111l11l1l1l1_tvp_.append(l1l1ll111l1l1l1_tvp_)
            else:
                title= item.get(l11l1l1l1l1_tvp_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ௃"),l11l1l1l1l1_tvp_ (u"ࠩࠪ௄")).encode(l11l1l1l1l1_tvp_ (u"ࠪࡹࡹ࡬࠭࠹ࠩ௅"))
                _1l111ll1l1l1l1_tvp_=item.get(l11l1l1l1l1_tvp_ (u"ࠫࡤ࡯ࡤࠨெ"),l11l1l1l1l1_tvp_ (u"ࠬ࠭ே"))
                if title.lower() == l11l1l1l1l1_tvp_ (u"࠭ࡷࡪࡦࡨࡳࠬை") and _1l111ll1l1l1l1_tvp_:
                    l1l1ll1l1l1l1l1_tvp_=_1l111ll1l1l1l1_tvp_
                    break
                if item[l11l1l1l1l1_tvp_ (u"ࠧࡶࡴ࡯ࠫ௉")].startswith(l11l1l1l1l1_tvp_ (u"ࠨࡪࡷࡸࡵ࠭ொ")):
                    l111l1l1l1_tvp_= l1l11l1l1l1l1l1_tvp_(item,[l11l1l1l1l1_tvp_ (u"ࠩ࡬ࡱࡦ࡭ࡥࠨோ"),l11l1l1l1l1_tvp_ (u"ࠪ࡭ࡲࡧࡧࡦࡡ࠷ࡼ࠸࠭ௌ")])
                    l1l1lll11l1l1l1_tvp_.append({l11l1l1l1l1_tvp_ (u"ࠫ࡮ࡳࡧࠨ்"):l111l1l1l1_tvp_,l11l1l1l1l1_tvp_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ௎"):title,l11l1l1l1l1_tvp_ (u"࠭ࡩࡥࠩ௏"):_1l111ll1l1l1l1_tvp_})
    if l1l1ll1l1l1l1l1_tvp_:
        (l1l1lll11l1l1l1_tvp_,l1l111l11l1l1l1_tvp_) = l11l1lll1l1l1_tvp_(l1l1ll1l1l1l1l1_tvp_,l11llll1l1l1_tvp_,l1l1llll1l1l1l1_tvp_)
    if l1l1l1llll1l1l1_tvp_:
        l1l1lll11l1l1l1_tvp_ =[l1l1l1llll1l1l1_tvp_]
    return (l1l1lll11l1l1l1_tvp_,l1l111l11l1l1l1_tvp_)
def l1lll1lll1l1l1_tvp_(url):
    out=[url]
    if url and url.endswith(l11l1l1l1l1_tvp_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭ௐ")):
        l1l1ll11ll1l1l1_tvp_ = re.search(l11l1l1l1l1_tvp_ (u"ࠨ࠱ࠫࡠࡼ࠱ࠩ࡝࠰ࡰ࠷ࡺ࠾ࠧ௑"),url)
        l1l1ll11ll1l1l1_tvp_ = l1l1ll11ll1l1l1_tvp_.group(1) if l1l1ll11ll1l1l1_tvp_ else l11l1l1l1l1_tvp_ (u"ࠩࡰࡥࡳ࡯ࡦࡦࡵࡷࠫ௒")
        content = l1ll111l1l1l1_tvp_(url)
        l1ll111l1l1l1l1_tvp_=re.compile(l11l1l1l1l1_tvp_ (u"ࠪࡖࡊ࡙ࡏࡍࡗࡗࡍࡔࡔ࠽ࠩ࠰࠭ࡃ࠮ࡢࡲ࡝ࡰࠫࡕࡺࡧ࡬ࡪࡶࡼࡐࡪࡼࡥ࡭ࡵ࡟ࠬ࠳࠰࡜ࠪ࠱ࡰࡥࡳ࡯ࡦࡦࡵࡷࡠ࠭࡬࡯ࡳ࡯ࡤࡸࡂࡳ࠳ࡶ࠺࠰ࡥࡦࡶ࡬࡝ࠫࠬࠫ௓")).findall(content)
        if l1ll111l1l1l1l1_tvp_:
            out=[{l11l1l1l1l1_tvp_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ௔"):l11l1l1l1l1_tvp_ (u"ࠬࡧࡵࡵࡱࠪ௕"),l11l1l1l1l1_tvp_ (u"࠭ࡵࡳ࡮ࠪ௖"):url}]
            for title, part in l1ll111l1l1l1l1_tvp_:
                l11l11ll1l1l1_tvp_={l11l1l1l1l1_tvp_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ௗ"):title,l11l1l1l1l1_tvp_ (u"ࠨࡷࡵࡰࠬ௘"):url.replace(l11l1l1l1l1_tvp_ (u"ࠩࡰࡥࡳ࡯ࡦࡦࡵࡷࠫ௙"),part)}
                out.append(l11l11ll1l1l1_tvp_)
    return out
