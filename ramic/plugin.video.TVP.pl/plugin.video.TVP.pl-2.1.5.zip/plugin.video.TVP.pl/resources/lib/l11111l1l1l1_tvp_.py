# -*- coding: utf-8 -*-
import sys
l1l1l11ll1l1l1_tvp_ = sys.version_info [0] == 2
l1lllll1l1l1l1_tvp_ = 2048
l1l1lllll1l1l1_tvp_ = 7
def l11l1l1l1l1_tvp_ (keyedStringLiteral):
    global l111111l1l1l1_tvp_
    stringNr = ord (keyedStringLiteral [-1])
    rotatedStringLiteral = keyedStringLiteral [:-1]
    rotationDistance = stringNr % len (rotatedStringLiteral)
    recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
    if l1l1l11ll1l1l1_tvp_:
        stringLiteral = unicode () .join ([unichr (ord (char) - l1lllll1l1l1l1_tvp_ - (charIndex + stringNr) % l1l1lllll1l1l1_tvp_) for charIndex, char in enumerate (recodedStringLiteral)])
    else:
        stringLiteral = str () .join ([chr (ord (char) - l1lllll1l1l1l1_tvp_ - (charIndex + stringNr) % l1l1lllll1l1l1_tvp_) for charIndex, char in enumerate (recodedStringLiteral)])
    return eval (stringLiteral)
import urllib2
import urlparse
import re
l11111lll1l1l1_tvp_ = 10
l1111l1ll1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡡࡴࡶࡵࡳࡳࡧࡲࡪࡷࡰ࠲ࡵࡲࠧ৚")
def l1ll111l1l1l1_tvp_(url,proxy={},timeout=l11111lll1l1l1_tvp_):
    if proxy:
        urllib2.install_opener(
            urllib2.build_opener(
                urllib2.ProxyHandler(proxy)
            )
        )
    req = urllib2.Request(url)
    req.add_header(l11l1l1l1l1_tvp_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ৛"), l11l1l1l1l1_tvp_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠷࠰࠴࠿ࠥࡸࡶ࠻࠴࠵࠲࠵࠯ࠠࡈࡧࡦ࡯ࡴ࠵࠲࠱࠳࠳࠴࠶࠶࠱ࠡࡈ࡬ࡶࡪ࡬࡯ࡹ࠱࠵࠶࠳࠶ࠧড়"))
    try:
        response = urllib2.urlopen(req,timeout=timeout)
        l1llll11l1l1l1_tvp_ = response.read()
        response.close()
    except:
        l1llll11l1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠬࢁࡽࠨঢ়")
    return l1llll11l1l1l1_tvp_
def l1lll1l1l1_tvp_(url=l11l1l1l1l1_tvp_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡥࡸࡺࡲࡰࡰࡤࡶ࡮ࡻ࡭࠯ࡲ࡯࠳ࡴࡪࡣࡪࡰ࡮࡭࠴࠭৞")):
    content=l1ll111l1l1l1_tvp_(url)
    out=[]
    items = re.compile(l11l1l1l1l1_tvp_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠳ࡴࡪࡣࡪࡰ࡮࡭࠳࠰࠿ࠪࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡨࡲࡡࡴࡵࡀࠦࡴࡪࡣࡪࡰ࡮࡭࠲ࡲࡩࡴࡶࡤࠦࡃࡂ࠯ࡢࡀࠪয়")).findall(content)
    for item in items:
        href= l1111l1ll1l1l1_tvp_+item[0]
        l111l1l1l1_tvp_ = l1111l1ll1l1l1_tvp_+item[1]
        title = l1111l11l1l1l1_tvp_(item[2].split(l11l1l1l1l1_tvp_ (u"ࠨࠤࠪৠ"))[0])
        out.append({l11l1l1l1l1_tvp_ (u"ࠩࡷ࡭ࡹࡲࡥࠨৡ"):title,l11l1l1l1l1_tvp_ (u"ࠪࡹࡷࡲࠧৢ"):href,l11l1l1l1l1_tvp_ (u"ࠫ࡮ࡳࡧࠨৣ"):l111l1l1l1_tvp_})
    return out
def l1l111ll1l1l1_tvp_(url):
    content=l1ll111l1l1l1_tvp_(url)
    l1llll11l1l1l1_tvp_=l11l1l1l1l1_tvp_ (u"ࠬ࠭৤")
    l11111l1l1l1l1_tvp_ = re.compile(l11l1l1l1l1_tvp_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠠࠩ࠰࠭ࡃ࠮ࡂ࠯ࡪࡨࡵࡥࡲ࡫࠾ࠨ৥"),re.DOTALL).findall(content)
    for l1111ll1l1l1l1_tvp_ in l11111l1l1l1l1_tvp_:
        src=re.compile(l11l1l1l1l1_tvp_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ০")).findall(l1111ll1l1l1l1_tvp_)
        src = src[0] if src else l11l1l1l1l1_tvp_ (u"ࠨࠩ১")
        if l11l1l1l1l1_tvp_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪ২") in src:
            l1111llll1l1l1_tvp_=urlparse.urlparse(src).path.split(l11l1l1l1l1_tvp_ (u"ࠪ࠳ࠬ৩"))[-1]
            l1llll11l1l1l1_tvp_ = l11l1l1l1l1_tvp_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠵ࡰ࡭ࡣࡼ࠳ࡄࡼࡩࡥࡧࡲࡣ࡮ࡪ࠽ࠨ৪") + l1111llll1l1l1_tvp_
    return l1llll11l1l1l1_tvp_
def l1111l11l1l1l1_tvp_(l111111ll1l1l1_tvp_):
    l111111ll1l1l1_tvp_ = l111111ll1l1l1_tvp_.replace(l11l1l1l1l1_tvp_ (u"ࠬࠬ࡮ࡣࡵࡳ࠿ࠬ৫"),l11l1l1l1l1_tvp_ (u"࠭ࠧ৬"))
    l111111ll1l1l1_tvp_ = l111111ll1l1l1_tvp_.replace(l11l1l1l1l1_tvp_ (u"ࠧࠧ࡮ࡷ࠿ࡧࡸ࠯ࠧࡩࡷ࠿ࠬ৭"),l11l1l1l1l1_tvp_ (u"ࠨࠢࠪ৮"))
    l111111ll1l1l1_tvp_ = l111111ll1l1l1_tvp_.replace(l11l1l1l1l1_tvp_ (u"ࠩࠩࡵࡺࡵࡴ࠼ࠩ৯"),l11l1l1l1l1_tvp_ (u"ࠪࠦࠬৰ")).replace(l11l1l1l1l1_tvp_ (u"ࠫࠫࡧ࡭ࡱ࠽ࡴࡹࡴࡺ࠻ࠨৱ"),l11l1l1l1l1_tvp_ (u"ࠬࠨࠧ৲"))
    l111111ll1l1l1_tvp_ = l111111ll1l1l1_tvp_.replace(l11l1l1l1l1_tvp_ (u"࠭ࠦࡰࡣࡦࡹࡹ࡫࠻ࠨ৳"),l11l1l1l1l1_tvp_ (u"ࠧࣴࠩ৴")).replace(l11l1l1l1l1_tvp_ (u"ࠨࠨࡒࡥࡨࡻࡴࡦ࠽ࠪ৵"),l11l1l1l1l1_tvp_ (u"ࠩࣖࠫ৶"))
    l111111ll1l1l1_tvp_ = l111111ll1l1l1_tvp_.replace(l11l1l1l1l1_tvp_ (u"ࠪࠪࡦࡳࡰ࠼ࡱࡤࡧࡺࡺࡥ࠼ࠩ৷"),l11l1l1l1l1_tvp_ (u"ࠫࣸ࠭৸")).replace(l11l1l1l1l1_tvp_ (u"ࠬࠬࡡ࡮ࡲ࠾ࡓࡦࡩࡵࡵࡧ࠾ࠫ৹"),l11l1l1l1l1_tvp_ (u"࣓࠭ࠨ৺"))
    l111111ll1l1l1_tvp_ = l111111ll1l1l1_tvp_.replace(l11l1l1l1l1_tvp_ (u"ࠧ࡝ࡷ࠳࠵࠵࠻ࠧ৻"),l11l1l1l1l1_tvp_ (u"ࠨइࠪৼ")).replace(l11l1l1l1l1_tvp_ (u"ࠩ࡟ࡹ࠵࠷࠰࠵ࠩ৽"),l11l1l1l1l1_tvp_ (u"ࠪईࠬ৾"))
    l111111ll1l1l1_tvp_ = l111111ll1l1l1_tvp_.replace(l11l1l1l1l1_tvp_ (u"ࠫࡡࡻ࠰࠲࠲࠺ࠫ৿"),l11l1l1l1l1_tvp_ (u"ࠬऍࠧ਀")).replace(l11l1l1l1l1_tvp_ (u"࠭࡜ࡶ࠲࠴࠴࠻࠭ਁ"),l11l1l1l1l1_tvp_ (u"ࠧइࠩਂ"))
    l111111ll1l1l1_tvp_ = l111111ll1l1l1_tvp_.replace(l11l1l1l1l1_tvp_ (u"ࠨ࡞ࡸ࠴࠶࠷࠹ࠨਃ"),l11l1l1l1l1_tvp_ (u"ࠩजࠫ਄")).replace(l11l1l1l1l1_tvp_ (u"ࠪࡠࡺ࠶࠱࠲࠺ࠪਅ"),l11l1l1l1l1_tvp_ (u"ࠫझ࠭ਆ"))
    l111111ll1l1l1_tvp_ = l111111ll1l1l1_tvp_.replace(l11l1l1l1l1_tvp_ (u"ࠬࡢࡵ࠱࠳࠷࠶ࠬਇ"),l11l1l1l1l1_tvp_ (u"࠭ूࠨਈ")).replace(l11l1l1l1l1_tvp_ (u"ࠧ࡝ࡷ࠳࠵࠹࠷ࠧਉ"),l11l1l1l1l1_tvp_ (u"ࠨृࠪਊ"))
    l111111ll1l1l1_tvp_ = l111111ll1l1l1_tvp_.replace(l11l1l1l1l1_tvp_ (u"ࠩ࡟ࡹ࠵࠷࠴࠵ࠩ਋"),l11l1l1l1l1_tvp_ (u"ࠪैࠬ਌")).replace(l11l1l1l1l1_tvp_ (u"ࠫࡡࡻ࠰࠲࠶࠷ࠫ਍"),l11l1l1l1l1_tvp_ (u"ࠬॉࠧ਎"))
    l111111ll1l1l1_tvp_ = l111111ll1l1l1_tvp_.replace(l11l1l1l1l1_tvp_ (u"࠭࡜ࡶ࠲࠳ࡪ࠸࠭ਏ"),l11l1l1l1l1_tvp_ (u"ࠧࣴࠩਐ")).replace(l11l1l1l1l1_tvp_ (u"ࠨ࡞ࡸ࠴࠵ࡪ࠳ࠨ਑"),l11l1l1l1l1_tvp_ (u"ࠩࣖࠫ਒"))
    l111111ll1l1l1_tvp_ = l111111ll1l1l1_tvp_.replace(l11l1l1l1l1_tvp_ (u"ࠪࡠࡺ࠶࠱࠶ࡤࠪਓ"),l11l1l1l1l1_tvp_ (u"ࠫॠ࠭ਔ")).replace(l11l1l1l1l1_tvp_ (u"ࠬࡢࡵ࠱࠳࠸ࡥࠬਕ"),l11l1l1l1l1_tvp_ (u"࠭ग़ࠨਖ"))
    l111111ll1l1l1_tvp_ = l111111ll1l1l1_tvp_.replace(l11l1l1l1l1_tvp_ (u"ࠧ࡝ࡷ࠳࠵࠼ࡧࠧਗ"),l11l1l1l1l1_tvp_ (u"ࠨॼࠪਘ")).replace(l11l1l1l1l1_tvp_ (u"ࠩ࡟ࡹ࠵࠷࠷࠺ࠩਙ"),l11l1l1l1l1_tvp_ (u"ࠪॽࠬਚ"))
    l111111ll1l1l1_tvp_ = l111111ll1l1l1_tvp_.replace(l11l1l1l1l1_tvp_ (u"ࠫࡡࡻ࠰࠲࠹ࡦࠫਛ"),l11l1l1l1l1_tvp_ (u"ࠬংࠧਜ")).replace(l11l1l1l1l1_tvp_ (u"࠭࡜ࡶ࠲࠴࠻ࡧ࠭ਝ"),l11l1l1l1l1_tvp_ (u"ࠧॼࠩਞ"))
    return l111111ll1l1l1_tvp_
