# coding: UTF-8
import sys
l1l1l11ll1l1l1_tvp_ = sys.version_info [0] == 2
l1lllll1l1l1l1_tvp_ = 2048
l1l1lllll1l1l1_tvp_ = 7
def l11l1l1l1l1_tvp_ (keyedStringLiteral):
    global l111111l1l1l1_tvp_
    stringNr = ord (keyedStringLiteral [-1])
    rotatedStringLiteral = keyedStringLiteral [:-1]
    rotationDistance = stringNr % len (rotatedStringLiteral)
    recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
    if l1l1l11ll1l1l1_tvp_:
        stringLiteral = unicode () .join ([unichr (ord (char) - l1lllll1l1l1l1_tvp_ - (charIndex + stringNr) % l1l1lllll1l1l1_tvp_) for charIndex, char in enumerate (recodedStringLiteral)])
    else:
        stringLiteral = str () .join ([chr (ord (char) - l1lllll1l1l1l1_tvp_ - (charIndex + stringNr) % l1l1lllll1l1l1_tvp_) for charIndex, char in enumerate (recodedStringLiteral)])
    return eval (stringLiteral)