# -*- coding: utf-8 -*-
import sys
l111l1l1_ek_ = sys.version_info [0] == 2
l111ll1l1_ek_ = 2048
l1l1ll1l1_ek_ = 7
def l1l11l1l1_ek_ (keyedStringLiteral):
	global l1llll1l1_ek_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l1l1_ek_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll1l1_ek_ - (charIndex + stringNr) % l1l1ll1l1_ek_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll1l1_ek_ - (charIndex + stringNr) % l1l1ll1l1_ek_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urlparse,sys,urllib
params = dict(urlparse.parse_qsl(sys.argv[2].replace(l1l11l1l1_ek_ (u"࠭࠿ࠨࠬ"),l1l11l1l1_ek_ (u"ࠧࠨ࠭"))))
mode = params.get(l1l11l1l1_ek_ (u"ࠨ࡯ࡲࡨࡪ࠭࠮"))
fname = params.get(l1l11l1l1_ek_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭࠯"))
ex_link = params.get(l1l11l1l1_ek_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫ࠰"))
l1ll1lll1l1_ek_ = params.get(l1l11l1l1_ek_ (u"ࠫࡵࡧࡧࡦࠩ࠱"))
import xbmcgui,xbmc
import time,os
l1l1lll1l1_ek_ = xbmcgui.Dialog()
import time,threading
try: from shutil import rmtree
except: rmtree = False
def l1ll1l1_ek_(l1111l1l1_ek_,l1lllll1l1_ek_=[l1l11l1l1_ek_ (u"ࠬ࠭࠲")]):
    debug=1
def l1l1l1_ek_(name=l1l11l1l1_ek_ (u"࠭ࠧ࠳")):
    debug=1
def l1lll1l1_ek_(top):
    debug=1
def l111lll1l1_ek_():
    l1111l1l1_ek_ = os.path.join(xbmc.translatePath(l1l11l1l1_ek_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨ࠻")),l1l11l1l1_ek_ (u"ࠨࡣࡧࡨࡴࡴࡳࠨ࠼"))
    xbmc.log(l1111l1l1_ek_)
    if l1ll1l1_ek_(l1111l1l1_ek_,[l1l11l1l1_ek_ (u"ࠩࡤࡰ࡮࡫࡮ࡸ࡫ࡽࡥࡷࡪࠧ࠽"),l1l11l1l1_ek_ (u"ࠪࡩࡽࡺࡥ࡯ࡦࡨࡶ࠳ࡧ࡬ࡪࡧࡱࠫ࠾")])>0:
        l1l1l1_ek_(l1l11l1l1_ek_ (u"ࠫࡼ࡯ࡺࡢࡴࡧࠫ࠿"))
        return
    l1l1l1l1_ek_ = os.path.join(xbmc.translatePath(l1l11l1l1_ek_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡷࡶࡩࡷࡪࡡࡵࡣࠪࡀ")),l1l11l1l1_ek_ (u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪࡁ"),l1l11l1l1_ek_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡧࡥࡰࡰ࠱ࡲࡴࡾ࠮࠶ࠩࡂ"),l1l11l1l1_ek_ (u"ࠨࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱ࡼࡲࡲࠧࡃ"))
    if os.path.exists(l1l1l1l1_ek_):
        data = open(l1l1l1l1_ek_,l1l11l1l1_ek_ (u"ࠩࡵࠫࡄ")).read()
        data= re.sub(l1l11l1l1_ek_ (u"ࠪࡠࡠ࠴ࠪ࡝࡟ࠪࡅ"),l1l11l1l1_ek_ (u"ࠫࠬࡆ"),data)
        if len(re.compile(l1l11l1l1_ek_ (u"ࠬࡄ࠮ࠫࠪࡳࡳࡱࡹ࡫ࡢ࡞ࡶ࠮ࡹࡢࡳࠫࡸࠬࠫࡇ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1l1l1_ek_(l1l11l1l1_ek_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡦ࡫࡯࡯࠰ࡱࡳࡽ࠴࠵ࠨࡈ"))
            return
        if len(re.compile(l1l11l1l1_ek_ (u"ࠧ࠿࠰࠭ࠬࡩࡧࡲ࡮ࡱࡺࡥࡡࡹࠪࡵ࡞ࡶ࠮ࡻ࠯ࠧࡉ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1l1l1_ek_(l1l11l1l1_ek_ (u"ࠨࡵ࡮࡭ࡳ࠴ࡡࡦࡱࡱ࠲ࡳࡵࡸ࠯࠷ࠪࡊ"))
            return
    l1l1l1l1_ek_ = os.path.join(xbmc.translatePath(l1l11l1l1_ek_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡻࡳࡦࡴࡧࡥࡹࡧࠧࡋ")),l1l11l1l1_ek_ (u"ࠪࡥࡩࡪ࡯࡯ࡡࡧࡥࡹࡧࠧࡌ"),l1l11l1l1_ek_ (u"ࠫࡸࡱࡩ࡯࠰ࡻࡳࡳ࡬࡬ࡶࡧࡱࡧࡪ࠭ࡍ"),l1l11l1l1_ek_ (u"ࠬࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡹ࡯࡯ࠫࡎ"))
    if os.path.exists(l1l1l1l1_ek_):
        data = open(l1l1l1l1_ek_,l1l11l1l1_ek_ (u"࠭ࡲࠨࡏ")).read()
        data= re.sub(l1l11l1l1_ek_ (u"ࠧ࡝࡝࠱࠮ࡡࡣࠧࡐ"),l1l11l1l1_ek_ (u"ࠨࠩࡑ"),data)
        if len(re.compile(l1l11l1l1_ek_ (u"ࠩࡁ࠲࠯࠮ࡰࡰ࡮ࡶ࡯ࡦࡢࡳࠫࡶ࡟ࡷ࠯ࡼࠩࠨࡒ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1l1l1_ek_(l1l11l1l1_ek_ (u"ࠪࡷࡰ࡯࡮࠯ࡺࡲࡲ࡫ࡲࡵࡦࡰࡦࡩࠬࡓ"))
            return
    l1111l1l1_ek_ = os.path.join(xbmc.translatePath(l1l11l1l1_ek_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡶࡵࡨࡶࡩࡧࡴࡢࠩࡔ")),l1l11l1l1_ek_ (u"ࠬࡶࡲࡰࡨ࡬ࡰࡪࡹࠧࡕ"))
    if os.path.exists(l1111l1l1_ek_):
        if l1ll1l1_ek_(l1111l1l1_ek_,[l1l11l1l1_ek_ (u"࠭࡫ࡪࡦࡶࠫࡖ")])>0:
            l1l1l1_ek_(l1l11l1l1_ek_ (u"ࠧࡸ࡫ࡽࡥࡷࡪࠧࡗ"))
            return
    l11lll1l1_ek_ = xbmc.translatePath(l1l11l1l1_ek_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩࡘ"))
    for f in os.listdir(l11lll1l1_ek_):
        if f.startswith(l1l11l1l1_ek_ (u"ࠩࡐࡑࡊ࡙࡙ࠧ")):
            l1l1l1_ek_()
            return
def l1ll1ll1l1_ek_():
    try:
        debug=1
    except: pass
if mode is None:
    from resources.lib import l1llll1l1l1_ek_
    l1llll1l1l1_ek_.l1llll1l1l1_ek_().root()
elif mode.startswith(l1l11l1l1_ek_ (u"ࠫࡤ࡯࡮ࡧࡱࡢ࡛ࠫ"))  :
    from resources.lib import l1llll1l1l1_ek_
    l1llll1l1l1_ek_.l1llll1l1l1_ek_().info()
elif mode.startswith(l1l11l1l1_ek_ (u"ࠬࡥ࡟ࡱࡣࡪࡩࡤࡥ࠺ࠨ࡜")):
    from resources.lib import l1llll1l1l1_ek_
    l1llll1l1l1_ek_.l1llll1l1l1_ek_().l1lll1l1l1_ek_(mode,ex_link)
elif mode == l1l11l1l1_ek_ (u"࠭࡭ࡢ࡫ࡱࡔࠬ࡝"):
    from resources.lib import l1llll1l1l1_ek_
    l1llll1l1l1_ek_.l1llll1l1l1_ek_().l11llll1l1_ek_(ex_link)
elif mode == l1l11l1l1_ek_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ࡞"):
    from resources.lib import l1llll1l1l1_ek_
    l1llll1l1l1_ek_.l1llll1l1l1_ek_().content(ex_link)
elif mode == l1l11l1l1_ek_ (u"ࠨࡩࡨࡸࡘ࡫ࡡࡴࡱࡱࡷࠬ࡟"):
    from resources.lib import l1llll1l1l1_ek_
    l1llll1l1l1_ek_.l1llll1l1l1_ek_().l11l1ll1l1_ek_(ex_link)
elif mode == l1l11l1l1_ek_ (u"ࠩࡪࡩࡹࡋࡰࡪࡵࡲࡨࡪࡹࠧࡠ"):
    from resources.lib import l1llll1l1l1_ek_
    l1llll1l1l1_ek_.l1llll1l1l1_ek_().l1111ll1l1_ek_(ex_link)
elif mode == l1l11l1l1_ek_ (u"ࠪ࡫ࡪࡺࡌࡪࡰ࡮ࠫࡡ"):
    from resources.lib import l1llll1l1l1_ek_
    import resources.lib.l1l11ll1l1_ek_
    l1llll1l1l1_ek_.l1llll1l1l1_ek_().l111l1l1l1_ek_(ex_link)
elif mode.startswith(l1l11l1l1_ek_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫࡢ")):
    from resources.lib import l1llll1l1l1_ek_
    l1llll1l1l1_ek_.l1llll1l1l1_ek_().l1ll11l1l1_ek_(mode,ex_link)
elif mode == l1l11l1l1_ek_ (u"ࠬࡶ࡯ࡱࡷ࡯ࡥࡷࡥࡧࡦࡰࡵࡩࡸ࠭ࡣ"):
    from resources.lib import l1llll1l1l1_ek_
    l1llll1l1l1_ek_.l1llll1l1l1_ek_().l1llllll1l1_ek_()
elif mode == l1l11l1l1_ek_ (u"࠭ࡧࡦࡰࡵࡩࡸࡥࡡࡳࡶ࡬ࡷࡹࡹࠧࡤ"):
    from resources.lib import l1llll1l1l1_ek_
    l1llll1l1l1_ek_.l1llll1l1l1_ek_().l1lll1ll1l1_ek_(ex_link)
elif mode == l1l11l1l1_ek_ (u"ࠧࡢࡴࡷ࡭ࡸࡺ࡟ࡤࡱࡱࡸࡪࡴࡴࠨࡥ"):
    from resources.lib import l1llll1l1l1_ek_
    l1llll1l1l1_ek_.l1llll1l1l1_ek_().l1l1l1l1l1_ek_(ex_link)
elif mode == l1l11l1l1_ek_ (u"ࠨࡲࡲࡴࡺࡲࡡࡳࡡࡤࡰࡧࡻ࡭ࡴࠩࡦ"):
    from resources.lib import l1llll1l1l1_ek_
    l1llll1l1l1_ek_.l1llll1l1l1_ek_().l11ll1l1l1_ek_()
elif mode == l1l11l1l1_ek_ (u"ࠩࡷࡳࡵࡥ࠵࠱ࠩࡧ"):
    from resources.lib import l1llll1l1l1_ek_
    l1llll1l1l1_ek_.l1llll1l1l1_ek_().l1lll11l1l1_ek_()
elif mode == l1l11l1l1_ek_ (u"ࠪࡲࡪࡽ࡟ࡳࡧ࡯ࡩࡦࡹࡥࡴࠩࡨ"):
    from resources.lib import l1llll1l1l1_ek_
    l1llll1l1l1_ek_.l1llll1l1l1_ek_().l11l11l1l1_ek_()
elif mode == l1l11l1l1_ek_ (u"ࠫࡺࡹࡥࡳࡡࡦࡳࡳࡺࡥ࡯ࡶࠪࡩ"):
    from resources.lib import l1llll1l1l1_ek_
    l1llll1l1l1_ek_.l1llll1l1l1_ek_().l11111l1l1_ek_(ex_link)
elif mode == l1l11l1l1_ek_ (u"ࠬࡇࡤࡥࡖࡲࡐ࡮ࡨࡲࡢࡴࡼࠫࡪ"):
    from resources.lib import l1llll1l1l1_ek_
    l1llll1l1l1_ek_.l1llll1l1l1_ek_().l1l111l1l1_ek_(ex_link)
