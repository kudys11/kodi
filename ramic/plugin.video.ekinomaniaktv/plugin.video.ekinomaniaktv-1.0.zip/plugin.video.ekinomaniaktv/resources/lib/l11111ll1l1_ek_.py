# -*- coding: utf-8 -*-
import sys
l111l1l1_ek_ = sys.version_info [0] == 2
l111ll1l1_ek_ = 2048
l1l1ll1l1_ek_ = 7
def l1l11l1l1_ek_ (keyedStringLiteral):
	global l1llll1l1_ek_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l1l1_ek_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll1l1_ek_ - (charIndex + stringNr) % l1l1ll1l1_ek_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll1l1_ek_ - (charIndex + stringNr) % l1l1ll1l1_ek_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os,json,base64
import cookielib
from urlparse import urlparse,urljoin
l1l1l11l1l1_ek_ = 15
l1l1ll1ll1l1_ek_=l1l11l1l1_ek_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠼࠮࠲࠽࡛ࠣ࡮ࡴ࠶࠵࠽ࠣࡼ࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠼࠱࠯࠲࠱࠷࠶࠼࠳࠯࠳࠳࠴࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬ࢑")
try:
    from xbmc import translatePath
    from xbmcaddon import Addon
    l1l1ll1l1l1_ek_    = translatePath(Addon().getAddonInfo(l1l11l1l1_ek_ (u"ࠪࡴࡷࡵࡦࡪ࡮ࡨࠫ࢒"))).decode(l1l11l1l1_ek_ (u"ࠫࡺࡺࡦ࠮࠺ࠪ࢓"))
    l1llll1ll1l1_ek_=os.path.join(l1l1ll1l1l1_ek_,l1l11l1l1_ek_ (u"ࠬࡩ࡯ࡰ࡭࡬ࡩࠬ࢔"))
except:
    l1llll1ll1l1_ek_=l1l11l1l1_ek_ (u"ࡸࠧࡣࡱࡻࡪ࡮ࡲ࡭࠯ࡥࡲࡳࡰ࡯ࡥࠨ࢕")
l1lll111l1l1_ek_ = l1l11l1l1_ek_ (u"ࠧࠨ࢖")
class l1ll11l1l1l1_ek_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
def l1111lll1l1_ek_(url,data=None):
    l1ll111l1l1_ek_ = cookielib.LWPCookieJar()
    if data:
        opener = urllib2.build_opener(l1ll11l1l1l1_ek_, urllib2.HTTPCookieProcessor(l1ll111l1l1_ek_))
    else:
        opener = urllib2.build_opener( urllib2.HTTPCookieProcessor(l1ll111l1l1_ek_))
    opener.addheaders = [(l1l11l1l1_ek_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬࢗ"), l1l1ll1ll1l1_ek_)]
    try:
        response = opener.open(url,data,l1l1l11l1l1_ek_)
        result= response.read()
        response.close()
    except:
        result=l1llll11l1l1_ek_ = e.read()
    return result
def l111llll1l1_ek_(l1l111ll1l1_ek_):
    if isinstance(l1l111ll1l1_ek_, unicode):
        l1l111ll1l1_ek_ = l1l111ll1l1_ek_.encode(l1l11l1l1_ek_ (u"ࠩࡸࡸ࡫࠳࠸ࠨ࢘"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠪࠪࡱࡺ࠻ࡣࡴ࠲ࠪ࡬ࡺ࠻ࠨ࢙"),l1l11l1l1_ek_ (u"࢚ࠫࠥ࠭"))
    s=l1l11l1l1_ek_ (u"ࠬࡐࡩࡏࡥ࡝ࡇࡸ࠽࢛ࠧ")
    l1l111ll1l1_ek_ = re.sub(s.decode(l1l11l1l1_ek_ (u"࠭ࡢࡢࡵࡨ࠺࠹࠭࢜")),l1l11l1l1_ek_ (u"ࠧࠨ࢝"),l1l111ll1l1_ek_)
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠨ࡞ࡱࠫ࢞"),l1l11l1l1_ek_ (u"ࠩࠪ࢟")).replace(l1l11l1l1_ek_ (u"ࠪࡠࡷ࠭ࢠ"),l1l11l1l1_ek_ (u"ࠫࠬࢡ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠬࠬ࡮ࡣࡵࡳ࠿ࠬࢢ"),l1l11l1l1_ek_ (u"࠭ࠧࢣ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠧࠧࡳࡸࡳࡹࡁࠧࢤ"),l1l11l1l1_ek_ (u"ࠨࠤࠪࢥ")).replace(l1l11l1l1_ek_ (u"ࠩࠩࡥࡲࡶ࠻ࡲࡷࡲࡸࡀ࠭ࢦ"),l1l11l1l1_ek_ (u"ࠪࠦࠬࢧ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠫࠫࡵࡡࡤࡷࡷࡩࡀ࠭ࢨ"),l1l11l1l1_ek_ (u"ࣹࠬࠧࢩ")).replace(l1l11l1l1_ek_ (u"࠭ࠦࡐࡣࡦࡹࡹ࡫࠻ࠨࢪ"),l1l11l1l1_ek_ (u"ࠧࣔࠩࢫ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠨࠨࡤࡱࡵࡁ࡯ࡢࡥࡸࡸࡪࡁࠧࢬ"),l1l11l1l1_ek_ (u"ࣶࠩࠫࢭ")).replace(l1l11l1l1_ek_ (u"ࠪࠪࡦࡳࡰ࠼ࡑࡤࡧࡺࡺࡥ࠼ࠩࢮ"),l1l11l1l1_ek_ (u"ࠫࣘ࠭ࢯ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠬࠬࡡ࡮ࡲ࠾ࠫࢰ"),l1l11l1l1_ek_ (u"࠭ࠦࠨࢱ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠧ࡝ࡷ࠳࠵࠵࠻ࠧࢲ"),l1l11l1l1_ek_ (u"ࠨइࠪࢳ")).replace(l1l11l1l1_ek_ (u"ࠩ࡟ࡹ࠵࠷࠰࠵ࠩࢴ"),l1l11l1l1_ek_ (u"ࠪईࠬࢵ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠫࡡࡻ࠰࠲࠲࠺ࠫࢶ"),l1l11l1l1_ek_ (u"ࠬऍࠧࢷ")).replace(l1l11l1l1_ek_ (u"࠭࡜ࡶ࠲࠴࠴࠻࠭ࢸ"),l1l11l1l1_ek_ (u"ࠧइࠩࢹ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠨ࡞ࡸ࠴࠶࠷࠹ࠨࢺ"),l1l11l1l1_ek_ (u"ࠩजࠫࢻ")).replace(l1l11l1l1_ek_ (u"ࠪࡠࡺ࠶࠱࠲࠺ࠪࢼ"),l1l11l1l1_ek_ (u"ࠫझ࠭ࢽ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠬࡢࡵ࠱࠳࠷࠶ࠬࢾ"),l1l11l1l1_ek_ (u"࠭ूࠨࢿ")).replace(l1l11l1l1_ek_ (u"ࠧ࡝ࡷ࠳࠵࠹࠷ࠧࣀ"),l1l11l1l1_ek_ (u"ࠨृࠪࣁ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠩ࡟ࡹ࠵࠷࠴࠵ࠩࣂ"),l1l11l1l1_ek_ (u"ࠪैࠬࣃ")).replace(l1l11l1l1_ek_ (u"ࠫࡡࡻ࠰࠲࠶࠷ࠫࣄ"),l1l11l1l1_ek_ (u"ࠬॉࠧࣅ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"࠭࡜ࡶ࠲࠳ࡪ࠸࠭ࣆ"),l1l11l1l1_ek_ (u"ࠧࣴࠩࣇ")).replace(l1l11l1l1_ek_ (u"ࠨ࡞ࡸ࠴࠵ࡪ࠳ࠨࣈ"),l1l11l1l1_ek_ (u"ࠩࣖࠫࣉ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠪࡠࡺ࠶࠱࠶ࡤࠪ࣊"),l1l11l1l1_ek_ (u"ࠫॠ࠭࣋")).replace(l1l11l1l1_ek_ (u"ࠬࡢࡵ࠱࠳࠸ࡥࠬ࣌"),l1l11l1l1_ek_ (u"࠭ग़ࠨ࣍"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠧ࡝ࡷ࠳࠵࠼ࡧࠧ࣎"),l1l11l1l1_ek_ (u"ࠨॼ࣏ࠪ")).replace(l1l11l1l1_ek_ (u"ࠩ࡟ࡹ࠵࠷࠷࠺࣐ࠩ"),l1l11l1l1_ek_ (u"ࠪॽ࣑ࠬ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠫࡡࡻ࠰࠲࠹ࡦ࣒ࠫ"),l1l11l1l1_ek_ (u"ࠬং࣓ࠧ")).replace(l1l11l1l1_ek_ (u"࠭࡜ࡶ࠲࠴࠻ࡧ࠭ࣔ"),l1l11l1l1_ek_ (u"ࠧॼࠩࣕ"))
    return l1l111ll1l1_ek_
class l111111l1l1_ek_:
    def l11lll1l1l1_ek_(self,url):
        if not url:
            url = l1l11l1l1_ek_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡬ࡥࡳ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭ࣖ")
        elif url.startswith(l1l11l1l1_ek_ (u"ࠩ࠲࠳ࠬࣗ")):
            url = l1l11l1l1_ek_ (u"ࠪ࡬ࡹࡺࡰࠨࣘ")+url
        elif url.startswith(l1l11l1l1_ek_ (u"ࠫ࠴࠭ࣙ")):
            url = urljoin(l1l11l1l1_ek_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡰࡢࡰࡨ࡬ࡰࡲ࠴ࡰ࡭࠱ࠪࣚ"),url)
        return url
    @staticmethod
    def l1lllll1l1l1_ek_(url=l1l11l1l1_ek_ (u"࠭ࠧࣛ")):
        if not url:
            url = l1l11l1l1_ek_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡫ࡤࡲࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࠬࣜ")
        elif url.startswith(l1l11l1l1_ek_ (u"ࠨ࠱ࠪࣝ")):
            url = urljoin(l1l11l1l1_ek_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡭ࡦࡴ࡬ࡩ࡭࡯࠱ࡴࡱ࠵ࠧࣞ"),url)
        content = l1111lll1l1_ek_(url)
        out=[]
        l111l11l1l1_ek_ = re.compile(l1l11l1l1_ek_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡵ࠯ࡪࡶ࡮ࡪࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ࣟ"),re.DOTALL).findall(content)
        for show in l111l11l1l1_ek_:
            l11l1l1l1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠰ࡵࡨࡶ࡮ࡧ࡬ࡦ࠱࠱࠮࠮ࠨ࠾࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ࣠"),show)
            if l11l1l1l1l1_ek_:
                l11l1lll1l1_ek_ = l11l1l1l1l1_ek_[0][1]
                l11l1lll1l1_ek_ = urljoin(l1l11l1l1_ek_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡰࡢࡰࡨ࡬ࡰࡲ࠴ࡰ࡭࠱ࠪ࣡"),l11l1lll1l1_ek_) if not l11l1lll1l1_ek_.startswith(l1l11l1l1_ek_ (u"࠭ࡨࡵࡶࡳࠫ࣢")) else l11l1lll1l1_ek_
                title = l11l1l1l1l1_ek_[0][0].replace(l1l11l1l1_ek_ (u"ࠧ࠰ࡵࡨࡶ࡮ࡧ࡬ࡦ࠱ࣣࠪ"),l1l11l1l1_ek_ (u"ࠨࠩࣤ")).replace(l1l11l1l1_ek_ (u"ࠩ࠰ࠫࣥ"),l1l11l1l1_ek_ (u"ࠪࠤࣦࠬ")).replace(l1l11l1l1_ek_ (u"ࠫ࠴࠭ࣧ"),l1l11l1l1_ek_ (u"ࠬ࠭ࣨ")).title()
                out.append({l1l11l1l1_ek_ (u"࠭ࡨࡳࡧࡩࣩࠫ"):l11l1l1l1l1_ek_[0][0],l1l11l1l1_ek_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭࣪"):title,l1l11l1l1_ek_ (u"ࠨ࡫ࡰ࡫ࠬ࣫"):l11l1lll1l1_ek_})
        idx = content.find(l1l11l1l1_ek_ (u"ࠩ࡫࠷ࡃ࡙ࡥࡳ࡫ࡤࡰࡪࡂ࠯ࡩ࠵ࡁࠫ࣬"))
        if idx:
            l1ll1l11l1l1_ek_ = re.compile(l1l11l1l1_ek_ (u"ࠪࡀࡺࡲ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁ࣭ࠫ"),re.DOTALL).search(content[idx:-1])
            l1ll1l11l1l1_ek_ = l1ll1l11l1l1_ek_.group(1) if l1ll1l11l1l1_ek_ else l1l11l1l1_ek_ (u"࣮ࠫࠬ")
            l1ll1l11l1l1_ek_ = re.sub(l1l11l1l1_ek_ (u"ࡷࠨ࠼ࠢ࠯࠰ࠬ࠳ࢂ࡜ࡴࡾ࡟ࡲ࠮࠰࠿࠮࠯ࡁ࣯ࠦ"), l1l11l1l1_ek_ (u"ࠨࣰࠢ"), l1ll1l11l1l1_ek_)
            l1ll11lll1l1_ek_ = re.compile(l1l11l1l1_ek_ (u"ࠧ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠰ࡵࡨࡶ࡮ࡧ࡬ࡦ࠱࠱࠮ࡄ࠯ࠢ࠿ࠪ࡞ࡢࡃࡣࠪࠪ࠾࠲ࡥࡃࡂ࠯࡭࡫ࡁࣱࠫ")).findall(l1ll1l11l1l1_ek_)
            for href,title in l1ll11lll1l1_ek_:
                out.append({l1l11l1l1_ek_ (u"ࠨࡪࡵࡩ࡫ࣲ࠭"):href,l1l11l1l1_ek_ (u"ࠩࡷ࡭ࡹࡲࡥࠨࣳ"):title})
        return out
    @staticmethod
    def l1l1lllll1l1_ek_(url=l1l11l1l1_ek_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡮ࡧࡵࡦࡪ࡮ࡰ࠲ࡵࡲ࠯ࡴࡧࡵ࡭ࡦࡲࡥ࠰ࡦࡨࡸࡪࡱࡴࡺࡹ࠲ࠫࣴ")):
        if not url:
            url = l1l11l1l1_ek_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩࣵ")
        if url.startswith(l1l11l1l1_ek_ (u"ࠬ࠵࠯ࠨࣶ")):
            url = l1l11l1l1_ek_ (u"࠭ࡨࡵࡶࡳࠫࣷ")+url
        if url.startswith(l1l11l1l1_ek_ (u"ࠧ࠰ࠩࣸ")):
            url = urljoin(l1l11l1l1_ek_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡬ࡥࡳ࡫࡯࡬࡮࠰ࡳࡰ࠴ࣹ࠭"),url)
        url += l1l11l1l1_ek_ (u"ࠩ࠲ࣺࠫ") if not url.endswith(l1l11l1l1_ek_ (u"ࠪ࠳ࠬࣻ")) else l1l11l1l1_ek_ (u"ࠫࠬࣼ")
        content = l1111lll1l1_ek_(url)
        out=[]
        l1ll1ll1l1l1_ek_ = re.compile(l1l11l1l1_ek_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡦࡰࡷ࠱࡬ࡸࡩࡥࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨࣽ"),re.DOTALL).findall(content)
        for l1l1111l1l1_ek_ in l1ll1ll1l1l1_ek_:
            l1lll1l1l1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"࠭ࡳࡦࡼࡲࡲࡡࡹࠪࠩ࡞ࡧ࠯࠮࠭ࣾ"),l1l1111l1l1_ek_,re.I)
            l1lll1l1l1l1_ek_ = l1lll1l1l1l1_ek_[0] if l1lll1l1l1l1_ek_ else l1l11l1l1_ek_ (u"ࠧࠨࣿ")
            l1l1lll1l1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠨࡑࡧࡧ࡮ࡴࡥ࡬࡞ࡶ࠮࠭ࡢࡤࠬࠫࠪऀ"),l1l1111l1l1_ek_,re.I)
            l1l1lll1l1l1_ek_ = l1l1lll1l1l1_ek_[0] if l1l1lll1l1l1_ek_ else l1l11l1l1_ek_ (u"ࠩࠪँ")
            href = re.compile(l1l11l1l1_ek_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮ࡳࡪࡰࡪࡰࡪࡶࡡࡨࡧ࠱ࡴ࡭ࡶ࡜ࡀ࡫ࡧࡁࡡࡪࠫࠪࠤࠪं")).findall(l1l1111l1l1_ek_)
            l11l1lll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠫࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧः"),l1l1111l1l1_ek_)
            if href and l1lll1l1l1l1_ek_ and l1l1lll1l1l1_ek_:
                l11l1lll1l1_ek_ = urljoin(l1l11l1l1_ek_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡰࡢࡰࡨ࡬ࡰࡲ࠴ࡰ࡭࠱ࠪऄ"),l11l1lll1l1_ek_[0]) if not l11l1lll1l1_ek_[0].startswith(l1l11l1l1_ek_ (u"࠭ࡨࡵࡶࡳࠫअ")) else l1l11l1l1_ek_ (u"ࠧࠨआ")
                out.append({l1l11l1l1_ek_ (u"ࠨࡪࡵࡩ࡫࠭इ"):url+href[0],l1l11l1l1_ek_ (u"ࠩࡷ࡭ࡹࡲࡥࠨई"):l1l11l1l1_ek_ (u"ࠪࡗࡪࢀ࡯࡯ࠢࠨࡷ࠱ࠦࡅࡱ࡫ࡽࡳࡩࠦࠥࡴࠩउ")%(l1lll1l1l1l1_ek_,l1l1lll1l1l1_ek_),l1l11l1l1_ek_ (u"ࠫ࡮ࡳࡧࠨऊ"):l11l1lll1l1_ek_,
                l1l11l1l1_ek_ (u"ࠬࡹࡥࡢࡵࡲࡲࠬऋ"):int(l1lll1l1l1l1_ek_),l1l11l1l1_ek_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࠧऌ"):int(l1l1lll1l1l1_ek_)})
        return out
    @staticmethod
    def l1lll11ll1l1_ek_(out):
        l1l11lll1l1_ek_={}
        l1lllllll1l1_ek_ = [x.get(l1l11l1l1_ek_ (u"ࠧࡴࡧࡤࡷࡴࡴࠧऍ")) for x in out]
        for s in set(l1lllllll1l1_ek_):
            l1l11lll1l1_ek_[l1l11l1l1_ek_ (u"ࠨࡕࡨࡾࡴࡴࠠࠦ࠲࠵ࡨࠬऎ")%s]=[out[i] for i, j in enumerate(l1lllllll1l1_ek_) if j == s]
        return l1l11lll1l1_ek_
    @staticmethod
    def l111l1l1l1_ek_(url):
        content = l1111lll1l1_ek_(url)
        l11ll1ll1l1_ek_=l1l11l1l1_ek_ (u"ࠩࠪए")
        l11ll11l1l1_ek_ = re.compile(l1l11l1l1_ek_ (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨࠬ࠳࠰࠿ࠪ࠾࠲࡭࡫ࡸࡡ࡮ࡧࡁࠫऐ"),re.DOTALL).findall(content)
        if l11ll11l1l1_ek_:
            src = re.compile(l1l11l1l1_ek_ (u"ࠫࡸࡸࡣ࠾࡝࡟ࠫࠧࡣࠨ࠯ࠬࡂ࠭ࡠࡢࠧࠣ࡟ࠪऑ"),re.DOTALL).findall(l11ll11l1l1_ek_[0])
            l11ll1ll1l1_ek_ = src[0] if src else l1l11l1l1_ek_ (u"ࠬ࠭ऒ")
        return l11ll1ll1l1_ek_
class l1ll1l1ll1l1_ek_:
    @staticmethod
    def l1lllll1l1l1_ek_(url,l11l111l1l1_ek_=None):
        if l11l111l1l1_ek_:
            l11l111l1l1_ek_ = l1l11l1l1_ek_ (u"࠭ࡳࡻࡷ࡮ࡥ࡯ࡃࠧओ")+l11l111l1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠧࠡࠩऔ"),l1l11l1l1_ek_ (u"ࠨ࠭ࠪक"))
            url= l1l11l1l1_ek_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡰࡺࡩ࡭ࡱࡳ࠮ࡱ࡮࠲ࡷࡿࡻ࡫ࡢ࡬ࠪख")
        if not url:
            url = l1l11l1l1_ek_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡣࡱࡻࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࠬग")
        elif url.startswith(l1l11l1l1_ek_ (u"ࠫ࠴࠭घ")):
            url = urljoin(l1l11l1l1_ek_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡥࡳࡽ࡬ࡩ࡭࡯࠱ࡴࡱ࠵ࠧङ"),url)
        content = l1111lll1l1_ek_(url,l11l111l1l1_ek_)
        ids = [(a.start(), a.end()) for a in re.finditer(l1l11l1l1_ek_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡻ࡯ࡤࡦࡱࡢ࡭ࡳ࡬࡯ࠣࡀࠪच"), content,re.IGNORECASE)]
        ids.append( (-1,-1) )
        out=[]
        for i in range(len(ids[:-1])):
            l1ll11ll1l1_ek_ = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile(l1l11l1l1_ek_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩछ"),re.DOTALL).search(l1ll11ll1l1_ek_)
            title = re.compile(l1l11l1l1_ek_ (u"ࠨ࠾࡫࠵ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠱࠿ࠩज"),re.DOTALL).search(l1ll11ll1l1_ek_)
            l11l1lll1l1_ek_ = re.compile(l1l11l1l1_ek_ (u"ࠩ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬझ"),re.DOTALL).search(l1ll11ll1l1_ek_)
            l1ll111ll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠪࡐࡪࡱࡴࡰࡴ࠽ࡠࡸ࠰࠼ࡴࡲࡤࡲࠥࡹࡴࡺ࡮ࡨࡁࠧࡡ࡞࠿࡟࠭ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫञ"),l1ll11ll1l1_ek_)
            l1ll1llll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠫࡉࡵࡤࡢࡰࡼ࠾ࡡࡹࠪ࠽ࡵࡳࡥࡳࠦࡳࡵࡻ࡯ࡩࡂࠨ࡛࡟ࡀࡠ࠮ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬट"),l1ll11ll1l1_ek_)
            l1ll1111l1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠬࡍࡡࡵࡷࡱࡩࡰࡀ࡜ࡴࠬ࠿ࡷࡵࡧ࡮ࠡࡵࡷࡽࡱ࡫࠽ࠣ࡝ࡡࡂࡢ࠰ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧठ"),l1ll11ll1l1_ek_)
            l1ll111ll1l1_ek_ = l1ll111ll1l1_ek_[0] if l1ll111ll1l1_ek_ else l1l11l1l1_ek_ (u"࠭ࠧड")
            l1ll1llll1l1_ek_ = l1ll1llll1l1_ek_[0] if l1ll1llll1l1_ek_ else l1l11l1l1_ek_ (u"ࠧࠨढ")
            l1ll1111l1l1_ek_ = l1ll1111l1l1_ek_[0] if l1ll1111l1l1_ek_ else l1l11l1l1_ek_ (u"ࠨࠩण")
            code = l1ll111ll1l1_ek_
            l11lllll1l1_ek_ = l1l11l1l1_ek_ (u"ࠤࡏࡩࡰࡺ࡯ࡳ࠼ࠣࠩࡸࠦ࡜࡯ࡆࡲࡨࡦࡴࡹ࠻ࠢࠨࡷࠥࡢ࡮ࡈࡣࡷࡹࡳ࡫࡫࠻ࠢࠨࡷࠥࡢ࡮ࠣत") %(l1ll111ll1l1_ek_,l1ll1llll1l1_ek_,l1ll1111l1l1_ek_)
            if href and title:
                l11l1lll1l1_ek_ = urljoin(l1l11l1l1_ek_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡣࡱࡻࡪ࡮ࡲ࡭࠯ࡲ࡯ࠫथ"),l11l1lll1l1_ek_.group(1)) if l11l1lll1l1_ek_ else l1l11l1l1_ek_ (u"ࠫࠬद")
                title = title.group(1)
                year =  re.findall(l1l11l1l1_ek_ (u"ࠬࡢࠨࠩ࡞ࡧࡿ࠹ࢃࠩ࡝ࠫࠪध"),title)
                l1l1llll1l1_ek_ = {l1l11l1l1_ek_ (u"࠭ࡨࡳࡧࡩࠫन")   : href.group(1),
                       l1l11l1l1_ek_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ऩ")  : l111llll1l1_ek_(title),
                       l1l11l1l1_ek_ (u"ࠨ࡫ࡰ࡫ࠬप")    : l11l1lll1l1_ek_,
                       l1l11l1l1_ek_ (u"ࠩࡳࡰࡴࡺࠧफ")   : l111llll1l1_ek_(l11lllll1l1_ek_),
                       l1l11l1l1_ek_ (u"ࠪࡽࡪࡧࡲࠨब")   : year[0] if year else l1l11l1l1_ek_ (u"ࠫࠬभ"),
                       l1l11l1l1_ek_ (u"ࠬࡩ࡯ࡥࡧࠪम")   : code,
                        }
                out.append(l1l1llll1l1_ek_)
        l1lll1lll1l1_ek_=False
        l1l1l1ll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࡞ࡢࠧࡣࠪࠪࠤࡁࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡰࡨࡼࡹࡥࡳࡪࡶࡨࠦࡃࡖ࡯ࡱࡴࡽࡩࡩࡴࡩࡢ࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡤࡂࠬय"),content)
        l1l1l1ll1l1_ek_ = l1l1l1ll1l1_ek_[0] if l1l1l1ll1l1_ek_ else False
        l1lll1lll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡟ࡣࠨ࡝ࠫࠫࠥࡂࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡱࡩࡽࡺ࡟ࡴ࡫ࡷࡩࠧࡄࡎࡢࡵࡷ࠲࠰ࡶ࡮ࡢ࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡤࡂࠬर"),content)
        l1lll1lll1l1_ek_ = l1lll1lll1l1_ek_[0] if l1lll1lll1l1_ek_ else False
        return (out, (l1l1l1ll1l1_ek_,l1lll1lll1l1_ek_))
    @staticmethod
    def l1111l1l1l1_ek_():
        content = l1111lll1l1_ek_(l1l11l1l1_ek_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡨ࡯ࡹࡨ࡬ࡰࡲ࠴ࡰ࡭࠱࡮ࡳࡳࡺࡡ࡬ࡶࠪऱ"))
        l111ll1l1l1_ek_=re.findall(l1l11l1l1_ek_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠵࡫ࡢࡶࡤࡰࡴ࡭࠯࠯ࠬࠬࠦࠥࡩ࡬ࡢࡵࡶࡁࠧࡴࡡࡷࡡ࡯࡭ࡳࡱࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫल"),content)
        out=[]
        for href,name in l111ll1l1l1_ek_:
            out.append({l1l11l1l1_ek_ (u"ࠪ࡬ࡷ࡫ࡦࠨळ"):href,l1l11l1l1_ek_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪऴ"):name})
        return out
    @staticmethod
    def l11l11ll1l1_ek_(url):
        url = urljoin(l1l11l1l1_ek_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡥࡳࡽ࡬ࡩ࡭࡯࠱ࡴࡱ࠵ࠧव"),url)
        content = l1111lll1l1_ek_(url)
        l111l1ll1l1_ek_=l1l11l1l1_ek_ (u"࠭ࠧश")
        l1l11l1l1l1_ek_=re.findall(l1l11l1l1_ek_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠩ࠰࠭ࡃ࠮ࡂ࠯ࡪࡨࡵࡥࡲ࡫࠾ࠨष"),content,re.DOTALL|re.IGNORECASE)
        if l1l11l1l1l1_ek_:
            l111l1ll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭स"),l1l11l1l1l1_ek_[0],re.DOTALL|re.IGNORECASE)
            l111l1ll1l1_ek_ = l111l1ll1l1_ek_[0] if l111l1ll1l1_ek_ else l1l11l1l1_ek_ (u"ࠩࠪह")
        return l111l1ll1l1_ek_
