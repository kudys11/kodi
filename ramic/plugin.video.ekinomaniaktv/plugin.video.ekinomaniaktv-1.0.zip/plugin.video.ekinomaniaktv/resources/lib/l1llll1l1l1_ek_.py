# -*- coding: utf-8 -*-
import sys
l111l1l1_ek_ = sys.version_info [0] == 2
l111ll1l1_ek_ = 2048
l1l1ll1l1_ek_ = 7
def l1l11l1l1_ek_ (keyedStringLiteral):
	global l1llll1l1_ek_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l1l1_ek_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll1l1_ek_ - (charIndex + stringNr) % l1l1ll1l1_ek_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll1l1_ek_ - (charIndex + stringNr) % l1l1ll1l1_ek_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import ramic as l1l1llllll1l1_ek_
l1l1l1llll1l1_ek_        = sys.argv[0]
l1l11l1lll1l1_ek_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l1l1ll1l1l1l1_ek_        = xbmcaddon.Addon()
l11ll1l11l1l1_ek_     = l1l1ll1l1l1l1_ek_.getAddonInfo(l1l11l1l1_ek_ (u"ࠩ࡬ࡨࠬச"))
l1ll111l1l1l1_ek_       = l1l1ll1l1l1l1_ek_.getAddonInfo(l1l11l1l1_ek_ (u"ࠪࡲࡦࡳࡥࠨ஛"))
PATH        = l1l1ll1l1l1l1_ek_.getAddonInfo(l1l11l1l1_ek_ (u"ࠫࡵࡧࡴࡩࠩஜ")).decode(l1l11l1l1_ek_ (u"ࠬࡻࡴࡧ࠯࠻ࠫ஝"))
l1l1ll1l1l1_ek_    = xbmc.translatePath(l1l1ll1l1l1l1_ek_.getAddonInfo(l1l11l1l1_ek_ (u"࠭ࡰࡳࡱࡩ࡭ࡱ࡫ࠧஞ"))).decode(l1l11l1l1_ek_ (u"ࠧࡶࡶࡩ࠱࠽࠭ட"))
l11lllll1l1l1_ek_   = PATH+l1l11l1l1_ek_ (u"ࠨ࠱ࡵࡩࡸࡵࡵࡳࡥࡨࡷ࠴࠭஠")
l11llll1ll1l1_ek_       = PATH+l1l11l1l1_ek_ (u"ࠩ࠲࡭ࡨࡵ࡮࠯ࡲࡱ࡫ࠬ஡")
l1l11lllll1l1_ek_        = l11lllll1l1l1_ek_+l1l11l1l1_ek_ (u"ࠪࡱ࡭࠴ࡰ࡯ࡩࠪ஢")
l11lll1lll1l1_ek_=l11lllll1l1l1_ek_+l1l11l1l1_ek_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷ࠲ࡵࡴࡧࠨண")
sys.path.append(l11lllll1l1l1_ek_+l1l11l1l1_ek_ (u"ࠬࡲࡩࡣ࠱ࠪத"))
l1ll1ll1ll1l1_ek_ = urllib2.urlopen
l1l1l11lll1l1_ek_ = urllib2.Request
l1l1lll1l1_ek_ = xbmcgui.Dialog()
import time
l1ll1111ll1l1_ek_ = lambda x,y: ord(x)+22*y if ord(x)%2 else ord(x)
l11ll111ll1l1_ek_ = lambda l1l1lll1ll1l1_ek_: l1l11l1l1_ek_ (u"࠭ࠧ஥").join([chr(l1ll1111ll1l1_ek_(x,1) ) for x in l1l1lll1ll1l1_ek_.encode(l1l11l1l1_ek_ (u"ࠧࡣࡣࡶࡩ࠻࠺ࠧ஦")).strip()])
l1ll1l11ll1l1_ek_ = lambda l1l1lll1ll1l1_ek_: l11ll111ll1l1_ek_(l1l1lll1ll1l1_ek_).encode(l1l11l1l1_ek_ (u"ࠨࡪࡨࡼࠬ஧"))
l1l1l111ll1l1_ek_ = lambda l1l1lll1ll1l1_ek_: l1l11l1l1_ek_ (u"ࠩࠪந").join([chr(l1ll1111ll1l1_ek_(x,-1) ) for x in l1l1lll1ll1l1_ek_]).decode(l1l11l1l1_ek_ (u"ࠪࡦࡦࡹࡥ࠷࠶ࠪன"))
l11ll11l1l1l1_ek_ = lambda l1l1lll1ll1l1_ek_: l1l1l111ll1l1_ek_(l1l1lll1ll1l1_ek_.decode(l1l11l1l1_ek_ (u"ࠫ࡭࡫ࡸࠨப")))
if not os.path.exists(l1l11l1l1_ek_ (u"ࠬ࠵ࡨࡰ࡯ࡨ࠳ࡴࡹ࡭ࡤࠩ஫")):
    tm=time.gmtime()
    try:    l1l1l1ll1l1l1_ek_,l1l111llll1l1_ek_,l1l1ll111l1l1_ek_ = l11ll11l1l1l1_ek_(l1l1ll1l1l1l1_ek_.getSetting(l1l11l1l1_ek_ (u"࠭࡫ࡰࡦࠪ஬"))).split(l1l11l1l1_ek_ (u"ࠧ࠻ࠩ஭"))
    except: l1l1l1ll1l1l1_ek_,l1l111llll1l1_ek_,l1l1ll111l1l1_ek_ =  [l1l11l1l1_ek_ (u"ࠨ࠯࠴ࠫம"),l1l11l1l1_ek_ (u"ࠩࠪய"),l1l11l1l1_ek_ (u"ࠪ࠱࠶࠭ர")]
    if int(l1l1l1ll1l1l1_ek_) != tm.tm_hour:
        try:    l1l11l1l1l1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠫࡐࡕࡄ࠻ࠢࠫ࠲࠯ࡅࠩ࡝ࡰࠪற"),l1ll1ll1ll1l1_ek_(l1l11l1l1_ek_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡲࡢࡹ࠱࡫࡮ࡺࡨࡶࡤࡸࡷࡪࡸࡣࡰࡰࡷࡩࡳࡺ࠮ࡤࡱࡰ࠳ࡷࡧ࡭ࡪࡥࡶࡴࡦ࠵࡫ࡰࡦ࡬࠳ࡲࡧࡳࡵࡧࡵ࠳ࡗࡋࡁࡅࡏࡈ࠲ࡲࡪࠧல")).read())[0].strip(l1l11l1l1_ek_ (u"࠭ࠪࠨள"))
        except: l1l11l1l1l1l1_ek_ = l1l11l1l1_ek_ (u"ࠧࠨழ")
def l1l11l111l1l1_ek_(name, url, mode, l1ll1lll1l1_ek_=1, l1ll1ll11l1l1_ek_=l1l11l1l1_ek_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠨி"), infoLabels={}, IsPlayable=True, isFolder=False, fanart=l11lll1lll1l1_ek_,l1l11lll1l1l1_ek_=1):
    u = l1ll11ll1l1l1_ek_({l1l11l1l1_ek_ (u"ࠬࡳ࡯ࡥࡧࠪீ"): mode, l1l11l1l1_ek_ (u"࠭ࡦࡰ࡮ࡧࡩࡷࡴࡡ࡮ࡧࠪு"): name, l1l11l1l1_ek_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨூ") : url, l1l11l1l1_ek_ (u"ࠨࡲࡤ࡫ࡪ࠭௃"):l1ll1lll1l1_ek_,l1l11l1l1_ek_ (u"ࠩࡰ࡭ࡳ࡬࡯ࠨ௄"):l1l11l1l1_ek_ (u"ࠪࠫ௅")})
    isFolder = infoLabels.get(l1l11l1l1_ek_ (u"ࠫ࡮ࡹࡆࡰ࡮ࡧࡩࡷ࠭ெ"),isFolder)
    if isFolder and infoLabels.get(l1l11l1l1_ek_ (u"ࠬࡿࡥࡢࡴࠪே"),False):
        name += l1l11l1l1_ek_ (u"࠭ࠠࠩࠧࡶ࠭ࠬை")%infoLabels.get(l1l11l1l1_ek_ (u"ࠧࡺࡧࡤࡶࠬ௉"))
    l1l11ll1ll1l1_ek_ = xbmcgui.ListItem(name)
    l1ll11llll1l1_ek_=[l1l11l1l1_ek_ (u"ࠨࡶ࡫ࡹࡲࡨࠧொ"),l1l11l1l1_ek_ (u"ࠩࡳࡳࡸࡺࡥࡳࠩோ"),l1l11l1l1_ek_ (u"ࠪࡦࡦࡴ࡮ࡦࡴࠪௌ"),l1l11l1l1_ek_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷ்ࠫ"),l1l11l1l1_ek_ (u"ࠬࡩ࡬ࡦࡣࡵࡥࡷࡺࠧ௎"),l1l11l1l1_ek_ (u"࠭ࡣ࡭ࡧࡤࡶࡱࡵࡧࡰࠩ௏"),l1l11l1l1_ek_ (u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪௐ"),l1l11l1l1_ek_ (u"ࠨ࡫ࡦࡳࡳ࠭௑")]
    l1ll1l1lll1l1_ek_ = dict(zip(l1ll11llll1l1_ek_,[infoLabels.get(x,l1ll1ll11l1l1_ek_) for x in l1ll11llll1l1_ek_]))
    l1ll1l1lll1l1_ek_[l1l11l1l1_ek_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬ௒")] = fanart if fanart else l1ll1l1lll1l1_ek_[l1l11l1l1_ek_ (u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭௓")]
    l1l11ll1ll1l1_ek_.setArt(l1ll1l1lll1l1_ek_)
    l1l11ll1ll1l1_ek_.setInfo(type=l1l11l1l1_ek_ (u"ࠦࡻ࡯ࡤࡦࡱࠥ௔"), infoLabels=infoLabels)
    if IsPlayable and not isFolder:
        l1l11ll1ll1l1_ek_.setProperty(l1l11l1l1_ek_ (u"ࠬࡏࡳࡑ࡮ࡤࡽࡦࡨ࡬ࡦࠩ௕"), l1l11l1l1_ek_ (u"࠭ࡴࡳࡷࡨࠫ௖"))
    ok = xbmcplugin.addDirectoryItem(handle=l1l11l1lll1l1_ek_, url=u, listitem=l1l11ll1ll1l1_ek_,isFolder=isFolder,totalItems=l1l11lll1l1l1_ek_)
    xbmcplugin.addSortMethod(l1l11l1lll1l1_ek_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1l11l1l1_ek_ (u"ࠢࠦࡔ࠯ࠤࠪ࡟ࠬࠡࠧࡓࠦௗ"))
    return ok
def l1l1l1l11l1l1_ek_(name,ex_link=None, l1ll1lll1l1_ek_=1, mode=l1l11l1l1_ek_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ௘"),iconImage=l1l11l1l1_ek_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬࠭௙"), infoLabels={}, fanart=l11lll1lll1l1_ek_,contextmenu=None):
    url = l1ll11ll1l1l1_ek_({l1l11l1l1_ek_ (u"ࠪࡱࡴࡪࡥࠨ௚"): mode, l1l11l1l1_ek_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨ௛"): name, l1l11l1l1_ek_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭௜") : ex_link, l1l11l1l1_ek_ (u"࠭ࡰࡢࡩࡨࠫ௝") : l1ll1lll1l1_ek_})
    l1l1l1l1ll1l1_ek_ = xbmcgui.ListItem(name)
    if infoLabels:
        l1l1l1l1ll1l1_ek_.setInfo(type=l1l11l1l1_ek_ (u"ࠢࡷ࡫ࡧࡩࡴࠨ௞"), infoLabels=infoLabels)
    l1ll11llll1l1_ek_=[l1l11l1l1_ek_ (u"ࠨࡶ࡫ࡹࡲࡨࠧ௟"),l1l11l1l1_ek_ (u"ࠩࡳࡳࡸࡺࡥࡳࠩ௠"),l1l11l1l1_ek_ (u"ࠪࡦࡦࡴ࡮ࡦࡴࠪ௡"),l1l11l1l1_ek_ (u"ࠫࡨࡲࡥࡢࡴࡤࡶࡹ࠭௢"),l1l11l1l1_ek_ (u"ࠬࡩ࡬ࡦࡣࡵࡰࡴ࡭࡯ࠨ௣"),l1l11l1l1_ek_ (u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦࠩ௤"),l1l11l1l1_ek_ (u"ࠧࡪࡥࡲࡲࠬ௥")]
    l1ll1l1lll1l1_ek_ = dict(zip(l1ll11llll1l1_ek_,[infoLabels.get(x,iconImage) for x in l1ll11llll1l1_ek_]))
    l1ll1l1lll1l1_ek_[l1l11l1l1_ek_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫ௦")] = fanart if fanart else l1ll1l1lll1l1_ek_[l1l11l1l1_ek_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬ௧")]
    l1l1l1l1ll1l1_ek_.setArt(l1ll1l1lll1l1_ek_)
    if contextmenu:
        l1l1ll1lll1l1_ek_=contextmenu
        l1l1l1l1ll1l1_ek_.addContextMenuItems(l1l1ll1lll1l1_ek_, replaceItems=True)
    else:
        l1l1ll1lll1l1_ek_ = []
        l1l1ll1lll1l1_ek_.append((l1l11l1l1_ek_ (u"ࠪࡍࡳ࡬࡯ࡳ࡯ࡤࡧ࡯ࡧࠧ௨"), l1l11l1l1_ek_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡄࡧࡹ࡯࡯࡯ࠪࡌࡲ࡫ࡵࠩࠨ௩")),)
        l1l1l1l1ll1l1_ek_.addContextMenuItems(l1l1ll1lll1l1_ek_, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=l1l11l1lll1l1_ek_, url=url,listitem=l1l1l1l1ll1l1_ek_, isFolder=True)
    xbmcplugin.addSortMethod(l1l11l1lll1l1_ek_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1l11l1l1_ek_ (u"ࠧࠫࡒ࠭ࠢࠨ࡝࠱ࠦࠥࡑࠤ௪"))
def l1l11l11ll1l1_ek_(name, url=l1l11l1l1_ek_ (u"࠭ࠧ௫"), mode=l1l11l1l1_ek_ (u"ࠧࠨ௬"), l1ll1ll11l1l1_ek_=None, fanart=l11lll1lll1l1_ek_):
    u = l1ll11ll1l1l1_ek_({l1l11l1l1_ek_ (u"ࠨ࡯ࡲࡨࡪ࠭௭"): mode, l1l11l1l1_ek_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭௮"): name, l1l11l1l1_ek_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫ௯") : url, l1l11l1l1_ek_ (u"ࠫࡵࡧࡧࡦࠩ௰"):1})
    l1l11ll1ll1l1_ek_ = xbmcgui.ListItem(name, iconImage=l1ll1ll11l1l1_ek_, thumbnailImage=l1ll1ll11l1l1_ek_)
    l1l11ll1ll1l1_ek_.setProperty(l1l11l1l1_ek_ (u"ࠬࡏࡳࡑ࡮ࡤࡽࡦࡨ࡬ࡦࠩ௱"), l1l11l1l1_ek_ (u"࠭ࡦࡢ࡮ࡶࡩࠬ௲"))
    if fanart:
        l1l11ll1ll1l1_ek_.setProperty(l1l11l1l1_ek_ (u"ࠧࡧࡣࡱࡥࡷࡺ࡟ࡪ࡯ࡤ࡫ࡪ࠭௳"),fanart)
    ok = xbmcplugin.addDirectoryItem(handle=l1l11l1lll1l1_ek_, url=u, listitem=l1l11ll1ll1l1_ek_,isFolder=False)
    return ok
def l11l1111l1l1_ek_(l1lllll1ll1l1_ek_):
    try:
        l11ll11ll1l1_ek_ = {}
        for k, v in l1lllll1ll1l1_ek_.iteritems():
            if isinstance(v, unicode):
                v = v.encode(l1l11l1l1_ek_ (u"ࠪࡹࡹ࡬࠸ࠨ௶"))
            elif isinstance(v, str):
                v.decode(l1l11l1l1_ek_ (u"ࠫࡺࡺࡦ࠹ࠩ௷"))
            l11ll11ll1l1_ek_[k] = v
    except:
        l11ll11ll1l1_ek_=l1lllll1ll1l1_ek_
    return l11ll11ll1l1_ek_
def l1ll11ll1l1l1_ek_(query):
    return l1l1l1llll1l1_ek_ + l1l11l1l1_ek_ (u"ࠬࡅࠧ௸") + urllib.urlencode(l11l1111l1l1_ek_(query))
def l1ll1lll1l1l1_ek_(l1l1111l1l1l1_ek_,l1l111l11l1l1_ek_=[],index=False):
    l1l111ll1l1l1_ek_ = _1ll11111l1l1_ek_()
    out = l1l111ll1l1l1_ek_.l1l1ll11ll1l1_ek_(l1l1111l1l1l1_ek_)
    l1ll11l1ll1l1_ek_ = {}
    if out and isinstance(out,list):
        l1ll11l1ll1l1_ek_ = out[0]
        l1l1111l1l1l1_ek_=l1l11l1l1_ek_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂࠫࡳࠨ௹") %l1ll11l1ll1l1_ek_.get(l1l11l1l1_ek_ (u"ࠧࡪࡦࠪ௺"))
        try:
            import urlresolver
            l1ll11l1ll1l1_ek_[l1l11l1l1_ek_ (u"ࠨࡷࡵࡰࠬ௻")] = urlresolver.resolve(l1l1111l1l1l1_ek_)
        except:
            pass
    if index:
        l1l111l11l1l1_ek_[index]=l1ll11l1ll1l1_ek_
    return l1ll11l1ll1l1_ek_
def l11lllllll1l1_ek_():
    l11ll1l1ll1l1_ek_ = l1l1ll1l1l1l1_ek_.getSetting(l1l11l1l1_ek_ (u"ࠩࡸࡷࡪࡸࠧ௼"))
    passwd = l1l1ll1l1l1l1_ek_.getSetting(l1l11l1l1_ek_ (u"ࠪࡴࡦࡹࡳࠨ௽"))
    l1l111ll1l1l1_ek_ = _1ll11111l1l1_ek_()
    status=l1l111ll1l1l1_ek_.l11ll11lll1l1_ek_(l11ll1l1ll1l1_ek_,passwd)
def _1ll11111l1l1_ek_():
    return False
class l1llll1l1l1_ek_():
    @staticmethod
    def root():
        l1l1l1l11l1l1_ek_(name=l1l11l1l1_ek_ (u"ࠫࡎࡴࡦࡰࡴࡰࡥࡨࡰࡡࠨ௾"),mode=l1l11l1l1_ek_ (u"ࠬࡥࡩ࡯ࡨࡲࡣࠬ௿"),ex_link=None,iconImage=l11llll1ll1l1_ek_,infoLabels={})
        l1l1l1l11l1l1_ek_(name=l1l11l1l1_ek_ (u"࠭ࡆࡪ࡮ࡰࡽࠬఀ"),mode=l1l11l1l1_ek_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨఁ"),ex_link=l1l11l1l1_ek_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧ࡮࡭ࡳࡵ࡭ࡢࡰ࡬ࡥࡰ࠴ࡴࡷ࠱ࡺࡥࡹࡩࡨ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࠩం"),iconImage=l1l11l1l1_ek_ (u"ࠤࡇࡩ࡫ࡧࡵ࡭ࡶࡐࡳࡻ࡯ࡥࡴ࠰ࡳࡲ࡬ࠨః"),infoLabels={})
        l1l1l1l11l1l1_ek_(name=l1l11l1l1_ek_ (u"ࠪࠤࠥࡡࡃࡐࡎࡒࡖࠥࡲࡩࡨࡪࡷࡦࡱࡻࡥ࡞ࡑࡶࡸࡦࡺ࡮ࡪࡱࠣࡨࡴࡪࡡ࡯ࡧ࡞࠳ࡈࡕࡌࡐࡔࡠࠫఄ"),mode=l1l11l1l1_ek_ (u"ࠫࡲࡧࡩ࡯ࡒࠪఅ"),ex_link=l1l11l1l1_ek_ (u"ࠬࡸࡥࡤࡧࡱࡸ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬఆ"),iconImage=l1l11l1l1_ek_ (u"ࠨࡄࡦࡨࡤࡹࡱࡺࡒࡦࡥࡨࡲࡹࡲࡹࡂࡦࡧࡩࡩࡓ࡯ࡷ࡫ࡨࡷ࠳ࡶ࡮ࡨࠤఇ"),infoLabels={})
        l1l1l1l11l1l1_ek_(name=l1l11l1l1_ek_ (u"ࠧࠡࠢ࡞ࡇࡔࡒࡏࡓࠢ࡯࡭࡬࡮ࡴࡣ࡮ࡸࡩࡢࡔࡡ࡫ࡹࡼঀࡪࡰࠠࡰࡥࡨࡲ࡮ࡧ࡮ࡦ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪఈ"),mode=l1l11l1l1_ek_ (u"ࠨ࡯ࡤ࡭ࡳࡖࠧఉ"),ex_link=l1l11l1l1_ek_ (u"ࠩࡷࡳࡵ࠳ࡲࡢࡶࡨࡨ࠲ࡳ࡯ࡷ࡫ࡨࡷࠬఊ"),iconImage=l1l11l1l1_ek_ (u"ࠥࡈࡪ࡬ࡡࡶ࡮ࡷࡖࡪࡩࡥ࡯ࡶ࡯ࡽࡆࡪࡤࡦࡦࡐࡳࡻ࡯ࡥࡴ࠰ࡳࡲ࡬ࠨఋ"),infoLabels={})
        l1l1l1l11l1l1_ek_(name=l1l11l1l1_ek_ (u"࡛ࠫࠥࠦࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸࡧࡲࡵࡦ࡟ࡑࡥ࡯ࡩࡺचढ़ࡦ࡭ࡪࡰࠠ࡬ࡱࡰࡩࡳࡺ࡯ࡸࡣࡱࡩࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ఌ"),mode=l1l11l1l1_ek_ (u"ࠬࡳࡡࡪࡰࡓࠫ఍"),ex_link=l1l11l1l1_ek_ (u"࠭࡭ࡰࡵࡷ࠱ࡨࡵ࡭࡮ࡧࡱࡸࡪࡪ࠭࡮ࡱࡹ࡭ࡪࡹࠧఎ"),iconImage=l1l11l1l1_ek_ (u"ࠢࡅࡧࡩࡥࡺࡲࡴࡓࡧࡦࡩࡳࡺ࡬ࡺࡃࡧࡨࡪࡪࡍࡰࡸ࡬ࡩࡸ࠴ࡰ࡯ࡩࠥఏ"),infoLabels={})
        l1l1l1l11l1l1_ek_(name=l1l11l1l1_ek_ (u"ࠨࡕࡨࡶ࡮ࡧ࡬ࡦࠩఐ"),mode=l1l11l1l1_ek_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ఑"),ex_link=l1l11l1l1_ek_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡰ࡯࡮ࡰ࡯ࡤࡲ࡮ࡧ࡫࠯ࡶࡹ࠳ࡼࡧࡴࡤࡪ࠲ࡸࡻ࠳ࡳࡩࡱࡺࡷ࠴࠭ఒ"),iconImage=l1l11l1l1_ek_ (u"ࠦࡉ࡫ࡦࡢࡷ࡯ࡸ࡙࡜ࡓࡩࡱࡺࡷ࠳ࡶ࡮ࡨࠤఓ"),infoLabels={})
        l1l1l1l11l1l1_ek_(name=l1l11l1l1_ek_ (u"ࠬࠦࠠ࡜ࡅࡒࡐࡔࡘࠠ࡭࡫ࡪ࡬ࡹࡨ࡬ࡶࡧࡠࡓࡸࡺࡡࡵࡰ࡬ࡳࠥࡪ࡯ࡥࡣࡱࡩࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ఔ"),mode=l1l11l1l1_ek_ (u"࠭࡭ࡢ࡫ࡱࡔࠬక"),ex_link=l1l11l1l1_ek_ (u"ࠧࡳࡧࡦࡩࡳࡺ࠭ࡵࡸ࠰ࡷ࡭ࡵࡷࡴࠩఖ"),iconImage=l1l11l1l1_ek_ (u"ࠣࡆࡨࡪࡦࡻ࡬ࡵࡔࡨࡧࡪࡴࡴ࡭ࡻࡄࡨࡩ࡫ࡤࡆࡲ࡬ࡷࡴࡪࡥࡴ࠰ࡳࡲ࡬ࠨగ"),infoLabels={})
        l1l1l1l11l1l1_ek_(name=l1l11l1l1_ek_ (u"ࠩࠣࠤࡠࡉࡏࡍࡑࡕࠤࡱ࡯ࡧࡩࡶࡥࡰࡺ࡫࡝ࡏࡣ࡭ࡻࡾংࡥ࡫ࠢࡲࡧࡪࡴࡩࡢࡰࡨ࡟࠴ࡉࡏࡍࡑࡕࡡࠬఘ"),mode=l1l11l1l1_ek_ (u"ࠪࡱࡦ࡯࡮ࡑࠩఙ"),ex_link=l1l11l1l1_ek_ (u"ࠫࡹࡵࡰ࠮ࡴࡤࡸࡪࡪ࠭ࡵࡸ࠰ࡷ࡭ࡵࡷࡴࠩచ"),iconImage=l1l11l1l1_ek_ (u"ࠧࡊࡥࡧࡣࡸࡰࡹࡘࡥࡤࡧࡱࡸࡱࡿࡁࡥࡦࡨࡨࡊࡶࡩࡴࡱࡧࡩࡸ࠴ࡰ࡯ࡩࠥఛ"),infoLabels={})
        l1l1l1l11l1l1_ek_(name=l1l11l1l1_ek_ (u"࠭ࠠࠡ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬࡫࡭ࡺࡢ࡭ࡷࡨࡡࡓࡧࡪࡤࡼजय़ࡨ࡯ࡥ࡫ࠢ࡮ࡳࡲ࡫࡮ࡵࡱࡺࡥࡳ࡫࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨజ"),mode=l1l11l1l1_ek_ (u"ࠧ࡮ࡣ࡬ࡲࡕ࠭ఝ"),ex_link=l1l11l1l1_ek_ (u"ࠨ࡯ࡲࡷࡹ࠳ࡣࡰ࡯ࡰࡩࡳࡺࡥࡥ࠯ࡷࡺ࠲ࡹࡨࡰࡹࡶࠫఞ"),iconImage=l1l11l1l1_ek_ (u"ࠤࡇࡩ࡫ࡧࡵ࡭ࡶࡕࡩࡨ࡫࡮ࡵ࡮ࡼࡅࡩࡪࡥࡥࡇࡳ࡭ࡸࡵࡤࡦࡵ࠱ࡴࡳ࡭ࠢట"),infoLabels={})
        l1l1l1l11l1l1_ek_(name=l1l11l1l1_ek_ (u"ࠪࡗࡿࡻ࡫ࡢ࡬ࠪఠ"),mode=l1l11l1l1_ek_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࠫడ"),ex_link=None, iconImage=l1l11l1l1_ek_ (u"ࠧࡊࡥࡧࡣࡸࡰࡹࡇࡤࡥࡱࡱࡷࡘ࡫ࡡࡳࡥ࡫࠲ࡵࡴࡧࠣఢ") )
        xbmcplugin.endOfDirectory(l1l11l1lll1l1_ek_)
    @staticmethod
    def l11llll1l1_ek_(l1l1llll1l1l1_ek_):
        from l1l11llll1l1_ek_ import l1l11llll1l1_ek_
        out = l1l11llll1l1_ek_().l1l11ll1l1l1_ek_(l1l1llll1l1l1_ek_)
        l1l1l11l1l1l1_ek_= l1l11l1l1_ek_ (u"࠭ࡧࡦࡶࡖࡩࡦࡹ࡯࡯ࡵࠪణ") if l1l11l1l1_ek_ (u"ࠧࡵࡸ࠰ࡷ࡭ࡵࡷࡴࠩత") in l1l1llll1l1l1_ek_ else l1l11l1l1_ek_ (u"ࠨࡩࡨࡸࡑ࡯࡮࡬ࠩథ")
        for f in out:
            l1l11l111l1l1_ek_(name=f.get(l1l11l1l1_ek_ (u"ࠩࡷ࡭ࡹࡲࡥࠨద")), url=f.get(l1l11l1l1_ek_ (u"ࠪ࡬ࡷ࡫ࡦࠨధ")), mode=l1l1l11l1l1l1_ek_, l1ll1ll11l1l1_ek_=f.get(l1l11l1l1_ek_ (u"ࠫ࡮ࡳࡧࠨన")), infoLabels=f, isFolder=f.get(l1l11l1l1_ek_ (u"ࠬ࡯ࡳࡇࡱ࡯ࡨࡪࡸࠧ఩"),True), IsPlayable=f.get(l1l11l1l1_ek_ (u"࠭ࡉࡴࡒ࡯ࡥࡾࡧࡢ࡭ࡧࠪప"),False))
        xbmcplugin.endOfDirectory(l1l11l1lll1l1_ek_)
    @staticmethod
    def content(l1l1llll1l1l1_ek_):
        from l1l11llll1l1_ek_ import l1l11llll1l1_ek_
        out,l1l1ll11l1l1_ek_ = l1l11llll1l1_ek_().l1lllll1l1l1_ek_(l1l1llll1l1l1_ek_)
        l1l111111l1l1_ek_=l1l11l1l1_ek_ (u"ࠧࡠࡡࡳࡥ࡬࡫࡟ࡠ࠼ࡦࡳࡳࡺࡥ࡯ࡶࠪఫ")
        l1l1l11l1l1l1_ek_= l1l11l1l1_ek_ (u"ࠨࡩࡨࡸࡑ࡯࡮࡬ࠩబ") if l1l11l1l1_ek_ (u"ࠩࡺࡥࡹࡩࡨ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࠩభ") in l1l1llll1l1l1_ek_ else l1l11l1l1_ek_ (u"ࠪ࡫ࡪࡺࡓࡦࡣࡶࡳࡳࡹࠧమ")
        if l1l1ll11l1l1_ek_[0]:
            l1l11l111l1l1_ek_(name=l1l11l1l1_ek_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡱ࡯ࡧࡩࡶࡥࡰࡺ࡫࡝࠽࠾ࠣࡴࡴࡶࡲࡻࡧࡧࡲ࡮ࡧࠠࡴࡶࡵࡳࡳࡧࠠ࠽࠾࡞࠳ࡈࡕࡌࡐࡔࡠࠫయ"), url=l1l1ll11l1l1_ek_[0], mode=l1l111111l1l1_ek_, IsPlayable=False)
        for f in out:
            l1l11l111l1l1_ek_(name=f.get(l1l11l1l1_ek_ (u"ࠬࡺࡩࡵ࡮ࡨࠫర")), url=f.get(l1l11l1l1_ek_ (u"࠭ࡨࡳࡧࡩࠫఱ")), mode=l1l1l11l1l1l1_ek_, l1ll1ll11l1l1_ek_=f.get(l1l11l1l1_ek_ (u"ࠧࡪ࡯ࡪࠫల")), infoLabels=f, isFolder=f.get(l1l11l1l1_ek_ (u"ࠨ࡫ࡶࡊࡴࡲࡤࡦࡴࠪళ")), IsPlayable=f.get(l1l11l1l1_ek_ (u"ࠩࡌࡷࡕࡲࡡࡺࡣࡥࡰࡪ࠭ఴ")))
        if l1l1ll11l1l1_ek_[1]:
            l1l11l111l1l1_ek_(name=l1l11l1l1_ek_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡰ࡮࡭ࡨࡵࡤ࡯ࡹࡪࡣ࠾࠿ࠢࡱࡥࡸࡺङࡱࡰࡤࠤࡸࡺࡲࡰࡰࡤࠤࡃࡄ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨవ"), url=l1l1ll11l1l1_ek_[1], mode=l1l111111l1l1_ek_, IsPlayable=False)
        xbmcplugin.endOfDirectory(l1l11l1lll1l1_ek_)
    @staticmethod
    def l1lll1l1l1_ek_(mode,ex_link):
        _11ll1ll1l1l1_ek_=mode.split(l1l11l1l1_ek_ (u"ࠦ࠿ࠨశ"))[-1]
        url = l1ll11ll1l1l1_ek_({l1l11l1l1_ek_ (u"ࠬࡳ࡯ࡥࡧࠪష"): _11ll1ll1l1l1_ek_, l1l11l1l1_ek_ (u"࠭ࡦࡰ࡮ࡧࡩࡷࡴࡡ࡮ࡧࠪస"): l1l11l1l1_ek_ (u"ࠧࠨహ"), l1l11l1l1_ek_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩ఺") : ex_link })
        xbmc.executebuiltin(l1l11l1l1_ek_ (u"࡛ࠩࡆࡒࡉ࠮ࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠬࠪࡹࠩࠨ఻")% url)
    @staticmethod
    def l11l1ll1l1_ek_(l1l1llll1l1l1_ek_):
        from l1l11llll1l1_ek_ import l1l11llll1l1_ek_
        l1ll1l1l1l1l1_ek_=l1l11llll1l1_ek_()
        l1ll1ll1l1l1_ek_ = l1ll1l1l1l1l1_ek_.l11l1ll1l1_ek_(l1l1llll1l1l1_ek_)
        l1lllllll1l1_ek_ = l1ll1l1l1l1l1_ek_.l1lll11ll1l1_ek_(l1ll1ll1l1l1_ek_)
        for l1ll111lll1l1_ek_ in sorted(l1lllllll1l1_ek_.keys()):
            l1l1l1l11l1l1_ek_(name=l1ll111lll1l1_ek_, ex_link=urllib.quote(str(l1lllllll1l1_ek_[l1ll111lll1l1_ek_])), mode=l1l11l1l1_ek_ (u"ࠪ࡫ࡪࡺࡅࡱ࡫ࡶࡳࡩ࡫ࡳࠨ఼"))
        xbmcplugin.endOfDirectory(l1l11l1lll1l1_ek_)
    @staticmethod
    def l1111ll1l1_ek_(l1l1llll1l1l1_ek_):
        l1ll1ll1l1l1_ek_ = eval(urllib.unquote(l1l1llll1l1l1_ek_))
        for f in l1ll1ll1l1l1_ek_:
            l1l11l111l1l1_ek_(name=f.get(l1l11l1l1_ek_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪఽ")), url=f.get(l1l11l1l1_ek_ (u"ࠬ࡮ࡲࡦࡨࠪా")), mode=l1l11l1l1_ek_ (u"࠭ࡧࡦࡶࡏ࡭ࡳࡱࠧి"), l1ll1ll11l1l1_ek_=f.get(l1l11l1l1_ek_ (u"ࠧࡪ࡯ࡪࠫీ")), infoLabels=f, IsPlayable=True,fanart=f.get(l1l11l1l1_ek_ (u"ࠨ࡫ࡰ࡫ࠬు")))
        xbmcplugin.endOfDirectory(l1l11l1lll1l1_ek_)
    @staticmethod
    def l111l1l1l1_ek_(l1l1llll1l1l1_ek_):
        from l1l11llll1l1_ek_ import l1l11llll1l1_ek_
        l1l1111l1l1l1_ek_ = l1l11llll1l1_ek_().l111l1l1l1_ek_(l1l1llll1l1l1_ek_)
        if l1l1111l1l1l1_ek_:
            try:
                import urlresolver
                l1l111l1ll1l1_ek_ = urlresolver.resolve(l1l1111l1l1l1_ek_)
            except Exception,e:
                l1l111l1ll1l1_ek_=l1l11l1l1_ek_ (u"ࠩࠪూ")
            if l1l111l1ll1l1_ek_:
                xbmcplugin.setResolvedUrl(l1l11l1lll1l1_ek_, True, xbmcgui.ListItem(path=l1l111l1ll1l1_ek_))
            else:
                xbmcplugin.setResolvedUrl(l1l11l1lll1l1_ek_, False, xbmcgui.ListItem(path=l1l11l1l1_ek_ (u"ࠪࠫృ")))
    @staticmethod
    def info():
        l1l1llllll1l1_ek_.__myinfo__.go(sys.argv)
        xbmcplugin.endOfDirectory(l1l11l1lll1l1_ek_)
    @staticmethod
    def l1ll11l1l1_ek_(mode,ex_link):
        from l1l11111ll1l1_ek_ import l11lll1l1l1l1_ek_
        l11ll1llll1l1_ek_=mode.split(l1l11l1l1_ek_ (u"ࠦ࠿ࠨౄ"))[-1] if l1l11l1l1_ek_ (u"ࠬࡀࠧ౅") in mode else l1l11l1l1_ek_ (u"࠭ࠧె")
        if l11ll1llll1l1_ek_ == l1l11l1l1_ek_ (u"ࠧࠨే"):
            l1l1l1l11l1l1_ek_(l1l11l1l1_ek_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬࡫࡭ࡺࡧࡳࡧࡨࡲࡢࡔ࡯ࡸࡧࠣࡷࡿࡻ࡫ࡢࡰ࡬ࡩࠥ࠴࠮࠯࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪై"),ex_link=l1l11l1l1_ek_ (u"ࠩࠪ౉"),mode=l1l11l1l1_ek_ (u"ࠪࡷࡪࡧࡲࡤࡪ࠽ࡲࡪࡽࠧొ"))
            l11llll11l1l1_ek_ = l11lll1l1l1l1_ek_().l1l1l1111l1l1_ek_()
            if not l11llll11l1l1_ek_ == [l1l11l1l1_ek_ (u"ࠫࠬో")]:
                for entry in l11llll11l1l1_ek_:
                    contextmenu = []
                    contextmenu.append((l1l11l1l1_ek_ (u"ࡺ࠭ࡒࡦ࡯ࡲࡺࡪ࠭ౌ"), l1l11l1l1_ek_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࠦࡵ్ࠬࠫ")% l1ll11ll1l1l1_ek_({l1l11l1l1_ek_ (u"ࠧ࡮ࡱࡧࡩࠬ౎"): l1l11l1l1_ek_ (u"ࠨࡵࡨࡥࡷࡩࡨ࠻ࡦࡨࡰࡔࡴࡥࠨ౏"), l1l11l1l1_ek_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪ౐") : entry})),)
                    contextmenu.append((l1l11l1l1_ek_ (u"ࡸࠫࡗ࡫࡭ࡰࡸࡨࠤࡆࡲ࡬ࠨ౑"), l1l11l1l1_ek_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࠫࡳࠪࠩ౒") % l1ll11ll1l1l1_ek_({l1l11l1l1_ek_ (u"ࠬࡳ࡯ࡥࡧࠪ౓"): l1l11l1l1_ek_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡀࡤࡦ࡮ࡄࡰࡱ࠭౔")})),)
                    l1l1l1l11l1l1_ek_(name=entry, ex_link=entry, mode=l1l11l1l1_ek_ (u"ࠧࡴࡧࡤࡶࡨ࡮࠺࡯ࡧࡺౕࠫ"), fanart=None, contextmenu=contextmenu)
            xbmcplugin.endOfDirectory(l1l11l1lll1l1_ek_)
        elif l11ll1llll1l1_ek_ ==l1l11l1l1_ek_ (u"ࠨࡰࡨࡻౖࠬ"):
            if not ex_link:
                l11lll11ll1l1_ek_ = l1l1lll1l1_ek_.input(l1l11l1l1_ek_ (u"ࡷࠪࡘࡾࡺࡵृࠢࡩ࡭ࡱࡳࡵ࠰ࡵࡨࡶ࡮ࡧ࡬ࡶࠩ౗"), type=xbmcgui.INPUT_ALPHANUM)
                if l11lll11ll1l1_ek_: l11lll1l1l1l1_ek_().l1l1111lll1l1_ek_(l11lll11ll1l1_ek_)
            else:
                l11lll11ll1l1_ek_ = ex_link
            if l11lll11ll1l1_ek_:
                print (l1l11l1l1_ek_ (u"ࠪࡷࡪࡧࡲࡤࡪࡢࡸ࡮ࡺ࡬ࡦࠩౘ"),l11lll11ll1l1_ek_)
                from l1l11llll1l1_ek_ import l1l11llll1l1_ek_
                out = l1l11llll1l1_ek_().search(l11lll11ll1l1_ek_)
                for f in out:
                    l1l11l111l1l1_ek_(name=f.get(l1l11l1l1_ek_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪౙ")), url=f.get(l1l11l1l1_ek_ (u"ࠬ࡮ࡲࡦࡨࠪౚ")), mode=f.get(l1l11l1l1_ek_ (u"࠭࡭ࡰࡦࡨࠫ౛")), l1ll1ll11l1l1_ek_=f.get(l1l11l1l1_ek_ (u"ࠧࡪ࡯ࡪࠫ౜")), infoLabels=f, isFolder=f.get(l1l11l1l1_ek_ (u"ࠨ࡫ࡶࡊࡴࡲࡤࡦࡴࠪౝ")), IsPlayable=f.get(l1l11l1l1_ek_ (u"ࠩࡌࡷࡕࡲࡡࡺࡣࡥࡰࡪ࠭౞")))
            xbmcplugin.endOfDirectory(l1l11l1lll1l1_ek_)
        elif l11ll1llll1l1_ek_ ==l1l11l1l1_ek_ (u"ࠪࡨࡪࡲࡏ࡯ࡧࠪ౟"):
            l11lll1l1l1l1_ek_().l1l1lll11l1l1_ek_(ex_link)
            xbmc.executebuiltin(l1l11l1l1_ek_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࠫࡳࠪࠩౠ")%  l1ll11ll1l1l1_ek_({l1l11l1l1_ek_ (u"ࠬࡳ࡯ࡥࡧࠪౡ"): l1l11l1l1_ek_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭ౢ")}))
        elif l11ll1llll1l1_ek_ ==l1l11l1l1_ek_ (u"ࠧࡥࡧ࡯ࡅࡱࡲࠧౣ"):
            l11lll1l1l1l1_ek_().l1ll11l11l1l1_ek_()
            xbmc.executebuiltin(l1l11l1l1_ek_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࠨࡷ࠮࠭౤")%  l1ll11ll1l1l1_ek_({l1l11l1l1_ek_ (u"ࠩࡰࡳࡩ࡫ࠧ౥"): l1l11l1l1_ek_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪ౦")}))
