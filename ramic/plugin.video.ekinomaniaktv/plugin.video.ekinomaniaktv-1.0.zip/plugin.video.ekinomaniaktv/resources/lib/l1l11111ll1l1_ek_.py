# -*- coding: utf-8 -*-
import sys
l111l1l1_ek_ = sys.version_info [0] == 2
l111ll1l1_ek_ = 2048
l1l1ll1l1_ek_ = 7
def l1l11l1l1_ek_ (keyedStringLiteral):
	global l1llll1l1_ek_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l1l1_ek_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll1l1_ek_ - (charIndex + stringNr) % l1l1ll1l1_ek_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll1l1_ek_ - (charIndex + stringNr) % l1l1ll1l1_ek_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import xbmcaddon
l1ll111l1l1l1_ek_       = xbmcaddon.Addon().getAddonInfo(l1l11l1l1_ek_ (u"ࠫࡳࡧ࡭ࡦࠩ౧"))
class l11lll1l1l1l1_ek_():
    def __init__(self,name=l1ll111l1l1l1_ek_):
        try:
            import StorageServer
        except:
            import storageserverdummy as StorageServer
        self.cache = StorageServer.StorageServer(name)
    def l11ll1111l1l1_ek_(self,t):
        return t.encode(l1l11l1l1_ek_ (u"ࠬࡻࡴࡧ࠯࠻ࠫ౨")) if isinstance(t,unicode) else t
    def l1l1l1111l1l1_ek_(self):
        return self.cache.get(l1l11l1l1_ek_ (u"࠭ࡨࡪࡵࡷࡳࡷࡿࠧ౩")).split(l1l11l1l1_ek_ (u"ࠧ࠼ࠩ౪"))
    def l1l1111lll1l1_ek_(self,entry):
        l11l1lllll1l1_ek_ = self.l1l1l1111l1l1_ek_()
        if l11l1lllll1l1_ek_ == [l1l11l1l1_ek_ (u"ࠨࠩ౫")]:
            l11l1lllll1l1_ek_ = []
        l11l1lllll1l1_ek_.insert(0, self.l11ll1111l1l1_ek_(entry))
        try:
            self.cache.set(l1l11l1l1_ek_ (u"ࠩ࡫࡭ࡸࡺ࡯ࡳࡻࠪ౬"),l1l11l1l1_ek_ (u"ࡸࠫࡀ࠭౭").join(l11l1lllll1l1_ek_[:50]))
        except:
            pass
    def l1l1lll11l1l1_ek_(self,entry):
        l11l1lllll1l1_ek_ = self.l1l1l1111l1l1_ek_()
        if l11l1lllll1l1_ek_:
            try:
                self.cache.set(l1l11l1l1_ek_ (u"ࠫ࡭࡯ࡳࡵࡱࡵࡽࠬ౮"),l1l11l1l1_ek_ (u"ࠬࡁࠧ౯").join(l11l1lllll1l1_ek_[:50]))
            except:
                pass
        else:
            self.l1ll11l11l1l1_ek_()
    def l1ll11l11l1l1_ek_(self):
        self.cache.delete(l1l11l1l1_ek_ (u"࠭ࡨࡪࡵࡷࡳࡷࡿࠧ౰"))
