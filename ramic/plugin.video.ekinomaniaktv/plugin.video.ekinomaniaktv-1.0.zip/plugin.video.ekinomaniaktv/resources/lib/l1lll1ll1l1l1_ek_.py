# -*- coding: utf-8 -*-
import sys
l111l1l1_ek_ = sys.version_info [0] == 2
l111ll1l1_ek_ = 2048
l1l1ll1l1_ek_ = 7
def l1l11l1l1_ek_ (keyedStringLiteral):
	global l1llll1l1_ek_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l1l1_ek_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll1l1_ek_ - (charIndex + stringNr) % l1l1ll1l1_ek_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll1l1_ek_ - (charIndex + stringNr) % l1l1ll1l1_ek_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os,json,base64
import cookielib
from urlparse import urlparse,urljoin
def l1lll1l11l1l1_ek_(l1l111ll1l1_ek_):
    pass
l1l1l11l1l1_ek_ = 15
l1l1ll1ll1l1_ek_=l1l11l1l1_ek_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠷࠰࠴࠿ࠥ࡝ࡩ࡯࠸࠷࠿ࠥࡾ࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠷࠳࠱࠴࠳࠹࠱࠷࠵࠱࠵࠵࠶ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧ৕")
try:
    from xbmc import translatePath
    from xbmcaddon import Addon
    l1l1ll1l1l1_ek_    = translatePath(Addon().getAddonInfo(l1l11l1l1_ek_ (u"ࠬࡶࡲࡰࡨ࡬ࡰࡪ࠭৖"))).decode(l1l11l1l1_ek_ (u"࠭ࡵࡵࡨ࠰࠼ࠬৗ"))
    l1llll1ll1l1_ek_=os.path.join(l1l1ll1l1l1_ek_,l1l11l1l1_ek_ (u"ࠧࡤࡱࡲ࡯࡮࡫ࠧ৘"))
except:
    l1llll1ll1l1_ek_=l1l11l1l1_ek_ (u"ࡳࠩࡧࡹࡵࡧ࠮ࡤࡱࡲ࡯࡮࡫ࠧ৙")
l1lll111l1l1_ek_ = l1l11l1l1_ek_ (u"ࠩࠪ৚")
class l1ll11l1l1l1_ek_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
def l1111lll1l1_ek_(url,data=None):
    l1ll111l1l1_ek_ = cookielib.LWPCookieJar()
    if data:
        opener = urllib2.build_opener(l1ll11l1l1l1_ek_, urllib2.HTTPCookieProcessor(l1ll111l1l1_ek_))
    else:
        opener = urllib2.build_opener( urllib2.HTTPCookieProcessor(l1ll111l1l1_ek_))
    opener.addheaders = [(l1l11l1l1_ek_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ৛"), l1l1ll1ll1l1_ek_)]
    try:
        response = opener.open(url,data,l1l1l11l1l1_ek_)
        result= response.read()
        response.close()
    except:
        result=l1llll11l1l1_ek_ = e.read()
    return result
def l111llll1l1_ek_(l1l111ll1l1_ek_):
    if isinstance(l1l111ll1l1_ek_, unicode):
        l1l111ll1l1_ek_ = l1l111ll1l1_ek_.encode(l1l11l1l1_ek_ (u"ࠫࡺࡺࡦ࠮࠺ࠪড়"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠬࠬ࡬ࡵ࠽ࡥࡶ࠴ࠬࡧࡵ࠽ࠪঢ়"),l1l11l1l1_ek_ (u"࠭ࠠࠨ৞"))
    s=l1l11l1l1_ek_ (u"ࠧࡋ࡫ࡑࡧ࡟ࡉࡳ࠸ࠩয়")
    l1l111ll1l1_ek_ = re.sub(s.decode(l1l11l1l1_ek_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨৠ")),l1l11l1l1_ek_ (u"ࠩࠪৡ"),l1l111ll1l1_ek_)
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠪࡠࡳ࠭ৢ"),l1l11l1l1_ek_ (u"ࠫࠬৣ")).replace(l1l11l1l1_ek_ (u"ࠬࡢࡲࠨ৤"),l1l11l1l1_ek_ (u"࠭ࠧ৥"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠧࠧࡰࡥࡷࡵࡁࠧ০"),l1l11l1l1_ek_ (u"ࠨࠩ১"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠩࠩࡵࡺࡵࡴ࠼ࠩ২"),l1l11l1l1_ek_ (u"ࠪࠦࠬ৩")).replace(l1l11l1l1_ek_ (u"ࠫࠫࡧ࡭ࡱ࠽ࡴࡹࡴࡺ࠻ࠨ৪"),l1l11l1l1_ek_ (u"ࠬࠨࠧ৫"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"࠭ࠦࡰࡣࡦࡹࡹ࡫࠻ࠨ৬"),l1l11l1l1_ek_ (u"ࠧࣴࠩ৭")).replace(l1l11l1l1_ek_ (u"ࠨࠨࡒࡥࡨࡻࡴࡦ࠽ࠪ৮"),l1l11l1l1_ek_ (u"ࠩࣖࠫ৯"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠪࠪࡦࡳࡰ࠼ࡱࡤࡧࡺࡺࡥ࠼ࠩৰ"),l1l11l1l1_ek_ (u"ࠫࣸ࠭ৱ")).replace(l1l11l1l1_ek_ (u"ࠬࠬࡡ࡮ࡲ࠾ࡓࡦࡩࡵࡵࡧ࠾ࠫ৲"),l1l11l1l1_ek_ (u"࣓࠭ࠨ৳"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠧࠧࡣࡰࡴࡀ࠭৴"),l1l11l1l1_ek_ (u"ࠨࠨࠪ৵"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠩ࡟ࡹ࠵࠷࠰࠶ࠩ৶"),l1l11l1l1_ek_ (u"ࠪउࠬ৷")).replace(l1l11l1l1_ek_ (u"ࠫࡡࡻ࠰࠲࠲࠷ࠫ৸"),l1l11l1l1_ek_ (u"ࠬऊࠧ৹"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"࠭࡜ࡶ࠲࠴࠴࠼࠭৺"),l1l11l1l1_ek_ (u"ࠧईࠩ৻")).replace(l1l11l1l1_ek_ (u"ࠨ࡞ࡸ࠴࠶࠶࠶ࠨৼ"),l1l11l1l1_ek_ (u"ࠩउࠫ৽"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠪࡠࡺ࠶࠱࠲࠻ࠪ৾"),l1l11l1l1_ek_ (u"ࠫञ࠭৿")).replace(l1l11l1l1_ek_ (u"ࠬࡢࡵ࠱࠳࠴࠼ࠬ਀"),l1l11l1l1_ek_ (u"࠭घࠨਁ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠧ࡝ࡷ࠳࠵࠹࠸ࠧਂ"),l1l11l1l1_ek_ (u"ࠨॄࠪਃ")).replace(l1l11l1l1_ek_ (u"ࠩ࡟ࡹ࠵࠷࠴࠲ࠩ਄"),l1l11l1l1_ek_ (u"ࠪॅࠬਅ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠫࡡࡻ࠰࠲࠶࠷ࠫਆ"),l1l11l1l1_ek_ (u"ࠬॊࠧਇ")).replace(l1l11l1l1_ek_ (u"࠭࡜ࡶ࠲࠴࠸࠹࠭ਈ"),l1l11l1l1_ek_ (u"ࠧॄࠩਉ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠨ࡞ࡸ࠴࠵࡬࠳ࠨਊ"),l1l11l1l1_ek_ (u"ࣶࠩࠫ਋")).replace(l1l11l1l1_ek_ (u"ࠪࡠࡺ࠶࠰ࡥ࠵ࠪ਌"),l1l11l1l1_ek_ (u"ࠫࣘ࠭਍"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠬࡢࡵ࠱࠳࠸ࡦࠬ਎"),l1l11l1l1_ek_ (u"࠭ज़ࠨਏ")).replace(l1l11l1l1_ek_ (u"ࠧ࡝ࡷ࠳࠵࠺ࡧࠧਐ"),l1l11l1l1_ek_ (u"ࠨड़ࠪ਑"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠩ࡟ࡹ࠵࠷࠷ࡢࠩ਒"),l1l11l1l1_ek_ (u"ࠪॾࠬਓ")).replace(l1l11l1l1_ek_ (u"ࠫࡡࡻ࠰࠲࠹࠼ࠫਔ"),l1l11l1l1_ek_ (u"ࠬॿࠧਕ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"࠭࡜ࡶ࠲࠴࠻ࡨ࠭ਖ"),l1l11l1l1_ek_ (u"ࠧॽࠩਗ")).replace(l1l11l1l1_ek_ (u"ࠨ࡞ࡸ࠴࠶࠽ࡢࠨਘ"),l1l11l1l1_ek_ (u"ࠩॾࠫਙ"))
    return l1l111ll1l1_ek_
def l11l1111l1l1_ek_(l1lllll1ll1l1_ek_):
    l11ll11ll1l1_ek_ = {}
    for k, v in l1lllll1ll1l1_ek_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l1l11l1l1_ek_ (u"ࠪࡹࡹ࡬࠸ࠨਚ"))
        elif isinstance(v, str):
            v.decode(l1l11l1l1_ek_ (u"ࠫࡺࡺࡦ࠹ࠩਛ"))
        l11ll11ll1l1_ek_[k] = v
    return l11ll11ll1l1_ek_
_111l111l1l1_ek_=l1l11l1l1_ek_ (u"ࠬ࠭ࠧࠎࠌ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠥࡥࡰࡺ࡫ࡳࠣࡀࡅࡰࡺ࡫ࡳ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠐࠎࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦࠨ࡫࡬ࡦࡥࡷࡶࡴࡴࡩࡤࠤࡁࡉࡱ࡫ࡣࡵࡴࡲࡲ࡮ࡩ࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠏࠍࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠧࡸ࡯࡮ࡨࡧࡵ࠳ࡸࡵ࡮ࡨࡹࡵ࡭ࡹ࡫ࡲࠣࡀࡖ࡭ࡳ࡭ࡥࡳ࠱ࡖࡳࡳ࡭ࡷࡳ࡫ࡷࡩࡷࡂ࠯ࡢࡀ࠿࠳ࡱ࡯࠾ࠎࠌࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠦࡶࠫࡨ࠯ࡴࡱࡸࡰࠧࡄࡒࠧࡄ࠲ࡗࡴࡻ࡬࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠐࠎࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦࠨࡪࡡ࡯ࡥࡨࠦࡃࡊࡡ࡯ࡥࡨࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃࠓࠊࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠤࡪ࡬ࡴࠥ࡮࡯ࡱ࠱ࡵࡥࡵࠨ࠾ࡉ࡫ࡳࠤࡍࡵࡰ࠰ࡔࡤࡴࡁ࠵ࡡ࠿࠾࠲ࡰ࡮ࡄࠍࠋࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠥࡤࡰࡹ࡫ࡲ࡯ࡣࡷ࡭ࡻ࡫ࠢ࠿ࡃ࡯ࡸࡪࡸ࡮ࡢࡶ࡬ࡺࡪࡂ࠯ࡢࡀ࠿࠳ࡱ࡯࠾ࠎࠌࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠦࡶࡴࡩ࡫ࠣࡀࡕࡳࡨࡱ࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠏࠍࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠧࡷ࡫ࡧࡨࡣࡨࠦࡃࡘࡥࡨࡩࡤࡩࡁ࠵ࡡ࠿࠾࠲ࡰ࡮ࡄࠍࠋࠩࠪࠫਜ")
def l11l11l1l1l1_ek_():
    out=[{l1l11l1l1_ek_ (u"࠭ࡴࡪࡶ࡯ࡩࠬਝ"):l1l11l1l1_ek_ (u"ࠧ࡜ࡄࡠࡅࡱࡲ࡛࠰ࡄࡠࠫਞ"),l1l11l1l1_ek_ (u"ࠨࡪࡵࡩ࡫࠭ਟ"):l1l11l1l1_ek_ (u"ࠩࠪਠ")}]
    for key,title in re.findall(l1l11l1l1_ek_ (u"ࠪࠦࠨ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴࠭ਡ"),_111l111l1l1_ek_):
        out.append({l1l11l1l1_ek_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪਢ"):title,l1l11l1l1_ek_ (u"ࠬ࡮ࡲࡦࡨࠪਣ"):key})
    return out
def l111ll1ll1l1_ek_(key=l1l11l1l1_ek_ (u"࠭ࡥ࡭ࡧࡦࡸࡷࡵ࡮ࡪࡥࠪਤ")):
    l1l11l11l1l1_ek_=l1l11l1l1_ek_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡲࡻࡳࡪࡺ࡫ࡹࡧ࠴ࡣࡰ࡯࠲࡫ࡪࡴࡲࡦࡵ࠱ࡴ࡭ࡶࠧਥ")
    content=l1111lll1l1_ek_(l1l11l11l1l1_ek_)
    data=content
    out=[]
    if key:
        ids = [(a.start(), a.end()) for a in re.finditer(l1l11l1l1_ek_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡳࡦࡥࡷ࡭ࡴࡴࠠࡨࡴࡲࡹࡵࠦࡧࡦࡰࡵࡩ࠲ࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠢ࡬ࡨࡂ࠭ਦ"), content)]
        ids.append( (-1,-1) )
        for i in range(len(ids[:-1])):
            l1ll11ll1l1_ek_ = content[ ids[i][1]:ids[i+1][0] ]
            if key in l1ll11ll1l1_ek_[:20]:
                data=l1ll11ll1l1_ek_
                break
    if data:
        ids = [(a.start(), a.end()) for a in re.finditer(l1l11l1l1_ek_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡵ࡫ࡷࡰࡪࡃࠢࡍ࡫ࡶࡸࡪࡴࠠࡵࡱࠣࡸ࡭࡫ࠠࡢ࡮ࡥࡹࡲࠦࠧਧ"), data)]
        ids.append( (-1,-1) )
        for i in range(len(ids[:-1])):
            l1ll11ll1l1_ek_ = data[ ids[i][1]:ids[i+1][0] ]
            artist = re.findall(l1l11l1l1_ek_ (u"ࠪࡦࡾࠦࠨ࠯ࠬࡂ࠭ࠧ࠭ਨ"),l1ll11ll1l1_ek_)
            l1llll11ll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠯ࡥࡧࡷࡥ࡮ࡲࡳ࠯ࡲ࡫ࡴࡡࡅࡴ࠾ࡣࠩ࡭ࡹࡃࠨ࠯ࠬࡂ࠭ࠧࡄࠧ਩"),l1ll11ll1l1_ek_)
            l11l1lll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡪࡩࡷࡖࡰࡦࡎࡳࡧࠣࠢࡶࡶࡨࡃࠢࠩࡪ࠱࠮ࡄ࠯ࠢࠨਪ"),l1ll11ll1l1_ek_)
            l111111ll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"࠭ࠨ࡝ࡦ࠮ࠤࡹࡸࡡࡤ࡭ࡶ࠭ࠬਫ"),l1ll11ll1l1_ek_)
            name = re.findall(l1l11l1l1_ek_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡥ࡫ࡹࡘࡲࡨࡎࡢ࡯ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠳࠿ࠩਬ"),l1ll11ll1l1_ek_)
            if l1llll11ll1l1_ek_ and name and artist:
                artist = artist[0].strip()
                name =  name[0].strip()
                l111111ll1l1_ek_ = l111111ll1l1_ek_[0] if l111111ll1l1_ek_ else l1l11l1l1_ek_ (u"ࠨࠩਭ")
                title = l1l11l1l1_ek_ (u"ࠩࠨࡷࠥ࠳ࠠࠦࡵࠣࠤࠥࡡࠥࡴ࡟ࠪਮ")%(artist,name,l111111ll1l1_ek_)
                href=urllib.urlencode(l11l1111l1l1_ek_({l1l11l1l1_ek_ (u"ࠪࡥࡱࡨࡵ࡮ࡋࡷࡍࡩ࠭ਯ"):l1llll11ll1l1_ek_[0],l1l11l1l1_ek_ (u"ࠫࡦࡸࡴࡪࡵࡷࠫਰ"):artist,l1l11l1l1_ek_ (u"ࠬࡴࡡ࡮ࡧࠪ਱"):name}))
                out.append({l1l11l1l1_ek_ (u"࠭ࡴࡪࡶ࡯ࡩࠬਲ"):title,l1l11l1l1_ek_ (u"ࠧࡩࡴࡨࡪࠬਲ਼"):href,l1l11l1l1_ek_ (u"ࠨ࡫ࡰ࡫ࠬ਴"):l11l1lll1l1_ek_[0] if l11l1lll1l1_ek_ else l1l11l1l1_ek_ (u"ࠩࠪਵ")})
    return out
def l1llllllll1l1_ek_(filename=l1l11l1l1_ek_ (u"ࠪࡥࡷࡺࡩࡴࡶࡶࡐ࡮ࡹࡴ࠯࡬ࡶࡳࡳ࠭ਸ਼")):
    url= l1l11l1l1_ek_ (u"ࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯࡯ࡸࡷ࡮ࡾࡨࡶࡤ࠱ࡧࡴࡳ࠯ࡤࡣࡦ࡬ࡪ࠵ࠢ਷")+filename
    data = l1111l11l1l1_ek_(url)
    l1111111l1l1_ek_=[]
    l11l1ll1l1l1_ek_ = data.get(l1l11l1l1_ek_ (u"ࠬࡧࡲࡵ࡫ࡶࡸࡸ࠭ਸ"),{}).get(l1l11l1l1_ek_ (u"࠭ࡡࡳࡶ࡬ࡷࡹ࠭ਹ"),[])
    for obj in l11l1ll1l1l1_ek_:
        l11111l1l1l1_ek_={}
        l11111l1l1l1_ek_[l1l11l1l1_ek_ (u"ࠧ࡯ࡣࡰࡩࠬ਺")] = obj.get(l1l11l1l1_ek_ (u"ࠨࡰࡤࡱࡪ࠭਻"),l1l11l1l1_ek_ (u"਼ࠩࠪ"));
        l11111l1l1l1_ek_[l1l11l1l1_ek_ (u"ࠪࡥࡷࡺࡩࡴࡶࡑࡥࡲ࡫ࠧ਽")] = obj.get(l1l11l1l1_ek_ (u"ࠫࡳࡧ࡭ࡦࠩਾ"),l1l11l1l1_ek_ (u"ࠬ࠭ਿ"))
        l11111l1l1l1_ek_[l1l11l1l1_ek_ (u"࠭ࡴࡪࡶ࡯ࡩࠬੀ")] = obj.get(l1l11l1l1_ek_ (u"ࠧ࡯ࡣࡰࡩࠬੁ"),l1l11l1l1_ek_ (u"ࠨࠩੂ"))
        l11111l1l1l1_ek_[l1l11l1l1_ek_ (u"ࠩ࡫ࡶࡪ࡬ࠧ੃")] = obj.get(l1l11l1l1_ek_ (u"ࠪࡲࡦࡳࡥࠨ੄"),l1l11l1l1_ek_ (u"ࠫࠬ੅"))
        l11111l1l1l1_ek_[l1l11l1l1_ek_ (u"ࠬ࡯࡭ࡨࠩ੆")] = obj.get(l1l11l1l1_ek_ (u"࠭ࡩ࡮ࡣࡪࡩࠬੇ"),[{}])[-1].get(l1l11l1l1_ek_ (u"ࠧࡊ࠵ࡕࡰࡪࡎࡑ࠾࠿ࠪੈ").decode(l1l11l1l1_ek_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨ੉")),l1l11l1l1_ek_ (u"ࠩࠪ੊"))
        l1111111l1l1_ek_.append(l11111l1l1l1_ek_)
    return l1111111l1l1_ek_
def l1lll111ll1l1_ek_(artist):
    url=l1l11l1l1_ek_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡮ࡺࡵ࡯ࡧࡶ࠲ࡦࡶࡰ࡭ࡧ࠱ࡧࡴࡳ࠯ࡴࡧࡤࡶࡨ࡮࠿ࡵࡧࡵࡱࡂࠫࡳࠧࡧࡱࡸ࡮ࡺࡹ࠾ࡣ࡯ࡦࡺࡳࠦ࡭࡫ࡰ࡭ࡹࡃ࠲࠱ࠩੋ")%urllib.quote(artist)
    data = l1111l11l1l1_ek_(url)
    l1llll1lll1l1_ek_=[]
    for val in data.get(l1l11l1l1_ek_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࡷࠬੌ")):
        l1llllll1l1l1_ek_={}
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠬࡴࡡ࡮ࡧ੍ࠪ")] = val.get(l1l11l1l1_ek_ (u"࠭ࡣࡰ࡮࡯ࡩࡨࡺࡩࡰࡰࡆࡩࡳࡹ࡯ࡳࡧࡧࡒࡦࡳࡥࠨ੎"),l1l11l1l1_ek_ (u"ࠧࠨ੏"))
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠨ࡫ࡰ࡫ࠬ੐")] = val.get(l1l11l1l1_ek_ (u"ࠩࡤࡶࡹࡽ࡯ࡳ࡭ࡘࡶࡱ࠷࠰࠱ࠩੑ"));
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠪࡥࡷࡺࡩࡴࡶࡑࡥࡲ࡫ࠧ੒")] = val.get(l1l11l1l1_ek_ (u"ࠫࡦࡸࡴࡪࡵࡷࡒࡦࡳࡥࠨ੓"),l1l11l1l1_ek_ (u"ࠬ࠭੔")).replace(l1l11l1l1_ek_ (u"ࠨࡖࡢࡴ࡬ࡳࡺࡹࠠࡂࡴࡷ࡭ࡸࡺࡳࠣ੕"), l1l11l1l1_ek_ (u"ࠢࠣ੖"));
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠨ࡫ࡧࠫ੗")] = val.get(l1l11l1l1_ek_ (u"ࠩࡦࡳࡱࡲࡥࡤࡶ࡬ࡳࡳࡏࡤࠨ੘"));
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠪࡥࡷࡺࡩࡴࡶࡌࡨࠬਖ਼")] = val.get(l1l11l1l1_ek_ (u"ࠫࡦࡸࡴࡪࡵࡷࡍࡩ࠭ਗ਼"));
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠬࡶࡵࡣ࡮࡬ࡷ࡭࡫ࡤࠨਜ਼")] = val.get(l1l11l1l1_ek_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫ࡄࡢࡶࡨࠫੜ"),l1l11l1l1_ek_ (u"ࠧࠨ੝")).split(l1l11l1l1_ek_ (u"ࠣࡖࠥਫ਼"))[0];
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠩࡷࡶࡦࡩ࡫ࡄࡱࡸࡲࡹ࠭੟")] = val.get(l1l11l1l1_ek_ (u"ࠪࡸࡷࡧࡣ࡬ࡅࡲࡹࡳࡺࠧ੠"))
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠫࡵࡲ࡯ࡵࠩ੡")] = l1llllll1l1l1_ek_.get(l1l11l1l1_ek_ (u"ࠬࡴࡡ࡮ࡧࠪ੢"),l1l11l1l1_ek_ (u"࠭ࠧ੣")) + l1l11l1l1_ek_ (u"ࠢࠡࡤࡼࠤࠧ੤") + l1llllll1l1l1_ek_.get(l1l11l1l1_ek_ (u"ࠨࡣࡵࡸ࡮ࡹࡴࡏࡣࡰࡩࠬ੥"),l1l11l1l1_ek_ (u"ࠩࠪ੦")) +l1l11l1l1_ek_ (u"ࠪࡠࡳࡶࡵࡣ࡮࡬ࡷ࡭࡫ࡤࠡ࠼ࠪ੧")+l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠫࡵࡻࡢ࡭࡫ࡶ࡬ࡪࡪࠧ੨")]
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠬࡶ࡬ࡰࡶࠪ੩")] += l1l11l1l1_ek_ (u"࠭࡜࡯ࡖࡵࡥࡨࡱࡳ࠻ࠢࠨࡨࠬ੪") %val.get(l1l11l1l1_ek_ (u"ࠧࡵࡴࡤࡧࡰࡉ࡯ࡶࡰࡷࠫ੫")) if val.get(l1l11l1l1_ek_ (u"ࠨࡶࡵࡥࡨࡱࡃࡰࡷࡱࡸࠬ੬")) else l1l11l1l1_ek_ (u"ࠩࠪ੭")
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠪࡴࡱࡵࡴࠨ੮")] += l1l11l1l1_ek_ (u"ࠫࡡࡴࡣࡰࡲࡼࡶ࡮࡭ࡨࡵ࠼ࠣࠩࡸ࠭੯") %val.get(l1l11l1l1_ek_ (u"ࠬࡩ࡯ࡱࡻࡵ࡭࡬࡮ࡴࠨੰ")) if val.get(l1l11l1l1_ek_ (u"࠭ࡣࡰࡲࡼࡶ࡮࡭ࡨࡵࠩੱ")) else l1l11l1l1_ek_ (u"ࠧࠨੲ")
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠨࡲ࡯ࡳࡹ࠭ੳ")] += l1l11l1l1_ek_ (u"ࠩ࡟ࡲࡷ࡫࡬ࡦࡣࡶࡩࡉࡧࡴࡦ࠼ࠣࠩࡸ࠭ੴ") %val.get(l1l11l1l1_ek_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨࡈࡦࡺࡥࠨੵ")) if val.get(l1l11l1l1_ek_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩࡉࡧࡴࡦࠩ੶")) else l1l11l1l1_ek_ (u"ࠬ࠭੷")
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ੸")] = l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠧ࡯ࡣࡰࡩࠬ੹")]
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠨࡥࡲࡨࡪ࠭੺")]=l1l11l1l1_ek_ (u"ࠩࡾࢁࠥࡺࡲࡢࡥ࡮ࡷࠬ੻").format( l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠪࡸࡷࡧࡣ࡬ࡅࡲࡹࡳࡺࠧ੼")] )
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠫ࡭ࡸࡥࡧࠩ੽")]=urllib.urlencode(l11l1111l1l1_ek_({l1l11l1l1_ek_ (u"ࠬࡧ࡬ࡣࡷࡰࡍࡹࡏࡤࠨ੾"):l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"࠭ࡩࡥࠩ੿")],l1l11l1l1_ek_ (u"ࠧࡢࡴࡷ࡭ࡸࡺࠧ઀"):l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠨࡣࡵࡸ࡮ࡹࡴࡏࡣࡰࡩࠬઁ")],l1l11l1l1_ek_ (u"ࠩࡱࡥࡲ࡫ࠧં"):l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠪࡲࡦࡳࡥࠨઃ")]}))
        if val.get(l1l11l1l1_ek_ (u"ࠫࡼࡸࡡࡱࡲࡨࡶ࡙ࡿࡰࡦࠩ઄"))==l1l11l1l1_ek_ (u"ࠬࡩ࡯࡭࡮ࡨࡧࡹ࡯࡯࡯ࠩઅ"):
            l1llll1lll1l1_ek_.append(l1llllll1l1l1_ek_)
    return l1llll1lll1l1_ek_
def l11ll1l1l1l1_ek_(filename=l1l11l1l1_ek_ (u"࠭ࡡ࡭ࡤࡸࡱࡸࡒࡩࡴࡶ࠱࡮ࡸࡵ࡮ࠨઆ"),l1lll1llll1l1_ek_=True):
    url= l1l11l1l1_ek_ (u"ࠢࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡲࡻࡳࡪࡺ࡫ࡹࡧ࠴ࡣࡰ࡯࠲ࡧࡦࡩࡨࡦ࠱ࠥઇ")+filename
    data = l1111lll1l1_ek_(url)
    out=[]
    if (data):
        data=json.loads(data)
        for k,v in data.items():
            for l11111l1l1l1_ek_ in v.get(l1l11l1l1_ek_ (u"ࠨࡧࡱࡸࡷࡿࠧઈ"),[]):
                name = l11111l1l1l1_ek_.get(l1l11l1l1_ek_ (u"ࠩ࡬ࡱ࠿ࡴࡡ࡮ࡧࠪઉ"),l1l11l1l1_ek_ (u"ࠪࠫઊ")).get(l1l11l1l1_ek_ (u"ࠫࡱࡧࡢࡦ࡮ࠪઋ"),l1l11l1l1_ek_ (u"ࠬ࠭ઌ"))
                artist = l11111l1l1l1_ek_.get(l1l11l1l1_ek_ (u"࠭ࡩ࡮࠼ࡤࡶࡹ࡯ࡳࡵࠩઍ"),l1l11l1l1_ek_ (u"ࠧࠨ઎")).get(l1l11l1l1_ek_ (u"ࠨ࡮ࡤࡦࡪࡲࠧએ"),l1l11l1l1_ek_ (u"ࠩࠪઐ"))
                l111lll1l1l1_ek_ =  l11111l1l1l1_ek_.get(l1l11l1l1_ek_ (u"ࠪ࡭ࡲࡀࡩࡵࡧࡰࡇࡴࡻ࡮ࡵࠩઑ"),l1l11l1l1_ek_ (u"ࠫࠬ઒")).get(l1l11l1l1_ek_ (u"ࠬࡲࡡࡣࡧ࡯ࠫઓ"),l1l11l1l1_ek_ (u"࠭ࠧઔ"))
                l1llll111l1l1_ek_  =  l11111l1l1l1_ek_.get(l1l11l1l1_ek_ (u"ࠧࡪ࡯࠽ࡶࡪࡲࡥࡢࡵࡨࡈࡦࡺࡥࠨક"),l1l11l1l1_ek_ (u"ࠨࠩખ")).get(l1l11l1l1_ek_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨગ"),l1l11l1l1_ek_ (u"ࠪࠫઘ")).split(l1l11l1l1_ek_ (u"࡙ࠦࠨઙ"))[0]
                l11lll11l1l1_ek_ = 		l11111l1l1l1_ek_[l1l11l1l1_ek_ (u"ࠧ࡯࡭࠻࡫ࡰࡥ࡬࡫ࠢચ")][-1].get(l1l11l1l1_ek_ (u"࠭࡬ࡢࡤࡨࡰࠬછ"),l1l11l1l1_ek_ (u"ࠧࠨજ"))
                l1llll11ll1l1_ek_ = l11111l1l1l1_ek_.get(l1l11l1l1_ek_ (u"ࠣ࡫ࡧࠦઝ"),{}).get(l1l11l1l1_ek_ (u"ࠩࡤࡸࡹࡸࡩࡣࡷࡷࡩࡸ࠭ઞ"),{}).get(l1l11l1l1_ek_ (u"ࠥ࡭ࡲࡀࡩࡥࠤટ"),l1l11l1l1_ek_ (u"ࠫࠬઠ"))
                href=urllib.urlencode(l11l1111l1l1_ek_({l1l11l1l1_ek_ (u"ࠬࡧ࡬ࡣࡷࡰࡍࡹࡏࡤࠨડ"):l1llll11ll1l1_ek_,l1l11l1l1_ek_ (u"࠭ࡡࡳࡶ࡬ࡷࡹ࠭ઢ"):artist,l1l11l1l1_ek_ (u"ࠧ࡯ࡣࡰࡩࠬણ"):name}))
                l11lllll1l1_ek_=l1l11l1l1_ek_ (u"ࠨࡃࡵࡸ࡮ࡹࡴ࠻ࠢ࡞ࡆࡢࠫࡳ࡜࠱ࡅࡡࡡࡴࡎࡢ࡯ࡨ࠾ࠥࡡࡂ࡞ࠧࡶ࡟࠴ࡈ࡝࡝ࡰࡗࡶࡦࡩ࡫ࡴ࠼ࠣ࡟ࡇࡣࠥࡴ࡝࠲ࡆࡢࡢ࡮ࠨત")%(artist,name,l111lll1l1l1_ek_)
                out.append({l1l11l1l1_ek_ (u"ࠩࡷ࡭ࡹࡲࡥࠨથ"):name,l1l11l1l1_ek_ (u"ࠪ࡭ࡲ࡭ࠧદ"):l11lll11l1l1_ek_,l1l11l1l1_ek_ (u"ࠫࡵࡲ࡯ࡵࠩધ"):l11lllll1l1_ek_,l1l11l1l1_ek_ (u"ࠬ࡮ࡲࡦࡨࠪન"):href})
    return out
def l11ll111l1l1_ek_(albumItId,artist,name):
    if albumItId:
        return l11ll1lll1l1_ek_(albumItId)
def l11llll1l1l1_ek_(l11l1llll1l1_ek_):
    try:
        m, s = divmod(l11l1llll1l1_ek_, 60)
        h, m = divmod(m, 60)
        if h>0:
            l1l111lll1l1_ek_= l1l11l1l1_ek_ (u"ࠨࠥࡥ࠼ࠨ࠴࠷ࡪ࠺ࠦ࠲࠵ࡨࠧ઩") % (h, m, s)
        else:
            l1l111lll1l1_ek_= l1l11l1l1_ek_ (u"ࠢࠦ࠲࠵ࡨ࠿ࠫ࠰࠳ࡦࠥપ") % ( m, s)
    except:
        l1l111lll1l1_ek_=l1l11l1l1_ek_ (u"ࠨࠩફ")
    return l1l111lll1l1_ek_
def l11ll1lll1l1_ek_(albumItId=l1l11l1l1_ek_ (u"ࠩ࠴࠵࠽࠾࠴࠹࠻࠻࠵࠼࠭બ")):
    url = l1l11l1l1_ek_ (u"ࠥ࡬ࡹࡺࡰࡴ࠼࠲࠳࡮ࡺࡵ࡯ࡧࡶ࠲ࡦࡶࡰ࡭ࡧ࠱ࡧࡴࡳ࠯࡭ࡱࡲ࡯ࡺࡶ࠿ࡪࡦࡀࠦભ") + albumItId + l1l11l1l1_ek_ (u"ࠦࠫ࡫࡮ࡵ࡫ࡷࡽࡂࡹ࡯࡯ࡩࠥમ");
    data = l1111lll1l1_ek_(url)
    l111111ll1l1_ek_ = []
    data = json.loads(data)
    for val in data.get(l1l11l1l1_ek_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࡸ࠭ય")):
        l1llllll1l1l1_ek_={}
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"࠭࡮ࡢ࡯ࡨࠫર")] = val.get(l1l11l1l1_ek_ (u"ࠧࡵࡴࡤࡧࡰࡔࡡ࡮ࡧࠪ઱"),l1l11l1l1_ek_ (u"ࠨࠩલ"))
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠩ࡬ࡱ࡬࠭ળ")] = val.get(l1l11l1l1_ek_ (u"ࠪࡥࡷࡺࡷࡰࡴ࡮࡙ࡷࡲ࠱࠱࠲ࠪ઴"));
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠫࡦࡸࡴࡪࡵࡷࡒࡦࡳࡥࠨવ")] = val.get(l1l11l1l1_ek_ (u"ࠬࡧࡲࡵ࡫ࡶࡸࡓࡧ࡭ࡦࠩશ"),l1l11l1l1_ek_ (u"࠭ࠧષ")).replace(l1l11l1l1_ek_ (u"ࠢࡗࡣࡵ࡭ࡴࡻࡳࠡࡃࡵࡸ࡮ࡹࡴࡴࠤસ"), l1l11l1l1_ek_ (u"ࠣࠤહ"));
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠩࡷࡶࡦࡩ࡫ࡏࡷࡰࡦࡪࡸࠧ઺")]=val.get(l1l11l1l1_ek_ (u"ࠪࡸࡷࡧࡣ࡬ࡐࡸࡱࡧ࡫ࡲࠨ઻"),0)
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ઼࠭")]=int(val.get(l1l11l1l1_ek_ (u"ࠬࡺࡲࡢࡥ࡮ࡘ࡮ࡳࡥࡎ࡫࡯ࡰ࡮ࡹࠧઽ"),l1l11l1l1_ek_ (u"࠭࠰ࠨા"))) / 1000
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠧࡪࡦࠪિ")] = albumItId;
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠨࡲࡸࡦࡱ࡯ࡳࡩࡧࡧࠫી")] = val.get(l1l11l1l1_ek_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧࡇࡥࡹ࡫ࠧુ"),l1l11l1l1_ek_ (u"ࠪࠫૂ")).split(l1l11l1l1_ek_ (u"࡙ࠦࠨૃ"))[0];
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠬࡺࡲࡢࡥ࡮ࡇࡴࡻ࡮ࡵࠩૄ")] = val.get(l1l11l1l1_ek_ (u"࠭ࡴࡳࡣࡦ࡯ࡈࡵࡵ࡯ࡶࠪૅ"))
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠧࡱ࡮ࡲࡸࠬ૆")] = l1llllll1l1l1_ek_.get(l1l11l1l1_ek_ (u"ࠨࡰࡤࡱࡪ࠭ે"),l1l11l1l1_ek_ (u"ࠩࠪૈ")) + l1l11l1l1_ek_ (u"ࠥࠤࡧࡿࠠࠣૉ") + l1llllll1l1l1_ek_.get(l1l11l1l1_ek_ (u"ࠫࡦࡸࡴࡪࡵࡷࡒࡦࡳࡥࠨ૊"),l1l11l1l1_ek_ (u"ࠬ࠭ો")) +l1l11l1l1_ek_ (u"࠭࡜࡯ࡲࡸࡦࡱ࡯ࡳࡩࡧࡧ࠾ࠬૌ")+l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠧࡱࡷࡥࡰ࡮ࡹࡨࡦࡦ્ࠪ")]
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠨࡶࡼࡴࡪ࠭૎")] = l1l11l1l1_ek_ (u"ࠤࡤࠦ૏");
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩૐ")] = l1l11l1l1_ek_ (u"ࠫࠪ࠴࠲ࡥࠢ࠰ࠤࠪࡹࠧ૑")%( l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠬࡺࡲࡢࡥ࡮ࡒࡺࡳࡢࡦࡴࠪ૒")],l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"࠭࡮ࡢ࡯ࡨࠫ૓")] )
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠧࡤࡱࡧࡩࠬ૔")]=l11llll1l1l1_ek_(l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪ૕")])
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠩ࡫ࡶࡪ࡬ࠧ૖")]=urllib.urlencode(l11l1111l1l1_ek_({l1l11l1l1_ek_ (u"ࠪࡥࡱࡨࡵ࡮ࡋࡷࡍࡩ࠭૗"):albumItId,l1l11l1l1_ek_ (u"ࠫࡦࡸࡴࡪࡵࡷࠫ૘"):l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠬࡧࡲࡵ࡫ࡶࡸࡓࡧ࡭ࡦࠩ૙")],l1l11l1l1_ek_ (u"࠭࡮ࡢ࡯ࡨࠫ૚"):l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠧ࡯ࡣࡰࡩࠬ૛")]}))
        if val.get(l1l11l1l1_ek_ (u"ࠨࡹࡵࡥࡵࡶࡥࡳࡖࡼࡴࡪ࠭૜"))==l1l11l1l1_ek_ (u"ࠩࡷࡶࡦࡩ࡫ࠨ૝"):
            l111111ll1l1_ek_.append(l1llllll1l1l1_ek_)
    return l111111ll1l1_ek_
l1111l1ll1l1_ek_=l1l11l1l1_ek_ (u"ࠥࡅࡎࢀࡡࡔࡻࡅࡦ࡜ࡎࡖࡨࡒࡦ࠼ࡺࡾࡌࡱࡦࡈࡸࡸࡨࡓࡓࡇࡳ࡬ࡊ࡛ࡉࡨࡅ࠷ࡦࡍࡉ࠴ࠣ૞")
def l1111l11l1l1_ek_(u):
    headers = { l1l11l1l1_ek_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ૟"): l1l1ll1ll1l1_ek_, l1l11l1l1_ek_ (u"ࠬࡸࡥࡧࡧࡵࡩࡷ࠭ૠ"): l1l11l1l1_ek_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡱࡺࡹࡩࡹࡪࡸࡦ࠳ࡩ࡯࡮࠱ࠪૡ") }
    try:
        l111ll11l1l1_ek_ = urllib2.Request(u, None, headers)
        l1111llll1l1_ek_ = urllib2.urlopen(l111ll11l1l1_ek_)
        data = json.load(l1111llll1l1_ek_)
    except:
        data={}
    return data
def l11lll1ll1l1_ek_(l1ll1lllll1l1_ek_=l1l11l1l1_ek_ (u"ࠧࡑࡖ࠷ࡑ࠶࠾ࡓࠨૢ")):
    res = 0;
    l1lll11lll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠨࠪ࡟ࡨ࠰࠯ࡈࠨૣ"),l1ll1lllll1l1_ek_)
    mm = re.findall(l1l11l1l1_ek_ (u"ࠩࠫࡠࡩ࠱ࠩࡎࠩ૤"),l1ll1lllll1l1_ek_)
    l1lll1l1ll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠪࠬࡡࡪࠫࠪࡕࠪ૥"),l1ll1lllll1l1_ek_)
    res += int(l1lll11lll1l1_ek_[0])*3600 if l1lll11lll1l1_ek_ else 0
    res += int(mm[0])*60 if mm else 0
    res += int(l1lll1l1ll1l1_ek_[0]) if l1lll1l1ll1l1_ek_ else 0
    return res;
def l11l11lll1l1_ek_(name,artist,**args):
    l1lll1l11l1l1_ek_((l1l11l1l1_ek_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫࡚࡮ࡪࡥࡰࠩ૦"),name,artist))
    l111l11ll1l1_ek_ = []
    u = l1l11l1l1_ek_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱࡫ࡴࡵࡧ࡭ࡧࡤࡴ࡮ࡹ࠮ࡤࡱࡰ࠳ࡾࡵࡵࡵࡷࡥࡩ࠴ࡼ࠳࠰ࡵࡨࡥࡷࡩࡨࡀࡲࡤࡶࡹࡃࡩࡥࠨࡴࡁࠬ૧") + urllib.quote(name + l1l11l1l1_ek_ (u"ࠨࠠࡣࡻࠣࠦ૨") + artist) + l1l11l1l1_ek_ (u"ࠧࠧ࡯ࡤࡼࡗ࡫ࡳࡶ࡮ࡷࡷࡂ࠷࠰ࠧࡶࡼࡴࡪࡃࡶࡪࡦࡨࡳࠫࡱࡥࡺ࠿ࠪ૩") + l1111l1ll1l1_ek_;
    data=l1111l11l1l1_ek_(u)
    if data.has_key(l1l11l1l1_ek_ (u"ࠨ࡫ࡷࡩࡲࡹࠧ૪")):
        l1lllll11l1l1_ek_ = l1l11l1l1_ek_ (u"ࠩ࠯ࠫ૫").join([d.get(l1l11l1l1_ek_ (u"ࠪ࡭ࡩ࠭૬"),{}).get(l1l11l1l1_ek_ (u"ࠫࡻ࡯ࡤࡦࡱࡌࡨࠬ૭"),l1l11l1l1_ek_ (u"ࠬ࠭૮")) for d in data[l1l11l1l1_ek_ (u"࠭ࡩࡵࡧࡰࡷࠬ૯")]])
        u2 = l1l11l1l1_ek_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩࡦࡶࡩࡴ࠰ࡦࡳࡲ࠵ࡹࡰࡷࡷࡹࡧ࡫࠯ࡷ࠵࠲ࡺ࡮ࡪࡥࡰࡵࡂࡴࡦࡸࡴ࠾ࡥࡲࡲࡹ࡫࡮ࡵࡆࡨࡸࡦ࡯࡬ࡴ࠮ࡶࡸࡦࡺࡩࡴࡶ࡬ࡧࡸ࠲ࡳ࡯࡫ࡳࡴࡪࡺࠦࡪࡦࡀࠫ૰") + l1lllll11l1l1_ek_ + l1l11l1l1_ek_ (u"ࠨࠨ࡮ࡩࡾࡃࠧ૱") + l1111l1ll1l1_ek_;
        items = l1111l11l1l1_ek_(u2)
        for l1l1llll1l1_ek_ in items.get(l1l11l1l1_ek_ (u"ࠩ࡬ࡸࡪࡳࡳࠨ૲"),[]):
            l11111lll1l1_ek_ = l11lll1ll1l1_ek_(l1l1llll1l1_ek_[l1l11l1l1_ek_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡈࡪࡺࡡࡪ࡮ࡶࠫ૳")][l1l11l1l1_ek_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭૴")]);
            l11l1lll1l1_ek_ = l1l1llll1l1_ek_[l1l11l1l1_ek_ (u"ࠬࡹ࡮ࡪࡲࡳࡩࡹ࠭૵")][l1l11l1l1_ek_ (u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪ૶")].get(l1l11l1l1_ek_ (u"ࠧࡩ࡫ࡪ࡬ࠬ૷")).get(l1l11l1l1_ek_ (u"ࠨࡷࡵࡰࠬ૸"))
            if (l11111lll1l1_ek_ < 900 and l11111lll1l1_ek_ > 60):
                l11l1l11l1l1_ek_={l1l11l1l1_ek_ (u"ࠩ࡬ࡨࠬૹ"):l1l1llll1l1_ek_[l1l11l1l1_ek_ (u"ࠪ࡭ࡩ࠭ૺ")],l1l11l1l1_ek_ (u"ࠫ࡮ࡳࡧࠨૻ"):l11l1lll1l1_ek_, l1l11l1l1_ek_ (u"ࠧࡺࡩࡵ࡮ࡨࠦૼ"): l1l1llll1l1_ek_[l1l11l1l1_ek_ (u"࠭ࡳ࡯࡫ࡳࡴࡪࡺࠧ૽")][l1l11l1l1_ek_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭૾")],l1l11l1l1_ek_ (u"ࠨࡲ࡯ࡳࡹ࠭૿"):l1l1llll1l1_ek_[l1l11l1l1_ek_ (u"ࠩࡶࡲ࡮ࡶࡰࡦࡶࠪ଀")][l1l11l1l1_ek_ (u"ࠪࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠨଁ")],l1l11l1l1_ek_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭ଂ"):l11111lll1l1_ek_}
                l11l1l11l1l1_ek_.update(l1l1llll1l1_ek_[l1l11l1l1_ek_ (u"ࠬࡹࡴࡢࡶ࡬ࡷࡹ࡯ࡣࡴࠩଃ")])
                l111l11ll1l1_ek_.append(l11l1l11l1l1_ek_)
    return l111l11ll1l1_ek_
def l11l111ll1l1_ek_(l1111ll1l1l1_ek_=l1l11l1l1_ek_ (u"࠭ࠧ଄")):
    if l1111ll1l1l1_ek_==l1l11l1l1_ek_ (u"ࠧࡵࡴࡲ࡮ࡰࡧࠧଅ"):
        return l111lllll1l1_ek_()
    elif l1111ll1l1l1_ek_==l1l11l1l1_ek_ (u"ࠨࡴࡰࡪ࡫ࡳࠧଆ"):
        return l111l1l1l1l1_ek_()
    return ([],l1l11l1l1_ek_ (u"ࠩࠪଇ"))
def l111lllll1l1_ek_():
    l1l11l11l1l1_ek_=l1l11l1l1_ek_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡰࡵ࠹࠮ࡱࡱ࡯ࡷࡰ࡯ࡥࡳࡣࡧ࡭ࡴ࠴ࡰ࡭࠱ࡱࡳࡹࡵࡷࡢࡰ࡬ࡥ࠴࠭ଈ")
    content = l1111lll1l1_ek_(l1l11l11l1l1_ek_)
    ids = [(a.start(), a.end()) for a in re.finditer(l1l11l1l1_ek_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡥࡳࡽࡔ࡯ࡵࡱࡺࡥࡳ࡯ࡥࠣࡀࠪଉ"), content)]
    ids.append( (-1,-1) )
    l111111ll1l1_ek_=[]
    i=0
    l1llll1l1l1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡲࡺࡳࡥࡳࡉ࡯ࡳࡸࡵࡷࡢࡰ࡬ࡥࠧࡄ࡛࡝ࡵ࡟ࡲࡢ࠰࠼ࡴࡲࡤࡲࠥࡩ࡬ࡢࡵࡶࡁࠧࡺࡥࡹࡶࠥࡂ࠭࠴ࠫࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀ࠿ࡷࡵࡧ࡮ࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡰࡸࡱࡧ࡫ࡲࠣࡀࠫࡠࡩ࠱ࠩ࠽࠱ࡶࡴࡦࡴ࠾࡜࡞ࡶࡠࡳࡣࠪ࠽ࡵࡳࡥࡳࠦࡣ࡭ࡣࡶࡷࡂࠨࡺࡅࡰ࡬ࡥࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬଊ"),content)
    l1llll1l1l1l1_ek_ = l1l11l1l1_ek_ (u"࠭ࠠࠨଋ").join(l1llll1l1l1l1_ek_[0]) if l1llll1l1l1l1_ek_ else l1l11l1l1_ek_ (u"ࠧࡏࡱࡷࡳࡼࡧ࡮ࡪࡧࠣࡴࡷࡵࡧࡳࡣࡰࡹࠥ࠹ࠧଌ")
    l11l1l1ll1l1_ek_ = content[ ids[i][1]:ids[i+1][0] ]
    l1lll1111l1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠨ࠾ࡷࡶࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡲ࠿ࠩ଍"),l11l1l1ll1l1_ek_,re.DOTALL)
    for idx,l1ll1l1l1_ek_ in enumerate(l1lll1111l1l1_ek_[1:]):
        l1lll11l1l1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠴ࡽࡹ࡬ࡱࡱࡥࡼࡩࡡ࠰࠰࠮ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ଎"),l1ll1l1l1_ek_)
        l111l1lll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠵ࡵࡵࡹࡲࡶ࠴࠴ࠫࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ଏ"),l1ll1l1l1_ek_)
        l11l1lll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩଐ"),l1ll1l1l1_ek_)
        if l1lll11l1l1l1_ek_ and l111l1lll1l1_ek_:
            l1llllll1l1l1_ek_={l1l11l1l1_ek_ (u"ࠬࡧࡲࡵ࡫ࡶࡸࡓࡧ࡭ࡦࠩ଑"):l1lll11l1l1l1_ek_[0].strip(),l1l11l1l1_ek_ (u"࠭࡮ࡢ࡯ࡨࠫ଒"):l111l1lll1l1_ek_[0].strip()}
            l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ଓ")] = l1l11l1l1_ek_ (u"ࠨࠧ࠱࠶ࡩ࠴ࠠࠦࡵࠣ࠱ࠥࠫࡳࠨଔ")%(idx+1,l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠩࡤࡶࡹ࡯ࡳࡵࡐࡤࡱࡪ࠭କ")],l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠪࡲࡦࡳࡥࠨଖ")])
            l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠫ࡭ࡸࡥࡧࠩଗ")]=urllib.urlencode(l11l1111l1l1_ek_({l1l11l1l1_ek_ (u"ࠬࡧ࡬ࡣࡷࡰࡍࡹࡏࡤࠨଘ"):None,l1l11l1l1_ek_ (u"࠭ࡡࡳࡶ࡬ࡷࡹ࠭ଙ"):l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠧࡢࡴࡷ࡭ࡸࡺࡎࡢ࡯ࡨࠫଚ")],l1l11l1l1_ek_ (u"ࠨࡰࡤࡱࡪ࠭ଛ"):l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠩࡱࡥࡲ࡫ࠧଜ")]}))
            l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠪ࡭ࡲ࡭ࠧଝ")]=l11l1lll1l1_ek_[0] if l11l1lll1l1_ek_ else l1l11l1l1_ek_ (u"ࠫࠬଞ")
            l111111ll1l1_ek_.append(l1llllll1l1l1_ek_)
    return l111111ll1l1_ek_,l1llll1l1l1l1_ek_
def l111l1l1l1l1_ek_():
    l1l11l11l1l1_ek_=l1l11l1l1_ek_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡵࡱ࡫࠴ࡦ࡮࠱ࡤࡹ࠴ࡶ࡯ࡱ࡮࡬ࡷࡹࡧ࠮ࡩࡶࡰࡰࠬଟ")
    content = l1111lll1l1_ek_(l1l11l11l1l1_ek_)
    content = content.decode(l1l11l1l1_ek_ (u"࠭ࡩࡴࡱ࠰࠼࠽࠻࠹࠮࠴ࠪଠ")).encode(l1l11l1l1_ek_ (u"ࠧࡶࡶࡩ࠱࠽࠭ଡ"))
    l111111ll1l1_ek_=[]
    l1llll1l1l1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡰࡰࡲ࡯࡭ࡸࡺࡡ࠮ࡰࡲࡸࡴࡽࡡ࡯࡫ࡨ࠱ࡳࡻ࡭ࡦࡴࠥࡂࡠࡢࡳ࡝ࡰࡠ࠮࠭࠴ࠫࡀࠫ࠿ࡷࡵࡧ࡮ࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡲࡴࡱ࡯ࡳࡵࡣ࠰ࡾࡩࡴࡩࡢࠤࡁࠬ࠳࠱࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩଢ"),content)
    l1llll1l1l1l1_ek_ = l1l11l1l1_ek_ (u"ࠩࠪଣ").join(l1llll1l1l1l1_ek_[0]) if l1llll1l1l1l1_ek_ else l1l11l1l1_ek_ (u"ࠪࡒࡴࡺ࡯ࡸࡣࡱ࡭ࡪࠦࡒࡎࡈࠣࡊࡒ࠭ତ")
    l11lll11l1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡳࡳࡵࡲࡩࡴࡶࡤ࠱࡮ࡳࡡࡨࡧࠥࡂࡁࡧ࠮ࠬࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧଥ"),content,re.DOTALL|re.I)
    title = re.findall(l1l11l1l1_ek_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡴࡴࡶ࡬ࡪࡵࡷࡥ࠲ࡧࡲࡵ࡫ࡶࡸ࠲ࡺࡩࡵ࡮ࡨࠦࡃࡂࡡ࡜ࡠࡁࡡ࠯ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠰࠮ࡃࡁࡧ࡛࡟ࡀࡠ࠮ࡃ࠮࠮ࠫࡁࠬࡀ࠴࠭ଦ"),content,re.DOTALL|re.I)
    idx=0
    for artist,name in title:
        l1lll11l1l1l1_ek_ = artist.strip()
        l111l1lll1l1_ek_ = name.strip()
        l11l1lll1l1_ek_ = l11lll11l1l1_ek_[idx].split(l1l11l1l1_ek_ (u"࠭࠿ࠨଧ"))[0] if idx<len(l11lll11l1l1_ek_) else l1l11l1l1_ek_ (u"ࠧࠨନ")
        l1llllll1l1l1_ek_={l1l11l1l1_ek_ (u"ࠨࡣࡵࡸ࡮ࡹࡴࡏࡣࡰࡩࠬ଩"):l1lll11l1l1l1_ek_,l1l11l1l1_ek_ (u"ࠩࡱࡥࡲ࡫ࠧପ"):l111l1lll1l1_ek_}
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩଫ")] = l1l11l1l1_ek_ (u"ࠫࠪ࠴࠲ࡥ࠰ࠣࠩࡸࠦ࠭ࠡࠧࡶࠫବ")%(idx+1,l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠬࡧࡲࡵ࡫ࡶࡸࡓࡧ࡭ࡦࠩଭ")],l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"࠭࡮ࡢ࡯ࡨࠫମ")])
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠧࡩࡴࡨࡪࠬଯ")]=urllib.urlencode(l11l1111l1l1_ek_({l1l11l1l1_ek_ (u"ࠨࡣ࡯ࡦࡺࡳࡉࡵࡋࡧࠫର"):None,l1l11l1l1_ek_ (u"ࠩࡤࡶࡹ࡯ࡳࡵࠩ଱"):l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠪࡥࡷࡺࡩࡴࡶࡑࡥࡲ࡫ࠧଲ")],l1l11l1l1_ek_ (u"ࠫࡳࡧ࡭ࡦࠩଳ"):l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"ࠬࡴࡡ࡮ࡧࠪ଴")]}))
        l1llllll1l1l1_ek_[l1l11l1l1_ek_ (u"࠭ࡩ࡮ࡩࠪଵ")]=l11l1lll1l1_ek_
        l111111ll1l1_ek_.append(l1llllll1l1l1_ek_)
        idx+=1
    return l111111ll1l1_ek_,l1llll1l1l1l1_ek_
class l111111l1l1_ek_:
    def l11lll1l1l1_ek_(self,url):
        if not url:
            url = l1l11l1l1_ek_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡫ࡤࡲࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࠬଶ")
        elif url.startswith(l1l11l1l1_ek_ (u"ࠨ࠱࠲ࠫଷ")):
            url = l1l11l1l1_ek_ (u"ࠩ࡫ࡸࡹࡶࠧସ")+url
        elif url.startswith(l1l11l1l1_ek_ (u"ࠪ࠳ࠬହ")):
            url = urljoin(l1l11l1l1_ek_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩ଺"),url)
        return url
    @staticmethod
    def l1lllll1l1l1_ek_(url=l1l11l1l1_ek_ (u"ࠬ࠭଻")):
        if not url:
            url = l1l11l1l1_ek_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡪࡣࡱࡩ࡭ࡱࡳ࠮ࡱ࡮࠲଼ࠫ")
        elif url.startswith(l1l11l1l1_ek_ (u"ࠧ࠰ࠩଽ")):
            url = urljoin(l1l11l1l1_ek_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡬ࡥࡳ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭ା"),url)
        content = l1111lll1l1_ek_(url)
        out=[]
        l111l11l1l1_ek_ = re.compile(l1l11l1l1_ek_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡪࡴࡴ࠮ࡩࡵ࡭ࡩࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬି"),re.DOTALL).findall(content)
        for show in l111l11l1l1_ek_:
            l11l1l1l1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠯ࡴࡧࡵ࡭ࡦࡲࡥ࠰࠰࠭࠭ࠧࡄ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩୀ"),show)
            if l11l1l1l1l1_ek_:
                l11l1lll1l1_ek_ = l11l1l1l1l1_ek_[0][1]
                l11l1lll1l1_ek_ = urljoin(l1l11l1l1_ek_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩୁ"),l11l1lll1l1_ek_) if not l11l1lll1l1_ek_.startswith(l1l11l1l1_ek_ (u"ࠬ࡮ࡴࡵࡲࠪୂ")) else l11l1lll1l1_ek_
                title = l11l1l1l1l1_ek_[0][0].replace(l1l11l1l1_ek_ (u"࠭࠯ࡴࡧࡵ࡭ࡦࡲࡥ࠰ࠩୃ"),l1l11l1l1_ek_ (u"ࠧࠨୄ")).replace(l1l11l1l1_ek_ (u"ࠨ࠯ࠪ୅"),l1l11l1l1_ek_ (u"ࠩࠣࠫ୆")).replace(l1l11l1l1_ek_ (u"ࠪ࠳ࠬେ"),l1l11l1l1_ek_ (u"ࠫࠬୈ")).title()
                out.append({l1l11l1l1_ek_ (u"ࠬ࡮ࡲࡦࡨࠪ୉"):l11l1l1l1l1_ek_[0][0],l1l11l1l1_ek_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ୊"):title,l1l11l1l1_ek_ (u"ࠧࡪ࡯ࡪࠫୋ"):l11l1lll1l1_ek_})
        idx = content.find(l1l11l1l1_ek_ (u"ࠨࡪ࠶ࡂࡘ࡫ࡲࡪࡣ࡯ࡩࡁ࠵ࡨ࠴ࡀࠪୌ"))
        if idx:
            l1ll1l11l1l1_ek_ = re.compile(l1l11l1l1_ek_ (u"ࠩ࠿ࡹࡱࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀ୍ࠪ"),re.DOTALL).search(content[idx:-1])
            l1ll1l11l1l1_ek_ = l1ll1l11l1l1_ek_.group(1) if l1ll1l11l1l1_ek_ else l1l11l1l1_ek_ (u"ࠪࠫ୎")
            l1ll1l11l1l1_ek_ = re.sub(l1l11l1l1_ek_ (u"ࡶࠧࡂࠡ࠮࠯ࠫ࠲ࢁࡢࡳࡽ࡞ࡱ࠭࠯ࡅ࠭࠮ࡀࠥ୏"), l1l11l1l1_ek_ (u"ࠧࠨ୐"), l1ll1l11l1l1_ek_)
            l1ll11lll1l1_ek_ = re.compile(l1l11l1l1_ek_ (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠯ࡴࡧࡵ࡭ࡦࡲࡥ࠰࠰࠭ࡃ࠮ࠨ࠾ࠩ࡝ࡡࡂࡢ࠰ࠩ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠪ୑")).findall(l1ll1l11l1l1_ek_)
            for href,title in l1ll11lll1l1_ek_:
                out.append({l1l11l1l1_ek_ (u"ࠧࡩࡴࡨࡪࠬ୒"):href,l1l11l1l1_ek_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ୓"):title})
        return out
    @staticmethod
    def l1l1lllll1l1_ek_(url=l1l11l1l1_ek_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡭ࡦࡴ࡬ࡩ࡭࡯࠱ࡴࡱ࠵ࡳࡦࡴ࡬ࡥࡱ࡫࠯ࡥࡧࡷࡩࡰࡺࡹࡸ࠱ࠪ୔")):
        if not url:
            url = l1l11l1l1_ek_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡮ࡧࡵࡦࡪ࡮ࡰ࠲ࡵࡲ࠯ࠨ୕")
        if url.startswith(l1l11l1l1_ek_ (u"ࠫ࠴࠵ࠧୖ")):
            url = l1l11l1l1_ek_ (u"ࠬ࡮ࡴࡵࡲࠪୗ")+url
        if url.startswith(l1l11l1l1_ek_ (u"࠭࠯ࠨ୘")):
            url = urljoin(l1l11l1l1_ek_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡫ࡤࡲࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࠬ୙"),url)
        url += l1l11l1l1_ek_ (u"ࠨ࠱ࠪ୚") if not url.endswith(l1l11l1l1_ek_ (u"ࠩ࠲ࠫ୛")) else l1l11l1l1_ek_ (u"ࠪࠫଡ଼")
        content = l1111lll1l1_ek_(url)
        out=[]
        l1ll1ll1l1l1_ek_ = re.compile(l1l11l1l1_ek_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶ࠰࡫ࡷ࡯ࡤࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧଢ଼"),re.DOTALL).findall(content)
        for l1l1111l1l1_ek_ in l1ll1ll1l1l1_ek_:
            l1lll1l1l1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠬࡹࡥࡻࡱࡱࡠࡸ࠰ࠨ࡝ࡦ࠮࠭ࠬ୞"),l1l1111l1l1_ek_,re.I)
            l1lll1l1l1l1_ek_ = l1lll1l1l1l1_ek_[0] if l1lll1l1l1l1_ek_ else l1l11l1l1_ek_ (u"࠭ࠧୟ")
            l1l1lll1l1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠧࡐࡦࡦ࡭ࡳ࡫࡫࡝ࡵ࠭ࠬࡡࡪࠫࠪࠩୠ"),l1l1111l1l1_ek_,re.I)
            l1l1lll1l1l1_ek_ = l1l1lll1l1l1_ek_[0] if l1l1lll1l1l1_ek_ else l1l11l1l1_ek_ (u"ࠨࠩୡ")
            href = re.compile(l1l11l1l1_ek_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭ࡹࡩ࡯ࡩ࡯ࡩࡵࡧࡧࡦ࠰ࡳ࡬ࡵࡢ࠿ࡪࡦࡀࡠࡩ࠱ࠩࠣࠩୢ")).findall(l1l1111l1l1_ek_)
            l11l1lll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠪࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ୣ"),l1l1111l1l1_ek_)
            if href and l1lll1l1l1l1_ek_ and l1l1lll1l1l1_ek_:
                l11l1lll1l1_ek_ = urljoin(l1l11l1l1_ek_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩ୤"),l11l1lll1l1_ek_[0]) if not l11l1lll1l1_ek_[0].startswith(l1l11l1l1_ek_ (u"ࠬ࡮ࡴࡵࡲࠪ୥")) else l1l11l1l1_ek_ (u"࠭ࠧ୦")
                out.append({l1l11l1l1_ek_ (u"ࠧࡩࡴࡨࡪࠬ୧"):url+href[0],l1l11l1l1_ek_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ୨"):l1l11l1l1_ek_ (u"ࠩࡖࡩࡿࡵ࡮ࠡࠧࡶ࠰ࠥࡋࡰࡪࡼࡲࡨࠥࠫࡳࠨ୩")%(l1lll1l1l1l1_ek_,l1l1lll1l1l1_ek_),l1l11l1l1_ek_ (u"ࠪ࡭ࡲ࡭ࠧ୪"):l11l1lll1l1_ek_,
                l1l11l1l1_ek_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࠫ୫"):int(l1lll1l1l1l1_ek_),l1l11l1l1_ek_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪ࠭୬"):int(l1l1lll1l1l1_ek_)})
        return out
    @staticmethod
    def l1lll11ll1l1_ek_(out):
        l1l11lll1l1_ek_={}
        l1lllllll1l1_ek_ = [x.get(l1l11l1l1_ek_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭୭")) for x in out]
        for s in set(l1lllllll1l1_ek_):
            l1l11lll1l1_ek_[l1l11l1l1_ek_ (u"ࠧࡔࡧࡽࡳࡳࠦࠥ࠱࠴ࡧࠫ୮")%s]=[out[i] for i, j in enumerate(l1lllllll1l1_ek_) if j == s]
        return l1l11lll1l1_ek_
    @staticmethod
    def l111l1l1l1_ek_(url):
        content = l1111lll1l1_ek_(url)
        l11ll1ll1l1_ek_=l1l11l1l1_ek_ (u"ࠨࠩ୯")
        l11ll11l1l1_ek_ = re.compile(l1l11l1l1_ek_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠫ࠲࠯ࡅࠩ࠽࠱࡬ࡪࡷࡧ࡭ࡦࡀࠪ୰"),re.DOTALL).findall(content)
        if l11ll11l1l1_ek_:
            src = re.compile(l1l11l1l1_ek_ (u"ࠪࡷࡷࡩ࠽࡜࡞ࠪࠦࡢ࠮࠮ࠫࡁࠬ࡟ࡡ࠭ࠢ࡞ࠩୱ"),re.DOTALL).findall(l11ll11l1l1_ek_[0])
            l11ll1ll1l1_ek_ = src[0] if src else l1l11l1l1_ek_ (u"ࠫࠬ୲")
        return l11ll1ll1l1_ek_
class l1ll1l1ll1l1_ek_:
    @staticmethod
    def l1lllll1l1l1_ek_(url,l11l111l1l1_ek_=None):
        if l11l111l1l1_ek_:
            l11l111l1l1_ek_ = l1l11l1l1_ek_ (u"ࠬࡹࡺࡶ࡭ࡤ࡮ࡂ࠭୳")+l11l111l1l1_ek_.replace(l1l11l1l1_ek_ (u"࠭ࠠࠨ୴"),l1l11l1l1_ek_ (u"ࠧࠬࠩ୵"))
            url= l1l11l1l1_ek_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡨ࡯ࡹࡨ࡬ࡰࡲ࠴ࡰ࡭࠱ࡶࡾࡺࡱࡡ࡫ࠩ୶")
        if not url:
            url = l1l11l1l1_ek_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡰࡺࡩ࡭ࡱࡳ࠮ࡱ࡮࠲ࠫ୷")
        elif url.startswith(l1l11l1l1_ek_ (u"ࠪ࠳ࠬ୸")):
            url = urljoin(l1l11l1l1_ek_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡲࡼ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭୹"),url)
        content = l1111lll1l1_ek_(url,l11l111l1l1_ek_)
        ids = [(a.start(), a.end()) for a in re.finditer(l1l11l1l1_ek_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡺ࡮ࡪࡥࡰࡡ࡬ࡲ࡫ࡵࠢ࠿ࠩ୺"), content,re.IGNORECASE)]
        ids.append( (-1,-1) )
        out=[]
        for i in range(len(ids[:-1])):
            l1ll11ll1l1_ek_ = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile(l1l11l1l1_ek_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ୻"),re.DOTALL).search(l1ll11ll1l1_ek_)
            title = re.compile(l1l11l1l1_ek_ (u"ࠧ࠽ࡪ࠴ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠷࠾ࠨ୼"),re.DOTALL).search(l1ll11ll1l1_ek_)
            l11l1lll1l1_ek_ = re.compile(l1l11l1l1_ek_ (u"ࠨ࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ୽"),re.DOTALL).search(l1ll11ll1l1_ek_)
            l1ll111ll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠩࡏࡩࡰࡺ࡯ࡳ࠼࡟ࡷ࠯ࡂࡳࡱࡣࡱࠤࡸࡺࡹ࡭ࡧࡀࠦࡠࡤ࠾࡞ࠬࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ୾"),l1ll11ll1l1_ek_)
            l1ll1llll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠪࡈࡴࡪࡡ࡯ࡻ࠽ࡠࡸ࠰࠼ࡴࡲࡤࡲࠥࡹࡴࡺ࡮ࡨࡁࠧࡡ࡞࠿࡟࠭ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ୿"),l1ll11ll1l1_ek_)
            l1ll1111l1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠫࡌࡧࡴࡶࡰࡨ࡯࠿ࡢࡳࠫ࠾ࡶࡴࡦࡴࠠࡴࡶࡼࡰࡪࡃࠢ࡜ࡠࡁࡡ࠯ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭஀"),l1ll11ll1l1_ek_)
            l1ll111ll1l1_ek_ = l1ll111ll1l1_ek_[0] if l1ll111ll1l1_ek_ else l1l11l1l1_ek_ (u"ࠬ࠭஁")
            l1ll1llll1l1_ek_ = l1ll1llll1l1_ek_[0] if l1ll1llll1l1_ek_ else l1l11l1l1_ek_ (u"࠭ࠧஂ")
            l1ll1111l1l1_ek_ = l1ll1111l1l1_ek_[0] if l1ll1111l1l1_ek_ else l1l11l1l1_ek_ (u"ࠧࠨஃ")
            code = l1ll111ll1l1_ek_
            l11lllll1l1_ek_ = l1l11l1l1_ek_ (u"ࠣࡎࡨ࡯ࡹࡵࡲ࠻ࠢࠨࡷࠥࡢ࡮ࡅࡱࡧࡥࡳࡿ࠺ࠡࠧࡶࠤࡡࡴࡇࡢࡶࡸࡲࡪࡱ࠺ࠡࠧࡶࠤࡡࡴࠢ஄") %(l1ll111ll1l1_ek_,l1ll1llll1l1_ek_,l1ll1111l1l1_ek_)
            if href and title:
                l11l1lll1l1_ek_ = urljoin(l1l11l1l1_ek_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡰࡺࡩ࡭ࡱࡳ࠮ࡱ࡮ࠪஅ"),l11l1lll1l1_ek_.group(1)) if l11l1lll1l1_ek_ else l1l11l1l1_ek_ (u"ࠪࠫஆ")
                title = title.group(1)
                year =  re.findall(l1l11l1l1_ek_ (u"ࠫࡡ࠮ࠨ࡝ࡦࡾ࠸ࢂ࠯࡜ࠪࠩஇ"),title)
                l1l1llll1l1_ek_ = {l1l11l1l1_ek_ (u"ࠬ࡮ࡲࡦࡨࠪஈ")   : href.group(1),
                       l1l11l1l1_ek_ (u"࠭ࡴࡪࡶ࡯ࡩࠬஉ")  : l111llll1l1_ek_(title),
                       l1l11l1l1_ek_ (u"ࠧࡪ࡯ࡪࠫஊ")    : l11l1lll1l1_ek_,
                       l1l11l1l1_ek_ (u"ࠨࡲ࡯ࡳࡹ࠭஋")   : l111llll1l1_ek_(l11lllll1l1_ek_),
                       l1l11l1l1_ek_ (u"ࠩࡼࡩࡦࡸࠧ஌")   : year[0] if year else l1l11l1l1_ek_ (u"ࠪࠫ஍"),
                       l1l11l1l1_ek_ (u"ࠫࡨࡵࡤࡦࠩஎ")   : code,
                        }
                out.append(l1l1llll1l1_ek_)
        l1lll1lll1l1_ek_=False
        l1l1l1ll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࡝ࡡࠦࡢ࠰ࠩࠣࡀ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢ࡯ࡧࡻࡸࡤࡹࡩࡵࡧࠥࡂࡕࡵࡰࡳࡼࡨࡨࡳ࡯ࡡ࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡣࡁࠫஏ"),content)
        l1l1l1ll1l1_ek_ = l1l1l1ll1l1_ek_[0] if l1l1l1ll1l1_ek_ else False
        l1lll1lll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࡞ࡢࠧࡣࠪࠪࠤࡁࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡰࡨࡼࡹࡥࡳࡪࡶࡨࠦࡃࡔࡡࡴࡶ࠱࠯ࡵࡴࡡ࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡣࡁࠫஐ"),content)
        l1lll1lll1l1_ek_ = l1lll1lll1l1_ek_[0] if l1lll1lll1l1_ek_ else False
        return (out, (l1l1l1ll1l1_ek_,l1lll1lll1l1_ek_))
    @staticmethod
    def l1111l1l1l1_ek_():
        content = l1111lll1l1_ek_(l1l11l1l1_ek_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡧࡵࡸࡧ࡫࡯ࡱ࠳ࡶ࡬࠰࡭ࡲࡲࡹࡧ࡫ࡵࠩ஑"))
        l111ll1l1l1_ek_=re.findall(l1l11l1l1_ek_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠴ࡱࡡࡵࡣ࡯ࡳ࡬࠵࠮ࠫࠫࠥࠤࡨࡲࡡࡴࡵࡀࠦࡳࡧࡶࡠ࡮࡬ࡲࡰࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪஒ"),content)
        out=[]
        for href,name in l111ll1l1l1_ek_:
            out.append({l1l11l1l1_ek_ (u"ࠩ࡫ࡶࡪ࡬ࠧஓ"):href,l1l11l1l1_ek_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩஔ"):name})
        return out
    @staticmethod
    def l11l11ll1l1_ek_(url):
        url = urljoin(l1l11l1l1_ek_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡲࡼ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭க"),url)
        content = l1111lll1l1_ek_(url)
        l111l1ll1l1_ek_=l1l11l1l1_ek_ (u"ࠬ࠭஖")
        l1l11l1l1l1_ek_=re.findall(l1l11l1l1_ek_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡩࡧࡴࡤࡱࡪࡄࠧ஗"),content,re.DOTALL|re.IGNORECASE)
        if l1l11l1l1l1_ek_:
            l111l1ll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ஘"),l1l11l1l1l1_ek_[0],re.DOTALL|re.IGNORECASE)
            l111l1ll1l1_ek_ = l111l1ll1l1_ek_[0] if l111l1ll1l1_ek_ else l1l11l1l1_ek_ (u"ࠨࠩங")
        return l111l1ll1l1_ek_
