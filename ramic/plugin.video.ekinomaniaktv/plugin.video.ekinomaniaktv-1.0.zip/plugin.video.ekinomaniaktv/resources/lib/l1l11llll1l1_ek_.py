# -*- coding: utf-8 -*-
import sys
l111l1l1_ek_ = sys.version_info [0] == 2
l111ll1l1_ek_ = 2048
l1l1ll1l1_ek_ = 7
def l1l11l1l1_ek_ (keyedStringLiteral):
	global l1llll1l1_ek_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l1l1_ek_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll1l1_ek_ - (charIndex + stringNr) % l1l1ll1l1_ek_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll1l1_ek_ - (charIndex + stringNr) % l1l1ll1l1_ek_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os,json,base64
import cookielib
from urlparse import urlparse,urljoin
l1l1l11l1l1_ek_ = 15
l1l1ll1ll1l1_ek_=l1l11l1l1_ek_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠶࠯࠳࠾ࠤ࡜࡯࡮࠷࠶࠾ࠤࡽ࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠶࠲࠰࠳࠲࠸࠷࠶࠴࠰࠴࠴࠵ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ऺ")
l1llll1ll1l1_ek_=l1l11l1l1_ek_ (u"ࡶࠬ࡫࡫ࡪࡰࡲࡱࡦࡴࡩࡢ࡭࠱ࡧࡴࡵ࡫ࡪࡧࠪऻ")
class l1ll11l1l1l1_ek_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
def l1111lll1l1_ek_(url,data=None):
    l1ll111l1l1_ek_ = cookielib.LWPCookieJar()
    if data:
        opener = urllib2.build_opener(l1ll11l1l1l1_ek_, urllib2.HTTPCookieProcessor(l1ll111l1l1_ek_))
    else:
        opener = urllib2.build_opener( urllib2.HTTPCookieProcessor(l1ll111l1l1_ek_))
    opener.addheaders = [(l1l11l1l1_ek_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ़ࠩ"), l1l1ll1ll1l1_ek_)]
    try:
        response = opener.open(url,data,l1l1l11l1l1_ek_)
        result= response.read()
        response.close()
    except:
        result=l1llll11l1l1_ek_ = e.read()
    return result
def l111llll1l1_ek_(l1l111ll1l1_ek_):
    if isinstance(l1l111ll1l1_ek_, unicode):
        l1l111ll1l1_ek_ = l1l111ll1l1_ek_.encode(l1l11l1l1_ek_ (u"࠭ࡵࡵࡨ࠰࠼ࠬऽ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠧࠧ࡮ࡷ࠿ࡧࡸ࠯ࠧࡩࡷ࠿ࠬा"),l1l11l1l1_ek_ (u"ࠨࠢࠪि"))
    s=l1l11l1l1_ek_ (u"ࠩࡍ࡭ࡓࡩ࡚ࡄࡵ࠺ࠫी")
    l1l111ll1l1_ek_ = re.sub(s.decode(l1l11l1l1_ek_ (u"ࠪࡦࡦࡹࡥ࠷࠶ࠪु")),l1l11l1l1_ek_ (u"ࠫࠬू"),l1l111ll1l1_ek_)
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠬࡢ࡮ࠨृ"),l1l11l1l1_ek_ (u"࠭ࠧॄ")).replace(l1l11l1l1_ek_ (u"ࠧ࡝ࡴࠪॅ"),l1l11l1l1_ek_ (u"ࠨࠩॆ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠩࠩࡲࡧࡹࡰ࠼ࠩे"),l1l11l1l1_ek_ (u"ࠪࠫै"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠫࠫࡷࡵࡰࡶ࠾ࠫॉ"),l1l11l1l1_ek_ (u"ࠬࠨࠧॊ")).replace(l1l11l1l1_ek_ (u"࠭ࠦࡢ࡯ࡳ࠿ࡶࡻ࡯ࡵ࠽ࠪो"),l1l11l1l1_ek_ (u"ࠧࠣࠩौ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠨࠨࡲࡥࡨࡻࡴࡦ࠽्ࠪ"),l1l11l1l1_ek_ (u"ࣶࠩࠫॎ")).replace(l1l11l1l1_ek_ (u"ࠪࠪࡔࡧࡣࡶࡶࡨ࠿ࠬॏ"),l1l11l1l1_ek_ (u"ࠫࣘ࠭ॐ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠬࠬࡡ࡮ࡲ࠾ࡳࡦࡩࡵࡵࡧ࠾ࠫ॑"),l1l11l1l1_ek_ (u"࠭ࣳࠨ॒")).replace(l1l11l1l1_ek_ (u"ࠧࠧࡣࡰࡴࡀࡕࡡࡤࡷࡷࡩࡀ࠭॓"),l1l11l1l1_ek_ (u"ࠨࣕࠪ॔"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠩࠩࡥࡲࡶ࠻ࠨॕ"),l1l11l1l1_ek_ (u"ࠪࠪࠬॖ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠫࡡࡻ࠰࠲࠲࠸ࠫॗ"),l1l11l1l1_ek_ (u"ࠬऋࠧक़")).replace(l1l11l1l1_ek_ (u"࠭࡜ࡶ࠲࠴࠴࠹࠭ख़"),l1l11l1l1_ek_ (u"ࠧअࠩग़"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠨ࡞ࡸ࠴࠶࠶࠷ࠨज़"),l1l11l1l1_ek_ (u"ࠩऊࠫड़")).replace(l1l11l1l1_ek_ (u"ࠪࡠࡺ࠶࠱࠱࠸ࠪढ़"),l1l11l1l1_ek_ (u"ࠫऋ࠭फ़"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠬࡢࡵ࠱࠳࠴࠽ࠬय़"),l1l11l1l1_ek_ (u"࠭ङࠨॠ")).replace(l1l11l1l1_ek_ (u"ࠧ࡝ࡷ࠳࠵࠶࠾ࠧॡ"),l1l11l1l1_ek_ (u"ࠨचࠪॢ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠩ࡟ࡹ࠵࠷࠴࠳ࠩॣ"),l1l11l1l1_ek_ (u"ࠪॆࠬ।")).replace(l1l11l1l1_ek_ (u"ࠫࡡࡻ࠰࠲࠶࠴ࠫ॥"),l1l11l1l1_ek_ (u"ࠬेࠧ०"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"࠭࡜ࡶ࠲࠴࠸࠹࠭१"),l1l11l1l1_ek_ (u"ࠧॅࠩ२")).replace(l1l11l1l1_ek_ (u"ࠨ࡞ࡸ࠴࠶࠺࠴ࠨ३"),l1l11l1l1_ek_ (u"ࠩॆࠫ४"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠪࡠࡺ࠶࠰ࡧ࠵ࠪ५"),l1l11l1l1_ek_ (u"ࠫࣸ࠭६")).replace(l1l11l1l1_ek_ (u"ࠬࡢࡵ࠱࠲ࡧ࠷ࠬ७"),l1l11l1l1_ek_ (u"࣓࠭ࠨ८"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠧ࡝ࡷ࠳࠵࠺ࡨࠧ९"),l1l11l1l1_ek_ (u"ࠨढ़ࠪ॰")).replace(l1l11l1l1_ek_ (u"ࠩ࡟ࡹ࠵࠷࠵ࡢࠩॱ"),l1l11l1l1_ek_ (u"ࠪफ़ࠬॲ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠫࡡࡻ࠰࠲࠹ࡤࠫॳ"),l1l11l1l1_ek_ (u"ࠬঀࠧॴ")).replace(l1l11l1l1_ek_ (u"࠭࡜ࡶ࠲࠴࠻࠾࠭ॵ"),l1l11l1l1_ek_ (u"ࠧॺࠩॶ"))
    l1l111ll1l1_ek_ = l1l111ll1l1_ek_.replace(l1l11l1l1_ek_ (u"ࠨ࡞ࡸ࠴࠶࠽ࡣࠨॷ"),l1l11l1l1_ek_ (u"ࠩॿࠫॸ")).replace(l1l11l1l1_ek_ (u"ࠪࡠࡺ࠶࠱࠸ࡤࠪॹ"),l1l11l1l1_ek_ (u"ࠫঀ࠭ॺ"))
    return l1l111ll1l1_ek_
class l1l11llll1l1_ek_:
    @staticmethod
    def l1l11ll1l1l1_ek_(id=l1l11l1l1_ek_ (u"ࠧࡺ࡯ࡱ࠯ࡵࡥࡹ࡫ࡤ࠮ࡶࡹ࠱ࡸ࡮࡯ࡸࡵࠥॻ")):
        content = l1111lll1l1_ek_(l1l11l1l1_ek_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡬࡫ࡱࡳࡲࡧ࡮ࡪࡣ࡮࠲ࡹࡼࠧॼ"))
        l1l111l1l1l1_ek_ = True if l1l11l1l1_ek_ (u"ࠧࡵࡸ࠰ࡷ࡭ࡵࡷࡴࠩॽ") in id else False
        IsPlayable = False if l1l111l1l1l1_ek_ else True
        out=[]
        l1l111lll1l1_ek_ = re.compile(l1l11l1l1_ek_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡴࡢࡤ࠰ࡴࡦࡴࡥࠩࡁ࠽ࠤࡦࡩࡴࡪࡸࡨࢀ࠮ࠨࠠࡪࡦࡀࠦࠪࡹࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࡥ࡫ࡹࠤࡸࡺࡹ࡭ࡧࡀࠦࡨࡲࡥࡢࡴࠪॾ")%id,re.DOTALL).findall(content)
        if l1l111lll1l1_ek_:
            l1l111lll1l1_ek_ = l1l111lll1l1_ek_[0]
            ids = [(a.start(), a.end()) for a in re.finditer(l1l11l1l1_ek_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡴ࡯ࡤࡰࡱ࠳ࡩࡵࡧࡰࠦࠬॿ"), l1l111lll1l1_ek_,re.IGNORECASE)]
            ids.append( (-1,-1) )
            for i in range(len(ids[:-1])):
                l1ll11ll1l1_ek_ = l1l111lll1l1_ek_[ ids[i][1]:ids[i+1][0] ]
                href = re.compile(l1l11l1l1_ek_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬঀ"),re.DOTALL).findall(l1ll11ll1l1_ek_)
                title = re.compile(l1l11l1l1_ek_ (u"ࠫࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩঁ"),re.DOTALL).findall(l1ll11ll1l1_ek_)
                l11l1lll1l1_ek_ = re.compile(l1l11l1l1_ek_ (u"ࠬࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨং"),re.DOTALL).findall(l1ll11ll1l1_ek_)
                year = re.compile(l1l11l1l1_ek_ (u"࠭࡜ࠩࠪࠫࡃ࠿࠷࠹ࡽ࠴࠳࠭ࡡࡪࡻ࠳ࡿࠬࡠ࠮࠭ঃ"),re.DOTALL).findall(l1ll11ll1l1_ek_)
                if href and title:
                    l11l1lll1l1_ek_ = l11l1lll1l1_ek_[0] if l11l1lll1l1_ek_ else l1l11l1l1_ek_ (u"ࠧࠨ঄")
                    title = title[0]
                    code=l1l11l1l1_ek_ (u"ࠨࠩঅ")
                    l1l1llll1l1_ek_ = {l1l11l1l1_ek_ (u"ࠩ࡫ࡶࡪ࡬ࠧআ")   : urljoin(l1l11l1l1_ek_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡰ࡯࡮ࡰ࡯ࡤࡲ࡮ࡧ࡫࠯ࡶࡹࠫই"),href[0]),
                        l1l11l1l1_ek_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪঈ")  : l111llll1l1_ek_(title),
                        l1l11l1l1_ek_ (u"ࠬ࡯࡭ࡨࠩউ")    : l11l1lll1l1_ek_,
                        l1l11l1l1_ek_ (u"࠭ࡰ࡭ࡱࡷࠫঊ")   : l1l11l1l1_ek_ (u"ࠧࠨঋ"),
                        l1l11l1l1_ek_ (u"ࠨࡻࡨࡥࡷ࠭ঌ")   : year[0] if year else l1l11l1l1_ek_ (u"ࠩࠪ঍"),
                        l1l11l1l1_ek_ (u"ࠪ࡭࡫ࡌ࡯࡭ࡦࡨࡶࠬ঎")   : l1l111l1l1l1_ek_,
                        l1l11l1l1_ek_ (u"ࠫࡎࡹࡐ࡭ࡣࡼࡥࡧࡲࡥࠨএ") : IsPlayable,
                        }
                    out.append(l1l1llll1l1_ek_)
        return out
    @staticmethod
    def l1lllll1l1l1_ek_(url,l11l111l1l1_ek_=None):
        l1l11l11l1l1_ek_ = urljoin(l1l11l1l1_ek_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡫ࡪࡰࡲࡱࡦࡴࡩࡢ࡭࠱ࡸࡻ࠭ঐ"),url) if url.startswith(l1l11l1l1_ek_ (u"࠭࠯ࠨ঑")) else url
        content = l1111lll1l1_ek_(l1l11l11l1l1_ek_)
        l1l111l1l1l1_ek_ = True if l1l11l1l1_ek_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࡵࡸ࠰ࡷ࡭ࡵࡷࡴࠩ঒") in url else False
        IsPlayable = False if l1l111l1l1l1_ek_ else True
        ids = [(a.start(), a.end()) for a in re.finditer(l1l11l1l1_ek_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡳ࡮ࡣ࡯ࡰ࠲࡯ࡴࡦ࡯ࠥࠫও"), content,re.IGNORECASE)]
        ids.append( (-1,-1) )
        out=[]
        for i in range(len(ids[:-1])):
            l1ll11ll1l1_ek_ = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile(l1l11l1l1_ek_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫঔ"),re.DOTALL).findall(l1ll11ll1l1_ek_)
            title = re.compile(l1l11l1l1_ek_ (u"ࠪࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨক"),re.DOTALL).findall(l1ll11ll1l1_ek_)
            l11l1lll1l1_ek_ = re.compile(l1l11l1l1_ek_ (u"ࠫࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧখ"),re.DOTALL).findall(l1ll11ll1l1_ek_)
            year = re.compile(l1l11l1l1_ek_ (u"ࠬࡢࠨࠩࠪࡂ࠾࠶࠿ࡼ࠳࠲ࠬࡠࡩࢁ࠲ࡾࠫ࡟࠭ࠬগ"),re.DOTALL).findall(l1ll11ll1l1_ek_)
            if href and title:
                l11l1lll1l1_ek_ = l11l1lll1l1_ek_[0] if l11l1lll1l1_ek_ else l1l11l1l1_ek_ (u"࠭ࠧঘ")
                title = title[0]
                code=l1l11l1l1_ek_ (u"ࠧࠨঙ")
                l1l1llll1l1_ek_ = {l1l11l1l1_ek_ (u"ࠨࡪࡵࡩ࡫࠭চ")   : urljoin(l1l11l1l1_ek_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨ࡯࡮ࡴ࡯࡮ࡣࡱ࡭ࡦࡱ࠮ࡵࡸࠪছ"),href[0]),
                       l1l11l1l1_ek_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩজ")  : l111llll1l1_ek_(title),
                       l1l11l1l1_ek_ (u"ࠫ࡮ࡳࡧࠨঝ")    : l11l1lll1l1_ek_,
                       l1l11l1l1_ek_ (u"ࠬࡶ࡬ࡰࡶࠪঞ")   : l1l11l1l1_ek_ (u"࠭ࠧট"),
                       l1l11l1l1_ek_ (u"ࠧࡪࡵࡉࡳࡱࡪࡥࡳࠩঠ"): l1l111l1l1l1_ek_,
                       l1l11l1l1_ek_ (u"ࠨࡋࡶࡔࡱࡧࡹࡢࡤ࡯ࡩࠬড"):IsPlayable,
                       l1l11l1l1_ek_ (u"ࠩࡼࡩࡦࡸࠧঢ")   : year[0] if year else l1l11l1l1_ek_ (u"ࠪࠫণ"),
                       l1l11l1l1_ek_ (u"ࠫࡨࡵࡤࡦࠩত")   : code,
                        }
                out.append(l1l1llll1l1_ek_)
        l1l1ll11l1l1_ek_ =re.findall(l1l11l1l1_ek_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠢ࠿࡞ࡶ࠮ࡁࡻ࡬࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬথ"),content)
        l1lll1lll1l1_ek_=False
        l1l1l1ll1l1_ek_=False
        if l1l1ll11l1l1_ek_:
            l1l1ll11l1l1_ek_ = l1l1ll11l1l1_ek_[0]
            l1l1l1ll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"࠭࠼࡭࡫ࠣࡧࡱࡧࡳࡴ࠿ࠥࡴࡷ࡫ࡶࡪࡱࡸࡷࠧࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠩদ"),content)
            l1l1l1ll1l1_ek_ = l1l1l1ll1l1_ek_[0] if l1l1l1ll1l1_ek_ else False
            l1l1l1ll1l1_ek_ = l1l11l11l1l1_ek_.split(l1l11l1l1_ek_ (u"ࠧ࠰ࡲࡤ࡫ࡪ࠭ধ"))[0] if  l1l1l1ll1l1_ek_==l1l11l1l1_ek_ (u"ࠨ࠳ࠪন") else l1l1l1ll1l1_ek_
            l1lll1lll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠩ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠩ঩"),l1l1ll11l1l1_ek_)
            l1lll1lll1l1_ek_ = l1lll1lll1l1_ek_[-1] if l1lll1lll1l1_ek_ else False
        return (out, (l1l1l1ll1l1_ek_,l1lll1lll1l1_ek_))
    @staticmethod
    def l11l1ll1l1_ek_(url):
        l1l11l11l1l1_ek_ = urljoin(l1l11l1l1_ek_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡰ࡯࡮ࡰ࡯ࡤࡲ࡮ࡧ࡫࠯ࡶࡹࠫপ"),url) if url.startswith(l1l11l1l1_ek_ (u"ࠫ࠴࠭ফ")) else url
        content = l1111lll1l1_ek_(l1l11l11l1l1_ek_)
        l1lllllll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠬࡂ࡬ࡪࠢࡦࡰࡦࡹࡳ࠾ࠤࡤࡧࡹ࡯ࡶࡦࠤࡁࡀࡸࡶࡡ࡯ࡀࡖࡩࡿࡵ࡮࠻ࠢࠫࡠࡩ࠱ࠩ࠽࠱ࡶࡴࡦࡴ࠾࠽ࡷ࡯ࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧব"),content,re.DOTALL)
        l11l1lll1l1_ek_ =  re.findall(l1l11l1l1_ek_ (u"࠭࠼ࡥ࡫ࡹࠤࡸࡺࡹ࡭ࡧࡀࠦࡵࡵࡳࡪࡶ࡬ࡳࡳࡀࡲࡦ࡮ࡤࡸ࡮ࡼࡥࠣࡀ࡞ࡠࡸࡢ࡮࡞ࠬ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬভ"),content)
        l11l1lll1l1_ek_ = l11l1lll1l1_ek_[0] if l11l1lll1l1_ek_ else l1l11l1l1_ek_ (u"ࠧࠨম")
        out=[]
        for l11llllll1l1_ek_, data in l1lllllll1l1_ek_:
            l1l1l11ll1l1_ek_ = int(l11llllll1l1_ek_)
            l1ll1ll1l1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠱࠿ࠪ࠾࠲ࡥࡃࡂ࠯࡭࡫ࡁࠫয"),data)
            for href,title in l1ll1ll1l1l1_ek_:
                l1l1l1lll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠩࠫࡠࡩ࠱ࠩࠨর"),title)
                l1l1l1lll1l1_ek_ = int(l1l1l1lll1l1_ek_[0]) if l1l1l1lll1l1_ek_ else l1l11l1l1_ek_ (u"ࠪࠫ঱")
                l1l1llll1l1_ek_ = { l1l11l1l1_ek_ (u"ࠫ࡭ࡸࡥࡧࠩল")  : href,
                    l1l11l1l1_ek_ (u"ࠬࡹࡥࡢࡵࡲࡲࠬ঳") : l1l1l11ll1l1_ek_,
                    l1l11l1l1_ek_ (u"࠭ࡩ࡮ࡩࠪ঴"): l11l1lll1l1_ek_,
                    l1l11l1l1_ek_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࠨ঵") : l1l1l1lll1l1_ek_,
                    l1l11l1l1_ek_ (u"ࠨ࡯ࡨࡨ࡮ࡧࡴࡺࡲࡨࠫশ"): l1l11l1l1_ek_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࠪষ"),
                    l1l11l1l1_ek_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩস") : l111llll1l1_ek_(title)}
                out.append(l1l1llll1l1_ek_)
        return out
    @staticmethod
    def l1lll11ll1l1_ek_(out):
        l1l11lll1l1_ek_={}
        l1lllllll1l1_ek_ = [x.get(l1l11l1l1_ek_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࠫহ")) for x in out]
        for s in set(l1lllllll1l1_ek_):
            l1l11lll1l1_ek_[l1l11l1l1_ek_ (u"࡙ࠬࡥࡻࡱࡱࠤࠪ࠶࠲ࡥࠩ঺")%s]=[out[i] for i, j in enumerate(l1lllllll1l1_ek_) if j == s]
        return l1l11lll1l1_ek_
    @staticmethod
    def l111l1l1l1_ek_(url):
        l1l11l11l1l1_ek_ = urljoin(l1l11l1l1_ek_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡬࡫ࡱࡳࡲࡧ࡮ࡪࡣ࡮࠲ࡹࡼࠧ঻"),url) if url.startswith(l1l11l1l1_ek_ (u"ࠧ࠰়ࠩ")) else url
        content = l1111lll1l1_ek_(l1l11l11l1l1_ek_)
        l1l11l1ll1l1_ek_ = re.findall(l1l11l1l1_ek_ (u"ࠨࡦࡲࡧࡺࡳࡥ࡯ࡶ࠱ࡻࡷ࡯ࡴࡦ࡞ࠫࡷ࡭ࡽࡰ࡝ࠪࠥࠬ࠳࠰࠿ࠪࠤ࡟࠭ࠬঽ"),content)
        if l1l11l1ll1l1_ek_:
            l1l11l1ll1l1_ek_ = l1l11l1ll1l1_ek_[0].replace(l1l11l1l1_ek_ (u"ࠩࠨࠫা"),l1l11l1l1_ek_ (u"ࠪࠫি"))
            l1l11111l1l1_ek_ = l1l11l1l1_ek_ (u"ࠫ࠵࠶࠰࠲࠲࠵࠴࠸࠶࠴࠱࠷࠳࠺࠵࠽࠰࠹࠲࠼࠴ࡦ࠶ࡢ࠱ࡥ࠳ࡨ࠵࡫࠰ࡧ࠳࠳࠵࠶࠷࠲࠲࠵࠴࠸࠶࠻࠱࠷࠳࠺࠵࠽࠷࠹࠲ࡣ࠴ࡦ࠶ࡩ࠱ࡥ࠳ࡨ࠵࡫࠸࠰࠳࠳࠵࠶࠷࠹࠲࠵࠴࠸࠶࠻࠸࠷࠳࠺࠵࠽࠷ࡧ࠲ࡣ࠴ࡦ࠶ࡩ࠸ࡥ࠳ࡨ࠶࠽࠸࠹࠳࠵࠵࠴࠷࠷࠹࠸࠴࠹࠶࠺࠸࠻࠳࠱࠵ࡤ࠷ࡧ࠹ࡣ࠴ࡦ࠶ࡩ࠸࡬࠴࠱࠶࠴࠸࠷࠺࠳࠵࠶࠷࠹࠹࠼࠴࠸࠶࠻࠸࠾࠺ࡡ࠵ࡤ࠷ࡧ࠹ࡪ࠴ࡦ࠶ࡩ࠹࠵࠻࠱࠶࠴࠸࠷࠺࠺࠵࠶࠷࠹࠹࠼࠻࠸࠶࠻࠸ࡥ࠺ࡨ࠵ࡤ࠷ࡧ࠹ࡪ࠻ࡦ࠷࠲࠹࠸࠻࠹࠶࠳࠸࠴࠺࠺࠼࠶࠷࠸࠹࠹࠻࠿࠶ࡢ࠸ࡥ࠺ࡨ࠼ࡤ࠷ࡧ࠹ࡪ࠼࠶࠷࠲࠹࠵࠻࠸࠽࠴࠸࠷࠺࠺࠼࠽࠷࠹࠹࠼࠻ࡦ࠽ࡢ࠸ࡥ࠺ࡨ࠼࡫࠷ࡧ࠺࠳࠼࠶࠾࠲࠹࠵࠻࠸࠽࠻࠸࠷࠺࠺࠼࠽࠾࠹࠹ࡣ࠻ࡦ࠽ࡩ࠸ࡥ࠺ࡨ࠼࡫࠿࠰࠺࠳࠼࠶࠾࠹࠹࠵࠻࠸࠽࠻࠿࠷࠺࠺࠼࠽࠾ࡧ࠹ࡣ࠻ࡦ࠽ࡩ࠿ࡥ࠺ࡨࡤ࠴ࡦ࠷ࡡ࠳ࡣ࠶ࡥ࠹ࡧ࠵ࡢ࠸ࡤ࠻ࡦ࠾ࡡ࠺ࡣࡤࡥࡧࡧࡣࡢࡦࡤࡩࡦ࡬ࡢ࠱ࡤ࠴ࡦ࠷ࡨ࠳ࡣ࠶ࡥ࠹ࡧ࠼ࡢ࠸ࡤ࠻ࡦ࠾ࡨࡡࡣࡤࡥࡧࡧࡪࡢࡦࡤࡩࡧ࠵ࡩ࠱ࡤ࠴ࡦ࠷ࡨ࠺ࡣ࠶ࡥ࠹ࡧ࠼ࡩ࠸ࡤ࠻ࡦࡥࡨࡨࡣࡤࡥࡧࡧࡪࡩࡦࡥ࠲ࡧ࠵ࡩ࠸ࡤ࠴ࡦ࠷ࡨ࠺ࡪ࠶ࡥ࠹ࡧ࠼ࡩ࠿ࡤࡢࡦࡥࡨࡨࡪࡤࡥࡧࡧࡪࡪ࠶ࡥ࠲ࡧ࠵ࡩ࠸࡫࠴ࡦ࠷ࡨ࠺ࡪ࠽ࡥ࠹ࡧ࠼ࡩࡦ࡫ࡢࡦࡥࡨࡨࡪ࡫ࡥࡧࡨ࠳ࡪ࠶࡬࠲ࡧ࠵ࡩ࠸࡫࠻ࡦ࠷ࡨ࠺ࡪ࠽࡬࠹ࡧࡣࡩࡦ࡫ࡩࡦࡥࡨࡨࡪ࡫࠭ী").decode(l1l11l1l1_ek_ (u"ࠬ࡮ࡥࡹࠩু"))
            src = re.findall(l1l11l1l1_ek_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫূ"), l1l11l1ll1l1_ek_.translate(l1l11111l1l1_ek_).decode(l1l11l1l1_ek_ (u"ࠧࡩࡧࡻࠫৃ")))
            if src:
                return src[0]
        return l1l11l1l1_ek_ (u"ࠨࠩৄ")
    @staticmethod
    def l1111l1l1l1_ek_():
        content = l1111lll1l1_ek_(l1l11l1l1_ek_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡰࡺࡩ࡭ࡱࡳ࠮ࡱ࡮࠲࡯ࡴࡴࡴࡢ࡭ࡷࠫ৅"))
        l111ll1l1l1_ek_=re.findall(l1l11l1l1_ek_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠯࡬ࡣࡷࡥࡱࡵࡧ࠰࠰࠭࠭ࠧࠦࡣ࡭ࡣࡶࡷࡂࠨ࡮ࡢࡸࡢࡰ࡮ࡴ࡫ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ৆"),content)
        out=[]
        for href,name in l111ll1l1l1_ek_:
            out.append({l1l11l1l1_ek_ (u"ࠫ࡭ࡸࡥࡧࠩে"):href,l1l11l1l1_ek_ (u"ࠬࡺࡩࡵ࡮ࡨࠫৈ"):name})
        return out
    @staticmethod
    def search(text=l1l11l1l1_ek_ (u"࠭ࡤࡰ࡯ࠪ৉")):
        l1l11l11l1l1_ek_ = l1l11l1l1_ek_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡭࡬ࡲࡴࡳࡡ࡯࡫ࡤ࡯࠳ࡺࡶ࠰ࡣ࡭ࡥࡽ࠵ࡳࡦࡣࡵࡧ࡭ࡅࡳࡦࡣࡵࡧ࡭ࡥࡴࡦࡴࡰࡁࠬ৊")+urllib.quote_plus(text)
        content = l1111lll1l1_ek_(l1l11l11l1l1_ek_)
        l1l1111ll1l1_ek_ =re.findall(l1l11l1l1_ek_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࡠࡸ࠰࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠮ࡃࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࡜ࡴࠬ࠿ࡦࡷ࠭ো"),content,re.DOTALL)
        out=[]
        for l1l1l111l1l1_ek_,l11l1lll1l1_ek_,l1l1l1l1l1l1_ek_ in l1l1111ll1l1_ek_:
            isFolder = True if l1l11l1l1_ek_ (u"ࠩࡷࡺ࠲ࡹࡨࡰࡹࡶࠫৌ") in l1l1l111l1l1_ek_ else False
            IsPlayable = False if isFolder else True
            mode = l1l11l1l1_ek_ (u"ࠪ࡫ࡪࡺࡓࡦࡣࡶࡳࡳࡹ্ࠧ")  if isFolder else l1l11l1l1_ek_ (u"ࠫ࡬࡫ࡴࡍ࡫ࡱ࡯ࠬৎ")
            l1l1llll1l1_ek_ = {l1l11l1l1_ek_ (u"ࠬ࡮ࡲࡦࡨࠪ৏")   : l1l1l111l1l1_ek_,
                    l1l11l1l1_ek_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ৐")  : l111llll1l1_ek_(l1l1l1l1l1l1_ek_.strip()),
                    l1l11l1l1_ek_ (u"ࠧࡪ࡯ࡪࠫ৑")    : l11l1lll1l1_ek_,
                    l1l11l1l1_ek_ (u"ࠨ࡫ࡶࡊࡴࡲࡤࡦࡴࠪ৒"): isFolder,
                    l1l11l1l1_ek_ (u"ࠩࡌࡷࡕࡲࡡࡺࡣࡥࡰࡪ࠭৓"): IsPlayable,
                    l1l11l1l1_ek_ (u"ࠪࡱࡴࡪࡥࠨ৔"):mode,
                    }
            out.append(l1l1llll1l1_ek_)
        return out
