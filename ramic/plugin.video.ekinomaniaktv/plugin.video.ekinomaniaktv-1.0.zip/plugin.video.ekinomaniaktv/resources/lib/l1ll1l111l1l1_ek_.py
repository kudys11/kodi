# -*- coding: utf-8 -*-
import sys
l111l1l1_ek_ = sys.version_info [0] == 2
l111ll1l1_ek_ = 2048
l1l1ll1l1_ek_ = 7
def l1l11l1l1_ek_ (keyedStringLiteral):
	global l1llll1l1_ek_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l1l1_ek_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll1l1_ek_ - (charIndex + stringNr) % l1l1ll1l1_ek_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll1l1_ek_ - (charIndex + stringNr) % l1l1ll1l1_ek_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import sys
from Queue import Queue
from threading import Thread
class l11l1ll11l1l1_ek_(Thread):
    l1l11l1l1_ek_ (u"ࠢࠣࠤࠣࡘ࡭ࡸࡥࡢࡦࠣࡩࡽ࡫ࡣࡶࡶ࡬ࡲ࡬ࠦࡴࡢࡵ࡮ࡷࠥ࡬ࡲࡰ࡯ࠣࡥࠥ࡭ࡩࡷࡧࡱࠤࡹࡧࡳ࡬ࡵࠣࡵࡺ࡫ࡵࡦࠢࠥࠦࠧ౱")
    def __init__(self, l11l1ll1ll1l1_ek_):
        Thread.__init__(self)
        self.l11l1ll1ll1l1_ek_ = l11l1ll1ll1l1_ek_
        self.daemon = True
        self.start()
    def run(self):
        while True:
            func, args, kargs = self.l11l1ll1ll1l1_ek_.get()
            try:
                func(*args, **kargs)
            except Exception as e:
                print(e)
            finally:
                self.l11l1ll1ll1l1_ek_.task_done()
class ThreadPool:
    l1l11l1l1_ek_ (u"ࠣࠤࠥࠤࡕࡵ࡯࡭ࠢࡲࡪࠥࡺࡨࡳࡧࡤࡨࡸࠦࡣࡰࡰࡶࡹࡲ࡯࡮ࡨࠢࡷࡥࡸࡱࡳࠡࡨࡵࡳࡲࠦࡡࠡࡳࡸࡩࡺ࡫ࠠࠣࠤࠥ౲")
    def __init__(self, l11l1lll1l1l1_ek_):
        self.l11l1ll1ll1l1_ek_ = Queue(l11l1lll1l1l1_ek_)
        for _ in range(l11l1lll1l1l1_ek_):
            l11l1ll11l1l1_ek_(self.l11l1ll1ll1l1_ek_)
    def l11l1l1l1l1l1_ek_(self, func, *args, **kargs):
        l1l11l1l1_ek_ (u"ࠤࠥࠦࠥࡇࡤࡥࠢࡤࠤࡹࡧࡳ࡬ࠢࡷࡳࠥࡺࡨࡦࠢࡴࡹࡪࡻࡥࠡࠤࠥࠦ౳")
        self.l11l1ll1ll1l1_ek_.put((func, args, kargs))
    def map(self, func, l11l1l1lll1l1_ek_):
        l1l11l1l1_ek_ (u"ࠥࠦࠧࠦࡁࡥࡦࠣࡥࠥࡲࡩࡴࡶࠣࡳ࡫ࠦࡴࡢࡵ࡮ࡷࠥࡺ࡯ࠡࡶ࡫ࡩࠥࡷࡵࡦࡷࡨࠤࠧࠨࠢ౴")
        for args in l11l1l1lll1l1_ek_:
            self.l11l1l1l1l1l1_ek_(func, args)
    def l11l1l11ll1l1_ek_(self):
        l1l11l1l1_ek_ (u"ࠦࠧࠨࠠࡘࡣ࡬ࡸࠥ࡬࡯ࡳࠢࡦࡳࡲࡶ࡬ࡦࡶ࡬ࡳࡳࠦ࡯ࡧࠢࡤࡰࡱࠦࡴࡩࡧࠣࡸࡦࡹ࡫ࡴࠢ࡬ࡲࠥࡺࡨࡦࠢࡴࡹࡪࡻࡥࠡࠤࠥࠦ౵")
        self.l11l1ll1ll1l1_ek_.join()
