# coding: UTF-8
import sys
l111l1l1_ek_ = sys.version_info [0] == 2
l111ll1l1_ek_ = 2048
l1l1ll1l1_ek_ = 7
def l1l11l1l1_ek_ (keyedStringLiteral):
	global l1llll1l1_ek_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l1l1_ek_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l111ll1l1_ek_ - (charIndex + stringNr) % l1l1ll1l1_ek_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l111ll1l1_ek_ - (charIndex + stringNr) % l1l1ll1l1_ek_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import xbmc,xbmcgui
import time,re,os,threading
try: from shutil import rmtree
except: rmtree = False
def l1ll1l1_ek_(l1111l1l1_ek_,l1lllll1l1_ek_=[l1l11l1l1_ek_ (u"ࠫࠬࠀ")]):
    debug=1
def l1l1l1_ek_(name=l1l11l1l1_ek_ (u"ࠬ࠭ࠁ")):
    debug=1
def l1lll1l1_ek_(top):
    debug=1
def check():
    debug=1
def run():
    try:
        debug=1
    except: pass
