# coding: UTF-8
import sys
l1lll1l_do_ = sys.version_info [0] == 2
l1llll1_do_ = 2048
l111l_do_ = 7
def l1l11ll_do_ (ll_do_):
	global l11l111_do_
	l11111l_do_ = ord (ll_do_ [-1])
	l1ll11l_do_ = ll_do_ [:-1]
	l111_do_ = l11111l_do_ % len (l1ll11l_do_)
	l1lll_do_ = l1ll11l_do_ [:l111_do_] + l1ll11l_do_ [l111_do_:]
	if l1lll1l_do_:
		l11lll1_do_ = unicode () .join ([unichr (ord (char) - l1llll1_do_ - (l111ll_do_ + l11111l_do_) % l111l_do_) for l111ll_do_, char in enumerate (l1lll_do_)])
	else:
		l11lll1_do_ = str () .join ([chr (ord (char) - l1llll1_do_ - (l111ll_do_ + l11111l_do_) % l111l_do_) for l111ll_do_, char in enumerate (l1lll_do_)])
	return eval (l11lll1_do_)
import xbmc,xbmcgui
import time,re,os,threading
try: from shutil import rmtree
except: rmtree = False
def l1l_do_(l1lll1l1_do_,l1l111l_do_=[l1l11ll_do_ (u"ࠨࣲࠩ")]):
    debug=1
def l1l1lll_do_(name=l1l11ll_do_ (u"ࠩࠪࣳ")):
    debug=1
def l1ll1l_do_(top):
    debug=1
def check():
    debug=1
try:
    debug=1
except: pass
