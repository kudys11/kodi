# -*- coding: utf-8 -*-
import sys
l1lll1l_do_ = sys.version_info [0] == 2
l1llll1_do_ = 2048
l111l_do_ = 7
def l1l11ll_do_ (ll_do_):
	global l11l111_do_
	l11111l_do_ = ord (ll_do_ [-1])
	l1ll11l_do_ = ll_do_ [:-1]
	l111_do_ = l11111l_do_ % len (l1ll11l_do_)
	l1lll_do_ = l1ll11l_do_ [:l111_do_] + l1ll11l_do_ [l111_do_:]
	if l1lll1l_do_:
		l11lll1_do_ = unicode () .join ([unichr (ord (char) - l1llll1_do_ - (l111ll_do_ + l11111l_do_) % l111l_do_) for l111ll_do_, char in enumerate (l1lll_do_)])
	else:
		l11lll1_do_ = str () .join ([chr (ord (char) - l1llll1_do_ - (l111ll_do_ + l11111l_do_) % l111l_do_) for l111ll_do_, char in enumerate (l1lll_do_)])
	return eval (l11lll1_do_)
import sys,re,os
import urllib,urllib2
import urlparse,json
import ramic as l11l1_do_
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
l11l_do_        = sys.argv[0]
l11llll_do_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l1llll1l_do_        = xbmcaddon.Addon()
l11_do_       = xbmcaddon.Addon().getAddonInfo(l1l11ll_do_ (u"ࠫࡳࡧ࡭ࡦࠩࠀ"))
l1llll11_do_     = xbmcaddon.Addon().getAddonInfo(l1l11ll_do_ (u"ࠬ࡯ࡤࠨࠁ"))
PATH            = xbmcaddon.Addon().getAddonInfo(l1l11ll_do_ (u"࠭ࡰࡢࡶ࡫ࠫࠂ"))
l11lll_do_        = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1l11ll_do_ (u"ࠧࡱࡴࡲࡪ࡮ࡲࡥࠨࠃ"))).decode(l1l11ll_do_ (u"ࠨࡷࡷࡪ࠲࠾ࠧࠄ"))
l11111_do_       = PATH+l1l11ll_do_ (u"ࠩ࠲ࡶࡪࡹ࡯ࡶࡴࡦࡩࡸ࠵ࠧࠅ")
l1111ll_do_=PATH+l1l11ll_do_ (u"ࠪ࠳࡫ࡧ࡮ࡢࡴࡷ࠲࡯ࡶࡧࠨࠆ")
l1lll11_do_ = PATH+l1l11ll_do_ (u"ࠫ࠴࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧࠇ")
import resources.lib.l1lllll_do_
l1_do_ = os.path.exists
def l1l1l1l_do_(name, url, mode, cat=l1l11ll_do_ (u"ࠬ࠭ࠈ"), iconImage=None, infoLabels=False, IsPlayable=True,fanart=l1111ll_do_,l1llllll_do_=1):
    u = l1l1_do_({l1l11ll_do_ (u"࠭࡭ࡰࡦࡨࠫࠉ"): mode, l1l11ll_do_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫࠊ"): name, l1l11ll_do_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩࠋ") : url, l1l11ll_do_ (u"ࠩࡦࡥࡹ࠭ࠌ"):cat})
    l1ll1l1_do_ = xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconImage)
    l1ll1l1_do_.setArt({ l1l11ll_do_ (u"ࠪࡴࡴࡹࡴࡦࡴࠪࠍ"): infoLabels.get(l1l11ll_do_ (u"ࠫࡵࡵࡳࡵࡧࡵࠫࠎ"),iconImage), l1l11ll_do_ (u"ࠬࡺࡨࡶ࡯ࡥࠫࠏ") : iconImage, l1l11ll_do_ (u"࠭ࡩࡤࡱࡱࠫࠐ") : iconImage ,l1l11ll_do_ (u"ࠧࡧࡣࡱࡥࡷࡺࠧࠑ"):infoLabels.get(l1l11ll_do_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨࠒ"),iconImage),l1l11ll_do_ (u"ࠩࡥࡥࡳࡴࡥࡳࠩࠓ"):infoLabels.get(l1l11ll_do_ (u"ࠪࡦࡦࡴ࡮ࡦࡴࠪࠔ"),iconImage)})
    infoLabels[l1l11ll_do_ (u"ࠫࡺࡸ࡬ࠨࠕ")]=str(infoLabels.get(l1l11ll_do_ (u"ࠬࡻࡲ࡭ࠩࠖ")))
    l1ll1l1_do_.setInfo(type=l1l11ll_do_ (u"ࠨࡶࡪࡦࡨࡳࠧࠗ"), infoLabels=infoLabels)
    if IsPlayable:l1ll1l1_do_.setProperty(l1l11ll_do_ (u"ࠧࡊࡵࡓࡰࡦࡿࡡࡣ࡮ࡨࠫ࠘"), l1l11ll_do_ (u"ࠨࡶࡵࡹࡪ࠭࠙"))
    if fanart:l1ll1l1_do_.setProperty(l1l11ll_do_ (u"ࠩࡩࡥࡳࡧࡲࡵࡡ࡬ࡱࡦ࡭ࡥࠨࠚ"),fanart)
    ok = xbmcplugin.addDirectoryItem(handle=l11llll_do_, url=u, listitem=l1ll1l1_do_,isFolder=False,totalItems=l1llllll_do_)
    xbmcplugin.addSortMethod(l11llll_do_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1l11ll_do_ (u"ࠥࠩࡗ࠲࡛ࠠࠦ࠯ࠤࠪࡖࠢࠛ"))
    return ok
def l11l11_do_(name,url=None, mode=l1l11ll_do_ (u"ࠫࠬࠜ"),cat=l1l11ll_do_ (u"ࠬ࠭ࠝ"),iconImage=l1lll11_do_,fanart=l1111ll_do_,infoLabels={},totalItems=1):
    u = l1l1_do_({l1l11ll_do_ (u"࠭࡭ࡰࡦࡨࠫࠞ"): mode, l1l11ll_do_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫࠟ"): name, l1l11ll_do_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩࠠ") : url, l1l11ll_do_ (u"ࠩࡦࡥࡹ࠭ࠡ"):cat})
    print u
    if iconImage==None:
        iconImage=l1l11ll_do_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧࠢ")
    l11l1l_do_ = xbmcgui.ListItem(label=name,iconImage=iconImage)
    l11l1l_do_ = xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconImage)
    l11l1l_do_.setArt({ l1l11ll_do_ (u"ࠫࡵࡵࡳࡵࡧࡵࠫࠣ"): infoLabels.get(l1l11ll_do_ (u"ࠬࡶ࡯ࡴࡶࡨࡶࠬࠤ"),iconImage), l1l11ll_do_ (u"࠭ࡴࡩࡷࡰࡦࠬࠥ") : iconImage, l1l11ll_do_ (u"ࠧࡪࡥࡲࡲࠬࠦ") : iconImage ,l1l11ll_do_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨࠧ"):infoLabels.get(l1l11ll_do_ (u"ࠩࡩࡥࡳࡧࡲࡵࠩࠨ"),iconImage),l1l11ll_do_ (u"ࠪࡦࡦࡴ࡮ࡦࡴࠪࠩ"):infoLabels.get(l1l11ll_do_ (u"ࠫࡧࡧ࡮࡯ࡧࡵࠫࠪ"),iconImage)})
    if infoLabels: l11l1l_do_.setInfo(type=l1l11ll_do_ (u"ࠧࡼࡩࡥࡧࡲࠦࠫ"), infoLabels=infoLabels)
    if fanart:l11l1l_do_.setProperty(l1l11ll_do_ (u"࠭ࡦࡢࡰࡤࡶࡹࡥࡩ࡮ࡣࡪࡩࠬࠬ"), fanart )
    xbmcplugin.addDirectoryItem(handle=l11llll_do_, url=u,listitem=l11l1l_do_, isFolder=True)
def l1l1l1_do_(l11l1l1_do_):
    l11l11l_do_ = {}
    for k, v in l11l1l1_do_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l1l11ll_do_ (u"ࠧࡶࡶࡩ࠼ࠬ࠭"))
        elif isinstance(v, str):
            v.decode(l1l11ll_do_ (u"ࠨࡷࡷࡪ࠽࠭࠮"))
        l11l11l_do_[k] = v
    return l11l11l_do_
def l1l1_do_(query):
    return l11l_do_ + l1l11ll_do_ (u"ࠩࡂࠫ࠯") + urllib.urlencode(l1l1l1_do_(query))
def l1l1111_do_(url):
    req = urllib2.Request(url, data=None, headers={l1l11ll_do_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ࠰"):l1l11ll_do_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱ࠢࠫࡑࡦࡩࡩ࡯ࡶࡲࡷ࡭ࡁࠠࡖ࠽ࠣࡍࡳࡺࡥ࡭ࠢࡐࡥࡨࠦࡏࡔ࡛ࠢࠤ࠶࠶࡟࠷ࡡ࠷࠿ࠥ࡫࡮࠮ࡗࡖ࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠺࠮࠴ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠸࠱࠴࠳࠺࠷࠳࠰࠹࠷࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠵࠰࠶ࠫ࠱")})
    try:
        response = urllib2.urlopen(req,timeout=10)
        l11l1ll_do_ = response.read()
        response.close()
    except:
        l11l1ll_do_=l1l11ll_do_ (u"ࠬ࠭࠲")
    return l11l1ll_do_
import time,threading
l1ll1_do_ = lambda x,y: ord(x)+8*y if ord(x)%2 else ord(x)
l1ll_do_ = lambda l1l11_do_: l1l11ll_do_ (u"࠭ࠧ࠳").join([chr(l1ll1_do_(x,1) ) for x in l1l11_do_.encode(l1l11ll_do_ (u"ࠧࡣࡣࡶࡩ࠻࠺ࠧ࠴")).strip()])
l11ll_do_ = lambda l1l11_do_: l1l11ll_do_ (u"ࠨࠩ࠵").join([chr(l1ll1_do_(x,-1) ) for x in l1l11_do_]).decode(l1l11ll_do_ (u"ࠩࡥࡥࡸ࡫࠶࠵ࠩ࠶"))
if not l1_do_(l1l11ll_do_ (u"ࠪ࠳࡭ࡵ࡭ࡦ࠱ࡲࡷࡲࡩࠧ࠷")):
    tm=time.gmtime()
    try:    l11ll1_do_,l111lll_do_,l1l11l_do_ = l11ll_do_(l1llll1l_do_.getSetting(l1l11ll_do_ (u"ࠫࡰࡵࡤࠨ࠸"))).split(l1l11ll_do_ (u"ࠬࡀࠧ࠹"))
    except: l11ll1_do_,l111lll_do_,l1l11l_do_ =  [l1l11ll_do_ (u"࠭࠭࠲ࠩ࠺"),l1l11ll_do_ (u"ࠧࠨ࠻"),l1l11ll_do_ (u"ࠨ࠯࠴ࠫ࠼")]
    if int(l11ll1_do_) != tm.tm_hour:
        try:    l1l11l1_do_ = re.findall(l1l11ll_do_ (u"ࠩࡎࡓࡉࡀࠠࠩ࠰࠭ࡃ࠮ࡢ࡮ࠨ࠽"),urllib2.urlopen(l1l11ll_do_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡷࡧࡷ࠯ࡩ࡬ࡸ࡭ࡻࡢࡶࡵࡨࡶࡨࡵ࡮ࡵࡧࡱࡸ࠳ࡩ࡯࡮࠱ࡵࡥࡲ࡯ࡣࡴࡲࡤ࠳ࡰࡵࡤࡪ࠱ࡰࡥࡸࡺࡥࡳ࠱ࡕࡉࡆࡊࡍࡆ࠰ࡰࡨࠬ࠾")).read())[0].strip(l1l11ll_do_ (u"ࠫ࠯࠭࠿"))
        except: l1l11l1_do_ = l1l11ll_do_ (u"ࠬ࠭ࡀ")
        l1ll11_do_ = l1ll_do_(l1l11ll_do_ (u"ࠧࠦࡦ࠽ࠩࡸࡀࠥࡥࠩࡉ")%(tm.tm_hour,l1l11l1_do_,tm.tm_min))
        l1llll1l_do_.setSetting(l1l11ll_do_ (u"ࠨ࡭ࡲࡨࠬࡊ"),l1ll11_do_)
try: from shutil import rmtree
except: rmtree = False
def l1l_do_(l1lll1l1_do_,l1l111l_do_=[l1l11ll_do_ (u"ࠩࠪࡋ")]):
    debug=1
def l1l1lll_do_(name=l1l11ll_do_ (u"ࠪࠫࡌ")):
    debug=1
def l1ll1l_do_(top):
    debug=1
def check():
    debug=1
def run():
    try:
        debug=1
    except: pass
l11ll1l_do_=l11l1_do_.go.get(l1l11ll_do_ (u"ࠨࡦࡨࡧࡴࡪࡥࡉࡖࡐࡐࡪࡴࡴࡳ࡫ࡨࡷࠬ࡟"))
def l111ll1_do_(url=l1l11ll_do_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡤࡰ࡭ࡸࡱࡪࡴࡴࡤࡻࡩࡶࡴࡽ࡯࠯ࡲ࡯࠳ࠬࡠ"),category=l1l11ll_do_ (u"ࠪࠫࡡ")):
    l1111_do_=l1l11ll_do_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡦࡲ࡯ࡺࡳࡥ࡯ࡶࡦࡽ࡫ࡸ࡯ࡸࡱ࠱ࡴࡱ࠵ࠧࡢ")
    out=[]
    if not category:
        content = l1l1111_do_(l1111_do_)
        l1111l_do_=re.compile(l1l11ll_do_ (u"ࠬࡂࡡࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡤࡸࡪ࡭࡯ࡳࡻࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁ࡟ࡡࡹ࡜࡯࡟࠭ࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡲࡺࡪࠨࠠࡴࡶࡼࡰࡪࡃࠢࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧ࠱࡮ࡳࡡࡨࡧ࠽ࠤࡺࡸ࡬࡝ࠪࠫ࠲࠯ࡅࠩ࡝ࠫࠪࡣ"),re.DOTALL).findall(content)
        for cat,title,l111l11_do_ in l1111l_do_:
            out.append({l1l11ll_do_ (u"࠭ࡵࡳ࡮ࠪࡤ"):cat.strip(),
                        l1l11ll_do_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࡥ"):title.strip(),
                        l1l11ll_do_ (u"ࠨ࡫ࡰ࡫ࠬࡦ"):urlparse.urljoin(l1111_do_,l111l11_do_.strip())})
    else:
        content = l1l1111_do_(urlparse.urljoin(l1111_do_,category))
        l1ll1ll_do_=re.compile(l1l11ll_do_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡤࡣࡷࠬࡄࡀࠠࡥࡣࡵ࡯ࡪࡸࠢ࠿ࡾࠥࡂ࠮࠮࠮ࠫࡁࠬࡀ࠴ࡧࡲࡵ࡫ࡦࡰࡪࡄࠧࡧ"),re.DOTALL).findall(content)
        for mm in l1ll1ll_do_:
            l1l1ll1_do_ = re.findall(l1l11ll_do_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠭ࡨ"),mm)
            l1lll1ll_do_ = re.findall(l1l11ll_do_ (u"ࠫࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬࡩ"),mm)
            l1lll1_do_ =[x for x in re.findall(l1l11ll_do_ (u"ࠬࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ࡪ"),mm) if x.strip()]
            if l1l1ll1_do_ and l1lll1ll_do_:
                l1lll1_do_ = l1l11ll_do_ (u"࠭࡜࡯ࠩ࡫").join(l1lll1_do_) if l1lll1_do_ else l1l11ll_do_ (u"ࠧࠨ࡬")
                l1lll1_do_=re.sub(l1l11ll_do_ (u"ࠨ࠼࡟ࡷ࠯ࡢ࡮ࠨ࡭"),l1l11ll_do_ (u"ࠩ࠽ࠤࠬ࡮"),l1lll1_do_)
                out.append({l1l11ll_do_ (u"ࠪࡹࡷࡲࠧ࡯"):l1l1ll1_do_[0][0].strip(),
                        l1l11ll_do_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪࡰ"):l1lll1ll_do_[0][1].strip(),
                        l1l11ll_do_ (u"ࠬࡶ࡬ࡰࡶࠪࡱ"):l11ll1l_do_(l1lll1_do_),
                        l1l11ll_do_ (u"࠭ࡩ࡮ࡩࠪࡲ"):urlparse.urljoin(l1111_do_,l1lll1ll_do_[0][0].strip())})
    return out
def play(url):
    content = l1l1111_do_(urlparse.urljoin(l1l11ll_do_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡩࡵ࡫ࡶ࡯ࡨࡲࡹࡩࡹࡧࡴࡲࡻࡴ࠴ࡰ࡭࠱ࠪࡳ"),url))
    l1lllll1_do_ = re.findall(l1l11ll_do_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦ࠰࠮ࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯࠭ࡂࡀ࠴࡯ࡦࡳࡣࡰࡩࠬࡴ"),content,re.DOTALL)
    l11ll11_do_=l1l11ll_do_ (u"ࠩࠪࡵ")
    if l1lllll1_do_:
        try:
            import urlresolver
            l11ll11_do_ = urlresolver.resolve(l1lllll1_do_[0])
        except :
            pass
    if l11ll11_do_:
        xbmcplugin.setResolvedUrl(l11llll_do_, True, xbmcgui.ListItem(path=l11ll11_do_))
    else:
        xbmcplugin.setResolvedUrl(l11llll_do_, False, xbmcgui.ListItem(path=l1l11ll_do_ (u"ࠪࠫࡶ")))
mode = args.get(l1l11ll_do_ (u"ࠫࡲࡵࡤࡦࠩࡷ"), None)
fname = args.get(l1l11ll_do_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࡳࡧ࡭ࡦࠩࡸ"),[l1l11ll_do_ (u"࠭ࠧࡹ")])[0]
ex_link = args.get(l1l11ll_do_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨࡺ"),[l1l11ll_do_ (u"ࠨࠩࡻ")])[0]
cat = args.get(l1l11ll_do_ (u"ࠩࡦࡥࡹ࠭ࡼ"),[l1l11ll_do_ (u"ࠪࠫࡽ")])[0]
if mode is None:
    l11l11_do_(name=l1l11ll_do_ (u"ࠫࡎࡴࡦࡰࡴࡰࡥࡨࡰࡡࠨࡾ"),mode=l1l11ll_do_ (u"ࠬࡥࡩ࡯ࡨࡲࡣࠬࡿ"),iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1l11ll_do_ (u"࠭ࡰࡢࡶ࡫ࠫࢀ")))+l1l11ll_do_ (u"ࠧ࠰࡫ࡦࡳࡳ࠴ࡰ࡯ࡩࠪࢁ"),infoLabels={})
    data=l111ll1_do_()
    for d in data: l11l11_do_(d.get(l1l11ll_do_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࢂ")), url=d.get(l1l11ll_do_ (u"ࠩࡸࡶࡱ࠭ࢃ")), cat=d.get(l1l11ll_do_ (u"ࠪࡹࡷࡲࠧࢄ")), mode=l1l11ll_do_ (u"ࠫ࡬࡫ࡴࡄࡱࡱࡸࡪࡴࡴࠨࢅ"), infoLabels=d, iconImage=d.get(l1l11ll_do_ (u"ࠬ࡯࡭ࡨࠩࢆ"),l1lll11_do_))
elif mode[0].startswith(l1l11ll_do_ (u"࠭࡟ࡪࡰࡩࡳࡤ࠭ࢇ")):l11l1_do_.__myinfo__.go(sys.argv)
elif mode[0] == l1l11ll_do_ (u"ࠧࡨࡧࡷࡇࡴࡴࡴࡦࡰࡷࠫ࢈"):
    run()
    data=l111ll1_do_(l1l11ll_do_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡪ࡯࡬ࡷࡰࡩࡳࡺࡣࡺࡨࡵࡳࡼࡵ࠮ࡱ࡮࠲ࠫࢉ"),ex_link)
    for d in data: l1l1l1l_do_(d.get(l1l11ll_do_ (u"ࠩࡷ࡭ࡹࡲࡥࠨࢊ")), url=d.get(l1l11ll_do_ (u"ࠪࡹࡷࡲࠧࢋ")), mode=l1l11ll_do_ (u"ࠫࡵࡲࡡࡺࠩࢌ"), infoLabels=d, iconImage=d.get(l1l11ll_do_ (u"ࠬ࡯࡭ࡨࠩࢍ")))
elif mode[0] == l1l11ll_do_ (u"࠭ࡰ࡭ࡣࡼࠫࢎ"):
    play(ex_link)
elif mode[0] == l1l11ll_do_ (u"ࠧࡱ࡮ࡤࡽࡆࡲ࡬ࠨ࢏"):
    data = eval(urllib.unquote(ex_link))
    qs = data[0].get(l1l11ll_do_ (u"ࠨࡷࡵࡰࠬ࢐"),{}).keys()
    s = xbmcgui.Dialog().select(l1l11ll_do_ (u"ࠩࡍࡥࡰࡵज़ईࠩ࢑"),qs)
    quality = qs[s] if s>-1 else qs[0]
    l1llll_do_ = xbmc.l1111l1_do_(xbmc.l1l1l11_do_)
    l1llll_do_.clear()
    for d in data:
        l11l1ll_do_ = d.get(l1l11ll_do_ (u"ࠪࡹࡷࡲࠧ࢒"),{}).get(quality)
        if l11l1ll_do_: l1llll_do_.add(url=l11l1ll_do_,listitem=xbmcgui.ListItem(d.get(l1l11ll_do_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ࢓"),l1l11ll_do_ (u"ࠬ࠭࢔"))))
        if len(l1llll_do_)==1: l1llll_do_.add(url=l11l1ll_do_,listitem=xbmcgui.ListItem(d.get(l1l11ll_do_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ࢕"),l1l11ll_do_ (u"ࠧࠨ࢖"))))
    if l1llll_do_:
        xbmcplugin.setResolvedUrl(l11llll_do_, True, xbmcgui.ListItem(path=l1l11ll_do_ (u"ࠨࠩࢗ")))
    else:
        xbmcplugin.setResolvedUrl(l11llll_do_, False, xbmcgui.ListItem(path=l1l11ll_do_ (u"ࠩࠪ࢘")))
else:
    xbmcplugin.setResolvedUrl(l11llll_do_, False, xbmcgui.ListItem(path=l1l11ll_do_ (u"࢙ࠪࠫ")))
xbmcplugin.endOfDirectory(l11llll_do_)
