# coding: UTF-8
import sys
l1l1ll1_r_ = sys.version_info [0] == 2
l1l1l11ll1_r_ = 2048
l1ll1111ll1_r_ = 7
def l1ll1l11ll1_r_ (ll1ll1_r_):
    global l1l111l1ll1_r_
    l1lll11l1ll1_r_ = ord (ll1ll1_r_ [-1])
    l1lllll1ll1_r_ = ll1ll1_r_ [:-1]
    l1l1l1ll1_r_ = l1lll11l1ll1_r_ % len (l1lllll1ll1_r_)
    l1l111ll1_r_ = l1lllll1ll1_r_ [:l1l1l1ll1_r_] + l1lllll1ll1_r_ [l1l1l1ll1_r_:]
    if l1l1ll1_r_:
        l11lll11ll1_r_ = unicode () .join ([unichr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    else:
        l11lll11ll1_r_ = str () .join ([chr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    return eval (l11lll11ll1_r_)
import urllib2,urllib
import re
import l1l11l11l1ll1_r_
import cookielib
from urlparse import urlparse
l1l111l111ll1_r_=10
l1111l11l1ll1_r_=l1ll1l11ll1_r_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠺࠸࠯࠲࠱࠶࠺࠼࠴࠯࠻࠺ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫ৳")
def l11llllll1ll1_r_(url,data=None,l1l11ll111ll1_r_=None):
    l1111llll1ll1_r_ = cookielib.LWPCookieJar()
    opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1111llll1ll1_r_))
    urllib2.install_opener(opener)
    req = urllib2.Request(url,data)
    req.add_header(l1ll1l11ll1_r_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ৴"), l1ll1l11ll1_r_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠵࠺࠱࠴࠳࠸࠵࠷࠶࠱࠽࠼ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭৵"))
    if l1l11ll111ll1_r_:
        req.add_header(l1ll1l11ll1_r_ (u"ࠤࡆࡳࡴࡱࡩࡦࠤ৶"), l1l11ll111ll1_r_)
    response = urllib2.urlopen(req,timeout=l1l111l111ll1_r_)
    l11lll11l1ll1_r_ =  response.read()
    response.close()
    return l11lll11l1ll1_r_,l1111llll1ll1_r_
def l1lllllll11ll1_r_(l1lllll1111ll1_r_):
    l1llllll1l1ll1_r_ = l1ll1l11ll1_r_ (u"ࠪࠫ৷")
    for match in re.finditer(l1ll1l11ll1_r_ (u"ࠫ࠭࡫ࡶࡢ࡮࡟ࡷ࠯ࡢࠨࡧࡷࡱࡧࡹ࡯࡯࡯࠰࠭ࡃ࠮ࡂ࠯ࡴࡥࡵ࡭ࡵࡺ࠾ࠨ৸"), l1lllll1111ll1_r_, re.DOTALL):
        l1llll1ll11ll1_r_ = l1l11l11l1ll1_r_.unpack(match.group(1))
        l1llll1ll11ll1_r_ = l1llll1ll11ll1_r_.replace(l1ll1l11ll1_r_ (u"ࠬࡢ࡜ࠨ৹"), l1ll1l11ll1_r_ (u"࠭ࠧ৺"))
        l1llllll1l1ll1_r_ += l1llll1ll11ll1_r_
    return l1llllll1l1ll1_r_
def l1llll11l11ll1_r_(url):
    pattern = l1ll1l11ll1_r_ (u"ࠧࠩࡁ࠽࠳࠴ࢂ࡜࠯ࠫࠫࡺࡸ࡮ࡡࡳࡧ࡟࠲࡮ࡵࠩ࠰࡞ࡺࡃ࠴࠮࡜ࡸ࠭ࠬࠫ৻")
    r = re.search(pattern, url, re.I)
    if r:
        return r.groups()
    else:
        return (False,False)
def l1lllll1ll1ll1_r_(host, l11lllll11ll1_r_):
    return l1ll1l11ll1_r_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡸࡶ࡬ࡦࡸࡥ࠯࡫ࡲ࠳ࡻ࠵ࠥࡴ࠱ࡺ࡭ࡩࡺࡨ࠮࠸࠵࠴࠴࡮ࡥࡪࡩ࡫ࡸ࠲࠸࠸࠱࠱ࠪৼ") % l11lllll11ll1_r_
def l1lllll1l11ll1_r_(headers):
    return l1ll1l11ll1_r_ (u"ࠩࡿࠩࡸ࠭৽") % l1ll1l11ll1_r_ (u"ࠪࠪࠬ৾").join([l1ll1l11ll1_r_ (u"ࠫࠪࡹ࠽ࠦࡵࠪ৿") % (key, urllib.quote_plus(headers[key])) for key in headers])
def l11ll1ll11ll1_r_(url):
    l1111lll11ll1_r_=[]
    host, l11lllll11ll1_r_= l1llll11l11ll1_r_(url)
    if l11lllll11ll1_r_:
        l1llll1lll1ll1_r_=l1lllll1ll1ll1_r_(host, l11lllll11ll1_r_)
        content,l1111llll1ll1_r_=l11llllll1ll1_r_(l1llll1lll1ll1_r_)
        l1111l1ll1ll1_r_ = l1ll1l11ll1_r_ (u"ࠬࡁࠧ਀").join([l1ll1l11ll1_r_ (u"࠭ࠥࡴ࠿ࠨࡷࠬਁ")%(c.name,c.value) for c in l1111llll1ll1_r_])
        p = l1lllllll11ll1_r_(content)
        l1llllllll1ll1_r_ = re.findall(l1ll1l11ll1_r_ (u"ࠧࠩ࡞࡞࠲࠯ࡅ࡜࡞ࠫࠪਂ"),p)
        l1llllllll1ll1_r_ = eval(l1llllllll1ll1_r_[0]) if l1llllllll1ll1_r_ else []
        l1llll1l111ll1_r_ = re.findall(l1ll1l11ll1_r_ (u"ࠨࡨࡵࡳࡲࡉࡨࡢࡴࡆࡳࡩ࡫࡜ࠩࡲࡤࡶࡸ࡫ࡉ࡯ࡶ࡟ࠬࡻࡧ࡬ࡶࡧ࡟࠭࠲࠮࡜ࡥ࠭ࠬࡠ࠮࠭ਃ"),p)
        l1llll1l111ll1_r_ = int(l1llll1l111ll1_r_[0]) if l1llll1l111ll1_r_ else 0
        l1l1ll1l11ll1_r_ = l1ll1l11ll1_r_ (u"ࠩࠪ਄")
        for c in l1llllllll1ll1_r_:
            l1l1ll1l11ll1_r_ += chr(c-l1llll1l111ll1_r_)
        l1llll11ll1ll1_r_=re.compile(l1ll1l11ll1_r_ (u"ࠪࡀࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࡞ࡶࡸࡾࡶࡥ࠾ࠤࡹ࡭ࡩ࡫࡯࠰࡯ࡳ࠸ࠧࡢࡳ࡭ࡣࡥࡩࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧਅ")).findall(l1l1ll1l11ll1_r_)
        if l1llll11ll1ll1_r_:
            l1llllll111ll1_r_ = urlparse(l1llll1lll1ll1_r_).scheme
            for url,l11111l1l1ll1_r_ in l1llll11ll1ll1_r_:
                l1llll1l1l1ll1_r_ = urlparse(url).scheme
                l1llll1lll1ll1_r_ = l1llll1lll1ll1_r_.replace(l1llllll111ll1_r_,l1llll1l1l1ll1_r_)
                headers = {l1ll1l11ll1_r_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨਆ"):l1ll1l11ll1_r_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘ࡫ࡱ࠺࠹ࡁࠠࡹ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠹࠵࠳࠶࠮࠴࠳࠹࠷࠳࠷࠰࠱ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩਇ"),
                    l1ll1l11ll1_r_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭ਈ"):l1111l1ll1ll1_r_,l1ll1l11ll1_r_ (u"ࠧࡑࡴࡤ࡫ࡲࡧࠧਉ"):l1ll1l11ll1_r_ (u"ࠨࡰࡲ࠱ࡨࡧࡣࡩࡧࠪਊ"),l1ll1l11ll1_r_ (u"ࠩࡕࡥࡳ࡭ࡥࠨ਋"):l1ll1l11ll1_r_ (u"ࠪࡦࡾࡺࡥࡴ࠿࠳࠱ࠬ਌")}
                l1lllll11l1ll1_r_ = url + l1lllll1l11ll1_r_(headers)
                l1111lll11ll1_r_.append((l11111l1l1ll1_r_,l1lllll11l1ll1_r_))
    return l1111lll11ll1_r_
