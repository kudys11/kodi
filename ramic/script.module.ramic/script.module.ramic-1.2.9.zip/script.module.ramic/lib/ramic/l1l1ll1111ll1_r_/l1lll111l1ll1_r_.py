# -*- coding: utf-8 -*-
import sys
l1l1ll1_r_ = sys.version_info [0] == 2
l1l1l11ll1_r_ = 2048
l1ll1111ll1_r_ = 7
def l1ll1l11ll1_r_ (ll1ll1_r_):
    global l1l111l1ll1_r_
    l1lll11l1ll1_r_ = ord (ll1ll1_r_ [-1])
    l1lllll1ll1_r_ = ll1ll1_r_ [:-1]
    l1l1l1ll1_r_ = l1lll11l1ll1_r_ % len (l1lllll1ll1_r_)
    l1l111ll1_r_ = l1lllll1ll1_r_ [:l1l1l1ll1_r_] + l1lllll1ll1_r_ [l1l1l1ll1_r_:]
    if l1l1ll1_r_:
        l11lll11ll1_r_ = unicode () .join ([unichr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    else:
        l11lll11ll1_r_ = str () .join ([chr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    return eval (l11lll11ll1_r_)
import sys,re,os
import urllib,urllib2
import xbmc,xbmcaddon,xbmcgui
def l111l11ll1ll1_r_(l111llll11ll1_r_):
    return xbmc.getCondVisibility(l1ll1l11ll1_r_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳ࡎࡡࡴࡃࡧࡨࡴࡴࠨࠦࡵࠬࠫথ") % l111llll11ll1_r_) == 1
l111l1lll1ll1_r_=l1ll1l11ll1_r_ (u"࠭ࡳࡤࡴ࡬ࡴࡹ࠴࡭ࡳ࡭ࡱࡳࡼ࠴ࡵࡳ࡮ࡵࡩࡸࡵ࡬ࡷࡧࡵࠫদ")
def rresolver(l11lll11l1ll1_r_,l111ll1l11ll1_r_=True):
    l111l11l11ll1_r_ =l1ll1l11ll1_r_ (u"ࠧࠨধ")
    if not l111l11l11ll1_r_:
        l111l11l11ll1_r_ = l111l1ll11ll1_r_(l11lll11l1ll1_r_)
    if l111ll1l11ll1_r_ and not l111l11l11ll1_r_ and False:
        l111l11l11ll1_r_ = l111l1l111ll1_r_(l11lll11l1ll1_r_)
    return l111l11l11ll1_r_
go = rresolver
def l111l1l111ll1_r_(l11lll11l1ll1_r_):
    l111l11l11ll1_r_ =l1ll1l11ll1_r_ (u"ࠨࠩন")
    if not l111l11ll1ll1_r_(l111l1lll1ll1_r_):
        return l111l11l11ll1_r_
    l111ll1111ll1_r_ = xbmc.translatePath(xbmcaddon.Addon(l111l1lll1ll1_r_).getAddonInfo(l1ll1l11ll1_r_ (u"ࠩࡳࡥࡹ࡮ࠧ঩"))).encode(l1ll1l11ll1_r_ (u"ࠪࡹࡹ࡬࠭࠹ࠩপ"))
    sys.path.insert(1,os.path.join(l111ll1111ll1_r_,l1ll1l11ll1_r_ (u"ࠫࡱ࡯ࡢࠨফ"))  )
    try:
        import urlresolver9 as urlresolver
        l111l111l1ll1_r_ = urlresolver.HostedMediaFile(url=l11lll11l1ll1_r_, include_disabled=True, include_universal=False)
        if l111l111l1ll1_r_.valid_url() == True:
            url = l111l111l1ll1_r_.resolve()
            if url:
                l111l11l11ll1_r_=url
    except:
        pass
    return l111l11l11ll1_r_
def l111l1ll11ll1_r_(l11lll11l1ll1_r_):
    l111l11l11ll1_r_   =l1ll1l11ll1_r_ (u"ࠬ࠭ব")
    if l1ll1l11ll1_r_ (u"࠭ࡰ࡭ࡣࡼࡩࡷࡴࡡࡶࡶࠪভ") in l11lll11l1ll1_r_: l11lll11l1ll1_r_ = l11lll11l1ll1_r_.replace(l1ll1l11ll1_r_ (u"ࠧࡱ࡮ࡤࡽࡪࡸ࡮ࡢࡷࡷࠫম"),l1ll1l11ll1_r_ (u"ࠨࡴࡤࡴࡹࡻࠧয"))
    if l1ll1l11ll1_r_ (u"ࠩࡦࡨࡦ࠴ࡰ࡭ࠩর") in l11lll11l1ll1_r_:
        import l11llll1l1ll1_r_ as l11llll1l1ll1_r_
        l111l11l11ll1_r_ = l11llll1l1ll1_r_.l11ll1ll11ll1_r_(l11lll11l1ll1_r_)
        if isinstance( l111l11l11ll1_r_, list) and list:
            l111lll111ll1_r_ = [x[0] for x in l111l11l11ll1_r_]
            l111lll1l1ll1_r_ = xbmcgui.Dialog().select(l1ll1l11ll1_r_ (u"࡛ࠥࡾࡨࡩࡦࡴࡽࠤ࡯ࡧ࡫ࡰढ़ऊࠤ࠭ࡩࡤࡢࠫࠥ঱"), l111lll111ll1_r_)
            if l111lll1l1ll1_r_>-1:
                l111l11l11ll1_r_ = l11llll1l1ll1_r_.l11ll1ll11ll1_r_(l111l11l11ll1_r_[l111lll1l1ll1_r_][1])
            else:
                l111l11l11ll1_r_=l1ll1l11ll1_r_ (u"ࠫࠬল")
    elif l1ll1l11ll1_r_ (u"ࠬࡸࡡࡱ࡫ࡧࡺ࡮ࡪࡥࡰࠩ঳") in l11lll11l1ll1_r_ or l1ll1l11ll1_r_ (u"࠭ࡲࡢࡲࡷࡹࠬ঴") in l11lll11l1ll1_r_:
        import l111l1l1l1ll1_r_ as l111ll11l1ll1_r_
        l111l11l11ll1_r_ = l111ll11l1ll1_r_.l11ll1ll11ll1_r_(l11lll11l1ll1_r_)
        if type(l111l11l11ll1_r_) is list:
            l111lll111ll1_r_ = [x[0] for x in l111l11l11ll1_r_]
            l111lll1l1ll1_r_ = xbmcgui.Dialog().select(l1ll1l11ll1_r_ (u"ࠢࡘࡻࡥ࡭ࡪࡸࡺࠡ࡬ࡤ࡯ࡴॡइࠡࠪࡵࡥࡵࡺࡵࠪࠤ঵"), l111lll111ll1_r_)
            if l111lll1l1ll1_r_>-1:
                l111l11l11ll1_r_ = l111l11l11ll1_r_[l111lll1l1ll1_r_][1]
            else:
                l111l11l11ll1_r_=l1ll1l11ll1_r_ (u"ࠨࠩশ")
    elif l1ll1l11ll1_r_ (u"ࠩࡹࡷ࡭ࡧࡲࡦࠩষ") in l11lll11l1ll1_r_:
        import l111l11111ll1_r_ as l111ll1ll1ll1_r_
        l111l11l11ll1_r_ = l111ll1ll1ll1_r_.l11ll1ll11ll1_r_(l11lll11l1ll1_r_)
        if l111l11l11ll1_r_ and type(l111l11l11ll1_r_) is list:
            l111lll111ll1_r_ = [x[0] for x in l111l11l11ll1_r_]
            print l111lll111ll1_r_
            l111lll1l1ll1_r_ = xbmcgui.Dialog().select(l1ll1l11ll1_r_ (u"࡛ࠥࡾࡨࡩࡦࡴࡽࠤ࡯ࡧ࡫ࡰढ़ऊࠤ࠭ࡼࡳࡩࡣࡵࡩ࠮ࠨস"), l111lll111ll1_r_)
            if l111lll1l1ll1_r_>-1:
                l111l11l11ll1_r_ = l111l11l11ll1_r_[l111lll1l1ll1_r_][1]
            else:
                l111l11l11ll1_r_=l1ll1l11ll1_r_ (u"ࠫࠬহ")
        else:
            l111l11l11ll1_r_=l1ll1l11ll1_r_ (u"ࠬ࠭঺")
    return l111l11l11ll1_r_
