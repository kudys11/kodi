# -*- coding: utf-8 -*-
import sys
l1l1ll1_r_ = sys.version_info [0] == 2
l1l1l11ll1_r_ = 2048
l1ll1111ll1_r_ = 7
def l1ll1l11ll1_r_ (ll1ll1_r_):
    global l1l111l1ll1_r_
    l1lll11l1ll1_r_ = ord (ll1ll1_r_ [-1])
    l1lllll1ll1_r_ = ll1ll1_r_ [:-1]
    l1l1l1ll1_r_ = l1lll11l1ll1_r_ % len (l1lllll1ll1_r_)
    l1l111ll1_r_ = l1lllll1ll1_r_ [:l1l1l1ll1_r_] + l1lllll1ll1_r_ [l1l1l1ll1_r_:]
    if l1l1ll1_r_:
        l11lll11ll1_r_ = unicode () .join ([unichr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    else:
        l11lll11ll1_r_ = str () .join ([chr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    return eval (l11lll11ll1_r_)
import urllib2,urllib
import re,random,json
import cookielib
import l1l11l11l1ll1_r_
l1l111l111ll1_r_=10
l1111l11l1ll1_r_=l1ll1l11ll1_r_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠱࠰࠳࠲࠷࠼࠶࠲࠰࠴࠴࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭৘")
def l11llllll1ll1_r_(url,data=None,header={},l1111ll1l1ll1_r_=True):
    l1111l1ll1ll1_r_=l1ll1l11ll1_r_ (u"ࠨࠩ৙")
    l1111llll1ll1_r_=[]
    if l1111ll1l1ll1_r_:
        l1111llll1ll1_r_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l1111llll1ll1_r_))
        urllib2.install_opener(opener)
    if not header:
        header = {l1ll1l11ll1_r_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭৚"):l1111l11l1ll1_r_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l1l111l111ll1_r_)
        l11lll11l1ll1_r_ =  response.read()
        response.close()
        l1111l1ll1ll1_r_ = l1ll1l11ll1_r_ (u"ࠪࠫ৛").join([l1ll1l11ll1_r_ (u"ࠫࠪࡹ࠽ࠦࡵ࠾ࠫড়")%(c.name, c.value) for c in l1111llll1ll1_r_])
    except urllib2.HTTPError as e:
        l11lll11l1ll1_r_ = l1ll1l11ll1_r_ (u"ࠬ࠭ঢ়")
    return l11lll11l1ll1_r_,l1111l1ll1ll1_r_
def l11ll1ll11ll1_r_(url):
    l1111lll11ll1_r_=[]
    url=url.replace(l1ll1l11ll1_r_ (u"࠭࠯ࡦ࡯ࡥࡩࡩ࠵ࠧ৞"),l1ll1l11ll1_r_ (u"ࠧ࠰ࡨ࠲ࠫয়")).replace(l1ll1l11ll1_r_ (u"ࠨ࠱ࡨ࠳ࠬৠ"),l1ll1l11ll1_r_ (u"ࠩ࠲ࡪ࠴࠭ৡ"))
    content,c = l11llllll1ll1_r_(url)
    l11111l111ll1_r_ = re.findall(l1ll1l11ll1_r_ (u"ࠪࡸࡾࡶࡥ࠻ࠤࡹ࡭ࡩ࡫࡯࠰࡯ࡳ࠸ࠧ࠲ࡳࡳࡥ࠽ࠦ࠭ࡡ࡞ࠣ࡟࠮࠭ࠧ࠭ৢ"), content)
    if len(l11111l111ll1_r_)==0:
        content,c = l11llllll1ll1_r_(url.replace(l1ll1l11ll1_r_ (u"ࠫ࠴࡬࠯ࠨৣ"),l1ll1l11ll1_r_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠴࠭৤")))
        l11111l111ll1_r_ = re.findall(l1ll1l11ll1_r_ (u"࠭ࡴࡺࡲࡨ࠾ࠧࡼࡩࡥࡧࡲ࠳ࡲࡶ࠴ࠣ࠮ࡶࡶࡨࡀࠢࠩ࡝ࡡࠦࡢ࠱ࠩࠣࠩ৥"), content)
    for source in l11111l111ll1_r_:
        l11111l1l1ll1_r_ = source.split(l1ll1l11ll1_r_ (u"ࠧ࠰ࠩ০"))[-1]
        if not l1ll1l11ll1_r_ (u"ࠨࡪࡷࡸࡵ࠭১") in source:
            source = l1ll1l11ll1_r_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ২") + source
        source = source + l1ll1l11ll1_r_ (u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠧࡶࠫ৩")%(l1111l11l1ll1_r_)
        l1111lll11ll1_r_.append((l11111l1l1ll1_r_,source))
    return l1111lll11ll1_r_
def l111111111ll1_r_(content):
    source = re.search(l1ll1l11ll1_r_ (u"ࠫࠬ࠭ࡳࡳࡥࡨࡷࡡ࠴ࡰࡶࡵ࡫ࡠ࠭ࢁࡴࡺࡲࡨ࠾ࠧࡼࡩࡥࡧࡲ࠳ࡲࡶ࠴ࠣ࠮ࡶࡶࡨࡀ࡜ࡴࠬࠫࠬࡡࡽࠫࠪ࡞ࠫ࠲࠰ࡅ࡜ࠪࠫࠪࠫࠬ৪"), content)
    if source:
        l1l11111l1ll1_r_ = re.search(l1ll1l11ll1_r_ (u"ࠬ࠮ࡥࡷࡣ࡯ࡠࡸ࠰࡜ࠩࡨࡸࡲࡨࡺࡩࡰࡰ࠱࠮ࡄ࠯࠼࠰ࡵࡦࡶ࡮ࡶࡴ࠿ࠩ৫"), content, re.DOTALL | re.I)
        if l1l11111l1ll1_r_:
            l1l11111l1ll1_r_ = l1l11l11l1ll1_r_.unpack(l1l11111l1ll1_r_.group(1))
            l1l11111l1ll1_r_ = re.sub(l1ll1l11ll1_r_ (u"࠭ࡥࡷࡣ࡯ࡠࡸ࠰࡜ࠩ࠰࠭ࡠ࠮࠭৬"), l1ll1l11ll1_r_ (u"ࠧࠨ৭"), l1l11111l1ll1_r_.replace(l1ll1l11ll1_r_ (u"ࠨ࡞࡟ࠫ৮"), l1ll1l11ll1_r_ (u"ࠩࠪ৯")))
            l1111111l1ll1_r_ = l1l11111l1ll1_r_ + l1ll1l11ll1_r_ (u"ࠥ࠿ࠧৰ") + source.group(1) + l1ll1l11ll1_r_ (u"ࠦࡀࠨৱ")
            try: _1111l1111ll1_r_ = l111111ll1ll1_r_.l111111l11ll1_r_(l1111111l1ll1_r_.replace(l1ll1l11ll1_r_ (u"ࠧࡽࡩ࡯ࡦࡲࡻ࠳ࠫࡳࠣ৲") % source.group(2), source.group(2)))
            except Exception as e: raise l11111lll1ll1_r_(e)
