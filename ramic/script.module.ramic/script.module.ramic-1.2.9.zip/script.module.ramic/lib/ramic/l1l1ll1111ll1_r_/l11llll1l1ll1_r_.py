# -*- coding: utf-8 -*-
import sys
l1l1ll1_r_ = sys.version_info [0] == 2
l1l1l11ll1_r_ = 2048
l1ll1111ll1_r_ = 7
def l1ll1l11ll1_r_ (ll1ll1_r_):
    global l1l111l1ll1_r_
    l1lll11l1ll1_r_ = ord (ll1ll1_r_ [-1])
    l1lllll1ll1_r_ = ll1ll1_r_ [:-1]
    l1l1l1ll1_r_ = l1lll11l1ll1_r_ % len (l1lllll1ll1_r_)
    l1l111ll1_r_ = l1lllll1ll1_r_ [:l1l1l1ll1_r_] + l1lllll1ll1_r_ [l1l1l1ll1_r_:]
    if l1l1ll1_r_:
        l11lll11ll1_r_ = unicode () .join ([unichr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    else:
        l11lll11ll1_r_ = str () .join ([chr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    return eval (l11lll11ll1_r_)
l1ll1l11ll1_r_ (u"ࠤࠥࠦࠒࠐࡃࡳࡧࡤࡸࡪࡪࠠࡰࡰࠣࡘ࡭ࡻࠠࡇࡧࡥࠤ࠶࠷ࠠ࠲࠺࠽࠸࠼ࡀ࠴࠴ࠢ࠵࠴࠶࠼ࠍࠋࠏࠍࡄࡦࡻࡴࡩࡱࡵ࠾ࠥࡸࡡ࡮࡫ࡦࠑࠏࠨࠢࠣॎ")
import urllib2
import re
import l1l11l11l1ll1_r_ as l1l11l11l1ll1_r_
l11ll1l111ll1_r_=l1ll1l11ll1_r_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡤࡦࡤ࠲ࡵࡲࠧॏ")
l1l111l111ll1_r_ = 5
def l11llllll1ll1_r_(url,data=None,l1l11ll111ll1_r_=None):
    req = urllib2.Request(url,data)
    req.add_header(l1ll1l11ll1_r_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨॐ"), l1ll1l11ll1_r_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠹࠾࠮࠱࠰࠵࠹࠻࠺࠮࠺࠹ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪ॑"))
    if l1l11ll111ll1_r_:
        req.add_header(l1ll1l11ll1_r_ (u"ࠨࡃࡰࡱ࡮࡭ࡪࠨ॒"), l1l11ll111ll1_r_)
    try:
        response = urllib2.urlopen(req,timeout=l1l111l111ll1_r_)
        l11lll11l1ll1_r_ =  response.read()
        response.close()
    except:
        l11lll11l1ll1_r_=l1ll1l11ll1_r_ (u"ࠧࠨ॓")
    return l11lll11l1ll1_r_
def _11ll1l1l1ll1_r_(content):
    src =l1ll1l11ll1_r_ (u"ࠨࠩ॔")
    l11ll111l1ll1_r_ = re.compile(l1ll1l11ll1_r_ (u"ࠤࡨࡺࡦࡲࠨ࠯ࠬࡂ࠭ࡡࢁ࡜ࡾ࡞ࠬࡠ࠮ࠨॕ"),re.DOTALL).findall(content)
    for l1l11111l1ll1_r_ in l11ll111l1ll1_r_:
        l1l11111l1ll1_r_=re.sub(l1ll1l11ll1_r_ (u"ࠪࠤࠥ࠭ॖ"),l1ll1l11ll1_r_ (u"ࠫࠥ࠭ॗ"),l1l11111l1ll1_r_)
        l1l11111l1ll1_r_=re.sub(l1ll1l11ll1_r_ (u"ࠬࡢ࡮ࠨक़"),l1ll1l11ll1_r_ (u"࠭ࠧख़"),l1l11111l1ll1_r_)
        try:
            l1l11l1111ll1_r_ = l1l11l11l1ll1_r_.unpack(l1l11111l1ll1_r_)
        except:
            l1l11l1111ll1_r_=l1ll1l11ll1_r_ (u"ࠧࠨग़")
        if l1l11l1111ll1_r_:
            l1l11l1111ll1_r_=re.sub(l1ll1l11ll1_r_ (u"ࡳࠩ࡟ࡠࠬज़"),l1ll1l11ll1_r_ (u"ࡴࠪࠫड़"),l1l11l1111ll1_r_)
            l1l111l1l1ll1_r_ = re.compile(l1ll1l11ll1_r_ (u"ࠪ࡟ࠧࡢࠧ࡞ࠬࡩ࡭ࡱ࡫࡛ࠣ࡞ࠪࡡ࠯ࡢࡳࠫ࠼࡟ࡷ࠯ࡡࠢ࡝ࠩࡠࠬ࠳࠱࠿ࠪ࡝ࠥࡠࠬࡣࠬࠨढ़"),  re.DOTALL).search(content)
            l1l111lll1ll1_r_ = re.compile(l1ll1l11ll1_r_ (u"ࠫࡠࠨ࡜ࠨ࡟ࡩ࡭ࡱ࡫࡛ࠣ࡞ࠪࡡ࠿ࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿࡝࠰ࡰࡴ࠹࠯࡛ࠣ࡞ࠪࡡࠬफ़"),  re.DOTALL).search(content)
            l1l111ll11ll1_r_ = re.compile(l1ll1l11ll1_r_ (u"ࠬࡡࠢ࡝ࠩࡠ࠮࠭࠴ࠪࡀ࡞࠱ࡱࡵ࠺ࠩ࡜ࠤ࡟ࠫࡢ࠰ࠧय़"),  re.DOTALL).search(content)
            if l1l111l1l1ll1_r_:   src = l1l111l1l1ll1_r_.group(1)
            elif l1l111lll1ll1_r_: src = l1l111lll1ll1_r_.group(1)
            elif l1l111ll11ll1_r_: src = l1l111ll11ll1_r_.group(1)
            if src:
                break
    return src
def l11lll1111ll1_r_(url):
    pattern = l1ll1l11ll1_r_ (u"࠭ࠨࡀ࠼࠲࠳ࢁࡢ࠮ࠪࠪࡦࡨࡦࡢ࠮ࡱ࡮ࠬ࠳࠭ࡅ࠺࠯࡞ࡧ࠯ࡽࡢࡤࠬࡾࡹ࡭ࡩ࡫࡯ࠪ࠱ࠫ࡟࠵࠳࠹ࡢ࠯ࡽࡅ࠲ࡠ࡝ࠬࠫࠪॠ")
    r = re.search(pattern, url, re.I)
    if r:
        host,l11lllll11ll1_r_=r.groups()
        return l11lllll11ll1_r_
    return False
def l11lll1l11ll1_r_(l11lllll11ll1_r_):
    l1l1111111ll1_r_=l1ll1l11ll1_r_ (u"ࠧࠨॡ")
    content = l11llllll1ll1_r_(l1ll1l11ll1_r_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡦࡩ࠴ࡣࡥࡣ࠱ࡴࡱ࠵࠱࠱࠲ࡻ࠵࠵࠶࠯ࠦࡵ࠲ࡺ࡫࡯࡬࡮ࠩॢ")%l11lllll11ll1_r_)
    l11lll1ll1ll1_r_ = re.findall(l1ll1l11ll1_r_ (u"ࠩࡳࡰࡦࡿࡥࡳࡡࡧࡥࡹࡧ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨॣ"),content,re.DOTALL)
    l11lll1ll1ll1_r_=l11lll1ll1ll1_r_[0] if l11lll1ll1ll1_r_ else l1ll1l11ll1_r_ (u"ࠪࠫ।")
    l1l11l1111ll1_r_ = l11lll1ll1ll1_r_.replace(l1ll1l11ll1_r_ (u"ࠫࠫࡷࡵࡰࡶ࠾ࠫ॥"),l1ll1l11ll1_r_ (u"ࠬࠨࠧ०"))
    l1l111l1l1ll1_r_ = re.compile(l1ll1l11ll1_r_ (u"࡛࠭࡝ࠩࠥࡡ࠯࡬ࡩ࡭ࡧ࡞ࡠࠬࠨ࡝ࠫ࠼࡟ࡷ࠯ࡡ࡜ࠨࠤࡠࠬ࠳࠱࠿ࠪ࡝࡟ࠫࠧࡣࠬࠨ१"),  re.DOTALL).search(l1l11l1111ll1_r_)
    if l1l111l1l1ll1_r_:
        src = l1l111l1l1ll1_r_.group(1)
        l1l1111111ll1_r_ = src.replace(l1ll1l11ll1_r_ (u"ࠢ࡝࡞ࠥ२"), l1ll1l11ll1_r_ (u"ࠣࠤ३"))
    return l1l1111111ll1_r_
def l1l11l1l11ll1_r_(content):
    l1ll1l11ll1_r_ (u"ࠤࠥࠦࠒࠐࠠࠡࠢࠣࡗࡨࡧ࡮ࡴࠢࡩࡳࡷࠦࡶࡪࡦࡨࡳࠥࡲࡩ࡯࡭ࠣ࡭ࡳࡩ࡬ࡶࡦࡨࡨࠥ࡫࡮ࡤࡱࡧࡩࡩࠦ࡯࡯ࡧࠐࠎࠥࠦࠠࠡࠤࠥࠦ४")
    l1l1111111ll1_r_=l1ll1l11ll1_r_ (u"ࠪࠫ५")
    l1l111l1l1ll1_r_ = re.compile(l1ll1l11ll1_r_ (u"ࠫࡠࠨ࡜ࠨ࡟࠭ࡪ࡮ࡲࡥ࡜ࠤ࡟ࠫࡢ࠰࡜ࡴࠬ࠽ࡠࡸ࠰࡛ࠣ࡞ࠪࡡ࠭࠴ࠫࡀࠫ࡞ࠦࡡ࠭࡝࠭ࠩ६"),  re.DOTALL).search(content)
    l1l111lll1ll1_r_ = re.compile(l1ll1l11ll1_r_ (u"ࠬࡡࠢ࡝ࠩࡠࡪ࡮ࡲࡥ࡜ࠤ࡟ࠫࡢࡀ࡛ࠣ࡞ࠪࡡ࠭࠴ࠪࡀ࡞࠱ࡱࡵ࠺ࠩ࡜ࠤ࡟ࠫࡢ࠭७"),  re.DOTALL).search(content)
    l11lll1ll1ll1_r_ = re.findall(l1ll1l11ll1_r_ (u"࠭ࡰ࡭ࡣࡼࡩࡷࡥࡤࡢࡶࡤࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ८"),content,re.DOTALL)
    l11lll1ll1ll1_r_=l11lll1ll1ll1_r_[0] if l11lll1ll1ll1_r_ else l1ll1l11ll1_r_ (u"ࠧࠨ९")
    l1l11l1111ll1_r_ = l11lll1ll1ll1_r_.replace(l1ll1l11ll1_r_ (u"ࠨࠨࡴࡹࡴࡺ࠻ࠨ॰"),l1ll1l11ll1_r_ (u"ࠩࠥࠫॱ"))
    l1l11l1ll1ll1_r_ = re.compile(l1ll1l11ll1_r_ (u"ࠪ࡟ࡡ࠭ࠢ࡞ࠬࡩ࡭ࡱ࡫࡛࡝ࠩࠥࡡ࠯ࡀ࡜ࡴࠬ࡞ࡠࠬࠨ࡝ࠩ࠰࠮ࡃ࠮ࡡ࡜ࠨࠤࡠ࠰ࠬॲ"),  re.DOTALL).search(l1l11l1111ll1_r_)
    if l1l111l1l1ll1_r_:
        print l1ll1l11ll1_r_ (u"ࠫ࡫ࡵࡵ࡯ࡦࠣࡖࡊ࡛ࠦࡧ࡫࡯ࡩ࠿ࡣࠧॳ")
        l1l1111111ll1_r_ = l1l111l1l1ll1_r_.group(1)
    elif l1l111lll1ll1_r_:
        print l1ll1l11ll1_r_ (u"ࠬ࡬࡯ࡶࡰࡧࠤࡗࡋࠠ࡜ࡷࡵࡰ࠿ࡣࠧॴ")
        l1l1111111ll1_r_ = l1l111lll1ll1_r_.group(1)
    elif l1l11l1ll1ll1_r_:
        l1l1111111ll1_r_ = l1l11l1ll1ll1_r_.group(1)
    else:
        print l1ll1l11ll1_r_ (u"࠭ࡥ࡯ࡥࡲࡨࡪࡪࠠ࠻ࠢࡸࡲࡵࡧࡣ࡬ࡧࡵࠫॵ")
        l1l1111111ll1_r_ = _11ll1l1l1ll1_r_(content)
    l1l1111111ll1_r_ = l1l1111111ll1_r_.replace(l1ll1l11ll1_r_ (u"ࠢ࡝࡞ࠥॶ"), l1ll1l11ll1_r_ (u"ࠣࠤॷ"))
    if l1l1111111ll1_r_.startswith(l1ll1l11ll1_r_ (u"ࠩࡸ࡫࡬ࡩࠧॸ")):
        l1l1111ll1ll1_r_ = lambda x: 0 if not x.isalpha() else -13 if l1ll1l11ll1_r_ (u"ࠪࡅࠬॹ") <=x.upper()<=l1ll1l11ll1_r_ (u"ࠫࡒ࠭ॺ") else 13
        l1l1111111ll1_r_ = l1ll1l11ll1_r_ (u"ࠬ࠭ॻ").join([chr((ord(x)-l1l1111ll1ll1_r_(x)) ) for x in l1l1111111ll1_r_])
        l1l1111111ll1_r_=l1l1111111ll1_r_[:-7] + l1l1111111ll1_r_[-4:]
    return l1l1111111ll1_r_
def l11ll1ll11ll1_r_(url):
    l1ll1l11ll1_r_ (u"ࠨࠢࠣࠏࠍࠤࠥࠦࠠࡳࡧࡷࡹࡷࡴࡳࠡࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠲ࠦࡵ࡭ࡴࠣ࡬ࡹࡺࡰ࠻࠱࠲࠲࠳࠴࠮ࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣ࠱ࠥࡵࡲࠡ࡮࡬ࡷࡹࠦ࡯ࡧࠢ࡞ࠬࠬ࠽࠲࠱ࡲࠪ࠰ࠥ࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡧࡩࡧ࠮ࡱ࡮࠲ࡺ࡮ࡪࡥࡰ࠱࠴࠽࠹࠼࠹࠺࠳ࡩࡃࡼ࡫ࡲࡴ࡬ࡤࡁ࠼࠸࠰ࡱࠩࠬ࠰࠳࠴࠮࡞ࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠓࠊࠡࠢࠣࠤࠧࠨࠢॼ")
    if not l1ll1l11ll1_r_ (u"ࠧࡦࡤࡧ࠲ࡨࡪࡡ࠯ࡲ࡯ࠫॽ") in url:
       url=l1ll1l11ll1_r_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨࡦࡩ࠴ࡣࡥࡣ࠱ࡴࡱ࠵࠶࠳࠲ࡻ࠷࠻࠾࠯ࠨॾ")+url.split(l1ll1l11ll1_r_ (u"ࠩ࠲ࠫॿ"))[-1]
    l11ll11ll1ll1_r_=l1ll1l11ll1_r_ (u"ࠪࢀࡈࡵ࡯࡬࡫ࡨࡁࡕࡎࡐࡔࡇࡖࡗࡎࡊ࠽࠲ࠨࡕࡩ࡫࡫ࡲࡦࡴࡀ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡹࡧࡴࡪࡥ࠱ࡧࡩࡧ࠮ࡱ࡮࠲ࡪࡱࡵࡷࡱ࡮ࡤࡽࡪࡸ࠯ࡧ࡮ࡤࡷ࡭࠵ࡦ࡭ࡱࡺࡴࡱࡧࡹࡦࡴ࠱ࡧࡴࡳ࡭ࡦࡴࡦ࡭ࡦࡲ࠭࠴࠰࠵࠲࠶࠾࠮ࡴࡹࡩࠫঀ")
    content = l11llllll1ll1_r_(url)
    src=[]
    if not l1ll1l11ll1_r_ (u"ࠫࡄࡽࡥࡳࡵ࡭ࡥࠬঁ") in url:
         l11ll11l11ll1_r_ = re.compile(l1ll1l11ll1_r_ (u"ࠬࡂࡡࠡࡦࡤࡸࡦ࠳ࡱࡶࡣ࡯࡭ࡹࡿ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࠪࡂࡔࡁࡎ࠾࠯ࠬࡂ࠭ࡃ࠮࠿ࡑ࠾ࡔࡂ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ং"), re.DOTALL).findall(content)
         for l1l1111l11ll1_r_ in l11ll11l11ll1_r_:
             l11lll11l1ll1_r_ = re.search(l1ll1l11ll1_r_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬঃ"),l1l1111l11ll1_r_[1]).group(1)
             l11lll11l1ll1_r_ += l11ll1l111ll1_r_ if not l11lll11l1ll1_r_.startswith(l1ll1l11ll1_r_ (u"ࠧࡩࡶࡷࡴࠬ঄")) else l1ll1l11ll1_r_ (u"ࠨࠩঅ")
             l11ll1lll1ll1_r_ = l1l1111l11ll1_r_[2]
             src.insert(0,(l11ll1lll1ll1_r_,l11lll11l1ll1_r_))
    if not src:
        src = l1l11l1l11ll1_r_(content)
        if src:
            src+=l11ll11ll1ll1_r_
    return src
def l11llll111ll1_r_(url,l1l1111l11ll1_r_=0):
    l1ll1l11ll1_r_ (u"ࠤࠥࠦࠒࠐࠠࠡࠢࠣࡶࡪࡺࡵࡳࡰࡶࠤࡺࡸ࡬ࠡࡶࡲࠤࡻ࡯ࡤࡦࡱࠐࠎࠥࠦࠠࠡࠤࠥࠦআ")
    src = l11ll1ll11ll1_r_(url)
    if type(src)==list:
        selected=src[l1l1111l11ll1_r_]
        print l1ll1l11ll1_r_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࠤ࠿࠭ই"),selected[0]
        src = l11ll1ll11ll1_r_(selected[1])
    return src
