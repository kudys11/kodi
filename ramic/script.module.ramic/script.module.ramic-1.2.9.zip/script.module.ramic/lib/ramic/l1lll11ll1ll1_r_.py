# -*- coding: utf-8 -*-
import sys
l1l1ll1_r_ = sys.version_info [0] == 2
l1l1l11ll1_r_ = 2048
l1ll1111ll1_r_ = 7
def l1ll1l11ll1_r_ (ll1ll1_r_):
    global l1l111l1ll1_r_
    l1lll11l1ll1_r_ = ord (ll1ll1_r_ [-1])
    l1lllll1ll1_r_ = ll1ll1_r_ [:-1]
    l1l1l1ll1_r_ = l1lll11l1ll1_r_ % len (l1lllll1ll1_r_)
    l1l111ll1_r_ = l1lllll1ll1_r_ [:l1l1l1ll1_r_] + l1lllll1ll1_r_ [l1l1l1ll1_r_:]
    if l1l1ll1_r_:
        l11lll11ll1_r_ = unicode () .join ([unichr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    else:
        l11lll11ll1_r_ = str () .join ([chr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    return eval (l11lll11ll1_r_)
import xbmc
import xbmcaddon
l1lllllll1ll1_r_               = xbmcaddon.Addon()
def l1lll11ll1ll1_r_(msg):
    if l1ll1l11ll1_r_ (u"ࠪࡸࡷࡻࡥࠨ࣊") in l1lllllll1ll1_r_.getSetting(l1ll1l11ll1_r_ (u"ࠫࡩ࡫ࡢࡶࡩࠪ࣋")):
        xbmc.log(l1ll1l11ll1_r_ (u"ࠬࡃ࠽ࠨ࣌") + l1lllllll1ll1_r_.getAddonInfo(l1ll1l11ll1_r_ (u"࠭࡮ࡢ࡯ࡨࠫ࣍")) + l1ll1l11ll1_r_ (u"ࠧ࠾࠿ࠪ࣎") + msg)
def notify(msg):
    xbmc.executebuiltin(l1ll1l11ll1_r_ (u"ࠨࡐࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠨࠨ࣏") + l1lllllll1ll1_r_.getAddonInfo(l1ll1l11ll1_r_ (u"ࠩࡱࡥࡲ࡫࣐ࠧ")) + l1ll1l11ll1_r_ (u"ࠪ࠰࣑ࠥ࠭") + msg + l1ll1l11ll1_r_ (u"ࠫ࠱ࠦ࠵࠱࠲࠳࠰࣒ࠥ࠭") + l1lllllll1ll1_r_.getAddonInfo(l1ll1l11ll1_r_ (u"ࠬ࡯ࡣࡰࡰ࣓ࠪ")) + l1ll1l11ll1_r_ (u"࠭ࠩࠨࣔ"))
