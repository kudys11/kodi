# -*- coding: utf-8 -*-
import sys
l1l1ll1_r_ = sys.version_info [0] == 2
l1l1l11ll1_r_ = 2048
l1ll1111ll1_r_ = 7
def l1ll1l11ll1_r_ (ll1ll1_r_):
    global l1l111l1ll1_r_
    l1lll11l1ll1_r_ = ord (ll1ll1_r_ [-1])
    l1lllll1ll1_r_ = ll1ll1_r_ [:-1]
    l1l1l1ll1_r_ = l1lll11l1ll1_r_ % len (l1lllll1ll1_r_)
    l1l111ll1_r_ = l1lllll1ll1_r_ [:l1l1l1ll1_r_] + l1lllll1ll1_r_ [l1l1l1ll1_r_:]
    if l1l1ll1_r_:
        l11lll11ll1_r_ = unicode () .join ([unichr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    else:
        l11lll11ll1_r_ = str () .join ([chr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    return eval (l11lll11ll1_r_)
import re
import xbmcaddon,xbmc,xbmcgui
import time
import os
l11ll1111ll1_r_ = xbmcgui.Dialog
l1l111111ll1_r_ = xbmcaddon.Addon
l1llll1l11ll1_r_            = xbmcaddon.Addon()
l11lllll1ll1_r_         = l1llll1l11ll1_r_.getAddonInfo(l1ll1l11ll1_r_ (u"࠭ࡩࡥࠩࣆ"))
l1llll1111ll1_r_       =l1llll1l11ll1_r_.getAddonInfo(l1ll1l11ll1_r_ (u"ࠧ࡯ࡣࡰࡩࠬࣇ"))
l1lll1l111ll1_r_       =l1llll1l11ll1_r_.getAddonInfo(l1ll1l11ll1_r_ (u"ࠨࡲࡤࡸ࡭࠭ࣈ"))
l1lllll111ll1_r_       = l1llll1l11ll1_r_.getAddonInfo(l1ll1l11ll1_r_ (u"ࠩࡹࡩࡷࡹࡩࡰࡰࠪࣉ"))
l1llll11l1ll1_r_   = l1llll1l11ll1_r_.getSetting
l1l11ll11ll1_r_   = l1llll1l11ll1_r_.setSetting
l1lll1l1l1ll1_r_ = xbmc.log
l1lll1ll11ll1_r_ = time.time
l1ll11111ll1_r_ = xbmc.translatePath
l1l111ll1ll1_r_ = re.findall
l1l111l11ll1_r_= re.search
import shutil
l1l1l1l11ll1_r_ = shutil.rmtree
import urllib2
l1l1lll11ll1_r_ = urllib2.urlopen
l1lll1lll1ll1_r_     = os.walk
l1111lll1ll1_r_ = os.path.join
import threading
l111ll1l1ll1_r_ = threading.Thread
