# -*- coding: utf-8 -*-
import sys
l1l1ll1_r_ = sys.version_info [0] == 2
l1l1l11ll1_r_ = 2048
l1ll1111ll1_r_ = 7
def l1ll1l11ll1_r_ (ll1ll1_r_):
    global l1l111l1ll1_r_
    l1lll11l1ll1_r_ = ord (ll1ll1_r_ [-1])
    l1lllll1ll1_r_ = ll1ll1_r_ [:-1]
    l1l1l1ll1_r_ = l1lll11l1ll1_r_ % len (l1lllll1ll1_r_)
    l1l111ll1_r_ = l1lllll1ll1_r_ [:l1l1l1ll1_r_] + l1lllll1ll1_r_ [l1l1l1ll1_r_:]
    if l1l1ll1_r_:
        l11lll11ll1_r_ = unicode () .join ([unichr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    else:
        l11lll11ll1_r_ = str () .join ([chr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    return eval (l11lll11ll1_r_)
import urlparse
import json,urllib2,urllib
import xbmcplugin,xbmcgui,xbmc
l1l11llll1ll1_r_ = xbmc.getLanguage
def l1l1l11ll1ll1_r_(l1l1l11l11ll1_r_,query):
    return l1l1l11l11ll1_r_ + l1ll1l11ll1_r_ (u"ࠨࡁࠪप") + urllib.urlencode(query)
def l1l1l1lll1ll1_r_(argv):
    l1l1l11l11ll1_r_        = argv[0]
    l1l1l111l1ll1_r_    = int(argv[1])
    args            = urlparse.parse_qs(argv[2][1:])
    mode = args.get(l1ll1l11ll1_r_ (u"ࠩࡰࡳࡩ࡫ࠧफ"), None)
    l1l11lll11ll1_r_ = args.get(l1ll1l11ll1_r_ (u"ࠪࡪࡴࡲࡤࡦࡴࡱࡥࡲ࡫ࠧब"),[l1ll1l11ll1_r_ (u"ࠫࠬभ")])[0]
    l1l1l1l111ll1_r_ = args.get(l1ll1l11ll1_r_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭म"),[l1ll1l11ll1_r_ (u"࠭ࠧय")])[0]
    if mode[0] == l1ll1l11ll1_r_ (u"ࠧࡠ࡫ࡱࡪࡴࡥࠧर"):
        url=l1ll1l11ll1_r_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡧࡶ࡮ࡼࡥ࠯ࡩࡲࡳ࡬ࡲࡥ࠯ࡥࡲࡱ࠴ࡻࡣࡀࡧࡻࡴࡴࡸࡴ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࠩ࡭ࡩࡃࠧऱ")
        try:
            if l1ll1l11ll1_r_ (u"ࠩࡓࡳࡱ࡯ࡳࡩࠩल") != l1l11llll1ll1_r_():
                l1l1l1ll11ll1_r_ = json.load(urllib2.urlopen(url+l1ll1l11ll1_r_ (u"ࠪ࠵࠶࠼࠷࡙࠹࠴ࡾࡼࡘࡦࡻ࠷ࡱ࡬࡚ࡾࡉ࠹࡭ࡼࡕ࡬ࡉ࠸ࡄࡪ࠼ࡔࡘࡼࡳࡦࠩळ")))
            else:
                l1l1l1ll11ll1_r_ = json.load(urllib2.urlopen(url+l1ll1l11ll1_r_ (u"ࠫ࠵ࡈ࠰ࡑ࡯࡯࡚ࡎࡾࡹࡨ࡭ࡷࡩࡳࡌࡋࡐࡕ࠴ࡶࡨ࠹ࡅ࠱ࡗࡘ࠴ࠬऴ")))
        except:
            l1l1l1ll11ll1_r_=[{l1ll1l11ll1_r_ (u"ࠬࡺࡩࡵ࡮ࡨࠫव"):l1ll1l11ll1_r_ (u"࠭ࡍࡰॾࡨࠤࡨࡵज़ࠡࡵ࡬झࠥࡺࡵࠡࡲࡲ࡮ࡦࡽࡩࠨश")}]
        for l1l1l11111ll1_r_ in l1l1l1ll11ll1_r_:
            u = l1l1l11ll1ll1_r_(l1l1l11l11ll1_r_,{l1ll1l11ll1_r_ (u"ࠧ࡮ࡱࡧࡩࠬष"): l1ll1l11ll1_r_ (u"ࠨࡡ࡬ࡲ࡫ࡵ࡟ࡵࡺࡷࠫस"), l1ll1l11ll1_r_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭ह"): l1ll1l11ll1_r_ (u"ࠪࠫऺ"), l1ll1l11ll1_r_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬऻ") : l1l1l11111ll1_r_.get(l1ll1l11ll1_r_ (u"ࠬࡶ࡬ࡰࡶ़ࠪ")).encode(l1ll1l11ll1_r_ (u"࠭ࡵࡵࡨ࠰࠼ࠬऽ"))})
            l1l11ll1l1ll1_r_ = xbmcgui.ListItem(l1l1l11111ll1_r_.get(l1ll1l11ll1_r_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ा")))
            l1l11ll1l1ll1_r_.setArt({l1ll1l11ll1_r_ (u"ࠨ࡫ࡦࡳࡳ࠭ि"):l1l1l11111ll1_r_.get(l1ll1l11ll1_r_ (u"ࠩ࡬ࡱ࡬࠭ी")),l1ll1l11ll1_r_ (u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭ु"):l1l1l11111ll1_r_.get(l1ll1l11ll1_r_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫू")),l1ll1l11ll1_r_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࠬृ"):l1l1l11111ll1_r_.get(l1ll1l11ll1_r_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠭ॄ")),l1ll1l11ll1_r_ (u"ࠧࡵࡪࡸࡱࡧ࠭ॅ"):l1l1l11111ll1_r_.get(l1ll1l11ll1_r_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨॆ"))})
            l1l11ll1l1ll1_r_.setInfo(type=l1ll1l11ll1_r_ (u"ࠤ࡙࡭ࡩ࡫࡯ࠣे"), infoLabels=l1l1l11111ll1_r_)
            l1l11ll1l1ll1_r_.setProperty(l1ll1l11ll1_r_ (u"ࠪࡍࡸࡖ࡬ࡢࡻࡤࡦࡱ࡫ࠧै"), l1ll1l11ll1_r_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪॉ"))
            l1l11ll1l1ll1_r_.setProperty(l1ll1l11ll1_r_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࡤ࡯࡭ࡢࡩࡨࠫॊ"),l1l1l11111ll1_r_.get(l1ll1l11ll1_r_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠭ो")))
            xbmcplugin.addDirectoryItem(handle=l1l1l111l1ll1_r_, url=u, listitem=l1l11ll1l1ll1_r_, isFolder=False)
    elif mode[0] == l1ll1l11ll1_r_ (u"ࠧࡠ࡫ࡱࡪࡴࡥࡴࡹࡶࠪौ"):
        try:
            xbmcgui.Dialog().textviewer(l1ll1l11ll1_r_ (u"ࠨࡋࡱࡪࡴ्࠭"), l1l1l1l111ll1_r_)
        except:
            pass
def go(argv):
    l1l1l1lll1ll1_r_(argv)
