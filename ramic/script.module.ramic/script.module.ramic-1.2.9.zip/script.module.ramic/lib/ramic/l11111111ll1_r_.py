# -*- coding: utf-8 -*-
import sys
l1l1ll1_r_ = sys.version_info [0] == 2
l1l1l11ll1_r_ = 2048
l1ll1111ll1_r_ = 7
def l1ll1l11ll1_r_ (ll1ll1_r_):
    global l1l111l1ll1_r_
    l1lll11l1ll1_r_ = ord (ll1ll1_r_ [-1])
    l1lllll1ll1_r_ = ll1ll1_r_ [:-1]
    l1l1l1ll1_r_ = l1lll11l1ll1_r_ % len (l1lllll1ll1_r_)
    l1l111ll1_r_ = l1lllll1ll1_r_ [:l1l1l1ll1_r_] + l1lllll1ll1_r_ [l1l1l1ll1_r_:]
    if l1l1ll1_r_:
        l11lll11ll1_r_ = unicode () .join ([unichr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    else:
        l11lll11ll1_r_ = str () .join ([chr (ord (char) - l1l1l11ll1_r_ - (l1111l1ll1_r_ + l1lll11l1ll1_r_) % l1ll1111ll1_r_) for l1111l1ll1_r_, char in enumerate (l1l111ll1_r_)])
    return eval (l11lll11ll1_r_)
import xbmc,xbmcgui
import time,re,os,threading
try: from shutil import rmtree
except: rmtree = False
l11l11ll1ll1_r_=10
l111llll1ll1_r_ = time.time
l11l11l11ll1_r_ =time.sleep
l1111l111ll1_r_ = xbmc.translatePath
l11l1l1l1ll1_r_ = os.path.exists
l1111lll1ll1_r_ = os.path.join
l111ll1l1ll1_r_ = threading.Thread
l111l1111ll1_r_=3
l11l111l1ll1_r_=4
def l11l1l111ll1_r_(l1lllll1l1ll1_r_,l111ll111ll1_r_=[l1ll1l11ll1_r_ (u"ࠨࠩࢗ")]):
    debug=1
def l1111l1l1ll1_r_(name=l1ll1l11ll1_r_ (u"ࠩࠪ࢘")):
    debug=1
def l111l1ll1ll1_r_(top):
    debug=1
def l11111l11ll1_r_():
    l1lllll1l1ll1_r_ = l1111lll1ll1_r_(l1111l111ll1_r_(l1ll1l11ll1_r_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫࢠ")),l1ll1l11ll1_r_ (u"ࠫࡦࡪࡤࡰࡰࡶࠫࢡ"))
    xbmc.log(l1lllll1l1ll1_r_)
    l11l11111ll1_r_ = l1111lll1ll1_r_(l1111l111ll1_r_(l1ll1l11ll1_r_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱ࡸࡷࡪࡸࡤࡢࡶࡤࠫࢪ")),l1ll1l11ll1_r_ (u"ࠧࡢࡦࡧࡳࡳࡥࡤࡢࡶࡤࠫࢫ"),l1ll1l11ll1_r_ (u"ࠨࡵ࡮࡭ࡳ࠴ࡡࡦࡱࡱ࠲ࡳࡵࡸ࠯࠷ࠪࢬ"),l1ll1l11ll1_r_ (u"ࠩࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡽࡳ࡬ࠨࢭ"))
    l11l11111ll1_r_ = l1111lll1ll1_r_(l1111l111ll1_r_(l1ll1l11ll1_r_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡵࡴࡧࡵࡨࡦࡺࡡࠨࢵ")),l1ll1l11ll1_r_ (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨࢶ"),l1ll1l11ll1_r_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡼࡴࡴࡦ࡭ࡷࡨࡲࡨ࡫ࠧࢷ"),l1ll1l11ll1_r_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬࢸ"))
    l111lll11ll1_r_ = l1111l111ll1_r_(l1ll1l11ll1_r_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭ࢾ"))
    l1lllll1l1ll1_r_ = l1111lll1ll1_r_(l1111l111ll1_r_(l1ll1l11ll1_r_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨࣀ")),l1ll1l11ll1_r_ (u"ࠨࡣࡧࡨࡴࡴࡳࠨࣁ"))
    l111111l1ll1_r_=[l1ll1l11ll1_r_ (u"ࠩࡸࡷࡪࡸࡶࡢࡴ࠱ࡴࡾ࠭ࣂ")]
def l11111ll1ll1_r_(top,l111111l1ll1_r_):
    return False
try: debug=1
except: pass
