# -*- coding: utf-8 -*-
import sys
l1_ef_ = sys.version_info [0] == 2
l1llll_ef_ = 2048
l1l1_ef_ = 7
def l1l1l_ef_ (ll_ef_):
	global l1111_ef_
	l1l1l1_ef_ = ord (ll_ef_ [-1])
	l11ll_ef_ = ll_ef_ [:-1]
	l11_ef_ = l1l1l1_ef_ % len (l11ll_ef_)
	l1ll_ef_ = l11ll_ef_ [:l11_ef_] + l11ll_ef_ [l11_ef_:]
	if l1_ef_:
		l1lll1_ef_ = unicode () .join ([unichr (ord (char) - l1llll_ef_ - (l1ll1_ef_ + l1l1l1_ef_) % l1l1_ef_) for l1ll1_ef_, char in enumerate (l1ll_ef_)])
	else:
		l1lll1_ef_ = str () .join ([chr (ord (char) - l1llll_ef_ - (l1ll1_ef_ + l1l1l1_ef_) % l1l1_ef_) for l1ll1_ef_, char in enumerate (l1ll_ef_)])
	return eval (l1lll1_ef_)
import urllib2,urllib
import os
import re
import base64,json
import cookielib
import l11l11l11_ef_
import random
import l111ll1l1_ef_
try:
    import l11ll11ll_ef_
except:
    pass
l1llll1lll_ef_=l1l1l_ef_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡪ࡬ࡩ࡭࡯ࡼ࠲ࡹࡼ࠯ࠨ৑")
l111l1l11_ef_ = 10
l1lllll111_ef_=l1l1l_ef_ (u"ࠨࠩ৒")
l111llll1_ef_=l1l1l_ef_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠷࠳࠲࠵࠴࠲࠷࠸࠴࠲࠶࠶࠲ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨ৓")
header={
    l1l1l_ef_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ৔"):l111llll1_ef_,
    l1l1l_ef_ (u"ࠫࡍࡵࡳࡵࠩ৕"):l1l1l_ef_ (u"ࠬࡽࡷࡸ࠰ࡨࡪ࡮ࡲ࡭ࡺ࠰ࡷࡺࠬ৖"),
    l1l1l_ef_ (u"࠭ࡕࡱࡩࡵࡥࡩ࡫࠭ࡊࡰࡶࡩࡨࡻࡲࡦ࠯ࡕࡩࡶࡻࡥࡴࡶࡶࠫৗ"):l1l1l_ef_ (u"ࠧ࠲ࠩ৘"),
    l1l1l_ef_ (u"ࠨࡅࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠬ৙"): l1l1l_ef_ (u"ࠩ࡮ࡩࡪࡶ࠭ࡢ࡮࡬ࡺࡪ࠭৚"),
    l1l1l_ef_ (u"ࠪࡅࡨࡩࡥࡱࡶࠪ৛"):l1l1l_ef_ (u"ࠫࡹ࡫ࡸࡵ࠱࡫ࡸࡲࡲࠬࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾࡨࡵ࡯࡯࠯ࡽࡳ࡬࠭ࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࠧড়"),
    }
l1ll1l1l_ef_=l1l1l_ef_ (u"ࡷ࠭ࡣ࠻࡞ࡸࡷࡪࡸࡳ࡝ࡴࡤࡱ࡮ࡩ࡜ࡢࡲࡳࡨࡦࡺࡡ࡝ࡴࡲࡥࡲ࡯࡮ࡨ࡞࡮ࡳࡩ࡯࡜ࡢࡦࡧࡳࡳࡹ࡜ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡥࡧ࡫࡯ࡱࡾࡢࡣࡰࡱ࡮࡭ࡪ࠭ঢ়")
def _1lllll1l1_ef_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l1l1l_ef_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ৞"), l111llll1_ef_)
    if cookies:
        req.add_header(l1l1l_ef_ (u"ࠢࡄࡱࡲ࡯࡮࡫ࠢয়"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l111l1l11_ef_)
        l1lll111_ef_ = response.read()
        response.close()
    except:
        l1lll111_ef_=l1l1l_ef_ (u"ࠨࠩৠ")
    return l1lll111_ef_
def l111111_ef_(url,data=None,header=None):
    cookies=l11l11l11_ef_.l11l1l1ll_ef_(l1ll1l1l_ef_)
    content=_1lllll1l1_ef_(url,data,cookies)
    if not content:
        l11l1lll1_ef_=l11111111_ef_(l1llll1lll_ef_,l1ll1l1l_ef_)
        cookies=l11l11l11_ef_.l11l1l1ll_ef_(l1ll1l1l_ef_)
        content=_1lllll1l1_ef_(url,data,cookies)
        if not content:
            content=_1lllll1l1_ef_(l1lllll111_ef_+url,data,cookies)
    return content
def l11111111_ef_(l1lll111_ef_,l11111l11_ef_):
    l11l1lll1_ef_ = cookielib.LWPCookieJar()
    l1lll111_ef_=l1llll1lll_ef_
    l1111111l_ef_ = l11l11l11_ef_.l11l111ll_ef_(l1lll111_ef_,l11l1lll1_ef_,l111llll1_ef_)
    l11ll1l11_ef_=os.path.dirname(l11111l11_ef_)
    if not os.path.exists(l11ll1l11_ef_):
        os.makedirs(l11ll1l11_ef_)
    if l11l1lll1_ef_:
        l11l1lll1_ef_.save(l11111l11_ef_, ignore_discard = True)
    return l11l1lll1_ef_
def l1llll1_ef_(url,data=None):
    out=[]
    l111l1lll_ef_=l1l1l_ef_ (u"ࠩࠪৡ")
    l1lllll1ll_ef_=l1l1l_ef_ (u"ࠪࠫৢ")
    header[l1l1l_ef_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬৣ")]=url,
    url=url.replace(l1l1l_ef_ (u"ࠬ࡫ࡦࡪ࡮ࡰࡽ࠳ࡴࡥࡵ࠱ࠪ৤"),l1l1l_ef_ (u"࠭ࡥࡧ࡫࡯ࡱࡾ࠴ࡴࡷ࠱ࠪ৥"))
    content = l111111_ef_(url,data)
    items = re.compile(l1l1l_ef_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡲࡩࡴࡶ࠰࡭ࡹ࡫࡭ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ০"),re.DOTALL).findall(content)
    len(items)
    for item in items:
        l1llll11ll_ef_ = re.compile(l1l1l_ef_ (u"ࠨ࠾ࡤࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠳࠰࠿ࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡬ࡸࡱ࡫࡟ࡱ࡮ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ১")).findall(item)
        l1llll11ll_ef_ = re.compile(l1l1l_ef_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡬ࡸࡱ࡫࡟ࡱ࡮ࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ২")).findall(item)
        l1llllllll_ef_ = re.compile(l1l1l_ef_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡺ࡬ࡦࡡࡨࡲࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ৩")).findall(item)
        l111ll111_ef_ = re.compile(l1l1l_ef_ (u"ࠫࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥࡨࡸࡺࠢ࠿ࡍࡤࡸࡪ࡭࡯ࡳ࡫ࡤ࠾ࠥࡂࡡࠡࡶ࡬ࡸࡱ࡫࠽ࠣ࠰࠭ࡃࠧࠦࡨࡳࡧࡩࡁࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭৪")).findall(item)
        l111ll11l_ef_ = re.compile(l1l1l_ef_ (u"ࠬࡂࡰ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡲࡁࠫ৫")).findall(item)
        l1111lll1_ef_ = re.compile(l1l1l_ef_ (u"࠭࠼ࡪ࡯ࡪࠤࡨࡲࡡࡴࡵࡀࠦࡵࡵࡳࡵࡧࡵࠦࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ৬")).findall(item)
        if l1llll11ll_ef_ and l1111lll1_ef_:
            h= l1llll1lll_ef_+l1llll11ll_ef_[0][0]
            t= l1llll11ll_ef_[0][1]
            i= l1l1l_ef_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡪ࡬ࡩ࡭࡯ࡼ࠲ࡹࡼ࠯ࠨ৭")+l1111lll1_ef_[0].replace(l1l1l_ef_ (u"ࠨ࠱ࡶࡱࡦࡲ࡬࠰ࠩ৮"),l1l1l_ef_ (u"ࠩ࠲ࡦ࡮࡭࠯ࠨ৯"))
            d= l111ll111_ef_[0] if l111ll111_ef_ else l1l1l_ef_ (u"ࠪࠫৰ")
            o= l111ll11l_ef_[0] if l111ll11l_ef_ else l1l1l_ef_ (u"ࠫࠬৱ")
            year=l1l1l_ef_ (u"ࠬ࠭৲")
            l1llll11l1_ef_=l1l1l_ef_ (u"࠭ࠧ৳")
            l1llll1ll1_ef_=l1l1l_ef_ (u"ࠧࠨ৴")
            if l1llllllll_ef_:
                year,l1llll11l1_ef_ = l1llllllll_ef_[0].split(l1l1l_ef_ (u"ࠨࡾࠪ৵"))[-1].split(l1l1l_ef_ (u"ࠩ࠯ࠫ৶"))
                l1llll1ll1_ef_=l1llllllll_ef_[0].split(l1l1l_ef_ (u"ࠪࢀࠬ৷"))[0].strip()
                year = year.strip()
                l1llll11l1_ef_ = l1l1l_ef_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤ࡬ࡸࡥࡦࡰࡠࠤࠪࡹࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ৸")%l1llll11l1_ef_.strip()
            out.append({l1l1l_ef_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ৹"):l1111l1l1_ef_(t),l1l1l_ef_ (u"࠭ࡴࡪࡶ࡯ࡩࡤ࡫࡮ࠨ৺"):l1111l1l1_ef_(l1llll1ll1_ef_),l1l1l_ef_ (u"ࠧࡢࡷࡧ࡭ࡴ࠭৻"):l1llll11l1_ef_,l1l1l_ef_ (u"ࠨࡷࡵࡰࠬৼ"):h,l1l1l_ef_ (u"ࠩ࡬ࡱ࡬࠭৽"):i,l1l1l_ef_ (u"ࠪࡽࡪࡧࡲࠨ৾"):year,l1l1l_ef_ (u"ࠫࡵࡲ࡯ࡵࠩ৿"):o})
    l1ll1111_ef_ = re.compile(l1l1l_ef_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ਀"),re.DOTALL).findall(content)
    if l1ll1111_ef_:
        l111l1lll_ef_=re.compile(l1l1l_ef_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂࡡࠬ࡬ࡢࡳࡸࡳࡀࡂ࠯ࡢࡀࠪਁ")).findall(l1ll1111_ef_[0])
        l1lllll1ll_ef_=re.compile(l1l1l_ef_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩਂ")).findall(l1ll1111_ef_[0])
        if l111l1lll_ef_:
            l111l1lll_ef_ = l1llll1lll_ef_ + l111l1lll_ef_[0]
        if l1lllll1ll_ef_:
            l1lllll1ll_ef_ = l1llll1lll_ef_ + l1lllll1ll_ef_[-1]
    return (out, (l111l1lll_ef_,l1lllll1ll_ef_))
def l1l1111l_ef_(l1l1l1l_ef_=l1l1l_ef_ (u"ࠨࡻࡨࡥࡷ࠭ਃ")):
    out=[]
    url=l1l1l_ef_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡥࡧ࡫࡯ࡱࡾ࠴ࡴࡷ࠱ࡩ࡭ࡱࡳࡹ࠯ࡪࡷࡱࡱ࠭਄")
    header[l1l1l_ef_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫਅ")]=url
    content = l111111_ef_(url)
    l1lllllll1_ef_ = re.compile(l1l1l_ef_ (u"ࠫࡁࡻ࡬ࠡࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡲࡺ࡮࡫࠭ࠦࡵࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨਆ")%l1l1l1l_ef_,re.DOTALL).findall(content)
    if l1lllllll1_ef_:
        if l1l1l1l_ef_==l1l1l_ef_ (u"ࠬࡩࡡࡵࠩਇ"):
            l111111l1_ef_ = re.compile(l1l1l_ef_ (u"࠭࠼ࡢࠢࡷ࡭ࡹࡲࡥ࠾ࠤ࠱࠮ࡄࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭ਈ")).findall(l1lllllll1_ef_[0])
            for k in l111111l1_ef_:
                out.append( (l1l1l_ef_ (u"ࠧࠡࠩਉ").join(k[1:]),l1llll1lll_ef_+k[0]) )
        else:
            l111111l1_ef_ = re.compile(l1l1l_ef_ (u"ࠨ࠾ࡤࠤࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠫਊ")).findall(l1lllllll1_ef_[0])
            for k in l111111l1_ef_:
                out.append((k[0],l1llll1lll_ef_+k[1]))
    return out
def l111l1_ef_(l1l111l1_ef_=0):
    out=[]
    url=l1l1l_ef_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡥࡧ࡫࡯ࡱࡾ࠴ࡴࡷ࠱࠲ࡷࡪࡸࡩࡢ࡮ࡨ࠲ࡵ࡮ࡰࡀࡥࡰࡨࡂࡹ࡬ࡪࡵࡷࠪࡵࡧࡧࡦ࠿ࠨࡨࠬ਋")%l1l111l1_ef_
    content = l111111_ef_(url)
    items= re.compile(l1l1l_ef_ (u"ࠪࡀࡦࠦࡴࡪࡶ࡯ࡩࡂࠨ࠮ࠫࡁࠥࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭਌")).findall(content)
    for item in items:
        out.append({l1l1l_ef_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ਍"):l1111l1l1_ef_(item[1]),l1l1l_ef_ (u"ࠬࡻࡲ࡭ࠩ਎"):l1llll1lll_ef_+item[0]})
    return out
def l1l1ll11_ef_(url):
    out=[]
    content = l111111_ef_(url)
    idx = content.find(l1l1l_ef_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦ࡭ࡵ࡬ࡥࡧࡵࠦࡃ࠭ਏ"))
    l1lll1l_ef_ = re.compile(l1l1l_ef_ (u"ࠧ࠽࡮࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨਐ"),re.DOTALL).findall(content[idx:])
    len(l1lll1l_ef_)
    for e in l1lll1l_ef_:
        href=re.compile(l1l1l_ef_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ਑")).findall(e)
        title=re.compile(l1l1l_ef_ (u"ࠩࡁࠬ࠳࠰࠿ࠪ࠾ࠪ਒")).findall(e)
        if href and title:
            h= l1llll1lll_ef_+href[0]
            t=l1l1l_ef_ (u"ࠪࠫਓ").join(title).replace(l1l1l_ef_ (u"ࠫ࠲࠳࠾ࠨਔ"),l1l1l_ef_ (u"ࠬ࠭ਕ")).strip()
            out.append({l1l1l_ef_ (u"࠭ࡴࡪࡶ࡯ࡩࠬਖ"):l1111l1l1_ef_(t),l1l1l_ef_ (u"ࠧࡶࡴ࡯ࠫਗ"):h})
    return out
def l1l1l1l1_ef_(url):
    out=[]
    content = l111111_ef_(url)
    l1llllll11_ef_= re.compile(l1l1l_ef_ (u"ࠨࠪ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃ࠮ࠫࡁ࠿࠳ࡩ࡯ࡶ࠿ࠫࠪਘ"),re.DOTALL).findall(content)
    for item in l1llllll11_ef_:
        l1llll11ll_ef_ = re.compile(l1l1l_ef_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡲ࡯ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨਙ")).findall(item)
        l1llllllll_ef_ = re.compile(l1l1l_ef_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡩࡳࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪਚ")).findall(item)
        l111ll111_ef_ = re.compile(l1l1l_ef_ (u"ࠫࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥࠬࡨࡧࡴࡽࡦࡶࡧ࠮ࠨ࠾࠯ࠬࡂࡀࡦࠦࡴࡪࡶ࡯ࡩࡂࠨ࠮ࠫࡁࠥࠤ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠬ࠳࠰࠿ࠪ࠾ࠪਛ")).findall(item)
        l111ll11l_ef_ = re.compile(l1l1l_ef_ (u"ࠬࡂࡰ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡲࡁࠫਜ")).findall(item)
        l1111lll1_ef_ = re.compile(l1l1l_ef_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫਝ")).findall(item)
        l1llllll1l_ef_={}
        if l1llll11ll_ef_ :
            l1llllll1l_ef_[l1l1l_ef_ (u"ࠧࡶࡴ࡯ࠫਞ")]= l1llll1lll_ef_+l1llll11ll_ef_[0][0]
            l1llllll1l_ef_[l1l1l_ef_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧਟ")]= l1111l1l1_ef_(l1llll11ll_ef_[0][1])
            l1llllll1l_ef_[l1l1l_ef_ (u"ࠩ࡬ࡱ࡬࠭ਠ")]= l1l1l_ef_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡦࡨ࡬ࡰࡲࡿ࠮ࡵࡸ࠲ࠫਡ")+l1111lll1_ef_[0].replace(l1l1l_ef_ (u"ࠫ࠴ࡹ࡭ࡢ࡮࡯࠳ࠬਢ"),l1l1l_ef_ (u"ࠬ࠵ࡢࡪࡩ࠲ࠫਣ")) if l1111lll1_ef_ else l1l1l_ef_ (u"࠭ࠧਤ")
            l1llllll1l_ef_[l1l1l_ef_ (u"ࠧࡺࡧࡤࡶࠬਥ")]=l1l1l_ef_ (u"ࠨࠩਦ")
            if l111ll111_ef_:
                if len(l111ll111_ef_[0])==3:
                    l1llllll1l_ef_[l1l1l_ef_ (u"ࠩࡪࡩࡳࡸࡥࠨਧ")]= l111ll111_ef_[0][1] if l111ll111_ef_ else l1l1l_ef_ (u"ࠪࠫਨ")
                    try:
                        l1llll11l1_ef_,year = l111ll111_ef_[0][-1].split(l1l1l_ef_ (u"ࠫࢁ࠭਩"))[-1].split(l1l1l_ef_ (u"ࠬ࠲ࠧਪ"))
                        l1llllll1l_ef_[l1l1l_ef_ (u"࠭ࡹࡦࡣࡵࠫਫ")] = year.strip()
                        l1llllll1l_ef_[l1l1l_ef_ (u"ࠧࡢࡷࡧ࡭ࡴ࠭ਬ")] = l1l1l_ef_ (u"ࠨࠢ࡞ࡇࡔࡒࡏࡓࠢࡪࡶࡪ࡫࡮࡞ࠢࠨࡷࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧਭ")%l1llll11l1_ef_.strip()
                    except:
                        pass
            l1llllll1l_ef_[l1l1l_ef_ (u"ࠩࡳࡰࡴࡺࠧਮ")]= l111ll11l_ef_[0] if l111ll11l_ef_ else l1l1l_ef_ (u"ࠪࠫਯ")
            if len(l1llllllll_ef_)==2:
                l1llllll1l_ef_[l1l1l_ef_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪਰ")] += l1l1l_ef_ (u"࡛ࠬࠦࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸࡧࡲࡵࡦ࡟ࠨࡷࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭਱") %(l1l1l_ef_ (u"࠭ࠠࠨਲ").join(l1llllllll_ef_))
            out.append(l1llllll1l_ef_)
    return out
def search(l111l111l_ef_=l1l1l_ef_ (u"ࠧࡵࡧࡲࡶ࡮ࡧࠠࡸ࡫ࡨࡰࡰ࡯ࡥࡨࡱࠪਲ਼")):
    url=l1l1l_ef_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡫ࡦࡪ࡮ࡰࡽ࠳ࡺࡶ࠰ࡵࡽࡹࡰࡧࡪ࠯ࡪࡷࡱࡱ࠭਴")
    data=l1l1l_ef_ (u"ࠩࡺࡳࡷࡪ࠽ࠦࡵࠩࡥࡸࡥࡶࡢ࡮ࡸࡩࡸࡥ࡭ࡰࡸ࡬ࡩࡤࡺࡩࡵ࡮ࡨࡁ࡭࡯ࡤࡥࡧࡱࠫਵ") % (l111l111l_ef_.replace(l1l1l_ef_ (u"ࠪࠤࠬਸ਼"),l1l1l_ef_ (u"ࠫ࠰࠭਷")))
    l111ll1ll_ef_=[]
    l111l11ll_ef_=[]
    l111ll1ll_ef_, l1ll1111_ef_ = l1llll1_ef_(url,data)
    return l111ll1ll_ef_, l1ll1111_ef_
def l1l111_ef_(url=l1l1l_ef_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡴࡳࡧࡤࡱ࡮ࡴ࠮ࡵࡱ࠲ࡩࡲࡨࡥࡥ࠯ࡹࡾ࠺ࡾࡱࡤࡼ࡬ࡺࡩࡨ࠸࠯ࡪࡷࡱࡱ࠭ਸ")):
    import l111ll1l1_ef_ as l111ll1l1_ef_
    content=l111111_ef_(url)
    l1llll1l11_ef_ = re.compile(l1l1l_ef_ (u"ࠨࡥࡷࡣ࡯ࠬ࠳࠰࠿࡝ࠫ࡟࠭ࡡ࠯ࠩࠣਹ"),re.DOTALL).findall(content)
    for l1111llll_ef_ in l1llll1l11_ef_:
        l1111llll_ef_=re.sub(l1l1l_ef_ (u"ࠧࠡࠢࠪ਺"),l1l1l_ef_ (u"ࠨࠢࠪ਻"),l1111llll_ef_)
        l1111llll_ef_=re.sub(l1l1l_ef_ (u"ࠩ࡟ࡲ਼ࠬ"),l1l1l_ef_ (u"ࠪࠫ਽"),l1111llll_ef_)
        try:
            l11111lll_ef_ = l111ll1l1_ef_.unpack(l1111llll_ef_)
        except:
            l11111lll_ef_=l1l1l_ef_ (u"ࠫࠬਾ")
        if l11111lll_ef_:
            l1111l11l_ef_=l11111lll_ef_
            try:
                l1l11l1l_ef_ = re.compile(l1l1l_ef_ (u"ࠧ࡬ࡩ࡭ࡧ࡟ࡷ࠯ࡀ࡜ࡴࠬ࡞ࡠࠬࢂ࡜ࠣ࡟ࠫ࡬ࡹࡺࡰ࠯࠭ࡂ࠭ࡠࡢࠧࡽ࡞ࠥࡡࠧਿ")).findall(l1111l11l_ef_)[0]
                r = urllib2.Request(l1l11l1l_ef_, headers={l1l1l_ef_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪੀ"): l111llll1_ef_})
                r = urllib2.urlopen(r, timeout=15).headers[l1l1l_ef_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡎࡨࡲ࡬ࡺࡨࠨੁ")]
                return l1l11l1l_ef_
            except:
                pass
            try:
                l111l1l1l_ef_ = re.search(l1l1l_ef_ (u"ࠨࡵࡷࡶࡪࡧ࡭ࡦࡴ࠽ࡠࡸ࠰ࠢࠩ࡝ࡡࠦࡢ࠱ࠩࠣ࠮ࠪੂ"), l1111l11l_ef_).group(1).replace(l1l1l_ef_ (u"ࠩ࠽࠵࠾࠹࠵ࠨ੃"), l1l1l_ef_ (u"ࠪࠫ੄"))
                l111l1ll1_ef_ = re.search(l1l1l_ef_ (u"ࠫ࡫࡯࡬ࡦ࠼࡟ࡷ࠯ࠨࠨ࡜ࡠࠥࡡ࠰࠯ࠢ࠭ࠩ੅"), l1111l11l_ef_).group(1).replace(l1l1l_ef_ (u"ࠬ࠴ࡦ࡭ࡸࠪ੆"), l1l1l_ef_ (u"࠭ࠧੇ"))
                return l1l1l_ef_ (u"ࠧࠦࡵࠣࡴࡱࡧࡹࡱࡣࡷ࡬ࡂࠫࡳࠨੈ") % (l111l1l1l_ef_, l111l1ll1_ef_)
            except:
                pass
    return l1l1l_ef_ (u"ࠨࠩ੉")
def l1l1llll_ef_(url):
    l111l1111_ef_=[]
    a={}
    content = l111111_ef_(url)
    try:
        exec urllib2.urlopen(l1l1l_ef_ (u"ࠩࡤࡌࡗ࠶ࡣࡉࡏ࠹ࡐࡾ࠿࡫ࡤ࡯࡯࠶࡟࡙࠵࡯ࡤ࠵࠽ࡳࡨࡇࡖࡷ࡜࠶࠾ࡺࡌ࠴ࡘ࡭ࡔ࠷࡜࠴ࡤࡉ࠼ࡽࡩࡊ࠱࡬ࡤ࠶ࡨࡺࡨࡇ࠺ࡪ࡝ࡇ࡟ࡶ࡚ࡅ࠲ࡺࡕ࡯ࡈࡑࡣ࡙ࡻ࡛ࡘ࡞ࡨ࠶࡞ࡱ࡞࠷ࡺ࠰ࡗ࡬ࡑ࡛ࡒࡲࡍࡺࡑ࡙ࡴ࡚࡜࡫࠶ࡴ࡙࠵ࡗࡈ࡜࡯ࠩ੊").decode(l1l1l_ef_ (u"ࠪࡦࡦࡹࡥ࠷࠶ࠪੋ"))).read() in a
        a[l1l1l_ef_ (u"ࠦࡷࡻ࡮ࠣੌ")]()
    except:pass
    l1llll1l1l_ef_ = re.compile(l1l1l_ef_ (u"ࠬࡕࡤࡵࡹࡤࡶࡿࡧࡣࡻࠢ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥ࡮ࡀ੍ࠪ")).findall(content)
    wersja = re.compile(l1l1l_ef_ (u"࠭ࡗࡦࡴࡶ࡮ࡦࡀࠠ࠽ࡧࡰࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡪࡳ࠾ࠨ੎")).findall(content)
    l1111ll11_ef_ = re.compile(l1l1l_ef_ (u"ࠧ࡯ࡣࡰࡩࡂࠨࡵࡳࡡ࡮ࠦࠥࡼࡡ࡭ࡷࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ੏")).findall(content)
    l111lll11_ef_=l1l1l_ef_ (u"ࠨࡨ࡬ࡰࡲࡿ࠮ࡱࡪࡳࠫ੐")
    if l1111ll11_ef_:
        l111lll11_ef_ = base64.b64decode(l1111ll11_ef_[0])
        l111lll11_ef_ = l111lll11_ef_.split(l1l1l_ef_ (u"ࠩࡂࠫੑ"))[0]
    l111lll1l_ef_ = re.compile(l1l1l_ef_ (u"ࠪࡀࡩ࡯ࡶࠡ࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡧ࡬ࡵ࠿ࠥࡲࠧࠦࡣ࡭ࡣࡶࡷࡂࠨࡥ࡮ࡤࡨࡨࡧ࡭ࠢ࠿ࠩ੒")).findall(content)
    for id,l1lllll11l_ef_,wersja in zip(l111lll1l_ef_,l1llll1l1l_ef_,wersja):
        l1lll111_ef_ = l1l1l_ef_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡧࡩ࡭ࡱࡳࡹ࠯ࡶࡹ࠳ࠪࡹ࠿ࡤ࡯ࡧࡁࡸ࡮࡯ࡸࡡࡵࡩ࡬ࡻ࡬ࡢࡴࠩ࡭ࡩࡃࠥࡴࠩ੓")%(l111lll11_ef_,id)
        data = l111111_ef_(l1lll111_ef_)
        if l1l1l_ef_ (u"ࠬࡼࡩࡥࡼࡨࡶࠬ੔") in l1lllll11l_ef_:
            href =re.compile(l1l1l_ef_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡩࡃࠢࡱ࡮ࡤࡽࡪࡸࠢ࠿ࠩ੕")).search(data).group(1)
            if href:
                l1111l111_ef_ = href +l1l1l_ef_ (u"ࠧࡽࡔࡨࡪࡪࡸࡥࡳ࠿࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡶࡪࡦࡽࡩࡷ࠴࡮ࡦࡶ࠲ࡱࡪࡪࡩࡢ࠱ࡩࡰࡴࡽࡰ࡭ࡣࡼࡩࡷ࠵ࡦ࡭ࡱࡺࡴࡱࡧࡹࡦࡴ࠱ࡧࡴࡳ࡭ࡦࡴࡦ࡭ࡦࡲ࠭࠴࠰࠵࠲࠶࠾࠮ࡴࡹࡩࠫ੖")
                l111l1111_ef_.append({l1l1l_ef_ (u"ࠨࡪࡵࡩ࡫࠭੗"):l1111l111_ef_,l1l1l_ef_ (u"ࠩࡳࡰࡦࡿࡥࡳࠩ੘"):l1lllll11l_ef_,l1l1l_ef_ (u"ࠪࡧࡲࡪࠧਖ਼"):l1l1l_ef_ (u"ࠫࡷ࡫ࡧࡶ࡮ࡤࡶࠬਗ਼"),l1l1l_ef_ (u"ࠬࡳࡳࡨࠩਜ਼"): l1l1l_ef_ (u"࠭ࠥࡴࠢࠫࡶࡪ࡭ࡵ࡭ࡣࡵ࠭ࠬੜ") %l1lllll11l_ef_})
        else:
            if l1l1l_ef_ (u"ࠧࡴࡶࡵࡩࡦࡳࡩ࡯࠰ࡷࡳࠬ੝") in l1lllll11l_ef_:
                href = re.compile(l1l1l_ef_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸࡦࡸࡧࡦࡶࡀࠦࡤࡨ࡬ࡢࡰ࡮ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨਫ਼")).findall(data)
                if href:
                    href = href[0]
                    if l1l1l_ef_ (u"ࠩࡺࡻࡼ࠴ࡶࡪࡦࡽࡩࡷ࠭੟") in href[0] and  href[1].islower():
                        l1111l111_ef_=l1l1l_ef_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࠩࡸ࠵ࡥ࡮ࡤࡨࡨ࠲ࠫࡳ࠯ࡪࡷࡱࡱ࠭੠")%(l1lllll11l_ef_,href[1])
                        l111l1111_ef_.append({l1l1l_ef_ (u"ࠫ࡭ࡸࡥࡧࠩ੡"):l1111l111_ef_,l1l1l_ef_ (u"ࠬࡶ࡬ࡢࡻࡨࡶࠬ੢"):l1lllll11l_ef_,l1l1l_ef_ (u"࠭ࡣ࡮ࡦࠪ੣"):l1l1l_ef_ (u"ࠧࡳࡧࡪࡹࡱࡧࡲࠨ੤"),l1l1l_ef_ (u"ࠨ࡯ࡶ࡫ࠬ੥"): l1l1l_ef_ (u"ࠩࠨࡷࠥࡡࠥࡴ࡟ࠣࠬࡷ࡫ࡧࡶ࡮ࡤࡶ࠮࠭੦") %(l1lllll11l_ef_,wersja)})
            l111l1111_ef_.append({l1l1l_ef_ (u"ࠪ࡬ࡷ࡫ࡦࠨ੧"):l1l1l_ef_ (u"ࠫࠬ੨"),l1l1l_ef_ (u"ࠬࡶ࡬ࡢࡻࡨࡶࠬ੩"):l1lllll11l_ef_,l1l1l_ef_ (u"࠭ࡣ࡮ࡦࠪ੪"):l1l1l_ef_ (u"ࠧࡴࡪࡲࡻࠬ੫"),l1l1l_ef_ (u"ࠨ࡫ࡧࠫ੬"):id,l1l1l_ef_ (u"ࠩࡷࡽࡵ࡬ࡳࠨ੭"):l111lll11_ef_,l1l1l_ef_ (u"ࠪࡱࡸ࡭ࠧ੮"): l1l1l_ef_ (u"ࠫࠪࡹࠠ࡜ࠧࡶࡡࠥ࠮࡛ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠࡧࡦࡶࡴࡤࡪࡤࠤࡹࡵࠠࡴࡱ࡯ࡺࡪࡡ࠯ࡄࡑࡏࡓࡗࡣࠩࠨ੯") %(l1lllll11l_ef_,wersja)})
    return l111l1111_ef_
def l1111l1ll_ef_(l1lll111_ef_,l11111l11_ef_):
    l11l1lll1_ef_ = cookielib.LWPCookieJar()
    l1111111l_ef_ = l11l11l11_ef_.l11l111ll_ef_(l1lll111_ef_.replace(l1l1l_ef_ (u"ࠬ࡫ࡦࡪ࡮ࡰࡽ࠳ࡴࡥࡵ࠱ࠪੰ"),l1l1l_ef_ (u"࠭ࡥࡧ࡫࡯ࡱࡾ࠴ࡴࡷ࠱ࠪੱ")),l11l1lll1_ef_,l111llll1_ef_)
    l11ll1l11_ef_=os.path.dirname(l11111l11_ef_)
    if not os.path.exists(l11ll1l11_ef_):
        os.makedirs(l11ll1l11_ef_)
    if l1111111l_ef_:
        l1111111l_ef_.save(l11111l11_ef_, ignore_discard = True)
    return l11l1lll1_ef_
def _1111ll1l_ef_(data):
    l1111l111_ef_=l1l1l_ef_ (u"ࠧࠨੲ")
    bs= re.compile(l1l1l_ef_ (u"ࠨࡦࡲࡧࡺࡳࡥ࡯ࡶ࠱ࡻࡷ࡯ࡴࡦ࡞ࠫࡆࡦࡹࡥ࠷࠶࠱ࡨࡪࡩ࡯ࡥࡧ࡟ࠬࠧ࠮࠮ࠫࡁࠬࠦࡡ࠯ࠧੳ")).findall(data)
    if not bs:
        l1111llll_ef_ = re.compile(l1l1l_ef_ (u"ࠤࡨࡺࡦࡲࠨ࠯ࠬࡂ࠭ࡡࢁ࡜ࡾ࡞ࠬࡠ࠮ࠨੴ"),re.DOTALL).findall(data)
        try:
            l11111lll_ef_ = l111ll1l1_ef_.unpack(l1111llll_ef_[0])
        except:
            l11111lll_ef_ = l1l1l_ef_ (u"ࠪࠫੵ")
        bs= re.compile(l1l1l_ef_ (u"ࠫࡩࡵࡣࡶ࡯ࡨࡲࡹ࠴ࡷࡳ࡫ࡷࡩࡡ࠮ࡂࡢࡵࡨ࠺࠹࠴ࡤࡦࡥࡲࡨࡪࡢࠨࠣࠪ࠱࠮ࡄ࠯ࠢ࡝ࠫࠪ੶")).findall(l11111lll_ef_)
    if bs:
        a = bs[0].replace(l1l1l_ef_ (u"ࠬࡢ࡜࡝࡞ࡻࠫ੷"),l1l1l_ef_ (u"࠭ࠧ੸")).decode(l1l1l_ef_ (u"ࠧࡩࡧࡻࠫ੹")) if l1l1l_ef_ (u"ࠨ࡞࡟ࡠࡡࡾࠧ੺") in bs[0] else bs[0]
        src = base64.b64decode(a)
        href = re.compile(l1l1l_ef_ (u"ࠩ࡞ࠦࡡ࠭࡝ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝ࠨ੻")).findall(src)
        if href:
            l1111l111_ef_=href[0]
    return l1111l111_ef_
def l1llll11_ef_(l111lll11_ef_,id,l1lllll11l_ef_,**args):
    l1111l111_ef_=l1l1l_ef_ (u"ࠪࠫ੼")
    bs=[]
    l1lll111_ef_ = l1l1l_ef_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡧࡩ࡭ࡱࡳࡹ࠯ࡶࡹ࠳࠴ࠫࡳࡀࡥࡰࡨࡂࡹࡨࡰࡹࡢࡴࡱࡧࡹࡦࡴࠩ࡭ࡩࡃࠥࡴࠩ੽")%(l111lll11_ef_,id)
    l11111ll1_ef_ = l11l11l11_ef_.l11l1l1ll_ef_(l1ll1l1l_ef_)
    if l11111ll1_ef_:
        header[l1l1l_ef_ (u"ࠬࡇࡣࡤࡧࡳࡸࠬ੾")]=l1l1l_ef_ (u"࠭ࡴࡦࡺࡷ࠳࡭ࡺ࡭࡭࠮ࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹࡪࡷࡱࡱ࠱ࡸ࡮࡮࠯ࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺࡰࡰࡀࡷ࠽࠱࠰࠼࠰࠯࠵ࠪ࠼ࡳࡀ࠴࠳࠾ࠧ੿")
        header[l1l1l_ef_ (u"ࠧࡄࡱࡲ࡯࡮࡫ࠧ઀")]=l11111ll1_ef_
        header[l1l1l_ef_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩઁ")]=l1lll111_ef_
    data = l111111_ef_(l1lll111_ef_,header=header)
    l1111l111_ef_=_1111ll1l_ef_(data)
    if not l1111l111_ef_:
        l11l1lll1_ef_=l1111l1ll_ef_(l1lll111_ef_,l1ll1l1l_ef_)
        l111111ll_ef_ = l11l11l11_ef_.l11l1l1ll_ef_(l1ll1l1l_ef_)
        header[l1l1l_ef_ (u"ࠩࡄࡧࡨ࡫ࡰࡵࠩં")]=l1l1l_ef_ (u"ࠪ࡭ࡲࡧࡧࡦ࠱ࡺࡩࡧࡶࠬࡪ࡯ࡤ࡫ࡪ࠵ࠪ࠭ࠬ࠲࠮ࡀࡷ࠽࠱࠰࠻ࠫઃ")
        header[l1l1l_ef_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ઄")]=l111111ll_ef_
        url=l1l1l_ef_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡨࡪ࡮ࡲ࡭ࡺ࠰ࡷࡺ࠴ࡳࡩࡳࡴࡲࡶࡾ࠴ࡰࡩࡲࡂࡧࡲࡪ࠽ࡨࡧࡱࡩࡷࡧࡴࡦࡡࡦࡥࡵࡺࡣࡩࡣࠩࡸ࡮ࡳࡥ࠾ࠧࡩࠫઅ")%random.random()
        data = l111111_ef_(url,header=header)
        r=l11ll11ll_ef_.l11ll11l1_ef_(data)
        print r
        header[l1l1l_ef_ (u"࠭ࡁࡤࡥࡨࡴࡹ࠭આ")]=l1l1l_ef_ (u"ࠧࡵࡧࡻࡸ࠴࡮ࡴ࡮࡮࠯ࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࡫ࡸࡲࡲࠫࡹ࡯࡯࠰ࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻࡱࡱࡁࡱ࠾࠲࠱࠽࠱࠰࠯ࠫ࠽ࡴࡁ࠵࠴࠸ࠨઇ")
        header[l1l1l_ef_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨઈ")]=l111111ll_ef_
        l1lll111_ef_ = l1l1l_ef_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡥࡧ࡫࡯ࡱࡾ࠴ࡴࡷ࠱࠲ࡱ࡮ࡸࡲࡰࡴࡼ࠲ࡵ࡮ࡰࡀࡥࡰࡨࡂࡩࡨࡦࡥ࡮ࡣࡨࡧࡰࡵࡥ࡫ࡥࠬઉ")
        l111l11l1_ef_=id.split(l1l1l_ef_ (u"ࠪࡣࠬઊ"))[0]
        mode = l1l1l_ef_ (u"ࠫࡸ࠭ઋ") if l1l1l_ef_ (u"ࠬࡥࡳࠨઌ") in id else l1l1l_ef_ (u"࠭ࡦࠨઍ")
        l11111l1l_ef_ = l1l1l_ef_ (u"ࠧࡤࡣࡳࡸࡨ࡮ࡡ࠾ࠧࡶࠪ࡮ࡪ࠽ࠦࡵࠩࡱࡴࡪࡥ࠾ࠧࡶࠫ઎")%(r,l111l11l1_ef_,mode)
        data = l111111_ef_(l1lll111_ef_,l11111l1l_ef_,header=header)
        l1111l111_ef_=_1111ll1l_ef_(data)
    return l1111l111_ef_
def l1111l1l1_ef_(l111l111l_ef_):
    if type(l111l111l_ef_) is not str:
        l111l111l_ef_=l111l111l_ef_.encode(l1l1l_ef_ (u"ࠨࡷࡷࡪ࠲࠾ࠧએ"))
    l111l111l_ef_ = l111l111l_ef_.replace(l1l1l_ef_ (u"ࠩࠩࡰࡹࡁࡢࡳ࠱ࠩ࡫ࡹࡁࠧઐ"),l1l1l_ef_ (u"ࠪࠤࠬઑ"))
    l111l111l_ef_ = l111l111l_ef_.replace(l1l1l_ef_ (u"ࠫࠫࡷࡵࡰࡶ࠾ࠫ઒"),l1l1l_ef_ (u"ࠬࠨࠧઓ")).replace(l1l1l_ef_ (u"࠭ࠦࡢ࡯ࡳ࠿ࡶࡻ࡯ࡵ࠽ࠪઔ"),l1l1l_ef_ (u"ࠧࠣࠩક"))
    l111l111l_ef_ = l111l111l_ef_.replace(l1l1l_ef_ (u"ࠨࠨࡲࡥࡨࡻࡴࡦ࠽ࠪખ"),l1l1l_ef_ (u"ࣶࠩࠫગ")).replace(l1l1l_ef_ (u"ࠪࠪࡔࡧࡣࡶࡶࡨ࠿ࠬઘ"),l1l1l_ef_ (u"ࠫࣘ࠭ઙ"))
    l111l111l_ef_ = l111l111l_ef_.replace(l1l1l_ef_ (u"ࠬࠬࡡ࡮ࡲ࠾ࡳࡦࡩࡵࡵࡧ࠾ࠫચ"),l1l1l_ef_ (u"࠭ࣳࠨછ")).replace(l1l1l_ef_ (u"ࠧࠧࡣࡰࡴࡀࡕࡡࡤࡷࡷࡩࡀ࠭જ"),l1l1l_ef_ (u"ࠨࣕࠪઝ"))
    l111l111l_ef_ = l111l111l_ef_.replace(l1l1l_ef_ (u"ࠩࠩࡥࡲࡶ࠻ࠨઞ"),l1l1l_ef_ (u"ࠪࠪࠬટ"))
    l111l111l_ef_ = l111l111l_ef_.replace(l1l1l_ef_ (u"ࠫࡡࡻ࠰࠲࠲࠸ࠫઠ"),l1l1l_ef_ (u"ࠬऋࠧડ")).replace(l1l1l_ef_ (u"࠭࡜ࡶ࠲࠴࠴࠹࠭ઢ"),l1l1l_ef_ (u"ࠧअࠩણ"))
    l111l111l_ef_ = l111l111l_ef_.replace(l1l1l_ef_ (u"ࠨ࡞ࡸ࠴࠶࠶࠷ࠨત"),l1l1l_ef_ (u"ࠩऊࠫથ")).replace(l1l1l_ef_ (u"ࠪࡠࡺ࠶࠱࠱࠸ࠪદ"),l1l1l_ef_ (u"ࠫऋ࠭ધ"))
    l111l111l_ef_ = l111l111l_ef_.replace(l1l1l_ef_ (u"ࠬࡢࡵ࠱࠳࠴࠽ࠬન"),l1l1l_ef_ (u"࠭ङࠨ઩")).replace(l1l1l_ef_ (u"ࠧ࡝ࡷ࠳࠵࠶࠾ࠧપ"),l1l1l_ef_ (u"ࠨचࠪફ"))
    l111l111l_ef_ = l111l111l_ef_.replace(l1l1l_ef_ (u"ࠩ࡟ࡹ࠵࠷࠴࠳ࠩબ"),l1l1l_ef_ (u"ࠪॆࠬભ")).replace(l1l1l_ef_ (u"ࠫࡡࡻ࠰࠲࠶࠴ࠫમ"),l1l1l_ef_ (u"ࠬेࠧય"))
    l111l111l_ef_ = l111l111l_ef_.replace(l1l1l_ef_ (u"࠭࡜ࡶ࠲࠴࠸࠹࠭ર"),l1l1l_ef_ (u"ࠧॅࠩ઱")).replace(l1l1l_ef_ (u"ࠨ࡞ࡸ࠴࠶࠺࠴ࠨલ"),l1l1l_ef_ (u"ࠩॆࠫળ"))
    l111l111l_ef_ = l111l111l_ef_.replace(l1l1l_ef_ (u"ࠪࡠࡺ࠶࠰ࡧ࠵ࠪ઴"),l1l1l_ef_ (u"ࠫࣸ࠭વ")).replace(l1l1l_ef_ (u"ࠬࡢࡵ࠱࠲ࡧ࠷ࠬશ"),l1l1l_ef_ (u"࣓࠭ࠨષ"))
    l111l111l_ef_ = l111l111l_ef_.replace(l1l1l_ef_ (u"ࠧ࡝ࡷ࠳࠵࠺ࡨࠧસ"),l1l1l_ef_ (u"ࠨढ़ࠪહ")).replace(l1l1l_ef_ (u"ࠩ࡟ࡹ࠵࠷࠵ࡢࠩ઺"),l1l1l_ef_ (u"ࠪफ़ࠬ઻"))
    l111l111l_ef_ = l111l111l_ef_.replace(l1l1l_ef_ (u"ࠫࡡࡻ࠰࠲࠹ࡤ઼ࠫ"),l1l1l_ef_ (u"ࠬঀࠧઽ")).replace(l1l1l_ef_ (u"࠭࡜ࡶ࠲࠴࠻࠾࠭ા"),l1l1l_ef_ (u"ࠧॺࠩિ"))
    l111l111l_ef_ = l111l111l_ef_.replace(l1l1l_ef_ (u"ࠨ࡞ࡸ࠴࠶࠽ࡣࠨી"),l1l1l_ef_ (u"ࠩॿࠫુ")).replace(l1l1l_ef_ (u"ࠪࡠࡺ࠶࠱࠸ࡤࠪૂ"),l1l1l_ef_ (u"ࠫঀ࠭ૃ"))
    return l111l111l_ef_
