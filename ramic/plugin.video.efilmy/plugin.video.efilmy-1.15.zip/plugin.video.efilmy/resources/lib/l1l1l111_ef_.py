# -*- coding: utf-8 -*-
import sys
l1_ef_ = sys.version_info [0] == 2
l1llll_ef_ = 2048
l1l1_ef_ = 7
def l1l1l_ef_ (ll_ef_):
	global l1111_ef_
	l1l1l1_ef_ = ord (ll_ef_ [-1])
	l11ll_ef_ = ll_ef_ [:-1]
	l11_ef_ = l1l1l1_ef_ % len (l11ll_ef_)
	l1ll_ef_ = l11ll_ef_ [:l11_ef_] + l11ll_ef_ [l11_ef_:]
	if l1_ef_:
		l1lll1_ef_ = unicode () .join ([unichr (ord (char) - l1llll_ef_ - (l1ll1_ef_ + l1l1l1_ef_) % l1l1_ef_) for l1ll1_ef_, char in enumerate (l1ll_ef_)])
	else:
		l1lll1_ef_ = str () .join ([chr (ord (char) - l1llll_ef_ - (l1ll1_ef_ + l1l1l1_ef_) % l1l1_ef_) for l1ll1_ef_, char in enumerate (l1ll_ef_)])
	return eval (l1lll1_ef_)
import urllib
import urllib2
import hashlib
import json
import re
l1ll1l1lll_ef_ = l1l1l_ef_ (u"ࠧ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡳࡴ࡮࠱ࡪ࡮ࡲ࡭ࡸࡧࡥ࠲ࡵࡲ࠯ࡢࡲ࡬ࡃࠧૄ");
l1ll1l1ll1_ef_ = l1l1l_ef_ (u"ࠨࡱ࡫ࡥࡊ࡬࡜࠸ࡊ࡯ࡸࡊࡘ࠾ࡪࡦࡄࡶ࠶ࡹ࡙ࡥࡪࡰࡼࡕ࠷ࡸࠨૅ");
l1ll1ll111_ef_ = l1l1l_ef_ (u"ࠢࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲࡫࡯࡬࡮ࡹࡨࡦ࠳ࡶ࡬ࠣ૆");
VERSION = l1l1l_ef_ (u"ࠣ࠴࠱࠶ࠧે");
l1ll1ll1ll_ef_ = l1l1l_ef_ (u"ࠤࡤࡲࡩࡸ࡯ࡪࡦࠥૈ");
l1ll1lll1l_ef_ = l1l1l_ef_ (u"ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡧ࡫࡯ࡱࡼ࡫ࡢ࠯ࡲ࡯࠳ࡸ࡫ࡡࡳࡥ࡫࠳ࡱ࡯ࡶࡦࡁࡴࡁࠧૉ");
l1ll1llll1_ef_ = l1l1l_ef_ (u"ࠦࡡࡢࡣࠣ૊");
l1ll1l11l1_ef_ = l1l1l_ef_ (u"ࠧࡢ࡜ࡢࠤો");
l1lll1lll1_ef_ = l1l1l_ef_ (u"ࠨࡨࡵࡶࡳ࠾࠴࠵࠱࠯ࡨࡺࡧࡩࡴ࠮ࡱ࡮࠲ࡴࡴࠨૌ")
l111l1l11_ef_=10
def _1lllll1l1_ef_(url):
    l1l1l_ef_ (u"ࠢࠣࠤࠐࠎࠥࠦࠠࠡࡉࡨࡸ࡛ࠥࡲ࡭ࠢࡦࡳࡳࡺ࡮ࡦࡶࡱࡸࠒࠐࠠࠡࠢࠣࡶࡪࡺࡵࡳࡰ࠽ࠤࡸࡺࡲࡪࡰࡪࠑࠏ્ࠦࠠࠡࠢࠥࠦࠧ")
    headers = {l1l1l_ef_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ૎"): l1l1l_ef_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶ࠠࠩࡎ࡬ࡲࡺࡾ࠻ࠡࡃࡱࡨࡷࡵࡩࡥࠢ࠷࠲࠶࠴࠱࠼ࠢࡊࡥࡱࡧࡸࡺࠢࡑࡩࡽࡻࡳࠡࡄࡸ࡭ࡱࡪ࠯ࡋࡔࡒ࠴࠸ࡉࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠷࠱࠵࠾ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠷࠸࠯࠲࠱࠵࠵࠸࠵࠯࠳࠹࠺ࠥࡓ࡯ࡣ࡫࡯ࡩ࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠶࠰࠴࠽ࠬ૏"),
            }
    req = urllib2.Request(url, None, headers)
    response = urllib2.urlopen(req,timeout=l111l1l11_ef_)
    l1lll111_ef_ = response.read()
    response.close()
    return l1lll111_ef_
def _1llll111l_ef_(method):
    l1ll1l1l1l_ef_ = method + l1l1l_ef_ (u"ࠥࡠࡳࠨૐ") + l1ll1ll1ll_ef_ + l1ll1l1ll1_ef_;
    l1ll1l1l1l_ef_ = VERSION + l1l1l_ef_ (u"ࠦ࠱ࠨ૑") + hashlib.md5(l1ll1l1l1l_ef_).hexdigest();
    return l1ll1l1l1l_ef_;
def _1lll1l1ll_ef_(method):
    l1ll1l1l1l_ef_ = _1llll111l_ef_(method);
    method += l1l1l_ef_ (u"ࠧࡢ࡮ࠣ૒");
    qs={    l1l1l_ef_ (u"࠭࡭ࡦࡶ࡫ࡳࡩࡹࠧ૓"):method,
            l1l1l_ef_ (u"ࠧࡴ࡫ࡪࡲࡦࡺࡵࡳࡧࠪ૔"):l1ll1l1l1l_ef_,
            l1l1l_ef_ (u"ࠨࡸࡨࡶࡸ࡯࡯࡯ࠩ૕"):VERSION,
            l1l1l_ef_ (u"ࠩࡤࡴࡵࡏࡤࠨ૖"):l1ll1ll1ll_ef_}
    return urllib.urlencode(qs)
def _1lll1l1l1_ef_(response,_1lll1llll_ef_):
    _1lll111l1_ef_ = response.split(l1l1l_ef_ (u"ࠪࠤࡹࡀࠧ૗"))[0].split(l1l1l_ef_ (u"ࠫࡡࡴࠧ૘"))
    status = _1lll111l1_ef_[0]
    data = _1lll111l1_ef_[1]
    out={}
    if data==l1l1l_ef_ (u"ࠬࡴࡵ࡭࡮ࠪ૙"):
        pass
    else:
        l1ll1ll11l_ef_=json.loads(data)
        N=len(l1ll1ll11l_ef_)
        for k,v in _1lll1llll_ef_.iteritems():
            if l1ll1ll11l_ef_[k]==None:
                l1ll1ll11l_ef_[k]=l1l1l_ef_ (u"࠭ࠧ૚")
            if N>= k: out[v]=l1ll1ll11l_ef_[k]
    return out
def getFilmInfoFull(filmID=l1l1l_ef_ (u"ࠧ࠲࠺࠸࠺࠸࠸ࠧ૛")):
    method = l1l1l_ef_ (u"ࠨࡩࡨࡸࡋ࡯࡬࡮ࡋࡱࡪࡴࡌࡵ࡭࡮ࠣ࡟ࠬ૜") + filmID + l1l1l_ef_ (u"ࠩࡠࠫ૝")
    _1lll1llll_ef_ ={
        0 :  l1l1l_ef_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ૞"),
        1 :  l1l1l_ef_ (u"ࠫࡴࡸࡩࡨ࡫ࡱࡥࡱࡺࡩࡵ࡮ࡨࠫ૟"),
        2 :  l1l1l_ef_ (u"ࠬࡸࡡࡵ࡫ࡱ࡫ࠬૠ"),
        3 :  l1l1l_ef_ (u"࠭ࡶࡰࡶࡨࡷࠬૡ"),
        4 :  l1l1l_ef_ (u"ࠧࡨࡧࡱࡶࡪ࠭ૢ"),
        5 :  l1l1l_ef_ (u"ࠨࡻࡨࡥࡷ࠭ૣ"),
        6 :  l1l1l_ef_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ૤"),
        7 :  l1l1l_ef_ (u"ࠪࡧࡴࡳ࡭ࡦࡰࡷࡷࡈࡵࡵ࡯ࡶࠪ૥"),
        8 :  l1l1l_ef_ (u"ࠫ࡫ࡵࡲࡶ࡯ࡘࡶࡱ࠭૦"),
        9 :  l1l1l_ef_ (u"ࠬ࡮ࡡࡴࡔࡨࡺ࡮࡫ࡷࠨ૧"),
        10 :  l1l1l_ef_ (u"࠭ࡨࡢࡵࡇࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠧ૨"),
        11 :  l1l1l_ef_ (u"ࠧࡪ࡯ࡪࠫ૩"),
        12 :  l1l1l_ef_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ૪"),
        13 :  l1l1l_ef_ (u"ࠩࡳࡶࡪࡳࡩࡦࡴࡨ࡛ࡴࡸ࡬ࡥࠩ૫"),
        14 :  l1l1l_ef_ (u"ࠪࡨࡦࡺࡥࠨ૬"),
        15 :  l1l1l_ef_ (u"ࠫ࡫࡯࡬࡮ࡖࡼࡴࡪ࠭૭"),
        16 :  l1l1l_ef_ (u"ࠬࡹࡥࡢࡵࡲࡲࡸࡉ࡯ࡶࡰࡷࠫ૮"),
        17 :  l1l1l_ef_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࡄࡱࡸࡲࡹ࠭૯"),
        18 :  l1l1l_ef_ (u"ࠧࡴࡶࡸࡨ࡮ࡵࠧ૰"),
        19 :  l1l1l_ef_ (u"ࠨࡲ࡯ࡳࡹ࠭૱")
    }
    response = _1lllll1l1_ef_( l1ll1l1lll_ef_ + _1lll1l1ll_ef_(method))
    out = {}
    if response[:2]==l1l1l_ef_ (u"ࠩࡲ࡯ࠬ૲"):
        out =_1lll1l1l1_ef_(response,_1lll1llll_ef_)
        out[l1l1l_ef_ (u"ࠪࡪ࡮ࡲ࡭ࡸࡧࡥࠫ૳")]=filmID
        if out.get(l1l1l_ef_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ૴")):
            l1ll1lll11_ef_ = [ x for x in out.get(l1l1l_ef_ (u"ࠬࡼࡩࡥࡧࡲࠫ૵")) if l1l1l_ef_ (u"࠭࡭ࡱ࠶ࠪ૶") in str(x) ]
            pattern = [l1l1l_ef_ (u"ࠧ࠯࠵࠹࠴ࡵ࠴ࠧ૷"), l1l1l_ef_ (u"ࠨ࠰࠷࠼࠵ࡶ࠮ࠨ૸"), l1l1l_ef_ (u"ࠩ࠱࠻࠷࠶ࡰ࠯ࠩૹ")]
            l1ll1l111l_ef_ = l1ll1lll11_ef_[0]
            for p in pattern:
                for t in l1ll1lll11_ef_:
                    if p in t:
                        l1ll1l111l_ef_ = t
            out[l1l1l_ef_ (u"ࠪࡸࡷࡧࡩ࡭ࡧࡵࠫૺ")]=l1ll1l111l_ef_
        if out.get(l1l1l_ef_ (u"ࠫ࡮ࡳࡧࠨૻ")):
            out[l1l1l_ef_ (u"ࠬ࡯࡭ࡨࠩૼ")]=l1lll1lll1_ef_ + out.get(l1l1l_ef_ (u"࠭ࡩ࡮ࡩࠪ૽")).replace(l1l1l_ef_ (u"ࠧ࠯࠴࠱ࠫ૾"),l1l1l_ef_ (u"ࠨ࠰࠶࠲ࠬ૿"))
        if out.get(l1l1l_ef_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫ଀")):
            out[l1l1l_ef_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬଁ")] = float(out.get(l1l1l_ef_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭ଂ")))*60
    return out
def l1lll1ll1l_ef_(filmID=l1l1l_ef_ (u"ࠬ࠻࠹࠵࠵࠸࠻ࠬଃ")):
    method = l1l1l_ef_ (u"࠭ࡧࡦࡶࡉ࡭ࡱࡳࡳࡊࡰࡩࡳࡘ࡮࡯ࡳࡶࠣ࡟ࡠ࠭଄") + filmID + l1l1l_ef_ (u"ࠧ࡞࡟ࠪଅ")
    _1lll1llll_ef_ = {
        0 :  l1l1l_ef_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧଆ"),
        1 :  l1l1l_ef_ (u"ࠩࡼࡩࡦࡸࠧଇ"),
        2 :  l1l1l_ef_ (u"ࠪࡶࡦࡺࡩ࡯ࡩࠪଈ"),
        3 :  l1l1l_ef_ (u"ࠫࡤ࠭ଉ"),
        4 :  l1l1l_ef_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧଊ"),
        5 :  l1l1l_ef_ (u"࠭ࡩ࡮ࡩࠪଋ"),
        6 :  l1l1l_ef_ (u"ࠧࡪࡦࠪଌ")}
    response = _1lllll1l1_ef_( l1ll1l1lll_ef_ + _1lll1l1ll_ef_(method))
    out = {}
    if response[:2]==l1l1l_ef_ (u"ࠨࡱ࡮ࠫ଍"):
        out =_1lll1l1l1_ef_(response.replace(l1l1l_ef_ (u"ࠩ࡞࡟ࠬ଎"),l1l1l_ef_ (u"ࠪ࡟ࠬଏ")).replace(l1l1l_ef_ (u"ࠫࡢࡣࠧଐ"),l1l1l_ef_ (u"ࠬࡣࠧ଑")),_1lll1llll_ef_)
    return out
def l1lll11ll1_ef_(filmID=l1l1l_ef_ (u"࠭࠵࠺࠶࠶࠹࠼࠭଒"), t=l1l1l_ef_ (u"ࠧࡢࡥࡷࡳࡷࡹࠧଓ")):
    l1ll1ll1l1_ef_ = { l1l1l_ef_ (u"ࠨࡦ࡬ࡶࡪࡩࡴࡰࡴࡶࠫଔ"): l1l1l_ef_ (u"ࠩ࠴ࠫକ"), l1l1l_ef_ (u"ࠪࡷࡨ࡫࡮ࡢࡴ࡬ࡷࡹࡹࠧଖ"): l1l1l_ef_ (u"ࠫ࠷࠭ଗ"), l1l1l_ef_ (u"ࠬࡳࡵࡴ࡫ࡦࡷࠬଘ"): l1l1l_ef_ (u"࠭࠳ࠨଙ"), l1l1l_ef_ (u"ࠧࡱࡪࡲࡸࡴࡹࠧଚ"): l1l1l_ef_ (u"ࠨ࠶ࠪଛ"), l1l1l_ef_ (u"ࠩࡤࡧࡹࡵࡲࡴࠩଜ"): l1l1l_ef_ (u"ࠪ࠺ࠬଝ"), l1l1l_ef_ (u"ࠫࡵࡸ࡯ࡥࡷࡦࡩࡷࡹࠧଞ"): l1l1l_ef_ (u"ࠬ࠿ࠧଟ") }
    l1lll11l11_ef_ = [l1l1l_ef_ (u"࠭ࡩࡥࠩଠ"), l1l1l_ef_ (u"ࠧࡳࡱ࡯ࡩࠬଡ"), l1l1l_ef_ (u"ࠨࡴࡲࡰࡪࡥࡴࡺࡲࡨࠫଢ"), l1l1l_ef_ (u"ࠩࡱࡥࡲ࡫ࠧଣ"), l1l1l_ef_ (u"ࠪ࡭ࡲ࡭ࠧତ")]
    l1lll1l11l_ef_ = {}
    if t in l1ll1ll1l1_ef_.keys():
        method = l1l1l_ef_ (u"ࠫ࡬࡫ࡴࡇ࡫࡯ࡱࡕ࡫ࡲࡴࡱࡱࡷࠥࡡࠧଥ") + str(filmID) + l1l1l_ef_ (u"ࠬ࠲ࠠࠨଦ") + l1ll1ll1l1_ef_[t] + l1l1l_ef_ (u"࠭ࠬࠡ࠲࠯ࠤ࠺࠶࡝ࠨଧ")
        response = _1lllll1l1_ef_( l1ll1l1lll_ef_ + _1lll1l1ll_ef_(method))
        l1ll1lllll_ef_ = re.search(l1l1l_ef_ (u"ࠧࠩ࡞࡞࠲࠯ࡢ࡝ࠪࠩନ"), response)
        l1lll11l1l_ef_ = json.loads(l1ll1lllll_ef_.group(1))
        for data in l1lll11l1l_ef_:
            l1lll1l11l_ef_[data[0]] = {}
            for i in range(0, len(l1lll11l11_ef_)):
                if l1lll11l11_ef_[i] == l1l1l_ef_ (u"ࠨ࡫ࡰ࡫ࠬ଩"):
                    l1lll1l11l_ef_[data[0]][l1lll11l11_ef_[i]] = l1l1l_ef_ (u"ࠩࠪପ") if data[i] == None else l1l1l_ef_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠳࡬ࡷࡤࡦࡱ࠲ࡵࡲ࠯ࡱࠩଫ") + data[i].encode(l1l1l_ef_ (u"ࠫࡺࡺࡦ࠮࠺ࠪବ")).replace(l1l1l_ef_ (u"ࠬ࠴࠱࠯࡬ࡳ࡫ࠬଭ"), l1l1l_ef_ (u"࠭࠮࠴࠰࡭ࡴ࡬࠭ମ"))
                else:
                    l1lll1l11l_ef_[data[0]][l1lll11l11_ef_[i]] = data[i].encode(l1l1l_ef_ (u"ࠧࡶࡶࡩ࠱࠽࠭ଯ")) if type(data[i]) == unicode else data[i]
    return l1lll1l11l_ef_
def l1lll1l111_ef_(filmID=l1l1l_ef_ (u"ࠨ࠳ࠪର")):
    method = l1l1l_ef_ (u"ࠩࡪࡩࡹࡌࡩ࡭࡯ࡇࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠠ࡜ࠩ଱") + filmID + l1l1l_ef_ (u"ࠪࡡࠬଲ")
    _1lll1llll_ef_ = {0 :  l1l1l_ef_ (u"ࠫࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯ࠩଳ")}
    response = _1lllll1l1_ef_( l1ll1l1lll_ef_ + _1lll1l1ll_ef_(method))
    out = {}
    if response[:2]==l1l1l_ef_ (u"ࠬࡵ࡫ࠨ଴"):
        out =_1lll1l1l1_ef_(response,_1lll1llll_ef_)
    return out
def _1lll11lll_ef_(result):
    l1ll1l11ll_ef_ = result.split(l1ll1l11l1_ef_);
    print l1l1l_ef_ (u"࠭࡜ࡵࡈࡲࡹࡳࡪࠠࠦࡦࠣࡩࡳࡺࡲࡪࡧࡶࠫଵ") %len(l1ll1l11ll_ef_)
    element=l1ll1l11ll_ef_[0]
    l1llll1111_ef_=[]
    for element in l1ll1l11ll_ef_:
        l1llllll1l_ef_=_1lll1ll11_ef_(element)
        if l1llllll1l_ef_: l1llll1111_ef_.append(l1llllll1l_ef_)
    return l1llll1111_ef_
def _1lll1ll11_ef_(element):
    l1lll1111l_ef_ = element.split(l1ll1llll1_ef_);
    type = l1lll1111l_ef_[0]
    if type == l1l1l_ef_ (u"ࠧࡧࠩଶ") or type == l1l1l_ef_ (u"ࠨࡵࠪଷ"):
        result = _1lll11111_ef_(l1lll1111l_ef_);
    elif type == l1l1l_ef_ (u"ࠩࡳࠫସ"):
        result=None
    else :
        result=None
    return result
def _1lll11111_ef_(l1lll1111l_ef_):
    item={}
    if len(l1lll1111l_ef_):
        item[l1l1l_ef_ (u"ࠪࡸࡾࡶࡥࠨହ")] = l1lll1111l_ef_[0]
        item[l1l1l_ef_ (u"ࠫ࡮ࡪࠧ଺")] = l1lll1111l_ef_[1]
        item[l1l1l_ef_ (u"ࠬ࡯࡭ࡨࠩ଻")] = l1lll1lll1_ef_ + l1lll1111l_ef_[2]
        item[l1l1l_ef_ (u"࠭ࡴࡪࡶ࡯ࡩࡤ࡬଼ࠧ")] = l1lll1111l_ef_[3]
        item[l1l1l_ef_ (u"ࠧࡵ࡫ࡷࡰࡪࡥࡰࠨଽ")] = l1lll1111l_ef_[4]
        item[l1l1l_ef_ (u"ࠨࡶ࡬ࡸࡱ࡫࡟ࡦࠩା")] = l1lll1111l_ef_[5]
        item[l1l1l_ef_ (u"ࠩࡼࡩࡦࡸࠧି")] = l1lll1111l_ef_[6]
        item[l1l1l_ef_ (u"ࠪࡧࡦࡹࡴࠨୀ")] = l1lll1111l_ef_[7]
    return item
def l1lll111ll_ef_(param=l1l1l_ef_ (u"ࡹࠬࡹࡴࡳࡣॿࡲ࡮ࡩࡹࠡࡩࡤࡰࡦࡱࡴࡺ࡭࡬ࠫୁ")):
    result = _1lllll1l1_ef_( l1ll1lll1l_ef_ + urllib.quote_plus(param.encode(l1l1l_ef_ (u"ࠬࡻࡴࡧ࠯࠻ࠫୂ")).lower()) )
    out = _1lll11lll_ef_(result)
    return out
def searchFilmweb(title=l1l1l_ef_ (u"࠭ࠧୃ"),year=l1l1l_ef_ (u"ࠧࠨୄ"),itemType=l1l1l_ef_ (u"ࠨࡨࠪ୅")):
    l1l1l_ef_ (u"ࠤࠥࠦࠒࠐࠠࠡࠢࠣࡗࡿࡻ࡫ࡢࠢ࡬ࡲ࡫ࡵࡲ࡮ࡣࡦ࡮࡮ࠦ࡯ࠡࡨ࡬ࡰࡲ࡯ࡥࠎࠌࠣࠤࠥࠦࡩࡵࡧࡰࡘࡾࡶࡥࠡ࠿ࠣࠫ࡫࠭ࠠ࠮ࠢࡉ࡭ࡱࡳࠍࠋࠢࠣࠤࠥ࡯ࡴࡦ࡯ࡗࡽࡵ࡫ࠠ࠾ࠢࠪࡷࠬࠦ࠭ࠡࡕࡨࡶ࡮ࡧ࡬ࠎࠌࠣࠤࠥࠦࠢࠣࠤ୆")
    l1ll1l1l11_ef_={}
    search = l1l1l_ef_ (u"ࡸࠫࠪࡹࠧେ") % title.strip()
    search += l1l1l_ef_ (u"ࡹࠬࠦࠥࡴࠩୈ") % year if year else l1l1l_ef_ (u"ࠬ࠭୉")
    out= l1lll111ll_ef_(search)
    if out:
        if len(out)==1:
            l1ll1l1l11_ef_ = out[0]
        else:
            for l1llllll1l_ef_ in sorted(out, key=lambda k: k[l1l1l_ef_ (u"࠭ࡹࡦࡣࡵࠫ୊")],reverse=True):
                if l1llllll1l_ef_.get(l1l1l_ef_ (u"ࠧࡺࡧࡤࡶࠬୋ"),l1l1l_ef_ (u"ࠨࠩୌ")) in [l1l1l_ef_ (u"ࠩ࠵࠴࠶࠽୍ࠧ"),l1l1l_ef_ (u"ࠪ࠶࠵࠷࠸ࠨ୎"),l1l1l_ef_ (u"ࠫ࠷࠶࠱࠺ࠩ୏"),l1l1l_ef_ (u"ࠬ࠸࠰࠳࠲ࠪ୐")]:
                    continue
                if l1llllll1l_ef_.get(l1l1l_ef_ (u"࠭ࡴࡺࡲࡨࠫ୑")) == itemType:
                    l1ll1l1l11_ef_ = l1llllll1l_ef_
                    break
        return getFilmInfoFull(l1ll1l1l11_ef_.get(l1l1l_ef_ (u"ࠧࡪࡦࠪ୒"),l1l1l_ef_ (u"ࠨࠩ୓")))
    else:
        return l1ll1l1l11_ef_
if __name__==l1l1l_ef_ (u"ࠤࡢࡣࡲࡧࡩ࡯ࡡࡢࠦ୔"):
    pass
