# -*- coding: utf-8 -*-
import sys
l1_ef_ = sys.version_info [0] == 2
l1llll_ef_ = 2048
l1l1_ef_ = 7
def l1l1l_ef_ (ll_ef_):
	global l1111_ef_
	l1l1l1_ef_ = ord (ll_ef_ [-1])
	l11ll_ef_ = ll_ef_ [:-1]
	l11_ef_ = l1l1l1_ef_ % len (l11ll_ef_)
	l1ll_ef_ = l11ll_ef_ [:l11_ef_] + l11ll_ef_ [l11_ef_:]
	if l1_ef_:
		l1lll1_ef_ = unicode () .join ([unichr (ord (char) - l1llll_ef_ - (l1ll1_ef_ + l1l1l1_ef_) % l1l1_ef_) for l1ll1_ef_, char in enumerate (l1ll_ef_)])
	else:
		l1lll1_ef_ = str () .join ([chr (ord (char) - l1llll_ef_ - (l1ll1_ef_ + l1l1l1_ef_) % l1l1_ef_) for l1ll1_ef_, char in enumerate (l1ll_ef_)])
	return eval (l1lll1_ef_)
import os,re,urllib
import xbmc,xbmcaddon,xbmcgui,xbmcvfs
l11ll1ll1_ef_    = xbmcaddon.Addon().getAddonInfo
l11ll1lll_ef_     = xbmcvfs.File
l11l1llll_ef_   = xbmcvfs.delete
l11ll1l11_ef_     = xbmc.translatePath(l11ll1ll1_ef_(l1l1l_ef_ (u"ࠧࡱࡴࡲࡪ࡮ࡲࡥࠨম"))).decode(l1l1l_ef_ (u"ࠨࡷࡷࡪ࠲࠾ࠧয"))
l11ll1l1l_ef_        = xbmcgui.ControlImage
l11ll1111_ef_ = xbmcgui.WindowDialog()
l11ll111l_ef_     = xbmc.Keyboard
def l11ll11l1_ef_(response):
    i = os.path.join(l11ll1l11_ef_,l1l1l_ef_ (u"ࠩࡦࡥࡵࡺࡣࡩࡣ࠱ࡴࡳ࡭ࠧর"))
    f = l11ll1lll_ef_(i, l1l1l_ef_ (u"ࠪࡻࠬ঱"))
    f.write(response)
    f.close()
    f = l11ll1l1l_ef_(450,5,375,115, i)
    d = l11ll1111_ef_
    d.addControl(f)
    l11l1llll_ef_(i)
    d.show()
    k = xbmc.Keyboard(l1l1l_ef_ (u"ࠫࠬল"), l1l1l_ef_ (u"ࠬ࠭঳"))
    k.doModal()
    c = k.getText() if k.isConfirmed() else None
    if c == l1l1l_ef_ (u"࠭ࠧ঴"): c = None
    d.removeControl(f)
    d.close()
    return c
