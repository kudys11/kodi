# coding: UTF-8
import sys
l1_ef_ = sys.version_info [0] == 2
l1llll_ef_ = 2048
l1l1_ef_ = 7
def l1l1l_ef_ (ll_ef_):
	global l1111_ef_
	l1l1l1_ef_ = ord (ll_ef_ [-1])
	l11ll_ef_ = ll_ef_ [:-1]
	l11_ef_ = l1l1l1_ef_ % len (l11ll_ef_)
	l1ll_ef_ = l11ll_ef_ [:l11_ef_] + l11ll_ef_ [l11_ef_:]
	if l1_ef_:
		l1lll1_ef_ = unicode () .join ([unichr (ord (char) - l1llll_ef_ - (l1ll1_ef_ + l1l1l1_ef_) % l1l1_ef_) for l1ll1_ef_, char in enumerate (l1ll_ef_)])
	else:
		l1lll1_ef_ = str () .join ([chr (ord (char) - l1llll_ef_ - (l1ll1_ef_ + l1l1l1_ef_) % l1l1_ef_) for l1ll1_ef_, char in enumerate (l1ll_ef_)])
	return eval (l1lll1_ef_)
l1l1l_ef_ (u"ࠥࠦࠧࠐࠠࠡࠢࠣࡹࡷࡲࡲࡦࡵࡲࡰࡻ࡫ࡲ࡚ࠡࡅࡑࡈࠦࡁࡥࡦࡲࡲࠏࠦࠠࠡࠢࡆࡳࡵࡿࡲࡪࡩ࡫ࡸࠥ࠮ࡃࠪࠢ࠵࠴࠶࠹ࠠࡃࡵࡷࡶࡩࡹ࡭࡬ࡴࠍࠎࠥࠦࠠࠡࡖ࡫࡭ࡸࠦࡰࡳࡱࡪࡶࡦࡳࠠࡪࡵࠣࡪࡷ࡫ࡥࠡࡵࡲࡪࡹࡽࡡࡳࡧ࠽ࠤࡾࡵࡵࠡࡥࡤࡲࠥࡸࡥࡥ࡫ࡶࡸࡷ࡯ࡢࡶࡶࡨࠤ࡮ࡺࠠࡢࡰࡧ࠳ࡴࡸࠠ࡮ࡱࡧ࡭࡫ࡿࠊࠡࠢࠣࠤ࡮ࡺࠠࡶࡰࡧࡩࡷࠦࡴࡩࡧࠣࡸࡪࡸ࡭ࡴࠢࡲࡪࠥࡺࡨࡦࠢࡊࡒ࡚ࠦࡇࡦࡰࡨࡶࡦࡲࠠࡑࡷࡥࡰ࡮ࡩࠠࡍ࡫ࡦࡩࡳࡹࡥࠡࡣࡶࠤࡵࡻࡢ࡭࡫ࡶ࡬ࡪࡪࠠࡣࡻࠍࠤࠥࠦࠠࡵࡪࡨࠤࡋࡸࡥࡦࠢࡖࡳ࡫ࡺࡷࡢࡴࡨࠤࡋࡵࡵ࡯ࡦࡤࡸ࡮ࡵ࡮࠭ࠢࡨ࡭ࡹ࡮ࡥࡳࠢࡹࡩࡷࡹࡩࡰࡰࠣ࠷ࠥࡵࡦࠡࡶ࡫ࡩࠥࡒࡩࡤࡧࡱࡷࡪ࠲ࠠࡰࡴࠍࠤࠥࠦࠠࠩࡣࡷࠤࡾࡵࡵࡳࠢࡲࡴࡹ࡯࡯࡯ࠫࠣࡥࡳࡿࠠ࡭ࡣࡷࡩࡷࠦࡶࡦࡴࡶ࡭ࡴࡴ࠮ࠋࠌࠣࠤࠥࠦࡔࡩ࡫ࡶࠤࡵࡸ࡯ࡨࡴࡤࡱࠥ࡯ࡳࠡࡦ࡬ࡷࡹࡸࡩࡣࡷࡷࡩࡩࠦࡩ࡯ࠢࡷ࡬ࡪࠦࡨࡰࡲࡨࠤࡹ࡮ࡡࡵࠢ࡬ࡸࠥࡽࡩ࡭࡮ࠣࡦࡪࠦࡵࡴࡧࡩࡹࡱ࠲ࠊࠡࠢࠣࠤࡧࡻࡴ࡙ࠡࡌࡘࡍࡕࡕࡕࠢࡄࡒ࡞ࠦࡗࡂࡔࡕࡅࡓ࡚࡙࠼ࠢࡺ࡭ࡹ࡮࡯ࡶࡶࠣࡩࡻ࡫࡮ࠡࡶ࡫ࡩࠥ࡯࡭ࡱ࡮࡬ࡩࡩࠦࡷࡢࡴࡵࡥࡳࡺࡹࠡࡱࡩࠎࠥࠦࠠࠡࡏࡈࡖࡈࡎࡁࡏࡖࡄࡆࡎࡒࡉࡕ࡛ࠣࡳࡷࠦࡆࡊࡖࡑࡉࡘ࡙ࠠࡇࡑࡕࠤࡆࠦࡐࡂࡔࡗࡍࡈ࡛ࡌࡂࡔࠣࡔ࡚ࡘࡐࡐࡕࡈ࠲ࠥࠦࡓࡦࡧࠣࡸ࡭࡫ࠊࠡࠢࠣࠤࡌࡔࡕࠡࡉࡨࡲࡪࡸࡡ࡭ࠢࡓࡹࡧࡲࡩࡤࠢࡏ࡭ࡨ࡫࡮ࡴࡧࠣࡪࡴࡸࠠ࡮ࡱࡵࡩࠥࡪࡥࡵࡣ࡬ࡰࡸ࠴ࠊࠋࠢࠣࠤࠥ࡟࡯ࡶࠢࡶ࡬ࡴࡻ࡬ࡥࠢ࡫ࡥࡻ࡫ࠠࡳࡧࡦࡩ࡮ࡼࡥࡥࠢࡤࠤࡨࡵࡰࡺࠢࡲࡪࠥࡺࡨࡦࠢࡊࡒ࡚ࠦࡇࡦࡰࡨࡶࡦࡲࠠࡑࡷࡥࡰ࡮ࡩࠠࡍ࡫ࡦࡩࡳࡹࡥࠋࠢࠣࠤࠥࡧ࡬ࡰࡰࡪࠤࡼ࡯ࡴࡩࠢࡷ࡬࡮ࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭࠯ࠢࠣࡍ࡫ࠦ࡮ࡰࡶ࠯ࠤࡸ࡫ࡥࠡ࠾࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡧ࡯ࡷ࠱ࡳࡷ࡭࠯࡭࡫ࡦࡩࡳࡹࡥࡴ࠱ࡁ࠲ࠏࠐࠠࠡࠢࠣࡅࡩࡧࡰࡵࡧࡧࠤ࡫ࡵࡲࠡࡷࡶࡩࠥ࡯࡮ࠡࡺࡥࡱࡨࠦࡦࡳࡱࡰ࠾ࠏࠦࠠࠡࠢ࡫ࡸࡹࡶࡳ࠻࠱࠲࡫࡮ࡺࡨࡶࡤ࠱ࡧࡴࡳ࠯ࡦ࡫ࡱࡥࡷࡹ࠯࡫ࡵ࠰ࡦࡪࡧࡵࡵ࡫ࡩࡽ࠴ࡨ࡬ࡰࡤ࠲ࡱࡦࡹࡴࡦࡴ࠲ࡴࡾࡺࡨࡰࡰ࠲࡮ࡸࡨࡥࡢࡷࡷ࡭࡫࡯ࡥࡳ࠱ࡸࡲࡵࡧࡣ࡬ࡧࡵࡷ࠴ࡶࡡࡤ࡭ࡨࡶ࠳ࡶࡹࠋࠢࠣࠤࠥࠐࠠࠡࠢࠣࡹࡸࡧࡧࡦ࠼ࠍࠎࠥࠦࠠࠡ࡫ࡩࠤࡩ࡫ࡴࡦࡥࡷࠬࡸࡵ࡭ࡦࡡࡶࡸࡷ࡯࡮ࡨࠫ࠽ࠎࠥࠦࠠࠡࠢࠣࠤࠥࡻ࡮ࡱࡣࡦ࡯ࡪࡪࠠ࠾ࠢࡸࡲࡵࡧࡣ࡬ࠪࡶࡳࡲ࡫࡟ࡴࡶࡵ࡭ࡳ࡭ࠩࠋࠌࠍ࡙ࡳࡶࡡࡤ࡭ࡨࡶࠥ࡬࡯ࡳࠢࡇࡩࡦࡴࠠࡆࡦࡺࡥࡷࡪࠧࡴࠢࡳ࠲ࡦ࠴ࡣ࠯࡭࠱ࡩ࠳ࡸࠊࠣࠤࠥ୕")
import re, random,base64
def l1ll111l1l_ef_(source):
    l1l1l_ef_ (u"ࠦࠧࠨࡄࡦࡶࡨࡧࡹࡹࠠࡸࡪࡨࡸ࡭࡫ࡲࠡࡢࡶࡳࡺࡸࡣࡦࡢࠣ࡭ࡸࠦࡐ࠯ࡃ࠱ࡇ࠳ࡑ࠮ࡆ࠰ࡕ࠲ࠥࡩ࡯ࡥࡧࡧ࠲ࠧࠨࠢୖ")
    source = source.replace(l1l1l_ef_ (u"ࠬࠦࠧୗ"), l1l1l_ef_ (u"࠭ࠧ୘"))
    if re.search(l1l1l_ef_ (u"ࠧࡦࡸࡤࡰࡡ࠮ࡦࡶࡰࡦࡸ࡮ࡵ࡮࡝ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱࠮࠿࠻ࡴࡿࡨ࠮࠭୙"), source): return True
    else: return False
def unpack(source):
    l1l1l_ef_ (u"ࠣࠤ࡙ࠥࡳࡶࡡࡤ࡭ࡶࠤࡕ࠴ࡁ࠯ࡅ࠱ࡏ࠳ࡋ࠮ࡓ࠰ࠣࡴࡦࡩ࡫ࡦࡦࠣ࡮ࡸࠦࡣࡰࡦࡨ࠲ࠧࠨࠢ୚")
    l1l1llllll_ef_, l1ll11l1l1_ef_, l1ll1l1111_ef_, count = _1ll11lll1_ef_(source)
    if count != len(l1ll11l1l1_ef_):
        raise l1ll111ll1_ef_(l1l1l_ef_ (u"ࠩࡐࡥࡱ࡬࡯ࡳ࡯ࡨࡨࠥࡶ࠮ࡢ࠰ࡦ࠲ࡰ࠴ࡥ࠯ࡴ࠱ࠤࡸࡿ࡭ࡵࡣࡥ࠲ࠬ୛"))
    try:
        unbase = l1ll11l1ll_ef_(l1ll1l1111_ef_)
    except TypeError:
        raise l1ll111ll1_ef_(l1l1l_ef_ (u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡵ࠴ࡡ࠯ࡥ࠱࡯࠳࡫࠮ࡳ࠰ࠣࡩࡳࡩ࡯ࡥ࡫ࡱ࡫࠳࠭ଡ଼"))
    def lookup(match):
        l1l1l_ef_ (u"ࠦࠧࠨࡌࡰࡱ࡮ࠤࡺࡶࠠࡴࡻࡰࡦࡴࡲࡳࠡ࡫ࡱࠤࡹ࡮ࡥࠡࡵࡼࡲࡹ࡮ࡥࡵ࡫ࡦࠤࡸࡿ࡭ࡵࡣࡥ࠲ࠧࠨࠢଢ଼")
        l1ll11llll_ef_ = match.group(0)
        return l1ll11l1l1_ef_[unbase(l1ll11llll_ef_)] or l1ll11llll_ef_
    source = re.sub(l1l1l_ef_ (u"ࡷ࠭࡜ࡣ࡞ࡺ࠯ࡡࡨࠧ୞"), lookup, l1l1llllll_ef_)
    source = source.replace(l1l1l_ef_ (u"ࠨ࡜࡝ࠩࠥୟ"), l1l1l_ef_ (u"ࠢࠨࠤୠ"))
    return _1ll11l11l_ef_(source)
def _1ll11lll1_ef_(source):
    l1l1l_ef_ (u"ࠣࠤࠥࡎࡺ࡯ࡣࡦࠢࡩࡶࡴࡳࠠࡢࠢࡶࡳࡺࡸࡣࡦࠢࡩ࡭ࡱ࡫ࠠࡵࡪࡨࠤ࡫ࡵࡵࡳࠢࡤࡶ࡬ࡹࠠ࡯ࡧࡨࡨࡪࡪࠠࡣࡻࠣࡨࡪࡩ࡯ࡥࡧࡵ࠲ࠧࠨࠢୡ")
    l1ll11ll11_ef_ = (l1l1l_ef_ (u"ࡴࠥࢁࡡ࠮ࠧࠩ࠰࠭࠭ࠬ࠲ࠠࠫࠪ࡟ࡨ࠰࠯ࠬࠡࠬࠫࡠࡩ࠱ࠩ࠭ࠢ࠭ࠫ࠭࠴ࠪࡀࠫࠪࡠ࠳ࡹࡰ࡭࡫ࡷࡠ࠭࠭࡜ࡽࠩ࡟࠭ࠧୢ"))
    args = re.search(l1ll11ll11_ef_, source, re.DOTALL).groups()
    try:
        return args[0], args[3].split(l1l1l_ef_ (u"ࠪࢀࠬୣ")), int(args[1]), int(args[2])
    except ValueError:
        raise l1ll111ll1_ef_(l1l1l_ef_ (u"ࠫࡈࡵࡲࡳࡷࡳࡸࡪࡪࠠࡱ࠰ࡤ࠲ࡨ࠴࡫࠯ࡧ࠱ࡶ࠳ࠦࡤࡢࡶࡤ࠲ࠬ୤"))
def _1ll11l11l_ef_(source):
    l1l1l_ef_ (u"ࠧࠨࠢࡔࡶࡵ࡭ࡵࠦࡳࡵࡴ࡬ࡲ࡬ࠦ࡬ࡰࡱ࡮ࡹࡵࠦࡴࡢࡤ࡯ࡩࠥ࠮࡬ࡪࡵࡷ࠭ࠥࡧ࡮ࡥࠢࡵࡩࡵࡲࡡࡤࡧࠣࡺࡦࡲࡵࡦࡵࠣ࡭ࡳࠦࡳࡰࡷࡵࡧࡪ࠴ࠢࠣࠤ୥")
    match = re.search(l1l1l_ef_ (u"ࡸࠧࡷࡣࡵࠤ࠯࠮࡟࡝ࡹ࠮࠭ࡡࡃ࡜࡜ࠤࠫ࠲࠯ࡅࠩࠣ࡞ࡠ࠿ࠬ୦"), source, re.DOTALL)
    if match:
        l1ll1111ll_ef_, l1ll111lll_ef_ = match.groups()
        l1ll111111_ef_ = len(match.group(0))
        lookup = l1ll111lll_ef_.split(l1l1l_ef_ (u"ࠧࠣ࠮ࠥࠫ୧"))
        l1ll1111l1_ef_ = l1l1l_ef_ (u"ࠨࠧࡶ࡟ࠪࠫࡤ࡞ࠩ୨") % l1ll1111ll_ef_
        for index, value in enumerate(lookup):
            source = source.replace(l1ll1111l1_ef_ % index, l1l1l_ef_ (u"ࠩࠥࠩࡸࠨࠧ୩") % value)
        return source[l1ll111111_ef_:]
    return source
def l1ll11111l_ef_(str):
    result = []
    while str:
        result.append(chr(str % 128))
        str >>= 7
    return l1l1l_ef_ (u"ࠪࠫ୪").join(reversed(result))
class l1ll11l1ll_ef_(object):
    l1l1l_ef_ (u"ࠦࠧࠨࡆࡶࡰࡦࡸࡴࡸࠠࡧࡱࡵࠤࡦࠦࡧࡪࡸࡨࡲࠥࡨࡡࡴࡧ࠱ࠤ࡜࡯࡬࡭ࠢࡨࡪ࡫࡯ࡣࡪࡧࡱࡸࡱࡿࠠࡤࡱࡱࡺࡪࡸࡴࠋࠢࠣࠤࠥࡹࡴࡳ࡫ࡱ࡫ࡸࠦࡴࡰࠢࡱࡥࡹࡻࡲࡢ࡮ࠣࡲࡺࡳࡢࡦࡴࡶ࠲ࠧࠨࠢ୫")
    l1ll11l111_ef_ = {
        62: l1l1l_ef_ (u"ࠬ࠶࠱࠳࠵࠷࠹࠻࠽࠸࠺ࡣࡥࡧࡩ࡫ࡦࡨࡪ࡬࡮ࡰࡲ࡭࡯ࡱࡳࡵࡷࡹࡴࡶࡸࡺࡼࡾࢀࡁࡃࡅࡇࡉࡋࡍࡈࡊࡌࡎࡐࡒࡔࡏࡑࡓࡕࡗ࡙࡛ࡖࡘ࡚࡜࡞ࠬ୬"),
        95: l1l1l_ef_ (u"࠭ࠠࠢࠤࠦࠨࠪࠬ࡜ࠨࠪࠬ࠮࠰࠲࠭࠯࠱࠳࠵࠷࠹࠴࠶࠸࠺࠼࠾ࡀ࠻࠽࠿ࡁࡃࡅࡇࡂࡄࡆࡈࡊࡌࡎࡉࡋࡍࡏࡑࡓࡕࡐࡒࡔࡖࡘ࡚࡜ࡗ࡙࡛࡝࡟ࡡࡣ࡞ࡠࡢࡤࡦࡨࡪࡥࡧࡩ࡫࡭࡯ࡱ࡬࡮ࡰࡲࡴࡶࡸࡳࡵࡷࡹࡻࡽࡿࡺࡼࡾࢀࢂࠬ୭")
    }
    def __init__(self, base):
        self.base = base
        if 2 <= base <= 36:
            self.unbase = lambda string: int(string, base)
        else:
            if base < 62:
                self.l1ll11l111_ef_[base] = self.l1ll11l111_ef_[62][0:base]
            elif 62 < base < 95:
                self.l1ll11l111_ef_[base] = self.l1ll11l111_ef_[95][0:base]
            try:
                self.l1ll11ll1l_ef_ = dict((cipher, index) for index, cipher in enumerate(self.l1ll11l111_ef_[base]))
            except KeyError:
                raise TypeError(l1l1l_ef_ (u"ࠧࡖࡰࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࠥࡨࡡࡴࡧࠣࡩࡳࡩ࡯ࡥ࡫ࡱ࡫࠳࠭୮"))
            self.unbase = self._1ll111l11_ef_
    def __call__(self, string):
        return self.unbase(string)
    def _1ll111l11_ef_(self, string):
        l1l1l_ef_ (u"ࠣࠤࠥࡈࡪࡩ࡯ࡥࡧࡶࠤࡦࠦࠠࡷࡣ࡯ࡹࡪࠦࡴࡰࠢࡤࡲࠥ࡯࡮ࡵࡧࡪࡩࡷ࠴ࠢࠣࠤ୯")
        l11111l_ef_ = 0
        for index, cipher in enumerate(string[::-1]):
            l11111l_ef_ += (self.base ** index) * self.l1ll11ll1l_ef_[cipher]
        return l11111l_ef_
class l1ll111ll1_ef_(Exception):
    l1l1l_ef_ (u"ࠤࠥࠦࡇࡧࡤ࡭ࡻࠣࡴࡦࡩ࡫ࡦࡦࠣࡷࡴࡻࡲࡤࡧࠣࡳࡷࠦࡧࡦࡰࡨࡶࡦࡲࠠࡦࡴࡵࡳࡷ࠴ࠠࡂࡴࡪࡹࡲ࡫࡮ࡵࠢ࡬ࡷࠥࡧࠊࠡࠢࠣࠤࡲ࡫ࡡ࡯࡫ࡱ࡫࡫ࡻ࡬ࠡࡦࡨࡷࡨࡸࡩࡱࡶ࡬ࡳࡳ࠴ࠢࠣࠤ୰")
    pass
if __name__ == l1l1l_ef_ (u"ࠥࡣࡤࡳࡡࡪࡰࡢࡣࠧୱ"):
    test = l1l1l_ef_ (u"ࠫࠬ࠭ࡥࡷࡣ࡯ࠬ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳ࠮ࡰ࠭ࡣ࠯ࡧ࠱ࡱࠬࡦ࠮ࡧ࠭ࢀ࡫࠽ࡧࡷࡱࡧࡹ࡯࡯࡯ࠪࡦ࠭ࢀࡸࡥࡵࡷࡵࡲ࠭ࡩ࠼ࡢࡁࠪࠫ࠿࡫ࠨࡱࡣࡵࡷࡪࡏ࡮ࡵࠪࡦ࠳ࡦ࠯ࠩࠪ࠭ࠫࠬࡨࡃࡣࠦࡣࠬࡂ࠸࠻࠿ࡔࡶࡵ࡭ࡳ࡭࠮ࡧࡴࡲࡱࡈ࡮ࡡࡳࡅࡲࡨࡪ࠮ࡣࠬ࠴࠼࠭࠿ࡩ࠮ࡵࡱࡖࡸࡷ࡯࡮ࡨࠪ࠶࠺࠮࠯ࡽ࠼࡫ࡩࠬࠦ࠭ࠧ࠯ࡴࡨࡴࡱࡧࡣࡦࠪ࠲ࡢ࠴࠲ࡓࡵࡴ࡬ࡲ࡬࠯ࠩࡼࡹ࡫࡭ࡱ࡫ࠨࡤ࠯࠰࠭ࢀࡪ࡛ࡦࠪࡦ࠭ࡢࡃ࡫࡜ࡥࡠࢀࢁ࡫ࠨࡤࠫࢀ࡯ࡂࡡࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠩࡧࠬࡿࡷ࡫ࡴࡶࡴࡱࠤࡩࡡࡥ࡞ࡿࡠ࠿ࡪࡃࡦࡶࡰࡦࡸ࡮ࡵ࡮ࠩࠫࡾࡶࡪࡺࡵࡳࡰࠪࡠࡡࡽࠫࠨࡿ࠾ࡧࡂ࠷ࡽ࠼ࡹ࡫࡭ࡱ࡫ࠨࡤ࠯࠰࠭ࢀ࡯ࡦࠩ࡭࡞ࡧࡢ࠯ࡻࡱ࠿ࡳ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭ࡴࡥࡸࠢࡕࡩ࡬ࡋࡸࡱࠪࠪࡠࡡࡨࠧࠬࡧࠫࡧ࠮࠱ࠧ࡝࡞ࡥࠫ࠱࠭ࡧࠨࠫ࠯࡯ࡠࡩ࡝ࠪࡿࢀࡶࡪࡺࡵࡳࡰࠣࡴࢂ࠮ࠧࡲ࠰ࡵࠬࡸ࠮࡜ࠨࠧ࡫ࠩࡹࠫࡡࠦࡲࠨࡹࠪ࠼ࠥࡤࠧࡱࠩ࠵ࠫ࠵ࠦ࡮ࠨ࠸ࠪ࠸ࠥ࠵ࠧ࠺ࠩ࡯ࠫ࠰ࠦ࠺ࠨ࠵ࠪࡵࠥࡣࠧ࠶ࠩ࠼ࠫ࡭ࠦ࠳ࠨ࠼ࠪࡧࠥ࠸ࠧࡥࠩ࠸ࠫࡤࠦ࠸ࠨ࠵ࠪ࡬ࠥ࠱ࠧࡹࠩ࠶ࠫ࠵ࠦࡆࠨ࠽ࠪ࠶ࠥ࠶ࠧࡦࠩ࡬ࠫ࠰ࠦ࠶ࠨࡅࠪ࠿ࠥ࠱ࠧࡩࠩࡰࠫࡺࠦ࠴ࠨ࠼ࠪ࠷ࠥࡄࠧ࠵ࠩ࡮ࠫࡤࠦ࠸ࠨ࠶ࠪ࠹ࠥ࡬ࠧ࡭ࠩ࠷ࠫ࠳ࠦࡻࠨࡩࠪࡾࠥࡸࠧࡪࠩࡇࠫࡅࠦࡈࠨ࡭ࠪ࡮ࠥࡦ࡞ࠪ࠭࠮ࡁࠧ࠭࠶࠵࠰࠹࠸ࠬࠨ࠷ࡤࢀ࠹ࡪࡼ࠵ࡨࡿ࠹࠹ࢂ࠶ࡢࡾ࠷࠸ࢁ࠹࠳ࡽ࠸ࡥࢀ࠺࠽ࡼ࠸ࡣࡿ࠹࠻ࢂ࠴ࡦࡾ࠹࠼ࢁ࠻࠵ࡽ࠵ࡨࢀ࠹࠽ࡼ࠷࠻ࡿ࠺࠺ࢂ࠶ࡥࡾ࠶࠶ࢁ࠺࠵ࡽ࠶࠹ࢀ࠸࠷ࡼ࠷ࡨࡿ࠷࠵ࢂ࠷࠶ࡾࡧࡳࡨࡻ࡭ࡦࡰࡷࢀࡼࡸࡩࡵࡧࡿࡹࡳ࡫ࡳࡤࡣࡳࡩࢁ࠼ࡥࡽ࠸࠵ࢀ࠻ࡩࡼ࠳ࡨࡿ࠷ࡨࢂ࠲࠳ࡾ࠺࠽ࢁ࠼࠳ࡽ࠸࠹ࢀ࠼࠾ࡼ࠶࠻ࡿ࠻࠷ࢂ࠶࠲ࠩ࠱ࡷࡵࡲࡩࡵࠪࠪࢀࠬ࠯ࠬ࠱࠮ࡾࢁ࠮࠯ࠧࠨࠩ୲")
    print unpack(test)
