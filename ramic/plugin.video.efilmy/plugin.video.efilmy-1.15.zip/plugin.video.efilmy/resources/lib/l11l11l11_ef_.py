# coding: UTF-8
import sys
l1_ef_ = sys.version_info [0] == 2
l1llll_ef_ = 2048
l1l1_ef_ = 7
def l1l1l_ef_ (ll_ef_):
	global l1111_ef_
	l1l1l1_ef_ = ord (ll_ef_ [-1])
	l11ll_ef_ = ll_ef_ [:-1]
	l11_ef_ = l1l1l1_ef_ % len (l11ll_ef_)
	l1ll_ef_ = l11ll_ef_ [:l11_ef_] + l11ll_ef_ [l11_ef_:]
	if l1_ef_:
		l1lll1_ef_ = unicode () .join ([unichr (ord (char) - l1llll_ef_ - (l1ll1_ef_ + l1l1l1_ef_) % l1l1_ef_) for l1ll1_ef_, char in enumerate (l1ll_ef_)])
	else:
		l1lll1_ef_ = str () .join ([chr (ord (char) - l1llll_ef_ - (l1ll1_ef_ + l1l1l1_ef_) % l1l1_ef_) for l1ll1_ef_, char in enumerate (l1ll_ef_)])
	return eval (l1lll1_ef_)
import urlparse,cookielib,urllib2,urllib
import time,re,os
url=l1l1l_ef_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡪ࡬ࡩ࡭࡯ࡼ࠲ࡹࡼ࠯ࠨ঵")
l11l1lll1_ef_= cookielib.LWPCookieJar()
l111llll1_ef_=l1l1l_ef_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠶࠲࠱࠴࠳࠸࠶࠷࠳࠱࠵࠵࠸ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧশ")
def l11l111ll_ef_(url,l11l1lll1_ef_=None,l11l1l111_ef_=l111llll1_ef_):
    l11l11111_ef_=l1l1l_ef_ (u"ࠩࠪষ")
    try:
        class l11l11l1l_ef_(urllib2.HTTPErrorProcessor):
            def http_response(self, request, response):
                return response
        def l11l1111l_ef_(s):
            try:
                offset=1 if s[0]==l1l1l_ef_ (u"ࠪ࠯ࠬস") else 0
                val = int(eval(s.replace(l1l1l_ef_ (u"ࠫࠦ࠱࡛࡞ࠩহ"),l1l1l_ef_ (u"ࠬ࠷ࠧ঺")).replace(l1l1l_ef_ (u"࠭ࠡࠢ࡝ࡠࠫ঻"),l1l1l_ef_ (u"ࠧ࠲়ࠩ")).replace(l1l1l_ef_ (u"ࠨ࡝ࡠࠫঽ"),l1l1l_ef_ (u"ࠩ࠳ࠫা")).replace(l1l1l_ef_ (u"ࠪࠬࠬি"),l1l1l_ef_ (u"ࠫࡸࡺࡲࠩࠩী"))[offset:]))
                return val
            except:
                pass
        if l11l1lll1_ef_==None:
            l11l1lll1_ef_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(l11l11l1l_ef_, urllib2.HTTPCookieProcessor(l11l1lll1_ef_))
        opener.addheaders = [(l1l1l_ef_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩু"), l11l1l111_ef_)]
        response = opener.open(url)
        result=l11l11111_ef_ = response.read()
        response.close()
        l11l1ll1l_ef_ = re.compile(l1l1l_ef_ (u"࠭࡮ࡢ࡯ࡨࡁࠧࡰࡳࡤࡪ࡯ࡣࡻࡩࠢࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠯ࡄ࠯ࠢ࠰ࡀࠪূ")).findall(result)[0]
        init = re.compile(l1l1l_ef_ (u"ࠧࡴࡧࡷࡘ࡮ࡳࡥࡰࡷࡷࡠ࠭࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡜ࠩ࡞ࠬࡿࡡࡹࠪ࠯ࠬࡂ࠲࠯ࡀࠨ࠯ࠬࡂ࠭ࢂࡁࠧৃ")).findall(result)[0]
        l11l1ll11_ef_ = re.compile(l1l1l_ef_ (u"ࡳࠤࡦ࡬ࡦࡲ࡬ࡦࡰࡪࡩ࠲࡬࡯ࡳ࡯࡟ࠫࡡ࠯࠻࡝ࡵ࠭ࠬ࠳࠰ࠩࡢ࠰ࡹࠦৄ")).findall(result)[0]
        l11l1l11l_ef_ = l11l1111l_ef_(init)
        lines = l11l1ll11_ef_.split(l1l1l_ef_ (u"ࠩ࠾ࠫ৅"))
        for line in lines:
            if len(line)>0 and l1l1l_ef_ (u"ࠪࡁࠬ৆") in line:
                l11l1l1l1_ef_=line.split(l1l1l_ef_ (u"ࠫࡂ࠭ে"))
                l111lllll_ef_ = l11l1111l_ef_(l11l1l1l1_ef_[1])
                l11l1l11l_ef_ = int(eval(str(l11l1l11l_ef_)+l11l1l1l1_ef_[0][-1]+str(l111lllll_ef_)))
        l11l111l1_ef_ = l11l1l11l_ef_ + len(urlparse.urlparse(url).netloc)
        u=l1l1l_ef_ (u"ࠬ࠵ࠧৈ").join(url.split(l1l1l_ef_ (u"࠭࠯ࠨ৉"))[:-1])
        query = l1l1l_ef_ (u"ࠧࠦࡵ࠲ࡧࡩࡴ࠭ࡤࡩ࡬࠳ࡱ࠵ࡣࡩ࡭ࡢ࡮ࡸࡩࡨ࡭ࡁ࡭ࡷࡨ࡮࡬ࡠࡸࡦࡁࠪࡹࠦ࡫ࡵࡦ࡬ࡱࡥࡡ࡯ࡵࡺࡩࡷࡃࠥࡴࠩ৊") % (u, l11l1ll1l_ef_, l11l111l1_ef_)
        if l1l1l_ef_ (u"ࠨࡶࡼࡴࡪࡃࠢࡩ࡫ࡧࡨࡪࡴࠢࠡࡰࡤࡱࡪࡃࠢࡱࡣࡶࡷࠧ࠭ো") in result:
            l11l11lll_ef_=re.compile(l1l1l_ef_ (u"ࠩࡱࡥࡲ࡫࠽ࠣࡲࡤࡷࡸࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧৌ")).findall(result)[0]
            query = l1l1l_ef_ (u"ࠪࠩࡸ࠵ࡣࡥࡰ࠰ࡧ࡬࡯࠯࡭࠱ࡦ࡬ࡰࡥࡪࡴࡥ࡫ࡰࡄࡶࡡࡴࡵࡀࠩࡸࠬࡪࡴࡥ࡫ࡰࡤࡼࡣ࠾ࠧࡶࠪ࡯ࡹࡣࡩ࡮ࡢࡥࡳࡹࡷࡦࡴࡀࠩࡸ্࠭") % (u,urllib.quote_plus(l11l11lll_ef_), l11l1ll1l_ef_, l11l111l1_ef_)
            time.sleep(5)
        response = opener.open(query)
        response.close()
        opener = urllib2.build_opener(l11l11l1l_ef_,urllib2.HTTPCookieProcessor(l11l1lll1_ef_))
        opener.addheaders = [(l1l1l_ef_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨৎ"), l11l1l111_ef_)]
        response = opener.open(url)
        response.close()
        return l11l1lll1_ef_
    except:
        return None
def l11l1l1ll_ef_(l1ll1l1l_ef_):
    l11l11ll1_ef_=l1l1l_ef_ (u"ࠬ࠭৏")
    if os.path.isfile(l1ll1l1l_ef_):
        l11l1lll1_ef_ = cookielib.LWPCookieJar()
        l11l1lll1_ef_.load(l1ll1l1l_ef_)
        for c in l11l1lll1_ef_:
            l11l11ll1_ef_+=l1l1l_ef_ (u"࠭ࠥࡴ࠿ࠨࡷࡀ࠭৐")%(c.name, c.value)
    return l11l11ll1_ef_
