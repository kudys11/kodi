# coding: UTF-8
import sys
l1_ef_ = sys.version_info [0] == 2
l1llll_ef_ = 2048
l1l1_ef_ = 7
def l1l1l_ef_ (ll_ef_):
	global l1111_ef_
	l1l1l1_ef_ = ord (ll_ef_ [-1])
	l11ll_ef_ = ll_ef_ [:-1]
	l11_ef_ = l1l1l1_ef_ % len (l11ll_ef_)
	l1ll_ef_ = l11ll_ef_ [:l11_ef_] + l11ll_ef_ [l11_ef_:]
	if l1_ef_:
		l1lll1_ef_ = unicode () .join ([unichr (ord (char) - l1llll_ef_ - (l1ll1_ef_ + l1l1l1_ef_) % l1l1_ef_) for l1ll1_ef_, char in enumerate (l1ll_ef_)])
	else:
		l1lll1_ef_ = str () .join ([chr (ord (char) - l1llll_ef_ - (l1ll1_ef_ + l1l1l1_ef_) % l1l1_ef_) for l1ll1_ef_, char in enumerate (l1ll_ef_)])
	return eval (l1lll1_ef_)
import threading
import xbmc,xbmcgui
import time,re,os
try: from shutil import rmtree
except: rmtree = False
def l1l_ef_(l1l11l_ef_,l1l11_ef_=[l1l1l_ef_ (u"ࠫࠬࠀ")]):
    debug=1
def l111l_ef_(name=l1l1l_ef_ (u"ࠬ࠭ࠁ")):
    debug=1
def l11l_ef_(top):
    debug=1
def check():
    debug=1
try:
    debug=1
except: pass
