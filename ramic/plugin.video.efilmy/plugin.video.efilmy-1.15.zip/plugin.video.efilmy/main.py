# -*- coding: utf-8 -*-
import sys
l1_ef_ = sys.version_info [0] == 2
l1llll_ef_ = 2048
l1l1_ef_ = 7
def l1l1l_ef_ (ll_ef_):
	global l1111_ef_
	l1l1l1_ef_ = ord (ll_ef_ [-1])
	l11ll_ef_ = ll_ef_ [:-1]
	l11_ef_ = l1l1l1_ef_ % len (l11ll_ef_)
	l1ll_ef_ = l11ll_ef_ [:l11_ef_] + l11ll_ef_ [l11_ef_:]
	if l1_ef_:
		l1lll1_ef_ = unicode () .join ([unichr (ord (char) - l1llll_ef_ - (l1ll1_ef_ + l1l1l1_ef_) % l1l1_ef_) for l1ll1_ef_, char in enumerate (l1ll_ef_)])
	else:
		l1lll1_ef_ = str () .join ([chr (ord (char) - l1llll_ef_ - (l1ll1_ef_ + l1l1l1_ef_) % l1l1_ef_) for l1ll1_ef_, char in enumerate (l1ll_ef_)])
	return eval (l1lll1_ef_)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import urlresolver
import check,time
try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
cache = StorageServer.StorageServer(l1l1l_ef_ (u"ࠢࡦࡨ࡬ࡰࡲࡿࠢࠦ"))
l11lll1_ef_        = sys.argv[0]
l1lll1ll_ef_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l1l11ll1_ef_        = xbmcaddon.Addon()
l11l11_ef_       = l1l11ll1_ef_.getAddonInfo(l1l1l_ef_ (u"ࠨࡰࡤࡱࡪ࠭ࠧ"))
PATH        = l1l11ll1_ef_.getAddonInfo(l1l1l_ef_ (u"ࠩࡳࡥࡹ࡮ࠧࠨ"))
l1l1l11_ef_    = xbmc.translatePath(l1l11ll1_ef_.getAddonInfo(l1l1l_ef_ (u"ࠪࡴࡷࡵࡦࡪ࡮ࡨࠫࠩ"))).decode(l1l1l_ef_ (u"ࠫࡺࡺࡦ࠮࠺ࠪࠪ"))
sys.path.append( os.path.join( PATH,l1l1l_ef_ (u"ࠬࡸࡥࡴࡱࡸࡶࡨ࡫ࡳࠨࠫ"),l1l1l_ef_ (u"࠭࡬ࡪࡤࠪࠬ")))
l1ll11l1_ef_   = PATH+l1l1l_ef_ (u"ࠧ࠰ࡴࡨࡷࡴࡻࡲࡤࡧࡶ࠳ࠬ࠭")
l1l1l11l_ef_      = None
import l11l111_ef_ as l1111l_ef_
import l1l1l111_ef_ as l1lll1l1_ef_
import ramic as l1ll111_ef_
l1111l_ef_.l1ll1l1l_ef_=os.path.join(l1l1l11_ef_,l1l1l_ef_ (u"ࠨࡧࡩ࡭ࡱࡳࡹ࠯ࡥࡲࡳࡰ࡯ࡥࠨ࠮"))
l1ll1l1_ef_ = lambda x,y: ord(x)+12*y if ord(x)%2 else ord(x)
l111ll_ef_ = lambda l1ll11l_ef_: l1l1l_ef_ (u"ࠩࠪ࠯").join([chr(l1ll1l1_ef_(x,1) ) for x in l1ll11l_ef_.encode(l1l1l_ef_ (u"ࠪࡦࡦࡹࡥ࠷࠶ࠪ࠰")).strip()])
l1l111ll_ef_ = lambda l1ll11l_ef_: l1l1l_ef_ (u"ࠫࠬ࠱").join([chr(l1ll1l1_ef_(x,-1) ) for x in l1ll11l_ef_]).decode(l1l1l_ef_ (u"ࠬࡨࡡࡴࡧ࠹࠸ࠬ࠲"))
if not os.path.exists(l1l1l_ef_ (u"࠭࠯ࡩࡱࡰࡩ࠴ࡵࡳ࡮ࡥࠪ࠳")):
    tm=time.gmtime()
    try:    l11ll1l_ef_,l11l11l_ef_,l1ll111l_ef_ = l1l111ll_ef_(l1l11ll1_ef_.getSetting(l1l1l_ef_ (u"ࠧ࡬ࡱࡧࠫ࠴"))).split(l1l1l_ef_ (u"ࠨ࠼ࠪ࠵"))
    except: l11ll1l_ef_,l11l11l_ef_,l1ll111l_ef_ =  [l1l1l_ef_ (u"ࠩ࠰࠵ࠬ࠶"),l1l1l_ef_ (u"ࠪࠫ࠷"),l1l1l_ef_ (u"ࠫ࠲࠷ࠧ࠸")]
    if int(l11ll1l_ef_) != tm.tm_hour:
        try:    l1l1lll_ef_ = re.findall(l1l1l_ef_ (u"ࠬࡑࡏࡅ࠼ࠣࠬ࠳࠰࠿ࠪ࡞ࡱࠫ࠹"),urllib2.urlopen(l1l1l_ef_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡳࡣࡺ࠲࡬࡯ࡴࡩࡷࡥࡹࡸ࡫ࡲࡤࡱࡱࡸࡪࡴࡴ࠯ࡥࡲࡱ࠴ࡸࡡ࡮࡫ࡦࡷࡵࡧ࠯࡬ࡱࡧ࡭࠴ࡳࡡࡴࡶࡨࡶ࠴ࡘࡅࡂࡆࡐࡉ࠳ࡳࡤࠨ࠺")).read())[0].strip(l1l1l_ef_ (u"ࠧࠫࠩ࠻"))
        except: l1l1lll_ef_ = l1l1l_ef_ (u"ࠨࠩ࠼")
def l111111_ef_(url,data=None):
    req = urllib2.Request(url,data)
    req.add_header(l1l1l_ef_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩࡇ"), l1l1l_ef_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠺࠸࠯࠲࠱࠶࠺࠼࠴࠯࠻࠺ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫࡈ"))
    response = urllib2.urlopen(req)
    l1lll111_ef_ = response.read()
    response.close()
    return l1lll111_ef_
def l1l1l1ll_ef_(name, url, mode, l1l111l1_ef_=1, l11llll_ef_=l1l1l_ef_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫࡉ"), infoLabels=False, IsPlayable=True,fanart=l1l1l11l_ef_,l111l11_ef_=1):
    u = l1llllll_ef_({l1l1l_ef_ (u"ࠨ࡯ࡲࡨࡪ࠭ࡊ"): mode, l1l1l_ef_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭ࡋ"): name, l1l1l_ef_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫࡌ") : url, l1l1l_ef_ (u"ࠫࡵࡧࡧࡦࠩࡍ"):l1l111l1_ef_})
    l1111l1_ef_ = xbmcgui.ListItem(name)
    l1l11lll_ef_=[l1l1l_ef_ (u"ࠬࡺࡨࡶ࡯ࡥࠫࡎ"),l1l1l_ef_ (u"࠭ࡰࡰࡵࡷࡩࡷ࠭ࡏ"),l1l1l_ef_ (u"ࠧࡣࡣࡱࡲࡪࡸࠧࡐ"),l1l1l_ef_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨࡑ"),l1l1l_ef_ (u"ࠩࡦࡰࡪࡧࡲࡢࡴࡷࠫࡒ"),l1l1l_ef_ (u"ࠪࡧࡱ࡫ࡡࡳ࡮ࡲ࡫ࡴ࠭ࡓ"),l1l1l_ef_ (u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫ࠧࡔ"),l1l1l_ef_ (u"ࠬ࡯ࡣࡰࡰࠪࡕ")]
    l11l1l_ef_ = dict(zip(l1l11lll_ef_,[l11llll_ef_ for x in l1l11lll_ef_]))
    l11l1l_ef_[l1l1l_ef_ (u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦࠩࡖ")] = fanart if fanart else l11l1l_ef_[l1l1l_ef_ (u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪࡗ")]
    l1111l1_ef_.setArt(l11l1l_ef_)
    if not infoLabels:
        infoLabels={l1l1l_ef_ (u"ࠣࡶ࡬ࡸࡱ࡫ࠢࡘ"): name}
    l1111l1_ef_.setInfo(type=l1l1l_ef_ (u"ࠤࡹ࡭ࡩ࡫࡯࡙ࠣ"), infoLabels=infoLabels)
    if IsPlayable:
        l1111l1_ef_.setProperty(l1l1l_ef_ (u"ࠪࡍࡸࡖ࡬ࡢࡻࡤࡦࡱ࡫࡚ࠧ"), l1l1l_ef_ (u"ࠫࡹࡸࡵࡦ࡛ࠩ"))
    l1l111l_ef_ = []
    l1l111l_ef_.append((l1l1l_ef_ (u"ࠬࡏ࡮ࡧࡱࡵࡱࡦࡩࡪࡢࠩ࡜"), l1l1l_ef_ (u"࠭ࡘࡃࡏࡆ࠲ࡆࡩࡴࡪࡱࡱࠬࡎࡴࡦࡰࠫࠪ࡝")))
    l1111l1_ef_.addContextMenuItems(l1l111l_ef_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l1lll1ll_ef_, url=u, listitem=l1111l1_ef_,isFolder=False,totalItems=l111l11_ef_)
    xbmcplugin.addSortMethod(l1lll1ll_ef_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1l1l_ef_ (u"ࠢࠦࡔ࠯ࠤࠪ࡟ࠬࠡࠧࡓࠦ࡞"))
    return ok
def l11l1ll_ef_(name,ex_link=None, l1l111l1_ef_=0, mode=l1l1l_ef_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࡟"),iconImage=l1l1l_ef_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬࠭ࡠ"), infoLabels=None, fanart=l1l1l11l_ef_,contextmenu=None,l111l11_ef_=1):
    url = l1llllll_ef_({l1l1l_ef_ (u"ࠪࡱࡴࡪࡥࠨࡡ"): mode, l1l1l_ef_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨࡢ"): name, l1l1l_ef_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭ࡣ") : ex_link, l1l1l_ef_ (u"࠭ࡰࡢࡩࡨࠫࡤ") : l1l111l1_ef_})
    l11ll11_ef_ = xbmcgui.ListItem(name)
    if infoLabels:
        l11ll11_ef_.setInfo(type=l1l1l_ef_ (u"ࠢ࡮ࡱࡹ࡭ࡪࠨࡥ"), infoLabels=infoLabels)
    l1l11lll_ef_=[l1l1l_ef_ (u"ࠨࡶ࡫ࡹࡲࡨࠧࡦ"),l1l1l_ef_ (u"ࠩࡳࡳࡸࡺࡥࡳࠩࡧ"),l1l1l_ef_ (u"ࠪࡦࡦࡴ࡮ࡦࡴࠪࡨ"),l1l1l_ef_ (u"ࠫࡨࡲࡥࡢࡴࡤࡶࡹ࠭ࡩ"),l1l1l_ef_ (u"ࠬࡩ࡬ࡦࡣࡵࡰࡴ࡭࡯ࠨࡪ"),l1l1l_ef_ (u"࠭ࡩࡤࡱࡱࠫ࡫")]
    l11l1l_ef_ = dict(zip(l1l11lll_ef_,[iconImage for x in l1l11lll_ef_]))
    l11ll11_ef_.setArt(l11l1l_ef_)
    if contextmenu:
        l1l111l_ef_=contextmenu
        l11ll11_ef_.addContextMenuItems(l1l111l_ef_, replaceItems=True)
    else:
        l1l111l_ef_ = []
        l1l111l_ef_.append((l1l1l_ef_ (u"ࠧࡊࡰࡩࡳࡷࡳࡡࡤ࡬ࡤࠫ࡬"), l1l1l_ef_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡁࡤࡶ࡬ࡳࡳ࠮ࡉ࡯ࡨࡲ࠭ࠬ࡭")),)
        l11ll11_ef_.addContextMenuItems(l1l111l_ef_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l1lll1ll_ef_, url=url,listitem=l11ll11_ef_, isFolder=True,totalItems=l111l11_ef_)
    xbmcplugin.addSortMethod(l1lll1ll_ef_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1l1l_ef_ (u"ࠤࠨࡖ࠱࡚ࠦࠥ࠮ࠣࠩࡕࠨ࡮"))
    return ok
def l1l1111_ef_(l1ll1ll1_ef_):
    l1ll1l11_ef_ = {}
    for k, v in l1ll1ll1_ef_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l1l1l_ef_ (u"ࠪࡹࡹ࡬࠸ࠨ࡯"))
        elif isinstance(v, str):
            v.decode(l1l1l_ef_ (u"ࠫࡺࡺࡦ࠹ࠩࡰ"))
        l1ll1l11_ef_[k] = v
    return l1ll1l11_ef_
def l1llllll_ef_(query):
    return l11lll1_ef_ + l1l1l_ef_ (u"ࠬࡅࠧࡱ") + urllib.urlencode(l1l1111_ef_(query))
def l11l1l1_ef_(item,use_filmweb=l1l1l_ef_ (u"࠭ࡴࡳࡷࡨࠫࡲ"),itemType=l1l1l_ef_ (u"ࠧࡧࠩࡳ")):
    if use_filmweb==l1l1l_ef_ (u"ࠨࡶࡵࡹࡪ࠭ࡴ"):
        title= item.get(l1l1l_ef_ (u"ࠩࡷ࡭ࡹࡲࡥࠨࡵ"),l1l1l_ef_ (u"ࠪࠫࡶ"))
        year = item.get(l1l1l_ef_ (u"ࠫࡾ࡫ࡡࡳࠩࡷ"),l1l1l_ef_ (u"ࠬ࠭ࡸ"))
        print title,year
        data = l1lll1l1_ef_.searchFilmweb(title.decode(l1l1l_ef_ (u"࠭ࡵࡵࡨ࠰࠼ࠬࡹ")),year.strip(),itemType)
        if data:
            item.update(data)
    item[l1l1l_ef_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࡺ")] += item.get(l1l1l_ef_ (u"ࠨࡣࡸࡨ࡮ࡵࠧࡻ"),l1l1l_ef_ (u"ࠩࠪࡼ"))
    return item
def l1lllll1_ef_(ex_link):
    l1l1ll1l_ef_ = l1l11ll1_ef_.getSetting(l1l1l_ef_ (u"ࠪࡪ࡮ࡲ࡭ࡸࡧࡥࡣ࡫࠭ࡽ"))
    l111l1l_ef_,l1ll1111_ef_ = l1111l_ef_.l1llll1_ef_(ex_link)
    if l1ll1111_ef_[0]:
        l1l1l1ll_ef_(name=l1l1l_ef_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟࠿ࡀࠥࡖ࡯ࡱࡴࡽࡩࡩࡴࡩࡢࠢࡶࡸࡷࡵ࡮ࡢࠢ࠿ࡀࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࡾ"), url=l1ll1111_ef_[0], mode=l1l1l_ef_ (u"ࠬࡥ࡟ࡱࡣࡪࡩࡤࡥࡍࠨࡿ"), IsPlayable=False)
    items=len(l111l1l_ef_)
    for f in l111l1l_ef_:
        f=l11l1l1_ef_(f,l1l1ll1l_ef_,l1l1l_ef_ (u"࠭ࡦࠨࢀ"))
        l1l1l1ll_ef_(name=f.get(l1l1l_ef_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࢁ")), url=f.get(l1l1l_ef_ (u"ࠨࡷࡵࡰࠬࢂ")), mode=l1l1l_ef_ (u"ࠩࡪࡩࡹࡒࡩ࡯࡭ࡶࠫࢃ"), l11llll_ef_=f.get(l1l1l_ef_ (u"ࠪ࡭ࡲ࡭ࠧࢄ")), infoLabels=f, IsPlayable=True,l111l11_ef_=items)
    if l1ll1111_ef_[1]:
        l1l1l1ll_ef_(name=l1l1l_ef_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟ࡁࡂࠥࡔࡡࡴࡶजࡴࡳࡧࠠࡴࡶࡵࡳࡳࡧࠠ࠿ࡀ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࢅ"), url=l1ll1111_ef_[1], mode=l1l1l_ef_ (u"ࠬࡥ࡟ࡱࡣࡪࡩࡤࡥࡍࠨࢆ"), IsPlayable=False)
    xbmcplugin.setContent(l1lll1ll_ef_, l1l1l_ef_ (u"࠭࡭ࡰࡸ࡬ࡩࡸ࠭ࢇ"))
def l11lll_ef_(l1l111l1_ef_):
    print l1l1l_ef_ (u"ࠧࡍ࡫ࡶࡸࡘ࡫ࡲࡪࡣ࡯ࡩࠬ࢈"),l1l111l1_ef_
    l1l11l1_ef_ = l1l11ll1_ef_.getSetting(l1l1l_ef_ (u"ࠨࡨ࡬ࡰࡲࡽࡥࡣࡡࡶࠫࢉ"))
    l1ll11ll_ef_=int(l1l111l1_ef_)
    l111l1l_ef_ = l1111l_ef_.l111l1_ef_(l1ll11ll_ef_)
    if l1ll11ll_ef_>0:
        l1l1l1ll_ef_(name=l1l1l_ef_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝࠽࠾ࠣࡔࡴࡶࡲࡻࡧࡧࡲ࡮ࡧࠠࡴࡶࡵࡳࡳࡧࠠ࠽࠾࡞࠳ࡈࡕࡌࡐࡔࡠࠫࢊ"), url=ex_link, mode=l1l1l_ef_ (u"ࠪࡣࡤࡶࡡࡨࡧࡢࡣࡘ࠭ࢋ"), l1l111l1_ef_=l1ll11ll_ef_-1, IsPlayable=False)
    items=len(l111l1l_ef_)
    for f in l111l1l_ef_:
        f=l11l1l1_ef_(f,l1l11l1_ef_,l1l1l_ef_ (u"ࠫࡸ࠭ࢌ"))
        l11l1ll_ef_(name=f.get(l1l1l_ef_ (u"ࠬࡺࡩࡵ࡮ࡨࠫࢍ")), ex_link=f.get(l1l1l_ef_ (u"࠭ࡵࡳ࡮ࠪࢎ")), mode=l1l1l_ef_ (u"ࠧࡨࡧࡷࡉࡵ࡯ࡳࡰࡦࡨࡷࠬ࢏"), iconImage=f.get(l1l1l_ef_ (u"ࠨ࡫ࡰ࡫ࠬ࢐")), infoLabels=f)
    l1l1l1ll_ef_(name=l1l1l_ef_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝࠿ࡀࠣࡒࡦࡹࡴचࡲࡱࡥࠥࡹࡴࡳࡱࡱࡥࠥࠦ࠾࠿࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ࢑"), url=ex_link, mode=l1l1l_ef_ (u"ࠪࡣࡤࡶࡡࡨࡧࡢࡣࡘ࠭࢒"), l1l111l1_ef_=l1ll11ll_ef_+1, IsPlayable=False,l111l11_ef_=items)
    xbmcplugin.setContent(l1lll1ll_ef_, l1l1l_ef_ (u"ࠫࡹࡼࡳࡩࡱࡺࡷࠬ࢓"))
def l1lll11_ef_(ex_link):
    l1lll1l_ef_ = l1111l_ef_.l1l1ll11_ef_(ex_link)
    for f in l1lll1l_ef_:
        l1l1l1ll_ef_(name=f.get(l1l1l_ef_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ࢔")), url=f.get(l1l1l_ef_ (u"࠭ࡵࡳ࡮ࠪ࢕")), mode=l1l1l_ef_ (u"ࠧࡨࡧࡷࡐ࡮ࡴ࡫ࡴࠩ࢖"), l11llll_ef_=f.get(l1l1l_ef_ (u"ࠨ࡫ࡰ࡫ࠬࢗ")), infoLabels=f, IsPlayable=True)
    xbmcplugin.setContent(l1lll1ll_ef_, l1l1l_ef_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ࢘"))
def l1ll1ll_ef_(ex_link):
    l111l1l_ef_,l1ll1111_ef_ = l1111l_ef_.search(ex_link)
    if l1ll1111_ef_[0]:
        l1l1l1ll_ef_(name=l1l1l_ef_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞࠾࠿ࠤࡕࡵࡰࡳࡼࡨࡨࡳ࡯ࡡࠡࡵࡷࡶࡴࡴࡡࠡ࠾࠿࡟࠴ࡉࡏࡍࡑࡕࡡ࢙ࠬ"), url=l1ll1111_ef_[0], mode=l1l1l_ef_ (u"ࠫࡤࡥࡰࡢࡩࡨࡣࡤࡓ࢚ࠧ"), IsPlayable=False)
    items=len(l111l1l_ef_)
    for f in l111l1l_ef_:
        l1l1l1ll_ef_(name=f.get(l1l1l_ef_ (u"ࠬࡺࡩࡵ࡮ࡨ࢛ࠫ")), url=f.get(l1l1l_ef_ (u"࠭ࡵࡳ࡮ࠪ࢜")), mode=l1l1l_ef_ (u"ࠧࡨࡧࡷࡐ࡮ࡴ࡫ࡴࠩ࢝"), l11llll_ef_=f.get(l1l1l_ef_ (u"ࠨ࡫ࡰ࡫ࠬ࢞")), infoLabels=f, IsPlayable=True,l111l11_ef_=items)
    if l1ll1111_ef_[1]:
        l1l1l1ll_ef_(name=l1l1l_ef_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝࠿ࡀࠣࡒࡦࡹࡴचࡲࡱࡥࠥࡹࡴࡳࡱࡱࡥࠥࡄ࠾࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࢟"), url=l1ll1111_ef_[1], mode=l1l1l_ef_ (u"ࠪࡣࡤࡶࡡࡨࡧࡢࡣࡒ࠭ࢠ"), IsPlayable=False)
    xbmcplugin.setContent(l1lll1ll_ef_, l1l1l_ef_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫࢡ"))
def l1llll1l_ef_(ex_link):
    l11ll1_ef_ = l1111l_ef_.l1l1llll_ef_(ex_link)
    l1l11l1l_ef_=l1l1l_ef_ (u"ࠬ࠭ࢢ")
    l1lll111_ef_=l1l1l_ef_ (u"࠭ࠧࢣ")
    if len(l11ll1_ef_):
        l111ll1_ef_ = [x.get(l1l1l_ef_ (u"ࠧ࡮ࡵࡪࠫࢤ")) for x in l11ll1_ef_]
        s = xbmcgui.Dialog().select(l1l1l_ef_ (u"ࠨࡎ࡬ࡲࡰ࡯ࠧࢥ"),l111ll1_ef_)
        l1lll111_ef_=l11ll1_ef_[s].get(l1l1l_ef_ (u"ࠩ࡫ࡶࡪ࡬ࠧࢦ")) if s>-1 else l1l1l_ef_ (u"ࠪࠫࢧ")
        if not l1lll111_ef_:
            l1lll111_ef_ = l1111l_ef_.l1llll11_ef_(l11ll1_ef_[s].get(l1l1l_ef_ (u"ࠫࡹࡿࡰࡧࡵࠪࢨ"),l1l1l_ef_ (u"ࠬ࠭ࢩ")),l11ll1_ef_[s].get(l1l1l_ef_ (u"࠭ࡩࡥࠩࢪ"),l1l1l_ef_ (u"ࠧࠨࢫ")),l11ll1_ef_[s].get(l1l1l_ef_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲࠨࢬ"),l1l1l_ef_ (u"ࠩࠪࢭ")))
    if l1lll111_ef_:
        if l1l1l_ef_ (u"ࠪࡺ࡮ࡪࡺࡦࡴࠪࢮ") in l1lll111_ef_:
            l1l11l1l_ef_=l1lll111_ef_
        if l1l1l_ef_ (u"ࠫࡸࡺࡲࡦࡣࡰ࡭ࡳ࠭ࢯ") in l1lll111_ef_:
            l1l11l1l_ef_= l1111l_ef_.l1l111_ef_(l1lll111_ef_)
        if not l1l11l1l_ef_:
            l1l11l1l_ef_=l1ll111_ef_.__mysolver__.go(l1lll111_ef_)
        if not l1l11l1l_ef_:
            try:
                l1l11l1l_ef_ = urlresolver.resolve(l1lll111_ef_)
            except Exception,e:
                l1l11l1l_ef_=l1l1l_ef_ (u"ࠬ࠭ࢰ")
                s = xbmcgui.Dialog().ok(l1l1l_ef_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠࡔࡷࡵࡢ࡭ࡧࡰ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࢱ"),str(e))
    print l1l1l_ef_ (u"ࠧࡴࡶࡵࡩࡦࡳ࡟ࡶࡴ࡯ࠫࢲ"),l1l11l1l_ef_
    if l1l11l1l_ef_:
        xbmcplugin.setResolvedUrl(l1lll1ll_ef_, True, xbmcgui.ListItem(path=l1l11l1l_ef_))
    else:
        xbmcplugin.setResolvedUrl(l1lll1ll_ef_, False, xbmcgui.ListItem(path=l1l1l_ef_ (u"ࠨࠩࢳ")))
def l111lll_ef_():
    return cache.get(l1l1l_ef_ (u"ࠩ࡫࡭ࡸࡺ࡯ࡳࡻࠪࢴ")).split(l1l1l_ef_ (u"ࠪ࠿ࠬࢵ"))
def l1lll11l_ef_(l1l11l11_ef_):
    l1l11111_ef_ = l111lll_ef_()
    if l1l11111_ef_ == [l1l1l_ef_ (u"ࠫࠬࢶ")]:
        l1l11111_ef_ = []
    l1l11111_ef_.insert(0, l1l11l11_ef_)
    cache.set(l1l1l_ef_ (u"ࠬ࡮ࡩࡴࡶࡲࡶࡾ࠭ࢷ"),l1l1l_ef_ (u"࠭࠻ࠨࢸ").join(l1l11111_ef_[:50]))
def l1l11ll_ef_(l1l11l11_ef_):
    l1l11111_ef_ = l111lll_ef_()
    if l1l11111_ef_:
        cache.set(l1l1l_ef_ (u"ࠧࡩ࡫ࡶࡸࡴࡸࡹࠨࢹ"),l1l1l_ef_ (u"ࠨ࠽ࠪࢺ").join(l1l11111_ef_[:50]))
    else:
        l11111_ef_()
def l11111_ef_():
    cache.delete(l1l1l_ef_ (u"ࠩ࡫࡭ࡸࡺ࡯ࡳࡻࠪࢻ"))
mode = args.get(l1l1l_ef_ (u"ࠪࡱࡴࡪࡥࠨࢼ"), None)
fname = args.get(l1l1l_ef_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨࢽ"),[l1l1l_ef_ (u"ࠬ࠭ࢾ")])[0]
ex_link = args.get(l1l1l_ef_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧࢿ"),[l1l1l_ef_ (u"ࠧࠨࣀ")])[0]
l1l111l1_ef_ = args.get(l1l1l_ef_ (u"ࠨࡲࡤ࡫ࡪ࠭ࣁ"),[1])[0]
if mode is None:
    l11l1ll_ef_(name=l1l1l_ef_ (u"ࠩࡌࡲ࡫ࡵࡲ࡮ࡣࡦ࡮ࡦ࠭ࣂ"),mode=l1l1l_ef_ (u"ࠪࡣ࡮ࡴࡦࡰࡡࠪࣃ"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1l1l_ef_ (u"ࠫࡵࡧࡴࡩࠩࣄ")))+l1l1l_ef_ (u"ࠬ࠵ࡩࡤࡱࡱ࠲ࡵࡴࡧࠨࣅ"),infoLabels={})
    l11l1ll_ef_(name=l1l1l_ef_ (u"ࠨ࡛ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࡋ࡯࡬࡮ࡻ࡞࠳ࡈࡕࡌࡐࡔࡠࠦࣆ"),ex_link=l1l1l_ef_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡪ࡬ࡩ࡭࡯ࡼ࠲ࡹࡼ࠯ࡧ࡫࡯ࡱࡾ࠴ࡨࡵ࡯࡯ࠫࣇ"), mode=l1l1l_ef_ (u"ࠨࡎ࡬ࡷࡹࡓ࡯ࡷ࡫ࡨࡷࠬࣈ"),iconImage=l1l1l_ef_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬࠭ࣉ"),fanart=l1l1l11l_ef_)
    l11l1ll_ef_(name=l1l1l_ef_ (u"ࠥࠤ࡙ࡵࡰࠡࡈ࡬ࡰࡲࣹࡷࠣ࣊"),ex_link=l1l1l_ef_ (u"ࠫࠬ࣋"), mode=l1l1l_ef_ (u"࡚ࠬ࡯ࡱࡡࡩ࡭ࡱࡳࡹࠨ࣌"),iconImage=l1l1l_ef_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࠪ࣍"),fanart=l1l1l11l_ef_)
    l11l1ll_ef_(name=l1l1l_ef_ (u"ࠢࠡࡖࡨࡶࡦࢀࠠࡐࡩ࡯उࡩࡧ࡮ࡦࠤ࣎"),ex_link=l1l1l_ef_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡫ࡦࡪ࡮ࡰࡽ࠳ࡺࡶ࠰ࡨ࡬ࡰࡲࡿ࠮ࡱࡪࡳࡃࡨࡳࡤ࠾ࡹࡤࡸࡨ࡮ࡥࡥ࣏ࠩ"), mode=l1l1l_ef_ (u"ࠩࡦࡱࡩ࣐࠭"),iconImage=l1l1l_ef_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭࣑ࠧ"),fanart=l1l1l11l_ef_)
    l11l1ll_ef_(name=l1l1l_ef_ (u"ࠦࠥࡕࡳࡵࡣࡷࡲ࡮ࡵࠠࡅࡱࡧࡥࡳ࡫࣒ࠢ"),ex_link=l1l1l_ef_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡨࡪ࡮ࡲ࡭ࡺ࠰ࡷࡺ࠴࡬ࡩ࡭࡯ࡼ࠲ࡵ࡮ࡰࡀࡥࡰࡨࡂࡧࡤࡥࡧࡧ࣓ࠫ"), mode=l1l1l_ef_ (u"࠭ࡣ࡮ࡦࠪࣔ"),iconImage=l1l1l_ef_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫࣕ"),fanart=l1l1l11l_ef_)
    l11l1ll_ef_(name=l1l1l_ef_ (u"ࠣࠢࡀࡂࠥࡡࡉ࡞ࡍࡤࡸࡪ࡭࡯ࡳ࡫ࡨࠤࡋ࡯࡬࡮ࣵࡺ࡟࠴ࡏ࡝ࠣࣖ"),ex_link=l1l1l_ef_ (u"ࠩࡦࡥࡹ࠭ࣗ"), mode=l1l1l_ef_ (u"ࠪࡋࡦࡺࡵ࡯ࡧ࡮ࡖࡴࡱࠧࣘ"),iconImage=l1l1l_ef_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠨࣙ"),fanart=l1l1l11l_ef_)
    l11l1ll_ef_(name=l1l1l_ef_ (u"ࠧࠦ࠽࠿ࠢ࡞ࡍࡢࡘ࡯࡬ࠢࡳࡶࡴࡪࡵ࡬ࡥ࡭࡭ࡠ࠵ࡉ࡞ࠤࣚ"),ex_link=l1l1l_ef_ (u"࠭ࡹࡦࡣࡵࠫࣛ"), mode=l1l1l_ef_ (u"ࠧࡈࡣࡷࡹࡳ࡫࡫ࡓࡱ࡮ࠫࣜ"),iconImage=l1l1l_ef_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬࣝ"),fanart=l1l1l11l_ef_)
    l11l1ll_ef_(name=l1l1l_ef_ (u"ࠤ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࡔࡧࡵ࡭ࡦࡲࡥ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠤࣞ"),ex_link=l1l1l_ef_ (u"ࠪࠫࣟ"),l1l111l1_ef_=0, mode=l1l1l_ef_ (u"ࠫࡑ࡯ࡳࡵࡕࡨࡶ࡮ࡧ࡬ࡦࠩ࣠"),iconImage=l1l1l_ef_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹࡌ࡯࡭ࡦࡨࡶ࠳ࡶ࡮ࡨࠩ࣡"),fanart=l1l1l11l_ef_)
    l11l1ll_ef_(name=l1l1l_ef_ (u"ࠨࠠࡕࡱࡳࠤࡘ࡫ࡲࡪࡣ࡯࡭ࠧ࣢"),ex_link=l1l1l_ef_ (u"ࠧࠨࣣ"), mode=l1l1l_ef_ (u"ࠨࡖࡲࡴࡤࡹࡥࡳ࡫ࡤࡰࡪ࠭ࣤ"),iconImage=l1l1l_ef_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬࠭ࣥ"),fanart=l1l1l11l_ef_)
    l11l1ll_ef_(name=l1l1l_ef_ (u"ࠥࠤ࡙࡫ࡲࡢࡼࠣࡓ࡬ࡲअࡥࡣࡱࡩࣦࠧ"),ex_link=l1l1l_ef_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡧࡩ࡭ࡱࡳࡹ࠯ࡶࡹ࠳ࡸ࡫ࡲࡪࡣ࡯ࡩ࠳ࡶࡨࡱࡁࡦࡱࡩࡃࡷࡢࡶࡦ࡬ࡪࡪ࡟ࡴࠩࣧ"), mode=l1l1l_ef_ (u"ࠬࡩ࡭ࡥࠩࣨ"),iconImage=l1l1l_ef_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࣩࠪ"),fanart=l1l1l11l_ef_)
    l11l1ll_ef_(name=l1l1l_ef_ (u"ࠢࠡࡑࡶࡸࡦࡺ࡮ࡪࡱࠣࡈࡴࡪࡡ࡯ࡧࠥ࣪"),ex_link=l1l1l_ef_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡫ࡦࡪ࡮ࡰࡽ࠳ࡺࡶ࠰ࡵࡨࡶ࡮ࡧ࡬ࡦ࠰ࡳ࡬ࡵࡅࡣ࡮ࡦࡀࡥࡩࡪࡥࡥࡡࡶࠫ࣫"), mode=l1l1l_ef_ (u"ࠩࡦࡱࡩ࠭࣬"),iconImage=l1l1l_ef_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭࣭ࠧ"),fanart=l1l1l11l_ef_)
    l11l1ll_ef_(name=l1l1l_ef_ (u"ࠦࡠࡈ࡝࡜ࡅࡒࡐࡔࡘࠠࡺࡧ࡯ࡰࡴࡽ࡝ࡅ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣࡌ࡜ࡅࡒࡐࡔࡘࠠࡳࡧࡧࡡࡆ࡛ࠦࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸ࡬ࡸࡥࡦࡰࡠࡈࡠࡉࡏࡍࡑࡕࠤࡵࡻࡲࡱ࡮ࡨࡡ࡟ࡡࡃࡐࡎࡒࡖࠥ࡭࡯࡭ࡦࡠࡍࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟ࡈ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࡄ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬࡫࡭ࡺࡧࡳࡧࡨࡲࡢࡏ࡛࠰ࡅࡒࡐࡔࡘ࡝࡜࠱ࡅࡡ࣮ࠧ"),ex_link=l1l1l_ef_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡨࡪ࡮ࡲ࡭ࡺ࠰ࡷࡺ࠴ࡱࡡࡵࡧࡪࡳࡷ࡯ࡡ࠭࠸࠯ࡊࡦࡳࡩ࡭࡫࡭ࡲࡪ࠴ࡨࡵ࡯࡯࣯ࠫ"), mode=l1l1l_ef_ (u"࠭ࡌࡪࡵࡷࡑࡴࡼࡩࡦࡵࣰࠪ"),iconImage=l1l1l_ef_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࣱࠫ"),fanart=l1l1l11l_ef_)
    l11l1ll_ef_(l1l1l_ef_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡩࡵࡩࡪࡴ࡝ࡔࡼࡸ࡯ࡦࡰࠠࡇ࡫࡯ࡱࡺࡡ࠯ࡄࡑࡏࡓࡗࡣࣲࠧ"),l1l1l_ef_ (u"ࠩࠪࣳ"),mode=l1l1l_ef_ (u"ࠪࡗࡿࡻ࡫ࡢ࡬ࠪࣴ"))
    l1l1l1ll_ef_(l1l1l_ef_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤ࡬ࡵ࡬ࡥ࡟࠰ࡁࡔࡶࡣ࡫ࡧࡀ࠱ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࣵ"),l1l1l_ef_ (u"ࣶࠬ࠭"),l1l1l_ef_ (u"࠭ࡏࡱࡥ࡭ࡩࠬࣷ"),IsPlayable=False)
elif mode[0].startswith(l1l1l_ef_ (u"ࠧࡠ࡫ࡱࡪࡴࡥࠧࣸ")):l1ll111_ef_.__myinfo__.go(sys.argv)
elif mode[0] == l1l1l_ef_ (u"ࠨࡑࡳࡧ࡯࡫ࣹࠧ"):
    l1l11ll1_ef_.openSettings()
elif mode[0] == l1l1l_ef_ (u"ࠩࡢࡣࡵࡧࡧࡦࡡࡢࡑࣺࠬ"):
    url = l1llllll_ef_({l1l1l_ef_ (u"ࠪࡱࡴࡪࡥࠨࣻ"): l1l1l_ef_ (u"ࠫࡑ࡯ࡳࡵࡏࡲࡺ࡮࡫ࡳࠨࣼ"), l1l1l_ef_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࡳࡧ࡭ࡦࠩࣽ"): l1l1l_ef_ (u"࠭ࠧࣾ"), l1l1l_ef_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨࣿ") : ex_link})
    xbmc.executebuiltin(l1l1l_ef_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠫࠩࡸ࠯ࠧऀ")% url)
elif mode[0] == l1l1l_ef_ (u"ࠩࡢࡣࡵࡧࡧࡦࡡࡢࡗࠬँ"):
    url = l1llllll_ef_({l1l1l_ef_ (u"ࠪࡱࡴࡪࡥࠨं"): l1l1l_ef_ (u"ࠫࡑ࡯ࡳࡵࡕࡨࡶ࡮ࡧ࡬ࡦࠩः"), l1l1l_ef_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࡳࡧ࡭ࡦࠩऄ"): l1l1l_ef_ (u"࠭ࠧअ"), l1l1l_ef_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨआ") : l1l1l_ef_ (u"ࠨࠩइ") ,l1l1l_ef_ (u"ࠩࡳࡥ࡬࡫ࠧई"):l1l111l1_ef_})
    xbmc.executebuiltin(l1l1l_ef_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬࠭ࠫࡳࠪࠩउ")% url)
elif mode[0] ==l1l1l_ef_ (u"ࠫࡨࡳࡤࠨऊ"):
    items = l1111l_ef_.l1l1l1l1_ef_(ex_link)
    l1l1ll1l_ef_ = False
    if l1l1l_ef_ (u"ࠬ࡬ࡩ࡭࡯ࡼ࠲ࡵ࡮ࡰࠨऋ") in ex_link:
        l1l1ll1l_ef_ = l1l11ll1_ef_.getSetting(l1l1l_ef_ (u"࠭ࡦࡪ࡮ࡰࡻࡪࡨ࡟ࡧࠩऌ"))
    for f in items:
        f=l11l1l1_ef_(f,l1l1ll1l_ef_,l1l1l_ef_ (u"ࠧࡧࠩऍ"))
        l1l1l1ll_ef_(name=f.get(l1l1l_ef_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧऎ")), url=f.get(l1l1l_ef_ (u"ࠩࡸࡶࡱ࠭ए")), mode=l1l1l_ef_ (u"ࠪ࡫ࡪࡺࡌࡪࡰ࡮ࡷࠬऐ"), l11llll_ef_=f.get(l1l1l_ef_ (u"ࠫ࡮ࡳࡧࠨऑ")), infoLabels=f, IsPlayable=True)
        xbmcplugin.setContent(l1lll1ll_ef_, l1l1l_ef_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࠬऒ"))
elif mode[0].startswith(l1l1l_ef_ (u"࠭ࡔࡰࡲࡢࠫओ")):
    l1l1l1l_ef_ = mode[0].split(l1l1l_ef_ (u"ࠧࡠࠩऔ"))[-1]
    l1lllll_ef_=[l1l1l_ef_ (u"ࠨࡶࡼࡨࡿ࡯ࡥॅࠩक"), l1l1l_ef_ (u"ࠩ࠵ࠤࡹࡿࡧࡰࡦࡱ࡭ࡪ࠭ख"), l1l1l_ef_ (u"ࠪࡱ࡮࡫ࡳࡪइࡦࠫग"),l1l1l_ef_ (u"ࠫ࠸ࠦ࡭ࡪࡧࡶ࡭ऊࡩࡥࠨघ")]
    l1111ll_ef_ = [l1l1l_ef_ (u"ࠬ࠽ࠧङ"),l1l1l_ef_ (u"࠭࠱࠵ࠩच"),l1l1l_ef_ (u"ࠧ࠴࠳ࠪछ"),l1l1l_ef_ (u"ࠨ࠻࠶ࠫज")]
    s = xbmcgui.Dialog().select(l1l1l_ef_ (u"ࠩࡗࡳࡵࠦࠥࡴࠩझ")%l1l1l1l_ef_,l1lllll_ef_)
    d=l1111ll_ef_[s] if s>-1 else l1111ll_ef_[0]
    url = l1l1l_ef_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡦࡨ࡬ࡰࡲࡿ࠮ࡵࡸ࠲ࠩࡸ࠴ࡰࡩࡲࡂࡧࡲࡪ࠽ࡱࡱࡳࡹࡱࡧࡲ࡯ࡧࠩࡨࡳ࡯࠽ࠦࡵࠪञ")%(l1l1l1l_ef_,d)
    items = l1111l_ef_.l1l1l1l1_ef_(url)
    if l1l1l1l_ef_ == l1l1l_ef_ (u"ࠫ࡫࡯࡬࡮ࡻࠪट"):
        l1l1ll1l_ef_ = l1l11ll1_ef_.getSetting(l1l1l_ef_ (u"ࠬ࡬ࡩ࡭࡯ࡺࡩࡧࡥࡦࠨठ"))
        for f in items:
            f=l11l1l1_ef_(f,l1l1ll1l_ef_,l1l1l_ef_ (u"࠭ࡦࠨड"))
            l1l1l1ll_ef_(name=f.get(l1l1l_ef_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ढ")), url=f.get(l1l1l_ef_ (u"ࠨࡷࡵࡰࠬण")), mode=l1l1l_ef_ (u"ࠩࡪࡩࡹࡒࡩ࡯࡭ࡶࠫत"), l11llll_ef_=f.get(l1l1l_ef_ (u"ࠪ࡭ࡲ࡭ࠧथ")), infoLabels=f, IsPlayable=True)
        xbmcplugin.setContent(l1lll1ll_ef_, l1l1l_ef_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫद"))
    else:
        for f in items:
            l11l1ll_ef_(name=f.get(l1l1l_ef_ (u"ࠬࡺࡩࡵ࡮ࡨࠫध")), ex_link=f.get(l1l1l_ef_ (u"࠭ࡵࡳ࡮ࠪन")), mode=l1l1l_ef_ (u"ࠧࡨࡧࡷࡉࡵ࡯ࡳࡰࡦࡨࡷࠬऩ"), iconImage=f.get(l1l1l_ef_ (u"ࠨ࡫ࡰ࡫ࠬप")), infoLabels=f)
        xbmcplugin.setContent(l1lll1ll_ef_, l1l1l_ef_ (u"ࠩࡷࡺࡸ࡮࡯ࡸࡵࠪफ"))
elif mode[0] == l1l1l_ef_ (u"ࠪࡐ࡮ࡹࡴࡎࡱࡹ࡭ࡪࡹࠧब"):
    l1lllll1_ef_(ex_link)
elif mode[0] == l1l1l_ef_ (u"ࠫࡑ࡯ࡳࡵࡕࡨࡶ࡮ࡧ࡬ࡦࠩभ"):
    l11lll_ef_(l1l111l1_ef_)
elif mode[0] == l1l1l_ef_ (u"ࠬ࡭ࡥࡵࡇࡳ࡭ࡸࡵࡤࡦࡵࠪम"):
    l1lll11_ef_(ex_link)
elif mode[0] == l1l1l_ef_ (u"࠭ࡧࡦࡶࡏ࡭ࡳࡱࡳࠨय"):
    l1llll1l_ef_(ex_link)
elif mode[0] == l1l1l_ef_ (u"ࠧࡍ࡫ࡶࡸࡘ࡫ࡡࡳࡥ࡫ࠫर"):
    l1ll1ll_ef_(ex_link)
elif mode[0] == l1l1l_ef_ (u"ࠨࡉࡤࡸࡺࡴࡥ࡬ࡔࡲ࡯ࠬऱ"):
    data = l1111l_ef_.l1l1111l_ef_(ex_link)
    if data:
        label = [x[0].strip() for x in data]
        url = [x[1].strip() for x in data]
        l11111l_ef_ = xbmcgui.Dialog().select(l1l1l_ef_ (u"࡚ࠩࡽࡧ࡯ࡥࡳࡼ࠽ࠤࠬल")+ex_link,label)
        if l11111l_ef_>-1:
            url = l1llllll_ef_({l1l1l_ef_ (u"ࠪࡱࡴࡪࡥࠨळ"): l1l1l_ef_ (u"ࠫࡑ࡯ࡳࡵࡏࡲࡺ࡮࡫ࡳࠨऴ"), l1l1l_ef_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࡳࡧ࡭ࡦࠩव"): l1l1l_ef_ (u"࠭ࠧश"), l1l1l_ef_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨष") : url[l11111l_ef_]})
            xbmc.executebuiltin(l1l1l_ef_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠫࠩࡸ࠯ࠧस")% url)
elif mode[0] == l1l1l_ef_ (u"ࠩࡒࡴࡨࡰࡥࠨह"):
    l1l11ll1_ef_.openSettings()
elif mode[0] ==l1l1l_ef_ (u"ࠪࡗࡿࡻ࡫ࡢ࡬ࠪऺ"):
    l11l1ll_ef_(l1l1l_ef_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤ࡬ࡸࡥࡦࡰࡠࡒࡴࡽࡥࠡࡕࡽࡹࡰࡧ࡮ࡪࡧ࡞࠳ࡈࡕࡌࡐࡔࡠࠫऻ"),l1l1l_ef_ (u"़ࠬ࠭"),mode=l1l1l_ef_ (u"࠭ࡓࡻࡷ࡮ࡥ࡯ࡔ࡯ࡸࡧࠪऽ"))
    l1l1lll1_ef_ = l111lll_ef_()
    if not l1l1lll1_ef_ == [l1l1l_ef_ (u"ࠧࠨा")]:
        for l1l11l11_ef_ in l1l1lll1_ef_:
            contextmenu = []
            contextmenu.append((l1l1l_ef_ (u"ࠨࡗࡶࡹॉ࠭ि"), l1l1l_ef_ (u"࡛ࠩࡆࡒࡉ࠮ࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠬࠪࡹࠩࠨी")% l1llllll_ef_({l1l1l_ef_ (u"ࠪࡱࡴࡪࡥࠨु"): l1l1l_ef_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭࡙ࡸࡻ࡮ࠨू"), l1l1l_ef_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭ृ") : l1l11l11_ef_})),)
            contextmenu.append((l1l1l_ef_ (u"࠭ࡕࡴࡷेࠤࡨࡧूआࠢ࡫࡭ࡸࡺ࡯ࡳ࡫जࠫॄ"), l1l1l_ef_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠧࡶ࠭ࠬॅ") % l1llllll_ef_({l1l1l_ef_ (u"ࠨ࡯ࡲࡨࡪ࠭ॆ"): l1l1l_ef_ (u"ࠩࡖࡾࡺࡱࡡ࡫ࡗࡶࡹࡳࡇ࡬࡭ࠩे")})),)
            l11l1ll_ef_(name=l1l11l11_ef_, ex_link=l1l11l11_ef_.replace(l1l1l_ef_ (u"ࠪࠤࠬै"),l1l1l_ef_ (u"ࠫ࠰࠭ॉ")), mode=l1l1l_ef_ (u"ࠬࡒࡩࡴࡶࡖࡩࡦࡸࡣࡩࠩॊ"), fanart=None, contextmenu=contextmenu)
elif mode[0] ==l1l1l_ef_ (u"࠭ࡓࡻࡷ࡮ࡥ࡯ࡔ࡯ࡸࡧࠪो"):
    d = xbmcgui.Dialog().input(l1l1l_ef_ (u"ࠧࡔࡼࡸ࡯ࡦࡰࠬࠡࡒࡲࡨࡦࡰࠠࡵࡻࡷࡹेࠦࡦࡪ࡮ࡰࡹ࠴ࡹࡥࡳ࡫ࡤࡰࡺ࠵ࡢࡢ࡬࡮࡭ࠬौ"), type=xbmcgui.INPUT_ALPHANUM)
    if d:
        l1lll11l_ef_(d)
        l1ll1ll_ef_(d)
elif mode[0] ==l1l1l_ef_ (u"ࠨࡕࡽࡹࡰࡧࡪࡖࡵࡸࡲ्ࠬ"):
    l1l11ll_ef_(ex_link)
    xbmc.executebuiltin(l1l1l_ef_ (u"࡛ࠩࡆࡒࡉ࠮ࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠬࠪࡹࠩࠨॎ")%  l1llllll_ef_({l1l1l_ef_ (u"ࠪࡱࡴࡪࡥࠨॏ"): l1l1l_ef_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭ࠫॐ")}))
elif mode[0] == l1l1l_ef_ (u"࡙ࠬࡺࡶ࡭ࡤ࡮࡚ࡹࡵ࡯ࡃ࡯ࡰࠬ॑"):
    l11111_ef_()
    xbmc.executebuiltin(l1l1l_ef_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠩࠧࡶ॒࠭ࠬ")%  l1llllll_ef_({l1l1l_ef_ (u"ࠧ࡮ࡱࡧࡩࠬ॓"): l1l1l_ef_ (u"ࠨࡕࡽࡹࡰࡧࡪࠨ॔")}))
elif mode[0] == l1l1l_ef_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩॕ"):
    pass
else:
    xbmcplugin.setResolvedUrl(l1lll1ll_ef_, False, xbmcgui.ListItem(path=l1l1l_ef_ (u"ࠪࠫॖ")))
xbmcplugin.endOfDirectory(l1lll1ll_ef_)
