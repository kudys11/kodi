# -*- coding: utf-8 -*-
import sys
l111l1lll1l1_mh_ = sys.version_info [0] == 2
l1111lll1l1_mh_ = 2048
l11l11lll1l1_mh_ = 7
def l11111lll1l1_mh_ (keyedStringLiteral):
	global l11llll1l1_mh_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l1lll1l1_mh_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1111lll1l1_mh_ - (charIndex + stringNr) % l11l11lll1l1_mh_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1111lll1l1_mh_ - (charIndex + stringNr) % l11l11lll1l1_mh_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urlparse,sys,urllib
params = dict(urlparse.parse_qsl(sys.argv[2].replace(l11111lll1l1_mh_ (u"ࠫࡄ࠭ࠀ"),l11111lll1l1_mh_ (u"ࠬ࠭ࠁ"))))
mode = params.get(l11111lll1l1_mh_ (u"࠭࡭ࡰࡦࡨࠫࠂ"))
fname = params.get(l11111lll1l1_mh_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫࠃ"))
ex_link = params.get(l11111lll1l1_mh_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩࠄ"))
l1llllllll1l1_mh_ = params.get(l11111lll1l1_mh_ (u"ࠩࡳࡥ࡬࡫ࠧࠅ"))
import xbmcgui,xbmc
import time,os
l1ll11lll1l1_mh_ = xbmcgui.Dialog()
import time,threading
try: from shutil import rmtree
except: rmtree = False
def lllll1l1_mh_(l1llll1lll1l1_mh_,l1l1lll1l1_mh_=[l11111lll1l1_mh_ (u"ࠪࠫࠆ")]):
    debug=1
def l1lll1lll1l1_mh_(name=l11111lll1l1_mh_ (u"ࠫࠬࠇ")):
    debug=1
def l1llllll1l1_mh_(top):
    debug=1
def l1ll1lll1l1_mh_():
    l1llll1lll1l1_mh_ = os.path.join(xbmc.translatePath(l11111lll1l1_mh_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭ࠏ")),l11111lll1l1_mh_ (u"࠭ࡡࡥࡦࡲࡲࡸ࠭ࠐ"))
    xbmc.log(l1llll1lll1l1_mh_)
    if lllll1l1_mh_(l1llll1lll1l1_mh_,[l11111lll1l1_mh_ (u"ࠧࡢ࡮࡬ࡩࡳࡽࡩࡻࡣࡵࡨࠬࠑ"),l11111lll1l1_mh_ (u"ࠨࡧࡻࡸࡪࡴࡤࡦࡴ࠱ࡥࡱ࡯ࡥ࡯ࠩࠒ")])>0:
        l1lll1lll1l1_mh_(l11111lll1l1_mh_ (u"ࠩࡺ࡭ࡿࡧࡲࡥࠩࠓ"))
        return
    l111lllll1l1_mh_ = os.path.join(xbmc.translatePath(l11111lll1l1_mh_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡵࡴࡧࡵࡨࡦࡺࡡࠨࠔ")),l11111lll1l1_mh_ (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨࠕ"),l11111lll1l1_mh_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡥࡪࡵ࡮࠯ࡰࡲࡼ࠳࠻ࠧࠖ"),l11111lll1l1_mh_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬࠗ"))
    if os.path.exists(l111lllll1l1_mh_):
        data = open(l111lllll1l1_mh_,l11111lll1l1_mh_ (u"ࠧࡳࠩ࠘")).read()
        data= re.sub(l11111lll1l1_mh_ (u"ࠨ࡞࡞࠲࠯ࡢ࡝ࠨ࠙"),l11111lll1l1_mh_ (u"ࠩࠪࠚ"),data)
        if len(re.compile(l11111lll1l1_mh_ (u"ࠪࡂ࠳࠰ࠨࡱࡱ࡯ࡷࡰࡧ࡜ࡴࠬࡷࡠࡸ࠰ࡶࠪࠩࠛ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1lll1lll1l1_mh_(l11111lll1l1_mh_ (u"ࠫࡸࡱࡩ࡯࠰ࡤࡩࡴࡴ࠮࡯ࡱࡻ࠲࠺࠭ࠜ"))
            return
        if len(re.compile(l11111lll1l1_mh_ (u"ࠬࡄ࠮ࠫࠪࡧࡥࡷࡳ࡯ࡸࡣ࡟ࡷ࠯ࡺ࡜ࡴࠬࡹ࠭ࠬࠝ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1lll1lll1l1_mh_(l11111lll1l1_mh_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡦ࡫࡯࡯࠰ࡱࡳࡽ࠴࠵ࠨࠞ"))
            return
    l111lllll1l1_mh_ = os.path.join(xbmc.translatePath(l11111lll1l1_mh_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡹࡸ࡫ࡲࡥࡣࡷࡥࠬࠟ")),l11111lll1l1_mh_ (u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬࠠ"),l11111lll1l1_mh_ (u"ࠩࡶ࡯࡮ࡴ࠮ࡹࡱࡱࡪࡱࡻࡥ࡯ࡥࡨࠫࠡ"),l11111lll1l1_mh_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩࠢ"))
    if os.path.exists(l111lllll1l1_mh_):
        data = open(l111lllll1l1_mh_,l11111lll1l1_mh_ (u"ࠫࡷ࠭ࠣ")).read()
        data= re.sub(l11111lll1l1_mh_ (u"ࠬࡢ࡛࠯ࠬ࡟ࡡࠬࠤ"),l11111lll1l1_mh_ (u"࠭ࠧࠥ"),data)
        if len(re.compile(l11111lll1l1_mh_ (u"ࠧ࠿࠰࠭ࠬࡵࡵ࡬ࡴ࡭ࡤࡠࡸ࠰ࡴ࡝ࡵ࠭ࡺ࠮࠭ࠦ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1lll1lll1l1_mh_(l11111lll1l1_mh_ (u"ࠨࡵ࡮࡭ࡳ࠴ࡸࡰࡰࡩࡰࡺ࡫࡮ࡤࡧࠪࠧ"))
            return
    l1llll1lll1l1_mh_ = os.path.join(xbmc.translatePath(l11111lll1l1_mh_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡻࡳࡦࡴࡧࡥࡹࡧࠧࠨ")),l11111lll1l1_mh_ (u"ࠪࡴࡷࡵࡦࡪ࡮ࡨࡷࠬࠩ"))
    if os.path.exists(l1llll1lll1l1_mh_):
        if lllll1l1_mh_(l1llll1lll1l1_mh_,[l11111lll1l1_mh_ (u"ࠫࡰ࡯ࡤࡴࠩࠪ")])>0:
            l1lll1lll1l1_mh_(l11111lll1l1_mh_ (u"ࠬࡽࡩࡻࡣࡵࡨࠬࠫ"))
            return
    l11lll1l1_mh_ = xbmc.translatePath(l11111lll1l1_mh_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧࠬ"))
    for f in os.listdir(l11lll1l1_mh_):
        if f.startswith(l11111lll1l1_mh_ (u"ࠧࡎࡏࡈࡗࠬ࠭")):
            l1lll1lll1l1_mh_()
            return
def l11lllll1l1_mh_():
    try:
        debug=1
    except: pass
import resources.lib.l1l1l1lll1l1_mh_
if mode is None:
    from resources.lib import l1lllll1l1_mh_
    l1lllll1l1_mh_.l1lllll1l1_mh_().root()
elif mode.startswith(l11111lll1l1_mh_ (u"ࠩࡢ࡭ࡳ࡬࡯ࡠࠩ࠯"))  :
    from resources.lib import l1lllll1l1_mh_
    l1lllll1l1_mh_.l1lllll1l1_mh_().info()
elif mode == l11111lll1l1_mh_ (u"ࠪࡥࡱࡨࡵ࡮ࡻࠪ࠰"):
    from resources.lib import l1lllll1l1_mh_
    l1lllll1l1_mh_.l1lllll1l1_mh_().l1l111lll1l1_mh_()
elif mode == l11111lll1l1_mh_ (u"ࠫࡦࡸࡴࡪࡵࡷࡷࠬ࠱"):
    from resources.lib import l1lllll1l1_mh_
    l1lllll1l1_mh_.l1lllll1l1_mh_().l1llll1l1_mh_()
elif mode == l11111lll1l1_mh_ (u"ࠬࡧࡲࡵ࡫ࡶࡸࡤࡩ࡯࡯ࡶࡨࡲࡹ࠭࠲"):
    from resources.lib import l1lllll1l1_mh_
    l1lllll1l1_mh_.l1lllll1l1_mh_().l1l1lllll1l1_mh_(ex_link)
elif mode == l11111lll1l1_mh_ (u"࠭ࡡ࡭ࡤࡸࡱࡤࡩ࡯࡯ࡶࡨࡲࡹ࠭࠳"):
    from resources.lib import l1lllll1l1_mh_
    l1lllll1l1_mh_.l1lllll1l1_mh_().l1l11llll1l1_mh_(ex_link)
elif mode == l11111lll1l1_mh_ (u"ࠧࡨࡧࡱࡶࡪࡹࠧ࠴"):
    from resources.lib import l1lllll1l1_mh_
    l1lllll1l1_mh_.l1lllll1l1_mh_().l111lll1l1_mh_()
elif mode == l11111lll1l1_mh_ (u"ࠨࡩࡨࡲࡷ࡫ࡳࡠࡥࡲࡲࡹ࡫࡮ࡵࠩ࠵"):
    from resources.lib import l1lllll1l1_mh_
    l1lllll1l1_mh_.l1lllll1l1_mh_().l11l1lll1l1_mh_(ex_link)
elif mode == l11111lll1l1_mh_ (u"ࠩ࡯࡭ࡸࡺࡡࠨ࠶"):
    from resources.lib import l1lllll1l1_mh_
    l1lllll1l1_mh_.l1lllll1l1_mh_().l11ll1lll1l1_mh_(ex_link)
elif mode == l11111lll1l1_mh_ (u"ࠪࡴࡱࡧࡹ࡚ࡖࡏࠫ࠷"):
    from resources.lib import l1lllll1l1_mh_
    l1lllll1l1_mh_.l1lllll1l1_mh_().l1lll1l1_mh_(ex_link)
elif mode == l11111lll1l1_mh_ (u"ࠫࡵࡲࡡࡺ࡛ࡗࡐࡆࡲ࡬ࠨ࠸"):
    from resources.lib import l1lllll1l1_mh_
    l1lllll1l1_mh_.l1lllll1l1_mh_().l1l1llll1l1_mh_(ex_link)
elif mode.startswith(l11111lll1l1_mh_ (u"ࠬࡥ࡟ࡱࡣࡪࡩࡤࡥ࠺ࠨ࠹")):
    from resources.lib import l1lllll1l1_mh_
    l1lllll1l1_mh_.l1lllll1l1_mh_().l111llll1l1_mh_(mode,ex_link)
elif mode.startswith(l11111lll1l1_mh_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭࠺")):
    from resources.lib import l1lllll1l1_mh_
    l1lllll1l1_mh_.l1lllll1l1_mh_().l1ll1llll1l1_mh_(mode,ex_link)
