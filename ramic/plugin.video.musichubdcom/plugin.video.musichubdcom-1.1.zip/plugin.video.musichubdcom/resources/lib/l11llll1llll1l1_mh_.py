# -*- coding: utf-8 -*-
import sys
l111l1lll1l1_mh_ = sys.version_info [0] == 2
l1111lll1l1_mh_ = 2048
l11l11lll1l1_mh_ = 7
def l11111lll1l1_mh_ (keyedStringLiteral):
	global l11llll1l1_mh_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l1lll1l1_mh_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1111lll1l1_mh_ - (charIndex + stringNr) % l11l11lll1l1_mh_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1111lll1l1_mh_ - (charIndex + stringNr) % l11l11lll1l1_mh_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import sys
from Queue import Queue
from threading import Thread
class l11llll11lll1l1_mh_(Thread):
    l11111lll1l1_mh_ (u"ࠧࠨࠢࠡࡖ࡫ࡶࡪࡧࡤࠡࡧࡻࡩࡨࡻࡴࡪࡰࡪࠤࡹࡧࡳ࡬ࡵࠣࡪࡷࡵ࡭ࠡࡣࠣ࡫࡮ࡼࡥ࡯ࠢࡷࡥࡸࡱࡳࠡࡳࡸࡩࡺ࡫ࠠࠣࠤࠥஹ")
    def __init__(self, l11lllll1lll1l1_mh_):
        Thread.__init__(self)
        self.l11lllll1lll1l1_mh_ = l11lllll1lll1l1_mh_
        self.daemon = True
        self.start()
    def run(self):
        while True:
            func, args, kargs = self.l11lllll1lll1l1_mh_.get()
            try:
                func(*args, **kargs)
            except Exception as e:
                print(e)
            finally:
                self.l11lllll1lll1l1_mh_.task_done()
class ThreadPool:
    l11111lll1l1_mh_ (u"ࠨࠢࠣࠢࡓࡳࡴࡲࠠࡰࡨࠣࡸ࡭ࡸࡥࡢࡦࡶࠤࡨࡵ࡮ࡴࡷࡰ࡭ࡳ࡭ࠠࡵࡣࡶ࡯ࡸࠦࡦࡳࡱࡰࠤࡦࠦࡱࡶࡧࡸࡩࠥࠨࠢࠣ஺")
    def __init__(self, l11lllllllll1l1_mh_):
        self.l11lllll1lll1l1_mh_ = Queue(l11lllllllll1l1_mh_)
        for _ in range(l11lllllllll1l1_mh_):
            l11llll11lll1l1_mh_(self.l11lllll1lll1l1_mh_)
    def l11lll1l1lll1l1_mh_(self, func, *args, **kargs):
        l11111lll1l1_mh_ (u"ࠢࠣࠤࠣࡅࡩࡪࠠࡢࠢࡷࡥࡸࡱࠠࡵࡱࠣࡸ࡭࡫ࠠࡲࡷࡨࡹࡪࠦࠢࠣࠤ஻")
        self.l11lllll1lll1l1_mh_.put((func, args, kargs))
    def map(self, func, l11lll1lllll1l1_mh_):
        l11111lll1l1_mh_ (u"ࠣࠤࠥࠤࡆࡪࡤࠡࡣࠣࡰ࡮ࡹࡴࠡࡱࡩࠤࡹࡧࡳ࡬ࡵࠣࡸࡴࠦࡴࡩࡧࠣࡵࡺ࡫ࡵࡦࠢࠥࠦࠧ஼")
        for args in l11lll1lllll1l1_mh_:
            self.l11lll1l1lll1l1_mh_(func, args)
    def l11lll11llll1l1_mh_(self):
        l11111lll1l1_mh_ (u"ࠤࠥࠦࠥ࡝ࡡࡪࡶࠣࡪࡴࡸࠠࡤࡱࡰࡴࡱ࡫ࡴࡪࡱࡱࠤࡴ࡬ࠠࡢ࡮࡯ࠤࡹ࡮ࡥࠡࡶࡤࡷࡰࡹࠠࡪࡰࠣࡸ࡭࡫ࠠࡲࡷࡨࡹࡪࠦࠢࠣࠤ஽")
        self.l11lllll1lll1l1_mh_.join()
