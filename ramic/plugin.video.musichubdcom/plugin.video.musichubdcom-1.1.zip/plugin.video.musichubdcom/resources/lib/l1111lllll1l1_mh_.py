# -*- coding: utf-8 -*-
import sys
l111l1lll1l1_mh_ = sys.version_info [0] == 2
l1111lll1l1_mh_ = 2048
l11l11lll1l1_mh_ = 7
def l11111lll1l1_mh_ (keyedStringLiteral):
	global l11llll1l1_mh_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l1lll1l1_mh_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1111lll1l1_mh_ - (charIndex + stringNr) % l11l11lll1l1_mh_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1111lll1l1_mh_ - (charIndex + stringNr) % l11l11lll1l1_mh_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os,json,base64
import cookielib
from urlparse import urlparse,urljoin
l1l1ll1lll1l1_mh_ = 15
l1l1lllllll1l1_mh_=l11111lll1l1_mh_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠶࠯࠳࠾ࠤ࡜࡯࡮࠷࠶࠾ࠤࡽ࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠶࠲࠰࠳࠲࠸࠷࠶࠴࠰࠴࠴࠵ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ࡡ")
try:
    from xbmc import translatePath
    from xbmcaddon import Addon
    l1ll11llll1l1_mh_    = translatePath(Addon().getAddonInfo(l11111lll1l1_mh_ (u"ࠫࡵࡸ࡯ࡧ࡫࡯ࡩࠬࡢ"))).decode(l11111lll1l1_mh_ (u"ࠬࡻࡴࡧ࠯࠻ࠫࡣ"))
    l1lllllllll1l1_mh_=os.path.join(l1ll11llll1l1_mh_,l11111lll1l1_mh_ (u"࠭ࡣࡰࡱ࡮࡭ࡪ࠭ࡤ"))
except:
    l1lllllllll1l1_mh_=l11111lll1l1_mh_ (u"ࡲࠨࡤࡲࡼ࡫࡯࡬࡮࠰ࡦࡳࡴࡱࡩࡦࠩࡥ")
l1lll1l1lll1l1_mh_ = l11111lll1l1_mh_ (u"ࠨࠩࡦ")
class l1ll1l11lll1l1_mh_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
def l111l1llll1l1_mh_(url,data=None):
    l1ll1lllll1l1_mh_ = cookielib.LWPCookieJar()
    if data:
        opener = urllib2.build_opener(l1ll1l11lll1l1_mh_, urllib2.HTTPCookieProcessor(l1ll1lllll1l1_mh_))
    else:
        opener = urllib2.build_opener( urllib2.HTTPCookieProcessor(l1ll1lllll1l1_mh_))
    opener.addheaders = [(l11111lll1l1_mh_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ࡧ"), l1l1lllllll1l1_mh_)]
    try:
        response = opener.open(url,data,l1l1ll1lll1l1_mh_)
        result= response.read()
        response.close()
    except:
        result=l1lllll1lll1l1_mh_ = e.read()
    return result
def l11l11llll1l1_mh_(l1l11lllll1l1_mh_):
    if isinstance(l1l11lllll1l1_mh_, unicode):
        l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.encode(l11111lll1l1_mh_ (u"ࠪࡹࡹ࡬࠭࠹ࠩࡨ"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠫࠫࡲࡴ࠼ࡤࡵ࠳ࠫ࡭ࡴ࠼ࠩࡩ"),l11111lll1l1_mh_ (u"ࠬࠦࠧࡪ"))
    s=l11111lll1l1_mh_ (u"࠭ࡊࡪࡐࡦ࡞ࡈࡹ࠷ࠨ࡫")
    l1l11lllll1l1_mh_ = re.sub(s.decode(l11111lll1l1_mh_ (u"ࠧࡣࡣࡶࡩ࠻࠺ࠧ࡬")),l11111lll1l1_mh_ (u"ࠨࠩ࡭"),l1l11lllll1l1_mh_)
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠩ࡟ࡲࠬ࡮"),l11111lll1l1_mh_ (u"ࠪࠫ࡯")).replace(l11111lll1l1_mh_ (u"ࠫࡡࡸࠧࡰ"),l11111lll1l1_mh_ (u"ࠬ࠭ࡱ"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"࠭ࠦ࡯ࡤࡶࡴࡀ࠭ࡲ"),l11111lll1l1_mh_ (u"ࠧࠨࡳ"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠨࠨࡴࡹࡴࡺ࠻ࠨࡴ"),l11111lll1l1_mh_ (u"ࠩࠥࠫࡵ")).replace(l11111lll1l1_mh_ (u"ࠪࠪࡦࡳࡰ࠼ࡳࡸࡳࡹࡁࠧࡶ"),l11111lll1l1_mh_ (u"ࠫࠧ࠭ࡷ"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠬࠬ࡯ࡢࡥࡸࡸࡪࡁࠧࡸ"),l11111lll1l1_mh_ (u"࠭ࣳࠨࡹ")).replace(l11111lll1l1_mh_ (u"ࠧࠧࡑࡤࡧࡺࡺࡥ࠼ࠩࡺ"),l11111lll1l1_mh_ (u"ࠨࣕࠪࡻ"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠩࠩࡥࡲࡶ࠻ࡰࡣࡦࡹࡹ࡫࠻ࠨࡼ"),l11111lll1l1_mh_ (u"ࠪࣷࠬࡽ")).replace(l11111lll1l1_mh_ (u"ࠫࠫࡧ࡭ࡱ࠽ࡒࡥࡨࡻࡴࡦ࠽ࠪࡾ"),l11111lll1l1_mh_ (u"ࠬࣙࠧࡿ"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"࠭ࠦࡢ࡯ࡳ࠿ࠬࢀ"),l11111lll1l1_mh_ (u"ࠧࠧࠩࢁ"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠨ࡞ࡸ࠴࠶࠶࠵ࠨࢂ"),l11111lll1l1_mh_ (u"ࠩईࠫࢃ")).replace(l11111lll1l1_mh_ (u"ࠪࡠࡺ࠶࠱࠱࠶ࠪࢄ"),l11111lll1l1_mh_ (u"ࠫउ࠭ࢅ"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠬࡢࡵ࠱࠳࠳࠻ࠬࢆ"),l11111lll1l1_mh_ (u"࠭इࠨࢇ")).replace(l11111lll1l1_mh_ (u"ࠧ࡝ࡷ࠳࠵࠵࠼ࠧ࢈"),l11111lll1l1_mh_ (u"ࠨईࠪࢉ"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠩ࡟ࡹ࠵࠷࠱࠺ࠩࢊ"),l11111lll1l1_mh_ (u"ࠪझࠬࢋ")).replace(l11111lll1l1_mh_ (u"ࠫࡡࡻ࠰࠲࠳࠻ࠫࢌ"),l11111lll1l1_mh_ (u"ࠬञࠧࢍ"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"࠭࡜ࡶ࠲࠴࠸࠷࠭ࢎ"),l11111lll1l1_mh_ (u"ࠧृࠩ࢏")).replace(l11111lll1l1_mh_ (u"ࠨ࡞ࡸ࠴࠶࠺࠱ࠨ࢐"),l11111lll1l1_mh_ (u"ࠩॄࠫ࢑"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠪࡠࡺ࠶࠱࠵࠶ࠪ࢒"),l11111lll1l1_mh_ (u"ࠫॉ࠭࢓")).replace(l11111lll1l1_mh_ (u"ࠬࡢࡵ࠱࠳࠷࠸ࠬ࢔"),l11111lll1l1_mh_ (u"࠭ृࠨ࢕"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠧ࡝ࡷ࠳࠴࡫࠹ࠧ࢖"),l11111lll1l1_mh_ (u"ࠨࣵࠪࢗ")).replace(l11111lll1l1_mh_ (u"ࠩ࡟ࡹ࠵࠶ࡤ࠴ࠩ࢘"),l11111lll1l1_mh_ (u"࢙ࠪࣗࠬ"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠫࡡࡻ࠰࠲࠷ࡥ࢚ࠫ"),l11111lll1l1_mh_ (u"ࠬॡ࢛ࠧ")).replace(l11111lll1l1_mh_ (u"࠭࡜ࡶ࠲࠴࠹ࡦ࠭࢜"),l11111lll1l1_mh_ (u"ࠧज़ࠩ࢝"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠨ࡞ࡸ࠴࠶࠽ࡡࠨ࢞"),l11111lll1l1_mh_ (u"ࠩॽࠫ࢟")).replace(l11111lll1l1_mh_ (u"ࠪࡠࡺ࠶࠱࠸࠻ࠪࢠ"),l11111lll1l1_mh_ (u"ࠫॾ࠭ࢡ"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠬࡢࡵ࠱࠳࠺ࡧࠬࢢ"),l11111lll1l1_mh_ (u"࠭ॼࠨࢣ")).replace(l11111lll1l1_mh_ (u"ࠧ࡝ࡷ࠳࠵࠼ࡨࠧࢤ"),l11111lll1l1_mh_ (u"ࠨॽࠪࢥ"))
    return l1l11lllll1l1_mh_
class l1111l1lll1l1_mh_:
    def l1l1111lll1l1_mh_(self,url):
        if not url:
            url = l11111lll1l1_mh_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡭ࡦࡴ࡬ࡩ࡭࡯࠱ࡴࡱ࠵ࠧࢦ")
        elif url.startswith(l11111lll1l1_mh_ (u"ࠪ࠳࠴࠭ࢧ")):
            url = l11111lll1l1_mh_ (u"ࠫ࡭ࡺࡴࡱࠩࢨ")+url
        elif url.startswith(l11111lll1l1_mh_ (u"ࠬ࠵ࠧࢩ")):
            url = urljoin(l11111lll1l1_mh_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡪࡣࡱࡩ࡭ࡱࡳ࠮ࡱ࡮࠲ࠫࢪ"),url)
        return url
    @staticmethod
    def l111111lll1l1_mh_(url=l11111lll1l1_mh_ (u"ࠧࠨࢫ")):
        if not url:
            url = l11111lll1l1_mh_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡬ࡥࡳ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭ࢬ")
        elif url.startswith(l11111lll1l1_mh_ (u"ࠩ࠲ࠫࢭ")):
            url = urljoin(l11111lll1l1_mh_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡮ࡧࡵࡦࡪ࡮ࡰ࠲ࡵࡲ࠯ࠨࢮ"),url)
        content = l111l1llll1l1_mh_(url)
        out=[]
        l111ll1lll1l1_mh_ = re.compile(l11111lll1l1_mh_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶ࠰࡫ࡷ࡯ࡤࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧࢯ"),re.DOTALL).findall(content)
        for show in l111ll1lll1l1_mh_:
            l11ll11lll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠱ࡶࡩࡷ࡯ࡡ࡭ࡧ࠲࠲࠯࠯ࠢ࠿࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࢰ"),show)
            if l11ll11lll1l1_mh_:
                l11ll1llll1l1_mh_ = l11ll11lll1l1_mh_[0][1]
                l11ll1llll1l1_mh_ = urljoin(l11111lll1l1_mh_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡪࡣࡱࡩ࡭ࡱࡳ࠮ࡱ࡮࠲ࠫࢱ"),l11ll1llll1l1_mh_) if not l11ll1llll1l1_mh_.startswith(l11111lll1l1_mh_ (u"ࠧࡩࡶࡷࡴࠬࢲ")) else l11ll1llll1l1_mh_
                title = l11ll11lll1l1_mh_[0][0].replace(l11111lll1l1_mh_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡡ࡭ࡧ࠲ࠫࢳ"),l11111lll1l1_mh_ (u"ࠩࠪࢴ")).replace(l11111lll1l1_mh_ (u"ࠪ࠱ࠬࢵ"),l11111lll1l1_mh_ (u"ࠫࠥ࠭ࢶ")).replace(l11111lll1l1_mh_ (u"ࠬ࠵ࠧࢷ"),l11111lll1l1_mh_ (u"࠭ࠧࢸ")).title()
                out.append({l11111lll1l1_mh_ (u"ࠧࡩࡴࡨࡪࠬࢹ"):l11ll11lll1l1_mh_[0][0],l11111lll1l1_mh_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࢺ"):title,l11111lll1l1_mh_ (u"ࠩ࡬ࡱ࡬࠭ࢻ"):l11ll1llll1l1_mh_})
        idx = content.find(l11111lll1l1_mh_ (u"ࠪ࡬࠸ࡄࡓࡦࡴ࡬ࡥࡱ࡫࠼࠰ࡪ࠶ࡂࠬࢼ"))
        if idx:
            l1ll1ll1lll1l1_mh_ = re.compile(l11111lll1l1_mh_ (u"ࠫࡁࡻ࡬࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬࢽ"),re.DOTALL).search(content[idx:-1])
            l1ll1ll1lll1l1_mh_ = l1ll1ll1lll1l1_mh_.group(1) if l1ll1ll1lll1l1_mh_ else l11111lll1l1_mh_ (u"ࠬ࠭ࢾ")
            l1ll1ll1lll1l1_mh_ = re.sub(l11111lll1l1_mh_ (u"ࡸࠢ࠽ࠣ࠰࠱࠭࠴ࡼ࡝ࡵࡿࡠࡳ࠯ࠪࡀ࠯࠰ࡂࠧࢿ"), l11111lll1l1_mh_ (u"ࠢࠣࣀ"), l1ll1ll1lll1l1_mh_)
            l1ll1l1llll1l1_mh_ = re.compile(l11111lll1l1_mh_ (u"ࠨ࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠱ࡶࡩࡷ࡯ࡡ࡭ࡧ࠲࠲࠯ࡅࠩࠣࡀࠫ࡟ࡣࡄ࡝ࠫࠫ࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠬࣁ")).findall(l1ll1ll1lll1l1_mh_)
            for href,title in l1ll1l1llll1l1_mh_:
                out.append({l11111lll1l1_mh_ (u"ࠩ࡫ࡶࡪ࡬ࠧࣂ"):href,l11111lll1l1_mh_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩࣃ"):title})
        return out
    @staticmethod
    def l1ll111llll1l1_mh_(url=l11111lll1l1_mh_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࡵࡨࡶ࡮ࡧ࡬ࡦ࠱ࡧࡩࡹ࡫࡫ࡵࡻࡺ࠳ࠬࣄ")):
        if not url:
            url = l11111lll1l1_mh_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡰࡢࡰࡨ࡬ࡰࡲ࠴ࡰ࡭࠱ࠪࣅ")
        if url.startswith(l11111lll1l1_mh_ (u"࠭࠯࠰ࠩࣆ")):
            url = l11111lll1l1_mh_ (u"ࠧࡩࡶࡷࡴࠬࣇ")+url
        if url.startswith(l11111lll1l1_mh_ (u"ࠨ࠱ࠪࣈ")):
            url = urljoin(l11111lll1l1_mh_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡭ࡦࡴ࡬ࡩ࡭࡯࠱ࡴࡱ࠵ࠧࣉ"),url)
        url += l11111lll1l1_mh_ (u"ࠪ࠳ࠬ࣊") if not url.endswith(l11111lll1l1_mh_ (u"ࠫ࠴࠭࣋")) else l11111lll1l1_mh_ (u"ࠬ࠭࣌")
        content = l111l1llll1l1_mh_(url)
        out=[]
        l1lll111lll1l1_mh_ = re.compile(l11111lll1l1_mh_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡮ࡵࡧࡱࡸ࠲࡭ࡲࡪࡦࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ࣍"),re.DOTALL).findall(content)
        for l1l11l1lll1l1_mh_ in l1lll111lll1l1_mh_:
            l1llll11lll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠧࡴࡧࡽࡳࡳࡢࡳࠫࠪ࡟ࡨ࠰࠯ࠧ࣎"),l1l11l1lll1l1_mh_,re.I)
            l1llll11lll1l1_mh_ = l1llll11lll1l1_mh_[0] if l1llll11lll1l1_mh_ else l11111lll1l1_mh_ (u"ࠨ࣏ࠩ")
            l1ll1111lll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠩࡒࡨࡨ࡯࡮ࡦ࡭࡟ࡷ࠯࠮࡜ࡥ࣐࠭ࠬࠫ"),l1l11l1lll1l1_mh_,re.I)
            l1ll1111lll1l1_mh_ = l1ll1111lll1l1_mh_[0] if l1ll1111lll1l1_mh_ else l11111lll1l1_mh_ (u"࣑ࠪࠫ")
            href = re.compile(l11111lll1l1_mh_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨࡴ࡫ࡱ࡫ࡱ࡫ࡰࡢࡩࡨ࠲ࡵ࡮ࡰ࡝ࡁ࡬ࡨࡂࡢࡤ࣒ࠬࠫࠥࠫ")).findall(l1l11l1lll1l1_mh_)
            l11ll1llll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠬࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࣓"),l1l11l1lll1l1_mh_)
            if href and l1llll11lll1l1_mh_ and l1ll1111lll1l1_mh_:
                l11ll1llll1l1_mh_ = urljoin(l11111lll1l1_mh_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡪࡣࡱࡩ࡭ࡱࡳ࠮ࡱ࡮࠲ࠫࣔ"),l11ll1llll1l1_mh_[0]) if not l11ll1llll1l1_mh_[0].startswith(l11111lll1l1_mh_ (u"ࠧࡩࡶࡷࡴࠬࣕ")) else l11111lll1l1_mh_ (u"ࠨࠩࣖ")
                out.append({l11111lll1l1_mh_ (u"ࠩ࡫ࡶࡪ࡬ࠧࣗ"):url+href[0],l11111lll1l1_mh_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩࣘ"):l11111lll1l1_mh_ (u"ࠫࡘ࡫ࡺࡰࡰࠣࠩࡸ࠲ࠠࡆࡲ࡬ࡾࡴࡪࠠࠦࡵࠪࣙ")%(l1llll11lll1l1_mh_,l1ll1111lll1l1_mh_),l11111lll1l1_mh_ (u"ࠬ࡯࡭ࡨࠩࣚ"):l11ll1llll1l1_mh_,
                l11111lll1l1_mh_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭ࣛ"):int(l1llll11lll1l1_mh_),l11111lll1l1_mh_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࠨࣜ"):int(l1ll1111lll1l1_mh_)})
        return out
    @staticmethod
    def l1lll1lllll1l1_mh_(out):
        l1l1l1llll1l1_mh_={}
        l11111llll1l1_mh_ = [x.get(l11111lll1l1_mh_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࠨࣝ")) for x in out]
        for s in set(l11111llll1l1_mh_):
            l1l1l1llll1l1_mh_[l11111lll1l1_mh_ (u"ࠩࡖࡩࡿࡵ࡮ࠡࠧ࠳࠶ࡩ࠭ࣞ")%s]=[out[i] for i, j in enumerate(l11111llll1l1_mh_) if j == s]
        return l1l1l1llll1l1_mh_
    @staticmethod
    def l1l1llllll1l1_mh_(url):
        content = l111l1llll1l1_mh_(url)
        l11lllllll1l1_mh_=l11111lll1l1_mh_ (u"ࠪࠫࣟ")
        l11lll1lll1l1_mh_ = re.compile(l11111lll1l1_mh_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩ࠭࠴ࠪࡀࠫ࠿࠳࡮࡬ࡲࡢ࡯ࡨࡂࠬ࣠"),re.DOTALL).findall(content)
        if l11lll1lll1l1_mh_:
            src = re.compile(l11111lll1l1_mh_ (u"ࠬࡹࡲࡤ࠿࡞ࡠࠬࠨ࡝ࠩ࠰࠭ࡃ࠮ࡡ࡜ࠨࠤࡠࠫ࣡"),re.DOTALL).findall(l11lll1lll1l1_mh_[0])
            l11lllllll1l1_mh_ = src[0] if src else l11111lll1l1_mh_ (u"࠭ࠧ࣢")
        return l11lllllll1l1_mh_
class l1ll1llllll1l1_mh_:
    @staticmethod
    def l111111lll1l1_mh_(url,l11l1l1lll1l1_mh_=None):
        if l11l1l1lll1l1_mh_:
            l11l1l1lll1l1_mh_ = l11111lll1l1_mh_ (u"ࠧࡴࡼࡸ࡯ࡦࡰ࠽ࠨࣣ")+l11l1l1lll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠨࠢࠪࣤ"),l11111lll1l1_mh_ (u"ࠩ࠮ࠫࣥ"))
            url= l11111lll1l1_mh_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡣࡱࡻࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࡸࢀࡵ࡬ࡣ࡭ࣦࠫ")
        if not url:
            url = l11111lll1l1_mh_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡲࡼ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭ࣧ")
        elif url.startswith(l11111lll1l1_mh_ (u"ࠬ࠵ࠧࣨ")):
            url = urljoin(l11111lll1l1_mh_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡦࡴࡾࡦࡪ࡮ࡰ࠲ࡵࡲ࠯ࠨࣩ"),url)
        content = l111l1llll1l1_mh_(url,l11l1l1lll1l1_mh_)
        ids = [(a.start(), a.end()) for a in re.finditer(l11111lll1l1_mh_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡼࡩࡥࡧࡲࡣ࡮ࡴࡦࡰࠤࡁࠫ࣪"), content,re.IGNORECASE)]
        ids.append( (-1,-1) )
        out=[]
        for i in range(len(ids[:-1])):
            l1lll11lll1l1_mh_ = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile(l11111lll1l1_mh_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ࣫"),re.DOTALL).search(l1lll11lll1l1_mh_)
            title = re.compile(l11111lll1l1_mh_ (u"ࠩ࠿࡬࠶ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠲ࡀࠪ࣬"),re.DOTALL).search(l1lll11lll1l1_mh_)
            l11ll1llll1l1_mh_ = re.compile(l11111lll1l1_mh_ (u"ࠪࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࣭࠭ࠧ࠭"),re.DOTALL).search(l1lll11lll1l1_mh_)
            l1ll11lllll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠫࡑ࡫࡫ࡵࡱࡵ࠾ࡡࡹࠪ࠽ࡵࡳࡥࡳࠦࡳࡵࡻ࡯ࡩࡂࠨ࡛࡟ࡀࡠ࠮ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂ࣮ࠬ"),l1lll11lll1l1_mh_)
            l1lll11llll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠬࡊ࡯ࡥࡣࡱࡽ࠿ࡢࡳࠫ࠾ࡶࡴࡦࡴࠠࡴࡶࡼࡰࡪࡃࠢ࡜ࡠࡁࡡ࠯ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࣯࠭"),l1lll11lll1l1_mh_)
            l1ll11l1lll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"࠭ࡇࡢࡶࡸࡲࡪࡱ࠺࡝ࡵ࠭ࡀࡸࡶࡡ࡯ࠢࡶࡸࡾࡲࡥ࠾ࠤ࡞ࡢࡃࡣࠪࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨࣰ"),l1lll11lll1l1_mh_)
            l1ll11lllll1l1_mh_ = l1ll11lllll1l1_mh_[0] if l1ll11lllll1l1_mh_ else l11111lll1l1_mh_ (u"ࠧࠨࣱ")
            l1lll11llll1l1_mh_ = l1lll11llll1l1_mh_[0] if l1lll11llll1l1_mh_ else l11111lll1l1_mh_ (u"ࠨࣲࠩ")
            l1ll11l1lll1l1_mh_ = l1ll11l1lll1l1_mh_[0] if l1ll11l1lll1l1_mh_ else l11111lll1l1_mh_ (u"ࠩࠪࣳ")
            code = l1ll11lllll1l1_mh_
            l1l111llll1l1_mh_ = l11111lll1l1_mh_ (u"ࠥࡐࡪࡱࡴࡰࡴ࠽ࠤࠪࡹࠠ࡝ࡰࡇࡳࡩࡧ࡮ࡺ࠼ࠣࠩࡸࠦ࡜࡯ࡉࡤࡸࡺࡴࡥ࡬࠼ࠣࠩࡸࠦ࡜࡯ࠤࣴ") %(l1ll11lllll1l1_mh_,l1lll11llll1l1_mh_,l1ll11l1lll1l1_mh_)
            if href and title:
                l11ll1llll1l1_mh_ = urljoin(l11111lll1l1_mh_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡲࡼ࡫࡯࡬࡮࠰ࡳࡰࠬࣵ"),l11ll1llll1l1_mh_.group(1)) if l11ll1llll1l1_mh_ else l11111lll1l1_mh_ (u"ࣶࠬ࠭")
                title = title.group(1)
                year =  re.findall(l11111lll1l1_mh_ (u"࠭࡜ࠩࠪ࡟ࡨࢀ࠺ࡽࠪ࡞ࠬࠫࣷ"),title)
                l1ll1l1lll1l1_mh_ = {l11111lll1l1_mh_ (u"ࠧࡩࡴࡨࡪࠬࣸ")   : href.group(1),
                       l11111lll1l1_mh_ (u"ࠨࡶ࡬ࡸࡱ࡫ࣹࠧ")  : l11l11llll1l1_mh_(title),
                       l11111lll1l1_mh_ (u"ࠩ࡬ࡱ࡬ࣺ࠭")    : l11ll1llll1l1_mh_,
                       l11111lll1l1_mh_ (u"ࠪࡴࡱࡵࡴࠨࣻ")   : l11l11llll1l1_mh_(l1l111llll1l1_mh_),
                       l11111lll1l1_mh_ (u"ࠫࡾ࡫ࡡࡳࠩࣼ")   : year[0] if year else l11111lll1l1_mh_ (u"ࠬ࠭ࣽ"),
                       l11111lll1l1_mh_ (u"࠭ࡣࡰࡦࡨࠫࣾ")   : code,
                        }
                out.append(l1ll1l1lll1l1_mh_)
        l1llll1llll1l1_mh_=False
        l1ll111lll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡟ࡣࠨ࡝ࠫࠫࠥࡂࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡱࡩࡽࡺ࡟ࡴ࡫ࡷࡩࠧࡄࡐࡰࡲࡵࡾࡪࡪ࡮ࡪࡣ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡥࡃ࠭ࣿ"),content)
        l1ll111lll1l1_mh_ = l1ll111lll1l1_mh_[0] if l1ll111lll1l1_mh_ else False
        l1llll1llll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬࡠࡤࠢ࡞ࠬࠬࠦࡃࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡲࡪࡾࡴࡠࡵ࡬ࡸࡪࠨ࠾ࡏࡣࡶࡸ࠳࠱ࡰ࡯ࡣ࠿࠳ࡩ࡯ࡶ࠿࠾࠲ࡥࡃ࠭ऀ"),content)
        l1llll1llll1l1_mh_ = l1llll1llll1l1_mh_[0] if l1llll1llll1l1_mh_ else False
        return (out, (l1ll111lll1l1_mh_,l1llll1llll1l1_mh_))
    @staticmethod
    def l111l11lll1l1_mh_():
        content = l111l1llll1l1_mh_(l11111lll1l1_mh_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡰࡺࡩ࡭ࡱࡳ࠮ࡱ࡮࠲࡯ࡴࡴࡴࡢ࡭ࡷࠫँ"))
        l11l111lll1l1_mh_=re.findall(l11111lll1l1_mh_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠯࡬ࡣࡷࡥࡱࡵࡧ࠰࠰࠭࠭ࠧࠦࡣ࡭ࡣࡶࡷࡂࠨ࡮ࡢࡸࡢࡰ࡮ࡴ࡫ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬं"),content)
        out=[]
        for href,name in l11l111lll1l1_mh_:
            out.append({l11111lll1l1_mh_ (u"ࠫ࡭ࡸࡥࡧࠩः"):href,l11111lll1l1_mh_ (u"ࠬࡺࡩࡵ࡮ࡨࠫऄ"):name})
        return out
    @staticmethod
    def l11l1lllll1l1_mh_(url):
        url = urljoin(l11111lll1l1_mh_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡦࡴࡾࡦࡪ࡮ࡰ࠲ࡵࡲ࠯ࠨअ"),url)
        content = l111l1llll1l1_mh_(url)
        l111llllll1l1_mh_=l11111lll1l1_mh_ (u"ࠧࠨआ")
        l1l1l11lll1l1_mh_=re.findall(l11111lll1l1_mh_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠪ࠱࠮ࡄ࠯࠼࠰࡫ࡩࡶࡦࡳࡥ࠿ࠩइ"),content,re.DOTALL|re.IGNORECASE)
        if l1l1l11lll1l1_mh_:
            l111llllll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧई"),l1l1l11lll1l1_mh_[0],re.DOTALL|re.IGNORECASE)
            l111llllll1l1_mh_ = l111llllll1l1_mh_[0] if l111llllll1l1_mh_ else l11111lll1l1_mh_ (u"ࠪࠫउ")
        return l111llllll1l1_mh_
