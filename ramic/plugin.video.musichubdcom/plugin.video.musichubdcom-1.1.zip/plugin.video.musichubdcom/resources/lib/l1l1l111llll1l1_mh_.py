# -*- coding: utf-8 -*-
import sys
l111l1lll1l1_mh_ = sys.version_info [0] == 2
l1111lll1l1_mh_ = 2048
l11l11lll1l1_mh_ = 7
def l11111lll1l1_mh_ (keyedStringLiteral):
	global l11llll1l1_mh_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l1lll1l1_mh_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1111lll1l1_mh_ - (charIndex + stringNr) % l11l11lll1l1_mh_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1111lll1l1_mh_ - (charIndex + stringNr) % l11l11lll1l1_mh_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import xbmcaddon
l1llll11llll1l1_mh_       = xbmcaddon.Addon().getAddonInfo(l11111lll1l1_mh_ (u"ࠩࡱࡥࡲ࡫ࠧய"))
class l1l11l1lllll1l1_mh_():
    def __init__(self,name=l1llll11llll1l1_mh_):
        try:
            import StorageServer
        except:
            import storageserverdummy as StorageServer
        self.cache = StorageServer.StorageServer(name)
    def l1l11111llll1l1_mh_(self,t):
        return t.encode(l11111lll1l1_mh_ (u"ࠪࡹࡹ࡬࠭࠹ࠩர")) if isinstance(t,unicode) else t
    def l1l1llllllll1l1_mh_(self):
        return self.cache.get(l11111lll1l1_mh_ (u"ࠫ࡭࡯ࡳࡵࡱࡵࡽࠬற")).split(l11111lll1l1_mh_ (u"ࠬࡁࠧல"))
    def l1l1l1l11lll1l1_mh_(self,entry):
        l1l111111lll1l1_mh_ = self.l1l1llllllll1l1_mh_()
        if l1l111111lll1l1_mh_ == [l11111lll1l1_mh_ (u"࠭ࠧள")]:
            l1l111111lll1l1_mh_ = []
        l1l111111lll1l1_mh_.insert(0, self.l1l11111llll1l1_mh_(entry))
        try:
            self.cache.set(l11111lll1l1_mh_ (u"ࠧࡩ࡫ࡶࡸࡴࡸࡹࠨழ"),l11111lll1l1_mh_ (u"ࡶࠩ࠾ࠫவ").join(l1l111111lll1l1_mh_[:50]))
        except:
            pass
    def l1ll1l1l1lll1l1_mh_(self,entry):
        l1l111111lll1l1_mh_ = self.l1l1llllllll1l1_mh_()
        if l1l111111lll1l1_mh_:
            try:
                self.cache.set(l11111lll1l1_mh_ (u"ࠩ࡫࡭ࡸࡺ࡯ࡳࡻࠪஶ"),l11111lll1l1_mh_ (u"ࠪ࠿ࠬஷ").join(l1l111111lll1l1_mh_[:50]))
            except:
                pass
        else:
            self.l1lll1l1llll1l1_mh_()
    def l1lll1l1llll1l1_mh_(self):
        self.cache.delete(l11111lll1l1_mh_ (u"ࠫ࡭࡯ࡳࡵࡱࡵࡽࠬஸ"))
