# coding: UTF-8
import sys
l111l1lll1l1_mh_ = sys.version_info [0] == 2
l1111lll1l1_mh_ = 2048
l11l11lll1l1_mh_ = 7
def l11111lll1l1_mh_ (keyedStringLiteral):
	global l11llll1l1_mh_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l1lll1l1_mh_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1111lll1l1_mh_ - (charIndex + stringNr) % l11l11lll1l1_mh_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1111lll1l1_mh_ - (charIndex + stringNr) % l11l11lll1l1_mh_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import threading
import xbmc,xbmcgui
import time,re,os
try: from shutil import rmtree
except: rmtree = False
def lllll1l1_mh_(l1llll1lll1l1_mh_,l1l1lll1l1_mh_=[l11111lll1l1_mh_ (u"ࠧࠨ࠻")]):
    debug=1
def l1lll1lll1l1_mh_(name=l11111lll1l1_mh_ (u"ࠨࠩ࠼")):
    debug=1
def l1llllll1l1_mh_(top):
    debug=1
def check():
    debug=1
try:
    debug=1
except: pass
