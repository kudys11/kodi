# -*- coding: utf-8 -*-
import sys
l111l1lll1l1_mh_ = sys.version_info [0] == 2
l1111lll1l1_mh_ = 2048
l11l11lll1l1_mh_ = 7
def l11111lll1l1_mh_ (keyedStringLiteral):
	global l11llll1l1_mh_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l1lll1l1_mh_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1111lll1l1_mh_ - (charIndex + stringNr) % l11l11lll1l1_mh_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1111lll1l1_mh_ - (charIndex + stringNr) % l11l11lll1l1_mh_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os,json,base64
import cookielib
from urlparse import urlparse,urljoin
def l1111l1llll1l1_mh_(l1l11lllll1l1_mh_):
    pass
l1l1ll1lll1l1_mh_ = 15
l1l1lllllll1l1_mh_=l11111lll1l1_mh_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠷࠰࠴࠿ࠥ࡝ࡩ࡯࠸࠷࠿ࠥࡾ࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠷࠳࠱࠴࠳࠹࠱࠷࠵࠱࠵࠵࠶ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧऊ")
try:
    from xbmc import translatePath
    from xbmcaddon import Addon
    l1ll11llll1l1_mh_    = translatePath(Addon().getAddonInfo(l11111lll1l1_mh_ (u"ࠬࡶࡲࡰࡨ࡬ࡰࡪ࠭ऋ"))).decode(l11111lll1l1_mh_ (u"࠭ࡵࡵࡨ࠰࠼ࠬऌ"))
    l1lllllllll1l1_mh_=os.path.join(l1ll11llll1l1_mh_,l11111lll1l1_mh_ (u"ࠧࡤࡱࡲ࡯࡮࡫ࠧऍ"))
except:
    l1lllllllll1l1_mh_=l11111lll1l1_mh_ (u"ࡳࠩࡧࡹࡵࡧ࠮ࡤࡱࡲ࡯࡮࡫ࠧऎ")
l1lll1l1lll1l1_mh_ = l11111lll1l1_mh_ (u"ࠩࠪए")
class l1ll1l11lll1l1_mh_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
def l111l1llll1l1_mh_(url,data=None):
    l1ll1lllll1l1_mh_ = cookielib.LWPCookieJar()
    if data:
        opener = urllib2.build_opener(l1ll1l11lll1l1_mh_, urllib2.HTTPCookieProcessor(l1ll1lllll1l1_mh_))
    else:
        opener = urllib2.build_opener( urllib2.HTTPCookieProcessor(l1ll1lllll1l1_mh_))
    opener.addheaders = [(l11111lll1l1_mh_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧऐ"), l1l1lllllll1l1_mh_)]
    try:
        response = opener.open(url,data,l1l1ll1lll1l1_mh_)
        result= response.read()
        response.close()
    except:
        result=l1lllll1lll1l1_mh_ = e.read()
    return result
def l11l11llll1l1_mh_(l1l11lllll1l1_mh_):
    if isinstance(l1l11lllll1l1_mh_, unicode):
        l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.encode(l11111lll1l1_mh_ (u"ࠫࡺࡺࡦ࠮࠺ࠪऑ"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠬࠬ࡬ࡵ࠽ࡥࡶ࠴ࠬࡧࡵ࠽ࠪऒ"),l11111lll1l1_mh_ (u"࠭ࠠࠨओ"))
    s=l11111lll1l1_mh_ (u"ࠧࡋ࡫ࡑࡧ࡟ࡉࡳ࠸ࠩऔ")
    l1l11lllll1l1_mh_ = re.sub(s.decode(l11111lll1l1_mh_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨक")),l11111lll1l1_mh_ (u"ࠩࠪख"),l1l11lllll1l1_mh_)
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠪࡠࡳ࠭ग"),l11111lll1l1_mh_ (u"ࠫࠬघ")).replace(l11111lll1l1_mh_ (u"ࠬࡢࡲࠨङ"),l11111lll1l1_mh_ (u"࠭ࠧच"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠧࠧࡰࡥࡷࡵࡁࠧछ"),l11111lll1l1_mh_ (u"ࠨࠩज"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠩࠩࡵࡺࡵࡴ࠼ࠩझ"),l11111lll1l1_mh_ (u"ࠪࠦࠬञ")).replace(l11111lll1l1_mh_ (u"ࠫࠫࡧ࡭ࡱ࠽ࡴࡹࡴࡺ࠻ࠨट"),l11111lll1l1_mh_ (u"ࠬࠨࠧठ"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"࠭ࠦࡰࡣࡦࡹࡹ࡫࠻ࠨड"),l11111lll1l1_mh_ (u"ࠧࣴࠩढ")).replace(l11111lll1l1_mh_ (u"ࠨࠨࡒࡥࡨࡻࡴࡦ࠽ࠪण"),l11111lll1l1_mh_ (u"ࠩࣖࠫत"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠪࠪࡦࡳࡰ࠼ࡱࡤࡧࡺࡺࡥ࠼ࠩथ"),l11111lll1l1_mh_ (u"ࠫࣸ࠭द")).replace(l11111lll1l1_mh_ (u"ࠬࠬࡡ࡮ࡲ࠾ࡓࡦࡩࡵࡵࡧ࠾ࠫध"),l11111lll1l1_mh_ (u"࣓࠭ࠨन"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠧࠧࡣࡰࡴࡀ࠭ऩ"),l11111lll1l1_mh_ (u"ࠨࠨࠪप"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠩ࡟ࡹ࠵࠷࠰࠶ࠩफ"),l11111lll1l1_mh_ (u"ࠪउࠬब")).replace(l11111lll1l1_mh_ (u"ࠫࡡࡻ࠰࠲࠲࠷ࠫभ"),l11111lll1l1_mh_ (u"ࠬऊࠧम"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"࠭࡜ࡶ࠲࠴࠴࠼࠭य"),l11111lll1l1_mh_ (u"ࠧईࠩर")).replace(l11111lll1l1_mh_ (u"ࠨ࡞ࡸ࠴࠶࠶࠶ࠨऱ"),l11111lll1l1_mh_ (u"ࠩउࠫल"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠪࡠࡺ࠶࠱࠲࠻ࠪळ"),l11111lll1l1_mh_ (u"ࠫञ࠭ऴ")).replace(l11111lll1l1_mh_ (u"ࠬࡢࡵ࠱࠳࠴࠼ࠬव"),l11111lll1l1_mh_ (u"࠭घࠨश"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠧ࡝ࡷ࠳࠵࠹࠸ࠧष"),l11111lll1l1_mh_ (u"ࠨॄࠪस")).replace(l11111lll1l1_mh_ (u"ࠩ࡟ࡹ࠵࠷࠴࠲ࠩह"),l11111lll1l1_mh_ (u"ࠪॅࠬऺ"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠫࡡࡻ࠰࠲࠶࠷ࠫऻ"),l11111lll1l1_mh_ (u"ࠬॊ़ࠧ")).replace(l11111lll1l1_mh_ (u"࠭࡜ࡶ࠲࠴࠸࠹࠭ऽ"),l11111lll1l1_mh_ (u"ࠧॄࠩा"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠨ࡞ࡸ࠴࠵࡬࠳ࠨि"),l11111lll1l1_mh_ (u"ࣶࠩࠫी")).replace(l11111lll1l1_mh_ (u"ࠪࡠࡺ࠶࠰ࡥ࠵ࠪु"),l11111lll1l1_mh_ (u"ࠫࣘ࠭ू"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠬࡢࡵ࠱࠳࠸ࡦࠬृ"),l11111lll1l1_mh_ (u"࠭ज़ࠨॄ")).replace(l11111lll1l1_mh_ (u"ࠧ࡝ࡷ࠳࠵࠺ࡧࠧॅ"),l11111lll1l1_mh_ (u"ࠨड़ࠪॆ"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"ࠩ࡟ࡹ࠵࠷࠷ࡢࠩे"),l11111lll1l1_mh_ (u"ࠪॾࠬै")).replace(l11111lll1l1_mh_ (u"ࠫࡡࡻ࠰࠲࠹࠼ࠫॉ"),l11111lll1l1_mh_ (u"ࠬॿࠧॊ"))
    l1l11lllll1l1_mh_ = l1l11lllll1l1_mh_.replace(l11111lll1l1_mh_ (u"࠭࡜ࡶ࠲࠴࠻ࡨ࠭ो"),l11111lll1l1_mh_ (u"ࠧॽࠩौ")).replace(l11111lll1l1_mh_ (u"ࠨ࡞ࡸ࠴࠶࠽ࡢࠨ्"),l11111lll1l1_mh_ (u"ࠩॾࠫॎ"))
    return l1l11lllll1l1_mh_
def l1l1111llll1l1_mh_(l111lll1lll1l1_mh_):
    l1l1l11llll1l1_mh_ = {}
    for k, v in l111lll1lll1l1_mh_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l11111lll1l1_mh_ (u"ࠪࡹࡹ࡬࠸ࠨॏ"))
        elif isinstance(v, str):
            v.decode(l11111lll1l1_mh_ (u"ࠫࡺࡺࡦ࠹ࠩॐ"))
        l1l1l11llll1l1_mh_[k] = v
    return l1l1l11llll1l1_mh_
_11ll1l1lll1l1_mh_=l11111lll1l1_mh_ (u"ࠬ࠭ࠧࠎࠌ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠥࡥࡰࡺ࡫ࡳࠣࡀࡅࡰࡺ࡫ࡳ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠐࠎࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦࠨ࡫࡬ࡦࡥࡷࡶࡴࡴࡩࡤࠤࡁࡉࡱ࡫ࡣࡵࡴࡲࡲ࡮ࡩ࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠏࠍࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠧࡸ࡯࡮ࡨࡧࡵ࠳ࡸࡵ࡮ࡨࡹࡵ࡭ࡹ࡫ࡲࠣࡀࡖ࡭ࡳ࡭ࡥࡳ࠱ࡖࡳࡳ࡭ࡷࡳ࡫ࡷࡩࡷࡂ࠯ࡢࡀ࠿࠳ࡱ࡯࠾ࠎࠌࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠦࡶࠫࡨ࠯ࡴࡱࡸࡰࠧࡄࡒࠧࡄ࠲ࡗࡴࡻ࡬࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠐࠎࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦࠨࡪࡡ࡯ࡥࡨࠦࡃࡊࡡ࡯ࡥࡨࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃࠓࠊࠎࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡ࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠤࡪ࡬ࡴࠥ࡮࡯ࡱ࠱ࡵࡥࡵࠨ࠾ࡉ࡫ࡳࠤࡍࡵࡰ࠰ࡔࡤࡴࡁ࠵ࡡ࠿࠾࠲ࡰ࡮ࡄࠍࠋࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢ࠿ࡰ࡮ࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠥࡤࡰࡹ࡫ࡲ࡯ࡣࡷ࡭ࡻ࡫ࠢ࠿ࡃ࡯ࡸࡪࡸ࡮ࡢࡶ࡬ࡺࡪࡂ࠯ࡢࡀ࠿࠳ࡱ࡯࠾ࠎࠌࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠦࡶࡴࡩ࡫ࠣࡀࡕࡳࡨࡱ࠼࠰ࡣࡁࡀ࠴ࡲࡩ࠿ࠏࠍࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࡁࡲࡩ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠧࡷ࡫ࡧࡨࡣࡨࠦࡃࡘࡥࡨࡩࡤࡩࡁ࠵ࡡ࠿࠾࠲ࡰ࡮ࡄࠍࠋࠩࠪࠫ॑")
def l1l111lllll1l1_mh_():
    out=[{l11111lll1l1_mh_ (u"࠭ࡴࡪࡶ࡯ࡩ॒ࠬ"):l11111lll1l1_mh_ (u"ࠧ࡜ࡄࡠࡅࡱࡲ࡛࠰ࡄࡠࠫ॓"),l11111lll1l1_mh_ (u"ࠨࡪࡵࡩ࡫࠭॔"):l11111lll1l1_mh_ (u"ࠩࠪॕ")}]
    for key,title in re.findall(l11111lll1l1_mh_ (u"ࠪࠦࠨ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴࠭ॖ"),_11ll1l1lll1l1_mh_):
        out.append({l11111lll1l1_mh_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪॗ"):title,l11111lll1l1_mh_ (u"ࠬ࡮ࡲࡦࡨࠪक़"):key})
    return out
def l11l1lll1l1_mh_(key=l11111lll1l1_mh_ (u"࠭ࡥ࡭ࡧࡦࡸࡷࡵ࡮ࡪࡥࠪख़")):
    l11111l1lll1l1_mh_=l11111lll1l1_mh_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡲࡻࡳࡪࡺ࡫ࡹࡧ࠴ࡣࡰ࡯࠲࡫ࡪࡴࡲࡦࡵ࠱ࡴ࡭ࡶࠧग़")
    content=l111l1llll1l1_mh_(l11111l1lll1l1_mh_)
    data=content
    out=[]
    if key:
        ids = [(a.start(), a.end()) for a in re.finditer(l11111lll1l1_mh_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡳࡦࡥࡷ࡭ࡴࡴࠠࡨࡴࡲࡹࡵࠦࡧࡦࡰࡵࡩ࠲ࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠢ࡬ࡨࡂ࠭ज़"), content)]
        ids.append( (-1,-1) )
        for i in range(len(ids[:-1])):
            l1lll11lll1l1_mh_ = content[ ids[i][1]:ids[i+1][0] ]
            if key in l1lll11lll1l1_mh_[:20]:
                data=l1lll11lll1l1_mh_
                break
    if data:
        ids = [(a.start(), a.end()) for a in re.finditer(l11111lll1l1_mh_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡵ࡫ࡷࡰࡪࡃࠢࡍ࡫ࡶࡸࡪࡴࠠࡵࡱࠣࡸ࡭࡫ࠠࡢ࡮ࡥࡹࡲࠦࠧड़"), data)]
        ids.append( (-1,-1) )
        for i in range(len(ids[:-1])):
            l1lll11lll1l1_mh_ = data[ ids[i][1]:ids[i+1][0] ]
            artist = re.findall(l11111lll1l1_mh_ (u"ࠪࡦࡾࠦࠨ࠯ࠬࡂ࠭ࠧ࠭ढ़"),l1lll11lll1l1_mh_)
            l111l1l1lll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠯ࡥࡧࡷࡥ࡮ࡲࡳ࠯ࡲ࡫ࡴࡡࡅࡴ࠾ࡣࠩ࡭ࡹࡃࠨ࠯ࠬࡂ࠭ࠧࡄࠧफ़"),l1lll11lll1l1_mh_)
            l11ll1llll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡪࡩࡷࡖࡰࡦࡎࡳࡧࠣࠢࡶࡶࡨࡃࠢࠩࡪ࠱࠮ࡄ࠯ࠢࠨय़"),l1lll11lll1l1_mh_)
            l11l11l1lll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"࠭ࠨ࡝ࡦ࠮ࠤࡹࡸࡡࡤ࡭ࡶ࠭ࠬॠ"),l1lll11lll1l1_mh_)
            name = re.findall(l11111lll1l1_mh_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡥ࡫ࡹࡘࡲࡨࡎࡢ࡯ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠳࠿ࠩॡ"),l1lll11lll1l1_mh_)
            if l111l1l1lll1l1_mh_ and name and artist:
                artist = artist[0].strip()
                name =  name[0].strip()
                l11l11l1lll1l1_mh_ = l11l11l1lll1l1_mh_[0] if l11l11l1lll1l1_mh_ else l11111lll1l1_mh_ (u"ࠨࠩॢ")
                title = l11111lll1l1_mh_ (u"ࠩࠨࡷࠥ࠳ࠠࠦࡵࠣࠤࠥࡡࠥࡴ࡟ࠪॣ")%(artist,name,l11l11l1lll1l1_mh_)
                href=urllib.urlencode(l1l1111llll1l1_mh_({l11111lll1l1_mh_ (u"ࠪࡥࡱࡨࡵ࡮ࡋࡷࡍࡩ࠭।"):l111l1l1lll1l1_mh_[0],l11111lll1l1_mh_ (u"ࠫࡦࡸࡴࡪࡵࡷࠫ॥"):artist,l11111lll1l1_mh_ (u"ࠬࡴࡡ࡮ࡧࠪ०"):name}))
                out.append({l11111lll1l1_mh_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ१"):title,l11111lll1l1_mh_ (u"ࠧࡩࡴࡨࡪࠬ२"):href,l11111lll1l1_mh_ (u"ࠨ࡫ࡰ࡫ࠬ३"):l11ll1llll1l1_mh_[0] if l11ll1llll1l1_mh_ else l11111lll1l1_mh_ (u"ࠩࠪ४")})
    return out
def l11l1111lll1l1_mh_(filename=l11111lll1l1_mh_ (u"ࠪࡥࡷࡺࡩࡴࡶࡶࡐ࡮ࡹࡴ࠯࡬ࡶࡳࡳ࠭५")):
    url= l11111lll1l1_mh_ (u"ࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯࡯ࡸࡷ࡮ࡾࡨࡶࡤ࠱ࡧࡴࡳ࠯ࡤࡣࡦ࡬ࡪ࠵ࠢ६")+filename
    data = l11l1ll1lll1l1_mh_(url)
    l11l111llll1l1_mh_=[]
    l1llll1l1_mh_ = data.get(l11111lll1l1_mh_ (u"ࠬࡧࡲࡵ࡫ࡶࡸࡸ࠭७"),{}).get(l11111lll1l1_mh_ (u"࠭ࡡࡳࡶ࡬ࡷࡹ࠭८"),[])
    for obj in l1llll1l1_mh_:
        l11l11lllll1l1_mh_={}
        l11l11lllll1l1_mh_[l11111lll1l1_mh_ (u"ࠧ࡯ࡣࡰࡩࠬ९")] = obj.get(l11111lll1l1_mh_ (u"ࠨࡰࡤࡱࡪ࠭॰"),l11111lll1l1_mh_ (u"ࠩࠪॱ"));
        l11l11lllll1l1_mh_[l11111lll1l1_mh_ (u"ࠪࡥࡷࡺࡩࡴࡶࡑࡥࡲ࡫ࠧॲ")] = obj.get(l11111lll1l1_mh_ (u"ࠫࡳࡧ࡭ࡦࠩॳ"),l11111lll1l1_mh_ (u"ࠬ࠭ॴ"))
        l11l11lllll1l1_mh_[l11111lll1l1_mh_ (u"࠭ࡴࡪࡶ࡯ࡩࠬॵ")] = obj.get(l11111lll1l1_mh_ (u"ࠧ࡯ࡣࡰࡩࠬॶ"),l11111lll1l1_mh_ (u"ࠨࠩॷ"))
        l11l11lllll1l1_mh_[l11111lll1l1_mh_ (u"ࠩ࡫ࡶࡪ࡬ࠧॸ")] = obj.get(l11111lll1l1_mh_ (u"ࠪࡲࡦࡳࡥࠨॹ"),l11111lll1l1_mh_ (u"ࠫࠬॺ"))
        l11l11lllll1l1_mh_[l11111lll1l1_mh_ (u"ࠬ࡯࡭ࡨࠩॻ")] = obj.get(l11111lll1l1_mh_ (u"࠭ࡩ࡮ࡣࡪࡩࠬॼ"),[{}])[-1].get(l11111lll1l1_mh_ (u"ࠧࡊ࠵ࡕࡰࡪࡎࡑ࠾࠿ࠪॽ").decode(l11111lll1l1_mh_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨॾ")),l11111lll1l1_mh_ (u"ࠩࠪॿ"))
        l11l111llll1l1_mh_.append(l11l11lllll1l1_mh_)
    return l11l111llll1l1_mh_
def l111111llll1l1_mh_(artist):
    url=l11111lll1l1_mh_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡮ࡺࡵ࡯ࡧࡶ࠲ࡦࡶࡰ࡭ࡧ࠱ࡧࡴࡳ࠯ࡴࡧࡤࡶࡨ࡮࠿ࡵࡧࡵࡱࡂࠫࡳࠧࡧࡱࡸ࡮ࡺࡹ࠾ࡣ࡯ࡦࡺࡳࠦ࡭࡫ࡰ࡭ࡹࡃ࠲࠱ࠩঀ")%urllib.quote(artist)
    data = l11l1ll1lll1l1_mh_(url)
    l111ll11lll1l1_mh_=[]
    for val in data.get(l11111lll1l1_mh_ (u"ࠫࡷ࡫ࡳࡶ࡮ࡷࡷࠬঁ")):
        l111lllllll1l1_mh_={}
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠬࡴࡡ࡮ࡧࠪং")] = val.get(l11111lll1l1_mh_ (u"࠭ࡣࡰ࡮࡯ࡩࡨࡺࡩࡰࡰࡆࡩࡳࡹ࡯ࡳࡧࡧࡒࡦࡳࡥࠨঃ"),l11111lll1l1_mh_ (u"ࠧࠨ঄"))
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠨ࡫ࡰ࡫ࠬঅ")] = val.get(l11111lll1l1_mh_ (u"ࠩࡤࡶࡹࡽ࡯ࡳ࡭ࡘࡶࡱ࠷࠰࠱ࠩআ"));
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠪࡥࡷࡺࡩࡴࡶࡑࡥࡲ࡫ࠧই")] = val.get(l11111lll1l1_mh_ (u"ࠫࡦࡸࡴࡪࡵࡷࡒࡦࡳࡥࠨঈ"),l11111lll1l1_mh_ (u"ࠬ࠭উ")).replace(l11111lll1l1_mh_ (u"ࠨࡖࡢࡴ࡬ࡳࡺࡹࠠࡂࡴࡷ࡭ࡸࡺࡳࠣঊ"), l11111lll1l1_mh_ (u"ࠢࠣঋ"));
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠨ࡫ࡧࠫঌ")] = val.get(l11111lll1l1_mh_ (u"ࠩࡦࡳࡱࡲࡥࡤࡶ࡬ࡳࡳࡏࡤࠨ঍"));
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠪࡥࡷࡺࡩࡴࡶࡌࡨࠬ঎")] = val.get(l11111lll1l1_mh_ (u"ࠫࡦࡸࡴࡪࡵࡷࡍࡩ࠭এ"));
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠬࡶࡵࡣ࡮࡬ࡷ࡭࡫ࡤࠨঐ")] = val.get(l11111lll1l1_mh_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫ࡄࡢࡶࡨࠫ঑"),l11111lll1l1_mh_ (u"ࠧࠨ঒")).split(l11111lll1l1_mh_ (u"ࠣࡖࠥও"))[0];
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠩࡷࡶࡦࡩ࡫ࡄࡱࡸࡲࡹ࠭ঔ")] = val.get(l11111lll1l1_mh_ (u"ࠪࡸࡷࡧࡣ࡬ࡅࡲࡹࡳࡺࠧক"))
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠫࡵࡲ࡯ࡵࠩখ")] = l111lllllll1l1_mh_.get(l11111lll1l1_mh_ (u"ࠬࡴࡡ࡮ࡧࠪগ"),l11111lll1l1_mh_ (u"࠭ࠧঘ")) + l11111lll1l1_mh_ (u"ࠢࠡࡤࡼࠤࠧঙ") + l111lllllll1l1_mh_.get(l11111lll1l1_mh_ (u"ࠨࡣࡵࡸ࡮ࡹࡴࡏࡣࡰࡩࠬচ"),l11111lll1l1_mh_ (u"ࠩࠪছ")) +l11111lll1l1_mh_ (u"ࠪࡠࡳࡶࡵࡣ࡮࡬ࡷ࡭࡫ࡤࠡ࠼ࠪজ")+l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠫࡵࡻࡢ࡭࡫ࡶ࡬ࡪࡪࠧঝ")]
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠬࡶ࡬ࡰࡶࠪঞ")] += l11111lll1l1_mh_ (u"࠭࡜࡯ࡖࡵࡥࡨࡱࡳ࠻ࠢࠨࡨࠬট") %val.get(l11111lll1l1_mh_ (u"ࠧࡵࡴࡤࡧࡰࡉ࡯ࡶࡰࡷࠫঠ")) if val.get(l11111lll1l1_mh_ (u"ࠨࡶࡵࡥࡨࡱࡃࡰࡷࡱࡸࠬড")) else l11111lll1l1_mh_ (u"ࠩࠪঢ")
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠪࡴࡱࡵࡴࠨণ")] += l11111lll1l1_mh_ (u"ࠫࡡࡴࡣࡰࡲࡼࡶ࡮࡭ࡨࡵ࠼ࠣࠩࡸ࠭ত") %val.get(l11111lll1l1_mh_ (u"ࠬࡩ࡯ࡱࡻࡵ࡭࡬࡮ࡴࠨথ")) if val.get(l11111lll1l1_mh_ (u"࠭ࡣࡰࡲࡼࡶ࡮࡭ࡨࡵࠩদ")) else l11111lll1l1_mh_ (u"ࠧࠨধ")
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠨࡲ࡯ࡳࡹ࠭ন")] += l11111lll1l1_mh_ (u"ࠩ࡟ࡲࡷ࡫࡬ࡦࡣࡶࡩࡉࡧࡴࡦ࠼ࠣࠩࡸ࠭঩") %val.get(l11111lll1l1_mh_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨࡈࡦࡺࡥࠨপ")) if val.get(l11111lll1l1_mh_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩࡉࡧࡴࡦࠩফ")) else l11111lll1l1_mh_ (u"ࠬ࠭ব")
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"࠭ࡴࡪࡶ࡯ࡩࠬভ")] = l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠧ࡯ࡣࡰࡩࠬম")]
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠨࡥࡲࡨࡪ࠭য")]=l11111lll1l1_mh_ (u"ࠩࡾࢁࠥࡺࡲࡢࡥ࡮ࡷࠬর").format( l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠪࡸࡷࡧࡣ࡬ࡅࡲࡹࡳࡺࠧ঱")] )
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠫ࡭ࡸࡥࡧࠩল")]=urllib.urlencode(l1l1111llll1l1_mh_({l11111lll1l1_mh_ (u"ࠬࡧ࡬ࡣࡷࡰࡍࡹࡏࡤࠨ঳"):l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"࠭ࡩࡥࠩ঴")],l11111lll1l1_mh_ (u"ࠧࡢࡴࡷ࡭ࡸࡺࠧ঵"):l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠨࡣࡵࡸ࡮ࡹࡴࡏࡣࡰࡩࠬশ")],l11111lll1l1_mh_ (u"ࠩࡱࡥࡲ࡫ࠧষ"):l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠪࡲࡦࡳࡥࠨস")]}))
        if val.get(l11111lll1l1_mh_ (u"ࠫࡼࡸࡡࡱࡲࡨࡶ࡙ࡿࡰࡦࠩহ"))==l11111lll1l1_mh_ (u"ࠬࡩ࡯࡭࡮ࡨࡧࡹ࡯࡯࡯ࠩ঺"):
            l111ll11lll1l1_mh_.append(l111lllllll1l1_mh_)
    return l111ll11lll1l1_mh_
def l1l1l1l1lll1l1_mh_(filename=l11111lll1l1_mh_ (u"࠭ࡡ࡭ࡤࡸࡱࡸࡒࡩࡴࡶ࠱࡮ࡸࡵ࡮ࠨ঻"),l111l111lll1l1_mh_=True):
    url= l11111lll1l1_mh_ (u"ࠢࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡲࡻࡳࡪࡺ࡫ࡹࡧ࠴ࡣࡰ࡯࠲ࡧࡦࡩࡨࡦ࠱়ࠥ")+filename
    data = l111l1llll1l1_mh_(url)
    out=[]
    if (data):
        data=json.loads(data)
        for k,v in data.items():
            for l11l11lllll1l1_mh_ in v.get(l11111lll1l1_mh_ (u"ࠨࡧࡱࡸࡷࡿࠧঽ"),[]):
                name = l11l11lllll1l1_mh_.get(l11111lll1l1_mh_ (u"ࠩ࡬ࡱ࠿ࡴࡡ࡮ࡧࠪা"),l11111lll1l1_mh_ (u"ࠪࠫি")).get(l11111lll1l1_mh_ (u"ࠫࡱࡧࡢࡦ࡮ࠪী"),l11111lll1l1_mh_ (u"ࠬ࠭ু"))
                artist = l11l11lllll1l1_mh_.get(l11111lll1l1_mh_ (u"࠭ࡩ࡮࠼ࡤࡶࡹ࡯ࡳࡵࠩূ"),l11111lll1l1_mh_ (u"ࠧࠨৃ")).get(l11111lll1l1_mh_ (u"ࠨ࡮ࡤࡦࡪࡲࠧৄ"),l11111lll1l1_mh_ (u"ࠩࠪ৅"))
                l11llllllll1l1_mh_ =  l11l11lllll1l1_mh_.get(l11111lll1l1_mh_ (u"ࠪ࡭ࡲࡀࡩࡵࡧࡰࡇࡴࡻ࡮ࡵࠩ৆"),l11111lll1l1_mh_ (u"ࠫࠬে")).get(l11111lll1l1_mh_ (u"ࠬࡲࡡࡣࡧ࡯ࠫৈ"),l11111lll1l1_mh_ (u"࠭ࠧ৉"))
                l1l1l111lll1l1_mh_  =  l11l11lllll1l1_mh_.get(l11111lll1l1_mh_ (u"ࠧࡪ࡯࠽ࡶࡪࡲࡥࡢࡵࡨࡈࡦࡺࡥࠨ৊"),l11111lll1l1_mh_ (u"ࠨࠩো")).get(l11111lll1l1_mh_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨৌ"),l11111lll1l1_mh_ (u"্ࠪࠫ")).split(l11111lll1l1_mh_ (u"࡙ࠦࠨৎ"))[0]
                l1l1ll11lll1l1_mh_ = 		l11l11lllll1l1_mh_[l11111lll1l1_mh_ (u"ࠧ࡯࡭࠻࡫ࡰࡥ࡬࡫ࠢ৏")][-1].get(l11111lll1l1_mh_ (u"࠭࡬ࡢࡤࡨࡰࠬ৐"),l11111lll1l1_mh_ (u"ࠧࠨ৑"))
                l111l1l1lll1l1_mh_ = l11l11lllll1l1_mh_.get(l11111lll1l1_mh_ (u"ࠣ࡫ࡧࠦ৒"),{}).get(l11111lll1l1_mh_ (u"ࠩࡤࡸࡹࡸࡩࡣࡷࡷࡩࡸ࠭৓"),{}).get(l11111lll1l1_mh_ (u"ࠥ࡭ࡲࡀࡩࡥࠤ৔"),l11111lll1l1_mh_ (u"ࠫࠬ৕"))
                href=urllib.urlencode(l1l1111llll1l1_mh_({l11111lll1l1_mh_ (u"ࠬࡧ࡬ࡣࡷࡰࡍࡹࡏࡤࠨ৖"):l111l1l1lll1l1_mh_,l11111lll1l1_mh_ (u"࠭ࡡࡳࡶ࡬ࡷࡹ࠭ৗ"):artist,l11111lll1l1_mh_ (u"ࠧ࡯ࡣࡰࡩࠬ৘"):name}))
                l1l111llll1l1_mh_=l11111lll1l1_mh_ (u"ࠨࡃࡵࡸ࡮ࡹࡴ࠻ࠢ࡞ࡆࡢࠫࡳ࡜࠱ࡅࡡࡡࡴࡎࡢ࡯ࡨ࠾ࠥࡡࡂ࡞ࠧࡶ࡟࠴ࡈ࡝࡝ࡰࡗࡶࡦࡩ࡫ࡴ࠼ࠣ࡟ࡇࡣࠥࡴ࡝࠲ࡆࡢࡢ࡮ࠨ৙")%(artist,name,l11llllllll1l1_mh_)
                out.append({l11111lll1l1_mh_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ৚"):name,l11111lll1l1_mh_ (u"ࠪ࡭ࡲ࡭ࠧ৛"):l1l1ll11lll1l1_mh_,l11111lll1l1_mh_ (u"ࠫࡵࡲ࡯ࡵࠩড়"):l1l111llll1l1_mh_,l11111lll1l1_mh_ (u"ࠬ࡮ࡲࡦࡨࠪঢ়"):href})
    return out
def l111l11llll1l1_mh_(albumItId,artist,name):
    if albumItId:
        return l1l1l1lllll1l1_mh_(albumItId)
def l1l1lll1lll1l1_mh_(l1l11llllll1l1_mh_):
    try:
        m, s = divmod(l1l11llllll1l1_mh_, 60)
        h, m = divmod(m, 60)
        if h>0:
            l11l1l1llll1l1_mh_= l11111lll1l1_mh_ (u"ࠨࠥࡥ࠼ࠨ࠴࠷ࡪ࠺ࠦ࠲࠵ࡨࠧ৞") % (h, m, s)
        else:
            l11l1l1llll1l1_mh_= l11111lll1l1_mh_ (u"ࠢࠦ࠲࠵ࡨ࠿ࠫ࠰࠳ࡦࠥয়") % ( m, s)
    except:
        l11l1l1llll1l1_mh_=l11111lll1l1_mh_ (u"ࠨࠩৠ")
    return l11l1l1llll1l1_mh_
def l1l1l1lllll1l1_mh_(albumItId=l11111lll1l1_mh_ (u"ࠩ࠴࠵࠽࠾࠴࠹࠻࠻࠵࠼࠭ৡ")):
    url = l11111lll1l1_mh_ (u"ࠥ࡬ࡹࡺࡰࡴ࠼࠲࠳࡮ࡺࡵ࡯ࡧࡶ࠲ࡦࡶࡰ࡭ࡧ࠱ࡧࡴࡳ࠯࡭ࡱࡲ࡯ࡺࡶ࠿ࡪࡦࡀࠦৢ") + albumItId + l11111lll1l1_mh_ (u"ࠦࠫ࡫࡮ࡵ࡫ࡷࡽࡂࡹ࡯࡯ࡩࠥৣ");
    data = l111l1llll1l1_mh_(url)
    l11l11l1lll1l1_mh_ = []
    data = json.loads(data)
    for val in data.get(l11111lll1l1_mh_ (u"ࠬࡸࡥࡴࡷ࡯ࡸࡸ࠭৤")):
        l111lllllll1l1_mh_={}
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"࠭࡮ࡢ࡯ࡨࠫ৥")] = val.get(l11111lll1l1_mh_ (u"ࠧࡵࡴࡤࡧࡰࡔࡡ࡮ࡧࠪ০"),l11111lll1l1_mh_ (u"ࠨࠩ১"))
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠩ࡬ࡱ࡬࠭২")] = val.get(l11111lll1l1_mh_ (u"ࠪࡥࡷࡺࡷࡰࡴ࡮࡙ࡷࡲ࠱࠱࠲ࠪ৩"));
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠫࡦࡸࡴࡪࡵࡷࡒࡦࡳࡥࠨ৪")] = val.get(l11111lll1l1_mh_ (u"ࠬࡧࡲࡵ࡫ࡶࡸࡓࡧ࡭ࡦࠩ৫"),l11111lll1l1_mh_ (u"࠭ࠧ৬")).replace(l11111lll1l1_mh_ (u"ࠢࡗࡣࡵ࡭ࡴࡻࡳࠡࡃࡵࡸ࡮ࡹࡴࡴࠤ৭"), l11111lll1l1_mh_ (u"ࠣࠤ৮"));
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠩࡷࡶࡦࡩ࡫ࡏࡷࡰࡦࡪࡸࠧ৯")]=val.get(l11111lll1l1_mh_ (u"ࠪࡸࡷࡧࡣ࡬ࡐࡸࡱࡧ࡫ࡲࠨৰ"),0)
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭ৱ")]=int(val.get(l11111lll1l1_mh_ (u"ࠬࡺࡲࡢࡥ࡮ࡘ࡮ࡳࡥࡎ࡫࡯ࡰ࡮ࡹࠧ৲"),l11111lll1l1_mh_ (u"࠭࠰ࠨ৳"))) / 1000
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠧࡪࡦࠪ৴")] = albumItId;
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠨࡲࡸࡦࡱ࡯ࡳࡩࡧࡧࠫ৵")] = val.get(l11111lll1l1_mh_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧࡇࡥࡹ࡫ࠧ৶"),l11111lll1l1_mh_ (u"ࠪࠫ৷")).split(l11111lll1l1_mh_ (u"࡙ࠦࠨ৸"))[0];
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠬࡺࡲࡢࡥ࡮ࡇࡴࡻ࡮ࡵࠩ৹")] = val.get(l11111lll1l1_mh_ (u"࠭ࡴࡳࡣࡦ࡯ࡈࡵࡵ࡯ࡶࠪ৺"))
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠧࡱ࡮ࡲࡸࠬ৻")] = l111lllllll1l1_mh_.get(l11111lll1l1_mh_ (u"ࠨࡰࡤࡱࡪ࠭ৼ"),l11111lll1l1_mh_ (u"ࠩࠪ৽")) + l11111lll1l1_mh_ (u"ࠥࠤࡧࡿࠠࠣ৾") + l111lllllll1l1_mh_.get(l11111lll1l1_mh_ (u"ࠫࡦࡸࡴࡪࡵࡷࡒࡦࡳࡥࠨ৿"),l11111lll1l1_mh_ (u"ࠬ࠭਀")) +l11111lll1l1_mh_ (u"࠭࡜࡯ࡲࡸࡦࡱ࡯ࡳࡩࡧࡧ࠾ࠬਁ")+l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠧࡱࡷࡥࡰ࡮ࡹࡨࡦࡦࠪਂ")]
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠨࡶࡼࡴࡪ࠭ਃ")] = l11111lll1l1_mh_ (u"ࠤࡤࠦ਄");
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩਅ")] = l11111lll1l1_mh_ (u"ࠫࠪ࠴࠲ࡥࠢ࠰ࠤࠪࡹࠧਆ")%( l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠬࡺࡲࡢࡥ࡮ࡒࡺࡳࡢࡦࡴࠪਇ")],l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"࠭࡮ࡢ࡯ࡨࠫਈ")] )
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠧࡤࡱࡧࡩࠬਉ")]=l1l1lll1lll1l1_mh_(l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪਊ")])
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠩ࡫ࡶࡪ࡬ࠧ਋")]=urllib.urlencode(l1l1111llll1l1_mh_({l11111lll1l1_mh_ (u"ࠪࡥࡱࡨࡵ࡮ࡋࡷࡍࡩ࠭਌"):albumItId,l11111lll1l1_mh_ (u"ࠫࡦࡸࡴࡪࡵࡷࠫ਍"):l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠬࡧࡲࡵ࡫ࡶࡸࡓࡧ࡭ࡦࠩ਎")],l11111lll1l1_mh_ (u"࠭࡮ࡢ࡯ࡨࠫਏ"):l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠧ࡯ࡣࡰࡩࠬਐ")]}))
        if val.get(l11111lll1l1_mh_ (u"ࠨࡹࡵࡥࡵࡶࡥࡳࡖࡼࡴࡪ࠭਑"))==l11111lll1l1_mh_ (u"ࠩࡷࡶࡦࡩ࡫ࠨ਒"):
            l11l11l1lll1l1_mh_.append(l111lllllll1l1_mh_)
    return l11l11l1lll1l1_mh_
l11l1llllll1l1_mh_=l11111lll1l1_mh_ (u"ࠥࡅࡎࢀࡡࡔࡻࡅࡦ࡜ࡎࡖࡨࡒࡦ࠼ࡺࡾࡌࡱࡦࡈࡸࡸࡨࡓࡓࡇࡳ࡬ࡊ࡛ࡉࡨࡅ࠷ࡦࡍࡉ࠴ࠣਓ")
def l11l1ll1lll1l1_mh_(u):
    headers = { l11111lll1l1_mh_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨਔ"): l1l1lllllll1l1_mh_, l11111lll1l1_mh_ (u"ࠬࡸࡥࡧࡧࡵࡩࡷ࠭ਕ"): l11111lll1l1_mh_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡱࡺࡹࡩࡹࡪࡸࡦ࠳ࡩ࡯࡮࠱ࠪਖ") }
    try:
        l11llll1lll1l1_mh_ = urllib2.Request(u, None, headers)
        l11ll11llll1l1_mh_ = urllib2.urlopen(l11llll1lll1l1_mh_)
        data = json.load(l11ll11llll1l1_mh_)
    except:
        data={}
    return data
def l1l1ll1llll1l1_mh_(l1llllllllll1l1_mh_=l11111lll1l1_mh_ (u"ࠧࡑࡖ࠷ࡑ࠶࠾ࡓࠨਗ")):
    res = 0;
    l1111l11lll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠨࠪ࡟ࡨ࠰࠯ࡈࠨਘ"),l1llllllllll1l1_mh_)
    mm = re.findall(l11111lll1l1_mh_ (u"ࠩࠫࡠࡩ࠱ࠩࡎࠩਙ"),l1llllllllll1l1_mh_)
    l1111ll1lll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠪࠬࡡࡪࠫࠪࡕࠪਚ"),l1llllllllll1l1_mh_)
    res += int(l1111l11lll1l1_mh_[0])*3600 if l1111l11lll1l1_mh_ else 0
    res += int(mm[0])*60 if mm else 0
    res += int(l1111ll1lll1l1_mh_[0]) if l1111ll1lll1l1_mh_ else 0
    return res;
def l1l11l11lll1l1_mh_(name,artist,**args):
    l1111l1llll1l1_mh_((l11111lll1l1_mh_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫࡚࡮ࡪࡥࡰࠩਛ"),name,artist))
    l11ll1lllll1l1_mh_ = []
    u = l11111lll1l1_mh_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱࡫ࡴࡵࡧ࡭ࡧࡤࡴ࡮ࡹ࠮ࡤࡱࡰ࠳ࡾࡵࡵࡵࡷࡥࡩ࠴ࡼ࠳࠰ࡵࡨࡥࡷࡩࡨࡀࡲࡤࡶࡹࡃࡩࡥࠨࡴࡁࠬਜ") + urllib.quote(name + l11111lll1l1_mh_ (u"ࠨࠠࡣࡻࠣࠦਝ") + artist) + l11111lll1l1_mh_ (u"ࠧࠧ࡯ࡤࡼࡗ࡫ࡳࡶ࡮ࡷࡷࡂ࠷࠰ࠧࡶࡼࡴࡪࡃࡶࡪࡦࡨࡳࠫࡱࡥࡺ࠿ࠪਞ") + l11l1llllll1l1_mh_;
    data=l11l1ll1lll1l1_mh_(u)
    if data.has_key(l11111lll1l1_mh_ (u"ࠨ࡫ࡷࡩࡲࡹࠧਟ")):
        l111ll1llll1l1_mh_ = l11111lll1l1_mh_ (u"ࠩ࠯ࠫਠ").join([d.get(l11111lll1l1_mh_ (u"ࠪ࡭ࡩ࠭ਡ"),{}).get(l11111lll1l1_mh_ (u"ࠫࡻ࡯ࡤࡦࡱࡌࡨࠬਢ"),l11111lll1l1_mh_ (u"ࠬ࠭ਣ")) for d in data[l11111lll1l1_mh_ (u"࠭ࡩࡵࡧࡰࡷࠬਤ")]])
        u2 = l11111lll1l1_mh_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩࡦࡶࡩࡴ࠰ࡦࡳࡲ࠵ࡹࡰࡷࡷࡹࡧ࡫࠯ࡷ࠵࠲ࡺ࡮ࡪࡥࡰࡵࡂࡴࡦࡸࡴ࠾ࡥࡲࡲࡹ࡫࡮ࡵࡆࡨࡸࡦ࡯࡬ࡴ࠮ࡶࡸࡦࡺࡩࡴࡶ࡬ࡧࡸ࠲ࡳ࡯࡫ࡳࡴࡪࡺࠦࡪࡦࡀࠫਥ") + l111ll1llll1l1_mh_ + l11111lll1l1_mh_ (u"ࠨࠨ࡮ࡩࡾࡃࠧਦ") + l11l1llllll1l1_mh_;
        items = l11l1ll1lll1l1_mh_(u2)
        for l1ll1l1lll1l1_mh_ in items.get(l11111lll1l1_mh_ (u"ࠩ࡬ࡸࡪࡳࡳࠨਧ"),[]):
            l11l1l11lll1l1_mh_ = l1l1ll1llll1l1_mh_(l1ll1l1lll1l1_mh_[l11111lll1l1_mh_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡈࡪࡺࡡࡪ࡮ࡶࠫਨ")][l11111lll1l1_mh_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭਩")]);
            l11ll1llll1l1_mh_ = l1ll1l1lll1l1_mh_[l11111lll1l1_mh_ (u"ࠬࡹ࡮ࡪࡲࡳࡩࡹ࠭ਪ")][l11111lll1l1_mh_ (u"࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪਫ")].get(l11111lll1l1_mh_ (u"ࠧࡩ࡫ࡪ࡬ࠬਬ")).get(l11111lll1l1_mh_ (u"ࠨࡷࡵࡰࠬਭ"))
            if (l11l1l11lll1l1_mh_ < 900 and l11l1l11lll1l1_mh_ > 60):
                l1l11l1llll1l1_mh_={l11111lll1l1_mh_ (u"ࠩ࡬ࡨࠬਮ"):l1ll1l1lll1l1_mh_[l11111lll1l1_mh_ (u"ࠪ࡭ࡩ࠭ਯ")],l11111lll1l1_mh_ (u"ࠫ࡮ࡳࡧࠨਰ"):l11ll1llll1l1_mh_, l11111lll1l1_mh_ (u"ࠧࡺࡩࡵ࡮ࡨࠦ਱"): l1ll1l1lll1l1_mh_[l11111lll1l1_mh_ (u"࠭ࡳ࡯࡫ࡳࡴࡪࡺࠧਲ")][l11111lll1l1_mh_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ਲ਼")],l11111lll1l1_mh_ (u"ࠨࡲ࡯ࡳࡹ࠭਴"):l1ll1l1lll1l1_mh_[l11111lll1l1_mh_ (u"ࠩࡶࡲ࡮ࡶࡰࡦࡶࠪਵ")][l11111lll1l1_mh_ (u"ࠪࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠨਸ਼")],l11111lll1l1_mh_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭਷"):l11l1l11lll1l1_mh_}
                l1l11l1llll1l1_mh_.update(l1ll1l1lll1l1_mh_[l11111lll1l1_mh_ (u"ࠬࡹࡴࡢࡶ࡬ࡷࡹ࡯ࡣࡴࠩਸ")])
                l11ll1lllll1l1_mh_.append(l1l11l1llll1l1_mh_)
    return l11ll1lllll1l1_mh_
def l1l111l1lll1l1_mh_(l11ll111lll1l1_mh_=l11111lll1l1_mh_ (u"࠭ࠧਹ")):
    if l11ll111lll1l1_mh_==l11111lll1l1_mh_ (u"ࠧࡵࡴࡲ࡮ࡰࡧࠧ਺"):
        return l1l11111lll1l1_mh_()
    elif l11ll111lll1l1_mh_==l11111lll1l1_mh_ (u"ࠨࡴࡰࡪ࡫ࡳࠧ਻"):
        return l11lll11lll1l1_mh_()
    return ([],l11111lll1l1_mh_ (u"਼ࠩࠪ"))
def l1l11111lll1l1_mh_():
    l11111l1lll1l1_mh_=l11111lll1l1_mh_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡰࡵ࠹࠮ࡱࡱ࡯ࡷࡰ࡯ࡥࡳࡣࡧ࡭ࡴ࠴ࡰ࡭࠱ࡱࡳࡹࡵࡷࡢࡰ࡬ࡥ࠴࠭਽")
    content = l111l1llll1l1_mh_(l11111l1lll1l1_mh_)
    ids = [(a.start(), a.end()) for a in re.finditer(l11111lll1l1_mh_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡥࡳࡽࡔ࡯ࡵࡱࡺࡥࡳ࡯ࡥࠣࡀࠪਾ"), content)]
    ids.append( (-1,-1) )
    l11l11l1lll1l1_mh_=[]
    i=0
    l111l1lllll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡲࡺࡳࡥࡳࡉ࡯ࡳࡸࡵࡷࡢࡰ࡬ࡥࠧࡄ࡛࡝ࡵ࡟ࡲࡢ࠰࠼ࡴࡲࡤࡲࠥࡩ࡬ࡢࡵࡶࡁࠧࡺࡥࡹࡶࠥࡂ࠭࠴ࠫࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀ࠿ࡷࡵࡧ࡮ࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡰࡸࡱࡧ࡫ࡲࠣࡀࠫࡠࡩ࠱ࠩ࠽࠱ࡶࡴࡦࡴ࠾࡜࡞ࡶࡠࡳࡣࠪ࠽ࡵࡳࡥࡳࠦࡣ࡭ࡣࡶࡷࡂࠨࡺࡅࡰ࡬ࡥࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬਿ"),content)
    l111l1lllll1l1_mh_ = l11111lll1l1_mh_ (u"࠭ࠠࠨੀ").join(l111l1lllll1l1_mh_[0]) if l111l1lllll1l1_mh_ else l11111lll1l1_mh_ (u"ࠧࡏࡱࡷࡳࡼࡧ࡮ࡪࡧࠣࡴࡷࡵࡧࡳࡣࡰࡹࠥ࠹ࠧੁ")
    l1l11ll1lll1l1_mh_ = content[ ids[i][1]:ids[i+1][0] ]
    l1111111lll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠨ࠾ࡷࡶࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡲ࠿ࠩੂ"),l1l11ll1lll1l1_mh_,re.DOTALL)
    for idx,l1l11lll1l1_mh_ in enumerate(l1111111lll1l1_mh_[1:]):
        l11111lllll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠴ࡽࡹ࡬ࡱࡱࡥࡼࡩࡡ࠰࠰࠮ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩ੃"),l1l11lll1l1_mh_)
        l11lll1llll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠵ࡵࡵࡹࡲࡶ࠴࠴ࠫࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭੄"),l1l11lll1l1_mh_)
        l11ll1llll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ੅"),l1l11lll1l1_mh_)
        if l11111lllll1l1_mh_ and l11lll1llll1l1_mh_:
            l111lllllll1l1_mh_={l11111lll1l1_mh_ (u"ࠬࡧࡲࡵ࡫ࡶࡸࡓࡧ࡭ࡦࠩ੆"):l11111lllll1l1_mh_[0].strip(),l11111lll1l1_mh_ (u"࠭࡮ࡢ࡯ࡨࠫੇ"):l11lll1llll1l1_mh_[0].strip()}
            l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ੈ")] = l11111lll1l1_mh_ (u"ࠨࠧ࠱࠶ࡩ࠴ࠠࠦࡵࠣ࠱ࠥࠫࡳࠨ੉")%(idx+1,l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠩࡤࡶࡹ࡯ࡳࡵࡐࡤࡱࡪ࠭੊")],l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠪࡲࡦࡳࡥࠨੋ")])
            l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠫ࡭ࡸࡥࡧࠩੌ")]=urllib.urlencode(l1l1111llll1l1_mh_({l11111lll1l1_mh_ (u"ࠬࡧ࡬ࡣࡷࡰࡍࡹࡏࡤࠨ੍"):None,l11111lll1l1_mh_ (u"࠭ࡡࡳࡶ࡬ࡷࡹ࠭੎"):l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠧࡢࡴࡷ࡭ࡸࡺࡎࡢ࡯ࡨࠫ੏")],l11111lll1l1_mh_ (u"ࠨࡰࡤࡱࡪ࠭੐"):l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠩࡱࡥࡲ࡫ࠧੑ")]}))
            l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠪ࡭ࡲ࡭ࠧ੒")]=l11ll1llll1l1_mh_[0] if l11ll1llll1l1_mh_ else l11111lll1l1_mh_ (u"ࠫࠬ੓")
            l11l11l1lll1l1_mh_.append(l111lllllll1l1_mh_)
    return l11l11l1lll1l1_mh_,l111l1lllll1l1_mh_
def l11lll11lll1l1_mh_():
    l11111l1lll1l1_mh_=l11111lll1l1_mh_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡵࡱ࡫࠴ࡦ࡮࠱ࡤࡹ࠴ࡶ࡯ࡱ࡮࡬ࡷࡹࡧ࠮ࡩࡶࡰࡰࠬ੔")
    content = l111l1llll1l1_mh_(l11111l1lll1l1_mh_)
    content = content.decode(l11111lll1l1_mh_ (u"࠭ࡩࡴࡱ࠰࠼࠽࠻࠹࠮࠴ࠪ੕")).encode(l11111lll1l1_mh_ (u"ࠧࡶࡶࡩ࠱࠽࠭੖"))
    l11l11l1lll1l1_mh_=[]
    l111l1lllll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡰࡰࡲ࡯࡭ࡸࡺࡡ࠮ࡰࡲࡸࡴࡽࡡ࡯࡫ࡨ࠱ࡳࡻ࡭ࡦࡴࠥࡂࡠࡢࡳ࡝ࡰࡠ࠮࠭࠴ࠫࡀࠫ࠿ࡷࡵࡧ࡮ࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡲࡴࡱ࡯ࡳࡵࡣ࠰ࡾࡩࡴࡩࡢࠤࡁࠬ࠳࠱࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ੗"),content)
    l111l1lllll1l1_mh_ = l11111lll1l1_mh_ (u"ࠩࠪ੘").join(l111l1lllll1l1_mh_[0]) if l111l1lllll1l1_mh_ else l11111lll1l1_mh_ (u"ࠪࡒࡴࡺ࡯ࡸࡣࡱ࡭ࡪࠦࡒࡎࡈࠣࡊࡒ࠭ਖ਼")
    l1l1ll11lll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡳࡳࡵࡲࡩࡴࡶࡤ࠱࡮ࡳࡡࡨࡧࠥࡂࡁࡧ࠮ࠬࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧਗ਼"),content,re.DOTALL|re.I)
    title = re.findall(l11111lll1l1_mh_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡴࡴࡶ࡬ࡪࡵࡷࡥ࠲ࡧࡲࡵ࡫ࡶࡸ࠲ࡺࡩࡵ࡮ࡨࠦࡃࡂࡡ࡜ࡠࡁࡡ࠯ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠰࠮ࡃࡁࡧ࡛࡟ࡀࡠ࠮ࡃ࠮࠮ࠫࡁࠬࡀ࠴࠭ਜ਼"),content,re.DOTALL|re.I)
    idx=0
    for artist,name in title:
        l11111lllll1l1_mh_ = artist.strip()
        l11lll1llll1l1_mh_ = name.strip()
        l11ll1llll1l1_mh_ = l1l1ll11lll1l1_mh_[idx].split(l11111lll1l1_mh_ (u"࠭࠿ࠨੜ"))[0] if idx<len(l1l1ll11lll1l1_mh_) else l11111lll1l1_mh_ (u"ࠧࠨ੝")
        l111lllllll1l1_mh_={l11111lll1l1_mh_ (u"ࠨࡣࡵࡸ࡮ࡹࡴࡏࡣࡰࡩࠬਫ਼"):l11111lllll1l1_mh_,l11111lll1l1_mh_ (u"ࠩࡱࡥࡲ࡫ࠧ੟"):l11lll1llll1l1_mh_}
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ੠")] = l11111lll1l1_mh_ (u"ࠫࠪ࠴࠲ࡥ࠰ࠣࠩࡸࠦ࠭ࠡࠧࡶࠫ੡")%(idx+1,l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠬࡧࡲࡵ࡫ࡶࡸࡓࡧ࡭ࡦࠩ੢")],l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"࠭࡮ࡢ࡯ࡨࠫ੣")])
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠧࡩࡴࡨࡪࠬ੤")]=urllib.urlencode(l1l1111llll1l1_mh_({l11111lll1l1_mh_ (u"ࠨࡣ࡯ࡦࡺࡳࡉࡵࡋࡧࠫ੥"):None,l11111lll1l1_mh_ (u"ࠩࡤࡶࡹ࡯ࡳࡵࠩ੦"):l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠪࡥࡷࡺࡩࡴࡶࡑࡥࡲ࡫ࠧ੧")],l11111lll1l1_mh_ (u"ࠫࡳࡧ࡭ࡦࠩ੨"):l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"ࠬࡴࡡ࡮ࡧࠪ੩")]}))
        l111lllllll1l1_mh_[l11111lll1l1_mh_ (u"࠭ࡩ࡮ࡩࠪ੪")]=l11ll1llll1l1_mh_
        l11l11l1lll1l1_mh_.append(l111lllllll1l1_mh_)
        idx+=1
    return l11l11l1lll1l1_mh_,l111l1lllll1l1_mh_
class l1111l1lll1l1_mh_:
    def l1l1111lll1l1_mh_(self,url):
        if not url:
            url = l11111lll1l1_mh_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡫ࡤࡲࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࠬ੫")
        elif url.startswith(l11111lll1l1_mh_ (u"ࠨ࠱࠲ࠫ੬")):
            url = l11111lll1l1_mh_ (u"ࠩ࡫ࡸࡹࡶࠧ੭")+url
        elif url.startswith(l11111lll1l1_mh_ (u"ࠪ࠳ࠬ੮")):
            url = urljoin(l11111lll1l1_mh_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩ੯"),url)
        return url
    @staticmethod
    def l111111lll1l1_mh_(url=l11111lll1l1_mh_ (u"ࠬ࠭ੰ")):
        if not url:
            url = l11111lll1l1_mh_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡪࡣࡱࡩ࡭ࡱࡳ࠮ࡱ࡮࠲ࠫੱ")
        elif url.startswith(l11111lll1l1_mh_ (u"ࠧ࠰ࠩੲ")):
            url = urljoin(l11111lll1l1_mh_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡬ࡥࡳ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭ੳ"),url)
        content = l111l1llll1l1_mh_(url)
        out=[]
        l111ll1lll1l1_mh_ = re.compile(l11111lll1l1_mh_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡪࡴࡴ࠮ࡩࡵ࡭ࡩࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬੴ"),re.DOTALL).findall(content)
        for show in l111ll1lll1l1_mh_:
            l11ll11lll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠯ࡴࡧࡵ࡭ࡦࡲࡥ࠰࠰࠭࠭ࠧࡄ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩੵ"),show)
            if l11ll11lll1l1_mh_:
                l11ll1llll1l1_mh_ = l11ll11lll1l1_mh_[0][1]
                l11ll1llll1l1_mh_ = urljoin(l11111lll1l1_mh_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩ੶"),l11ll1llll1l1_mh_) if not l11ll1llll1l1_mh_.startswith(l11111lll1l1_mh_ (u"ࠬ࡮ࡴࡵࡲࠪ੷")) else l11ll1llll1l1_mh_
                title = l11ll11lll1l1_mh_[0][0].replace(l11111lll1l1_mh_ (u"࠭࠯ࡴࡧࡵ࡭ࡦࡲࡥ࠰ࠩ੸"),l11111lll1l1_mh_ (u"ࠧࠨ੹")).replace(l11111lll1l1_mh_ (u"ࠨ࠯ࠪ੺"),l11111lll1l1_mh_ (u"ࠩࠣࠫ੻")).replace(l11111lll1l1_mh_ (u"ࠪ࠳ࠬ੼"),l11111lll1l1_mh_ (u"ࠫࠬ੽")).title()
                out.append({l11111lll1l1_mh_ (u"ࠬ࡮ࡲࡦࡨࠪ੾"):l11ll11lll1l1_mh_[0][0],l11111lll1l1_mh_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ੿"):title,l11111lll1l1_mh_ (u"ࠧࡪ࡯ࡪࠫ઀"):l11ll1llll1l1_mh_})
        idx = content.find(l11111lll1l1_mh_ (u"ࠨࡪ࠶ࡂࡘ࡫ࡲࡪࡣ࡯ࡩࡁ࠵ࡨ࠴ࡀࠪઁ"))
        if idx:
            l1ll1ll1lll1l1_mh_ = re.compile(l11111lll1l1_mh_ (u"ࠩ࠿ࡹࡱࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪં"),re.DOTALL).search(content[idx:-1])
            l1ll1ll1lll1l1_mh_ = l1ll1ll1lll1l1_mh_.group(1) if l1ll1ll1lll1l1_mh_ else l11111lll1l1_mh_ (u"ࠪࠫઃ")
            l1ll1ll1lll1l1_mh_ = re.sub(l11111lll1l1_mh_ (u"ࡶࠧࡂࠡ࠮࠯ࠫ࠲ࢁࡢࡳࡽ࡞ࡱ࠭࠯ࡅ࠭࠮ࡀࠥ઄"), l11111lll1l1_mh_ (u"ࠧࠨઅ"), l1ll1ll1lll1l1_mh_)
            l1ll1l1llll1l1_mh_ = re.compile(l11111lll1l1_mh_ (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠯ࡴࡧࡵ࡭ࡦࡲࡥ࠰࠰࠭ࡃ࠮ࠨ࠾ࠩ࡝ࡡࡂࡢ࠰ࠩ࠽࠱ࡤࡂࡁ࠵࡬ࡪࡀࠪઆ")).findall(l1ll1ll1lll1l1_mh_)
            for href,title in l1ll1l1llll1l1_mh_:
                out.append({l11111lll1l1_mh_ (u"ࠧࡩࡴࡨࡪࠬઇ"):href,l11111lll1l1_mh_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧઈ"):title})
        return out
    @staticmethod
    def l1ll111llll1l1_mh_(url=l11111lll1l1_mh_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡭ࡦࡴ࡬ࡩ࡭࡯࠱ࡴࡱ࠵ࡳࡦࡴ࡬ࡥࡱ࡫࠯ࡥࡧࡷࡩࡰࡺࡹࡸ࠱ࠪઉ")):
        if not url:
            url = l11111lll1l1_mh_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡮ࡧࡵࡦࡪ࡮ࡰ࠲ࡵࡲ࠯ࠨઊ")
        if url.startswith(l11111lll1l1_mh_ (u"ࠫ࠴࠵ࠧઋ")):
            url = l11111lll1l1_mh_ (u"ࠬ࡮ࡴࡵࡲࠪઌ")+url
        if url.startswith(l11111lll1l1_mh_ (u"࠭࠯ࠨઍ")):
            url = urljoin(l11111lll1l1_mh_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡫ࡤࡲࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࠬ઎"),url)
        url += l11111lll1l1_mh_ (u"ࠨ࠱ࠪએ") if not url.endswith(l11111lll1l1_mh_ (u"ࠩ࠲ࠫઐ")) else l11111lll1l1_mh_ (u"ࠪࠫઑ")
        content = l111l1llll1l1_mh_(url)
        out=[]
        l1lll111lll1l1_mh_ = re.compile(l11111lll1l1_mh_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡶ࠰࡫ࡷ࡯ࡤࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ઒"),re.DOTALL).findall(content)
        for l1l11l1lll1l1_mh_ in l1lll111lll1l1_mh_:
            l1llll11lll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠬࡹࡥࡻࡱࡱࡠࡸ࠰ࠨ࡝ࡦ࠮࠭ࠬઓ"),l1l11l1lll1l1_mh_,re.I)
            l1llll11lll1l1_mh_ = l1llll11lll1l1_mh_[0] if l1llll11lll1l1_mh_ else l11111lll1l1_mh_ (u"࠭ࠧઔ")
            l1ll1111lll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠧࡐࡦࡦ࡭ࡳ࡫࡫࡝ࡵ࠭ࠬࡡࡪࠫࠪࠩક"),l1l11l1lll1l1_mh_,re.I)
            l1ll1111lll1l1_mh_ = l1ll1111lll1l1_mh_[0] if l1ll1111lll1l1_mh_ else l11111lll1l1_mh_ (u"ࠨࠩખ")
            href = re.compile(l11111lll1l1_mh_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭ࡹࡩ࡯ࡩ࡯ࡩࡵࡧࡧࡦ࠰ࡳ࡬ࡵࡢ࠿ࡪࡦࡀࡠࡩ࠱ࠩࠣࠩગ")).findall(l1l11l1lll1l1_mh_)
            l11ll1llll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠪࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ઘ"),l1l11l1lll1l1_mh_)
            if href and l1llll11lll1l1_mh_ and l1ll1111lll1l1_mh_:
                l11ll1llll1l1_mh_ = urljoin(l11111lll1l1_mh_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩઙ"),l11ll1llll1l1_mh_[0]) if not l11ll1llll1l1_mh_[0].startswith(l11111lll1l1_mh_ (u"ࠬ࡮ࡴࡵࡲࠪચ")) else l11111lll1l1_mh_ (u"࠭ࠧછ")
                out.append({l11111lll1l1_mh_ (u"ࠧࡩࡴࡨࡪࠬજ"):url+href[0],l11111lll1l1_mh_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧઝ"):l11111lll1l1_mh_ (u"ࠩࡖࡩࡿࡵ࡮ࠡࠧࡶ࠰ࠥࡋࡰࡪࡼࡲࡨࠥࠫࡳࠨઞ")%(l1llll11lll1l1_mh_,l1ll1111lll1l1_mh_),l11111lll1l1_mh_ (u"ࠪ࡭ࡲ࡭ࠧટ"):l11ll1llll1l1_mh_,
                l11111lll1l1_mh_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࠫઠ"):int(l1llll11lll1l1_mh_),l11111lll1l1_mh_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪ࠭ડ"):int(l1ll1111lll1l1_mh_)})
        return out
    @staticmethod
    def l1lll1lllll1l1_mh_(out):
        l1l1l1llll1l1_mh_={}
        l11111llll1l1_mh_ = [x.get(l11111lll1l1_mh_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭ઢ")) for x in out]
        for s in set(l11111llll1l1_mh_):
            l1l1l1llll1l1_mh_[l11111lll1l1_mh_ (u"ࠧࡔࡧࡽࡳࡳࠦࠥ࠱࠴ࡧࠫણ")%s]=[out[i] for i, j in enumerate(l11111llll1l1_mh_) if j == s]
        return l1l1l1llll1l1_mh_
    @staticmethod
    def l1l1llllll1l1_mh_(url):
        content = l111l1llll1l1_mh_(url)
        l11lllllll1l1_mh_=l11111lll1l1_mh_ (u"ࠨࠩત")
        l11lll1lll1l1_mh_ = re.compile(l11111lll1l1_mh_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠫ࠲࠯ࡅࠩ࠽࠱࡬ࡪࡷࡧ࡭ࡦࡀࠪથ"),re.DOTALL).findall(content)
        if l11lll1lll1l1_mh_:
            src = re.compile(l11111lll1l1_mh_ (u"ࠪࡷࡷࡩ࠽࡜࡞ࠪࠦࡢ࠮࠮ࠫࡁࠬ࡟ࡡ࠭ࠢ࡞ࠩદ"),re.DOTALL).findall(l11lll1lll1l1_mh_[0])
            l11lllllll1l1_mh_ = src[0] if src else l11111lll1l1_mh_ (u"ࠫࠬધ")
        return l11lllllll1l1_mh_
class l1ll1llllll1l1_mh_:
    @staticmethod
    def l111111lll1l1_mh_(url,l11l1l1lll1l1_mh_=None):
        if l11l1l1lll1l1_mh_:
            l11l1l1lll1l1_mh_ = l11111lll1l1_mh_ (u"ࠬࡹࡺࡶ࡭ࡤ࡮ࡂ࠭ન")+l11l1l1lll1l1_mh_.replace(l11111lll1l1_mh_ (u"࠭ࠠࠨ઩"),l11111lll1l1_mh_ (u"ࠧࠬࠩપ"))
            url= l11111lll1l1_mh_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡨ࡯ࡹࡨ࡬ࡰࡲ࠴ࡰ࡭࠱ࡶࡾࡺࡱࡡ࡫ࠩફ")
        if not url:
            url = l11111lll1l1_mh_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡰࡺࡩ࡭ࡱࡳ࠮ࡱ࡮࠲ࠫબ")
        elif url.startswith(l11111lll1l1_mh_ (u"ࠪ࠳ࠬભ")):
            url = urljoin(l11111lll1l1_mh_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡲࡼ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭મ"),url)
        content = l111l1llll1l1_mh_(url,l11l1l1lll1l1_mh_)
        ids = [(a.start(), a.end()) for a in re.finditer(l11111lll1l1_mh_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡺ࡮ࡪࡥࡰࡡ࡬ࡲ࡫ࡵࠢ࠿ࠩય"), content,re.IGNORECASE)]
        ids.append( (-1,-1) )
        out=[]
        for i in range(len(ids[:-1])):
            l1lll11lll1l1_mh_ = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile(l11111lll1l1_mh_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨર"),re.DOTALL).search(l1lll11lll1l1_mh_)
            title = re.compile(l11111lll1l1_mh_ (u"ࠧ࠽ࡪ࠴ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠷࠾ࠨ઱"),re.DOTALL).search(l1lll11lll1l1_mh_)
            l11ll1llll1l1_mh_ = re.compile(l11111lll1l1_mh_ (u"ࠨ࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫલ"),re.DOTALL).search(l1lll11lll1l1_mh_)
            l1ll11lllll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠩࡏࡩࡰࡺ࡯ࡳ࠼࡟ࡷ࠯ࡂࡳࡱࡣࡱࠤࡸࡺࡹ࡭ࡧࡀࠦࡠࡤ࠾࡞ࠬࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪળ"),l1lll11lll1l1_mh_)
            l1lll11llll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠪࡈࡴࡪࡡ࡯ࡻ࠽ࡠࡸ࠰࠼ࡴࡲࡤࡲࠥࡹࡴࡺ࡮ࡨࡁࠧࡡ࡞࠿࡟࠭ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫ઴"),l1lll11lll1l1_mh_)
            l1ll11l1lll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠫࡌࡧࡴࡶࡰࡨ࡯࠿ࡢࡳࠫ࠾ࡶࡴࡦࡴࠠࡴࡶࡼࡰࡪࡃࠢ࡜ࡠࡁࡡ࠯ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭વ"),l1lll11lll1l1_mh_)
            l1ll11lllll1l1_mh_ = l1ll11lllll1l1_mh_[0] if l1ll11lllll1l1_mh_ else l11111lll1l1_mh_ (u"ࠬ࠭શ")
            l1lll11llll1l1_mh_ = l1lll11llll1l1_mh_[0] if l1lll11llll1l1_mh_ else l11111lll1l1_mh_ (u"࠭ࠧષ")
            l1ll11l1lll1l1_mh_ = l1ll11l1lll1l1_mh_[0] if l1ll11l1lll1l1_mh_ else l11111lll1l1_mh_ (u"ࠧࠨસ")
            code = l1ll11lllll1l1_mh_
            l1l111llll1l1_mh_ = l11111lll1l1_mh_ (u"ࠣࡎࡨ࡯ࡹࡵࡲ࠻ࠢࠨࡷࠥࡢ࡮ࡅࡱࡧࡥࡳࡿ࠺ࠡࠧࡶࠤࡡࡴࡇࡢࡶࡸࡲࡪࡱ࠺ࠡࠧࡶࠤࡡࡴࠢહ") %(l1ll11lllll1l1_mh_,l1lll11llll1l1_mh_,l1ll11l1lll1l1_mh_)
            if href and title:
                l11ll1llll1l1_mh_ = urljoin(l11111lll1l1_mh_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡢࡰࡺࡩ࡭ࡱࡳ࠮ࡱ࡮ࠪ઺"),l11ll1llll1l1_mh_.group(1)) if l11ll1llll1l1_mh_ else l11111lll1l1_mh_ (u"ࠪࠫ઻")
                title = title.group(1)
                year =  re.findall(l11111lll1l1_mh_ (u"ࠫࡡ࠮ࠨ࡝ࡦࡾ࠸ࢂ࠯࡜઼ࠪࠩ"),title)
                l1ll1l1lll1l1_mh_ = {l11111lll1l1_mh_ (u"ࠬ࡮ࡲࡦࡨࠪઽ")   : href.group(1),
                       l11111lll1l1_mh_ (u"࠭ࡴࡪࡶ࡯ࡩࠬા")  : l11l11llll1l1_mh_(title),
                       l11111lll1l1_mh_ (u"ࠧࡪ࡯ࡪࠫિ")    : l11ll1llll1l1_mh_,
                       l11111lll1l1_mh_ (u"ࠨࡲ࡯ࡳࡹ࠭ી")   : l11l11llll1l1_mh_(l1l111llll1l1_mh_),
                       l11111lll1l1_mh_ (u"ࠩࡼࡩࡦࡸࠧુ")   : year[0] if year else l11111lll1l1_mh_ (u"ࠪࠫૂ"),
                       l11111lll1l1_mh_ (u"ࠫࡨࡵࡤࡦࠩૃ")   : code,
                        }
                out.append(l1ll1l1lll1l1_mh_)
        l1llll1llll1l1_mh_=False
        l1ll111lll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࡝ࡡࠦࡢ࠰ࠩࠣࡀ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢ࡯ࡧࡻࡸࡤࡹࡩࡵࡧࠥࡂࡕࡵࡰࡳࡼࡨࡨࡳ࡯ࡡ࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡣࡁࠫૄ"),content)
        l1ll111lll1l1_mh_ = l1ll111lll1l1_mh_[0] if l1ll111lll1l1_mh_ else False
        l1llll1llll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࡞ࡢࠧࡣࠪࠪࠤࡁࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡰࡨࡼࡹࡥࡳࡪࡶࡨࠦࡃࡔࡡࡴࡶ࠱࠯ࡵࡴࡡ࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡣࡁࠫૅ"),content)
        l1llll1llll1l1_mh_ = l1llll1llll1l1_mh_[0] if l1llll1llll1l1_mh_ else False
        return (out, (l1ll111lll1l1_mh_,l1llll1llll1l1_mh_))
    @staticmethod
    def l111l11lll1l1_mh_():
        content = l111l1llll1l1_mh_(l11111lll1l1_mh_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡧࡵࡸࡧ࡫࡯ࡱ࠳ࡶ࡬࠰࡭ࡲࡲࡹࡧ࡫ࡵࠩ૆"))
        l11l111lll1l1_mh_=re.findall(l11111lll1l1_mh_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠴ࡱࡡࡵࡣ࡯ࡳ࡬࠵࠮ࠫࠫࠥࠤࡨࡲࡡࡴࡵࡀࠦࡳࡧࡶࡠ࡮࡬ࡲࡰࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪે"),content)
        out=[]
        for href,name in l11l111lll1l1_mh_:
            out.append({l11111lll1l1_mh_ (u"ࠩ࡫ࡶࡪ࡬ࠧૈ"):href,l11111lll1l1_mh_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩૉ"):name})
        return out
    @staticmethod
    def l11l1lllll1l1_mh_(url):
        url = urljoin(l11111lll1l1_mh_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡤࡲࡼ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭૊"),url)
        content = l111l1llll1l1_mh_(url)
        l111llllll1l1_mh_=l11111lll1l1_mh_ (u"ࠬ࠭ો")
        l1l1l11lll1l1_mh_=re.findall(l11111lll1l1_mh_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡩࡧࡴࡤࡱࡪࡄࠧૌ"),content,re.DOTALL|re.IGNORECASE)
        if l1l1l11lll1l1_mh_:
            l111llllll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁ્ࠬࠦࠬ"),l1l1l11lll1l1_mh_[0],re.DOTALL|re.IGNORECASE)
            l111llllll1l1_mh_ = l111llllll1l1_mh_[0] if l111llllll1l1_mh_ else l11111lll1l1_mh_ (u"ࠨࠩ૎")
        return l111llllll1l1_mh_
