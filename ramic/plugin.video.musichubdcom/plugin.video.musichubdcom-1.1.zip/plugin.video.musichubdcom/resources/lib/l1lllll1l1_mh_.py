# -*- coding: utf-8 -*-
import sys
l111l1lll1l1_mh_ = sys.version_info [0] == 2
l1111lll1l1_mh_ = 2048
l11l11lll1l1_mh_ = 7
def l11111lll1l1_mh_ (keyedStringLiteral):
	global l11llll1l1_mh_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l111l1lll1l1_mh_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1111lll1l1_mh_ - (charIndex + stringNr) % l11l11lll1l1_mh_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1111lll1l1_mh_ - (charIndex + stringNr) % l11l11lll1l1_mh_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import ramic as l1ll1lllllll1l1_mh_
l1ll11ll1lll1l1_mh_        = sys.argv[0]
l1l1ll1lllll1l1_mh_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l1ll1l111lll1l1_mh_        = xbmcaddon.Addon()
l1llll1l1lll1l1_mh_     = l1ll1l111lll1l1_mh_.getAddonInfo(l11111lll1l1_mh_ (u"ࠩ࡬ࡨࠬ૏"))
l1llll11llll1l1_mh_       = l1ll1l111lll1l1_mh_.getAddonInfo(l11111lll1l1_mh_ (u"ࠪࡲࡦࡳࡥࠨૐ"))
PATH        = l1ll1l111lll1l1_mh_.getAddonInfo(l11111lll1l1_mh_ (u"ࠫࡵࡧࡴࡩࠩ૑")).decode(l11111lll1l1_mh_ (u"ࠬࡻࡴࡧ࠯࠻ࠫ૒"))
l1ll11llll1l1_mh_    = xbmc.translatePath(l1ll1l111lll1l1_mh_.getAddonInfo(l11111lll1l1_mh_ (u"࠭ࡰࡳࡱࡩ࡭ࡱ࡫ࠧ૓"))).decode(l11111lll1l1_mh_ (u"ࠧࡶࡶࡩ࠱࠽࠭૔"))
l1l11lll1lll1l1_mh_   = PATH+l11111lll1l1_mh_ (u"ࠨ࠱ࡵࡩࡸࡵࡵࡳࡥࡨࡷ࠴࠭૕")
l1l11ll1llll1l1_mh_       = PATH+l11111lll1l1_mh_ (u"ࠩ࠲࡭ࡨࡵ࡮࠯ࡲࡱ࡫ࠬ૖")
l1l1llll1lll1l1_mh_        = l1l11lll1lll1l1_mh_+l11111lll1l1_mh_ (u"ࠪࡱ࡭࠴ࡰ࡯ࡩࠪ૗")
l1l11l111lll1l1_mh_=l1l11lll1lll1l1_mh_+l11111lll1l1_mh_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷ࠲ࡵࡴࡧࠨ૘")
sys.path.append(l1l11lll1lll1l1_mh_+l11111lll1l1_mh_ (u"ࠬࡲࡩࡣ࠱ࠪ૙"))
l1l111ll1lll1l1_mh_ = urllib2.urlopen
l1ll111l1lll1l1_mh_ = urllib2.Request
l1ll11lll1l1_mh_ = xbmcgui.Dialog()
import time
l1lll11lllll1l1_mh_ = lambda x,y: ord(x)+18*y if ord(x)%2 else ord(x)
l1l1111l1lll1l1_mh_ = lambda l1ll1l1lllll1l1_mh_: l11111lll1l1_mh_ (u"࠭ࠧ૚").join([chr(l1lll11lllll1l1_mh_(x,1) ) for x in l1ll1l1lllll1l1_mh_.encode(l11111lll1l1_mh_ (u"ࠧࡣࡣࡶࡩ࠻࠺ࠧ૛")).strip()])
l1llll111lll1l1_mh_ = lambda l1ll1l1lllll1l1_mh_: l1l1111l1lll1l1_mh_(l1ll1l1lllll1l1_mh_).encode(l11111lll1l1_mh_ (u"ࠨࡪࡨࡼࠬ૜"))
l1ll1111llll1l1_mh_ = lambda l1ll1l1lllll1l1_mh_: l11111lll1l1_mh_ (u"ࠩࠪ૝").join([chr(l1lll11lllll1l1_mh_(x,-1) ) for x in l1ll1l1lllll1l1_mh_]).decode(l11111lll1l1_mh_ (u"ࠪࡦࡦࡹࡥ࠷࠶ࠪ૞"))
l1l1111lllll1l1_mh_ = lambda l1ll1l1lllll1l1_mh_: l1ll1111llll1l1_mh_(l1ll1l1lllll1l1_mh_.decode(l11111lll1l1_mh_ (u"ࠫ࡭࡫ࡸࠨ૟")))
if not os.path.exists(l11111lll1l1_mh_ (u"ࠬ࠵ࡨࡰ࡯ࡨ࠳ࡴࡹ࡭ࡤࠩૠ")):
    tm=time.gmtime()
    try:    l1ll11l1llll1l1_mh_,l1l1l1llllll1l1_mh_,l1ll11llllll1l1_mh_ = l1l1111lllll1l1_mh_(l1ll1l111lll1l1_mh_.getSetting(l11111lll1l1_mh_ (u"࠭࡫ࡰࡦࠪૡ"))).split(l11111lll1l1_mh_ (u"ࠧ࠻ࠩૢ"))
    except: l1ll11l1llll1l1_mh_,l1l1l1llllll1l1_mh_,l1ll11llllll1l1_mh_ =  [l11111lll1l1_mh_ (u"ࠨ࠯࠴ࠫૣ"),l11111lll1l1_mh_ (u"ࠩࠪ૤"),l11111lll1l1_mh_ (u"ࠪ࠱࠶࠭૥")]
    if int(l1ll11l1llll1l1_mh_) != tm.tm_hour:
        try:    l1ll1lll1lll1l1_mh_ = re.findall(l11111lll1l1_mh_ (u"ࠫࡐࡕࡄ࠻ࠢࠫ࠲࠯ࡅࠩ࡝ࡰࠪ૦"),l1l111ll1lll1l1_mh_(l11111lll1l1_mh_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡲࡢࡹ࠱࡫࡮ࡺࡨࡶࡤࡸࡷࡪࡸࡣࡰࡰࡷࡩࡳࡺ࠮ࡤࡱࡰ࠳ࡷࡧ࡭ࡪࡥࡶࡴࡦ࠵࡫ࡰࡦ࡬࠳ࡲࡧࡳࡵࡧࡵ࠳ࡗࡋࡁࡅࡏࡈ࠲ࡲࡪࠧ૧")).read())[0].strip(l11111lll1l1_mh_ (u"࠭ࠪࠨ૨"))
        except: l1ll1lll1lll1l1_mh_ = l11111lll1l1_mh_ (u"ࠧࠨ૩")
        l1ll1ll1llll1l1_mh_ = l1llll111lll1l1_mh_(l11111lll1l1_mh_ (u"ࠩࠨࡨ࠿ࠫࡳ࠻ࠧࡧࠫ૲")%(tm.tm_hour,l1ll1lll1lll1l1_mh_,tm.tm_min))
        l1ll1l111lll1l1_mh_.setSetting(l11111lll1l1_mh_ (u"ࠪ࡯ࡴࡪࠧ૳"),l1ll1ll1llll1l1_mh_)
def l1l1ll111lll1l1_mh_(name, url, mode, l1llllllll1l1_mh_=1, l1lllll11lll1l1_mh_=l11111lll1l1_mh_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠨ૴"), infoLabels={}, IsPlayable=True, isFolder=False, fanart=l1l11l111lll1l1_mh_,l1l1lll1llll1l1_mh_=1):
    u = l1lll1ll1lll1l1_mh_({l11111lll1l1_mh_ (u"ࠬࡳ࡯ࡥࡧࠪ૵"): mode, l11111lll1l1_mh_ (u"࠭ࡦࡰ࡮ࡧࡩࡷࡴࡡ࡮ࡧࠪ૶"): name, l11111lll1l1_mh_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨ૷") : url, l11111lll1l1_mh_ (u"ࠨࡲࡤ࡫ࡪ࠭૸"):l1llllllll1l1_mh_,l11111lll1l1_mh_ (u"ࠩࡰ࡭ࡳ࡬࡯ࠨૹ"):str(infoLabels)})
    isFolder = infoLabels.get(l11111lll1l1_mh_ (u"ࠪ࡭ࡸࡌ࡯࡭ࡦࡨࡶࠬૺ"),isFolder)
    if isFolder and infoLabels.get(l11111lll1l1_mh_ (u"ࠫࡾ࡫ࡡࡳࠩૻ"),False):
        name += l11111lll1l1_mh_ (u"ࠬࠦࠨࠦࡵࠬࠫૼ")%infoLabels.get(l11111lll1l1_mh_ (u"࠭ࡹࡦࡣࡵࠫ૽"))
    l1l1lll11lll1l1_mh_ = xbmcgui.ListItem(name)
    l1lll1llllll1l1_mh_=[l11111lll1l1_mh_ (u"ࠧࡵࡪࡸࡱࡧ࠭૾"),l11111lll1l1_mh_ (u"ࠨࡲࡲࡷࡹ࡫ࡲࠨ૿"),l11111lll1l1_mh_ (u"ࠩࡥࡥࡳࡴࡥࡳࠩ଀"),l11111lll1l1_mh_ (u"ࠪࡪࡦࡴࡡࡳࡶࠪଁ"),l11111lll1l1_mh_ (u"ࠫࡨࡲࡥࡢࡴࡤࡶࡹ࠭ଂ"),l11111lll1l1_mh_ (u"ࠬࡩ࡬ࡦࡣࡵࡰࡴ࡭࡯ࠨଃ"),l11111lll1l1_mh_ (u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦࠩ଄"),l11111lll1l1_mh_ (u"ࠧࡪࡥࡲࡲࠬଅ")]
    l1llll1lllll1l1_mh_ = dict(zip(l1lll1llllll1l1_mh_,[infoLabels.get(x,l1lllll11lll1l1_mh_) for x in l1lll1llllll1l1_mh_]))
    l1llll1lllll1l1_mh_[l11111lll1l1_mh_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫଆ")] = fanart if fanart else l1llll1lllll1l1_mh_[l11111lll1l1_mh_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬଇ")]
    l1l1lll11lll1l1_mh_.setArt(l1llll1lllll1l1_mh_)
    l1l1lll11lll1l1_mh_.setInfo(type=l11111lll1l1_mh_ (u"ࠥࡺ࡮ࡪࡥࡰࠤଈ"), infoLabels=infoLabels)
    if IsPlayable and not isFolder:
        l1l1lll11lll1l1_mh_.setProperty(l11111lll1l1_mh_ (u"ࠫࡎࡹࡐ࡭ࡣࡼࡥࡧࡲࡥࠨଉ"), l11111lll1l1_mh_ (u"ࠬࡺࡲࡶࡧࠪଊ"))
    ok = xbmcplugin.addDirectoryItem(handle=l1l1ll1lllll1l1_mh_, url=u, listitem=l1l1lll11lll1l1_mh_,isFolder=isFolder,totalItems=l1l1lll1llll1l1_mh_)
    xbmcplugin.addSortMethod(l1l1ll1lllll1l1_mh_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l11111lll1l1_mh_ (u"ࠨࠥࡓ࠮ࠣࠩ࡞࠲ࠠࠦࡒࠥଋ"))
    return ok
def l1ll111lllll1l1_mh_(name,ex_link=None, l1llllllll1l1_mh_=1, mode=l11111lll1l1_mh_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧଌ"),iconImage=l11111lll1l1_mh_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬ଍"), infoLabels={}, fanart=l1l11l111lll1l1_mh_,contextmenu=None):
    url = l1lll1ll1lll1l1_mh_({l11111lll1l1_mh_ (u"ࠩࡰࡳࡩ࡫ࠧ଎"): mode, l11111lll1l1_mh_ (u"ࠪࡪࡴࡲࡤࡦࡴࡱࡥࡲ࡫ࠧଏ"): name, l11111lll1l1_mh_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬଐ") : ex_link, l11111lll1l1_mh_ (u"ࠬࡶࡡࡨࡧࠪ଑") : l1llllllll1l1_mh_})
    l1ll11l11lll1l1_mh_ = xbmcgui.ListItem(name)
    if infoLabels:
        l1ll11l11lll1l1_mh_.setInfo(type=l11111lll1l1_mh_ (u"ࠨࡶࡪࡦࡨࡳࠧ଒"), infoLabels=infoLabels)
    l1lll1llllll1l1_mh_=[l11111lll1l1_mh_ (u"ࠧࡵࡪࡸࡱࡧ࠭ଓ"),l11111lll1l1_mh_ (u"ࠨࡲࡲࡷࡹ࡫ࡲࠨଔ"),l11111lll1l1_mh_ (u"ࠩࡥࡥࡳࡴࡥࡳࠩକ"),l11111lll1l1_mh_ (u"ࠪࡧࡱ࡫ࡡࡳࡣࡵࡸࠬଖ"),l11111lll1l1_mh_ (u"ࠫࡨࡲࡥࡢࡴ࡯ࡳ࡬ࡵࠧଗ"),l11111lll1l1_mh_ (u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨଘ"),l11111lll1l1_mh_ (u"࠭ࡩࡤࡱࡱࠫଙ")]
    l1llll1lllll1l1_mh_ = dict(zip(l1lll1llllll1l1_mh_,[infoLabels.get(x,iconImage) for x in l1lll1llllll1l1_mh_]))
    l1llll1lllll1l1_mh_[l11111lll1l1_mh_ (u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪଚ")] = fanart if fanart else l1llll1lllll1l1_mh_[l11111lll1l1_mh_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫଛ")]
    l1ll11l11lll1l1_mh_.setArt(l1llll1lllll1l1_mh_)
    if contextmenu:
        l1ll1l11llll1l1_mh_=contextmenu
        l1ll11l11lll1l1_mh_.addContextMenuItems(l1ll1l11llll1l1_mh_, replaceItems=True)
    else:
        l1ll1l11llll1l1_mh_ = []
        l1ll1l11llll1l1_mh_.append((l11111lll1l1_mh_ (u"ࠩࡌࡲ࡫ࡵࡲ࡮ࡣࡦ࡮ࡦ࠭ଜ"), l11111lll1l1_mh_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡃࡦࡸ࡮ࡵ࡮ࠩࡋࡱࡪࡴ࠯ࠧଝ")),)
        l1ll11l11lll1l1_mh_.addContextMenuItems(l1ll1l11llll1l1_mh_, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=l1l1ll1lllll1l1_mh_, url=url,listitem=l1ll11l11lll1l1_mh_, isFolder=True)
    xbmcplugin.addSortMethod(l1l1ll1lllll1l1_mh_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l11111lll1l1_mh_ (u"ࠦࠪࡘࠬࠡࠧ࡜࠰ࠥࠫࡐࠣଞ"))
def l1l1ll11llll1l1_mh_(name, url=l11111lll1l1_mh_ (u"ࠬ࠭ଟ"), mode=l11111lll1l1_mh_ (u"࠭ࠧଠ"), l1lllll11lll1l1_mh_=None, fanart=l1l11l111lll1l1_mh_):
    u = l1lll1ll1lll1l1_mh_({l11111lll1l1_mh_ (u"ࠧ࡮ࡱࡧࡩࠬଡ"): mode, l11111lll1l1_mh_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬଢ"): name, l11111lll1l1_mh_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪଣ") : url, l11111lll1l1_mh_ (u"ࠪࡴࡦ࡭ࡥࠨତ"):1})
    l1l1lll11lll1l1_mh_ = xbmcgui.ListItem(name, iconImage=l1lllll11lll1l1_mh_, thumbnailImage=l1lllll11lll1l1_mh_)
    l1l1lll11lll1l1_mh_.setProperty(l11111lll1l1_mh_ (u"ࠫࡎࡹࡐ࡭ࡣࡼࡥࡧࡲࡥࠨଥ"), l11111lll1l1_mh_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫଦ"))
    if fanart:
        l1l1lll11lll1l1_mh_.setProperty(l11111lll1l1_mh_ (u"࠭ࡦࡢࡰࡤࡶࡹࡥࡩ࡮ࡣࡪࡩࠬଧ"),fanart)
    ok = xbmcplugin.addDirectoryItem(handle=l1l1ll1lllll1l1_mh_, url=u, listitem=l1l1lll11lll1l1_mh_,isFolder=False)
    return ok
def l1l1111llll1l1_mh_(l111lll1lll1l1_mh_):
    l1l1l11llll1l1_mh_ = {}
    for k, v in l111lll1lll1l1_mh_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l11111lll1l1_mh_ (u"ࠧࡶࡶࡩ࠼ࠬନ"))
        elif isinstance(v, str):
            v.decode(l11111lll1l1_mh_ (u"ࠨࡷࡷࡪ࠽࠭଩"))
        l1l1l11llll1l1_mh_[k] = v
    return l1l1l11llll1l1_mh_
def l1lll1ll1lll1l1_mh_(query):
    return l1ll11ll1lll1l1_mh_ + l11111lll1l1_mh_ (u"ࠩࡂࠫପ") + urllib.urlencode(l1l1111llll1l1_mh_(query))
def l1llllll1lll1l1_mh_(params,l1l1l1l1llll1l1_mh_=[],index=False):
    import l1111llllll1l1_mh_ as l1l11l11llll1l1_mh_
    out = l1l11l11llll1l1_mh_.l1l11l11lll1l1_mh_(**params)
    l1l1l1111lll1l1_mh_ = {}
    if out:
        l1l1l1111lll1l1_mh_ = out[0]
        l1l1l11lllll1l1_mh_=l11111lll1l1_mh_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࠨࡷࠬଫ") %l1l1l1111lll1l1_mh_.get(l11111lll1l1_mh_ (u"ࠫ࡮ࡪࠧବ"))
        try:
            import urlresolver
            l1l1l1111lll1l1_mh_[l11111lll1l1_mh_ (u"ࠬࡻࡲ࡭ࠩଭ")] = urlresolver.resolve(l1l1l11lllll1l1_mh_)
        except:
            pass
    if index:
        l1l1l1l1llll1l1_mh_[index]=l1l1l1111lll1l1_mh_
    return l1l1l1111lll1l1_mh_
l1lll111llll1l1_mh_=l11111lll1l1_mh_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤࡦࡱ࠲ࡷ࡫ࡰ࡭ࡣ࠱࡭ࡴ࠵࡬ࡰࡩࡲ࠳࠶࠻࠵࠵࠲࠱ࡴࡳ࡭ࠧମ")
l1lll1l11lll1l1_mh_=l11111lll1l1_mh_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡱࡧࡷࡿࡰࡵࡧࡧ࠱ࡹࡨ࡮࠱࠰ࡪࡷࡹࡧࡴࡪࡥ࠱ࡧࡴࡳ࠯ࡪ࡯ࡤ࡫ࡪࡹ࠿ࡲ࠿ࡷࡦࡳࡀࡁࡏࡦ࠼ࡋࡨࡗࡗࡃࡖࡄࡉ࡛ࡴ࠵ࡎࡣ࡛ࡖࡩ࠽ࡑࡄ࡙࠳ࡳࡉࡪࡈ࠶࡛࠵࡛ࡍࡈࡈࡅࡲࡥ࠹ࡇࡿࡴ࠲ࡃࡪࡹࡘ࡜ࡆ࡫ࡗࡳࡷ࠼࡛࠵ࡨࠩଯ")
class l1lllll1l1_mh_():
    @staticmethod
    def root():
        l1ll111lllll1l1_mh_(name=l11111lll1l1_mh_ (u"ࠨࡋࡱࡪࡴࡸ࡭ࡢࡥ࡭ࡥࠬର"),mode=l11111lll1l1_mh_ (u"ࠩࡢ࡭ࡳ࡬࡯ࡠࠩ଱"),ex_link=None,iconImage=l1l11ll1llll1l1_mh_,infoLabels={})
        l1ll111lllll1l1_mh_(name=l11111lll1l1_mh_ (u"ࠪࡑࡺࡹࡩࡹࡊࡸࡦ࠿ࠦࡐࡰࡲࡸࡰࡦࡸࠠࡂ࡮ࡥࡹࡲࡹࠧଲ"),mode=l11111lll1l1_mh_ (u"ࠫࡦࡲࡢࡶ࡯ࡼࠫଳ"),ex_link=l11111lll1l1_mh_ (u"ࠬ࠭଴"),iconImage=l1l1llll1lll1l1_mh_,infoLabels={})
        l1ll111lllll1l1_mh_(name=l11111lll1l1_mh_ (u"࠭ࡍࡶࡵ࡬ࡼࡍࡻࡢ࠻ࠢࡉࡩࡦࡺࡵࡳࡧࡧࠤࡆࡸࡴࡪࡵࡷࡷࠬଵ"),mode=l11111lll1l1_mh_ (u"ࠧࡢࡴࡷ࡭ࡸࡺࡳࠨଶ"),ex_link=None,iconImage=l1l1llll1lll1l1_mh_,infoLabels={})
        l1ll111lllll1l1_mh_(name=l11111lll1l1_mh_ (u"ࠨࡏࡸࡷ࡮ࡾࡈࡶࡤ࠽ࠤࡌ࡫࡮ࡳࡧࡶࠫଷ"),mode=l11111lll1l1_mh_ (u"ࠩࡪࡩࡳࡸࡥࡴࠩସ"),ex_link=None, iconImage=l1l1llll1lll1l1_mh_,infoLabels={})
        l1ll111lllll1l1_mh_(name=l11111lll1l1_mh_ (u"ࠪࡐ࡮ࡹࡴࡢࠢࡓࡶࡿ࡫ࡢࡰ࡬ࣶࡻࠥࡶࡲࡰࡩࡵࡥࡲࡻࠠ࠴ࠩହ"),mode=l11111lll1l1_mh_ (u"ࠫࡱ࡯ࡳࡵࡣࠪ଺"),ex_link=l11111lll1l1_mh_ (u"ࠬࡺࡲࡰ࡬࡮ࡥࠬ଻"), iconImage=l1lll111llll1l1_mh_)
        l1ll111lllll1l1_mh_(name=l11111lll1l1_mh_ (u"࠭ࡐࡰࡲ࡯࡭ࡸࡺࡡࠡࡔࡐࡊࠥࡌࡍࠨ଼"),mode=l11111lll1l1_mh_ (u"ࠧ࡭࡫ࡶࡸࡦ࠭ଽ"),ex_link=l11111lll1l1_mh_ (u"ࠨࡴࡰࡪ࡫ࡳࠧା"), iconImage=l1lll1l11lll1l1_mh_)
        l1ll111lllll1l1_mh_(name=l11111lll1l1_mh_ (u"ࠩࡖࡩࡦࡸࡣࡩࠩି"),mode=l11111lll1l1_mh_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪୀ"),ex_link=None)
        xbmcplugin.endOfDirectory(l1l1ll1lllll1l1_mh_)
    @staticmethod
    def l1l111lll1l1_mh_():
        import l1111llllll1l1_mh_ as l1l11l11llll1l1_mh_
        out = l1l11l11llll1l1_mh_.l1l1l1l1lll1l1_mh_()
        for f in out:
            l1l1ll111lll1l1_mh_(name=f.get(l11111lll1l1_mh_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪୁ")), url=f.get(l11111lll1l1_mh_ (u"ࠬ࡮ࡲࡦࡨࠪୂ")), mode=l11111lll1l1_mh_ (u"࠭ࡡ࡭ࡤࡸࡱࡤࡩ࡯࡯ࡶࡨࡲࡹ࠭ୃ"), l1lllll11lll1l1_mh_=f.get(l11111lll1l1_mh_ (u"ࠧࡪ࡯ࡪࠫୄ")), infoLabels=f, isFolder=True, IsPlayable=False)
        xbmcplugin.endOfDirectory(l1l1ll1lllll1l1_mh_)
    @staticmethod
    def l1l11llll1l1_mh_(l1lllll1llll1l1_mh_):
        params = dict(urlparse.parse_qsl(l1lllll1llll1l1_mh_))
        import l1111llllll1l1_mh_ as l1l11l11llll1l1_mh_
        out = l1l11l11llll1l1_mh_.l111l11llll1l1_mh_(**params)
        if len(out)>1:
            l1l1ll111lll1l1_mh_(l11111lll1l1_mh_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬࡫࡭ࡺࡢ࡭ࡷࡨࡡࡠࡈ࡝ࡑ࡮ࡤࡽࠥࡇ࡬ࡣࡷࡰ࡟࠴ࡈ࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ୅"), url=urllib.quote(str(out)), mode=l11111lll1l1_mh_ (u"ࠩࡳࡰࡦࡿ࡙ࡕࡎࡄࡰࡱ࠭୆"), infoLabels={l11111lll1l1_mh_ (u"ࠪࡴࡱࡵࡴࠨେ"):l11111lll1l1_mh_ (u"ࠦࡕࡲࡡࡺࠢࡄࡰࡧࡻ࡭ࠣୈ")}, l1lllll11lll1l1_mh_=l1l1llll1lll1l1_mh_, IsPlayable=True)
        for f in out:
            l1l1ll111lll1l1_mh_(name=f.get(l11111lll1l1_mh_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ୉")), url=f.get(l11111lll1l1_mh_ (u"࠭ࡨࡳࡧࡩࠫ୊")), mode=l11111lll1l1_mh_ (u"ࠧࡱ࡮ࡤࡽ࡞࡚ࡌࠨୋ"), l1lllll11lll1l1_mh_=f.get(l11111lll1l1_mh_ (u"ࠨ࡫ࡰ࡫ࠬୌ")), infoLabels=f, IsPlayable=True)
        xbmcplugin.endOfDirectory(l1l1ll1lllll1l1_mh_)
    @staticmethod
    def l1llll1l1_mh_():
        import l1111llllll1l1_mh_ as l1l11l11llll1l1_mh_
        out = l1l11l11llll1l1_mh_.l11l1111lll1l1_mh_()
        for f in out:
            l1l1ll111lll1l1_mh_(name=f.get(l11111lll1l1_mh_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ୍")), url=f.get(l11111lll1l1_mh_ (u"ࠪ࡬ࡷ࡫ࡦࠨ୎")), mode=l11111lll1l1_mh_ (u"ࠫࡦࡸࡴࡪࡵࡷࡣࡨࡵ࡮ࡵࡧࡱࡸࠬ୏"), l1lllll11lll1l1_mh_=f.get(l11111lll1l1_mh_ (u"ࠬ࡯࡭ࡨࠩ୐")), infoLabels=f, isFolder=True, IsPlayable=False)
        xbmcplugin.endOfDirectory(l1l1ll1lllll1l1_mh_)
    @staticmethod
    def l1l1lllll1l1_mh_(artist):
        import l1111llllll1l1_mh_ as l1l11l11llll1l1_mh_
        out = l1l11l11llll1l1_mh_.l111111llll1l1_mh_(artist)
        for f in out:
            l1l1ll111lll1l1_mh_(name=f.get(l11111lll1l1_mh_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ୑")), url=f.get(l11111lll1l1_mh_ (u"ࠧࡩࡴࡨࡪࠬ୒")), mode=l11111lll1l1_mh_ (u"ࠨࡣ࡯ࡦࡺࡳ࡟ࡤࡱࡱࡸࡪࡴࡴࠨ୓"), l1lllll11lll1l1_mh_=f.get(l11111lll1l1_mh_ (u"ࠩ࡬ࡱ࡬࠭୔")), infoLabels=f, isFolder=True, IsPlayable=False)
        xbmcplugin.endOfDirectory(l1l1ll1lllll1l1_mh_)
    @staticmethod
    def l111lll1l1_mh_():
        import l1111llllll1l1_mh_ as l1l11l11llll1l1_mh_
        out = l1l11l11llll1l1_mh_.l1l111lllll1l1_mh_()
        for f in out:
            l1l1ll111lll1l1_mh_(name=f.get(l11111lll1l1_mh_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ୕")), url=f.get(l11111lll1l1_mh_ (u"ࠫ࡭ࡸࡥࡧࠩୖ")), mode=l11111lll1l1_mh_ (u"ࠬ࡭ࡥ࡯ࡴࡨࡷࡤࡩ࡯࡯ࡶࡨࡲࡹ࠭ୗ"), l1lllll11lll1l1_mh_=f.get(l11111lll1l1_mh_ (u"࠭ࡩ࡮ࡩࠪ୘")), infoLabels=f, isFolder=True, IsPlayable=False)
        xbmcplugin.endOfDirectory(l1l1ll1lllll1l1_mh_)
    @staticmethod
    def l11l1lll1l1_mh_(key=l11111lll1l1_mh_ (u"ࠧࠨ୙")):
        import l1111llllll1l1_mh_ as l1l11l11llll1l1_mh_
        out = l1l11l11llll1l1_mh_.l11l1lll1l1_mh_(key)
        for f in out:
            l1l1ll111lll1l1_mh_(name=f.get(l11111lll1l1_mh_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ୚")), url=f.get(l11111lll1l1_mh_ (u"ࠩ࡫ࡶࡪ࡬ࠧ୛")), mode=l11111lll1l1_mh_ (u"ࠪࡥࡱࡨࡵ࡮ࡡࡦࡳࡳࡺࡥ࡯ࡶࠪଡ଼"), l1lllll11lll1l1_mh_=f.get(l11111lll1l1_mh_ (u"ࠫ࡮ࡳࡧࠨଢ଼")), infoLabels=f, isFolder=True, IsPlayable=False)
        xbmcplugin.endOfDirectory(l1l1ll1lllll1l1_mh_)
    @staticmethod
    def l1lll1l1_mh_(l1lllll1llll1l1_mh_):
        params = dict(urlparse.parse_qsl(l1lllll1llll1l1_mh_))
        import l1111llllll1l1_mh_ as l1l11l11llll1l1_mh_
        out = l1l11l11llll1l1_mh_.l1l11l11lll1l1_mh_(**params)
        if out:
            l1l1l11lllll1l1_mh_=l11111lll1l1_mh_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁࠪࡹࠧ୞") %out[0].get(l11111lll1l1_mh_ (u"࠭ࡩࡥࠩୟ"))
            try:
                import urlresolver
                l1l111l11lll1l1_mh_ = urlresolver.resolve(l1l1l11lllll1l1_mh_)
            except Exception,e:
                l1l111l11lll1l1_mh_=l11111lll1l1_mh_ (u"ࠧࠨୠ")
            if l1l111l11lll1l1_mh_:
                xbmcplugin.setResolvedUrl(l1l1ll1lllll1l1_mh_, True, xbmcgui.ListItem(path=l1l111l11lll1l1_mh_))
            else:
                xbmcplugin.setResolvedUrl(l1l1ll1lllll1l1_mh_, False, xbmcgui.ListItem(path=l11111lll1l1_mh_ (u"ࠨࠩୡ")))
    @staticmethod
    def l1l1llll1l1_mh_(l1lllll1llll1l1_mh_):
        data = eval(urllib.unquote(l1lllll1llll1l1_mh_))
        l1ll1ll11lll1l1_mh_ = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        l1ll1ll11lll1l1_mh_.clear()
        params = dict(urlparse.parse_qsl(data[0].get(l11111lll1l1_mh_ (u"ࠩ࡫ࡶࡪ࡬ࠧୢ"))))
        first = l1llllll1lll1l1_mh_(params)
        l1l1lll11lll1l1_mh_ = xbmcgui.ListItem(first.get(l11111lll1l1_mh_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩୣ")) )
        l1l1lll11lll1l1_mh_.setArt( {l11111lll1l1_mh_ (u"ࠫࡹ࡮ࡵ࡮ࡤࠪ୤"):first.get(l11111lll1l1_mh_ (u"ࠬ࡯࡭ࡨࠩ୥")) } )
        l1l1lll11lll1l1_mh_.setInfo(type=l11111lll1l1_mh_ (u"ࠨࡶࡪࡦࡨࡳࠧ୦"), infoLabels=first)
        l1ll1ll11lll1l1_mh_.add(url=first.get(l11111lll1l1_mh_ (u"ࠧࡶࡴ࡯ࠫ୧")),listitem=l1l1lll11lll1l1_mh_)
        l1ll1ll11lll1l1_mh_.add(url=first.get(l11111lll1l1_mh_ (u"ࠨࡷࡵࡰࠬ୨")),listitem=l1l1lll11lll1l1_mh_)
        if l1ll1ll11lll1l1_mh_:
            xbmcplugin.setResolvedUrl(l1l1ll1lllll1l1_mh_, True, xbmcgui.ListItem(path=l11111lll1l1_mh_ (u"ࠩࠪ୩")))
            for d in data[1:]:
                params = dict(urlparse.parse_qsl(d.get(l11111lll1l1_mh_ (u"ࠪ࡬ࡷ࡫ࡦࠨ୪"))))
                first = l1llllll1lll1l1_mh_(params)
                l1l1lll11lll1l1_mh_ = xbmcgui.ListItem(first.get(l11111lll1l1_mh_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ୫")) )
                l1l1lll11lll1l1_mh_.setArt( {l11111lll1l1_mh_ (u"ࠬࡺࡨࡶ࡯ࡥࠫ୬"):first.get(l11111lll1l1_mh_ (u"࠭ࡩ࡮ࡩࠪ୭")) } )
                l1l1lll11lll1l1_mh_.setInfo(type=l11111lll1l1_mh_ (u"ࠢࡷ࡫ࡧࡩࡴࠨ୮"), infoLabels=first)
                l1ll1ll11lll1l1_mh_.add(url=first.get(l11111lll1l1_mh_ (u"ࠨࡷࡵࡰࠬ୯")),listitem=l1l1lll11lll1l1_mh_)
    @staticmethod
    def info():
        l1ll1lllllll1l1_mh_.__myinfo__.go(sys.argv)
        xbmcplugin.endOfDirectory(l1l1ll1lllll1l1_mh_)
    @staticmethod
    def l11ll1lll1l1_mh_(ex_link):
        import l1111llllll1l1_mh_ as l1l11l11llll1l1_mh_
        out,info = l1l11l11llll1l1_mh_.l1l111l1lll1l1_mh_(ex_link)
        l1l11lllllll1l1_mh_ = l1lll1l11lll1l1_mh_ if l11111lll1l1_mh_ (u"ࠩࡵࡱ࡫࡬࡭ࠨ୰") in ex_link else l1lll111llll1l1_mh_
        if len(out)>1: l1l1ll111lll1l1_mh_(l11111lll1l1_mh_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡰ࡮࡭ࡨࡵࡤ࡯ࡹࡪࡣ࡛ࡃ࡟ࡊࡶࡦࡰࠠࠦࡵ࡞࠳ࡇࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨୱ")%info, url=urllib.quote(str(out)), mode=l11111lll1l1_mh_ (u"ࠫࡵࡲࡡࡺ࡛ࡗࡐࡆࡲ࡬ࠨ୲"), infoLabels={l11111lll1l1_mh_ (u"ࠬࡶ࡬ࡰࡶࠪ୳"):info}, l1lllll11lll1l1_mh_=l1l11lllllll1l1_mh_, IsPlayable=True)
        for f in out:  l1l1ll111lll1l1_mh_(name=f.get(l11111lll1l1_mh_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ୴")), url=f.get(l11111lll1l1_mh_ (u"ࠧࡩࡴࡨࡪࠬ୵")), mode=l11111lll1l1_mh_ (u"ࠨࡲ࡯ࡥࡾ࡟ࡔࡍࠩ୶"), l1lllll11lll1l1_mh_=f.get(l11111lll1l1_mh_ (u"ࠩ࡬ࡱ࡬࠭୷")), infoLabels=f, IsPlayable=True)
        xbmcplugin.endOfDirectory(l1l1ll1lllll1l1_mh_)
    @staticmethod
    def l1ll1llll1l1_mh_(mode,ex_link):
        from l1l1l111llll1l1_mh_ import l1l11l1lllll1l1_mh_
        l1l111llllll1l1_mh_=mode.split(l11111lll1l1_mh_ (u"ࠥ࠾ࠧ୸"))[-1] if l11111lll1l1_mh_ (u"ࠫ࠿࠭୹") in mode else l11111lll1l1_mh_ (u"ࠬ࠭୺")
        if l1l111llllll1l1_mh_ == l11111lll1l1_mh_ (u"࠭ࠧ୻"):
            l1ll111lllll1l1_mh_(l11111lll1l1_mh_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠ࡭࡫ࡪ࡬ࡹ࡭ࡲࡦࡧࡱࡡࡓࡵࡷࡦࠢࡶࡾࡺࡱࡡ࡯࡫ࡨࠤ࠳࠴࠮࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ୼"),ex_link=l11111lll1l1_mh_ (u"ࠨࠩ୽"),mode=l11111lll1l1_mh_ (u"ࠩࡶࡩࡦࡸࡣࡩ࠼ࡱࡩࡼࡥࡡࡳࡶ࡬ࡷࡹ࠭୾"))
            l1l1l1ll1lll1l1_mh_ = l1l11l1lllll1l1_mh_().l1l1llllllll1l1_mh_()
            if not l1l1l1ll1lll1l1_mh_ == [l11111lll1l1_mh_ (u"ࠪࠫ୿")]:
                for entry in l1l1l1ll1lll1l1_mh_:
                    contextmenu = []
                    contextmenu.append((l11111lll1l1_mh_ (u"ࡹࠬࡘࡥ࡮ࡱࡹࡩࠬ஀"), l11111lll1l1_mh_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠨࠦࡵࠬࠫ஁")% l1lll1ll1lll1l1_mh_({l11111lll1l1_mh_ (u"࠭࡭ࡰࡦࡨࠫஂ"): l11111lll1l1_mh_ (u"ࠧࡴࡧࡤࡶࡨ࡮࠺ࡥࡧ࡯ࡓࡳ࡫ࠧஃ"), l11111lll1l1_mh_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩ஄") : entry})),)
                    contextmenu.append((l11111lll1l1_mh_ (u"ࡷࠪࡖࡪࡳ࡯ࡷࡧࠣࡅࡱࡲࠧஅ"), l11111lll1l1_mh_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࠪࡹࠩࠨஆ") % l1lll1ll1lll1l1_mh_({l11111lll1l1_mh_ (u"ࠫࡲࡵࡤࡦࠩஇ"): l11111lll1l1_mh_ (u"ࠬࡹࡥࡢࡴࡦ࡬࠿ࡪࡥ࡭ࡃ࡯ࡰࠬஈ")})),)
                    l1ll111lllll1l1_mh_(name=entry, ex_link=entry, mode=l11111lll1l1_mh_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡀ࡮ࡦࡹࡢࡥࡷࡺࡩࡴࡶࠪஉ"), fanart=None, contextmenu=contextmenu)
            xbmcplugin.endOfDirectory(l1l1ll1lllll1l1_mh_)
        elif l1l111llllll1l1_mh_ ==l11111lll1l1_mh_ (u"ࠧ࡯ࡧࡺࡣࡦࡸࡴࡪࡵࡷࠫஊ"):
            if not ex_link:
                l1l11l1l1lll1l1_mh_ = l1ll11lll1l1_mh_.input(l11111lll1l1_mh_ (u"ࡶࠩࡑࡥࡿࡽࡡࠡࡹࡼ࡯ࡴࡴࡡࡸࡥࡼࠫ஋"), type=xbmcgui.INPUT_ALPHANUM)
                if l1l11l1l1lll1l1_mh_: l1l11l1lllll1l1_mh_().l1l1l1l11lll1l1_mh_(l1l11l1l1lll1l1_mh_)
            else:
                l1l11l1l1lll1l1_mh_ = ex_link
            if l1l11l1l1lll1l1_mh_:
                import l1111llllll1l1_mh_ as l1l11l11llll1l1_mh_
                out = l1l11l11llll1l1_mh_.l111111llll1l1_mh_(l1l11l1l1lll1l1_mh_)
                for f in out:
                    l1l1ll111lll1l1_mh_(name=f.get(l11111lll1l1_mh_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ஌")), url=f.get(l11111lll1l1_mh_ (u"ࠪ࡬ࡷ࡫ࡦࠨ஍")), mode=l11111lll1l1_mh_ (u"ࠫࡦࡲࡢࡶ࡯ࡢࡧࡴࡴࡴࡦࡰࡷࠫஎ"), l1lllll11lll1l1_mh_=f.get(l11111lll1l1_mh_ (u"ࠬ࡯࡭ࡨࠩஏ")), infoLabels=f, isFolder=True, IsPlayable=False)
            xbmcplugin.endOfDirectory(l1l1ll1lllll1l1_mh_)
        elif l1l111llllll1l1_mh_ ==l11111lll1l1_mh_ (u"࠭ࡤࡦ࡮ࡒࡲࡪ࠭ஐ"):
            l1l11l1lllll1l1_mh_().l1ll1l1l1lll1l1_mh_(ex_link)
            xbmc.executebuiltin(l11111lll1l1_mh_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠪࠨࡷ࠮࠭஑")%  l1lll1ll1lll1l1_mh_({l11111lll1l1_mh_ (u"ࠨ࡯ࡲࡨࡪ࠭ஒ"): l11111lll1l1_mh_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩஓ")}))
        elif l1l111llllll1l1_mh_ ==l11111lll1l1_mh_ (u"ࠪࡨࡪࡲࡁ࡭࡮ࠪஔ"):
            l1l11l1lllll1l1_mh_().l1lll1l1llll1l1_mh_()
            xbmc.executebuiltin(l11111lll1l1_mh_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠮ࠥࡴࠫࠪக")%  l1lll1ll1lll1l1_mh_({l11111lll1l1_mh_ (u"ࠬࡳ࡯ࡥࡧࠪ஖"): l11111lll1l1_mh_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭஗")}))
        xbmcplugin.setContent(l1l1ll1lllll1l1_mh_, l11111lll1l1_mh_ (u"ࠧ࡮ࡱࡹ࡭ࡪࡹࠧ஘"))
    @staticmethod
    def l1l11ll11lll1l1_mh_(ex_link):
        from l1111lllll1l1_mh_ import l1ll1llllll1l1_mh_
        l1l1l11lllll1l1_mh_ = l1ll1llllll1l1_mh_().l11l1lllll1l1_mh_(ex_link)
        if l1l1l11lllll1l1_mh_:
            l1l111l11lll1l1_mh_=l1ll1lllllll1l1_mh_.__mysolver__.go(l1l1l11lllll1l1_mh_)
            if not l1l111l11lll1l1_mh_:
                try:
                    import urlresolver
                    l1l111l11lll1l1_mh_ = urlresolver.resolve(l1l1l11lllll1l1_mh_)
                except Exception,e:
                    l1l111l11lll1l1_mh_=l11111lll1l1_mh_ (u"ࠨࠩங")
            if l1l111l11lll1l1_mh_:
                xbmcplugin.setResolvedUrl(l1l1ll1lllll1l1_mh_, True, xbmcgui.ListItem(path=l1l111l11lll1l1_mh_))
            else:
                xbmcplugin.setResolvedUrl(l1l1ll1lllll1l1_mh_, False, xbmcgui.ListItem(path=l11111lll1l1_mh_ (u"ࠩࠪச")))
        else:
            l1ll11lll1l1_mh_.notification(l1llll11llll1l1_mh_, l11111lll1l1_mh_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝࡜ࡄࡠࠤࡇࡸࡡ࡬ࠢॽࡶࣸࡪࡥृࠢ࡞࠳ࡇࡣ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ஛") , xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l11111lll1l1_mh_ (u"ࠫࡵࡧࡴࡩࠩஜ")))+l11111lll1l1_mh_ (u"ࠬ࠵ࡩࡤࡱࡱ࠲ࡵࡴࡧࠨ஝"), 5000, False)
    @staticmethod
    def l1ll11111lll1l1_mh_(ex_link):
        from l1111lllll1l1_mh_ import l1111l1lll1l1_mh_
        out = l1111l1lll1l1_mh_().l111111lll1l1_mh_(ex_link)
        for f in out:
            l1ll111lllll1l1_mh_(name=f.get(l11111lll1l1_mh_ (u"࠭ࡴࡪࡶ࡯ࡩࠬஞ")),ex_link=f.get(l11111lll1l1_mh_ (u"ࠧࡩࡴࡨࡪࠬட")),  mode=l11111lll1l1_mh_ (u"ࠨࡵࡨࡶ࡮ࡧ࡬ࡦࡡࡶࡩࡦࡹ࡯࡯ࡵࠪ஠"),iconImage=f.get(l11111lll1l1_mh_ (u"ࠩ࡬ࡱ࡬࠭஡")), infoLabels=f)
        xbmcplugin.setContent(l1l1ll1lllll1l1_mh_, l11111lll1l1_mh_ (u"ࠪࡸࡻࡹࡨࡰࡹࡶࠫ஢"))
        xbmcplugin.endOfDirectory(l1l1ll1lllll1l1_mh_)
    @staticmethod
    def l1l1ll1l1lll1l1_mh_(ex_link):
        from l1111lllll1l1_mh_ import l1111l1lll1l1_mh_
        out = l1111l1lll1l1_mh_().l1ll111llll1l1_mh_(ex_link)
        l11111llll1l1_mh_ = l1111l1lll1l1_mh_().l1lll1lllll1l1_mh_(out)
        for l1lll11l1lll1l1_mh_ in sorted(l11111llll1l1_mh_.keys()):
            l1ll111lllll1l1_mh_(name=l1lll11l1lll1l1_mh_, ex_link=urllib.quote(str(l11111llll1l1_mh_[l1lll11l1lll1l1_mh_])), mode=l11111lll1l1_mh_ (u"ࠫࡸ࡫ࡲࡪࡣ࡯ࡩࡤ࡫ࡰࡪࡵࡲࡨࡪࡹࠧண"))
        xbmcplugin.setContent(l1l1ll1lllll1l1_mh_, l11111lll1l1_mh_ (u"ࠬࡺࡶࡴࡪࡲࡻࡸ࠭த"))
        xbmcplugin.endOfDirectory(l1l1ll1lllll1l1_mh_)
    @staticmethod
    def l1l111l1llll1l1_mh_(ex_link):
        l1lll111lll1l1_mh_ = eval(urllib.unquote(ex_link))
        for f in l1lll111lll1l1_mh_:
            l1l1ll111lll1l1_mh_(name=f.get(l11111lll1l1_mh_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ஥")), url=f.get(l11111lll1l1_mh_ (u"ࠧࡩࡴࡨࡪࠬ஦")), mode=l11111lll1l1_mh_ (u"ࠨࡲ࡯ࡥࡾ࡙ࡥࡳ࡫ࡤࡰࡪ࠭஧"), l1lllll11lll1l1_mh_=f.get(l11111lll1l1_mh_ (u"ࠩ࡬ࡱ࡬࠭ந")), infoLabels=f, IsPlayable=True)
        xbmcplugin.setContent(l1l1ll1lllll1l1_mh_, l11111lll1l1_mh_ (u"ࠪࡩࡵ࡯ࡳࡰࡦࡨࡷࠬன"))
        xbmcplugin.endOfDirectory(l1l1ll1lllll1l1_mh_)
    @staticmethod
    def l1lll1111lll1l1_mh_(ex_link):
        from l1111lllll1l1_mh_ import l1111l1lll1l1_mh_
        l1l1l11lllll1l1_mh_ = l1111l1lll1l1_mh_().l1l1llllll1l1_mh_(ex_link)
        if l1l1l11lllll1l1_mh_:
            l1l111l11lll1l1_mh_=l1ll1lllllll1l1_mh_.__mysolver__.go(l1l1l11lllll1l1_mh_)
            if not l1l111l11lll1l1_mh_:
                try:
                    import urlresolver
                    l1l111l11lll1l1_mh_ = urlresolver.resolve(l1l1l11lllll1l1_mh_)
                except Exception,e:
                    l1l111l11lll1l1_mh_=l11111lll1l1_mh_ (u"ࠫࠬப")
            if l1l111l11lll1l1_mh_:
                xbmcplugin.setResolvedUrl(l1l1ll1lllll1l1_mh_, True, xbmcgui.ListItem(path=l1l111l11lll1l1_mh_))
            else:
                xbmcplugin.setResolvedUrl(l1l1ll1lllll1l1_mh_, False, xbmcgui.ListItem(path=l11111lll1l1_mh_ (u"ࠬ࠭஫")))
        else:
            l1ll11lll1l1_mh_.notification(l1llll11llll1l1_mh_, l11111lll1l1_mh_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠ࡟ࡇࡣࠠࡃࡴࡤ࡯ࠥঀࡲࣴࡦࡨॆࠥࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫ஬") , xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l11111lll1l1_mh_ (u"ࠧࡱࡣࡷ࡬ࠬ஭")))+l11111lll1l1_mh_ (u"ࠨ࠱࡬ࡧࡴࡴ࠮ࡱࡰࡪࠫம"), 5000, False)
