# coding: UTF-8
import sys
l1ll11ll11l1_cdhd_ = sys.version_info [0] == 2
l11ll1ll11l1_cdhd_ = 2048
l1111ll11l1_cdhd_ = 7
def l1lll1ll11l1_cdhd_ (keyedStringLiteral):
	global l1l111ll11l1_cdhd_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll11l1_cdhd_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import xbmc,xbmcgui
import time,re,os,threading
try: from shutil import rmtree
except: rmtree = False
def l1l1ll11l1_cdhd_(l11111ll11l1_cdhd_,l1llll1ll11l1_cdhd_=[l1lll1ll11l1_cdhd_ (u"ࠫࠬࠀ")]):
    debug=1
def l11ll11l1_cdhd_(name=l1lll1ll11l1_cdhd_ (u"ࠬ࠭ࠁ")):
    debug=1
def l1ll1ll11l1_cdhd_(top):
    debug=1
def check():
    debug=1
try:
    debug=1
except: pass
