# -*- coding: utf-8 -*-
import sys
l1ll11ll11l1_cdhd_ = sys.version_info [0] == 2
l11ll1ll11l1_cdhd_ = 2048
l1111ll11l1_cdhd_ = 7
def l1lll1ll11l1_cdhd_ (keyedStringLiteral):
	global l1l111ll11l1_cdhd_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll11l1_cdhd_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,random,json
import cookielib
l111ll1l1ll11l1_cdhd_=10
l1ll11l1l1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠶࠲࠱࠴࠳࠸࠶࠷࠳࠱࠵࠵࠸ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧ൒")
def l1lll1l111ll11l1_cdhd_(url,data=None,header={},l111111ll1ll11l1_cdhd_=True):
    l1l11111l1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠩࠪ൓")
    l111llll1ll11l1_cdhd_=[]
    if l111111ll1ll11l1_cdhd_:
        l111llll1ll11l1_cdhd_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l111llll1ll11l1_cdhd_))
        urllib2.install_opener(opener)
    if not header:
        header = {l1lll1ll11l1_cdhd_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧൔ"):l1ll11l1l1ll11l1_cdhd_}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=l111ll1l1ll11l1_cdhd_)
        l1ll1l111ll11l1_cdhd_ =  response.read()
        response.close()
        l1l11111l1ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠫࠬൕ").join([l1lll1ll11l1_cdhd_ (u"ࠬࠫࡳ࠾ࠧࡶ࠿ࠬൖ")%(c.name, c.value) for c in l111llll1ll11l1_cdhd_])
    except urllib2.HTTPError as e:
        l1ll1l111ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"࠭ࠧൗ")
    return l1ll1l111ll11l1_cdhd_,l1l11111l1ll11l1_cdhd_
url = l1lll1ll11l1_cdhd_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡸࡡࡱ࡫ࡧࡺ࡮ࡪࡥࡰ࠰ࡦࡳࡲ࠵ࡥ࡮ࡤࡨࡨ࠴࡜࠲ࡗࡵ࡙ࡏ࡝ࡖࠧ൘")
url = l1lll1ll11l1_cdhd_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡲࡢࡲ࡬ࡨࡻ࡯ࡤࡦࡱ࠱ࡧࡴࡳ࠯ࡦ࡯ࡥࡩࡩ࠵ࡅࡄࡥࡼࡅࡗ࡭ࡍࠨ൙")
def l1ll11l11ll11l1_cdhd_(url):
    url = url.replace(l1lll1ll11l1_cdhd_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ൚"),l1lll1ll11l1_cdhd_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼ࠪ൛")).replace(l1lll1ll11l1_cdhd_ (u"ࠫ࠴࡫࡭ࡣࡧࡧ࠳ࠬ൜"),l1lll1ll11l1_cdhd_ (u"ࠬ࠵࠿ࡷ࠿ࠪ൝"))
    content,c = l1lll1l111ll11l1_cdhd_(url)
    match = re.findall(l1lll1ll11l1_cdhd_ (u"࠭ࠧࠨ࡝ࠥࠫࡢࡅࡳࡰࡷࡵࡧࡪࡹ࡛ࠨࠤࡠࡃࡡࡹࠪ࠻࡞ࡶ࠮࠭ࡢ࡛࠯ࠬࡂࡠࡢ࠯ࠧࠨࠩ൞"), content)
    l11111l111ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠧࠨൟ")
    if not match:
        data = {}
        data[l1lll1ll11l1_cdhd_ (u"ࠨࡥࡲࡲ࡫࡯ࡲ࡮࠰ࡼࠫൠ")] = random.randint(0, 120)
        data[l1lll1ll11l1_cdhd_ (u"ࠩࡦࡳࡳ࡬ࡩࡳ࡯࠱ࡼࠬൡ")] = random.randint(0, 120)
        header={l1lll1ll11l1_cdhd_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧൢ"):l1ll11l1l1ll11l1_cdhd_,l1lll1ll11l1_cdhd_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬൣ"):url}
        l11111ll11ll11l1_cdhd_ = url + l1lll1ll11l1_cdhd_ (u"ࠬࠩࠧ൤")
        content,c = l1lll1l111ll11l1_cdhd_(l11111ll11ll11l1_cdhd_,urllib.urlencode(data),header=header)
        match = re.findall(l1lll1ll11l1_cdhd_ (u"࠭ࠧࠨ࡝ࠥࠫࡢࡅࡳࡰࡷࡵࡧࡪࡹ࡛ࠨࠤࡠࡃࡡࡹࠪ࠻࡞ࡶ࠮࠭ࡢ࡛࠯ࠬࡂࡠࡢ࠯ࠧࠨࠩ൥"), content)
    if match:
        try:
            data = json.loads(match[0])
            l11111l111ll11l1_cdhd_=[]
            for d in data:
                if isinstance(d,dict):
                    l11111l1l1ll11l1_cdhd_ = d.get(l1lll1ll11l1_cdhd_ (u"ࠧࡧ࡫࡯ࡩࠬ൦"),l1lll1ll11l1_cdhd_ (u"ࠨࠩ൧"))+l1lll1ll11l1_cdhd_ (u"ࠩࡿ࡙ࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠦࡵࠩࡖࡪ࡬ࡥࡳࡧࡵࡁࠪࡹࠧ൨")%(l1ll11l1l1ll11l1_cdhd_,url)
                    l11111l111ll11l1_cdhd_.append((d.get(l1lll1ll11l1_cdhd_ (u"ࠪࡰࡦࡨࡥ࡭ࠩ൩"),l1lll1ll11l1_cdhd_ (u"ࠫࠬ൪")),l11111l1l1ll11l1_cdhd_))
        except:
            l11111l111ll11l1_cdhd_ = re.findall(l1lll1ll11l1_cdhd_ (u"ࠬ࠭ࠧ࡜ࠩࠥࡡࡄ࡬ࡩ࡭ࡧ࡞ࠫࠧࡣ࠿࡝ࡵ࠭࠾ࡡࡹࠪ࡜ࠩࠥࡡࡄ࠮࡛࡟ࠩࠥࡡ࠰࠯ࠧࠨࠩ൫"), match[0])
            if l11111l111ll11l1_cdhd_:
                l11111l111ll11l1_cdhd_ = l11111l111ll11l1_cdhd_[0].replace(l1lll1ll11l1_cdhd_ (u"࠭࡜࠰ࠩ൬"), l1lll1ll11l1_cdhd_ (u"ࠧ࠰ࠩ൭"))
                l11111l111ll11l1_cdhd_ += l1lll1ll11l1_cdhd_ (u"ࠨࡾࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠥࡴࠨࡕࡩ࡫࡫ࡲࡦࡴࡀࠩࡸ࠭൮")%(l1ll11l1l1ll11l1_cdhd_,url)
    return l11111l111ll11l1_cdhd_
