# -*- coding: utf-8 -*-
import sys
l1ll11ll11l1_cdhd_ = sys.version_info [0] == 2
l11ll1ll11l1_cdhd_ = 2048
l1111ll11l1_cdhd_ = 7
def l1lll1ll11l1_cdhd_ (keyedStringLiteral):
	global l1l111ll11l1_cdhd_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll11l1_cdhd_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import re
import time
import json
import urllib2
_1lllll1111ll11l1_cdhd_ = { l1lll1ll11l1_cdhd_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭൯"): l1lll1ll11l1_cdhd_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠶࠯࠴࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠵࠳࠲࠵࠴࠱࠶࠻࠼࠲࠻࠿ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧ൰")}
_1lllll1ll1ll11l1_cdhd_ = 10
def l1lll1l111ll11l1_cdhd_(url,data={},headers={}):
    req = urllib2.Request(url,json.dumps(data),headers=headers)
    try:
        response = urllib2.urlopen(req, timeout=10)
        l1ll1l111ll11l1_cdhd_ = response.read()
        response.close()
    except:
        l1ll1l111ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠫࠬ൱")
    return l1ll1l111ll11l1_cdhd_
def l1111111ll11l1_cdhd_(url):
    if l1lll1ll11l1_cdhd_ (u"ࠬࡹࡨ࠯ࡵࡷ࠳ࠬ൲") in url:
        url = _1lllllll11ll11l1_cdhd_(url)
    elif l1lll1ll11l1_cdhd_ (u"࠭ࡳࡢࡨࡨࡰ࡮ࡴ࡫ࡪࡰࡪ࠲ࡳ࡫ࡴࠨ൳") in url:
        url = _1llllll1l1ll11l1_cdhd_(url)
    elif l1lll1ll11l1_cdhd_ (u"ࠧࡷ࡫࡬ࡨ࠳ࡳࡥࠨ൴") in url:
        url = _1lllll11l1ll11l1_cdhd_(url)
    return url
def _1lllll11l1ll11l1_cdhd_(uri):
    l111111111ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠨࠩ൵")
    html = l1lll1l111ll11l1_cdhd_(uri, headers=_1lllll1111ll11l1_cdhd_)
    l1llllll111ll11l1_cdhd_ = re.findall(l1lll1ll11l1_cdhd_ (u"ࡴࠪࡷࡪࡹࡳࡪࡱࡱࡍࡩࡢ࠺ࠩ࠰࠭ࡃ࠮ࡢࠢ࡝࠮ࠪ൶"), html)
    if len(l1llllll111ll11l1_cdhd_) > 0:
        l1llllll111ll11l1_cdhd_ = re.sub(l1lll1ll11l1_cdhd_ (u"ࡵࠫࡡࡹ࡜ࠣࠩ൷"), l1lll1ll11l1_cdhd_ (u"ࠫࠬ൸"), l1llllll111ll11l1_cdhd_[0])
        l1111111l1ll11l1_cdhd_ = {
            l1lll1ll11l1_cdhd_ (u"࡛ࠧࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠤ൹"): l1lll1ll11l1_cdhd_ (u"ࠨࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡞࠱࠲࠽ࠣࡐ࡮ࡴࡵࡹࠢࡻ࠼࠻ࡥ࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠹࠳࠷࠱ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠲࠹࠱࠴࠳࠿࠶࠴࠰࠷࠺࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠶࠰࠴࠵ࠧൺ"),
            l1lll1ll11l1_cdhd_ (u"ࠢࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠤൻ"): l1lll1ll11l1_cdhd_ (u"ࠣࡩࡽ࡭ࡵ࠲ࡤࡦࡨ࡯ࡥࡹ࡫ࠬࡴࡦࡦ࡬ࠧർ"),
            l1lll1ll11l1_cdhd_ (u"ࠤࡄࡧࡨ࡫ࡰࡵ࠯ࡏࡥࡳ࡭ࡵࡢࡩࡨࠦൽ"): l1lll1ll11l1_cdhd_ (u"ࠥࡩࡳ࠳ࡕࡔ࠮ࡨࡲࡀ࠲ࡱ࠾࠲࠱࠼ࠧൾ"),
            l1lll1ll11l1_cdhd_ (u"ࠦࡈࡵ࡮࡯ࡧࡦࡸ࡮ࡵ࡮ࠣൿ"): l1lll1ll11l1_cdhd_ (u"ࠧࡱࡥࡦࡲ࠰ࡥࡱ࡯ࡶࡦࠤ඀"),
            l1lll1ll11l1_cdhd_ (u"ࠨࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠧඁ"): l1lll1ll11l1_cdhd_ (u"ࠢࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࠨං"),
            l1lll1ll11l1_cdhd_ (u"ࠣࡊࡲࡷࡹࠨඃ"): l1lll1ll11l1_cdhd_ (u"ࠤࡶ࡬࠳ࡹࡴࠣ඄"),
            l1lll1ll11l1_cdhd_ (u"ࠥࡖࡪ࡬ࡥࡳࡧࡵࠦඅ"): uri,
            l1lll1ll11l1_cdhd_ (u"ࠦࡔࡸࡩࡨ࡫ࡱࠦආ"): l1lll1ll11l1_cdhd_ (u"ࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡼࡩࡪࡦ࠱ࡱࡪࠨඇ"),
            l1lll1ll11l1_cdhd_ (u"ࠨࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠤඈ"): l1lll1ll11l1_cdhd_ (u"࡙ࠢࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠣඉ")
        }
        time.sleep(5)
        l111111l11ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡸ࡬࡭ࡩ࠴࡭ࡦ࠱ࡶ࡬ࡴࡸࡴࡦࡵࡷ࠱ࡺࡸ࡬࠰ࡧࡱࡨ࠲ࡧࡤࡴࡧࡶࡷ࡮ࡵ࡮ࡀࡣࡧࡗࡪࡹࡳࡪࡱࡱࡍࡩࡃࠥࡴࠨࡤࡨࡧࡪ࠽࠲ࠨࡦࡥࡱࡲࡢࡢࡥ࡮ࡁࡨ࠭ඊ")%l1llllll111ll11l1_cdhd_
        response = l1lll1l111ll11l1_cdhd_(l111111l11ll11l1_cdhd_, headers=l1111111l1ll11l1_cdhd_)
        l111111111ll11l1_cdhd_=re.search(l1lll1ll11l1_cdhd_ (u"ࠩࠥࡨࡪࡹࡴࡪࡰࡤࡸ࡮ࡵ࡮ࡖࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭උ"),response)
        if l111111111ll11l1_cdhd_:
            l111111111ll11l1_cdhd_=l111111111ll11l1_cdhd_.group(1).replace(l1lll1ll11l1_cdhd_ (u"ࠪࡠࡡ࠭ඌ"),l1lll1ll11l1_cdhd_ (u"ࠫࠬඍ"))
    return l111111111ll11l1_cdhd_
def _1llllll1l1ll11l1_cdhd_(url):
    hash = url.split(l1lll1ll11l1_cdhd_ (u"ࠬ࠵ࠧඎ"))[-1]
    l1lllll1l11ll11l1_cdhd_ = {l1lll1ll11l1_cdhd_ (u"࠭ࡨࡢࡵ࡫ࠫඏ"): hash}
    headers = { l1lll1ll11l1_cdhd_ (u"ࠢࡂࡥࡦࡩࡵࡺࠢඐ"): l1lll1ll11l1_cdhd_ (u"ࠣࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱ࠰ࠥࡺࡥࡹࡶ࠲ࡴࡱࡧࡩ࡯࠮ࠣ࠮࠴࠰ࠢඑ"),
                l1lll1ll11l1_cdhd_ (u"ࠤࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠣඒ"): l1lll1ll11l1_cdhd_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰࡬ࡶࡳࡳ࠭ඓ")}
    response = l1lll1l111ll11l1_cdhd_(l1lll1ll11l1_cdhd_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡸࡧࡦࡦ࡮࡬ࡲࡰ࡯࡮ࡨ࠰ࡱࡩࡹ࠵ࡶ࠲࠱ࡳࡶࡴࡺࡥࡤࡶࡨࡨࠬඔ"),data=l1lllll1l11ll11l1_cdhd_,headers=headers)
    l1llllllll1ll11l1_cdhd_ = json.loads( response)
    if l1llllllll1ll11l1_cdhd_:
        l1l1l1ll1ll11l1_cdhd_=l1llllllll1ll11l1_cdhd_.get(l1lll1ll11l1_cdhd_ (u"ࠬࡲࡩ࡯࡭ࡶࠫඕ"),[])
        if len(l1l1l1ll1ll11l1_cdhd_):
            url=l1l1l1ll1ll11l1_cdhd_[0].get(l1lll1ll11l1_cdhd_ (u"࠭ࡵࡳ࡮ࠪඖ"),l1lll1ll11l1_cdhd_ (u"ࠧࠨ඗"))
    return url
def _1lllllll11ll11l1_cdhd_(uri):
    l111111111ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠨࠩ඘")
    html = l1lll1l111ll11l1_cdhd_(uri, headers=_1lllll1111ll11l1_cdhd_)
    l1llllll111ll11l1_cdhd_ = re.findall(l1lll1ll11l1_cdhd_ (u"ࡴࠪࡷࡪࡹࡳࡪࡱࡱࡍࡩࡢ࠺ࠩ࠰࠭ࡃ࠮ࡢࠢ࡝࠮ࠪ඙"), html)
    if len(l1llllll111ll11l1_cdhd_) > 0:
        l1llllll111ll11l1_cdhd_ = re.sub(l1lll1ll11l1_cdhd_ (u"ࡵࠫࡡࡹ࡜ࠣࠩක"), l1lll1ll11l1_cdhd_ (u"ࠫࠬඛ"), l1llllll111ll11l1_cdhd_[0])
        l1111111l1ll11l1_cdhd_ = {
            l1lll1ll11l1_cdhd_ (u"࡛ࠧࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠤග"): l1lll1ll11l1_cdhd_ (u"ࠨࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡞࠱࠲࠽ࠣࡐ࡮ࡴࡵࡹࠢࡻ࠼࠻ࡥ࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠹࠳࠷࠱ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠲࠹࠱࠴࠳࠿࠶࠴࠰࠷࠺࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠶࠰࠴࠵ࠧඝ"),
            l1lll1ll11l1_cdhd_ (u"ࠢࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠤඞ"): l1lll1ll11l1_cdhd_ (u"ࠣࡩࡽ࡭ࡵ࠲ࡤࡦࡨ࡯ࡥࡹ࡫ࠬࡴࡦࡦ࡬ࠧඟ"),
            l1lll1ll11l1_cdhd_ (u"ࠤࡄࡧࡨ࡫ࡰࡵ࠯ࡏࡥࡳ࡭ࡵࡢࡩࡨࠦච"): l1lll1ll11l1_cdhd_ (u"ࠥࡩࡳ࠳ࡕࡔ࠮ࡨࡲࡀ࠲ࡱ࠾࠲࠱࠼ࠧඡ"),
            l1lll1ll11l1_cdhd_ (u"ࠦࡈࡵ࡮࡯ࡧࡦࡸ࡮ࡵ࡮ࠣජ"): l1lll1ll11l1_cdhd_ (u"ࠧࡱࡥࡦࡲ࠰ࡥࡱ࡯ࡶࡦࠤඣ"),
            l1lll1ll11l1_cdhd_ (u"ࠨࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠧඤ"): l1lll1ll11l1_cdhd_ (u"ࠢࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࠨඥ"),
            l1lll1ll11l1_cdhd_ (u"ࠣࡊࡲࡷࡹࠨඦ"): l1lll1ll11l1_cdhd_ (u"ࠤࡶ࡬࠳ࡹࡴࠣට"),
            l1lll1ll11l1_cdhd_ (u"ࠥࡖࡪ࡬ࡥࡳࡧࡵࠦඨ"): uri,
            l1lll1ll11l1_cdhd_ (u"ࠦࡔࡸࡩࡨ࡫ࡱࠦඩ"): l1lll1ll11l1_cdhd_ (u"ࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡨ࠯ࡵࡷࠦඪ"),
            l1lll1ll11l1_cdhd_ (u"ࠨࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠤණ"): l1lll1ll11l1_cdhd_ (u"࡙ࠢࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠣඬ")
        }
        time.sleep(5)
        l111111l11ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡵ࡫࠲ࡸࡺ࠯ࡴࡪࡲࡶࡹ࡫ࡳࡵ࠯ࡸࡶࡱ࠵ࡥ࡯ࡦ࠰ࡥࡩࡹࡥࡴࡵ࡬ࡳࡳࡅࡡࡥࡕࡨࡷࡸ࡯࡯࡯ࡋࡧࡁࠪࡹࠦࡢࡦࡥࡨࡂ࠷ࠦࡤࡣ࡯ࡰࡧࡧࡣ࡬࠿ࡦࠫත")%l1llllll111ll11l1_cdhd_
        response = l1lll1l111ll11l1_cdhd_(l111111l11ll11l1_cdhd_, headers=l1111111l1ll11l1_cdhd_)
        l111111111ll11l1_cdhd_=re.search(l1lll1ll11l1_cdhd_ (u"ࠩࠥࡨࡪࡹࡴࡪࡰࡤࡸ࡮ࡵ࡮ࡖࡴ࡯ࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ථ"),response)
        if l111111111ll11l1_cdhd_:
            l111111111ll11l1_cdhd_=l111111111ll11l1_cdhd_.group(1).replace(l1lll1ll11l1_cdhd_ (u"ࠪࡠࡡ࠭ද"),l1lll1ll11l1_cdhd_ (u"ࠫࠬධ"))
    return l111111111ll11l1_cdhd_
