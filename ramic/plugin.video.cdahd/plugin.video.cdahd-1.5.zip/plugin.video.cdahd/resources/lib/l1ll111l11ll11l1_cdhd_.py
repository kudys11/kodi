# -*- coding: utf-8 -*-
import sys
l1ll11ll11l1_cdhd_ = sys.version_info [0] == 2
l11ll1ll11l1_cdhd_ = 2048
l1111ll11l1_cdhd_ = 7
def l1lll1ll11l1_cdhd_ (keyedStringLiteral):
	global l1l111ll11l1_cdhd_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll11l1_cdhd_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os
import l1llll1111ll11l1_cdhd_,cookielib
from urlparse import urlparse
l1ll11lll1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡧࡩࡧ࠭ࡩࡦ࠱ࡴࡱ࠵ࠧ઻")
l111ll1l1ll11l1_cdhd_ = 10
l1ll11l1l1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡐ࡙࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠸࠽࠴࠰࠯࠴࠸࠺࠹࠴࠹࠸ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷઼ࠩ")
l11lll1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࡷ࠭ࡣࡰࡱ࡮࡭ࡪ࠴ࡣࡥࡣࠪઽ")
l1ll1l11l1ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡦࡷࡧ࡭࡬ࡣ࠱ࡴࡷࡵࡸࡺ࠰ࡱࡩࡹ࠴ࡰ࡭࠱࡬ࡲࡩ࡫ࡸ࠯ࡲ࡫ࡴࡄࡷ࠽ࠨા")
def _1ll1ll1l1ll11l1_cdhd_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l1lll1ll11l1_cdhd_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫિ"), l1ll11l1l1ll11l1_cdhd_)
    if cookies:
        req.add_header(l1lll1ll11l1_cdhd_ (u"ࠣࡅࡲࡳࡰ࡯ࡥࠣી"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l111ll1l1ll11l1_cdhd_)
        l1ll1l111ll11l1_cdhd_ = response.read()
        response.close()
    except:
        l1ll1l111ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠩࠪુ")
    return l1ll1l111ll11l1_cdhd_
def l1lll1l111ll11l1_cdhd_(url,data=None):
    cookies=l1llll1111ll11l1_cdhd_.l1ll1l1ll1ll11l1_cdhd_(l11lll1ll11l1_cdhd_)
    content=_1ll1ll1l1ll11l1_cdhd_(url,data,cookies)
    if not content:
        l111llll1ll11l1_cdhd_=l1ll1llll1ll11l1_cdhd_(l1ll11lll1ll11l1_cdhd_,l11lll1ll11l1_cdhd_)
        cookies=l1llll1111ll11l1_cdhd_.l1ll1l1ll1ll11l1_cdhd_(l11lll1ll11l1_cdhd_)
        content=_1ll1ll1l1ll11l1_cdhd_(url,data,cookies)
        if not content:
            content=_1ll1ll1l1ll11l1_cdhd_(l1ll1l11l1ll11l1_cdhd_+url,data,cookies)
    return content
def l1ll1llll1ll11l1_cdhd_(l1ll1l111ll11l1_cdhd_,l1lll1l1l1ll11l1_cdhd_):
    l111llll1ll11l1_cdhd_ = cookielib.LWPCookieJar()
    l1lll11ll1ll11l1_cdhd_ = l1llll1111ll11l1_cdhd_.l111111l1ll11l1_cdhd_(l1ll1l111ll11l1_cdhd_,l111llll1ll11l1_cdhd_,l1ll11l1l1ll11l1_cdhd_)
    l111l11l1ll11l1_cdhd_=os.path.dirname(l1lll1l1l1ll11l1_cdhd_)
    if not os.path.exists(l111l11l1ll11l1_cdhd_):
        os.makedirs(l111l11l1ll11l1_cdhd_)
    if l111llll1ll11l1_cdhd_:
        l111llll1ll11l1_cdhd_.save(l1lll1l1l1ll11l1_cdhd_, ignore_discard = True)
    return l111llll1ll11l1_cdhd_
def l1ll1lll1ll11l1_cdhd_(url,l1l1l1l1ll11l1_cdhd_=1):
    if l1lll1ll11l1_cdhd_ (u"ࠪࡃࡸࡃࠧૂ") in url:
        url = url.replace(l1lll1ll11l1_cdhd_ (u"ࠫࡄࡹ࠽ࠨૃ"),l1lll1ll11l1_cdhd_ (u"ࠬࡶࡡࡨࡧ࠲ࠩࡩ࠵࠿ࡴ࠿ࠪૄ") %l1l1l1l1ll11l1_cdhd_)
    else:
        url += l1lll1ll11l1_cdhd_ (u"࠭࠯ࠨૅ") if url[-1] != l1lll1ll11l1_cdhd_ (u"ࠧ࠰ࠩ૆") else l1lll1ll11l1_cdhd_ (u"ࠨࠩે")
        url = url + l1lll1ll11l1_cdhd_ (u"ࠩࡳࡥ࡬࡫࠯ࠦࡦ࠲ࠫૈ") %l1l1l1l1ll11l1_cdhd_
    content = l1lll1l111ll11l1_cdhd_(url)
    l1ll111l1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽࡜ࠤ࡟ࠫࡢࡶࡡࡨ࡫ࡱࡥࡩࡵ࡛ࠣ࡞ࠪࡡࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪૉ"),re.DOTALL).findall(content)
    l1ll111l1ll11l1_cdhd_ = urllib.unquote(l1ll111l1ll11l1_cdhd_[0]) if l1ll111l1ll11l1_cdhd_ else content
    l1ll1ll111ll11l1_cdhd_=False
    l1ll11ll11ll11l1_cdhd_=url.replace(l1lll1ll11l1_cdhd_ (u"ࠫࡵࡧࡧࡦ࠱ࠨࡨ࠴࠭૊")%l1l1l1l1ll11l1_cdhd_,l1lll1ll11l1_cdhd_ (u"ࠬࡶࡡࡨࡧ࠲ࠩࡩ࠵ࠧો") %(l1l1l1l1ll11l1_cdhd_+1))
    if l1ll111l1ll11l1_cdhd_.find(l1ll11ll11ll11l1_cdhd_.split(l1lll1ll11l1_cdhd_ (u"࠭࠯࠰ࠩૌ"))[-1])>-1:
        l1ll1ll111ll11l1_cdhd_ = l1l1l1l1ll11l1_cdhd_+1
    ids = [(a.start(), a.end()) for a in re.finditer(l1lll1ll11l1_cdhd_ (u"ࠧ࠽ࡦ࡬ࡺࠥ࡯ࡤ࠾࡞ࠥࡱࡹ࠴ࠪ࡝ࠤࠣࡧࡱࡧࡳࡴ࠿࡟ࠦ࡮ࡺࡥ࡮࡞ࠥࡂ્ࠬ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11l11111ll11l1_cdhd_ = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile(l1lll1ll11l1_cdhd_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡢࡰࡺ࡬ࡲ࡫ࡵࠢ࠿࡝࡟ࡷࡡࡴ࡝ࠬ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠫ૎"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
        title = re.compile(l1lll1ll11l1_cdhd_ (u"ࠩ࠿ࡷࡵࡧ࡮ࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡶࡷࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ૏"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
        l1lllll1l1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠪࡀࡸࡶࡡ࡯ࠢࡦࡰࡦࡹࡳ࠾ࠤࡷࡸࡽࠨ࠾࡝ࡰࠫ࠲࠯ࡅࠩࠩࡁ࠽ࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡦࡨ࡫ࡷࡧࡤࡢࡦࡲࠦࡃࡂ࠯ࡥ࡫ࡹࡂ࠮ࢁ࠰࠭࠳ࢀ࡟ࡡࡹ࡜࡯࡟࠭ࡀ࠴ࡹࡰࡢࡰࡁ࡟ࡡࡹ࡜࡯࡟࠭ࠫૐ"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
        l1llll1l11ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡱࡦ࡭ࡥࠣࡀ࡞ࡠࡸࡢ࡮࡞࠭࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ૑"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
        l1111l1l1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠬࡂࡳࡱࡣࡱࠤࡨࡲࡡࡴࡵࡀࠦ࡮ࡳࡤࡣࡵࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ૒"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
        year =  re.compile(l1lll1ll11l1_cdhd_ (u"࠭࠼ࡴࡲࡤࡲࠥࡩ࡬ࡢࡵࡶࡁࠧࡿࡥࡢࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ૓"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
        quality = re.compile(l1lll1ll11l1_cdhd_ (u"ࠧ࠽ࡵࡳࡥࡳࠦࡣ࡭ࡣࡶࡷࡂࠨࡣࡢ࡮࡬ࡨࡦࡪ࠲ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ૔"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
        l1lllll111ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠨ࠾ࡥࡂ࠳࠱࠿࠽࠱ࡥࡂࠥࡂࡢ࠿ࠪ࠱࠮ࡄࠦࡧृࡱࡶࣷࡼ࠯࠼࠰ࡤࡁࠫ૕")).search(l11l11111ll11l1_cdhd_)
        if href and title:
            l1llll1l11ll11l1_cdhd_ = l1llll1l11ll11l1_cdhd_.group(1) if l1llll1l11ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠩࠪ૖")
            if l1llll1l11ll11l1_cdhd_.startswith(l1lll1ll11l1_cdhd_ (u"ࠪ࠳࠴࠭૗")):
                l1llll1l11ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪ૘")+l1llll1l11ll11l1_cdhd_
            l111l1111ll11l1_cdhd_ = {l1lll1ll11l1_cdhd_ (u"ࠬ࡮ࡲࡦࡨࠪ૙")   : href.group(1),
                l1lll1ll11l1_cdhd_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ૚")  : l1llll11l1ll11l1_cdhd_(title.group(1)),
                l1lll1ll11l1_cdhd_ (u"ࠧࡱ࡮ࡲࡸࠬ૛")   : l1llll11l1ll11l1_cdhd_(l1lllll1l1ll11l1_cdhd_.group(1)) if l1lllll1l1ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠨࠩ૜"),
                l1lll1ll11l1_cdhd_ (u"ࠩ࡬ࡱ࡬࠭૝")    : l1llll1l11ll11l1_cdhd_,
                l1lll1ll11l1_cdhd_ (u"ࠪࡶࡦࡺࡩ࡯ࡩࠪ૞") : l1111l1l1ll11l1_cdhd_.group(1) if l1111l1l1ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠫࠬ૟"),
                l1lll1ll11l1_cdhd_ (u"ࠬࡿࡥࡢࡴࠪૠ")   : year.group(1) if year else l1lll1ll11l1_cdhd_ (u"࠭ࠧૡ"),
                l1lll1ll11l1_cdhd_ (u"ࠧࡷࡱࡷࡩࡸ࠭ૢ")  : l1lllll111ll11l1_cdhd_.group(1) if l1lllll111ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠨࠩૣ"),
                l1lll1ll11l1_cdhd_ (u"ࠩࡦࡳࡩ࡫ࠧ૤")  : quality.group(1) if quality else l1lll1ll11l1_cdhd_ (u"ࠪࠫ૥"),
                    }
            out.append(l111l1111ll11l1_cdhd_)
    l1111lll1ll11l1_cdhd_ = l1l1l1l1ll11l1_cdhd_-1 if l1l1l1l1ll11l1_cdhd_>1 else False
    return (out, (l1111lll1ll11l1_cdhd_,l1ll1ll111ll11l1_cdhd_))
def l111lll11ll11l1_cdhd_(url):
    content = l1lll1l111ll11l1_cdhd_(url)
    token = re.search(l1lll1ll11l1_cdhd_ (u"ࠫࡳࡧ࡭ࡦ࠿ࠥࡣࡹࡵ࡫ࡦࡰࠥࠤࡹࡿࡰࡦ࠿ࠥ࡬࡮ࡪࡤࡦࡰࠥࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࠬ૦"),content).group(1)
    l1lll11111ll11l1_cdhd_ = re.search(l1lll1ll11l1_cdhd_ (u"ࠬࡹࡩࡵࡧ࡮ࡩࡾࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢࠨ૧"),content).group(1)
    params = {l1lll1ll11l1_cdhd_ (u"࠭࡟ࡵࡱ࡮ࡩࡳ࠭૨"):l1lll1ll11l1_cdhd_ (u"ࠧࡎࡩ࡝ࡑࡇ࠷ࡗࡧ࠶ࡘࡆࡌࡶࡨ࡚ࡈ࠴࡭࠻࠹࡭ࡐ࠶࠹࠻ࡼࡾࡇ࠹ࡕ࠸࡯࠺ࡩ࡫ࡱ࠶ࡐࡓ࡯࠭૩"),
            l1lll1ll11l1_cdhd_ (u"ࠨࡩ࠰ࡶࡪࡩࡡࡱࡶࡦ࡬ࡦ࠳ࡲࡦࡵࡳࡳࡳࡹࡥࠨ૪"):l1lll1ll11l1_cdhd_ (u"ࠩ࠳࠷ࡆࡎࡊࡠࡘࡸࡺࡼࡽ࡫ࡌࡈ࠴ࡍ࠾ࡒࡎࡩࡗࡕࡖࡸࡖࡊࡴࡓࡒ࠹ࡤ࡙࡬ࡉࡳࡊࡵ࡛࠿ࡢࡰࡴࡅࡥ࡚࡝ࡱ࡮ࡰࡴࡒࡉ࡬ࡱࡉ࠳ࡳࡘࡎࡖࡹ࡮ࡳࡘࡻࡑࡒ࡫࡫࠶ࡻ࡬࠻ࡴࡗࡨࡃࡰࡆࡳࡽࡖࡤ࡜ࡅ࡚ࡺ࡭࡭ࡎࡌ࡬࡚ࡨࡶࡌ࠷࠯ࡗ࠶ࡨࡐࡇࡶ࠷ࡩࡈࡐࡳࡅࡴࡺࡤ࡞ࡸ࠷ࡏࡒࡉࡔࡼࡵ࠾ࡴࡐࡴ࠵࡝ࡵࡧࡖࡤࡃ࡙ࡴࡪࡖࡥࡵࡓ࡯ࡆ࡛࠶ࡹࡂ࠺ࡪࡘࡈࡗࡣࡱ࡯ࡱࡪ࡞ࡪࡏࡔࡥࡔ࡯ࡽ࡛࠹ࡰࡡࡶ࠹ࡖ࠺ࡳ࡫ࡒ࠷ࡌࡴࡼ࠲ࡒࡤࡥ࡬ࡌ࡜࠹ࡔࡋ࠷ࡓ࠽ࡧ࠭ࡗࡔࡄ࡚࡝ࡸࡕࡻࡲࡩ࠺ࡽࡿࡵࡦࡸ࡜ࡷࡺ࡞࠳ࡉࡺࡋࡥࡤࡈࡳ࡚ࡓࡆ࠽࡚࠽ࡄ࡙࠲࡭ࡪ࡯ࡈࡊࡅ࡯࡬ࡰࡏࡧࡢ࠷ࡗࡇࡖࡩ࡜ࡃ࡭ࡧࡊ࠱࡯ࡌࡷ࠸ࡔࡎࡴ࠼࠻ࡕࡖࡪ࡯ࡾ࡝ࡇࡌࡐࡈࡲ࡬࠸ࡏࡗࡢ࡜࡚࠽࡯ࡒࡥ࠱ࡈ࠶ࡱ࡛࡫࡭ࡗࡖࡔ࠱࠶࠹ࡰ࠱ࡑࡄࡽࡳࡽࡵࡰࡃࡗ࡞࡜ࡌࡴࡩࡇࡏ࠼ࡈ࠶ࡎࡌࡏࡘࡦࡩ࡜ࡧ࠶ࡦ࠰ࡣ࠻࠸࠸࡬ࡡࡅࡻࡉ࠷ࡒ࠷ࡍࡧ࠸࡝ࡰࡵࡂ࠻ࡩࡰࡖࡉࡅࡎࡩࡘ࠹࡭ࢀࡌ࡮࠺ࡕࡣࡐ࠹ࡆࡌࡣࡉ࡯ࡕࡶࡩࡶࡗࡖ࠷ࡲࡸ࠭ࡵ࡚ࡽ࠻ࡻࡹࡴࡍ࠻ࡅࡍࡕ࡞ࡪࡒࡹ࠹࠼࡞࠷ࡵ࡮࡭ࡢ࠻ࡷࡗࡶࡌࡌࡪࡍࡖࡇ࠲ࡏࡨࡥ࠹ࡼࡧࡔࡂࡆࡉ࠵࡬ࡧࡃࡶࡵ࡜ࡑ࠹ࡪ࠱࠵ࡐࡋ࠽ࡋ࠻࠲࡬ࡇ࠷ࡰࡷࡪࡢࡢ࡛࠵࡙ࡘ࠿ࡵࡪࡐࡆࡵࡊ࡬࡙ࡩࡃࡦࡾ࡝ࡿࡆࡨࡺࡻࡵࡇࡐ࠵࠹ࡄ࠹ࡔࡕࢀ࠰࡬࠵ࡐ࠻࠲࡞ࡱ࡛ࡕࡷࡔࡿࡧࡍࡑ࠶ࡐࡈࡗࡌࡲ࠵ࡻࡸࡎ࠶ࡇ࡮࠸ࡦࡲࡲ࠹࡯࡭࠷࠻ࡦࡓ࠽ࡶࡃ࠱ࡻࡹ࡫ࡦࡿࡗࡹࡵࡤࡰࡒ࠾ࡊࡍࡅࡇ࡭࡙࠽ࡖ࡮ࡕ࡮ࡥ࠼࠾ࡇ࡚ࡦ࠳ࡆࡩࡽࡓࡠࡦࡆ࠵࡙ࡾࡔࡪ࡭࡫࡚࠽ࡩࡈ࠺ࡣࡧࡎ࡝࡟࠵ࡂࡶࡆࡎࡈࡏ࠲ࡦ࡬ࡷࡅࡨࡩࡹ࡚࠷࡬ࡽࡨ࡯ࡥ࠮ࡼࡹࡒ࡟࡫ࡪࡷࡣࡆ࠼ࡌ࡟ࡉࡧࡹࡎࡒࡪ࡟ࡁ࠴ࡘ࡬࠺࠵࡭࡙ࡏࡩࡌࡩࡻ࠸ࡡ࠶ࡗࡐࡍࡖࡠࡦ࡚࠶ࡽ࡛࡫ࡥࡰ࡫ࡵ࠻ࡘ࠼ࡽࡄࡍࡳࡵ࠴࠽ࡱࡒࡉࡶࡕ࠻࡭ࡿࡢ࡮࡯ࡎࡷࡻ࡟ࡷࡈࡈ࡮࡭ࡉࡓࡶࡦࡧࡴࡕࡽ࠳ࡶࡻࡘࡇ࠸ࡨ࠿ࡴࡦ࠹࠼࡞ࡵࡕࡵࡓࡕࡰࡅࡓ࠾ࡩࡪ࠴ࡄࡶࡩ࡟ࡈࡘࡤࡢࡑ࠻࠿ࡡ࠱ࡊࡩࡪࡦ࡭ࡺࡑࡶࡘ࠼ࡒࡉࡣ࠷ࡎࡺࡹ࠽࡚࠶࠶ࡹ࠴ࡼࡶ࠽ࡉࡍࡰࡔࡖࡴࡩࡣࡱࡲࡐࡻࡈ࠿ࡂ࠹ࡖ࠻ࡰࡿࡪࡉࡲࡕ࠵ࡽࡑࡉࡳࡨࡍࡻࡾࡨࡒࡆࡐࡧࡴࡴࡹࡥࡑࡂࡋࡧࡒ࡬࡯ࡢࡺࡈ࠶ࡵ࠼ࡊ࡚ࡦࡥ࡯࠸࠶ࡸ࠲ࡩࡺࡑ࡯ࡍࡶ࠶࡮ࡖ࠴࡯࡯ࡱࡃ࠹ࡩࡺࡾࡈࡨࡧࡷࡌࡄࡳࡶ࠽ࡺࡶ࡜ࡘ࡜ࡻࡵࡑࡄࡷࡈࡉ࡚ࡔࡁࡶࡥࡌࡸࡍࡓ࠹ࡖࡥࡐࡈࡖ࠺ࡩࡎ࡛ࡓࡻࡇ࡝ࡢࡴࡗࡩࡩࡿࡇࡂࡪࡑ࡚ࡲࡪ࠶ࡆ࠸ࡓࡔࡧࡊࡥࡋࡗ࡛࠷ࡽࡊ࠺ࡒࡇࡕࡈࡲࡹ࡝࡬࠺ࡰࡼࡽ࡝࠿ࡏ࠳ࡑ࡜࠺࡭ࡋࡩ࠳ࡧ࠴ࡋ࠺ࡈࡁࡦ࡚ࡇࡣ࠶ࡿࡩࡍ࠻ࡶ࠱ࡸ࠼࠸ࡱ࡮࡬࡯ࡋࡌ࡟࡭ࡄࡵࡕ࡞࠶ࡶࡤࡣࡓࡲࡒ࠼࠹ࡒࡕࡩࡲࡷ࡛ࡁ࡯ࡈ࠸࡬࠼ࡈࡇࡸ࡮ࡗ࡯ࡶࡈࡧ࡭ࡹ࠹࠶ࡺࡕࡷ࠶ࡒࡱ࠶ࡰࡺࡹࡨࡔࡓ࠱ࡇ࡚ࡔࡱࡩࡘࡼ࡛ࡧ࠰ࡧࡶ࡫ࡼࡊࡰࡒࡠ࠵࠴࡚ࡈ࡛ࡶࡃ࡯ࡇ࠷ࡳࡽࡶࡪࡑࡒࡅࡗࡈ࡫ࡏࡺࡺࡾࡓࡒࡶࡻࡄ࠰ࡐࡍࡗ࠴ࡊࡹࡷ࠼ࡗ࡝ࡖ࡫࠳ࡋࡈ࠷࠸ࡑ࡚ࡃ࡚࡮ࡋ࡚ࡈࡖ࡜ࡑࡑ࡞ࡵࡧ࠴ࡴࡉࡖ࠶࠷ࡘࡪ࠴ࡢ࠻ࡋ࡛ࡣࡖࡥࡒࡋࡋࡓࡺࡻ࡭ࡆࡱࡎࡵࡦࡱ࡚࠻࠵࠸ࡲ࡫࠶ࡦࡨࡈࡲࡎࡩࡗࡼࡲࡒ࡝࡭࠲ࡶࡔ࡬ࡥࡉࡐࡱࡥࡆࡪࡰࡹ࡚࠷࠹ࡃ࡫ࡑࡘࡌࡍ࡛ࡪࡲࡑ࡮ࡳࡊࡖࡸࡋࡰࡺࡻࡂ࠱࠻ࡌࡊࡈࡱࡅ࠱ࡏࡢ࠺ࡩࢀࡐࡺ࡫࠵࠷࡬࡯ࡤ࡛ࡔ࡭࡝ࡴࡪ࠸ࡱࡳ࡙࠶࠵ࡍ࠴࡚࠳ࡥࡇ࠻ࡠࡺࡵࡶ࡯ࡈࡧࡩࡒࡤࡥࡇࡪࡐࡧࡤࡤࡌࡸ࠽ࡊࡶࡇࡎࡥ࡙ࡐࡖࡴ࡮ࡃࡼࡶࡩ࡙࡙࠰ࡄࡉࡰ࠼ࡓ࠷ࡎ࡭ࡷࡇࡧ࡯ࡓࡨࡸࡰࡽࡱ࠽ࡺࡥࡕࡌࡌࡩ࡬࡫ࡳࡪࡲࡶࡌ࠼ࡗ࡚࠹ࡗࡼࡪ࡬ࡩࡹࡇࡒࡧ࠴࠲࠾ࡣࡐ࡭࡮ࡱࡐ࡭࡬ࡦࡇࡘࡈ࡛࡞ࡃࡵࡃ࡮࡞ࡘࡨ࡙ࡕ࠲࠶ࡗ࠲ࡺࡕࡲࡍࡻ࡭ࡰࡗ࠷ࡒࡺࡍࡓࡊ࡜ࡲࡉࡏ࠳࡝࠺ࡽࡖ࡫ࡎࡑࡘࡸ࠶ࡔࡘࡈࡘࡉࡉࡋ࡯࠶࡫࡛ࡺ࠲࠼ࡱࡸ࠻࠻ࡾࡺ࠼ࡹࡪ࡙࡬ࡕ࠷ࡶࡆࡣ࠹ࡖࡦࡽࡼࡦ࡮࡚࡫ࡏ࠸ࡷࡆࡘࡸ࡮࡙ࡈࡲࡸ࡫ࡩࡅ࡬࠼ࡱࡖࡶ࠷ࡷ࡯ࡰࡊࡎ࠱࠳࠴ࡗࡇ࠻ࡒࡦࡱࡆࡎࡺࡒࡤࡧࡊࡏࡸࡔ࡮࠲ࡇࡳ࡝࠶ࡼ࠽ࡐࡩࡉࡎࡆ࡯࡫ࡶࡥࡃࡏ࠶࡫ࡉࡒࡆࡪ࡛࠵ࡏࡺ࡙ࡏ࠺ࡼࡅ࡚࡯ࡐࡏ࡬ࡻ࡯ࡆࡈࡴࡂࡤࡰࡽࡑ࠽ࡳ࠮ࡍࡳ࠶࡜ࡨࡶࡷࡔࡴࡐ࠹࠹࠵࠸ࡶࡗ࠺ࡲࡔࡘࡄࡳࡪ࠱࡫ࡴࡍ࠲࡫ࡔ࠽ࡴ࡟ࡁࡵࡒ࡬ࡱࡏࡵࡤࡷࡆ࠻࡞ࡈࡑ࡙࠶ࡄ࠼ࡱࡨ࠹ࡡࡐࡷࡇࡍࡖࢀࡶ࠷ࡎࡗࡣࡴࡶࡥࡷࡘࡤ࠽࠼ࡵࡆ࠱࡮ࡨࡨ࡮࡛࠸ࡨࡑ࠹࠷ࡊࡻࡱ࡮࠸ࡪࡍ࠺ࡑ࠰࡫࠷࡙ࡔࡪ࡜ࡶࡱࡥ࠳ࡾࡾࡧ࡙ࡗ࡚ࡉ࠽ࡹࡾ࠵ࡒࡼࡉࡏࡹࡕࡅࡂࡅࡢࡏࡦ࡚ࡨ࠮ࡕࡸ࠻࡚ࡐ࡮ࡘ࠶ࡔࡦࡍ࡛ࡩ࠺ࡒ࡯ࡷ࡬࡭ࡑࡑ࠲ࡍࡅ࠺࠼࡟ࡨࡪࡗࡓ࠽ࡈࡪࡑ࡛࠵ࡹ࠽ࡑ࠹࠺ࡊࡇ࡬ࡤࡪࡰ࠵ࡇࡥ࠵ࡊ࠶ࡔ࠺ࡃ࠴ࡼࡹࢀࡲࡣ࡚࠶࡞࡬ࡌ࠰࠶ࡹࡆࡉࡏ࡫࠵ࡍ࡯࠵ࡵ࡝࠶ࡕࡥ࡜࡛ࡽࡤࡇࡖࡶࡳ࠺ࡗ࠸ࡋࡍ࠴ࡏ࡭࡬ࡏࡏ࡚࠮ࡍࡥ࡮ࡪ࠽ࡐࡰࡨࡴࡰࡽࡍ࡭࠱࠻ࡌ࡬ࡏࡾࡒࡤࡦࡈ࠸࡯࡞࡚ࡨࡴ࡯ࡨ࠼ࡧࡐࡩࡸ࠳ࡆ࡙࠷ࡑ࠺࠳ࡇ࡜ࡷࡘ࠸࡭ࡎࡷ࡝࠻ࡔࡒࡃࡵ࡝ࡪࡰ࡮࠹ࡏࠩ૫")
           }
    data=urllib.urlencode(params)
    a=l1lll1l111ll11l1_cdhd_(l1lll1ll11l1_cdhd_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡳࡺࡵ࠮ࡪࡱ࠲࡫ࡴ࠵ࡆ࡬ࡤࡦࡹࠬ૬"),data)
    print a
def _1lllllll1ll11l1_cdhd_(url,host=l1lll1ll11l1_cdhd_ (u"ࠫࠬ૭")):
    l111l1l11ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠬ࠭૮")
    if url.startswith(l1lll1ll11l1_cdhd_ (u"࠭ࡨࡵࡶࡳࠫ૯")):
        if l1lll1ll11l1_cdhd_ (u"ࠧ࡭࡫ࡱ࡯࡮࠴࡯࡯࡮࡬ࡲࡪ࠭૰") in url:
            content = l1lll1l111ll11l1_cdhd_(url)
            l1l1l1ll1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠨࡶࡲࡴ࠳ࡲ࡯ࡤࡣࡷ࡭ࡴࡴࠠ࠾ࠢ࡞ࡠࠬࠨ࡝ࠩ࠰࠭ࡃ࠮ࡡ࡜ࠨࠤࡠ࠿ࠬ૱")).search(content)
            if l1l1l1ll1ll11l1_cdhd_:
                l111l1l11ll11l1_cdhd_ = l1l1l1ll1ll11l1_cdhd_.group(1)
        if l1lll1ll11l1_cdhd_ (u"ࠩࡲࡹࡴ࠴ࡩࡰࠩ૲") in url:
            l111l1l11ll11l1_cdhd_ = url
        else:
            req = urllib2.Request(url)
            req.add_header(l1lll1ll11l1_cdhd_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ૳"), l1lll1ll11l1_cdhd_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡐ࡙࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠸࠽࠴࠰࠯࠴࠸࠺࠹࠴࠹࠸ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩ૴"))
            try:
                response = urllib2.urlopen(req)
                if response:
                    l111l1l11ll11l1_cdhd_=response.url
                    if l111l1l11ll11l1_cdhd_==url:
                        content=response.read()
                        l1l1l1ll1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭࠭ࠧࠦࡣ࡭ࡣࡶࡷࠬ૵")).findall(content)
                        for l in l1l1l1ll1ll11l1_cdhd_:
                            if host in l:
                                l111l1l11ll11l1_cdhd_ = l
                                break
                    response.close()
            except:
                pass
    return l111l1l11ll11l1_cdhd_
def l1ll1l1111ll11l1_cdhd_(url,content=None):
    if not content:
        content = l1lll1l111ll11l1_cdhd_(url)
    out  =[]
    l1ll1111l1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠠࠩ࠰࠭ࡃ࠮ࡂ࠯ࡪࡨࡵࡥࡲ࡫࠾ࠨ૶"),re.DOTALL).findall(content)
    names = re.compile(l1lll1ll11l1_cdhd_ (u"ࠧ࠽ࡷ࡯ࠤࡨࡲࡡࡴࡵࡀࠦ࡮ࡪࡔࡢࡤࡶࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ૷"),re.DOTALL).findall(content)
    if names:
        names = [x.strip() for x in re.compile(l1lll1ll11l1_cdhd_ (u"ࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠩ૸"),re.DOTALL).findall(names[0]) if x.strip()]
    else:
        names=[]
    for l1111l111ll11l1_cdhd_ in l1ll1111l1ll11l1_cdhd_:
        href = re.compile(l1lll1ll11l1_cdhd_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧૹ"),re.DOTALL).search(l1111l111ll11l1_cdhd_)
        if href:
            l1111ll11ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠪ࡬ࡹࡺࡰࠨૺ")+ urllib.unquote(href.group(1)).split(l1lll1ll11l1_cdhd_ (u"ࠫ࡭ࡺࡴࡱࠩૻ"))[-1]
            if l1111ll11ll11l1_cdhd_.startswith(l1lll1ll11l1_cdhd_ (u"ࠬ࡮ࡴࡵࡲࠪૼ")) and not l1lll1ll11l1_cdhd_ (u"࠭ࡹࡰࡷࡷࡹࡧ࡫ࠧ૽") in l1111ll11ll11l1_cdhd_ and not l1lll1ll11l1_cdhd_ (u"ࠧࡧࡣࡦࡩࡧࡵ࡯࡬ࠩ૾") in l1111ll11ll11l1_cdhd_:
                host = urlparse(l1111ll11ll11l1_cdhd_).netloc
                l111l1111ll11l1_cdhd_ = {l1lll1ll11l1_cdhd_ (u"ࠨࡷࡵࡰࠬ૿") : l1111ll11ll11l1_cdhd_,
                    l1lll1ll11l1_cdhd_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ଀"): l1lll1ll11l1_cdhd_ (u"ࠥ࡟ࠪࡹ࡝ࠣଁ") %(host),
                    l1lll1ll11l1_cdhd_ (u"ࠫ࡭ࡵࡳࡵࠩଂ"): host    }
                out.append(l111l1111ll11l1_cdhd_)
    if len(names)==len(out):
        for l111l1111ll11l1_cdhd_,name in zip(out,names):
            l111l1111ll11l1_cdhd_[l1lll1ll11l1_cdhd_ (u"ࠬࡺࡩࡵ࡮ࡨࠫଃ")] += l1lll1ll11l1_cdhd_ (u"࠭ࠠࠦࡵࠪ଄")%name
    return out
url=l1lll1ll11l1_cdhd_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥࡧࡥ࠲ࡵ࡮࡭࡫ࡱࡩ࠳ࡶ࡬࠰ࡪࡲࡲࡩࡵ࠯ࠨଅ")
def l1l1lll1ll11l1_cdhd_(url):
    content = l1lll1l111ll11l1_cdhd_(url)
    ids = [(a.start(), a.end()) for a in re.finditer(l1lll1ll11l1_cdhd_ (u"ࠨ࠾࡯࡭ࠥࡩ࡬ࡢࡵࡶࡁࠧ࡫࡬ࡦ࡯ࡨࡲࡹࡵࠢ࠿ࠩଆ"), content)]
    ids.append( (-1,-1) )
    out=l1ll1l1111ll11l1_cdhd_(url,content)
    for i in range(len(ids[:-1])):
        l11l11111ll11l1_cdhd_ = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile(l1lll1ll11l1_cdhd_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫଇ"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
        host = re.compile(l1lll1ll11l1_cdhd_ (u"ࠪࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨࡀ࠼࠱࠮ࡄ࠯ࠢࠡࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄ࡛࡝ࡵ࡟ࡲࡢ࠱ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬଈ")).search(l11l11111ll11l1_cdhd_)
        l1lll111l1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠫࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥࡧࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࠬଉ"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
        l1ll1lll11ll11l1_cdhd_ =re.compile(l1lll1ll11l1_cdhd_ (u"ࠬࡂࡳࡱࡣࡱࠤࡨࡲࡡࡴࡵࡀࠦࡩࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭ଊ"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
        if href and host:
            j= l1lll111l1ll11l1_cdhd_.group(1) if l1lll111l1ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"࠭ࠧଋ")
            q= l1ll1lll11ll11l1_cdhd_.group(1) if l1ll1lll11ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠧࠨଌ")
            host = host.groups()[-1]
            l1111ll11ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠨࡪࡷࡸࡵ࠭଍")+ urllib.unquote(href.group(1)).split(l1lll1ll11l1_cdhd_ (u"ࠩ࡫ࡸࡹࡶࠧ଎"))[-1]
            print i,host,l1111ll11ll11l1_cdhd_,l1lll1ll11l1_cdhd_ (u"ࠪࡠࡳ࠭ଏ")
            l1ll1l111ll11l1_cdhd_ = l1111ll11ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡨࡪࡡ࠮ࡱࡱࡰ࡮ࡴࡥ࠯ࡲ࡯ࡃࠬଐ"),l1lll1ll11l1_cdhd_ (u"ࠬ࠭଑"))
            if l1ll1l111ll11l1_cdhd_:
                msg =l1lll1ll11l1_cdhd_ (u"࠭ࠧ଒")
                if l1lll1ll11l1_cdhd_ (u"ࠧࡰࡷࡲ࠲࡮ࡵࠧଓ") in l1ll1l111ll11l1_cdhd_:
                    msg = l1lll1ll11l1_cdhd_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡴࡨࡨࡢࠦ࡯ࡶࡱ࠱࡭ࡴࠦ࡮ࡰࡶࠣࡷࡺࡶࡰࡰࡴࡷࡩࡩࡡ࠯ࡄࡑࡏࡓࡗࡣࠧଔ")
                l111l1111ll11l1_cdhd_ = {l1lll1ll11l1_cdhd_ (u"ࠩࡸࡶࡱ࠭କ") : urllib.unquote(l1ll1l111ll11l1_cdhd_),
                    l1lll1ll11l1_cdhd_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩଖ"): l1lll1ll11l1_cdhd_ (u"ࠦࡠࠫࡳ࡞ࠢࠨࡷ࠱ࠦࠥࡴࠢࠨࡷࠧଗ") %(host,j,q,msg),
                    l1lll1ll11l1_cdhd_ (u"ࠬ࡮࡯ࡴࡶࠪଘ"): host    }
                out.append(l111l1111ll11l1_cdhd_)
    return out
url=l1lll1ll11l1_cdhd_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤࡦࡤ࠱ࡴࡴ࡬ࡪࡰࡨ࠲ࡵࡲ࠯ࡴࡧࡵ࡭ࡦࡲࡥ࠰ࡦࡨࡼࡹ࡫ࡲ࠰ࠩଙ")
def l1111l11ll11l1_cdhd_(url):
    content = l1lll1l111ll11l1_cdhd_(url)
    l1llll1l11ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠧࡪ࡯ࡤ࡫ࡪࡀࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭ࠬଚ")).findall(content)
    l1llll1l11ll11l1_cdhd_ = l1llll1l11ll11l1_cdhd_[0] if l1llll1l11ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠨࠩଛ")
    ids = [(a.start(), a.end()) for a in re.finditer(l1lll1ll11l1_cdhd_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢ࡯ࡷࡰࡩࡷࡧ࡮ࡥࡱࠥࡂࠬଜ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11l11111ll11l1_cdhd_ = content[ ids[i][1]:ids[i+1][0] ]
        l111l1ll1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃࡡ࡜ࡴ࡞ࡱࡡ࠰࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨଝ"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
        date = re.compile(l1lll1ll11l1_cdhd_ (u"ࠫࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥࡨࡦࡺࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨଞ")).search(l11l11111ll11l1_cdhd_)
        l1ll111ll1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠬ࠮࡜ࡥ࠭ࡂ࠭ࠥࡾࠠࠩ࡞ࡧ࠯ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ଟ")).findall(l11l11111ll11l1_cdhd_)
        if l111l1ll1ll11l1_cdhd_:
            d= date.group(1) if date else l1lll1ll11l1_cdhd_ (u"࠭ࠧଠ")
            t= l111l1ll1ll11l1_cdhd_.group(2)
            l111l1111ll11l1_cdhd_ = {l1lll1ll11l1_cdhd_ (u"ࠧࡩࡴࡨࡪࠬଡ")  : l111l1ll1ll11l1_cdhd_.group(1),
                l1lll1ll11l1_cdhd_ (u"ࠨࡲ࡯ࡳࡹ࠭ଢ"): l1llll11l1ll11l1_cdhd_(t.strip()),
                l1lll1ll11l1_cdhd_ (u"ࠩࡷ࡭ࡹࡲࡥࠨଣ") : l1llll11l1ll11l1_cdhd_(t.strip()),
                l1lll1ll11l1_cdhd_ (u"ࠪ࡭ࡲ࡭ࠧତ"):l1llll1l11ll11l1_cdhd_,
                l1lll1ll11l1_cdhd_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࠫଥ"): int(l1ll111ll1ll11l1_cdhd_[0][0]) if l1ll111ll1ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠬ࠭ଦ"),
                l1lll1ll11l1_cdhd_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࠧଧ"): int(l1ll111ll1ll11l1_cdhd_[0][1]) if l1ll111ll1ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠧࠨନ"),
                l1lll1ll11l1_cdhd_ (u"ࠨࡣ࡬ࡶࡪࡪࠧ଩") : d}
            out.append(l111l1111ll11l1_cdhd_)
    return out
def l11111l11ll11l1_cdhd_(m):
    return l1lll1ll11l1_cdhd_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠩପ")+urllib.unquote(m.group(1))
def l1l11lll1ll11l1_cdhd_(l1l11l111ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠪࡪ࡮ࡲ࡭ࠨଫ"),l11lll1l1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠫ࡬ࡧࡴࡶࡰࡨ࡯ࠬବ")):
    content = l1lll1l111ll11l1_cdhd_(l1lll1ll11l1_cdhd_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡩࡤࡢ࠯ࡲࡲࡱ࡯࡮ࡦ࠰ࡳࡰ࠴࠭ଭ"))
    if l1ll1l11l1ll11l1_cdhd_:
        content=content.replace(l1ll1l11l1ll11l1_cdhd_,l1lll1ll11l1_cdhd_ (u"࠭ࠧମ"))
        content=re.sub(l1lll1ll11l1_cdhd_ (u"ࡲࠨࡪࡵࡩ࡫ࡃ࡛࡝ࠩࠥࡡࡄ࠮࡛࡟࡞ࠪࠦࠥࡄ࡝ࠬࠫࠪଯ"),l11111l11ll11l1_cdhd_,content)
    selected = []
    if l1l11l111ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"ࠨࡨ࡬ࡰࡲ࠭ର"):
        if l11lll1l1ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"ࠩࡪࡥࡹࡻ࡮ࡦ࡭ࠪ଱"):
            selected = re.compile(l1lll1ll11l1_cdhd_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࡟ࡸࡣ࠺࠰࠱ࡦࡨࡦ࠳࡯࡯࡮࡬ࡲࡪ࠴ࡰ࡭࠱࡮ࡥࡹ࡫ࡧࡰࡴ࡬ࡥ࠴࠴ࠪࡀ࠱ࠬࠦࠥࡺࡩࡵ࡮ࡨࡁࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ଲ")).findall(content)
        elif l11lll1l1ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"ࠫࡷࡵ࡫ࠨଳ"):
            selected = re.compile(l1lll1ll11l1_cdhd_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵࡡࡳ࡞࠼࠲࠳ࡨࡪࡡ࠮ࡱࡱࡰ࡮ࡴࡥ࠯ࡲ࡯࠳ࡷࡵ࡫࠰࡞ࡧࡿ࠹ࢃ࠯ࠪࠤࡁࠬࡡࡪࡻ࠵ࡿࠬࡀ࠴ࡧ࠾ࠨ଴")).findall(content)
        elif l11lll1l1ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"࠭ࡪࡢ࡭ࡲࡷࡨ࠭ଵ"):
            selected = re.compile(l1lll1ll11l1_cdhd_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࡜ࡵࡠ࠾࠴࠵ࡣࡥࡣ࠰ࡳࡳࡲࡩ࡯ࡧ࠱ࡴࡱ࠵ࡪࡢ࡭ࡲࡷࡨ࠵࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨଶ")).findall(content)
    elif l1l11l111ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"ࠨࡵࡨࡶ࡮ࡧ࡬ࠨଷ"):
        if l11lll1l1ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"ࠩࡪࡥࡹࡻ࡮ࡦ࡭ࠪସ"):
            selected = re.compile(l1lll1ll11l1_cdhd_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࡟ࡸࡣ࠺࠰࠱ࡦࡨࡦ࠳࡯࡯࡮࡬ࡲࡪ࠴ࡰ࡭࠱ࡶࡩࡷ࡯ࡡ࡭ࡧ࠰࡫ࡦࡺࡵ࡯ࡧ࡮࠳࠳࠰࠿ࠪࠤ࡞ࡠࡹࡢ࡮ࠡ࡟࠭ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧହ")).findall(content)
        elif l11lll1l1ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"ࠫࡷࡵ࡫ࠨ଺"):
            selected = re.compile(l1lll1ll11l1_cdhd_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵࡡࡳ࡞࠼࠲࠳ࡨࡪࡡ࠮ࡱࡱࡰ࡮ࡴࡥ࠯ࡲ࡯࠳ࡸ࡫ࡲࡪࡣ࡯ࡩ࠲ࡸ࡯࡬࠱࡟ࡨࢀ࠺ࡽ࠰ࠫࠥࡂ࠭ࡢࡤࡼ࠶ࢀ࠭ࡁ࠵ࡡ࠿ࠩ଻")).findall(content)
    if selected:
        l1lll1ll11ll11l1_cdhd_ = [x[0] for x in selected]
        l1ll11l111ll11l1_cdhd_ = [l1lll1ll11l1_cdhd_ (u"࠭ࠠࠨ଼").join(x[1:]) for x in selected]
        return (l1ll11l111ll11l1_cdhd_,l1lll1ll11ll11l1_cdhd_)
    return False
def l1llll11l1ll11l1_cdhd_(l11111111ll11l1_cdhd_):
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠧࠤ࠲࠶࠼ࡀ࠭ଽ"),l1lll1ll11l1_cdhd_ (u"ࠨࠩା"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠩࠩࡰࡹࡁࡢࡳ࠱ࠩ࡫ࡹࡁࠧି"),l1lll1ll11l1_cdhd_ (u"ࠪࠤࠬୀ"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠫࠫࠐࠠࠡࠢࠣࡸࡽࡺࠠ࠾ࠢࡷࡼࡹ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨୁ")&
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠬࠬࠊࠡࠢࠣࠤࡹࡾࡴࠡ࠿ࠣࡸࡽࡺ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩୂ")&
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"࠭ࠦࠋࠢࠣࠤࠥࡺࡸࡵࠢࡀࠤࡹࡾࡴ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪୃ")&
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠧࠧࡳࡸࡳࡹࡁࠧୄ"),l1lll1ll11l1_cdhd_ (u"ࠨࠤࠪ୅")).replace(l1lll1ll11l1_cdhd_ (u"ࠩࠩࡥࡲࡶ࠻ࡲࡷࡲࡸࡀ࠭୆"),l1lll1ll11l1_cdhd_ (u"ࠪࠦࠬେ"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠫࠫࡵࡡࡤࡷࡷࡩࡀ࠭ୈ"),l1lll1ll11l1_cdhd_ (u"ࣹࠬࠧ୉")).replace(l1lll1ll11l1_cdhd_ (u"࠭ࠦࡐࡣࡦࡹࡹ࡫࠻ࠨ୊"),l1lll1ll11l1_cdhd_ (u"ࠧࣔࠩୋ"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠨࠨࡤࡱࡵࡁ࡯ࡢࡥࡸࡸࡪࡁࠧୌ"),l1lll1ll11l1_cdhd_ (u"୍ࣶࠩࠫ")).replace(l1lll1ll11l1_cdhd_ (u"ࠪࠪࡦࡳࡰ࠼ࡑࡤࡧࡺࡺࡥ࠼ࠩ୎"),l1lll1ll11l1_cdhd_ (u"ࠫࣘ࠭୏"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠬࡢࡵ࠱࠳࠳࠹ࠬ୐"),l1lll1ll11l1_cdhd_ (u"࠭अࠨ୑")).replace(l1lll1ll11l1_cdhd_ (u"ࠧ࡝ࡷ࠳࠵࠵࠺ࠧ୒"),l1lll1ll11l1_cdhd_ (u"ࠨआࠪ୓"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠩ࡟ࡹ࠵࠷࠰࠸ࠩ୔"),l1lll1ll11l1_cdhd_ (u"ࠪऋࠬ୕")).replace(l1lll1ll11l1_cdhd_ (u"ࠫࡡࡻ࠰࠲࠲࠹ࠫୖ"),l1lll1ll11l1_cdhd_ (u"ࠬऌࠧୗ"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"࠭࡜ࡶ࠲࠴࠵࠾࠭୘"),l1lll1ll11l1_cdhd_ (u"ࠧचࠩ୙")).replace(l1lll1ll11l1_cdhd_ (u"ࠨ࡞ࡸ࠴࠶࠷࠸ࠨ୚"),l1lll1ll11l1_cdhd_ (u"ࠩछࠫ୛"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠪࡠࡺ࠶࠱࠵࠴ࠪଡ଼"),l1lll1ll11l1_cdhd_ (u"ࠫे࠭ଢ଼")).replace(l1lll1ll11l1_cdhd_ (u"ࠬࡢࡵ࠱࠳࠷࠵ࠬ୞"),l1lll1ll11l1_cdhd_ (u"࠭ुࠨୟ"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠧ࡝ࡷ࠳࠵࠹࠺ࠧୠ"),l1lll1ll11l1_cdhd_ (u"ࠨॆࠪୡ")).replace(l1lll1ll11l1_cdhd_ (u"ࠩ࡟ࡹ࠵࠷࠴࠵ࠩୢ"),l1lll1ll11l1_cdhd_ (u"ࠪेࠬୣ"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠫࡡࡻ࠰࠱ࡨ࠶ࠫ୤"),l1lll1ll11l1_cdhd_ (u"ࣹࠬࠧ୥")).replace(l1lll1ll11l1_cdhd_ (u"࠭࡜ࡶ࠲࠳ࡨ࠸࠭୦"),l1lll1ll11l1_cdhd_ (u"ࠧࣔࠩ୧"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠨ࡞ࡸ࠴࠶࠻ࡢࠨ୨"),l1lll1ll11l1_cdhd_ (u"ࠩफ़ࠫ୩")).replace(l1lll1ll11l1_cdhd_ (u"ࠪࡠࡺ࠶࠱࠶ࡣࠪ୪"),l1lll1ll11l1_cdhd_ (u"ࠫय़࠭୫"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠬࡢࡵ࠱࠳࠺ࡥࠬ୬"),l1lll1ll11l1_cdhd_ (u"࠭ॺࠨ୭")).replace(l1lll1ll11l1_cdhd_ (u"ࠧ࡝ࡷ࠳࠵࠼࠿ࠧ୮"),l1lll1ll11l1_cdhd_ (u"ࠨॻࠪ୯"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠩ࡟ࡹ࠵࠷࠷ࡤࠩ୰"),l1lll1ll11l1_cdhd_ (u"ࠪঀࠬୱ")).replace(l1lll1ll11l1_cdhd_ (u"ࠫࡡࡻ࠰࠲࠹ࡥࠫ୲"),l1lll1ll11l1_cdhd_ (u"ࠬঁࠧ୳"))
    return l11111111ll11l1_cdhd_
