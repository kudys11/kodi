# -*- coding: utf-8 -*-
import sys
l1ll11ll11l1_cdhd_ = sys.version_info [0] == 2
l11ll1ll11l1_cdhd_ = 2048
l1111ll11l1_cdhd_ = 7
def l1lll1ll11l1_cdhd_ (keyedStringLiteral):
	global l1l111ll11l1_cdhd_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll11l1_cdhd_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import xbmc,xbmcgui
import time,re,os,sys,threading
try: from shutil import rmtree
except: rmtree = False
import ramic
def l1l1ll11l1_cdhd_(l11111ll11l1_cdhd_,l1llll1ll11l1_cdhd_=[l1lll1ll11l1_cdhd_ (u"ࠨࠩড")]):
    debug=1
def l11ll11l1_cdhd_(name=l1lll1ll11l1_cdhd_ (u"ࠩࠪঢ")):
    debug=1
def l11l11ll1ll11l1_cdhd_(name=l1lll1ll11l1_cdhd_ (u"ࠪࠫপ")):
    debug=1
def l1ll1ll11l1_cdhd_(top):
    debug=1
def l11ll111ll11l1_cdhd_():
    l11111ll11l1_cdhd_ = os.path.join(xbmc.translatePath(l1lll1ll11l1_cdhd_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨࠫ঱")),l1lll1ll11l1_cdhd_ (u"ࠫࡦࡪࡤࡰࡰࡶࠫল"))
    xbmc.log(l11111ll11l1_cdhd_)
    if l1l1ll11l1_cdhd_(l11111ll11l1_cdhd_,[l1lll1ll11l1_cdhd_ (u"ࠬࡧ࡬ࡪࡧࡱࡻ࡮ࢀࡡࡳࡦࠪ঳"),l1lll1ll11l1_cdhd_ (u"࠭ࡥࡹࡶࡨࡲࡩ࡫ࡲ࠯ࡣ࡯࡭ࡪࡴࠧ঴")])>0:
        l11ll11l1_cdhd_(l1lll1ll11l1_cdhd_ (u"ࠧࡸ࡫ࡽࡥࡷࡪࠧ঵"))
        return
    l11l11ll11l1_cdhd_ = xbmc.translatePath(l1lll1ll11l1_cdhd_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩশ"))
    for f in os.listdir(l11l11ll11l1_cdhd_):
        if f.startswith(l1lll1ll11l1_cdhd_ (u"ࠩࡐࡑࡊ࡙ࠧষ")):
            l11ll11l1_cdhd_()
            return
def run(l11l11l11ll11l1_cdhd_):
    try:
        debug=1
    except: pass
def l11l1ll11ll11l1_cdhd_(fname):
    try:
        l11l111l1ll11l1_cdhd_= open(fname,l1lll1ll11l1_cdhd_ (u"ࠫࡷ࠭হ"))
        data=l11l111l1ll11l1_cdhd_.read(100)
        l11l111l1ll11l1_cdhd_.close()
        if l1lll1ll11l1_cdhd_ (u"ࠬ࡫ࡸࡦࡥࠫࡾࡱ࡯ࡢ࠯ࡦࡨࡧࡴࡳࡰࡳࡧࡶࡷ࠭ࡨࡡࡴࡧ࠹࠸࠳ࡨ࠶࠵ࡦࡨࡧࡴࡪࡥࠩࠩ঺") not in data:
            print data
            l11l11ll1ll11l1_cdhd_()
    except:
        pass
def l11l1l111ll11l1_cdhd_():
    debug=1
