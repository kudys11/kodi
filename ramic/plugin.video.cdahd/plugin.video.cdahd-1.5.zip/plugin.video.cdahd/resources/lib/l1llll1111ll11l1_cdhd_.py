# coding: UTF-8
import sys
l1ll11ll11l1_cdhd_ = sys.version_info [0] == 2
l11ll1ll11l1_cdhd_ = 2048
l1111ll11l1_cdhd_ = 7
def l1lll1ll11l1_cdhd_ (keyedStringLiteral):
	global l1l111ll11l1_cdhd_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll11l1_cdhd_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urlparse,cookielib,urllib2,urllib
import time,re,os
url=l1lll1ll11l1_cdhd_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡪ࡮ࡲ࡭ࡵࡷ࠱ࡴࡱ࠵ࠧೲ")
l111llll1ll11l1_cdhd_= cookielib.LWPCookieJar()
l1ll11l1l1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡐ࡙࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠹࠵࠴࠰࠯࠴࠹࠺࠶࠴࠱࠱࠴ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪೳ")
l11ll1l1l1ll11l1_cdhd_=l1ll11l1l1ll11l1_cdhd_
def l111111l1ll11l1_cdhd_(url,l111llll1ll11l1_cdhd_=l111llll1ll11l1_cdhd_,l11ll1l1l1ll11l1_cdhd_=l1ll11l1l1ll11l1_cdhd_):
    l11ll1lll1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠬ࠭೴")
    try:
        class l11ll11l11ll11l1_cdhd_(urllib2.HTTPErrorProcessor):
            def http_response(self, request, response):
                return response
        def l11ll11111ll11l1_cdhd_(s):
            try:
                offset=1 if s[0]==l1lll1ll11l1_cdhd_ (u"࠭ࠫࠨ೵") else 0
                val = int(eval(s.replace(l1lll1ll11l1_cdhd_ (u"ࠧࠢ࠭࡞ࡡࠬ೶"),l1lll1ll11l1_cdhd_ (u"ࠨ࠳ࠪ೷")).replace(l1lll1ll11l1_cdhd_ (u"ࠩࠤࠥࡠࡣࠧ೸"),l1lll1ll11l1_cdhd_ (u"ࠪ࠵ࠬ೹")).replace(l1lll1ll11l1_cdhd_ (u"ࠫࡠࡣࠧ೺"),l1lll1ll11l1_cdhd_ (u"ࠬ࠶ࠧ೻")).replace(l1lll1ll11l1_cdhd_ (u"࠭ࠨࠨ೼"),l1lll1ll11l1_cdhd_ (u"ࠧࡴࡶࡵࠬࠬ೽"))[offset:]))
                return val
            except:
                pass
        if l111llll1ll11l1_cdhd_==None:
            l111llll1ll11l1_cdhd_ = cookielib.LWPCookieJar()
        opener = urllib2.build_opener(l11ll11l11ll11l1_cdhd_, urllib2.HTTPCookieProcessor(l111llll1ll11l1_cdhd_))
        opener.addheaders = [(l1lll1ll11l1_cdhd_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ೾"), l11ll1l1l1ll11l1_cdhd_)]
        try:
            response = opener.open(url)
            result=l11ll1lll1ll11l1_cdhd_ = response.read()
            response.close()
        except urllib2.HTTPError as e:
            result=l11ll1lll1ll11l1_cdhd_ = e.read()
        time.sleep(1)
        l11lll1111ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠩࡱࡥࡲ࡫࠽ࠣ࡬ࡶࡧ࡭ࡲ࡟ࡷࡥࠥࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭࠴ࠫࡀࠫࠥ࠳ࡃ࠭೿")).findall(result)[0]
        init = re.compile(l1lll1ll11l1_cdhd_ (u"ࠪࡷࡪࡺࡔࡪ࡯ࡨࡳࡺࡺ࡜ࠩࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡡ࠯ࡻ࡝ࡵ࠭࠲࠯ࡅ࠮ࠫ࠼ࠫ࠲࠯ࡅࠩࡾ࠽ࠪഀ")).findall(result)[0]
        l11lll11l1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࡶࠧࡩࡨࡢ࡮࡯ࡩࡳ࡭ࡥ࠮ࡨࡲࡶࡲࡢࠧ࡝ࠫ࠾ࡠࡸ࠰ࠨ࠯ࠬࠬࡥ࠳ࡼࠢഁ")).findall(result)[0]
        l11ll1ll11ll11l1_cdhd_ = l11ll11111ll11l1_cdhd_(init)
        lines = l11lll11l1ll11l1_cdhd_.split(l1lll1ll11l1_cdhd_ (u"ࠬࡁࠧം"))
        if l11lll1111ll11l1_cdhd_:
            for line in lines:
                if len(line)>0 and l1lll1ll11l1_cdhd_ (u"࠭࠽ࠨഃ") in line:
                    l11l1llll1ll11l1_cdhd_=line.split(l1lll1ll11l1_cdhd_ (u"ࠧ࠾ࠩഄ"))
                    l11l1lll11ll11l1_cdhd_ = l11ll11111ll11l1_cdhd_(l11l1llll1ll11l1_cdhd_[1])
                    l11ll1ll11ll11l1_cdhd_ = int(eval(str(l11ll1ll11ll11l1_cdhd_)+l11l1llll1ll11l1_cdhd_[0][-1]+str(l11l1lll11ll11l1_cdhd_)))
            l11ll111l1ll11l1_cdhd_ = l11ll1ll11ll11l1_cdhd_ + len(urlparse.urlparse(url).netloc)
            u=l1lll1ll11l1_cdhd_ (u"ࠨ࠱ࠪഅ").join(url.split(l1lll1ll11l1_cdhd_ (u"ࠩ࠲ࠫആ"))[:-1])
            query = l1lll1ll11l1_cdhd_ (u"ࠪࠩࡸ࠵ࡣࡥࡰ࠰ࡧ࡬࡯࠯࡭࠱ࡦ࡬ࡰࡥࡪࡴࡥ࡫ࡰࡄࡰࡳࡤࡪ࡯ࡣࡻࡩ࠽ࠦࡵࠩ࡮ࡸࡩࡨ࡭ࡡࡤࡲࡸࡽࡥࡳ࠿ࠨࡷࠬഇ") % (u, l11lll1111ll11l1_cdhd_, l11ll111l1ll11l1_cdhd_)
            if l1lll1ll11l1_cdhd_ (u"ࠫࡹࡿࡰࡦ࠿ࠥ࡬࡮ࡪࡤࡦࡰࠥࠤࡳࡧ࡭ࡦ࠿ࠥࡴࡦࡹࡳࠣࠩഈ") in result:
                l11ll1l111ll11l1_cdhd_=re.compile(l1lll1ll11l1_cdhd_ (u"ࠬࡴࡡ࡮ࡧࡀࠦࡵࡧࡳࡴࠤࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪഉ")).findall(result)[0]
                query = l1lll1ll11l1_cdhd_ (u"࠭ࠥࡴ࠱ࡦࡨࡳ࠳ࡣࡨ࡫࠲ࡰ࠴ࡩࡨ࡬ࡡ࡭ࡷࡨ࡮࡬ࡀࡲࡤࡷࡸࡃࠥࡴࠨ࡭ࡷࡨ࡮࡬ࡠࡸࡦࡁࠪࡹࠦ࡫ࡵࡦ࡬ࡱࡥࡡ࡯ࡵࡺࡩࡷࡃࠥࡴࠩഊ") % (u,urllib.quote_plus(l11ll1l111ll11l1_cdhd_), l11lll1111ll11l1_cdhd_, l11ll111l1ll11l1_cdhd_)
                time.sleep(5)
            l1l11111l1ll11l1_cdhd_ =l1lll1ll11l1_cdhd_ (u"ࠧࠨഋ").join([l1lll1ll11l1_cdhd_ (u"ࠨࠧࡶࡁࠪࡹ࠻ࠨഌ")%(c.name, c.value) for c in l111llll1ll11l1_cdhd_])
            opener = urllib2.build_opener(l11ll11l11ll11l1_cdhd_,urllib2.HTTPCookieProcessor(l111llll1ll11l1_cdhd_))
            opener.addheaders = [(l1lll1ll11l1_cdhd_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭഍"), l11ll1l1l1ll11l1_cdhd_),(l1lll1ll11l1_cdhd_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫഎ"),url),(l1lll1ll11l1_cdhd_ (u"࡚ࠫࡶࡧࡳࡣࡧࡩ࠲ࡏ࡮ࡴࡧࡦࡹࡷ࡫࠭ࡓࡧࡴࡹࡪࡹࡴࡴࠩഏ"),l1lll1ll11l1_cdhd_ (u"ࠬ࠷ࠧഐ"))]
            opener.addheaders.append((l1lll1ll11l1_cdhd_ (u"࠭ࡣࡰࡱ࡮࡭ࡪ࠭഑"),l1l11111l1ll11l1_cdhd_))
            try:
                response = opener.open(query)
                response.close()
            except urllib2.HTTPError as e:
                response = e.read()
            print (l1lll1ll11l1_cdhd_ (u"ࠧࡤ࡬ࠪഒ"),l111llll1ll11l1_cdhd_)
        return l111llll1ll11l1_cdhd_
    except:
        return None
def l1ll1l1ll1ll11l1_cdhd_(l11lll1ll11l1_cdhd_):
    l11ll11ll1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠨࠩഓ")
    if os.path.isfile(l11lll1ll11l1_cdhd_):
        l111llll1ll11l1_cdhd_ = cookielib.LWPCookieJar()
        l111llll1ll11l1_cdhd_.load(l11lll1ll11l1_cdhd_,True)
        for c in l111llll1ll11l1_cdhd_:
            l11ll11ll1ll11l1_cdhd_+=l1lll1ll11l1_cdhd_ (u"ࠩࠨࡷࡂࠫࡳ࠼ࠩഔ")%(c.name, c.value)
    return l11ll11ll1ll11l1_cdhd_
