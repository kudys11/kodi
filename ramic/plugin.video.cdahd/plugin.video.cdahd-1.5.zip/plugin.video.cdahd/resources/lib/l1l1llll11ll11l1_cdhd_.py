# coding: UTF-8
import sys
l1ll11ll11l1_cdhd_ = sys.version_info [0] == 2
l11ll1ll11l1_cdhd_ = 2048
l1111ll11l1_cdhd_ = 7
def l1lll1ll11l1_cdhd_ (keyedStringLiteral):
	global l1l111ll11l1_cdhd_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll11l1_cdhd_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
l1lll1ll11l1_cdhd_ (u"ࠢࠣࠤࠍࠤࠥࠦࠠࡶࡴ࡯ࡶࡪࡹ࡯࡭ࡸࡨࡶࠥ࡞ࡂࡎࡅࠣࡅࡩࡪ࡯࡯ࠌࠣࠤࠥࠦࡃࡰࡲࡼࡶ࡮࡭ࡨࡵࠢࠫࡇ࠮ࠦ࠲࠱࠳࠶ࠤࡇࡹࡴࡳࡦࡶࡱࡰࡸࠊࠡࠢࠍࠤࠥࠦࠠࡕࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡩࡴࠢࡩࡶࡪ࡫ࠠࡴࡱࡩࡸࡼࡧࡲࡦ࠼ࠣࡽࡴࡻࠠࡤࡣࡱࠤࡷ࡫ࡤࡪࡵࡷࡶ࡮ࡨࡵࡵࡧࠣ࡭ࡹࠦࡡ࡯ࡦ࠲ࡳࡷࠦ࡭ࡰࡦ࡬ࡪࡾࠐࠠࠡࠢࠣ࡭ࡹࠦࡵ࡯ࡦࡨࡶࠥࡺࡨࡦࠢࡷࡩࡷࡳࡳࠡࡱࡩࠤࡹ࡮ࡥࠡࡉࡑ࡙ࠥࡍࡥ࡯ࡧࡵࡥࡱࠦࡐࡶࡤ࡯࡭ࡨࠦࡌࡪࡥࡨࡲࡸ࡫ࠠࡢࡵࠣࡴࡺࡨ࡬ࡪࡵ࡫ࡩࡩࠦࡢࡺࠌࠣࠤࠥࠦࡴࡩࡧࠣࡊࡷ࡫ࡥࠡࡕࡲࡪࡹࡽࡡࡳࡧࠣࡊࡴࡻ࡮ࡥࡣࡷ࡭ࡴࡴࠬࠡࡧ࡬ࡸ࡭࡫ࡲࠡࡸࡨࡶࡸ࡯࡯࡯ࠢ࠶ࠤࡴ࡬ࠠࡵࡪࡨࠤࡑ࡯ࡣࡦࡰࡶࡩ࠱ࠦ࡯ࡳࠌࠣࠤࠥࠦࠨࡢࡶࠣࡽࡴࡻࡲࠡࡱࡳࡸ࡮ࡵ࡮ࠪࠢࡤࡲࡾࠦ࡬ࡢࡶࡨࡶࠥࡼࡥࡳࡵ࡬ࡳࡳ࠴ࠊࠡࠢࠍࠤࠥࠦࠠࡕࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲࠦࡩࡴࠢࡧ࡭ࡸࡺࡲࡪࡤࡸࡸࡪࡪࠠࡪࡰࠣࡸ࡭࡫ࠠࡩࡱࡳࡩࠥࡺࡨࡢࡶࠣ࡭ࡹࠦࡷࡪ࡮࡯ࠤࡧ࡫ࠠࡶࡵࡨࡪࡺࡲࠬࠋࠢࠣࠤࠥࡨࡵࡵ࡚ࠢࡍ࡙ࡎࡏࡖࡖࠣࡅࡓ࡟ࠠࡘࡃࡕࡖࡆࡔࡔ࡚࠽ࠣࡻ࡮ࡺࡨࡰࡷࡷࠤࡪࡼࡥ࡯ࠢࡷ࡬ࡪࠦࡩ࡮ࡲ࡯࡭ࡪࡪࠠࡸࡣࡵࡶࡦࡴࡴࡺࠢࡲࡪࠏࠦࠠࠡࠢࡐࡉࡗࡉࡈࡂࡐࡗࡅࡇࡏࡌࡊࡖ࡜ࠤࡴࡸࠠࡇࡋࡗࡒࡊ࡙ࡓࠡࡈࡒࡖࠥࡇࠠࡑࡃࡕࡘࡎࡉࡕࡍࡃࡕࠤࡕ࡛ࡒࡑࡑࡖࡉ࠳ࠦࠠࡔࡧࡨࠤࡹ࡮ࡥࠋࠢࠣࠤࠥࡍࡎࡖࠢࡊࡩࡳ࡫ࡲࡢ࡮ࠣࡔࡺࡨ࡬ࡪࡥࠣࡐ࡮ࡩࡥ࡯ࡵࡨࠤ࡫ࡵࡲࠡ࡯ࡲࡶࡪࠦࡤࡦࡶࡤ࡭ࡱࡹ࠮ࠋࠢࠣࠎ࡛ࠥࠦࠠࠡࡲࡹࠥࡹࡨࡰࡷ࡯ࡨࠥ࡮ࡡࡷࡧࠣࡶࡪࡩࡥࡪࡸࡨࡨࠥࡧࠠࡤࡱࡳࡽࠥࡵࡦࠡࡶ࡫ࡩࠥࡍࡎࡖࠢࡊࡩࡳ࡫ࡲࡢ࡮ࠣࡔࡺࡨ࡬ࡪࡥࠣࡐ࡮ࡩࡥ࡯ࡵࡨࠎࠥࠦࠠࠡࡣ࡯ࡳࡳ࡭ࠠࡸ࡫ࡷ࡬ࠥࡺࡨࡪࡵࠣࡴࡷࡵࡧࡳࡣࡰ࠲ࠥࠦࡉࡧࠢࡱࡳࡹ࠲ࠠࡴࡧࡨࠤࡁ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡪࡲࡺ࠴࡯ࡳࡩ࠲ࡰ࡮ࡩࡥ࡯ࡵࡨࡷ࠴ࡄ࠮ࠋࠢࠣࠎࠥࠦࠠࠡࡃࡧࡥࡵࡺࡥࡥࠢࡩࡳࡷࠦࡵࡴࡧࠣ࡭ࡳࠦࡸࡣ࡯ࡦࠤ࡫ࡸ࡯࡮࠼ࠍࠤࠥࠦࠠࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸ࡭ࡻࡢ࠯ࡥࡲࡱ࠴࡫ࡩ࡯ࡣࡵࡷ࠴ࡰࡳ࠮ࡤࡨࡥࡺࡺࡩࡧࡻ࠲ࡦࡱࡵࡢ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡲࡼࡸ࡭ࡵ࡮࠰࡬ࡶࡦࡪࡧࡵࡵ࡫ࡩ࡭ࡪࡸ࠯ࡶࡰࡳࡥࡨࡱࡥࡳࡵ࠲ࡴࡦࡩ࡫ࡦࡴ࠱ࡴࡾࠐࠠࠡࠌࠣࠤࠥࠦࡵࡴࡣࡪࡩ࠿ࠐࠠࠡࠌࠣࠤࠥࠦࡩࡧࠢࡧࡩࡹ࡫ࡣࡵࠪࡶࡳࡲ࡫࡟ࡴࡶࡵ࡭ࡳ࡭ࠩ࠻ࠌࠣࠤࠥࠦࠠࠡࠢࠣࡹࡳࡶࡡࡤ࡭ࡨࡨࠥࡃࠠࡶࡰࡳࡥࡨࡱࠨࡴࡱࡰࡩࡤࡹࡴࡳ࡫ࡱ࡫࠮ࠐࠠࠡࠌࠣࠤࠏ࡛࡮ࡱࡣࡦ࡯ࡪࡸࠠࡧࡱࡵࠤࡉ࡫ࡡ࡯ࠢࡈࡨࡼࡧࡲࡥࠩࡶࠤࡵ࠴ࡡ࠯ࡥ࠱࡯࠳࡫࠮ࡳࠌࠥࠦࠧവ")
import re
import string
def l1111ll111ll11l1_cdhd_(source):
    l1lll1ll11l1_cdhd_ (u"ࠣࠤࠥࡈࡪࡺࡥࡤࡶࡶࠤࡼ࡮ࡥࡵࡪࡨࡶࠥࡦࡳࡰࡷࡵࡧࡪࡦࠠࡪࡵࠣࡔ࠳ࡇ࠮ࡄ࠰ࡎ࠲ࡊ࠴ࡒ࠯ࠢࡦࡳࡩ࡫ࡤ࠯ࠤࠥࠦശ")
    source = source.replace(l1lll1ll11l1_cdhd_ (u"ࠩࠣࠫഷ"),l1lll1ll11l1_cdhd_ (u"ࠪࠫസ"))
    if re.search(l1lll1ll11l1_cdhd_ (u"ࠫࡪࡼࡡ࡭ࠪࡩࡹࡳࡩࡴࡪࡱࡱࠬࡵ࠲ࡡ࠭ࡥ࠯࡯࠱࡫ࠬࠩࡁ࠽ࡶࢁࡪࠩࠨഹ"),source): return True
    else: return False
def unpack(source):
    l1lll1ll11l1_cdhd_ (u"ࠧࠨࠢࡖࡰࡳࡥࡨࡱࡳࠡࡒ࠱ࡅ࠳ࡉ࠮ࡌ࠰ࡈ࠲ࡗ࠴ࠠࡱࡣࡦ࡯ࡪࡪࠠ࡫ࡵࠣࡧࡴࡪࡥ࠯ࠤࠥࠦഺ")
    l11111lll1ll11l1_cdhd_, l111l11111ll11l1_cdhd_, l111l1ll11ll11l1_cdhd_, count = _111l1l111ll11l1_cdhd_(source)
    if count != len(l111l11111ll11l1_cdhd_):
        raise l1111ll1l1ll11l1_cdhd_(l1lll1ll11l1_cdhd_ (u"࠭ࡍࡢ࡮ࡩࡳࡷࡳࡥࡥࠢࡳ࠲ࡦ࠴ࡣ࠯࡭࠱ࡩ࠳ࡸ࠮ࠡࡵࡼࡱࡹࡧࡢ࠯഻ࠩ"))
    try:
        unbase = l111l111l1ll11l1_cdhd_(l111l1ll11ll11l1_cdhd_)
    except TypeError:
        raise l1111ll1l1ll11l1_cdhd_(l1lll1ll11l1_cdhd_ (u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡲ࠱ࡥ࠳ࡩ࠮࡬࠰ࡨ࠲ࡷ࠴ࠠࡦࡰࡦࡳࡩ࡯࡮ࡨ࠰഼ࠪ"))
    def lookup(match):
        l1lll1ll11l1_cdhd_ (u"ࠣࠤࠥࡐࡴࡵ࡫ࠡࡷࡳࠤࡸࡿ࡭ࡣࡱ࡯ࡷࠥ࡯࡮ࠡࡶ࡫ࡩࠥࡹࡹ࡯ࡶ࡫ࡩࡹ࡯ࡣࠡࡵࡼࡱࡹࡧࡢ࠯ࠤࠥࠦഽ")
        l111l1l1l1ll11l1_cdhd_  = match.group(0)
        return l111l11111ll11l1_cdhd_[unbase(l111l1l1l1ll11l1_cdhd_)] or l111l1l1l1ll11l1_cdhd_
    source = re.sub(l1lll1ll11l1_cdhd_ (u"ࡴࠪࠫࠬࡢࡢ࡝ࡹ࠮ࡠࡧ࠭ࠧࠨാ"), lookup, l11111lll1ll11l1_cdhd_)
    return _1111llll1ll11l1_cdhd_(source)
def _111l1l111ll11l1_cdhd_(source):
    l1lll1ll11l1_cdhd_ (u"ࠥࠦࠧࡐࡵࡪࡥࡨࠤ࡫ࡸ࡯࡮ࠢࡤࠤࡸࡵࡵࡳࡥࡨࠤ࡫࡯࡬ࡦࠢࡷ࡬ࡪࠦࡦࡰࡷࡵࠤࡦࡸࡧࡴࠢࡱࡩࡪࡪࡥࡥࠢࡥࡽࠥࡪࡥࡤࡱࡧࡩࡷ࠴ࠢࠣࠤി")
    l111l11l11ll11l1_cdhd_ = (l1lll1ll11l1_cdhd_ (u"ࡶࠧࠨࠢࡾ࡞ࠫࠫ࠭࠴ࠪࠪࠩ࠯ࠤ࠯࠮࡜ࡥ࠭ࠬ࠰ࠥ࠰ࠨ࡝ࡦ࠮࠭࠱ࠦࠪࠨࠪ࠱࠮ࡄ࠯ࠧ࡝࠰ࡶࡴࡱ࡯ࡴ࡝ࠪࠪࡠࢁ࠭࡜ࠪࠤࠥࠦീ"))
    args = re.search(l111l11l11ll11l1_cdhd_, source, re.DOTALL).groups()
    try:
        return args[0], args[3].split(l1lll1ll11l1_cdhd_ (u"ࠬࢂࠧു")), int(args[1]), int(args[2])
    except ValueError:
        raise l1111ll1l1ll11l1_cdhd_(l1lll1ll11l1_cdhd_ (u"࠭ࡃࡰࡴࡵࡹࡵࡺࡥࡥࠢࡳ࠲ࡦ࠴ࡣ࠯࡭࠱ࡩ࠳ࡸ࠮ࠡࡦࡤࡸࡦ࠴ࠧൂ"))
def _1111llll1ll11l1_cdhd_(source):
    l1lll1ll11l1_cdhd_ (u"ࠢࠣࠤࡖࡸࡷ࡯ࡰࠡࡵࡷࡶ࡮ࡴࡧࠡ࡮ࡲࡳࡰࡻࡰࠡࡶࡤࡦࡱ࡫ࠠࠩ࡮࡬ࡷࡹ࠯ࠠࡢࡰࡧࠤࡷ࡫ࡰ࡭ࡣࡦࡩࠥࡼࡡ࡭ࡷࡨࡷࠥ࡯࡮ࠡࡵࡲࡹࡷࡩࡥ࠯ࠤࠥࠦൃ")
    match = re.search(l1lll1ll11l1_cdhd_ (u"ࡳࠩࠪࠫࡻࡧࡲࠡࠬࠫࡣࡡࡽࠫࠪ࡞ࡀࡠࡠࠨࠨ࠯ࠬࡂ࠭ࠧࡢ࡝࠼ࠩࠪࠫൄ"), source, re.DOTALL)
    if match:
        l111lll111ll11l1_cdhd_, l1111lll11ll11l1_cdhd_ = match.groups()
        l1111l1111ll11l1_cdhd_ = len(match.group(0))
        lookup = l1111lll11ll11l1_cdhd_.split(l1lll1ll11l1_cdhd_ (u"ࠩࠥ࠰ࠧ࠭൅"))
        l1111l11l1ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠪࠩࡸࡡࠥࠦࡦࡠࠫെ") % l111lll111ll11l1_cdhd_
        for index, value in enumerate(lookup):
            source = source.replace(l1111l11l1ll11l1_cdhd_ % index, l1lll1ll11l1_cdhd_ (u"ࠫࠧࠫࡳࠣࠩേ") % value)
        return source[l1111l1111ll11l1_cdhd_:]
    return source
class l111l111l1ll11l1_cdhd_(object):
    l1lll1ll11l1_cdhd_ (u"ࠧࠨࠢࡇࡷࡱࡧࡹࡵࡲࠡࡨࡲࡶࠥࡧࠠࡨ࡫ࡹࡩࡳࠦࡢࡢࡵࡨ࠲ࠥ࡝ࡩ࡭࡮ࠣࡩ࡫࡬ࡩࡤ࡫ࡨࡲࡹࡲࡹࠡࡥࡲࡲࡻ࡫ࡲࡵࠌࠣࠤࠥࠦࡳࡵࡴ࡬ࡲ࡬ࡹࠠࡵࡱࠣࡲࡦࡺࡵࡳࡣ࡯ࠤࡳࡻ࡭ࡣࡧࡵࡷ࠳ࠨࠢࠣൈ")
    l1111l1l11ll11l1_cdhd_  = {
        52 : l1lll1ll11l1_cdhd_ (u"࠭࠰࠲࠴࠶࠸࠺࠼࠷࠹࠻ࡤࡦࡨࡪࡥࡧࡩ࡫࡭࡯ࡱ࡬࡮ࡰࡲࡴࡶࡸࡳࡵࡷࡹࡻࡽࡿࡺࡂࡄࡆࡈࡊࡌࡇࡉࡋࡍࡏࡑࡓࡎࡐࡒࠪ൉"),
        54 : l1lll1ll11l1_cdhd_ (u"ࠧ࠱࠳࠵࠷࠹࠻࠶࠸࠺࠼ࡥࡧࡩࡤࡦࡨࡪ࡬࡮ࡰ࡫࡭࡯ࡱࡳࡵࡷࡲࡴࡶࡸࡺࡼࡾࡹࡻࡃࡅࡇࡉࡋࡆࡈࡊࡌࡎࡐࡒࡍࡏࡑࡓࡕࡗ࠭ൊ"),
        62 : l1lll1ll11l1_cdhd_ (u"ࠨ࠲࠴࠶࠸࠺࠵࠷࠹࠻࠽ࡦࡨࡣࡥࡧࡩ࡫࡭࡯ࡪ࡬࡮ࡰࡲࡴࡶࡱࡳࡵࡷࡹࡻࡽࡸࡺࡼࡄࡆࡈࡊࡅࡇࡉࡋࡍࡏࡑࡌࡎࡐࡒࡔࡖࡘࡓࡕࡗ࡙࡛࡝࡟࡚ࠨോ"),
        95 : l1lll1ll11l1_cdhd_ (u"ࠩࠪࠫࠥࠧࠢࠤࠦࠨࠪࡡ࠭ࠨࠪࠬ࠮࠰࠲࠴࠯࠱࠳࠵࠷࠹࠻࠶࠸࠺࠼࠾ࡀࡂ࠽࠿ࡁࡃࡅࡇࡉࡄࡆࡈࡊࡌࡎࡐࡋࡍࡏࡑࡓࡕࡗࡒࡔࡖࡘ࡚࡜࡞࡙࡛࡝࡟ࡡࡣࡥࡠࡢࡤࡦࡨࡪ࡬ࡧࡩ࡫࡭࡯ࡱࡳ࡮ࡰࡲࡴࡶࡸࡺࡵࡷࡹࡻࡽࡿࢁࡼࡾࢀࠪࠫࠬൌ")
    }
    def __init__(self, base):
        self.base = base
        if 2 <= base <= 36:
            self.unbase = lambda string: int(string, base)
        else:
            try:
                self.l111l11ll1ll11l1_cdhd_ = dict((cipher, index) for
                    index, cipher in enumerate(self.l1111l1l11ll11l1_cdhd_[base]))
            except KeyError:
                raise TypeError(l1lll1ll11l1_cdhd_ (u"࡙ࠪࡳࡹࡵࡱࡲࡲࡶࡹ࡫ࡤࠡࡤࡤࡷࡪࠦࡥ࡯ࡥࡲࡨ࡮ࡴࡧ࠯്ࠩ"))
            self.unbase = self._1111l1ll1ll11l1_cdhd_
    def __call__(self, string):
        return self.unbase(string)
    def _1111l1ll1ll11l1_cdhd_(self, string):
        l1lll1ll11l1_cdhd_ (u"ࠦࠧࠨࡄࡦࡥࡲࡨࡪࡹࠠࡢࠢࠣࡺࡦࡲࡵࡦࠢࡷࡳࠥࡧ࡮ࠡ࡫ࡱࡸࡪ࡭ࡥࡳ࠰ࠥࠦࠧൎ")
        l1l1llll1ll11l1_cdhd_ = 0
        for index, cipher in enumerate(string[::-1]):
            l1l1llll1ll11l1_cdhd_ += (self.base ** index) * self.l111l11ll1ll11l1_cdhd_[cipher]
        return l1l1llll1ll11l1_cdhd_
class l1111ll1l1ll11l1_cdhd_(Exception):
    l1lll1ll11l1_cdhd_ (u"ࠧࠨࠢࡃࡣࡧࡰࡾࠦࡰࡢࡥ࡮ࡩࡩࠦࡳࡰࡷࡵࡧࡪࠦ࡯ࡳࠢࡪࡩࡳ࡫ࡲࡢ࡮ࠣࡩࡷࡸ࡯ࡳ࠰ࠣࡅࡷ࡭ࡵ࡮ࡧࡱࡸࠥ࡯ࡳࠡࡣࠍࠤࠥࠦࠠ࡮ࡧࡤࡲ࡮ࡴࡧࡧࡷ࡯ࠤࡩ࡫ࡳࡤࡴ࡬ࡴࡹ࡯࡯࡯࠰ࠥࠦࠧ൏")
    pass
if __name__ == l1lll1ll11l1_cdhd_ (u"ࠨ࡟ࡠ࡯ࡤ࡭ࡳࡥ࡟ࠣ൐"):
    test=l1lll1ll11l1_cdhd_ (u"ࠧࠨࠩࡨࡺࡦࡲࠨࡧࡷࡱࡧࡹ࡯࡯࡯ࠪࡳ࠰ࡦ࠲ࡣ࠭࡭࠯ࡩ࠱ࡪࠩࡼࡹ࡫࡭ࡱ࡫ࠨࡤ࠯࠰࠭࡮࡬ࠨ࡬࡝ࡦࡡ࠮ࡶ࠽ࡱ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࡲࡪࡽࠠࡓࡧࡪࡉࡽࡶࠨࠨ࡞࡟ࡦࠬ࠱ࡣ࠯ࡶࡲࡗࡹࡸࡩ࡯ࡩࠫࡥ࠮࠱ࠧ࡝࡞ࡥࠫ࠱࠭ࡧࠨࠫ࠯࡯ࡠࡩ࡝ࠪ࠽ࡵࡩࡹࡻࡲ࡯ࠢࡳࢁ࠭࠭࠴ࠩ࡞ࠪ࠷࠵ࡢࠧࠪ࠰࠵ࡾ࠭ࢁ࠲ࡺ࠼࡟ࠫ࠺ࡀ࠯࠰ࡣ࠱࠼࠳࠽࠯ࡪ࠱ࡽ࠳ࡾ࠵ࡷ࠯࠴ࡻࡠࠬ࠲࠲ࡸ࠼ࡾࡦ࠿ࡢࠧ࠳ࡸ࡟ࠫ࠱࠷࠹࠻࡞ࠪࡀࡵࡄ࠼ࡶࡀ࠿࠶ࠥࡪ࠽ࠣ࠴࠳ࠦࠥࡩ࠽ࠣࠥ࠴࠻ࠧࡄ࠲ࡶࠢ࠴࠽࠳ࡂ࠯࠳ࡀ࠿࠳ࡺࡄ࠼࠲࠸࠲ࡂࡁࡻ࠾࠽࠴ࠣࡨࡂࠨ࠱࠹ࠤࠣࡧࡂࠨࠣ࠲࠷ࠥࡂ࠷ࡺࠠ࠳ࡵࠣ࠶ࡷࠦ࠲ࡲ࠰࠿࠳࠷ࡄ࠼࠰ࡷࡁࡀ࠴ࡶ࠾࡝ࠩ࠯࠶ࡵࡀ࡜ࠨ࠾ࡳࡂࡁࡻ࠾࠽࠴ࠣࡨࡂࠨ࠲࠱ࠤࠣࡧࡂࠨࠣ࠲࠹ࠥࡂ࠷ࡵࠠ࠳ࡰࠣࡦ࠳ࡂ࠯࠳ࡀ࠿࠳ࡺࡄ࠼࠲࠸࠲ࡂࡁࡻ࠾࠽࠴ࠣࡨࡂࠨ࠱࠹ࠤࠣࡧࡂࠨࠣ࠲࠷ࠥࡂ࠷ࡳࠠ࠳࡮ࠣ࠶ࡰࠦ࠲࡫࠰࠿࠳࠷ࡄ࠼࠰ࡷࡁࡀ࠴ࡶ࠾࡝ࠩ࠯ࢁ࠱࠸ࡩ࠻࡞ࠪ࠶࡭ࡢࠧ࠭࠴ࡪ࠾ࡠࢁ࠱࠵࠼ࠥ࠵࠶ࠨࠬࡣ࠼ࠥ࠹࠿࠵࠯ࡢ࠰࠻࠲࠼࠵࠲ࡧ࠱࠴࠷࠳࠷࠲ࠣࡿ࠯ࡿ࠶࠺࠺ࠣ࠴ࡨࠦ࠱ࡨ࠺ࠣ࠷࠽࠳࠴ࡧ࠮࠹࠰࠺࠳࠷ࡪ࠯࠲࠵࠱࠵࠷ࠨࡽ࠭࡟࠯࠶ࡨࡀࠢ࠲࠳ࠥ࠰࠷ࡨ࠺࡜ࡽ࠴࠴࠿ࡢࠧ࠳ࡣ࡟ࠫ࠱࠸࠹࠻࡞ࠪ࠹࠿࠵࠯ࡷ࠰࠻࠲࠼࠵ࡴ࠮࡯࠲ࡱ࠳࠸࠸࡝ࠩࢀ࠰ࢀ࠷࠰࠻࡞ࠪ࠶࠼ࡢࠧࡾ࡟࠯࠶࠻ࡀࡻ࡝ࠩ࠵࠹࠲࠹࡜ࠨ࠼ࡾࡠࠬ࠸࠴࡝ࠩ࠽ࡿࡡ࠭࠲࠴࡞ࠪ࠾࠷࠸ࠬ࡝ࠩ࠵࠵ࡡ࠭࠺࡝ࠩ࠸࠾࠴࠵ࡡ࠯࠺࠱࠻࠴࡯࠯ࡻ࠱ࡼ࠳ࡡ࠭ࠬ࡝ࠩ࠴ࡾࡡ࠭࠺࡝ࠩࡺࡠࠬ࠲࡜ࠨ࠳ࡼࡠࠬࡀ࡜ࠨ࠳ࡻࡠࠬࢃࡽࡾ࠮ࡶ࠾ࡡ࠭࠵࠻࠱࠲ࡺ࠳࠾࠮࠸࠱ࡷ࠱ࡲ࠵ࡳ࠰࠳ࡺ࠲࠶ࡼ࡜ࠨ࠮࠴ࡹ࠿ࠨ࠱ࡵࠤ࠯࠵ࡸࡀࠢ࠲ࡴࠥ࠰࠶ࡷ࠺࡝ࠩ࠴ࡴࡡ࠭ࠬ࠲ࡱ࠽ࠦ࠶ࡴࠢ࠭࠳ࡰ࠾ࠧ࠷࡬ࠣ࠮࠴࡯࠿ࡢࠧ࠶࡞ࠪ࠰࠶ࡰ࠺࡝ࠩࡲࡠࠬ࠲ࡽࠪ࠽࡯ࠤࡪࡁ࡬ࠡ࡭ࡀ࠴ࡀࡲࠠ࠷࠿࠳࠿࠹࠮ࠩ࠯࠳࡬ࠬ࠾࠮ࡸࠪࡽࡩࠬ࠻ࡄ࠰ࠪ࡭࠮ࡁࡽ࠴ࡲ࠮࠸࠾࠺ࡂࡾ࠮ࡳ࠽ࡩࠬࡶࠧ࠽࠱ࠨࠩ࡯ࡃࡃࡱࠪࡽ࠹ࡁ࠲࠷࠻࠵ࠪࠬ࠲࠶࡮ࠨࠪ࠽࠷ࠬ࠮࠴࠱ࡨࠪࡲ࠭ࡀࠪࠨ࡝ࠩࠦ࠵࡫ࡢࠧࠪ࠰࡭ࠬ࠮ࡁࠤࠩ࡞ࠪ࡬࠳࡭࡜ࠨࠫ࠱࡮࠭࠯ࡽࡾࠫ࠾࠸࠭࠯࠮࠲ࡧࠫ࠽࠭ࡾࠩࡼ࠸ࡀ࠱࠶ࢃࠩ࠼࠶ࠫ࠭࠳࠷ࡤࠩ࠻ࠫࡼ࠮ࢁ࡮ࠩࡺࠬࢁ࠮ࡁ࠴ࠩࠫ࠱࠵ࡨ࠮࠹ࠩࠫࡾࠨ࠭ࡢࠧࡩ࠰ࡪࡠࠬ࠯࠮࡫ࠪࠬࢁ࠮ࡁ࠹ࠡࡰࠫࡼ࠮ࢁࠤࠩ࡞ࠪ࡬࠳࡭࡜ࠨࠫ࠱࠵ࡧ࠮ࠩ࠼ࡨࠫࡩ࠮࠷ࡡ࠼ࡧࡀ࠵ࡀࢃࠧ࠭࠵࠹࠰࠶࠶࠹࠭ࠩࡿࢀ࡫ࡵ࡮ࡵࡾࡿ࡮ࡼࡶ࡬ࡢࡻࡨࡶࢁ࡮ࡴࡵࡲࡿࡴ࠵࠷࠰࠳࠺࠼࠹ࢁࡳࡥࡽࡸ࡬ࡨࡹࡵࡼࡧࡷࡱࡧࡹ࡯࡯࡯ࡾࡨࡨ࡬࡫࠳ࡽࡨ࡬ࡰࡪࢂࡣࡰ࡮ࡲࡶࢁࡹࡩࡻࡧࡿࡺࡻࡶ࡬ࡢࡻࡿ࡭࡫ࢂࡶࡪࡦࡨࡳࡤࡧࡤࡽࡦ࡬ࡺࢁࢂࡳࡩࡱࡺࢀࡹࡺ࠱࠱࠴࠻࠽࠺ࢂࡶࡢࡴࡿࡴࡱࡧࡹࡦࡴࡿࡨࡴࡖ࡬ࡢࡻࡿࡪࡦࡲࡳࡦࡾࡿ࠶࠶࠼࠰࠱ࡾࡳࡳࡸ࡯ࡴࡪࡱࡱࢀࡸࡱࡩ࡯ࡾࡷࡩࡸࡺࡼࡽࡵࡷࡥࡹ࡯ࡣࡽ࠳ࡼ࠻ࡴࡱࡲࡲ࡭ࡹ࠸࡯࡯ࡼࡽ࠲࠳࠴࠷࠶ࡼ࠱࠳ࡿࡸࡾࡶࡥࡽ࠵࠹࠴ࡵࢂ࡭ࡱ࠶ࡿࡺ࡮ࡪࡥࡰࡾ࡯ࡥࡧ࡫࡬ࡽࡈࡉࡊࡋࡌࡆࡽࡤࡵࢀࡋࡌ࠰࠱࠲࠳ࢀࢁࡪࡥ࡭ࡧࡷࡩࡩࢂࡲࡦࡶࡸࡶࡳࢂࡨࡪࡦࡨࢀࡴࡴࡃࡰ࡯ࡳࡰࡪࡺࡥࡽࡱࡱࡔࡱࡧࡹࡽࡱࡱࡗࡪ࡫࡫ࡽࡲ࡯ࡥࡾࡥ࡬ࡪ࡯࡬ࡸࡤࡨ࡯ࡹࡾࡶࡩࡹࡌࡵ࡭࡮ࡶࡧࡷ࡫ࡥ࡯ࡾࡶࡸࡴࡶࡼࡰࡰࡗ࡭ࡲ࡫ࡼࡥࡱࡦ࡯ࢁࡶࡲࡰࡸ࡬ࡨࡪࡸࡼ࠴࠻࠴ࢀ࡭࡫ࡩࡨࡪࡷࢀ࠻࠻࠰ࡽࡹ࡬ࡨࡹ࡮ࡼࡰࡸࡨࡶࢁࡩ࡯࡯ࡶࡵࡳࡱࡨࡡࡳࡾ࠸࠵࠶࠶ࡼࡥࡷࡵࡥࡹ࡯࡯࡯ࡾࡸࡲ࡮࡬࡯ࡳ࡯ࡿࡷࡹࡸࡥࡵࡥ࡫࡭ࡳ࡭ࡼࡻ࡫ࡳࢀࡸࡺ࡯ࡳ࡯ࡷࡶࡴࡵࡰࡦࡴࡿ࠶࠶࠹ࡼࡧࡴࡨࡵࡺ࡫࡮ࡤࡻࡿࡴࡷ࡫ࡦࡪࡺࡿࢀࡵࡧࡴࡩࡾࡷࡶࡺ࡫ࡼࡦࡰࡤࡦࡱ࡫ࡤࡽࡲࡵࡩࡻ࡯ࡥࡸࡾࡷ࡭ࡲ࡫ࡳ࡭࡫ࡧࡩࡷࡺ࡯ࡰ࡮ࡷ࡭ࡵࡶ࡬ࡶࡩ࡬ࡲࢁࡶ࡬ࡶࡩ࡬ࡲࡸࢂࡨࡵ࡯࡯࠹ࢁࡹࡷࡧࡾࡶࡶࡨࢂࡦ࡭ࡣࡶ࡬ࢁࡳ࡯ࡥࡧࡶࢀ࡭ࡪ࡟ࡥࡧࡩࡥࡺࡲࡴࡽ࠵ࡥ࡮࡭ࡵࡨࡧࡺࡳ࡭ࡶࡽࡷࡴ࠶ࡳ࡬ࡻࡷࡴࡴࡰࡲࡰࡽࡵࡣࡺࡥ࡫ࡹࡲࡱ࠲࠸࠶ࡧࡷࡳࡱࡢ࡭ࡼ࠹ࡷ࡫࡭ࡱ࠷ࡷࡽ࠺ࡿࡺ࠷࠸ࡩࡻ࡭ࡦࢂ࠲࠵࠲ࡳࢀ࠸ࡨࡪࡩࡱ࡫ࡪࡽࡶࡩࡲࡹࡺࡷ࠹ࡶࡨࡷࡳࡷࡷࡳࡵ࡬ࡹࡱࡦࡽࡨ࡮ࡵ࡮࡭࠵࠻࠹ࡪࡳ࡯࡭ࡥࡥ࠸࠼ࡳࡧࡩࡴ࠺ࡺࢀࡹ࠴ࡶࡹ࠶ࡴ࡯ࡤࡲࡾ࡫ࡨࢁࡵࡲࡪࡩ࡬ࡲࡦࡲࡼࡳࡣࡷ࡭ࡴࢂࡢࡳࡱ࡮ࡩࡳࢂࡩࡴࡾ࡯࡭ࡳࡱࡼ࡚ࡱࡸࡶࢁࡹࡵࡤࡪࡿࡒࡴࢂ࡮ࡰࡨ࡬ࡰࡪࢂ࡭ࡰࡴࡨࢀࡦࡴࡹࡽࡣࡹࡥ࡮ࡲࡡࡣࡧࡿࡒࡴࡺࡼࡇ࡫࡯ࡩࢁࡕࡋࡽࡲࡵࡩࡻ࡯ࡷࡽ࡬ࡳ࡫ࢁ࡯࡭ࡢࡩࡨࢀࡸ࡫ࡴࡶࡲࡿࡪࡱࡼࡰ࡭ࡣࡼࡩࡷ࠭࠮ࡴࡲ࡯࡭ࡹ࠮ࠧࡽࠩࠬ࠭࠮࠭ࠧࠨ൑")
    print unpack(test)
