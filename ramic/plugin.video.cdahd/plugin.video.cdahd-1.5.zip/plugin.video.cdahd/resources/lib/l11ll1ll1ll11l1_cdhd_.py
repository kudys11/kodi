# -*- coding: utf-8 -*-
import sys
l1ll11ll11l1_cdhd_ = sys.version_info [0] == 2
l11ll1ll11l1_cdhd_ = 2048
l1111ll11l1_cdhd_ = 7
def l1lll1ll11l1_cdhd_ (keyedStringLiteral):
	global l1l111ll11l1_cdhd_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll11l1_cdhd_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os
import json
import l1l11l1111ll11l1_cdhd_ as l1llll1111ll11l1_cdhd_
import cookielib
from urlparse import urlparse
l1ll11lll1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡥࡣࡻ࠲ࡹࡼ࠯ࠨర")
l111ll1l1ll11l1_cdhd_ = 15
l1ll11l1l1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠺࠸࠯࠲࠱࠶࠺࠼࠴࠯࠻࠺ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫఱ")
l11lll1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࡲࠨࡆ࠽ࡠࡨࡪࡡࡹ࠰ࡦࡳࡴࡱࡩࡦࠩల")
l1ll1l11l1ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠨࠩళ")
l11llll1l1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠩࠪఴ")
l11llll1l1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡣࡴࡤࡱࡰࡧ࠭ࡱࡴࡲࡼࡾ࠴ࡰ࡭࠱ࠪవ")
l1l11l1l11ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠫࠬశ")
def l1l111l1l1ll11l1_cdhd_(url,header={}):
    l1ll1l111ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠬ࠭ష")
    global l1l11l1l11ll11l1_cdhd_
    if not l1l11l1l11ll11l1_cdhd_:
        req = urllib2.Request(l11llll1l1ll11l1_cdhd_,data=None,headers={l1lll1ll11l1_cdhd_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪస"): l1ll11l1l1ll11l1_cdhd_,l1lll1ll11l1_cdhd_ (u"ࠧࡖࡲࡪࡶࡦࡪࡥ࠮ࡋࡱࡷࡪࡩࡵࡳࡧ࠰ࡖࡪࡷࡵࡦࡵࡷࡷࠬహ"):1})
        response = urllib2.urlopen(req,timeout=l111ll1l1ll11l1_cdhd_)
        cookies=response.headers.get(l1lll1ll11l1_cdhd_ (u"ࠨࡵࡨࡸ࠲ࡩ࡯ࡰ࡭࡬ࡩࠬ఺"),l1lll1ll11l1_cdhd_ (u"ࠩࠣࠫ఻")).split(l1lll1ll11l1_cdhd_ (u"ࠪࠤ఼ࠬ"))[0]
        response.close()
        l1l11l1l11ll11l1_cdhd_ = cookies
    else:
        cookies=l1l11l1l11ll11l1_cdhd_
    data = l1lll1ll11l1_cdhd_ (u"ࠫࡺࡃࠥࡴࠨࡤࡰࡱࡵࡷࡄࡱࡲ࡯࡮࡫ࡳ࠾ࡱࡱࠫఽ")%urllib.quote_plus(url)
    l1l111l111ll11l1_cdhd_ = l11llll1l1ll11l1_cdhd_+l1lll1ll11l1_cdhd_ (u"ࠬ࠵ࡩ࡯ࡥ࡯ࡹࡩ࡫ࡳ࠰ࡲࡵࡳࡨ࡫ࡳࡴ࠰ࡳ࡬ࡵࡅࡡࡤࡶ࡬ࡳࡳࡃࡵࡱࡦࡤࡸࡪ࠭ా")
    headers={l1lll1ll11l1_cdhd_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪి"): l1ll11l1l1ll11l1_cdhd_,l1lll1ll11l1_cdhd_ (u"ࠧࡖࡲࡪࡶࡦࡪࡥ࠮ࡋࡱࡷࡪࡩࡵࡳࡧ࠰ࡖࡪࡷࡵࡦࡵࡷࡷࠬీ"):1,l1lll1ll11l1_cdhd_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨు"):cookies}
    headers.update(header)
    req = urllib2.Request(l1l111l111ll11l1_cdhd_,data,headers)
    response = urllib2.urlopen(req,timeout=l111ll1l1ll11l1_cdhd_)
    l1ll1l111ll11l1_cdhd_=response.read()
    if l1lll1ll11l1_cdhd_ (u"ࠩࡶࡷࡱࡧࡧࡳࡧࡨࠫూ") in l1ll1l111ll11l1_cdhd_:
        l1l111l111ll11l1_cdhd_ = l11llll1l1ll11l1_cdhd_+l1lll1ll11l1_cdhd_ (u"ࠪ࠳࡮ࡴࡣ࡭ࡷࡧࡩࡸ࠵ࡰࡳࡱࡦࡩࡸࡹ࠮ࡱࡪࡳࡃࡦࡩࡴࡪࡱࡱࡁࡸࡹ࡬ࡢࡩࡵࡩࡪ࠭ృ")
        req = urllib2.Request(l1l111l111ll11l1_cdhd_,data,headers)
        response = urllib2.urlopen(req,timeout=l111ll1l1ll11l1_cdhd_)
        l1ll1l111ll11l1_cdhd_=response.read()
    response.close()
    print l1lll1ll11l1_cdhd_ (u"ࠫࡌࡇࡔࡆࠢ࡬ࡲ࡛ࠥࡓࡆࠩౄ")
    return l1ll1l111ll11l1_cdhd_
def _1ll1ll1l1ll11l1_cdhd_(url,data=None,header={},cookies=None):
    headers={l1lll1ll11l1_cdhd_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ౅"): l1ll11l1l1ll11l1_cdhd_,l1lll1ll11l1_cdhd_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧె"):l1ll11lll1ll11l1_cdhd_}
    headers.update(header)
    req = urllib2.Request(url,data,headers)
    l11lll1ll1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠧࠨే")
    if cookies:
        req.add_header(l1lll1ll11l1_cdhd_ (u"ࠣࡅࡲࡳࡰ࡯ࡥࠣై"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l111ll1l1ll11l1_cdhd_)
        l11lll1ll1ll11l1_cdhd_ = response.headers[l1lll1ll11l1_cdhd_ (u"ࠩࡶࡩࡹ࠳ࡣࡰࡱ࡮࡭ࡪ࠭౉")]
        response = urllib2.urlopen(req,timeout=l111ll1l1ll11l1_cdhd_)
        l1ll1l111ll11l1_cdhd_ = response.read()
    except:
        l1ll1l111ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠪࠫొ")
    return l1ll1l111ll11l1_cdhd_
def l1lll1l111ll11l1_cdhd_(url,data=None,header={}):
    cookies=l1llll1111ll11l1_cdhd_.l1ll1l1ll1ll11l1_cdhd_(l11lll1ll11l1_cdhd_)
    content=_1ll1ll1l1ll11l1_cdhd_(url,data,header,cookies)
    if not content or len(content)<100:
        l111llll1ll11l1_cdhd_=l1ll1llll1ll11l1_cdhd_(url,l11lll1ll11l1_cdhd_)
        cookies=l1llll1111ll11l1_cdhd_.l1ll1l1ll1ll11l1_cdhd_(l11lll1ll11l1_cdhd_)
        content=_1ll1ll1l1ll11l1_cdhd_(url,data,header,cookies)
        if not content:
            print l1lll1ll11l1_cdhd_ (u"ࠫࡻ࡯ࡡࠡࡉࡄࡘࡊࡀࠠࠦࡵࠪో")%url
            content=l1l111l1l1ll11l1_cdhd_(url,header)
    return content
def l1ll1llll1ll11l1_cdhd_(l1ll1l111ll11l1_cdhd_,l1lll1l1l1ll11l1_cdhd_):
    l111llll1ll11l1_cdhd_ = cookielib.LWPCookieJar()
    l1lll11ll1ll11l1_cdhd_ = l1llll1111ll11l1_cdhd_.l111111l1ll11l1_cdhd_(l1ll1l111ll11l1_cdhd_,l111llll1ll11l1_cdhd_,l1ll11l1l1ll11l1_cdhd_)
    l111l11l1ll11l1_cdhd_=os.path.dirname(l1lll1l1l1ll11l1_cdhd_)
    if not os.path.exists(l111l11l1ll11l1_cdhd_):
        os.makedirs(l111l11l1ll11l1_cdhd_)
    if l111llll1ll11l1_cdhd_:
        l111llll1ll11l1_cdhd_.save(l1lll1l1l1ll11l1_cdhd_, ignore_discard = True)
    return l111llll1ll11l1_cdhd_
def l1ll1lll1ll11l1_cdhd_(url,l1l1l1l1ll11l1_cdhd_=1,group=l1lll1ll11l1_cdhd_ (u"ࠬ࠭ౌ")):
    if l1lll1ll11l1_cdhd_ (u"࠭࠿ࡱࡣࡪࡩࡂ్࠭") in url:
        url = re.sub(l1lll1ll11l1_cdhd_ (u"ࠧࠨࠩࡳࡥ࡬࡫࠽࡝ࡦ࠮ࠫࠬ࠭౎"),l1lll1ll11l1_cdhd_ (u"ࠨࠩࠪࡴࡦ࡭ࡥ࠾ࠧࡧࠫࠬ࠭౏")%l1l1l1l1ll11l1_cdhd_,url)
    else:
        url += l1lll1ll11l1_cdhd_ (u"ࠩ࠲ࠫ౐") if url[-1] != l1lll1ll11l1_cdhd_ (u"ࠪ࠳ࠬ౑") else l1lll1ll11l1_cdhd_ (u"ࠫࠬ౒")
        url = url + l1lll1ll11l1_cdhd_ (u"ࠬࡅࡰࡢࡩࡨࡁࠪࡪࠧ౓") %l1l1l1l1ll11l1_cdhd_
    content = l1lll1l111ll11l1_cdhd_(url)
    content = urllib.unquote(content)
    l1l11l1ll1ll11l1_cdhd_ = l1llll1111ll11l1_cdhd_.l1ll1l1ll1ll11l1_cdhd_(l11lll1ll11l1_cdhd_)
    l1l11111l1ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠨࡼࡄࡱࡲ࡯࡮࡫࠽ࠦࡵ࡙ࠩࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺ࠽ࠦࡵࠥ౔") % (l1l11l1ll1ll11l1_cdhd_, l1ll11l1l1ll11l1_cdhd_) if l1l11l1ll1ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠧࠨౕ")
    if group:
        idx = [(m.start(0), m.end(0)) for m in re.finditer(group.decode(l1lll1ll11l1_cdhd_ (u"ࠨࡷࡷࡪ࠲࠾ౖࠧ")), content,re.IGNORECASE) ]
        if idx:
            idx = idx[0][0]
            l1llllll11ll11l1_cdhd_=content[idx:]
            ids = [(a.start(), a.end()) for a in re.finditer(l1lll1ll11l1_cdhd_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡪࡦࡀࠦ࡮ࡺࡥ࡮࠯࡯࡭ࡸࡺࠢࠨ౗"), l1llllll11ll11l1_cdhd_)]
            if not ids:
                ids = [(a.start(), a.end()) for a in re.finditer(l1lll1ll11l1_cdhd_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡷࡩࡲ࠳࡬ࡪࡵࡷࠤࡷࡵࡷࠣࠩౘ"), l1llllll11ll11l1_cdhd_)]
            ids.append( (-1,-1) )
            if len(ids)>1: content = l1llllll11ll11l1_cdhd_[ ids[0][1]:ids[1][0] ]
    ids = [(a.start(), a.end()) for a in re.finditer(l1lll1ll11l1_cdhd_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳ࡸࡴ࠯࡟ࡨࢀ࠷ࡽࠡࡥࡲࡰ࠲ࡹ࡭࠮࡞ࡧࡿ࠶ࢃ࡛࡟ࠤࡠ࠮ࠧࡄࠧౙ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11l11111ll11l1_cdhd_ = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile(l1lll1ll11l1_cdhd_ (u"ࠬ࠭ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠧࠨౚ")).search(l11l11111ll11l1_cdhd_)
        title = re.compile(l1lll1ll11l1_cdhd_ (u"࠭ࠧࠨࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࠩࠪ౛"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
        l1lllll1l1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠧࠨࠩࡧࡥࡹࡧ࠭ࡤࡱࡱࡸࡪࡴࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩࠪࠫ౜")).search(l11l11111ll11l1_cdhd_)
        l1llll1l11ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠨࠩࠪࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠧࠨౝ")).search(l11l11111ll11l1_cdhd_)
        year =  re.compile(l1lll1ll11l1_cdhd_ (u"ࠩࠪࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡼࡩࡦࡸࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨࠩࠪ౞")).search(l11l11111ll11l1_cdhd_)
        l1l111ll11ll11l1_cdhd_ =  re.compile(l1lll1ll11l1_cdhd_ (u"ࠪࠫࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡶࡦࡺࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩࠪࠫ౟")).search(l11l11111ll11l1_cdhd_)
        if href and title:
            l1llll1l11ll11l1_cdhd_ = l1llll1l11ll11l1_cdhd_.group(1) if l1llll1l11ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠫࠬౠ")
            l1llll1l11ll11l1_cdhd_ = _1l1111l11ll11l1_cdhd_(l1llll1l11ll11l1_cdhd_)
            l111l1111ll11l1_cdhd_ = {l1lll1ll11l1_cdhd_ (u"ࠬ࡮ࡲࡦࡨࠪౡ")   : _1l1111l11ll11l1_cdhd_(href.group(1)),
                l1lll1ll11l1_cdhd_ (u"࠭ࡴࡪࡶ࡯ࡩࠬౢ")  : l1llll11l1ll11l1_cdhd_(title.group(1)),
                l1lll1ll11l1_cdhd_ (u"ࠧࡱ࡮ࡲࡸࠬౣ")   : l1llll11l1ll11l1_cdhd_(l1lllll1l1ll11l1_cdhd_.group(1)) if l1lllll1l1ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠨࠩ౤"),
                l1lll1ll11l1_cdhd_ (u"ࠩ࡬ࡱ࡬࠭౥")    : l1llll1l11ll11l1_cdhd_,
                l1lll1ll11l1_cdhd_ (u"ࠪࡶࡦࡺࡩ࡯ࡩࠪ౦") : l1l111ll11ll11l1_cdhd_.group(1) if l1l111ll11ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠫࠬ౧"),
                l1lll1ll11l1_cdhd_ (u"ࠬࡿࡥࡢࡴࠪ౨")   : year.group(1) if year else l1lll1ll11l1_cdhd_ (u"࠭ࠧ౩"),
                    }
            out.append(l111l1111ll11l1_cdhd_)
    l1ll1ll111ll11l1_cdhd_ = l1l1l1l1ll11l1_cdhd_+1 if  content.find(l1lll1ll11l1_cdhd_ (u"ࠧࡱࡣࡪࡩࡂࠫࡤࠨ౪") %(l1l1l1l1ll11l1_cdhd_+1))>-1 else False
    l1111lll1ll11l1_cdhd_ = l1l1l1l1ll11l1_cdhd_-1 if l1l1l1l1ll11l1_cdhd_>1 else False
    return (out, (l1111lll1ll11l1_cdhd_,l1ll1ll111ll11l1_cdhd_))
def l11llllll1ll11l1_cdhd_(url):
    content = l1lll1l111ll11l1_cdhd_(url)
    l11l11111ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠨࠩࠪࡀࡺࡲࠠࡪࡦࡀࠦࡸ࡫ࡲࡪࡧࡶ࠱ࡱ࡯ࡳࡵࠤࠣࡧࡱࡧࡳࡴ࠿ࠥࡪ࡮ࡲࡴࡦࡴࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨࠩࠪ౫"),re.DOTALL).findall(content)
    out=[]
    if l11l11111ll11l1_cdhd_:
        l1l11ll1l1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠩࠪࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠧࠨࠩ౬"),re.MULTILINE).findall(l11l11111ll11l1_cdhd_[0])
        for href,title in l1l11ll1l1ll11l1_cdhd_:
            l111l1111ll11l1_cdhd_ = {l1lll1ll11l1_cdhd_ (u"ࠪ࡬ࡷ࡫ࡦࠨ౭")   : _1l1111l11ll11l1_cdhd_(href),
                l1lll1ll11l1_cdhd_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ౮")  : l1llll11l1ll11l1_cdhd_(title),
                l1lll1ll11l1_cdhd_ (u"ࠬࡶ࡬ࡰࡶࠪ౯")   : l1lll1ll11l1_cdhd_ (u"࠭ࠧ౰"),
                    }
            out.append(l111l1111ll11l1_cdhd_)
    return out
def _1l1111l11ll11l1_cdhd_(href):
    url = href.replace(l1lll1ll11l1_cdhd_ (u"ࠧ࠰ࡤࡵࡳࡼࡹࡥ࠯ࡲ࡫ࡴࡄࡻ࠽ࠨ౱"),l1lll1ll11l1_cdhd_ (u"ࠨࠩ౲"))
    url = url.split(l1lll1ll11l1_cdhd_ (u"ࠩࠩࡥࡲࡶ࠻ࠨ౳"))[0]
    return urllib.unquote(url)
url=l1lll1ll11l1_cdhd_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨࡪࡡࡹ࠰ࡷࡺ࠴࡮ࡵࡨࡱ࠰࡭࠲ࡲ࡯ࡸࡥࡼ࠱ࡩࡻࡣࡩࡱࡺࠫ౴")
def l1l1lll1ll11l1_cdhd_(url):
    content = l1lll1l111ll11l1_cdhd_(url)
    out=[]
    l11lll1l11ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠫࠬ࠭࠼ࡵࡤࡲࡨࡾࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡣࡱࡧࡽࡃ࠭ࠧࠨ౵"),re.DOTALL).findall(content)
    for l1l1111ll1ll11l1_cdhd_ in l11lll1l11ll11l1_cdhd_:
        l11llll111ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠬ࠭ࠧ࠽ࡶࡵࠬ࠳࠰࠿ࠪ࠾࠲ࡸࡷࡄࠧࠨࠩ౶"),re.DOTALL).findall(l1l1111ll1ll11l1_cdhd_)
        for l1l1l1ll11l1_cdhd_ in l11llll111ll11l1_cdhd_:
            l11lllll11ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"࠭ࠧࠨ࠾ࡷࡨ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡪ࠾ࠨࠩࠪ౷"),re.DOTALL).findall(l1l1l1ll11l1_cdhd_)
            host = re.compile(l1lll1ll11l1_cdhd_ (u"ࠧࠨࠩࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧࠨࠩ౸")).findall(l11lllll11ll11l1_cdhd_[0]) if len(l11lllll11ll11l1_cdhd_)>1 else l1lll1ll11l1_cdhd_ (u"ࠨࠩ౹")
            version = l11lllll11ll11l1_cdhd_[1].strip(l1lll1ll11l1_cdhd_ (u"ࠩ࠿ࡂࠬ౺")) if len(l11lllll11ll11l1_cdhd_)>2 else l1lll1ll11l1_cdhd_ (u"ࠪࠫ౻")
            quality = l11lllll11ll11l1_cdhd_[2].strip(l1lll1ll11l1_cdhd_ (u"ࠫࡁࡄࠧ౼")) if len(l11lllll11ll11l1_cdhd_)>3 else l1lll1ll11l1_cdhd_ (u"ࠬ࠭౽")
            href = re.compile(l1lll1ll11l1_cdhd_ (u"࠭ࠧࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧࠨࠩ౾")).findall(l11lllll11ll11l1_cdhd_[3])if len(l11lllll11ll11l1_cdhd_)>4 else l1lll1ll11l1_cdhd_ (u"ࠧࠨ౿")
            if href:
                href=href[0]
                href = urllib.unquote(_1l1111l11ll11l1_cdhd_(href))
                if l1lll1ll11l1_cdhd_ (u"ࠨ࡮࡬ࡲࡰ࡯࠮ࡰࡰ࡯࡭ࡳ࡫ࠧಀ") in href:
                    data = l1lll1l111ll11l1_cdhd_(href)
                    l1ll1111l1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠩࠪࠫࡁ࡯ࡦࡳࡣࡰࡩ࠭࠴ࠪࡀࠫ࠿࠳࡮࡬ࡲࡢ࡯ࡨࡂࠬ࠭ࠧಁ"),re.DOTALL).findall(data)
                    if l1ll1111l1ll11l1_cdhd_:
                        src = re.compile(l1lll1ll11l1_cdhd_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨಂ")).findall(l1ll1111l1ll11l1_cdhd_[0])
                        href = src[0] if src else href
                href = urllib.unquote(_1l1111l11ll11l1_cdhd_(href))
                host = host[0] if host else l1lll1ll11l1_cdhd_ (u"ࠫࠬಃ")
                l1l1111111ll11l1_cdhd_ = urlparse(href).netloc
                l111l1111ll11l1_cdhd_ = {l1lll1ll11l1_cdhd_ (u"ࠬࡻࡲ࡭ࠩ಄") : urllib.unquote(href),
                    l1lll1ll11l1_cdhd_ (u"࠭ࡴࡪࡶ࡯ࡩࠬಅ"): l1lll1ll11l1_cdhd_ (u"ࠢ࡜ࠧࡶࡡࠥࠫࡳ࠭ࠢࠨࡷࠧಆ") %(host,version,quality),
                    l1lll1ll11l1_cdhd_ (u"ࠨࡪࡲࡷࡹ࠭ಇ"): host }
                out.append(l111l1111ll11l1_cdhd_)
    return out
def l1111l11ll11l1_cdhd_(url):
    content = l1lll1l111ll11l1_cdhd_(url)
    l1l11l1ll1ll11l1_cdhd_ = l1llll1111ll11l1_cdhd_.l1ll1l1ll1ll11l1_cdhd_(l11lll1ll11l1_cdhd_)
    l1l11111l1ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠤࡿࡇࡴࡵ࡫ࡪࡧࡀࠩࡸࠬࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࠩࡸࠨಈ") % (l1l11l1ll1ll11l1_cdhd_, l1ll11l1l1ll11l1_cdhd_)
    l1l11ll111ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠪࠫࠬࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࠩࠪಉ")).findall(content)
    l1llll1l11ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠫࠬಊ")
    for l1l111lll1ll11l1_cdhd_ in l1l11ll111ll11l1_cdhd_:
        if l1lll1ll11l1_cdhd_ (u"ࠬ࠴ࡪࡱࡩࠪಋ") in l1l111lll1ll11l1_cdhd_:
            l1llll1l11ll11l1_cdhd_ = _1l1111l11ll11l1_cdhd_(l1l111lll1ll11l1_cdhd_)
            break
    l1llll1l11ll11l1_cdhd_ = l1llll1l11ll11l1_cdhd_ + l1l11111l1ll11l1_cdhd_
    ids = [(a.start(), a.end()) for a in re.finditer(l1lll1ll11l1_cdhd_ (u"࠭ࠧࠨ࠾ࡧ࡭ࡻࠦࡩࡥ࠿ࠥࡷࡪࡧࡳࡰࡰ࠰ࡠࡩ࠱ࠧࠨࠩಌ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11l11111ll11l1_cdhd_ = content[ ids[i][1]:ids[i+1][0] ]
        l1l11lll11ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠧࠨࠩ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡥࡀ࡟ࡷ࠯ࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡨࡃࡢࡳࠫ࠾ࡷࡨࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧࠨࠩ಍"),re.DOTALL).findall(l11l11111ll11l1_cdhd_)
        for l1l11l11l1ll11l1_cdhd_,title,href in l1l11lll11ll11l1_cdhd_:
            title = title.replace(l1lll1ll11l1_cdhd_ (u"ࠨ࡞ࡱࠫಎ"),l1lll1ll11l1_cdhd_ (u"ࠩࠣࠫಏ"))
            title = re.sub(l1lll1ll11l1_cdhd_ (u"ࡵࠫࠬ࠭ࠦ࠯ࠬ࠾ࠫࠬ࠭ಐ"),l1lll1ll11l1_cdhd_ (u"ࠫࠬ಑"),title)
            l1ll111ll1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠬ࠭ࠧࡴࠪ࡟ࡨ࠰ࡅࠩࡦࠪ࡟ࡨ࠰ࡅࠩࠨࠩࠪಒ")).findall(l1l11l11l1ll11l1_cdhd_)
            if l1lll1ll11l1_cdhd_ (u"࠭ࡳࡦࡴ࡬ࡥࡱ࡫ࠧಓ") in href:
                l111l1111ll11l1_cdhd_ = {l1lll1ll11l1_cdhd_ (u"ࠧࡩࡴࡨࡪࠬಔ")  : _1l1111l11ll11l1_cdhd_(href),
                    l1lll1ll11l1_cdhd_ (u"ࠨࡲ࡯ࡳࡹ࠭ಕ"): l1lll1ll11l1_cdhd_ (u"ࠩࠪಖ"),
                    l1lll1ll11l1_cdhd_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩಗ") : l1lll1ll11l1_cdhd_ (u"ࠫࠪࡹࠠࠦࡵࠪಘ")%(l1l11l11l1ll11l1_cdhd_,l1llll11l1ll11l1_cdhd_(title.strip())),
                    l1lll1ll11l1_cdhd_ (u"ࠬ࡯࡭ࡨࠩಙ"):l1llll1l11ll11l1_cdhd_,
                    l1lll1ll11l1_cdhd_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭ಚ"): int(l1ll111ll1ll11l1_cdhd_[0][0]) if l1ll111ll1ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠧࠨಛ"),
                    l1lll1ll11l1_cdhd_ (u"ࠨࡧࡳ࡭ࡸࡵࡤࡦࠩಜ"): int(l1ll111ll1ll11l1_cdhd_[0][1]) if l1ll111ll1ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠩࠪಝ"),
                    }
                out.append(l111l1111ll11l1_cdhd_)
    return out
def l11111l11ll11l1_cdhd_(m):
    return l1lll1ll11l1_cdhd_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠪಞ")+urllib.unquote(m.group(1))
def l1l11lll1ll11l1_cdhd_(l1l11l111ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠫ࡫࡯࡬࡮ࠩಟ"),l11lll1l1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧಠ")):
    content = l1lll1l111ll11l1_cdhd_(l1lll1ll11l1_cdhd_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤࡦࡤࡼ࠳ࡺࡶ࠰ࡨ࡬ࡰࡲࡿ࠭ࡰࡰ࡯࡭ࡳ࡫࠯ࠨಡ"))
    selected = []
    if l1l11l111ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"ࠧࡧ࡫࡯ࡱࠬಢ"):
        if l11lll1l1ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪಣ"):
            l11l11111ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠩࠪࠫࡁࡻ࡬ࠡ࡫ࡧࡁࠧ࡬ࡩ࡭ࡶࡨࡶ࠲ࡩࡡࡵࡧࡪࡳࡷࡿࠢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡨ࡬ࡰࡹ࡫ࡲࠡ࡯ࡸࡰࡹ࡯ࡰ࡭ࡧ࠰ࡷࡪࡲࡥࡤࡶࠣࡸࡪࡸ࡭࠮࡮࡬ࡷࡹࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫࠬ࠭ತ"),re.DOTALL).findall(content)[0]
            selected = re.compile(l1lll1ll11l1_cdhd_ (u"ࠪࠫࠬࡂ࡬ࡪࠢࡧࡥࡹࡧ࠭ࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥ࡟ࡣࡄ࡝ࠫࡀ࡟ࡷ࠯ࡂࡡࠡࡪࡵࡩ࡫ࡃࠢ࠯ࠬࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࠼࠰࡮࡬ࡂࠬ࠭ࠧಥ"),re.MULTILINE).findall(l11l11111ll11l1_cdhd_)
        elif l11lll1l1ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"ࠫࡾ࡫ࡡࡳࠩದ"):
            l11l11111ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠬ࠭ࠧ࠽ࡷ࡯ࠤ࡮ࡪ࠽ࠣࡨ࡬ࡰࡹ࡫ࡲ࠮ࡻࡨࡥࡷࠨࠠࡤ࡮ࡤࡷࡸࡃࠢࡧ࡫࡯ࡸࡪࡸࠠ࡮ࡷ࡯ࡸ࡮ࡶ࡬ࡦ࠯ࡶࡩࡱ࡫ࡣࡵࠢࡷࡩࡷࡳ࠭࡭࡫ࡶࡸࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪࠫࠬಧ"),re.DOTALL).findall(content)[0]
            selected = re.compile(l1lll1ll11l1_cdhd_ (u"࠭ࠧࠨ࠾࡯࡭ࠥࡪࡡࡵࡣ࠰࡭ࡩࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࡛࡟ࡀࡠ࠮ࡃࡢࡳࠫ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥ࠲࠯ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀ࠿࠳ࡱ࡯࠾ࠨࠩࠪನ"),re.MULTILINE).findall(l11l11111ll11l1_cdhd_)
        elif l11lll1l1ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"ࠧࡤࡱࡸࡲࡹࡸࡹࠨ಩"):
            l11l11111ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠨࠩࠪࡀࡺࡲࠠࡪࡦࡀࠦ࡫࡯࡬ࡵࡧࡵ࠱ࡨࡵࡵ࡯ࡶࡵࡽࠧࠦࡣ࡭ࡣࡶࡷࡂࠨࡦࡪ࡮ࡷࡩࡷࠦ࡭ࡶ࡮ࡷ࡭ࡵࡲࡥ࠮ࡵࡨࡰࡪࡩࡴࠡࡶࡨࡶࡲ࠳࡬ࡪࡵࡷࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩࠪࠫಪ"),re.DOTALL).findall(content)[0]
            selected = re.compile(l1lll1ll11l1_cdhd_ (u"ࠩࠪࠫࡁࡲࡩࠡࡦࡤࡸࡦ࠳ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࡞ࡢࡃࡣࠪ࠿࡞ࡶ࠮ࡁࡧࠠࡩࡴࡨࡪࡂࠨ࠮ࠫࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃࡂ࠯࡭࡫ࡁࠫࠬ࠭ಫ"),re.MULTILINE).findall(l11l11111ll11l1_cdhd_)
    elif l1l11l111ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"ࠪࡷࡪࡸࡩࡢ࡮ࠪಬ"):
        if l11lll1l1ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"ࠫ࡬ࡧࡴࡶࡰࡨ࡯ࠬಭ"):
            selected = re.compile(l1lll1ll11l1_cdhd_ (u"ࠬ࠭ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࡜ࡵࡠ࠾࠴࠵ࡣࡥࡣ࠰ࡳࡳࡲࡩ࡯ࡧ࠱ࡴࡱ࠵ࡳࡦࡴ࡬ࡥࡱ࡫࠭ࡨࡣࡷࡹࡳ࡫࡫࠰࠰࠭ࡃ࠮ࠨ࡛࡝ࡶ࡟ࡲࠥࡣࠪ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫࠬ࠭ಮ")).findall(content)
        elif l11lll1l1ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"࠭ࡲࡰ࡭ࠪಯ"):
            selected = re.compile(l1lll1ll11l1_cdhd_ (u"ࠧࠨࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࡞ࡷࡢࡀ࠯࠰ࡥࡧࡥ࠲ࡵ࡮࡭࡫ࡱࡩ࠳ࡶ࡬࠰ࡵࡨࡶ࡮ࡧ࡬ࡦ࠯ࡵࡳࡰ࠵࡜ࡥࡽ࠷ࢁ࠴࠯ࠢ࠿ࠪ࡟ࡨࢀ࠺ࡽࠪ࠾࠲ࡥࡃ࠭ࠧࠨರ")).findall(content)
    if selected:
        l1lll1ll11ll11l1_cdhd_ = [x[0] for x in selected]
        l1ll11l111ll11l1_cdhd_ = [l1lll1ll11l1_cdhd_ (u"ࠨࠢࠪಱ").join(x[1:]) for x in selected]
        return (l1ll11l111ll11l1_cdhd_,l1lll1ll11ll11l1_cdhd_)
    return False
def search(l11111111ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠩࡤ࡯ࡦࡪࡥ࡮࡫ࡤࠤࡵࡧ࡮ࡢࠩಲ")):
    url=l1lll1ll11l1_cdhd_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨࡪࡡࡹ࠰ࡷࡺ࠴ࡹࡺࡶ࡭ࡤ࡮ࠬಳ")
    content = l1lll1l111ll11l1_cdhd_(url,data=l1lll1ll11l1_cdhd_ (u"ࠫࡵ࡮ࡲࡢࡵࡨࡁࠬ಴")+l11111111ll11l1_cdhd_)
    l1l11l1ll1ll11l1_cdhd_ = l1llll1111ll11l1_cdhd_.l1ll1l1ll1ll11l1_cdhd_(l11lll1ll11l1_cdhd_)
    l1l11111l1ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠧࢂࡃࡰࡱ࡮࡭ࡪࡃࠥࡴࠨࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࡃࠥࡴࠤವ") % (l1l11l1ll1ll11l1_cdhd_, l1ll11l1l1ll11l1_cdhd_)
    ids = [(a.start(), a.end()) for a in re.finditer(l1lll1ll11l1_cdhd_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡬࠮ࡺࡶ࠱ࡡࡪࡻ࠲ࡿ࡞ࡢࠧࡣࠪࠣࡀࠪಶ"), content)]
    ids.append( (-1,-1) )
    l1lll1lll1ll11l1_cdhd_=[]
    l1llll1ll1ll11l1_cdhd_=[]
    for i in range(len(ids[:-1])):
        l11l11111ll11l1_cdhd_ = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile(l1lll1ll11l1_cdhd_ (u"ࠧࠨࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࠩࠪಷ")).search(l11l11111ll11l1_cdhd_)
        title = re.compile(l1lll1ll11l1_cdhd_ (u"ࠨࠩࠪࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪࠫࠬಸ"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
        l1lllll1l1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠩࠪࠫࡩࡧࡴࡢ࠯ࡦࡳࡳࡺࡥ࡯ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫࠬ࠭ಹ")).search(l11l11111ll11l1_cdhd_)
        l1llll1l11ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠪࠫࠬࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࠩࠪ಺")).search(l11l11111ll11l1_cdhd_)
        year =  re.compile(l1lll1ll11l1_cdhd_ (u"ࠫࠬ࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡾ࡫ࡡࡳࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪࠫࠬ಻")).search(l11l11111ll11l1_cdhd_)
        l1l111ll11ll11l1_cdhd_ =  re.compile(l1lll1ll11l1_cdhd_ (u"ࠬ࠭ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡸࡡࡵࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿಼ࠫࠬ࠭")).search(l11l11111ll11l1_cdhd_)
        if href and title:
            l1llll1l11ll11l1_cdhd_ = l1llll1l11ll11l1_cdhd_.group(1) if l1llll1l11ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"࠭ࠧಽ")
            l1llll1l11ll11l1_cdhd_ = l1llll1l11ll11l1_cdhd_ + l1l11111l1ll11l1_cdhd_
            l111l1111ll11l1_cdhd_ = {l1lll1ll11l1_cdhd_ (u"ࠧࡩࡴࡨࡪࠬಾ")   : href.group(1),
                l1lll1ll11l1_cdhd_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧಿ")  : l1llll11l1ll11l1_cdhd_(title.group(1)),
                l1lll1ll11l1_cdhd_ (u"ࠩࡳࡰࡴࡺࠧೀ")   : l1llll11l1ll11l1_cdhd_(l1lllll1l1ll11l1_cdhd_.group(1)) if l1lllll1l1ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠪࠫು"),
                l1lll1ll11l1_cdhd_ (u"ࠫ࡮ࡳࡧࠨೂ")    : l1llll1l11ll11l1_cdhd_,
                l1lll1ll11l1_cdhd_ (u"ࠬࡸࡡࡵ࡫ࡱ࡫ࠬೃ") : l1l111ll11ll11l1_cdhd_.group(1) if l1l111ll11ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"࠭ࠧೄ"),
                l1lll1ll11l1_cdhd_ (u"ࠧࡺࡧࡤࡶࠬ೅")   : year.group(1) if year else l1lll1ll11l1_cdhd_ (u"ࠨࠩೆ"),
                    }
            if l1lll1ll11l1_cdhd_ (u"ࠩ࠲ࡷࡪࡸࡩࡢ࡮ࡨ࠳ࠬೇ") in l111l1111ll11l1_cdhd_[l1lll1ll11l1_cdhd_ (u"ࠪ࡬ࡷ࡫ࡦࠨೈ")]:
                l1llll1ll1ll11l1_cdhd_.append(l111l1111ll11l1_cdhd_)
            else:
                l1lll1lll1ll11l1_cdhd_.append(l111l1111ll11l1_cdhd_)
    return l1lll1lll1ll11l1_cdhd_,l1llll1ll1ll11l1_cdhd_
def search(l11111111ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠫࡩࡵ࡬ࡪࡰࡤࠫ೉")):
    l111ll111ll11l1_cdhd_ = {
        l1lll1ll11l1_cdhd_ (u"ࠬࡎ࡯ࡴࡶࠪೊ"):l1lll1ll11l1_cdhd_ (u"࠭ࡡࡱ࡫࠱ࡷࡪࡧࡲࡤࡪ࡬ࡵ࠳ࡾࡹࡻࠩೋ"),
        l1lll1ll11l1_cdhd_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫೌ"):l1lll1ll11l1_cdhd_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠻࠴࠱࠼࡚ࠢࡓ࡜࠼࠴࠼ࠢࡵࡺ࠿࠻࠲࠯࠲ࠬࠤࡌ࡫ࡣ࡬ࡱ࠲࠶࠵࠷࠰࠱࠳࠳࠵ࠥࡌࡩࡳࡧࡩࡳࡽ࠵࠵࠳࠰࠳್ࠫ"),
        l1lll1ll11l1_cdhd_ (u"ࠩࡄࡧࡨ࡫ࡰࡵࠩ೎"):l1lll1ll11l1_cdhd_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰࡬ࡶࡳࡳ࠲ࠠࡵࡧࡻࡸ࠴ࡰࡡࡷࡣࡶࡧࡷ࡯ࡰࡵ࠮ࠣ࠮࠴࠰࠻ࠡࡳࡀ࠴࠳࠶࠱ࠨ೏"),
        l1lll1ll11l1_cdhd_ (u"ࠫࡆࡩࡣࡦࡲࡷ࠱ࡑࡧ࡮ࡨࡷࡤ࡫ࡪ࠭೐"):l1lll1ll11l1_cdhd_ (u"ࠬ࡫࡮࠮ࡗࡖ࠰ࡪࡴ࠻ࡲ࠿࠳࠲࠺࠭೑"),
        l1lll1ll11l1_cdhd_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ೒"):l1lll1ll11l1_cdhd_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥࡧࡥࡽ࠴ࡴࡷ࠱ࡺࡽࡸࢀࡵ࡬࡫ࡺࡥࡷࡱࡡࡀࡲ࡫ࡶࡦࡹࡥ࠾ࡦࡲࡱࠬ೓"),
        l1lll1ll11l1_cdhd_ (u"ࠨࡑࡵ࡭࡬࡯࡮ࠨ೔"):l1lll1ll11l1_cdhd_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡧࡩࡧࡸ࠯ࡶࡹࠫೕ"),
        l1lll1ll11l1_cdhd_ (u"ࠪࡇࡴࡴ࡮ࡦࡥࡷ࡭ࡴࡴࠧೖ"):l1lll1ll11l1_cdhd_ (u"ࠫࡰ࡫ࡥࡱ࠯ࡤࡰ࡮ࡼࡥࠨ೗"),
        l1lll1ll11l1_cdhd_ (u"ࠬࡖࡲࡢࡩࡰࡥࠬ೘"):l1lll1ll11l1_cdhd_ (u"࠭࡮ࡰ࠯ࡦࡥࡨ࡮ࡥࠨ೙")}
    url=l1lll1ll11l1_cdhd_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡣࡳ࡭࠳ࡹࡥࡢࡴࡦ࡬࡮ࡷ࠮ࡹࡻࡽ࠳ࡦࡶࡩ࠰ࡵࡨࡥࡷࡩࡨ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡴࡁࠪࡹࠦࡦࡰࡪ࡭ࡳ࡫ࡋࡦࡻࡀ࠷࠽࠻ࡣ࠱࠲ࡤࡪ࠶࠶࠶࠸࠸ࡤ࠷࠺࠽࠲ࡥ࠺࠻࠴࠺࠻ࡥ࠴࠴ࡦ࠸࠶ࡩ࠴ࠧࡲࡤ࡫ࡪࡃ࠰ࠧ࡫ࡷࡩࡲࡹࡐࡦࡴࡓࡥ࡬࡫࠽࠶࠲ࠩ࡫ࡷࡵࡵࡱ࠿࠴ࠫ೚")
    try:
        req = urllib2.Request(url%l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠨࠢࠪ೛"),l1lll1ll11l1_cdhd_ (u"ࠩ࠮ࠫ೜")),data=None,headers=l111ll111ll11l1_cdhd_)
        response = urllib2.urlopen(req,timeout=10)
        dd = json.loads(response.read())
    except:
        dd={}
    data = dd.get(l1lll1ll11l1_cdhd_ (u"ࠪࡱࡦ࡯࡮ࠨೝ"),{}).get(l1lll1ll11l1_cdhd_ (u"ࠫࡷ࡫ࡣࡰࡴࡧࡷࠬೞ"),[])
    l1lll1lll1ll11l1_cdhd_=[]
    l1llll1ll1ll11l1_cdhd_=[]
    for item in data:
        href = item.get(l1lll1ll11l1_cdhd_ (u"ࠬࡻࡲ࡭ࠩ೟"),l1lll1ll11l1_cdhd_ (u"࠭ࠧೠ"))
        title = item.get(l1lll1ll11l1_cdhd_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ೡ"),l1lll1ll11l1_cdhd_ (u"ࠨࠩೢ"))
        title = re.sub(l1lll1ll11l1_cdhd_ (u"ࡴࠪࠫࠬࡂ࡛࠰࡟࠭ࡩࡲࡄࠧࠨࠩೣ"),l1lll1ll11l1_cdhd_ (u"ࠪࠤࠬ೤"),title)
        l1lllll1l1ll11l1_cdhd_ = item.get(l1lll1ll11l1_cdhd_ (u"ࠫࡧࡵࡤࡺࠩ೥"),l1lll1ll11l1_cdhd_ (u"ࠬ࠭೦"))
        if href and title:
            year = re.search(l1lll1ll11l1_cdhd_ (u"࠭࡜ࡥࡽ࠷ࢁࠬ೧"),title)
        l111l1111ll11l1_cdhd_ = {l1lll1ll11l1_cdhd_ (u"ࠧࡩࡴࡨࡪࠬ೨") : href,
            l1lll1ll11l1_cdhd_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ೩") : l1llll11l1ll11l1_cdhd_(title),
            l1lll1ll11l1_cdhd_ (u"ࠩࡳࡰࡴࡺࠧ೪") : l1llll11l1ll11l1_cdhd_(l1lllll1l1ll11l1_cdhd_) if l1lllll1l1ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠪࠫ೫"),
            l1lll1ll11l1_cdhd_ (u"ࠫ࡮ࡳࡧࠨ೬") : l1lll1ll11l1_cdhd_ (u"ࠬ࠭೭"),
            l1lll1ll11l1_cdhd_ (u"࠭ࡹࡦࡣࡵࠫ೮") : year.group() if year else l1lll1ll11l1_cdhd_ (u"ࠧࠨ೯"),
                }
        if l1lll1ll11l1_cdhd_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡡ࡭ࡧ࠲ࠫ೰") in l111l1111ll11l1_cdhd_[l1lll1ll11l1_cdhd_ (u"ࠩ࡫ࡶࡪ࡬ࠧೱ")]:
            l1llll1ll1ll11l1_cdhd_.append(l111l1111ll11l1_cdhd_)
        else:
            l1lll1lll1ll11l1_cdhd_.append(l111l1111ll11l1_cdhd_)
    return l1lll1lll1ll11l1_cdhd_,l1llll1ll1ll11l1_cdhd_
def l1llll11l1ll11l1_cdhd_(l11111111ll11l1_cdhd_):
    return l11111111ll11l1_cdhd_
