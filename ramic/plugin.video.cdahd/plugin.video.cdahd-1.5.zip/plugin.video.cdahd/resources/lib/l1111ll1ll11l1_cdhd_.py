# -*- coding: utf-8 -*-
import sys
l1ll11ll11l1_cdhd_ = sys.version_info [0] == 2
l11ll1ll11l1_cdhd_ = 2048
l1111ll11l1_cdhd_ = 7
def l1lll1ll11l1_cdhd_ (keyedStringLiteral):
	global l1l111ll11l1_cdhd_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll11l1_cdhd_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
l1lll1ll11l1_cdhd_ (u"ࠨࠢࠣࠏࠍࡇࡷ࡫ࡡࡵࡧࡧࠤࡴࡴࠠࡕࡪࡸࠤࡋ࡫ࡢࠡ࠳࠴ࠤ࠶࠾࠺࠵࠹࠽࠸࠸ࠦ࠲࠱࠳࠹ࠑࠏࠓࠊࡁࡣࡸࡸ࡭ࡵࡲ࠻ࠢࡵࡥࡲ࡯ࡣࠎࠌࠥࠦࠧ୴")
import urllib2
import re
import l1l1llll11ll11l1_cdhd_ as l1l1llll11ll11l1_cdhd_
l1ll11lll1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡨࡪࡡ࠯ࡲ࡯ࠫ୵")
l111ll1l1ll11l1_cdhd_ = 5
def l1lll1l111ll11l1_cdhd_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l1lll1ll11l1_cdhd_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ୶"), l1lll1ll11l1_cdhd_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠶࠻࠲࠵࠴࠲࠶࠸࠷࠲࠾࠽ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧ୷"))
    if cookies:
        req.add_header(l1lll1ll11l1_cdhd_ (u"ࠥࡇࡴࡵ࡫ࡪࡧࠥ୸"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l111ll1l1ll11l1_cdhd_)
        l1ll1l111ll11l1_cdhd_ =  response.read()
        response.close()
    except:
        l1ll1l111ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠫࠬ୹")
    return l1ll1l111ll11l1_cdhd_
def _1ll111111ll11l1_cdhd_(content):
    src =l1lll1ll11l1_cdhd_ (u"ࠬ࠭୺")
    l1l1ll1111ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠨࡥࡷࡣ࡯ࠬ࠳࠰࠿ࠪ࡞ࡾࡠࢂࡢࠩ࡝ࠫࠥ୻"),re.DOTALL).findall(content)
    for l1l1l1lll1ll11l1_cdhd_ in l1l1ll1111ll11l1_cdhd_:
        l1l1l1lll1ll11l1_cdhd_=re.sub(l1lll1ll11l1_cdhd_ (u"ࠧࠡࠢࠪ୼"),l1lll1ll11l1_cdhd_ (u"ࠨࠢࠪ୽"),l1l1l1lll1ll11l1_cdhd_)
        l1l1l1lll1ll11l1_cdhd_=re.sub(l1lll1ll11l1_cdhd_ (u"ࠩ࡟ࡲࠬ୾"),l1lll1ll11l1_cdhd_ (u"ࠪࠫ୿"),l1l1l1lll1ll11l1_cdhd_)
        try:
            l1l1lll111ll11l1_cdhd_ = l1l1llll11ll11l1_cdhd_.unpack(l1l1l1lll1ll11l1_cdhd_)
        except:
            l1l1lll111ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠫࠬ஀")
        if l1l1lll111ll11l1_cdhd_:
            l1l1lll111ll11l1_cdhd_=re.sub(l1lll1ll11l1_cdhd_ (u"ࡷ࠭࡜࡝ࠩ஁"),l1lll1ll11l1_cdhd_ (u"ࡸࠧࠨஂ"),l1l1lll111ll11l1_cdhd_)
            l1l1ll11l1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠧࡧ࡫࡯ࡩ࠿ࡢࡳࠫ࡝࡟ࠫࠧࡣࠨ࠯࠭ࡂ࠭ࡠࡢࠧࠣ࡟࠯ࠫஃ"),  re.DOTALL).search(l1l1lll111ll11l1_cdhd_)
            l1l1ll1ll1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠨࡷࡵࡰ࠿ࡢࡳࠫ࡝࡟ࠫࠧࡣࠨ࠯࠭ࡂ࠭ࡠࡢࠧࠣ࡟࠯ࠫ஄"),  re.DOTALL).search(l1l1lll111ll11l1_cdhd_)
            if l1l1ll11l1ll11l1_cdhd_:
                src = l1l1ll11l1ll11l1_cdhd_.group(1)
            elif l1l1ll1ll1ll11l1_cdhd_:
                src = l1l1ll1ll1ll11l1_cdhd_.group(1)
            if src:
                break
    return src
def _1l1ll1l11ll11l1_cdhd_(content):
    src=l1lll1ll11l1_cdhd_ (u"ࠩࠪஅ")
    l1l1l111l1ll11l1_cdhd_ = content.find(l1lll1ll11l1_cdhd_ (u"ࠪࢀࢁࢂࡨࡵࡶࡳࠫஆ"))
    if l1l1l111l1ll11l1_cdhd_>0:
        l1l1l11ll1ll11l1_cdhd_ = content.find(l1lll1ll11l1_cdhd_ (u"ࠫ࠳ࡹࡰ࡭࡫ࡷࠫஇ"),l1l1l111l1ll11l1_cdhd_)
        encoded =content[l1l1l111l1ll11l1_cdhd_:l1l1l11ll1ll11l1_cdhd_]
        if encoded:
            l1llllll11ll11l1_cdhd_ = encoded.split(l1lll1ll11l1_cdhd_ (u"ࠬࡶ࡬ࡢࡻࡨࡶࠬஈ"))[0]
            l1llllll11ll11l1_cdhd_=re.sub(l1lll1ll11l1_cdhd_ (u"ࡸࠧ࡜ࡾࡠ࠯ࡡࡽࡻ࠳࠮࠶ࢁࡠࢂ࡝ࠬࠩஉ"),l1lll1ll11l1_cdhd_ (u"ࠧࡽࠩஊ"),l1llllll11ll11l1_cdhd_,re.DOTALL)
            l1llllll11ll11l1_cdhd_=re.sub(l1lll1ll11l1_cdhd_ (u"ࡳࠩ࡞ࢀࡢ࠱࡜ࡸࡽ࠵࠰࠸ࢃ࡛ࡽ࡟࠮ࠫ஋"),l1lll1ll11l1_cdhd_ (u"ࠩࡿࠫ஌"),l1llllll11ll11l1_cdhd_,re.DOTALL)
            l1l11llll1ll11l1_cdhd_=[l1lll1ll11l1_cdhd_ (u"ࠪ࡬ࡹࡺࡰࠨ஍"),l1lll1ll11l1_cdhd_ (u"ࠫࡨࡪࡡࠨஎ"),l1lll1ll11l1_cdhd_ (u"ࠬࡶ࡬ࠨஏ"),l1lll1ll11l1_cdhd_ (u"࠭࡬ࡰࡩࡲࠫஐ"),l1lll1ll11l1_cdhd_ (u"ࠧࡸ࡫ࡧࡸ࡭࠭஑"),l1lll1ll11l1_cdhd_ (u"ࠨࡪࡨ࡭࡬࡮ࡴࠨஒ"),l1lll1ll11l1_cdhd_ (u"ࠩࡷࡶࡺ࡫ࠧஓ"),l1lll1ll11l1_cdhd_ (u"ࠪࡷࡹࡧࡴࡪࡥࠪஔ"),l1lll1ll11l1_cdhd_ (u"ࠫࡸࡺࠧக"),l1lll1ll11l1_cdhd_ (u"ࠬࡳࡰ࠵ࠩ஖"),l1lll1ll11l1_cdhd_ (u"࠭ࡦࡢ࡮ࡶࡩࠬ஗"),l1lll1ll11l1_cdhd_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭஘"),l1lll1ll11l1_cdhd_ (u"ࠨࡵࡷࡥࡹ࡯ࡣࠨங"),
                    l1lll1ll11l1_cdhd_ (u"ࠩࡷࡽࡵ࡫ࠧச"),l1lll1ll11l1_cdhd_ (u"ࠪࡷࡼ࡬ࠧ஛"),l1lll1ll11l1_cdhd_ (u"ࠫࡵࡲࡡࡺࡧࡵࠫஜ"),l1lll1ll11l1_cdhd_ (u"ࠬ࡬ࡩ࡭ࡧࠪ஝"),l1lll1ll11l1_cdhd_ (u"࠭ࡣࡰࡰࡷࡶࡴࡲࡢࡢࡴࠪஞ"),l1lll1ll11l1_cdhd_ (u"ࠧࡢࡦࡶࠫட"),l1lll1ll11l1_cdhd_ (u"ࠨࡥࡽࡥࡸ࠭஠"),l1lll1ll11l1_cdhd_ (u"ࠩࡳࡳࡸ࡯ࡴࡪࡱࡱࠫ஡"),l1lll1ll11l1_cdhd_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬ஢"),l1lll1ll11l1_cdhd_ (u"ࠫࡧࡵࡴࡵࡱࡰࠫண"),l1lll1ll11l1_cdhd_ (u"ࠬࡻࡳࡦࡴࡄ࡫ࡪࡴࡴࠨத"),
                    l1lll1ll11l1_cdhd_ (u"࠭࡭ࡢࡶࡦ࡬ࠬ஥"),l1lll1ll11l1_cdhd_ (u"ࠧࡱࡰࡪࠫ஦"),l1lll1ll11l1_cdhd_ (u"ࠨࡰࡤࡺ࡮࡭ࡡࡵࡱࡵࠫ஧"),l1lll1ll11l1_cdhd_ (u"ࠩ࡬ࡨࠬந"), l1lll1ll11l1_cdhd_ (u"ࠪ࠷࠼࠭ன"), l1lll1ll11l1_cdhd_ (u"ࠫࡷ࡫ࡧࡪࡱࡱࡷࠬப"), l1lll1ll11l1_cdhd_ (u"ࠬ࠶࠹ࠨ஫"), l1lll1ll11l1_cdhd_ (u"࠭ࡥ࡯ࡣࡥࡰࡪࡪࠧ஬"), l1lll1ll11l1_cdhd_ (u"ࠧࡴࡴࡦࠫ஭"), l1lll1ll11l1_cdhd_ (u"ࠨ࡯ࡨࡨ࡮ࡧࠧம")]
            l1l11llll1ll11l1_cdhd_=[l1lll1ll11l1_cdhd_ (u"ࠩ࡫ࡸࡹࡶࠧய"), l1lll1ll11l1_cdhd_ (u"ࠪࡰࡴ࡭࡯ࠨர"), l1lll1ll11l1_cdhd_ (u"ࠫࡼ࡯ࡤࡵࡪࠪற"), l1lll1ll11l1_cdhd_ (u"ࠬ࡮ࡥࡪࡩ࡫ࡸࠬல"), l1lll1ll11l1_cdhd_ (u"࠭ࡴࡳࡷࡨࠫள"), l1lll1ll11l1_cdhd_ (u"ࠧࡴࡶࡤࡸ࡮ࡩࠧழ"), l1lll1ll11l1_cdhd_ (u"ࠨࡨࡤࡰࡸ࡫ࠧவ"), l1lll1ll11l1_cdhd_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨஶ"), l1lll1ll11l1_cdhd_ (u"ࠪࡴࡱࡧࡹࡦࡴࠪஷ"),
                l1lll1ll11l1_cdhd_ (u"ࠫ࡫࡯࡬ࡦࠩஸ"), l1lll1ll11l1_cdhd_ (u"ࠬࡺࡹࡱࡧࠪஹ"), l1lll1ll11l1_cdhd_ (u"࠭ࡲࡦࡩ࡬ࡳࡳࡹࠧ஺"), l1lll1ll11l1_cdhd_ (u"ࠧ࡯ࡱࡱࡩࠬ஻"), l1lll1ll11l1_cdhd_ (u"ࠨࡥࡽࡥࡸ࠭஼"), l1lll1ll11l1_cdhd_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࡦࠪ஽"), l1lll1ll11l1_cdhd_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬா"), l1lll1ll11l1_cdhd_ (u"ࠫࡨࡵ࡮ࡵࡴࡲࡰࡧࡧࡲࠨி"), l1lll1ll11l1_cdhd_ (u"ࠬࡳࡡࡵࡥ࡫ࠫீ"), l1lll1ll11l1_cdhd_ (u"࠭ࡢࡰࡶࡷࡳࡲ࠭ு"),
                l1lll1ll11l1_cdhd_ (u"ࠧࡤࡧࡱࡸࡪࡸࠧூ"), l1lll1ll11l1_cdhd_ (u"ࠨࡲࡲࡷ࡮ࡺࡩࡰࡰࠪ௃"), l1lll1ll11l1_cdhd_ (u"ࠩࡸࡷࡪࡸࡁࡨࡧࡱࡸࠬ௄"), l1lll1ll11l1_cdhd_ (u"ࠪࡲࡦࡼࡩࡨࡣࡷࡳࡷ࠭௅"), l1lll1ll11l1_cdhd_ (u"ࠫࡨࡵ࡮ࡧ࡫ࡪࠫெ"), l1lll1ll11l1_cdhd_ (u"ࠬ࡮ࡴ࡮࡮ࠪே"), l1lll1ll11l1_cdhd_ (u"࠭ࡨࡵ࡯࡯࠹ࠬை"), l1lll1ll11l1_cdhd_ (u"ࠧࡱࡴࡲࡺ࡮ࡪࡥࡳࠩ௉"), l1lll1ll11l1_cdhd_ (u"ࠨࡤ࡯ࡥࡨࡱࠧொ"),
                l1lll1ll11l1_cdhd_ (u"ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡇ࡬ࡪࡩࡱࠫோ"), l1lll1ll11l1_cdhd_ (u"ࠪࡧࡦࡴࡆࡪࡴࡨࡉࡻ࡫࡮ࡵࡃࡓࡍࡈࡧ࡬࡭ࡵࠪௌ"), l1lll1ll11l1_cdhd_ (u"ࠫࡺࡹࡥࡗ࠴ࡄࡔࡎࡉࡡ࡭࡮ࡶ்ࠫ"), l1lll1ll11l1_cdhd_ (u"ࠬࡼࡥࡳࡶ࡬ࡧࡦࡲࡁ࡭࡫ࡪࡲࠬ௎"), l1lll1ll11l1_cdhd_ (u"࠭ࡴࡪ࡯ࡨࡷࡱ࡯ࡤࡦࡴࡷࡳࡴࡲࡴࡪࡲࡳࡰࡺ࡭ࡩ࡯ࠩ௏"),
                l1lll1ll11l1_cdhd_ (u"ࠧࡰࡸࡨࡶࡱࡧࡹࡴࠩௐ"), l1lll1ll11l1_cdhd_ (u"ࠨࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨࡈࡵ࡬ࡰࡴࠪ௑"), l1lll1ll11l1_cdhd_ (u"ࠩࡰࡥࡷ࡭ࡩ࡯ࡤࡲࡸࡹࡵ࡭ࠨ௒"), l1lll1ll11l1_cdhd_ (u"ࠪࡴࡱࡻࡧࡪࡰࡶࠫ௓"), l1lll1ll11l1_cdhd_ (u"ࠫࡱ࡯࡮࡬ࠩ௔"), l1lll1ll11l1_cdhd_ (u"ࠬࡹࡴࡳࡧࡷࡧ࡭࡯࡮ࡨࠩ௕"), l1lll1ll11l1_cdhd_ (u"࠭ࡵ࡯࡫ࡩࡳࡷࡳࠧ௖"), l1lll1ll11l1_cdhd_ (u"ࠧࡴࡶࡤࡸ࡮ࡩ࠱ࠨௗ"),
                l1lll1ll11l1_cdhd_ (u"ࠨࡵࡨࡸࡺࡶࠧ௘"), l1lll1ll11l1_cdhd_ (u"ࠩ࡭ࡻࡵࡲࡡࡺࡧࡵࠫ௙"), l1lll1ll11l1_cdhd_ (u"ࠪࡧ࡭࡫ࡣ࡬ࡈ࡯ࡥࡸ࡮ࠧ௚"), l1lll1ll11l1_cdhd_ (u"ࠫࡘࡳࡡࡳࡶࡗ࡚ࠬ௛"), l1lll1ll11l1_cdhd_ (u"ࠬࡼ࠰࠱࠳ࠪ௜"), l1lll1ll11l1_cdhd_ (u"࠭ࡣࡳࡧࡰࡩࠬ௝"), l1lll1ll11l1_cdhd_ (u"ࠧࡥࡱࡦ࡯ࠬ௞"), l1lll1ll11l1_cdhd_ (u"ࠨࡣࡸࡸࡴࡹࡴࡢࡴࡷࠫ௟"), l1lll1ll11l1_cdhd_ (u"ࠩ࡬ࡨࡱ࡫ࡨࡪࡦࡨࠫ௠"), l1lll1ll11l1_cdhd_ (u"ࠪࡱࡴࡪࡥࡴࠩ௡"),
               l1lll1ll11l1_cdhd_ (u"ࠫ࡫ࡲࡡࡴࡪࠪ௢"), l1lll1ll11l1_cdhd_ (u"ࠬࡵࡶࡦࡴࠪ௣"), l1lll1ll11l1_cdhd_ (u"࠭࡬ࡦࡨࡷࠫ௤"), l1lll1ll11l1_cdhd_ (u"ࠧࡩ࡫ࡧࡩࠬ௥"), l1lll1ll11l1_cdhd_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲ࠶ࠩ௦"), l1lll1ll11l1_cdhd_ (u"ࠩ࡬ࡱࡦ࡭ࡥࠨ௧"), l1lll1ll11l1_cdhd_ (u"ࠪࡏࡑࡏࡋࡏࡋࡍࠫ௨"), l1lll1ll11l1_cdhd_ (u"ࠫࡨࡵ࡭ࡱࡣࡱ࡭ࡴࡴࡳࠨ௩"), l1lll1ll11l1_cdhd_ (u"ࠬࡸࡥࡴࡶࡲࡶࡪ࠭௪"), l1lll1ll11l1_cdhd_ (u"࠭ࡣ࡭࡫ࡦ࡯ࡘ࡯ࡧ࡯ࠩ௫"),
                l1lll1ll11l1_cdhd_ (u"ࠧࡴࡥ࡫ࡩࡩࡻ࡬ࡦࠩ௬"), l1lll1ll11l1_cdhd_ (u"ࠨࡡࡦࡳࡺࡴࡴࡥࡱࡺࡲࡤ࠭௭"), l1lll1ll11l1_cdhd_ (u"ࠩࡦࡳࡺࡴࡴࡥࡱࡺࡲࠬ௮"), l1lll1ll11l1_cdhd_ (u"ࠪࡶࡪ࡭ࡩࡰࡰࠪ௯"), l1lll1ll11l1_cdhd_ (u"ࠫࡪࡲࡳࡦࠩ௰"), l1lll1ll11l1_cdhd_ (u"ࠬࡩ࡯࡯ࡶࡵࡳࡱࡹࠧ௱"), l1lll1ll11l1_cdhd_ (u"࠭ࡰࡳࡧ࡯ࡳࡦࡪࠧ௲"), l1lll1ll11l1_cdhd_ (u"ࠧࡰࡴࡼ࡫࡮ࡴࡡ࡭ࡰࡨࠫ௳"), l1lll1ll11l1_cdhd_ (u"ࠨࡵࡷࡽࡱ࡫ࠧ௴"),
                l1lll1ll11l1_cdhd_ (u"ࠩ࠹࠶࠵ࡶࡸࠨ௵"), l1lll1ll11l1_cdhd_ (u"ࠪ࠷࠽࠽ࡰࡹࠩ௶"), l1lll1ll11l1_cdhd_ (u"ࠫࡵࡵࡳࡵࡧࡵࠫ௷"), l1lll1ll11l1_cdhd_ (u"ࠬࢀ࡮ࡪ࡭ࡱ࡭ࡪ࠭௸"), l1lll1ll11l1_cdhd_ (u"࠭ࡳࡦ࡭ࡸࡲࡩ࠭௹"), l1lll1ll11l1_cdhd_ (u"ࠧࡴࡪࡲࡻࡆ࡬ࡴࡦࡴࡖࡩࡨࡵ࡮ࡥࡵࠪ௺"), l1lll1ll11l1_cdhd_ (u"ࠨ࡫ࡰࡥ࡬࡫ࡳࠨ௻"), l1lll1ll11l1_cdhd_ (u"ࠩࡕࡩࡰࡲࡡ࡮ࡣࠪ௼"), l1lll1ll11l1_cdhd_ (u"ࠪࡷࡰ࡯ࡰࡂࡦࠪ௽"),
                 l1lll1ll11l1_cdhd_ (u"ࠫࡱ࡫ࡶࡦ࡮ࡶࠫ௾"), l1lll1ll11l1_cdhd_ (u"ࠬࡶࡡࡥࡦ࡬ࡲ࡬࠭௿"), l1lll1ll11l1_cdhd_ (u"࠭࡯ࡱࡣࡦ࡭ࡹࡿࠧఀ"), l1lll1ll11l1_cdhd_ (u"ࠧࡥࡧࡥࡹ࡬࠭ఁ"), l1lll1ll11l1_cdhd_ (u"ࠨࡸ࡬ࡨࡪࡵ࠳ࠨం"), l1lll1ll11l1_cdhd_ (u"ࠩࡦࡰࡴࡹࡥࠨః"), l1lll1ll11l1_cdhd_ (u"ࠪࡷࡲࡧ࡬࡭ࡶࡨࡼࡹ࠭ఄ"), l1lll1ll11l1_cdhd_ (u"ࠫࡲ࡫ࡳࡴࡣࡪࡩࠬఅ"), l1lll1ll11l1_cdhd_ (u"ࠬࡩ࡬ࡢࡵࡶࠫఆ"), l1lll1ll11l1_cdhd_ (u"࠭ࡡ࡭࡫ࡪࡲࠬఇ"),
                  l1lll1ll11l1_cdhd_ (u"ࠧ࡯ࡱࡷ࡭ࡨ࡫ࠧఈ"), l1lll1ll11l1_cdhd_ (u"ࠨ࡯ࡨࡨ࡮ࡧࠧఉ")]
            for l111l1111ll11l1_cdhd_ in l1l11llll1ll11l1_cdhd_:
                l1llllll11ll11l1_cdhd_=l1llllll11ll11l1_cdhd_.replace(l111l1111ll11l1_cdhd_,l1lll1ll11l1_cdhd_ (u"ࠩࠪఊ"))
            cleanup=l1llllll11ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠪࢀࠬఋ"),l1lll1ll11l1_cdhd_ (u"ࠫࠥ࠭ఌ")).split()
            out={l1lll1ll11l1_cdhd_ (u"ࠬࡹࡥࡳࡸࡨࡶࠬ఍"): l1lll1ll11l1_cdhd_ (u"࠭ࠧఎ"), l1lll1ll11l1_cdhd_ (u"ࠧࡦࠩఏ"): l1lll1ll11l1_cdhd_ (u"ࠨࠩఐ"), l1lll1ll11l1_cdhd_ (u"ࠩࡩ࡭ࡱ࡫ࠧ఑"): l1lll1ll11l1_cdhd_ (u"ࠪࠫఒ"), l1lll1ll11l1_cdhd_ (u"ࠫࡸࡺࠧఓ"): l1lll1ll11l1_cdhd_ (u"ࠬ࠭ఔ")}
            if len(cleanup)==4:
                print l1lll1ll11l1_cdhd_ (u"࠭ࡌࡦࡰࡪࡸ࡭ࠦࡏࡌࠩక")
                for l111l1111ll11l1_cdhd_ in cleanup:
                    if l111l1111ll11l1_cdhd_.isdigit():
                        out[l1lll1ll11l1_cdhd_ (u"ࠧࡦࠩఖ")]=l111l1111ll11l1_cdhd_
                    elif re.match(l1lll1ll11l1_cdhd_ (u"ࠨ࡝ࡤ࠱ࡿࡣࡻ࠳࠮ࢀࡠࡩࢁ࠳ࡾࠩగ"),l111l1111ll11l1_cdhd_) and len(l111l1111ll11l1_cdhd_)<10:
                        out[l1lll1ll11l1_cdhd_ (u"ࠩࡶࡩࡷࡼࡥࡳࠩఘ")] = l111l1111ll11l1_cdhd_
                    elif len(l111l1111ll11l1_cdhd_)==22:
                        out[l1lll1ll11l1_cdhd_ (u"ࠪࡷࡹ࠭ఙ")] = l111l1111ll11l1_cdhd_
                    else:
                        out[l1lll1ll11l1_cdhd_ (u"ࠫ࡫࡯࡬ࡦࠩచ")] = l111l1111ll11l1_cdhd_
                src=l1lll1ll11l1_cdhd_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࠫࡳ࠯ࡥࡧࡥ࠳ࡶ࡬࠰ࠧࡶ࠲ࡲࡶ࠴ࡀࡵࡷࡁࠪࡹࠦࡦ࠿ࠨࡷࠬఛ")%(out.get(l1lll1ll11l1_cdhd_ (u"࠭ࡳࡦࡴࡹࡩࡷ࠭జ")),out.get(l1lll1ll11l1_cdhd_ (u"ࠧࡧ࡫࡯ࡩࠬఝ")),out.get(l1lll1ll11l1_cdhd_ (u"ࠨࡵࡷࠫఞ")),out.get(l1lll1ll11l1_cdhd_ (u"ࠩࡨࠫట")))
    return src
def l1l1lllll1ll11l1_cdhd_(content):
    l1lll1ll11l1_cdhd_ (u"ࠥࠦࠧࠓࠊࠡࠢࠣࠤࡘࡩࡡ࡯ࡵࠣࡪࡴࡸࠠࡷ࡫ࡧࡩࡴࠦ࡬ࡪࡰ࡮ࠤ࡮ࡴࡣ࡭ࡷࡧࡩࡩࠦࡥ࡯ࡥࡲࡨࡪࡪࠠࡰࡰࡨࠑࠏࠦࠠࠡࠢࠥࠦࠧఠ")
    l1l1l1ll11ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠫࠬడ")
    l1l1ll11l1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠬ࡬ࡩ࡭ࡧ࠽ࠤࡠࡢࠧࠣ࡟ࠫ࠲࠰ࡅࠩ࡜࡞ࠪࠦࡢ࠲ࠧఢ"),  re.DOTALL).search(content)
    l1l1ll1ll1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"࠭ࡵࡳ࡮࠽ࠤࡠࡢࠧࠣ࡟ࠫ࠲࠰ࡅࠩ࡜࡞ࠪࠦࡢ࠲ࠧణ"),  re.DOTALL).search(content)
    if l1l1ll11l1ll11l1_cdhd_:
        print l1lll1ll11l1_cdhd_ (u"ࠧࡧࡱࡸࡲࡩࠦࡒࡆࠢ࡞ࡪ࡮ࡲࡥ࠻࡟ࠪత")
        l1l1l1ll11ll11l1_cdhd_ = l1l1ll11l1ll11l1_cdhd_.group(1)
    elif l1l1ll1ll1ll11l1_cdhd_:
        print l1lll1ll11l1_cdhd_ (u"ࠨࡨࡲࡹࡳࡪࠠࡓࡇࠣ࡟ࡺࡸ࡬࠻࡟ࠪథ")
        l1l1l1ll11ll11l1_cdhd_ = l1l1ll1ll1ll11l1_cdhd_.group(1)
    else:
        print l1lll1ll11l1_cdhd_ (u"ࠩࡨࡲࡨࡵࡤࡦࡦࠣ࠾ࠥࡻ࡮ࡱࡣࡦ࡯ࡪࡸࠧద")
        l1l1l1ll11ll11l1_cdhd_ = _1ll111111ll11l1_cdhd_(content)
        if not l1l1l1ll11ll11l1_cdhd_:
            print l1lll1ll11l1_cdhd_ (u"ࠪࡩࡳࡩ࡯ࡥࡧࡧࠤ࠿ࠦࡦࡰࡴࡦࡩࠥ࠭ధ")
            l1l1l1ll11ll11l1_cdhd_ = _1l1ll1l11ll11l1_cdhd_(content)
    return l1l1l1ll11ll11l1_cdhd_
def l1ll11l11ll11l1_cdhd_(url):
    l1lll1ll11l1_cdhd_ (u"ࠦࠧࠨࠍࠋࠢࠣࠤࠥࡸࡥࡵࡷࡵࡲࡸࠦࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠰ࠤࡺࡲࡲࠡࡪࡷࡸࡵࡀ࠯࠰࠰࠱࠲࠳ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠯ࠣࡳࡷࠦ࡬ࡪࡵࡷࠤࡴ࡬ࠠ࡜ࠪࠪ࠻࠷࠶ࡰࠨ࠮ࠣࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡥࡧࡥ࠳ࡶ࡬࠰ࡸ࡬ࡨࡪࡵ࠯࠲࠻࠷࠺࠾࠿࠱ࡧࡁࡺࡩࡷࡹࡪࡢ࠿࠺࠶࠵ࡶࠧࠪ࠮࠱࠲࠳ࡣࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠑࠏࠦࠠࠡࠢࠥࠦࠧన")
    l1l1l1l1l1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠬࢂࡃࡰࡱ࡮࡭ࡪࡃࠢࡑࡊࡓࡗࡊ࡙ࡓࡊࡆࡀ࠵ࠫࡘࡥࡧࡧࡵࡩࡷࡃࡨࡵࡶࡳ࠾࠴࠵ࡳࡵࡣࡷ࡭ࡨ࠴ࡣࡥࡣ࠱ࡴࡱ࠵ࡰ࡭ࡣࡼࡩࡷ࠻࠮࠺࠱ࡳࡰࡦࡿࡥࡳ࠰ࡶࡻ࡫࠭఩")
    l1l1l11l11ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࡪࡷࡸࡵࡀ࠯࠰ࡵࡷࡥࡹ࡯ࡣ࠯ࡥࡧࡥ࠳ࡶ࡬࠰ࡲ࡯ࡥࡾ࡫ࡲ࠶࠰࠼࠳ࡵࡲࡡࡺࡧࡵ࠲ࡸࡽࡦࠨప")
    print url
    content = l1lll1l111ll11l1_cdhd_(url)
    src=[]
    if not l1lll1ll11l1_cdhd_ (u"ࠧࡀࡹࡨࡶࡸࡰࡡࠨఫ") in url:
         l1l1l1l111ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠨ࠾ࡤࠤࡩࡧࡴࡢ࠯ࡴࡹࡦࡲࡩࡵࡻࡀࠦ࠭࠴ࠪࡀࠫࠥࠤ࠭ࡅࡐ࠽ࡊࡁ࠲࠯ࡅࠩ࠿ࠪࡂࡔࡁࡗ࠾࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩబ"), re.DOTALL).findall(content)
         for quality in l1l1l1l111ll11l1_cdhd_:
             l1ll1l111ll11l1_cdhd_ = re.search(l1lll1ll11l1_cdhd_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨభ"),quality[1])
             l1l1l11111ll11l1_cdhd_ = quality[2]
             src.insert(0,(l1l1l11111ll11l1_cdhd_,l1ll11lll1ll11l1_cdhd_+l1ll1l111ll11l1_cdhd_.group(1)))
    if not src:
        src = l1l1lllll1ll11l1_cdhd_(content)
        if src:
            src+=l1l1l1l1l1ll11l1_cdhd_+l1l1l11l11ll11l1_cdhd_
    return src
def l1l1lll1l1ll11l1_cdhd_(url,quality=0):
    l1lll1ll11l1_cdhd_ (u"ࠥࠦࠧࠓࠊࠡࠢࠣࠤࡷ࡫ࡴࡶࡴࡱࡷࠥࡻࡲ࡭ࠢࡷࡳࠥࡼࡩࡥࡧࡲࠑࠏࠦࠠࠡࠢࠥࠦࠧమ")
    src = l1ll11l11ll11l1_cdhd_(url)
    if type(src)==list:
        selected=src[quality]
        print l1lll1ll11l1_cdhd_ (u"ࠫࡖࡻࡡ࡭࡫ࡷࡽࠥࡀࠧయ"),selected[0]
        src = l1ll11l11ll11l1_cdhd_(selected[1])
    return src
