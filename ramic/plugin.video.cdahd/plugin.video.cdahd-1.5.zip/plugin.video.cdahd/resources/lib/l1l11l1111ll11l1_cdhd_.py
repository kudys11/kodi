# coding: UTF-8
import sys
l1ll11ll11l1_cdhd_ = sys.version_info [0] == 2
l11ll1ll11l1_cdhd_ = 2048
l1111ll11l1_cdhd_ = 7
def l1lll1ll11l1_cdhd_ (keyedStringLiteral):
	global l1l111ll11l1_cdhd_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll11l1_cdhd_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import re,os
import urllib2
import urllib
import urlparse
import time
import cookielib
l1ll11l1l1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡏࡘ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠸࠴࠳࠶࠮࠳࠸࠹࠵࠳࠷࠰࠳ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩക")
l11ll1l1l1ll11l1_cdhd_=l1ll11l1l1ll11l1_cdhd_
l111llll11ll11l1_cdhd_ = 3
class l11ll11l11ll11l1_cdhd_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
    https_response = http_response
def l11l1l11l1ll11l1_cdhd_(l111ll1ll1ll11l1_cdhd_):
    try:
        offset = 1 if l111ll1ll1ll11l1_cdhd_[0] == l1lll1ll11l1_cdhd_ (u"ࠫ࠰࠭ഖ") else 0
        return int(eval(l111ll1ll1ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠬࠧࠫ࡜࡟ࠪഗ"), l1lll1ll11l1_cdhd_ (u"࠭࠱ࠨഘ")).replace(l1lll1ll11l1_cdhd_ (u"ࠧࠢࠣ࡞ࡡࠬങ"), l1lll1ll11l1_cdhd_ (u"ࠨ࠳ࠪച")).replace(l1lll1ll11l1_cdhd_ (u"ࠩ࡞ࡡࠬഛ"), l1lll1ll11l1_cdhd_ (u"ࠪ࠴ࠬജ")).replace(l1lll1ll11l1_cdhd_ (u"ࠫ࠭࠭ഝ"), l1lll1ll11l1_cdhd_ (u"ࠬࡹࡴࡳࠪࠪഞ"))[offset:]))
    except:
        pass
url=l1lll1ll11l1_cdhd_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡤࡦࡤࡼ࠳ࡺࡶ࠰ࠩട")
wait=True
l111ll1111ll11l1_cdhd_=l1ll11l1l1ll11l1_cdhd_
l111llll1ll11l1_cdhd_ = cookielib.LWPCookieJar()
def l111111l1ll11l1_cdhd_(url,l111llll1ll11l1_cdhd_=l111llll1ll11l1_cdhd_,l11ll1l1l1ll11l1_cdhd_=l1ll11l1l1ll11l1_cdhd_):
    return l111ll11l1ll11l1_cdhd_(url,l111llll1ll11l1_cdhd_,l111ll1111ll11l1_cdhd_=l11ll1l1l1ll11l1_cdhd_, wait=True)
def l111ll11l1ll11l1_cdhd_(url, l111llll1ll11l1_cdhd_, l111ll1111ll11l1_cdhd_=None, wait=True):
    if l111ll1111ll11l1_cdhd_ is None: l111ll1111ll11l1_cdhd_ = l1ll11l1l1ll11l1_cdhd_
    headers = {l1lll1ll11l1_cdhd_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫഠ"): l111ll1111ll11l1_cdhd_, l1lll1ll11l1_cdhd_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩഡ"): url}
    if l111llll1ll11l1_cdhd_ is not None:
        try: l111llll1ll11l1_cdhd_.load(ignore_discard=True)
        except: pass
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(l111llll1ll11l1_cdhd_))
        urllib2.install_opener(opener)
    request = urllib2.Request(url)
    for key in headers: request.add_header(key, headers[key])
    try:
        response = urllib2.urlopen(request)
        html = response.read()
    except urllib2.HTTPError as e:
        html = e.read()
    l111lllll1ll11l1_cdhd_ = 0
    while l111lllll1ll11l1_cdhd_ < l111llll11ll11l1_cdhd_:
        l111ll1l11ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠩࡹࡥࡷࠦࠨࡀ࠼ࡶ࠰ࡹ࠲࡯࠭ࡲ࠯ࡦ࠱ࡸࠬࡦ࠮ࡤ࠰ࡰ࠲ࡩ࠭ࡰ࠯࡫ࢁࡺࠬࡳ࠮ࡤ࠭࠱࡬ࠬ࡝ࡵ࠭ࠬࡠࡤ࠽࡞࠭ࠬࡁࢀࠨࠨ࡜ࡠࠥࡡ࠰࠯ࠢ࠻ࠪ࡞ࡢࢂࡣࠫࠪࡿ࠾࠲࠰ࡩࡨࡢ࡮࡯ࡩࡳ࡭ࡥ࠮ࡨࡲࡶࡲࡢࠧ࡝ࠫ࠾࠲࠯ࡅ࡜࡯࠰࠭ࡃࡀ࠮࠮ࠫࡁࠬ࠿ࡦࡢ࠮ࡷࡣ࡯ࡹࡪ࠭ഢ")
        l11l11l111ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠪ࡭ࡳࡶࡵࡵࠢࡷࡽࡵ࡫࠽ࠣࡪ࡬ࡨࡩ࡫࡮ࠣࠢࡱࡥࡲ࡫࠽ࠣ࡬ࡶࡧ࡭ࡲ࡟ࡷࡥࠥࠤࡻࡧ࡬ࡶࡧࡀࠦ࠭ࡡ࡞ࠣ࡟࠮࠭ࠬണ")
        l11l111ll1ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠫ࡮ࡴࡰࡶࡶࠣࡸࡾࡶࡥ࠾ࠤ࡫࡭ࡩࡪࡥ࡯ࠤࠣࡲࡦࡳࡥ࠾ࠤࡳࡥࡸࡹࠢࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࡞ࡢࠧࡣࠫࠪࠩത")
        l11l111l11ll11l1_cdhd_ = re.search(l111ll1l11ll11l1_cdhd_, html, re.DOTALL)
        l11l11l1l1ll11l1_cdhd_ = re.search(l11l11l111ll11l1_cdhd_, html)
        l11l1l1l11ll11l1_cdhd_ = re.search(l11l111ll1ll11l1_cdhd_, html)
        if not l11l111l11ll11l1_cdhd_ or not l11l11l1l1ll11l1_cdhd_ or not l11l1l1l11ll11l1_cdhd_:
            return False
        l11l1l1ll1ll11l1_cdhd_, l111lll1l1ll11l1_cdhd_, l11l1111l1ll11l1_cdhd_, l11l11lll1ll11l1_cdhd_ = l11l111l11ll11l1_cdhd_.groups()
        l11l1ll111ll11l1_cdhd_ = l11l11l1l1ll11l1_cdhd_.group(1)
        password = l11l1l1l11ll11l1_cdhd_.group(1)
        l111lll111ll11l1_cdhd_ = (l11l1l1ll1ll11l1_cdhd_, l111lll1l1ll11l1_cdhd_)
        result = int(l11l1l11l1ll11l1_cdhd_(l11l1111l1ll11l1_cdhd_.rstrip()))
        for l111ll1ll1ll11l1_cdhd_ in l11l11lll1ll11l1_cdhd_.split(l1lll1ll11l1_cdhd_ (u"ࠬࡁࠧഥ")):
            l111ll1ll1ll11l1_cdhd_ = l111ll1ll1ll11l1_cdhd_.rstrip()
            if l111ll1ll1ll11l1_cdhd_[:len(l1lll1ll11l1_cdhd_ (u"࠭࠮ࠨദ").join(l111lll111ll11l1_cdhd_))] != l1lll1ll11l1_cdhd_ (u"ࠧ࠯ࠩധ").join(l111lll111ll11l1_cdhd_):
                    print l1lll1ll11l1_cdhd_ (u"ࠨࡇࡴࡹࡦࡺࡩࡰࡰࠣࡨࡴ࡫ࡳࠡࡰࡲࡸࠥࡹࡴࡢࡴࡷࠤࡼ࡯ࡴࡩࠢࡹࡥࡷࡴࡡ࡮ࡧࠣࢀࠪࡹࡼࠨന") % (l111ll1ll1ll11l1_cdhd_)
            else:
                    l111ll1ll1ll11l1_cdhd_ = l111ll1ll1ll11l1_cdhd_[len(l1lll1ll11l1_cdhd_ (u"ࠩ࠱ࠫഩ").join(l111lll111ll11l1_cdhd_)):]
            l111l1lll1ll11l1_cdhd_ = l111ll1ll1ll11l1_cdhd_[2:]
            l11l1l1111ll11l1_cdhd_ = l111ll1ll1ll11l1_cdhd_[0]
            if l11l1l1111ll11l1_cdhd_ not in [l1lll1ll11l1_cdhd_ (u"ࠪ࠯ࠬപ"), l1lll1ll11l1_cdhd_ (u"ࠫ࠲࠭ഫ"), l1lll1ll11l1_cdhd_ (u"ࠬ࠰ࠧബ"), l1lll1ll11l1_cdhd_ (u"࠭࠯ࠨഭ")]:
                print l1lll1ll11l1_cdhd_ (u"ࠧࡖࡰ࡮ࡲࡴࡽ࡮ࠡࡱࡳࡩࡷࡧࡴࡰࡴ࠽ࠤࢁࠫࡳࡽࠩമ") % (l111ll1ll1ll11l1_cdhd_)
                continue
            result = int(str(eval(str(result) + l11l1l1111ll11l1_cdhd_ + str(l11l1l11l1ll11l1_cdhd_(l111l1lll1ll11l1_cdhd_)))))
        scheme = urlparse.urlparse(url).scheme
        l11l1ll1l1ll11l1_cdhd_ = urlparse.urlparse(url).hostname
        result += len(l11l1ll1l1ll11l1_cdhd_)
        if wait: time.sleep(5)
        url = l1lll1ll11l1_cdhd_ (u"ࠨࠧࡶ࠾࠴࠵ࠥࡴ࠱ࡦࡨࡳ࠳ࡣࡨ࡫࠲ࡰ࠴ࡩࡨ࡬ࡡ࡭ࡷࡨ࡮࡬ࡀ࡬ࡶࡧ࡭ࡲ࡟ࡷࡥࡀࠩࡸࠬࡪࡴࡥ࡫ࡰࡤࡧ࡮ࡴࡹࡨࡶࡂࠫࡳࠧࡲࡤࡷࡸࡃࠥࡴࠩയ") % (scheme, l11l1ll1l1ll11l1_cdhd_, l11l1ll111ll11l1_cdhd_, result, urllib.quote(password))
        request = urllib2.Request(url)
        for key in headers: request.add_header(key, headers[key])
        try:
            opener = urllib2.build_opener(l11ll11l11ll11l1_cdhd_)
            urllib2.install_opener(opener)
            response = urllib2.urlopen(request)
            while response.getcode() in [301, 302, 303, 307]:
                if l111llll1ll11l1_cdhd_ is not None:
                    l111llll1ll11l1_cdhd_.l11l11ll11ll11l1_cdhd_(response, request)
                request = urllib2.Request(response.info().getheader(l1lll1ll11l1_cdhd_ (u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫര")))
                for key in headers: request.add_header(key, headers[key])
                if l111llll1ll11l1_cdhd_ is not None:
                    l111llll1ll11l1_cdhd_.l11l111111ll11l1_cdhd_(request)
                response = urllib2.urlopen(request)
            final = response.read()
            if l1lll1ll11l1_cdhd_ (u"ࠪࡧ࡫࠳ࡢࡳࡱࡺࡷࡪࡸ࠭ࡷࡧࡵ࡭࡫࡯ࡣࡢࡶ࡬ࡳࡳ࠭റ") in final:
                l111lllll1ll11l1_cdhd_ += 1
                html = final
            else:
                break
        except urllib2.HTTPError as e:
            print l1lll1ll11l1_cdhd_ (u"ࠫࡈࡲ࡯ࡶࡦࡉࡰࡦࡸࡥࠡࡇࡵࡶࡴࡸ࠺ࠡࠧࡶࠤࡴࡴࠠࡶࡴ࡯࠾ࠥࠫࡳࠨല") % (e.code, url)
            return False
    return l111llll1ll11l1_cdhd_
def l1ll1l1ll1ll11l1_cdhd_(l11lll1ll11l1_cdhd_):
    l11ll11ll1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠬ࠭ള")
    if os.path.isfile(l11lll1ll11l1_cdhd_):
        l111llll1ll11l1_cdhd_ = cookielib.LWPCookieJar()
        l111llll1ll11l1_cdhd_.load(l11lll1ll11l1_cdhd_)
        for c in l111llll1ll11l1_cdhd_:
            l11ll11ll1ll11l1_cdhd_+=l1lll1ll11l1_cdhd_ (u"࠭ࠥࡴ࠿ࠨࡷࡀ࠭ഴ")%(c.name, c.value)
    return l11ll11ll1ll11l1_cdhd_
