# -*- coding: utf-8 -*-
import sys
l1ll11ll11l1_cdhd_ = sys.version_info [0] == 2
l11ll1ll11l1_cdhd_ = 2048
l1111ll11l1_cdhd_ = 7
def l1lll1ll11l1_cdhd_ (keyedStringLiteral):
	global l1l111ll11l1_cdhd_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll11l1_cdhd_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os,json
import l1llll1111ll11l1_cdhd_,cookielib
from urlparse import urlparse
l1ll11lll1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡣࡥࡣ࠰࡬ࡩ࠴ࡴࡷ࠱ࠪূ")
l111ll1l1ll11l1_cdhd_ = 10
l1ll11l1l1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠴࠹࠰࠳࠲࠷࠻࠶࠵࠰࠼࠻࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬৃ")
l11lll1ll11l1_cdhd_=os.path.join(os.getcwd(),l1lll1ll11l1_cdhd_ (u"ࠨࡥࡲࡳࡰ࡯ࡥ࠯ࡥࡧࡥࠬৄ"))
l1ll1l11l1ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠩࠪ৅")
def _1ll1ll1l1ll11l1_cdhd_(url,data=None,cookies=l1lll1ll11l1_cdhd_ (u"ࠪࠫ৆")):
    req = urllib2.Request(url,data)
    req.add_header(l1lll1ll11l1_cdhd_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨে"), l1ll11l1l1ll11l1_cdhd_)
    if cookies:
        req.add_header(l1lll1ll11l1_cdhd_ (u"ࠧࡉ࡯ࡰ࡭࡬ࡩࠧৈ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l111ll1l1ll11l1_cdhd_)
        l1ll1l111ll11l1_cdhd_ = response.read()
        response.close()
    except:
        l1ll1l111ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"࠭ࠧ৉")
    return l1ll1l111ll11l1_cdhd_
def l1lll1l111ll11l1_cdhd_(url,data=None):
    cookies=l1llll1111ll11l1_cdhd_.l1ll1l1ll1ll11l1_cdhd_(l11lll1ll11l1_cdhd_)
    content=_1ll1ll1l1ll11l1_cdhd_(url,data,cookies)
    if not content:
        l111llll1ll11l1_cdhd_=l1ll1llll1ll11l1_cdhd_(l1ll11lll1ll11l1_cdhd_,l11lll1ll11l1_cdhd_)
        cookies=l1llll1111ll11l1_cdhd_.l1ll1l1ll1ll11l1_cdhd_(l11lll1ll11l1_cdhd_)
        content=_1ll1ll1l1ll11l1_cdhd_(url,data,cookies)
    return content
def l1ll1llll1ll11l1_cdhd_(l1ll1l111ll11l1_cdhd_,l1lll1l1l1ll11l1_cdhd_):
    l111llll1ll11l1_cdhd_ = cookielib.LWPCookieJar()
    l1lll11ll1ll11l1_cdhd_ = l1llll1111ll11l1_cdhd_.l111111l1ll11l1_cdhd_(l1ll1l111ll11l1_cdhd_,l111llll1ll11l1_cdhd_,l1ll11l1l1ll11l1_cdhd_)
    l111l11l1ll11l1_cdhd_=os.path.dirname(l1lll1l1l1ll11l1_cdhd_)
    if not os.path.exists(l111l11l1ll11l1_cdhd_):
        os.makedirs(l111l11l1ll11l1_cdhd_)
    if l111llll1ll11l1_cdhd_:
        l111llll1ll11l1_cdhd_.save(l1lll1l1l1ll11l1_cdhd_,  True, True)
    return l111llll1ll11l1_cdhd_
def l1ll1lll1ll11l1_cdhd_(url,l1l1l1l1ll11l1_cdhd_=1,group=l1lll1ll11l1_cdhd_ (u"ࠧ࠽ࡪ࠶ࡂࡓࡵࡷࡦࠢࡲࡨࠬ৊")):
    if l1lll1ll11l1_cdhd_ (u"ࠨࡁࡶࡁࠬো") in url:
        url = url.replace(l1lll1ll11l1_cdhd_ (u"ࠩࡂࡷࡂ࠭ৌ"),l1lll1ll11l1_cdhd_ (u"ࠪࡴࡦ࡭ࡥ࠰ࠧࡧ࠳ࡄࡹ࠽ࠨ্") %l1l1l1l1ll11l1_cdhd_)
    else:
        url += l1lll1ll11l1_cdhd_ (u"ࠫ࠴࠭ৎ") if url[-1] != l1lll1ll11l1_cdhd_ (u"ࠬ࠵ࠧ৏") else l1lll1ll11l1_cdhd_ (u"࠭ࠧ৐")
        url = url + l1lll1ll11l1_cdhd_ (u"ࠧࡱࡣࡪࡩ࠴ࠫࡤ࠰ࠩ৑") %l1l1l1l1ll11l1_cdhd_
    content = l1lll1l111ll11l1_cdhd_(url)
    out=[]
    l1ll1ll111ll11l1_cdhd_=False
    l1111lll1ll11l1_cdhd_=False
    ids = []
    if group:
        idx = [(m.start(0), m.end(0)) for m in re.finditer(l1lll1ll11l1_cdhd_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡩࡥ࠿ࠥࡷࡱ࡯ࡤ࡝ࡦ࠮ࠦࡃ࠭৒"), content,re.IGNORECASE) ]
        idx.append( (content.find(l1lll1ll11l1_cdhd_ (u"ࠩࡒࡷࡹࡧࡴ࡯࡫ࡲࠤࡩࡵࡤࡢࡰࡨࠫ৓")),content.find(l1lll1ll11l1_cdhd_ (u"ࠪࡓࡸࡺࡡࡵࡰ࡬ࡳࠥࡪ࡯ࡥࡣࡱࡩࠬ৔"))) )
        for i in range(len(idx[:-1])):
            l1llllll11ll11l1_cdhd_=content[ idx[i][0]:idx[i+1][0] ]
            if group in l1llllll11ll11l1_cdhd_:
                content = l1llllll11ll11l1_cdhd_
                ids = [(a.start(), a.end()) for a in re.finditer(l1lll1ll11l1_cdhd_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡸࡪࡳࠢࠨ৕"), content)]
                ids.append( (-1,-1) )
                break
        for i in range(len(ids[:-1])):
            l11l11111ll11l1_cdhd_ = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile(l1lll1ll11l1_cdhd_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠨ৖"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
            title = re.compile(l1lll1ll11l1_cdhd_ (u"࠭࠼ࡴࡲࡤࡲࠥࡩ࡬ࡢࡵࡶࡁࠧࡺࡴࡱࡵࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫৗ"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
            l1llll1l11ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠧ࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ৘"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
            l1111l1l1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠨ࠾࠲ࡦࡃࡢࡳࠫࠪ࡟ࡨࡡ࠴࡜ࡥࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪ৙"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
            year =  re.compile(l1lll1ll11l1_cdhd_ (u"ࠩ࠿ࡷࡵࡧ࡮ࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡻࡷࡴࡸࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭৚"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
            if href and title:
                l1llll1l11ll11l1_cdhd_ = l1llll1l11ll11l1_cdhd_.group(1) if l1llll1l11ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠪࠫ৛")
                if l1llll1l11ll11l1_cdhd_.startswith(l1lll1ll11l1_cdhd_ (u"ࠫ࠴࠵ࠧড়")):
                    l1llll1l11ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫঢ়")+l1llll1l11ll11l1_cdhd_
                l111l1111ll11l1_cdhd_ = {l1lll1ll11l1_cdhd_ (u"࠭ࡨࡳࡧࡩࠫ৞")   : href.group(1),
                    l1lll1ll11l1_cdhd_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭য়")  : l1llll11l1ll11l1_cdhd_(title.group(1)),
                    l1lll1ll11l1_cdhd_ (u"ࠨ࡫ࡰ࡫ࠬৠ")    : l1llll1l11ll11l1_cdhd_,
                    l1lll1ll11l1_cdhd_ (u"ࠩࡵࡥࡹ࡯࡮ࡨࠩৡ") : l1111l1l1ll11l1_cdhd_.group(1) if l1111l1l1ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠪࠫৢ"),
                    l1lll1ll11l1_cdhd_ (u"ࠫࡾ࡫ࡡࡳࠩৣ")   : year.group(1) if year else l1lll1ll11l1_cdhd_ (u"ࠬ࠭৤"),
                        }
                out.append(l111l1111ll11l1_cdhd_)
    else:
        l1ll111l1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀ࡟ࠧࡢࠧ࡞ࡲࡤ࡫࡮ࡴࡡࡥࡱ࡞ࠦࡡ࠭࡝࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭৥"),re.DOTALL).findall(content)
        l1ll111l1ll11l1_cdhd_ = urllib.unquote(l1ll111l1ll11l1_cdhd_[0]) if l1ll111l1ll11l1_cdhd_ else content
        l1ll1ll111ll11l1_cdhd_=False
        l1ll11ll11ll11l1_cdhd_=url.replace(l1lll1ll11l1_cdhd_ (u"ࠧࡱࡣࡪࡩ࠴ࠫࡤ࠰ࠩ০")%l1l1l1l1ll11l1_cdhd_,l1lll1ll11l1_cdhd_ (u"ࠨࡲࡤ࡫ࡪ࠵ࠥࡥࠩ১") %(l1l1l1l1ll11l1_cdhd_+1))
        if l1ll111l1ll11l1_cdhd_.find(l1ll11ll11ll11l1_cdhd_.split(l1lll1ll11l1_cdhd_ (u"ࠩ࠲࠳ࠬ২"))[-1])>-1:
            l1ll1ll111ll11l1_cdhd_ = l1l1l1l1ll11l1_cdhd_+1
        ids = [(a.start(), a.end()) for a in re.finditer(l1lll1ll11l1_cdhd_ (u"ࠪࡀࡩ࡯ࡶࠡ࡫ࡧࡁࡡࠨ࡭ࡵ࠰࠭ࡠࠧࠦࡣ࡭ࡣࡶࡷࡂࡢࠢࡪࡶࡨࡱࡡࠨ࠾ࠨ৩"), content)]
        ids.append( (-1,-1) )
        for i in range(len(ids[:-1])):
            l11l11111ll11l1_cdhd_ = content[ ids[i][1]:ids[i+1][0] ]
            href = re.compile(l1lll1ll11l1_cdhd_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡥࡳࡽ࡯࡮ࡧࡱࠥࡂࡠࡢࡳ࡝ࡰࡠ࠯ࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠧ৪"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
            title = re.compile(l1lll1ll11l1_cdhd_ (u"ࠬࡂࡳࡱࡣࡱࠤࡨࡲࡡࡴࡵࡀࠦࡹࡺࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ৫"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
            l1lllll1l1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"࠭࠼ࡴࡲࡤࡲࠥࡩ࡬ࡢࡵࡶࡁࠧࡺࡴࡹࠤࡁࡠࡳ࠮࠮ࠫࡁࠬࠬࡄࡀ࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡩ࡫ࡧࡳࡣࡧࡥࡩࡵࠢ࠿࠾࠲ࡨ࡮ࡼ࠾ࠪࡽ࠳࠰࠶ࢃ࡛࡝ࡵ࡟ࡲࡢ࠰࠼࠰ࡵࡳࡥࡳࡄ࡛࡝ࡵ࡟ࡲࡢ࠰ࠧ৬"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
            l1llll1l11ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧ࡯࡭ࡢࡩࡨࠦࡃࡡ࡜ࡴ࡞ࡱࡡ࠰ࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ৭"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
            l1111l1l1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠨ࠾ࡶࡴࡦࡴࠠࡤ࡮ࡤࡷࡸࡃࠢࡪ࡯ࡧࡦࡸࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭৮"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
            year =  re.compile(l1lll1ll11l1_cdhd_ (u"ࠩ࠿ࡷࡵࡧ࡮ࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡻࡨࡥࡷࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭৯"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
            quality = re.compile(l1lll1ll11l1_cdhd_ (u"ࠪࡀࡸࡶࡡ࡯ࠢࡦࡰࡦࡹࡳ࠾ࠤࡦࡥࡱ࡯ࡤࡢࡦ࠵ࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡰࡢࡰࡁࠫৰ"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
            l1lllll111ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠫࡁࡨ࠾࠯࠭ࡂࡀ࠴ࡨ࠾ࠡ࠾ࡥࡂ࠭࠴ࠪࡀࠢࡪॆࡴࡹࣳࡸࠫ࠿࠳ࡧࡄࠧৱ")).search(l11l11111ll11l1_cdhd_)
            if href and title:
                l1llll1l11ll11l1_cdhd_ = l1llll1l11ll11l1_cdhd_.group(1) if l1llll1l11ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠬ࠭৲")
                if l1llll1l11ll11l1_cdhd_.startswith(l1lll1ll11l1_cdhd_ (u"࠭࠯࠰ࠩ৳")):
                    l1llll1l11ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠧࡩࡶࡷࡴ࠿࠭৴")+l1llll1l11ll11l1_cdhd_
                l111l1111ll11l1_cdhd_ = {l1lll1ll11l1_cdhd_ (u"ࠨࡪࡵࡩ࡫࠭৵")   : href.group(1),
                    l1lll1ll11l1_cdhd_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ৶")  : l1llll11l1ll11l1_cdhd_(title.group(1)),
                    l1lll1ll11l1_cdhd_ (u"ࠪࡴࡱࡵࡴࠨ৷")   : l1llll11l1ll11l1_cdhd_(l1lllll1l1ll11l1_cdhd_.group(1)) if l1lllll1l1ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠫࠬ৸"),
                    l1lll1ll11l1_cdhd_ (u"ࠬ࡯࡭ࡨࠩ৹")    : l1llll1l11ll11l1_cdhd_,
                    l1lll1ll11l1_cdhd_ (u"࠭ࡲࡢࡶ࡬ࡲ࡬࠭৺") : l1111l1l1ll11l1_cdhd_.group(1) if l1111l1l1ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠧࠨ৻"),
                    l1lll1ll11l1_cdhd_ (u"ࠨࡻࡨࡥࡷ࠭ৼ")   : year.group(1) if year else l1lll1ll11l1_cdhd_ (u"ࠩࠪ৽"),
                    l1lll1ll11l1_cdhd_ (u"ࠪࡺࡴࡺࡥࡴࠩ৾")  : l1lllll111ll11l1_cdhd_.group(1) if l1lllll111ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠫࠬ৿"),
                    l1lll1ll11l1_cdhd_ (u"ࠬࡩ࡯ࡥࡧࠪ਀")  : quality.group(1) if quality else l1lll1ll11l1_cdhd_ (u"࠭ࠧਁ"),
                        }
                out.append(l111l1111ll11l1_cdhd_)
        l1111lll1ll11l1_cdhd_ = l1l1l1l1ll11l1_cdhd_-1 if l1l1l1l1ll11l1_cdhd_>1 else False
    return (out, (l1111lll1ll11l1_cdhd_,l1ll1ll111ll11l1_cdhd_))
def l111lll11ll11l1_cdhd_(url):
    content = l1lll1l111ll11l1_cdhd_(url)
    token = re.search(l1lll1ll11l1_cdhd_ (u"ࠧ࡯ࡣࡰࡩࡂࠨ࡟ࡵࡱ࡮ࡩࡳࠨࠠࡵࡻࡳࡩࡂࠨࡨࡪࡦࡧࡩࡳࠨࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠨਂ"),content).group(1)
    l1lll11111ll11l1_cdhd_ = re.search(l1lll1ll11l1_cdhd_ (u"ࠨࡵ࡬ࡸࡪࡱࡥࡺ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫਃ"),content).group(1)
    params = {l1lll1ll11l1_cdhd_ (u"ࠩࡢࡸࡴࡱࡥ࡯ࠩ਄"):l1lll1ll11l1_cdhd_ (u"ࠪࡑ࡬ࡠࡍࡃ࠳࡚ࡪ࠹࡛ࡂࡈࡲ࡫࡝ࡋ࠷ࡩ࠷࠵ࡰࡓ࠹࠼࠷ࡸࡺࡊ࠼ࡘ࠻࡫࠶ࡥ࡮ࡴ࠹ࡓࡏ࡫ࠩਅ"),
            l1lll1ll11l1_cdhd_ (u"ࠫ࡬࠳ࡲࡦࡥࡤࡴࡹࡩࡨࡢ࠯ࡵࡩࡸࡶ࡯࡯ࡵࡨࠫਆ"):l1lll1ll11l1_cdhd_ (u"ࠬ࠶࠳ࡂࡊࡍࡣ࡛ࡻࡶࡸࡹ࡮ࡏࡋ࠷ࡉ࠺ࡎࡑ࡬࡚ࡘࡒࡴࡒࡍࡷࡖࡕ࠵ࡠࡕ࡯ࡌࡶࡍࡱࡗ࠻ࡥࡳࡷࡈࡡࡖ࡙ࡴࡱࡳࡷࡎࡅࡨࡴࡌ࠶ࡶࡔࡊࡒࡼࡱࡶ࡛ࡷࡍࡎ࡮࡮࠹ࡾࡨ࠷ࡰ࡚࡫ࡆࡳࡂ࡯ࡹ࡙ࡧ࡟ࡈࡖࡶࡩࡰࡑࡏ࡯ࡖࡤࡲࡏ࠺࠲࡚࠲ࡤࡌࡊࡹ࠺࡬ࡄࡌ࡯ࡈࡷࡽࡧ࡚ࡴ࠳ࡒࡕࡌࡗࡸࡱ࠺ࡷࡓࡷ࠸࡙ࡱࡣ࡙ࡧࡆ࡜ࡰࡦࡒࡨࡸࡖࡲࡂࡗ࠲ࡼࡅ࠽࡭ࡔࡄࡓࡦࡴࡲࡴࡦ࡚ࡦࡒࡗࡨࡗ࡫ࡹࡗ࠼ࡳࡤࡹ࠵ࡒ࠶ࡶ࡮ࡕ࠺ࡈࡰࡸ࠵ࡕࡧࡨࡨࡈࡘ࠼ࡗࡎ࠺ࡏ࠹ࡣ࠰࡚ࡗࡇࡖ࡙ࡴࡘࡾࡵ࡬࠶ࡹࡻࡸࡩࡻ࡟ࡳࡶ࡚࠶ࡌࡽࡎࡡࡠࡄࡶ࡝ࡖࡉ࠹ࡖ࠹ࡇ࡜࠵ࡰࡦ࡫ࡄࡍࡈࡲ࡯࡬ࡋࡣࡥ࠺࡚ࡊࡒࡥࡘࡆࡰࡪࡍ࠭࡫ࡈࡺ࠻ࡗࡑࡰ࠸࠷ࡘ࡙࡭ࡲࡺ࡙ࡃࡏࡓࡋࡵࡨ࠴ࡋ࡚ࡥ࡟࡝࠹࡫ࡎࡨ࠴ࡋ࠹࡭ࡗࡧࡰ࡚࡙ࡗ࠭࠲࠵ࡳ࠴ࡔࡇࡹ࡯ࡹࡸࡳࡆ࡚࡚ࡘࡈࡷ࡬ࡊࡒ࠸ࡄ࠲ࡑࡏࡒ࡛ࡢࡥࡘࡪ࠹ࡩ࠳࡟࠷࠴࠻࡯ࡤࡈࡷࡅ࠳ࡕ࠺ࡐࡪ࠴࡙࡬ࡸࡅ࠾࡬࡬ࡒࡅࡈࡑ࡬࡛࠵ࡩࡼࡏࡱ࠽ࡘ࡟ࡌ࠵ࡉࡏࡦࡌ࡫ࡑࡲ࡬ࡹ࡚࡙࠳࡮ࡴ࠰ࡸ࡝ࢀ࠷ࡷࡵࡷࡐ࠾ࡈࡉࡑ࡚࡭ࡕࡼ࠼࠸࡚࠳ࡸࡱࡰࡥ࠷ࡳࡓࡹࡏࡏ࡭ࡉࡒࡃ࠵ࡒ࡫ࡨ࠵ࡸࡣࡗࡅࡉࡌ࠱ࡨࡣࡆࡹࡸ࡟ࡍ࠵ࡦ࠴࠸ࡓࡎ࠹ࡇ࠷࠵࡯ࡊ࠺࡬ࡳࡦࡥࡥ࡞࠸ࡕࡔ࠻ࡸ࡭ࡓࡉࡱࡆࡨ࡜࡬ࡆࡩࡺ࡙ࡻࡉ࡫ࡽࡾࡱࡃࡌ࠸࠼ࡇ࠼ࡐࡑࡼ࠳࡯࠸ࡓ࠷࠮࡚ࡴ࡞ࡘࡺࡐࡻࡣࡐࡔ࠹ࡓࡄࡓࡈࡵ࠸ࡾࡻࡊ࠲ࡃࡱ࠻ࡩࡵ࡮࠵࡫ࡰ࠺࠾ࡩࡏ࠹ࡲࡆ࠴ࡾࡼࡧࡢࡻ࡚ࡼࡸࡧ࡬ࡎ࠺ࡍࡐࡈࡊࡩࡕ࠹࡙ࡱࡘࡱࡡ࠸࠺ࡊ࡝ࡩ࠶ࡂࡥࡹࡖࡣࡩࡉ࠱ࡕࡺࡗ࡭ࡰ࡮ࡖ࠹ࡥࡋ࠽ࡦࡪࡊ࡙࡛࠸ࡅࡹࡉࡊࡄࡋ࠵ࡩ࡯ࡺࡁࡤࡥࡼ࡝࠺࡯ࡹࡤ࡫ࡨ࠱ࡿࡼࡎ࡛ࡧ࡭ࡺࡦࡉ࠸ࡈ࡛ࡌࡪࡼࡑࡎࡦ࡛ࡄ࠷࡛࡯࠶࠱ࡩ࡜ࡒ࡬ࡏࡥࡷ࠴ࡤ࠹࡚ࡓࡉࡒ࡜ࡩ࡝࠹ࢀࡗࡧࡡࡳ࡮ࡸ࠾ࡔ࠸ࡹࡇࡐࡶࡸ࠰࠹࡭ࡕࡌࡹࡘ࠷ࡩࡻࡥࡱࡲࡑࡳࡷ࡛ࡺࡋࡋࡱࡩࡅࡏࡹࡩࡪࡷࡑࡹ࠯ࡹࡾ࡛ࡊ࠴ࡤ࠻ࡷࡩ࠼࠿࡚ࡱࡑࡸࡖࡘࡳࡁࡏ࠺࡬࡭࠷ࡇࡲࡥ࡛ࡋ࡛ࡧࡥࡍ࠷࠻ࡤ࠴ࡍ࡬ࡦࡢࡩࡽࡔࡹ࡛࠸ࡎࡅࡦ࠺ࡑࡽࡵ࠹ࡖ࠹࠹ࡼ࠷ࡸࡲ࠹ࡌࡐࡳࡗࡒࡰࡥࡦࡴࡵࡓࡷࡄ࠻ࡅ࠼࡙࠾࡬ࡻࡦࡌࡵࡘ࠸ࡹࡍࡅࡶ࡫ࡐࡾࡺࡤࡎࡉࡓࡪࡷࡰࡵࡡࡔࡅࡎࡪࡎࡨ࡫ࡥࡽࡋ࠹ࡱ࠸ࡆ࡝ࡩࡨࡲ࠴࠲ࡴ࠵࡬ࡽࡔ࡫ࡉࡲ࠹ࡱ࡙࠷࡫࡫࡭ࡆ࠼࡬ࡽࡺࡄࡤࡪࡺࡏࡇ࡯ࡲ࠹ࡽࡹ࡟࡛ࡘࡷࡱࡔࡇࡺࡋࡅࡖࡐࡄࡹࡨࡏࡴࡉࡏ࠼࡙ࡨࡓࡄࡒ࠶࡬ࡑ࡞ࡖࡷࡃ࡙ࡥࡷ࡚࡬ࡥࡻࡃࡅ࡭ࡔ࡝࡮ࡦ࠲ࡉ࠻ࡖࡗࡣࡆࡡࡎ࡚࡞࠺ࡹࡆ࠶ࡕࡊࡘࡋ࡮ࡵ࡙࡯࠽ࡳࡿࡹ࡙࠻ࡒ࠶ࡔ࡟࠶ࡩࡇ࡬࠶ࡪ࠷ࡇ࠶ࡄࡄࡩ࡝ࡊ࡟࠲ࡻ࡬ࡐ࠾ࡹ࠭ࡴ࠸࠻ࡴࡱ࡯࡫ࡇࡈࡢࡰࡇࡸࡑ࡚࠲ࡹࡧࡦࡖ࡮ࡎ࠸࠼ࡕࡘ࡬࡮ࡳࡗࡄࡲࡋ࠻ࡨ࠸ࡄࡊࡻࡱ࡚࡫ࡲࡄࡪࡰࡼ࠼࠲ࡶࡑࡺ࠹ࡕࡴ࠲࡬ࡶࡼ࡫ࡗࡖ࠭ࡃࡖࡗࡴ࡬࡛ࡸࡗࡣ࠳ࡪࡹ࡮ࡸࡆ࡬ࡕࡣ࠸࠷ࡖࡄࡗࡹࡆࡲࡊ࠳࡯ࡹࡹ࡭ࡔࡕࡁࡓࡄ࡮ࡒࡽࡽࡺࡏࡎࡹࡾࡇ࠳ࡌࡉࡓ࠷ࡍࡼࡺ࠸ࡓ࡙࡙࡮࠶ࡎࡄ࠳࠴ࡔ࡝ࡆ࡝ࡪࡇࡖࡋ࡙࡟ࡔࡍ࡚ࡱࡪ࠷ࡷࡌࡒ࠲࠳࡛࡭࠷ࡥ࠷ࡇࡗࡦ࡙ࡨࡕࡇࡇࡏࡽࡾࡰࡉ࡭ࡊࡱࡩࡴ࡝࠾࠱࠴࡮࡮࠹ࡩ࡫ࡄ࡮ࡊ࡬࡚ࡿࡵࡎ࡙ࡩ࠵ࡹࡗ࡯ࡡࡅࡌࡴࡨࡉ࡭࡬ࡵࡖ࠺࠼ࡆ࡮ࡍࡔࡈࡐ࡞࡭ࡵࡍࡪ࡯ࡍ࡙ࡻࡎ࡬ࡶࡷࡅ࠴࠾ࡏࡆࡄ࡭ࡈ࠴ࡒࡥ࠶ࡥࡼࡓࡽ࡮࠸࠳ࡨ࡫ࡧ࡞ࡗࡰ࡙ࡰࡦ࠻ࡴࡶ࡜࠲࠱ࡉ࠷࡝࠶ࡨࡃ࠷࡜ࡽࡸࡹࡲࡄࡣࡥࡕࡧࡨࡊࡦࡌࡣࡧࡧࡏࡻ࠹ࡆࡲࡊࡑࡨ࡜ࡌࡒࡰࡱࡆࡿࡹࡥࡕࡕ࠳ࡇࡌࡳ࠸ࡏ࠳ࡑࡰࡺࡊࡣ࡫ࡏ࡫ࡻࡳࢀ࡭࠹ࡶࡨࡘࡏࡏࡥࡨࡧࡶ࡭ࡵࡹࡈ࠸ࡓ࡝࠼࡚ࡿࡦࡨࡥࡼࡊࡕࡪ࠰࠮࠺ࡦࡓࡰࡱ࡭ࡌࡩ࡯ࡩࡊ࡛ࡄࡗ࡚ࡆࡸࡆࡱ࡚ࡔࡤ࡜ࡘ࠵࠹ࡓ࠮ࡶࡘࡵࡐࡾࡩ࡬ࡓ࠺ࡕࡽࡐࡏࡆࡘࡵࡌࡒ࠶࡙࠶ࡹ࡙࡮ࡑࡔࡔࡴ࠲ࡗ࡛ࡋ࡛ࡅࡅࡇࡲ࠹࡮࡞ࡶ࠮࠸ࡴࡻ࠾࠾ࡺࡶ࠸ࡼ࡭࡜࡯ࡑ࠳ࡲࡉࡦ࠼࡙ࡢࡹࡸࡩࡱ࡝࡮ࡋ࠴ࡳࡉ࡛ࡻࡱࡕࡄ࡮ࡻ࡮࡬ࡈࡨ࠸࡭࡙ࡹ࠺ࡺ࡫࡬ࡆࡑ࠴࠶࠷ࡓࡃ࠷ࡕࡩࡴࡉࡊࡶࡎࡧࡪࡍࡒࡴࡐࡪ࠵ࡊࡶࡠ࠲ࡸ࠹ࡓ࡬ࡌࡑࡂ࡫ࡧࡹࡨࡆࡒ࠲ࡧࡅࡕࡉ࡭࡞࠱ࡋࡶ࡜ࡒ࠽ࡿࡁࡖ࡫ࡓࡒ࡯ࡾ࡫ࡂࡄࡷࡅࡧࡳࡹࡍ࠹ࡶ࠱ࡐࡶ࠲ࡘࡤࡹࡺࡗࡷࡌ࠵࠵࠸࠻ࡹ࡚࠶࡮ࡐ࡛ࡇࡶ࡭࠭ࡧࡰࡐ࠵࡮ࡗ࠹ࡰ࡛ࡄࡸࡕ࡯࡭ࡋࡱࡧࡺࡉ࠾࡚ࡄࡍ࡜࠹ࡇ࠿࡭ࡤ࠵ࡤࡓࡺࡊࡉࡒࡼࡹ࠺ࡑ࡚࡟ࡰࡲࡨࡺ࡛ࡧ࠹࠸ࡱࡉ࠴ࡱ࡫ࡤࡪࡗ࠻࡫ࡔ࠼࠳ࡆࡷࡴࡱ࠻࡭ࡉ࠶ࡍ࠳࡮࠺࡜ࡐࡦࡘࡹࡴࡨ࠶ࡺࡺࡣ࡜࡚࡝ࡌ࠹ࡵࡺ࠸ࡕࡿࡌࡋࡵࡑࡈࡅࡈࡥࡋࡢࡖ࡫࠱ࡘࡻ࠷ࡖࡌࡱ࡛࠹ࡗࡢࡉࡗ࡬࠽ࡕࡲࡳࡨࡩࡔࡔ࠵ࡐࡁ࠶࠸ࡢ࡫࡭࡚ࡏ࠹ࡄ࡭ࡔ࡞࠸ࡵ࠹ࡍ࠼࠽ࡍࡊࡨࡠࡦࡳ࠸ࡊࡨ࠱ࡆ࠲ࡗ࠽ࡆ࠷ࡸࡵࡼࡵࡦ࡝࠹࡚ࡨࡈ࠳࠹ࡼࡉࡅࡋࡧ࠸ࡐࡲ࠸ࡱ࡙࠲ࡘࡨ࡟࡞ࡹࡠࡃ࡙ࡹࡶ࠽ࡓ࠴ࡇࡐ࠷ࡒࡰࡨࡋࡋ࡝࠱ࡐࡨࡪࡦ࠹ࡓࡳ࡫ࡷ࡬ࡹࡉࡰ࠴࠾ࡏࡨࡋࡺࡕࡧࡩࡋ࠴࡫࡚࡝࡫ࡷࡲࡤ࠸ࡣࡓ࡬ࡻ࠶ࡂࡕ࠳ࡔ࠽࠶ࡊࡘࡳࡔ࠻ࡰࡑࡺ࡙࠷ࡐࡕࡆࡸࡠࡦ࡬ࡪ࠼ࡒࠬਇ")
           }
    data=urllib.urlencode(params)
    a=l1lll1l111ll11l1_cdhd_(l1lll1ll11l1_cdhd_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࡯ࡶࡱ࠱࡭ࡴ࠵ࡧࡰ࠱ࡉ࡯ࡧࡩࡵࠨਈ"),data)
def _1lllllll1ll11l1_cdhd_(url,host=l1lll1ll11l1_cdhd_ (u"ࠧࠨਉ")):
    l111l1l11ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠨࠩਊ")
    if url.startswith(l1lll1ll11l1_cdhd_ (u"ࠩ࡫ࡸࡹࡶࠧ਋")):
        if l1lll1ll11l1_cdhd_ (u"ࠪࡰ࡮ࡴ࡫ࡪ࠰ࡲࡲࡱ࡯࡮ࡦࠩ਌") in url:
            content = l1lll1l111ll11l1_cdhd_(url)
            l1l1l1ll1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠫࡹࡵࡰ࠯࡮ࡲࡧࡦࡺࡩࡰࡰࠣࡁࠥࡡ࡜ࠨࠤࡠࠬ࠳࠰࠿ࠪ࡝࡟ࠫࠧࡣ࠻ࠨ਍")).search(content)
            if l1l1l1ll1ll11l1_cdhd_:
                l111l1l11ll11l1_cdhd_ = l1l1l1ll1ll11l1_cdhd_.group(1)
        if l1lll1ll11l1_cdhd_ (u"ࠬࡵࡵࡰ࠰࡬ࡳࠬ਎") in url:
            l111l1l11ll11l1_cdhd_ = url
        else:
            req = urllib2.Request(url)
            req.add_header(l1lll1ll11l1_cdhd_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪਏ"), l1lll1ll11l1_cdhd_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠴࠹࠰࠳࠲࠷࠻࠶࠵࠰࠼࠻࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬਐ"))
            try:
                response = urllib2.urlopen(req)
                if response:
                    l111l1l11ll11l1_cdhd_=response.url
                    if l111l1l11ll11l1_cdhd_==url:
                        content=response.read()
                        l1l1l1ll1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰ࠩࠣࠢࡦࡰࡦࡹࡳࠨ਑")).findall(content)
                        for l in l1l1l1ll1ll11l1_cdhd_:
                            if host in l:
                                l111l1l11ll11l1_cdhd_ = l
                                break
                    response.close()
            except:
                pass
    return l111l1l11ll11l1_cdhd_
def l1ll1l1111ll11l1_cdhd_(url,content=None):
    if not content:
        content = l1lll1l111ll11l1_cdhd_(url)
    out  =[]
    l1ll1l1l11ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡱࡹ࡭ࡪࡶ࡬ࡢࡻࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ਒"),re.DOTALL|re.I).findall(content)
    names = re.compile(l1lll1ll11l1_cdhd_ (u"ࠪࡀࡺࡲࠠࡤ࡮ࡤࡷࡸࡃࠢࡪࡦࡗࡥࡧࡹࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬਓ"),re.DOTALL).findall(content)
    if names:
        names = [x.strip() for x in re.compile(l1lll1ll11l1_cdhd_ (u"ࠫࡃ࠮࠮ࠫࡁࠬࡀࠬਔ"),re.DOTALL).findall(names[0]) if x.strip()]
    else:
        names=[]
    for l1111l111ll11l1_cdhd_ in l1ll1l1l11ll11l1_cdhd_:
        href = re.compile(l1lll1ll11l1_cdhd_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪਕ"),re.DOTALL|re.I).search(l1111l111ll11l1_cdhd_)
        if href:
            l1111ll11ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"࠭ࡨࡵࡶࡳࠫਖ")+ urllib.unquote(href.group(1)).split(l1lll1ll11l1_cdhd_ (u"ࠧࡩࡶࡷࡴࠬਗ"))[-1]
            if l1111ll11ll11l1_cdhd_.startswith(l1lll1ll11l1_cdhd_ (u"ࠨࡪࡷࡸࡵ࠭ਘ")) and not l1lll1ll11l1_cdhd_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪਙ") in l1111ll11ll11l1_cdhd_ and not l1lll1ll11l1_cdhd_ (u"ࠪࡪࡦࡩࡥࡣࡱࡲ࡯ࠬਚ") in l1111ll11ll11l1_cdhd_:
                host = urlparse(l1111ll11ll11l1_cdhd_).netloc
                l111l1111ll11l1_cdhd_ = {l1lll1ll11l1_cdhd_ (u"ࠫࡺࡸ࡬ࠨਛ") : l1111ll11ll11l1_cdhd_,
                    l1lll1ll11l1_cdhd_ (u"ࠬࡺࡩࡵ࡮ࡨࠫਜ"): l1lll1ll11l1_cdhd_ (u"ࠨ࡛ࠦࡵࡠࠦਝ") %(host),
                    l1lll1ll11l1_cdhd_ (u"ࠧࡩࡱࡶࡸࠬਞ"): host    }
                out.append(l111l1111ll11l1_cdhd_)
    if len(names)==len(out):
        for l111l1111ll11l1_cdhd_,name in zip(out,names):
            l111l1111ll11l1_cdhd_[l1lll1ll11l1_cdhd_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧਟ")] += l1lll1ll11l1_cdhd_ (u"ࠩࠣ࡟ࡇࡣࠥࡴ࡝࠲ࡆࡢ࠭ਠ")%name
    return out
def l1l1lll1ll11l1_cdhd_(url):
    content = l1lll1l111ll11l1_cdhd_(url)
    ids = [(a.start(), a.end()) for a in re.finditer(l1lll1ll11l1_cdhd_ (u"ࠪࡀࡱ࡯ࠠࡤ࡮ࡤࡷࡸࡃࠢࡦ࡮ࡨࡱࡪࡴࡴࡰࠤࡁࠫਡ"), content)]
    ids.append( (-1,-1) )
    out=l1ll1l1111ll11l1_cdhd_(url,content)
    for i in range(len(ids[:-1])):
        l11l11111ll11l1_cdhd_ = content[ ids[i][1]:ids[i+1][0] ]
        href = re.compile(l1lll1ll11l1_cdhd_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ਢ"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
        host = re.compile(l1lll1ll11l1_cdhd_ (u"ࠬࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪࡂ࠾࠳࠰࠿ࠪࠤࠣࡥࡱࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿࡝࡟ࡷࡡࡴ࡝ࠬࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧਣ")).search(l11l11111ll11l1_cdhd_)
        l1lll111l1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"࠭࠼ࡴࡲࡤࡲࠥࡩ࡬ࡢࡵࡶࡁࠧࡩࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧਤ"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
        l1ll1lll11ll11l1_cdhd_ =re.compile(l1lll1ll11l1_cdhd_ (u"ࠧ࠽ࡵࡳࡥࡳࠦࡣ࡭ࡣࡶࡷࡂࠨࡤࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨਥ"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
        if href and host:
            j= l1lll111l1ll11l1_cdhd_.group(1) if l1lll111l1ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠨࠩਦ")
            q= l1ll1lll11ll11l1_cdhd_.group(1) if l1ll1lll11ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠩࠪਧ")
            host = host.groups()[-1]
            l1111ll11ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠪ࡬ࡹࡺࡰࠨਨ")+ urllib.unquote(href.group(1)).split(l1lll1ll11l1_cdhd_ (u"ࠫ࡭ࡺࡴࡱࠩ਩"))[-1]
            l1ll1l111ll11l1_cdhd_ = l1111ll11ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡩࡤࡢ࠯ࡲࡲࡱ࡯࡮ࡦ࠰ࡳࡰࡄ࠭ਪ"),l1lll1ll11l1_cdhd_ (u"࠭ࠧਫ"))
            if l1ll1l111ll11l1_cdhd_:
                msg =l1lll1ll11l1_cdhd_ (u"ࠧࠨਬ")
                if l1lll1ll11l1_cdhd_ (u"ࠨࡱࡸࡳ࠳࡯࡯ࠨਭ") in l1ll1l111ll11l1_cdhd_:
                    msg = l1lll1ll11l1_cdhd_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡵࡩࡩࡣࠠࡰࡷࡲ࠲࡮ࡵࠠ࡯ࡱࡷࠤࡸࡻࡰࡱࡱࡵࡸࡪࡪ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨਮ")
                l111l1111ll11l1_cdhd_ = {l1lll1ll11l1_cdhd_ (u"ࠪࡹࡷࡲࠧਯ") : urllib.unquote(l1ll1l111ll11l1_cdhd_),
                    l1lll1ll11l1_cdhd_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪਰ"): l1lll1ll11l1_cdhd_ (u"ࠧࡡࠥࡴ࡟ࠣࠩࡸ࠲ࠠࠦࡵࠣࠩࡸࠨ਱") %(host,j,q,msg),
                    l1lll1ll11l1_cdhd_ (u"࠭ࡨࡰࡵࡷࠫਲ"): host    }
                out.append(l111l1111ll11l1_cdhd_)
    return out
def l1111l11ll11l1_cdhd_(url):
    content = l1lll1l111ll11l1_cdhd_(url)
    l1llll1l11ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠧࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧ࠱࡮ࡳࡡࡨࡧ࠽ࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪࠩਲ਼")).findall(content)
    l1llll1l11ll11l1_cdhd_ = l1llll1l11ll11l1_cdhd_[-1] if l1llll1l11ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠨࠩ਴")
    ids = [(a.start(), a.end()) for a in re.finditer(l1lll1ll11l1_cdhd_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢ࡯ࡷࡰࡩࡷࡧ࡮ࡥࡱࠥࡂࠬਵ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11l11111ll11l1_cdhd_ = content[ ids[i][1]:ids[i+1][0] ]
        l111l1ll1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃࡡ࡜ࡴ࡞ࡱࡡ࠰࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨਸ਼"),re.DOTALL).search(l11l11111ll11l1_cdhd_)
        date = re.compile(l1lll1ll11l1_cdhd_ (u"ࠫࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥࡨࡦࡺࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨ਷")).search(l11l11111ll11l1_cdhd_)
        l1ll111ll1ll11l1_cdhd_ = re.compile(l1lll1ll11l1_cdhd_ (u"ࠬ࠮࡜ࡥ࠭ࡂ࠭ࠥࡾࠠࠩ࡞ࡧ࠯ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ਸ")).findall(l11l11111ll11l1_cdhd_)
        if l111l1ll1ll11l1_cdhd_:
            d= date.group(1) if date else l1lll1ll11l1_cdhd_ (u"࠭ࠧਹ")
            t= l111l1ll1ll11l1_cdhd_.group(2)
            l1lll11l11ll11l1_cdhd_ =l1lll1ll11l1_cdhd_ (u"ࠧࡹࠩ਺").join(l1ll111ll1ll11l1_cdhd_[0]) if l1ll111ll1ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠨࠩ਻")
            t= l1lll11l11ll11l1_cdhd_+l1lll1ll11l1_cdhd_ (u"਼ࠩࠣࠫ")+t
            l111l1111ll11l1_cdhd_ = {l1lll1ll11l1_cdhd_ (u"ࠪ࡬ࡷ࡫ࡦࠨ਽")  : l111l1ll1ll11l1_cdhd_.group(1),
                l1lll1ll11l1_cdhd_ (u"ࠫࡵࡲ࡯ࡵࠩਾ"): l1llll11l1ll11l1_cdhd_(t.strip()),
                l1lll1ll11l1_cdhd_ (u"ࠬࡺࡩࡵ࡮ࡨࠫਿ") : l1llll11l1ll11l1_cdhd_(t.strip()),
                l1lll1ll11l1_cdhd_ (u"࠭ࡩ࡮ࡩࠪੀ"):l1llll1l11ll11l1_cdhd_,
                l1lll1ll11l1_cdhd_ (u"ࠧࡴࡧࡤࡷࡴࡴࠧੁ"): int(l1ll111ll1ll11l1_cdhd_[0][0]) if l1ll111ll1ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠨࠩੂ"),
                l1lll1ll11l1_cdhd_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࠪ੃"): int(l1ll111ll1ll11l1_cdhd_[0][1]) if l1ll111ll1ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠪࠫ੄"),
                l1lll1ll11l1_cdhd_ (u"ࠫࡦ࡯ࡲࡦࡦࠪ੅") : d}
            out.append(l111l1111ll11l1_cdhd_)
    return out
def l1l1111ll11l1_cdhd_(out):
    l11111ll1ll11l1_cdhd_={}
    l11llll11ll11l1_cdhd_ = [x.get(l1lll1ll11l1_cdhd_ (u"ࠬࡹࡥࡢࡵࡲࡲࠬ੆")) for x in out]
    for s in set(l11llll11ll11l1_cdhd_):
        l11111ll1ll11l1_cdhd_[l1lll1ll11l1_cdhd_ (u"࠭ࡓࡦࡼࡲࡲࠥࠫ࠰࠳ࡦࠪੇ")%s]=[out[i] for i, j in enumerate(l11llll11ll11l1_cdhd_) if j == s]
    return l11111ll1ll11l1_cdhd_
def l11111l11ll11l1_cdhd_(m):
    return l1lll1ll11l1_cdhd_ (u"ࠧࡩࡴࡨࡪࡂࠨࠧੈ")+urllib.unquote(m.group(1))
def l1l11lll1ll11l1_cdhd_(l1l11l111ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠨࡨ࡬ࡰࡲ࠭੉"),l11lll1l1ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠩࡪࡥࡹࡻ࡮ࡦ࡭ࠪ੊")):
    content = l1lll1l111ll11l1_cdhd_(l1ll11lll1ll11l1_cdhd_)
    selected = []
    if l1l11l111ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"ࠪࡪ࡮ࡲ࡭ࠨੋ"):
        if l11lll1l1ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"ࠫ࡬ࡧࡴࡶࡰࡨ࡯ࠬੌ"):
            selected = re.compile(l1lll1ll11l1_cdhd_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵࡀ࠯࠰ࡥࡧࡥ࠲࡮ࡤ࠯ࡶࡹ࠳࡬ࡧࡴࡶࡰࡨ࡯࠴࠴ࠪࡀࠫࠥࡠࡸ࠰࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀ࡟ࡷ࠯ࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀ੍ࠪ")).findall(content)
        elif l11lll1l1ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"࠭ࡲࡰ࡭ࠪ੎"):
            selected = re.compile(l1lll1ll11l1_cdhd_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠻࠱࠲ࡧࡩࡧ࠭ࡩࡦ࠱ࡸࡻ࠵ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶ࠴ࡢࡤࡼ࠶ࢀ࡟ࡣࠨ࡝ࠫࠫࠥࡂ࠭ࡢࡤࡼ࠶ࢀ࠭ࡁ࠵ࡡ࠿ࠩ੏")).findall(content)
    elif l1l11l111ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"ࠨࡵࡨࡶ࡮ࡧ࡬ࠨ੐"):
        if l11lll1l1ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"ࠩࡪࡥࡹࡻ࡮ࡦ࡭ࠪੑ"):
            selected = re.compile(l1lll1ll11l1_cdhd_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠾࠴࠵ࡣࡥࡣ࠰࡬ࡩ࠴ࡴࡷ࠱ࡷࡺࡸ࡮࡯ࡸࡵ࠰࡫ࡪࡴࡲࡦ࠱࠱࠮ࡄ࠯ࠢ࡝ࡵ࠭ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄ࡜ࡴࠬ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ੒")).findall(content)
        elif l11lll1l1ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"ࠫࡷࡵ࡫ࠨ੓"):
            selected = re.compile(l1lll1ll11l1_cdhd_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵࡀ࠯࠰ࡥࡧࡥ࠲࡮ࡤ࠯ࡶࡹ࠳ࡹࡼࡳࡩࡱࡺࡷ࠲ࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵ࠳ࡡࡪࡻ࠵ࡿ࡞ࡢࠧࡣࠪࠪࠤࡁࠬࡡࡪࡻ࠵ࡿࠬࡀ࠴ࡧ࠾ࠨ੔")).findall(content)
    if selected:
        l1lll1ll11ll11l1_cdhd_ = [x[0] for x in selected]
        l1ll11l111ll11l1_cdhd_ = [l1llll11l1ll11l1_cdhd_(l1lll1ll11l1_cdhd_ (u"࠭ࠠࠨ੕").join(x[1:])) for x in selected]
        return (l1ll11l111ll11l1_cdhd_,l1lll1ll11ll11l1_cdhd_)
    return False
def l1llll11l1ll11l1_cdhd_(l11111111ll11l1_cdhd_):
    if isinstance(l11111111ll11l1_cdhd_, unicode):
        l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.encode(l1lll1ll11l1_cdhd_ (u"ࠧࡶࡶࡩ࠱࠽࠭੖"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠨࠨ࡯ࡸࡀࡨࡲ࠰ࠨࡪࡸࡀ࠭੗"),l1lll1ll11l1_cdhd_ (u"ࠩࠣࠫ੘"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠪࠪࡳࡨࡳࡱ࠽ࠪਖ਼"),l1lll1ll11l1_cdhd_ (u"ࠫࠬਗ਼"))
    s=l1lll1ll11l1_cdhd_ (u"ࠬࡐࡩࡏࡥ࡝ࡇࡸ࠽ࠧਜ਼")
    l11111111ll11l1_cdhd_ = re.sub(s.decode(l1lll1ll11l1_cdhd_ (u"࠭ࡢࡢࡵࡨ࠺࠹࠭ੜ")),l1lll1ll11l1_cdhd_ (u"ࠧࠨ੝"),l11111111ll11l1_cdhd_)
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠨࠨࡴࡹࡴࡺ࠻ࠨਫ਼"),l1lll1ll11l1_cdhd_ (u"ࠩࠥࠫ੟")).replace(l1lll1ll11l1_cdhd_ (u"ࠪࠪࡦࡳࡰ࠼ࡳࡸࡳࡹࡁࠧ੠"),l1lll1ll11l1_cdhd_ (u"ࠫࠧ࠭੡"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠬࠬ࡯ࡢࡥࡸࡸࡪࡁࠧ੢"),l1lll1ll11l1_cdhd_ (u"࠭ࣳࠨ੣")).replace(l1lll1ll11l1_cdhd_ (u"ࠧࠧࡑࡤࡧࡺࡺࡥ࠼ࠩ੤"),l1lll1ll11l1_cdhd_ (u"ࠨࣕࠪ੥"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠩࠩࡥࡲࡶ࠻ࡰࡣࡦࡹࡹ࡫࠻ࠨ੦"),l1lll1ll11l1_cdhd_ (u"ࠪࣷࠬ੧")).replace(l1lll1ll11l1_cdhd_ (u"ࠫࠫࡧ࡭ࡱ࠽ࡒࡥࡨࡻࡴࡦ࠽ࠪ੨"),l1lll1ll11l1_cdhd_ (u"ࠬࣙࠧ੩"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"࠭ࠦࡢ࡯ࡳ࠿ࠬ੪"),l1lll1ll11l1_cdhd_ (u"ࠧࠧࠩ੫"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠨ࡞ࡸ࠴࠶࠶࠵ࠨ੬"),l1lll1ll11l1_cdhd_ (u"ࠩईࠫ੭")).replace(l1lll1ll11l1_cdhd_ (u"ࠪࡠࡺ࠶࠱࠱࠶ࠪ੮"),l1lll1ll11l1_cdhd_ (u"ࠫउ࠭੯"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠬࡢࡵ࠱࠳࠳࠻ࠬੰ"),l1lll1ll11l1_cdhd_ (u"࠭इࠨੱ")).replace(l1lll1ll11l1_cdhd_ (u"ࠧ࡝ࡷ࠳࠵࠵࠼ࠧੲ"),l1lll1ll11l1_cdhd_ (u"ࠨईࠪੳ"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠩ࡟ࡹ࠵࠷࠱࠺ࠩੴ"),l1lll1ll11l1_cdhd_ (u"ࠪझࠬੵ")).replace(l1lll1ll11l1_cdhd_ (u"ࠫࡡࡻ࠰࠲࠳࠻ࠫ੶"),l1lll1ll11l1_cdhd_ (u"ࠬञࠧ੷"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"࠭࡜ࡶ࠲࠴࠸࠷࠭੸"),l1lll1ll11l1_cdhd_ (u"ࠧृࠩ੹")).replace(l1lll1ll11l1_cdhd_ (u"ࠨ࡞ࡸ࠴࠶࠺࠱ࠨ੺"),l1lll1ll11l1_cdhd_ (u"ࠩॄࠫ੻"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠪࡠࡺ࠶࠱࠵࠶ࠪ੼"),l1lll1ll11l1_cdhd_ (u"ࠫॉ࠭੽")).replace(l1lll1ll11l1_cdhd_ (u"ࠬࡢࡵ࠱࠳࠷࠸ࠬ੾"),l1lll1ll11l1_cdhd_ (u"࠭ृࠨ੿"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠧ࡝ࡷ࠳࠴࡫࠹ࠧ઀"),l1lll1ll11l1_cdhd_ (u"ࠨࣵࠪઁ")).replace(l1lll1ll11l1_cdhd_ (u"ࠩ࡟ࡹ࠵࠶ࡤ࠴ࠩં"),l1lll1ll11l1_cdhd_ (u"ࠪࣗࠬઃ"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠫࡡࡻ࠰࠲࠷ࡥࠫ઄"),l1lll1ll11l1_cdhd_ (u"ࠬॡࠧઅ")).replace(l1lll1ll11l1_cdhd_ (u"࠭࡜ࡶ࠲࠴࠹ࡦ࠭આ"),l1lll1ll11l1_cdhd_ (u"ࠧज़ࠩઇ"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠨ࡞ࡸ࠴࠶࠽ࡡࠨઈ"),l1lll1ll11l1_cdhd_ (u"ࠩॽࠫઉ")).replace(l1lll1ll11l1_cdhd_ (u"ࠪࡠࡺ࠶࠱࠸࠻ࠪઊ"),l1lll1ll11l1_cdhd_ (u"ࠫॾ࠭ઋ"))
    l11111111ll11l1_cdhd_ = l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠬࡢࡵ࠱࠳࠺ࡧࠬઌ"),l1lll1ll11l1_cdhd_ (u"࠭ॼࠨઍ")).replace(l1lll1ll11l1_cdhd_ (u"ࠧ࡝ࡷ࠳࠵࠼ࡨࠧ઎"),l1lll1ll11l1_cdhd_ (u"ࠨॽࠪએ"))
    return l11111111ll11l1_cdhd_
def search(l11111111ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠩ࡬ࡲࡩ࡯ࡡ࡯ࡣࠪઐ")):
    l111ll111ll11l1_cdhd_ = {
        l1lll1ll11l1_cdhd_ (u"ࠪࡌࡴࡹࡴࠨઑ"):l1lll1ll11l1_cdhd_ (u"ࠫࡦࡶࡩ࠯ࡵࡨࡥࡷࡩࡨࡪࡳ࠱ࡼࡾࢀࠧ઒"),
        l1lll1ll11l1_cdhd_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩઓ"):l1lll1ll11l1_cdhd_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠹࠲࠶ࡁࠠࡘࡑ࡚࠺࠹ࡁࠠࡳࡸ࠽࠹࠷࠴࠰ࠪࠢࡊࡩࡨࡱ࡯࠰࠴࠳࠵࠵࠶࠱࠱࠳ࠣࡊ࡮ࡸࡥࡧࡱࡻ࠳࠺࠸࠮࠱ࠩઔ"),
        l1lll1ll11l1_cdhd_ (u"ࠧࡂࡥࡦࡩࡵࡺࠧક"):l1lll1ll11l1_cdhd_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱ࠰ࠥࡺࡥࡹࡶ࠲࡮ࡦࡼࡡࡴࡥࡵ࡭ࡵࡺࠬࠡࠬ࠲࠮ࡀࠦࡱ࠾࠲࠱࠴࠶࠭ખ"),
        l1lll1ll11l1_cdhd_ (u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡏࡥࡳ࡭ࡵࡢࡩࡨࠫગ"):l1lll1ll11l1_cdhd_ (u"ࠪࡩࡳ࠳ࡕࡔ࠮ࡨࡲࡀࡷ࠽࠱࠰࠸ࠫઘ"),
        l1lll1ll11l1_cdhd_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬઙ"):l1lll1ll11l1_cdhd_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡩࡤࡢ࠯࡫ࡨ࠳ࡺࡶ࠰ࠩચ"),
        l1lll1ll11l1_cdhd_ (u"࠭ࡏࡳ࡫ࡪ࡭ࡳ࠭છ"):l1lll1ll11l1_cdhd_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡤࡦࡤ࠱࡭ࡪ࠮ࡵࡸ࠲ࠫજ"),
        l1lll1ll11l1_cdhd_ (u"ࠨࡅࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠬઝ"):l1lll1ll11l1_cdhd_ (u"ࠩ࡮ࡩࡪࡶ࠭ࡢ࡮࡬ࡺࡪ࠭ઞ"),
        l1lll1ll11l1_cdhd_ (u"ࠪࡔࡷࡧࡧ࡮ࡣࠪટ"):l1lll1ll11l1_cdhd_ (u"ࠫࡳࡵ࠭ࡤࡣࡦ࡬ࡪ࠭ઠ")}
    url=l1lll1ll11l1_cdhd_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡧࡰࡪ࠰ࡶࡩࡦࡸࡣࡩ࡫ࡴ࠲ࡽࡿࡺ࠰ࡣࡳ࡭࠴ࡹࡥࡢࡴࡦ࡬࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡱ࠾ࠧࡶࠪࡪࡴࡧࡪࡰࡨࡏࡪࡿ࠽࠴ࡥࡤ࠹࠸ࡩ࠸ࡣ࠹ࡥࡩࡨ࠼࠱࠲࠶࠷࠵ࡪࡩࡥ࠵࠸ࡦࡨ࠷࠸ࡥ࠶ࡧࡨ࠷ࠫࡶࡡࡨࡧࡀ࠴ࠫ࡯ࡴࡦ࡯ࡶࡔࡪࡸࡐࡢࡩࡨࡁ࠺࠶ࠦࡨࡴࡲࡹࡵࡃ࠱ࠧࡣࡸࡸࡴࡩ࡯࡮ࡲ࡯ࡩࡹ࡫࠽࠲ࠩડ")
    try:
        req = urllib2.Request(url%l11111111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"࠭ࠠࠨઢ"),l1lll1ll11l1_cdhd_ (u"ࠧࠦ࠴࠳ࠫણ")),data=None,headers=l111ll111ll11l1_cdhd_)
        response = urllib2.urlopen(req,timeout=10)
        dd = json.loads(response.read())
    except:
        dd={}
    data = dd.get(l1lll1ll11l1_cdhd_ (u"ࠨ࡯ࡤ࡭ࡳ࠭ત"),{}).get(l1lll1ll11l1_cdhd_ (u"ࠩࡵࡩࡨࡵࡲࡥࡵࠪથ"),[])
    l1lll1lll1ll11l1_cdhd_=[]
    l1llll1ll1ll11l1_cdhd_=[]
    for item in data:
        href = item.get(l1lll1ll11l1_cdhd_ (u"ࠪࡹࡷࡲࠧદ"),l1lll1ll11l1_cdhd_ (u"ࠫࠬધ"))
        title = item.get(l1lll1ll11l1_cdhd_ (u"ࠬࡺࡩࡵ࡮ࡨࠫન"),l1lll1ll11l1_cdhd_ (u"࠭ࠧ઩"))
        title = re.sub(l1lll1ll11l1_cdhd_ (u"ࡲࠨࠩࠪࡀࡠ࠵࡝ࠫࡧࡰࡂࠬ࠭ࠧપ"),l1lll1ll11l1_cdhd_ (u"ࠨࠢࠪફ"),title)
        l1lllll1l1ll11l1_cdhd_ = item.get(l1lll1ll11l1_cdhd_ (u"ࠩࡥࡳࡩࡿࠧબ"),l1lll1ll11l1_cdhd_ (u"ࠪࠫભ"))
        l1llll1l11ll11l1_cdhd_ = item.get(l1lll1ll11l1_cdhd_ (u"ࠫ࡮ࡳࡡࡨࡧࠪમ"),[l1lll1ll11l1_cdhd_ (u"ࠬ࠭ય")])
        l1llll1l11ll11l1_cdhd_ = l1llll1l11ll11l1_cdhd_[-1] if l1llll1l11ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"࠭ࠧર")
        if href and title:
            year = re.search(l1lll1ll11l1_cdhd_ (u"ࠧ࡝ࡦࡾ࠸ࢂ࠭઱"),title)
        l111l1111ll11l1_cdhd_ = {l1lll1ll11l1_cdhd_ (u"ࠨࡪࡵࡩ࡫࠭લ") : href,
            l1lll1ll11l1_cdhd_ (u"ࠩࡷ࡭ࡹࡲࡥࠨળ") : l1llll11l1ll11l1_cdhd_(title),
            l1lll1ll11l1_cdhd_ (u"ࠪࡴࡱࡵࡴࠨ઴") : l1llll11l1ll11l1_cdhd_(l1lllll1l1ll11l1_cdhd_) if l1lllll1l1ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠫࠬવ"),
            l1lll1ll11l1_cdhd_ (u"ࠬ࡯࡭ࡨࠩશ") : l1llll1l11ll11l1_cdhd_,
            l1lll1ll11l1_cdhd_ (u"࠭ࡹࡦࡣࡵࠫષ") : year.group() if year else l1lll1ll11l1_cdhd_ (u"ࠧࠨસ"),
                }
        if l1lll1ll11l1_cdhd_ (u"ࠨ࠱ࡷࡺࡸ࡮࡯ࡸࡵ࠲ࠫહ") in l111l1111ll11l1_cdhd_[l1lll1ll11l1_cdhd_ (u"ࠩ࡫ࡶࡪ࡬ࠧ઺")]:
            l1llll1ll1ll11l1_cdhd_.append(l111l1111ll11l1_cdhd_)
        else:
            l1lll1lll1ll11l1_cdhd_.append(l111l1111ll11l1_cdhd_)
    return l1lll1lll1ll11l1_cdhd_,l1llll1ll1ll11l1_cdhd_
