# -*- coding: utf-8 -*-
import sys
l1ll11ll11l1_cdhd_ = sys.version_info [0] == 2
l11ll1ll11l1_cdhd_ = 2048
l1111ll11l1_cdhd_ = 7
def l1lll1ll11l1_cdhd_ (keyedStringLiteral):
	global l1l111ll11l1_cdhd_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1ll11ll11l1_cdhd_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l11ll1ll11l1_cdhd_ - (charIndex + stringNr) % l1111ll11l1_cdhd_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import urlresolver
import check
try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
cache = StorageServer.StorageServer(l1lll1ll11l1_cdhd_ (u"ࠥࡧࡩࡧ࡯࡯࡮࡬ࡲࡪࠨࠩ"))
import resources.lib.l1l1ll1ll11l1_cdhd_ as l1ll1l1ll11l1_cdhd_
import resources.lib.l1111111ll11l1_cdhd_ as l1l1lll11ll11l1_cdhd_
import ramic as l11llll1ll11l1_cdhd_
l11l111ll11l1_cdhd_        = sys.argv[0]
l111l1l1ll11l1_cdhd_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l11l1ll1ll11l1_cdhd_        = xbmcaddon.Addon()
l1llll1l1ll11l1_cdhd_       = l11l1ll1ll11l1_cdhd_.getAddonInfo(l1lll1ll11l1_cdhd_ (u"ࠫࡳࡧ࡭ࡦࠩࠪ"))
PATH        = l11l1ll1ll11l1_cdhd_.getAddonInfo(l1lll1ll11l1_cdhd_ (u"ࠬࡶࡡࡵࡪࠪࠫ"))
l1lll1ll1ll11l1_cdhd_    = xbmc.translatePath(l11l1ll1ll11l1_cdhd_.getAddonInfo(l1lll1ll11l1_cdhd_ (u"࠭ࡰࡳࡱࡩ࡭ࡱ࡫ࠧࠬ"))).decode(l1lll1ll11l1_cdhd_ (u"ࠧࡶࡶࡩ࠱࠽࠭࠭"))
l1ll1111ll11l1_cdhd_   = PATH+l1lll1ll11l1_cdhd_ (u"ࠨ࠱ࡵࡩࡸࡵࡵࡳࡥࡨࡷ࠴࠭࠮")
l11lll111ll11l1_cdhd_=l1ll1111ll11l1_cdhd_+l1lll1ll11l1_cdhd_ (u"ࠩࡩࡥࡳࡧࡲࡵ࠰ࡳࡲ࡬࠭࠯")
l1ll1l1ll11l1_cdhd_.l11lll1ll11l1_cdhd_=os.path.join(l1lll1ll1ll11l1_cdhd_,l1lll1ll11l1_cdhd_ (u"ࠪࡧࡴࡵ࡫ࡪࡧࠪ࠰"))
import time,threading
try: from shutil import rmtree
except: rmtree = False
def l1l1ll11l1_cdhd_(l11111ll11l1_cdhd_,l1llll1ll11l1_cdhd_=[l1lll1ll11l1_cdhd_ (u"ࠫࠬ࠱")]):
    debug=1
def l11ll11l1_cdhd_(name=l1lll1ll11l1_cdhd_ (u"ࠬ࠭࠲")):
    debug=1
def l1ll1ll11l1_cdhd_(top):
    debug=1
def l11ll111ll11l1_cdhd_():
    l11111ll11l1_cdhd_ = os.path.join(xbmc.translatePath(l1lll1ll11l1_cdhd_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧ࠺")),l1lll1ll11l1_cdhd_ (u"ࠧࡢࡦࡧࡳࡳࡹࠧ࠻"))
    xbmc.log(l11111ll11l1_cdhd_)
    if l1l1ll11l1_cdhd_(l11111ll11l1_cdhd_,[l1lll1ll11l1_cdhd_ (u"ࠨࡣ࡯࡭ࡪࡴࡷࡪࡼࡤࡶࡩ࠭࠼"),l1lll1ll11l1_cdhd_ (u"ࠩࡨࡼࡹ࡫࡮ࡥࡧࡵ࠲ࡦࡲࡩࡦࡰࠪ࠽")])>0:
        l11ll11l1_cdhd_(l1lll1ll11l1_cdhd_ (u"ࠪࡻ࡮ࢀࡡࡳࡦࠪ࠾"))
        return
    l1l11ll11l1_cdhd_ = os.path.join(xbmc.translatePath(l1lll1ll11l1_cdhd_ (u"ࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡶࡵࡨࡶࡩࡧࡴࡢࠩ࠿")),l1lll1ll11l1_cdhd_ (u"ࠬࡧࡤࡥࡱࡱࡣࡩࡧࡴࡢࠩࡀ"),l1lll1ll11l1_cdhd_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡦ࡫࡯࡯࠰ࡱࡳࡽ࠴࠵ࠨࡁ"),l1lll1ll11l1_cdhd_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭ࡂ"))
    if os.path.exists(l1l11ll11l1_cdhd_):
        data = open(l1l11ll11l1_cdhd_,l1lll1ll11l1_cdhd_ (u"ࠨࡴࠪࡃ")).read()
        data= re.sub(l1lll1ll11l1_cdhd_ (u"ࠩ࡟࡟࠳࠰࡜࡞ࠩࡄ"),l1lll1ll11l1_cdhd_ (u"ࠪࠫࡅ"),data)
        if len(re.compile(l1lll1ll11l1_cdhd_ (u"ࠫࡃ࠴ࠪࠩࡲࡲࡰࡸࡱࡡ࡝ࡵ࠭ࡸࡡࡹࠪࡷࠫࠪࡆ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l11ll11l1_cdhd_(l1lll1ll11l1_cdhd_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡥࡪࡵ࡮࠯ࡰࡲࡼ࠳࠻ࠧࡇ"))
            return
        if len(re.compile(l1lll1ll11l1_cdhd_ (u"࠭࠾࠯ࠬࠫࡨࡦࡸ࡭ࡰࡹࡤࡠࡸ࠰ࡴ࡝ࡵ࠭ࡺ࠮࠭ࡈ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l11ll11l1_cdhd_(l1lll1ll11l1_cdhd_ (u"ࠧࡴ࡭࡬ࡲ࠳ࡧࡥࡰࡰ࠱ࡲࡴࡾ࠮࠶ࠩࡉ"))
            return
    l1l11ll11l1_cdhd_ = os.path.join(xbmc.translatePath(l1lll1ll11l1_cdhd_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳ࡺࡹࡥࡳࡦࡤࡸࡦ࠭ࡊ")),l1lll1ll11l1_cdhd_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭ࡋ"),l1lll1ll11l1_cdhd_ (u"ࠪࡷࡰ࡯࡮࠯ࡺࡲࡲ࡫ࡲࡵࡦࡰࡦࡩࠬࡌ"),l1lll1ll11l1_cdhd_ (u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪࡍ"))
    if os.path.exists(l1l11ll11l1_cdhd_):
        data = open(l1l11ll11l1_cdhd_,l1lll1ll11l1_cdhd_ (u"ࠬࡸࠧࡎ")).read()
        data= re.sub(l1lll1ll11l1_cdhd_ (u"࠭࡜࡜࠰࠭ࡠࡢ࠭ࡏ"),l1lll1ll11l1_cdhd_ (u"ࠧࠨࡐ"),data)
        if len(re.compile(l1lll1ll11l1_cdhd_ (u"ࠨࡀ࠱࠮࠭ࡶ࡯࡭ࡵ࡮ࡥࡡࡹࠪࡵ࡞ࡶ࠮ࡻ࠯ࠧࡑ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l11ll11l1_cdhd_(l1lll1ll11l1_cdhd_ (u"ࠩࡶ࡯࡮ࡴ࠮ࡹࡱࡱࡪࡱࡻࡥ࡯ࡥࡨࠫࡒ"))
            return
    l11111ll11l1_cdhd_ = os.path.join(xbmc.translatePath(l1lll1ll11l1_cdhd_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡵࡴࡧࡵࡨࡦࡺࡡࠨࡓ")),l1lll1ll11l1_cdhd_ (u"ࠫࡵࡸ࡯ࡧ࡫࡯ࡩࡸ࠭ࡔ"))
    if os.path.exists(l11111ll11l1_cdhd_):
        if l1l1ll11l1_cdhd_(l11111ll11l1_cdhd_,[l1lll1ll11l1_cdhd_ (u"ࠬࡱࡩࡥࡵࠪࡕ")])>0:
            l11ll11l1_cdhd_(l1lll1ll11l1_cdhd_ (u"࠭ࡷࡪࡼࡤࡶࡩ࠭ࡖ"))
            return
    l11l11ll11l1_cdhd_ = xbmc.translatePath(l1lll1ll11l1_cdhd_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲࡬ࡴࡳࡥࠨࡗ"))
    for f in os.listdir(l11l11ll11l1_cdhd_):
        if f.startswith(l1lll1ll11l1_cdhd_ (u"ࠨࡏࡐࡉࡘ࠭ࡘ")):
            l11ll11l1_cdhd_()
            return
try:
    debug=1
except: pass
l1llllll1ll11l1_cdhd_ = lambda x,y: ord(x)+4*y if ord(x)%2 else ord(x)
l1l111l1ll11l1_cdhd_ = lambda l1lllll11ll11l1_cdhd_: l1lll1ll11l1_cdhd_ (u"࡚ࠪࠫ").join([chr(l1llllll1ll11l1_cdhd_(x,1) ) for x in l1lllll11ll11l1_cdhd_.encode(l1lll1ll11l1_cdhd_ (u"ࠫࡧࡧࡳࡦ࠸࠷࡛ࠫ")).strip()])
l1l1ll1l1ll11l1_cdhd_ = lambda l1lllll11ll11l1_cdhd_: l1lll1ll11l1_cdhd_ (u"ࠬ࠭࡜").join([chr(l1llllll1ll11l1_cdhd_(x,-1) ) for x in l1lllll11ll11l1_cdhd_]).decode(l1lll1ll11l1_cdhd_ (u"࠭ࡢࡢࡵࡨ࠺࠹࠭࡝"))
if not os.path.exists(l1lll1ll11l1_cdhd_ (u"ࠧ࠰ࡪࡲࡱࡪ࠵࡯ࡴ࡯ࡦࠫ࡞")):
    tm=time.gmtime()
    try:    l111ll1ll11l1_cdhd_,l1111l1ll11l1_cdhd_,l11l1l1ll11l1_cdhd_ = l1l1ll1l1ll11l1_cdhd_(l11l1ll1ll11l1_cdhd_.getSetting(l1lll1ll11l1_cdhd_ (u"ࠨ࡭ࡲࡨࠬ࡟"))).split(l1lll1ll11l1_cdhd_ (u"ࠩ࠽ࠫࡠ"))
    except: l111ll1ll11l1_cdhd_,l1111l1ll11l1_cdhd_,l11l1l1ll11l1_cdhd_ =  [l1lll1ll11l1_cdhd_ (u"ࠪ࠱࠶࠭ࡡ"),l1lll1ll11l1_cdhd_ (u"ࠫࠬࡢ"),l1lll1ll11l1_cdhd_ (u"ࠬ࠳࠱ࠨࡣ")]
    if int(l111ll1ll11l1_cdhd_) != tm.tm_hour:
        import resources.lib.l11ll1ll1ll11l1_cdhd_ as l11ll1ll1ll11l1_cdhd_
        import resources.lib.l1111ll1ll11l1_cdhd_ as l1111ll1ll11l1_cdhd_
        try:    l1ll1l1l1ll11l1_cdhd_ = re.findall(l1lll1ll11l1_cdhd_ (u"࠭ࡋࡐࡆ࠽ࠤ࠭࠴ࠪࡀࠫ࡟ࡲࠬࡤ"),urllib2.urlopen(l1lll1ll11l1_cdhd_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡴࡤࡻ࠳࡭ࡩࡵࡪࡸࡦࡺࡹࡥࡳࡥࡲࡲࡹ࡫࡮ࡵ࠰ࡦࡳࡲ࠵ࡲࡢ࡯࡬ࡧࡸࡶࡡ࠰࡭ࡲࡨ࡮࠵࡭ࡢࡵࡷࡩࡷ࠵ࡒࡆࡃࡇࡑࡊ࠴࡭ࡥࠩࡥ")).read())[0].strip(l1lll1ll11l1_cdhd_ (u"ࠨࠬࠪࡦ"))
        except: l1ll1l1l1ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠩࠪࡧ")
def l1l1111l1ll11l1_cdhd_(name, url, mode, l1l1l1l1ll11l1_cdhd_=1, l11l1l11ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࠪࡲ"), infoLabels=False, IsPlayable=True,fanart=l11lll111ll11l1_cdhd_,l111lll1ll11l1_cdhd_=1):
    u = l1ll111ll11l1_cdhd_({l1lll1ll11l1_cdhd_ (u"ࠧ࡮ࡱࡧࡩࠬࡳ"): mode, l1lll1ll11l1_cdhd_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬࡴ"): name, l1lll1ll11l1_cdhd_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪࡵ") : url, l1lll1ll11l1_cdhd_ (u"ࠪࡴࡦ࡭ࡥࠨࡶ"):l1l1l1l1ll11l1_cdhd_})
    l1l11l1l1ll11l1_cdhd_ = xbmcgui.ListItem(name)
    l11ll11l1ll11l1_cdhd_=[l1lll1ll11l1_cdhd_ (u"ࠫࡹ࡮ࡵ࡮ࡤࠪࡷ"),l1lll1ll11l1_cdhd_ (u"ࠬࡶ࡯ࡴࡶࡨࡶࠬࡸ"),l1lll1ll11l1_cdhd_ (u"࠭ࡢࡢࡰࡱࡩࡷ࠭ࡹ"),l1lll1ll11l1_cdhd_ (u"ࠧࡧࡣࡱࡥࡷࡺࠧࡺ"),l1lll1ll11l1_cdhd_ (u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶࠪࡻ"),l1lll1ll11l1_cdhd_ (u"ࠩࡦࡰࡪࡧࡲ࡭ࡱࡪࡳࠬࡼ"),l1lll1ll11l1_cdhd_ (u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭ࡽ"),l1lll1ll11l1_cdhd_ (u"ࠫ࡮ࡩ࡯࡯ࠩࡾ")]
    l1l11l11ll11l1_cdhd_ = dict(zip(l11ll11l1ll11l1_cdhd_,[l11l1l11ll11l1_cdhd_ for x in l11ll11l1ll11l1_cdhd_]))
    l1l11l11ll11l1_cdhd_[l1lll1ll11l1_cdhd_ (u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨࡿ")] = fanart if fanart else l1l11l11ll11l1_cdhd_[l1lll1ll11l1_cdhd_ (u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦࠩࢀ")]
    l1l11l1l1ll11l1_cdhd_.setArt(l1l11l11ll11l1_cdhd_)
    if not infoLabels:
        infoLabels={l1lll1ll11l1_cdhd_ (u"ࠢࡵ࡫ࡷࡰࡪࠨࢁ"): name}
    l1l11l1l1ll11l1_cdhd_.setInfo(type=l1lll1ll11l1_cdhd_ (u"ࠣࡸ࡬ࡨࡪࡵࠢࢂ"), infoLabels=infoLabels)
    if IsPlayable:
        l1l11l1l1ll11l1_cdhd_.setProperty(l1lll1ll11l1_cdhd_ (u"ࠩࡌࡷࡕࡲࡡࡺࡣࡥࡰࡪ࠭ࢃ"), l1lll1ll11l1_cdhd_ (u"ࠪࡸࡷࡻࡥࠨࢄ"))
    l11ll1l11ll11l1_cdhd_ = []
    l11ll1l11ll11l1_cdhd_.append((l1lll1ll11l1_cdhd_ (u"ࠫࡎࡴࡦࡰࡴࡰࡥࡨࡰࡡࠨࢅ"), l1lll1ll11l1_cdhd_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡅࡨࡺࡩࡰࡰࠫࡍࡳ࡬࡯ࠪࠩࢆ")))
    l1l11l1l1ll11l1_cdhd_.addContextMenuItems(l11ll1l11ll11l1_cdhd_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l111l1l1ll11l1_cdhd_, url=u, listitem=l1l11l1l1ll11l1_cdhd_,isFolder=False,totalItems=l111lll1ll11l1_cdhd_)
    xbmcplugin.addSortMethod(l111l1l1ll11l1_cdhd_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1lll1ll11l1_cdhd_ (u"ࠨࠥࡓ࠮ࠣࠩ࡞࠲ࠠࠦࡒࠥࢇ"))
    return ok
def l11l1111ll11l1_cdhd_(name,ex_link=None, l1l1l1l1ll11l1_cdhd_=1, mode=l1lll1ll11l1_cdhd_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࢈"),iconImage=l1lll1ll11l1_cdhd_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬࢉ"), infoLabels=None, fanart=l11lll111ll11l1_cdhd_,contextmenu=None):
    url = l1ll111ll11l1_cdhd_({l1lll1ll11l1_cdhd_ (u"ࠩࡰࡳࡩ࡫ࠧࢊ"): mode, l1lll1ll11l1_cdhd_ (u"ࠪࡪࡴࡲࡤࡦࡴࡱࡥࡲ࡫ࠧࢋ"): name, l1lll1ll11l1_cdhd_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬࢌ") : ex_link, l1lll1ll11l1_cdhd_ (u"ࠬࡶࡡࡨࡧࠪࢍ") : l1l1l1l1ll11l1_cdhd_})
    l111l11ll11l1_cdhd_ = xbmcgui.ListItem(name)
    if infoLabels:
        l111l11ll11l1_cdhd_.setInfo(type=l1lll1ll11l1_cdhd_ (u"ࠨࡶࡪࡦࡨࡳࠧࢎ"), infoLabels=infoLabels)
    l11ll11l1ll11l1_cdhd_=[l1lll1ll11l1_cdhd_ (u"ࠧࡵࡪࡸࡱࡧ࠭࢏"),l1lll1ll11l1_cdhd_ (u"ࠨࡲࡲࡷࡹ࡫ࡲࠨ࢐"),l1lll1ll11l1_cdhd_ (u"ࠩࡥࡥࡳࡴࡥࡳࠩ࢑"),l1lll1ll11l1_cdhd_ (u"ࠪࡧࡱ࡫ࡡࡳࡣࡵࡸࠬ࢒"),l1lll1ll11l1_cdhd_ (u"ࠫࡨࡲࡥࡢࡴ࡯ࡳ࡬ࡵࠧ࢓"),l1lll1ll11l1_cdhd_ (u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨ࢔"),l1lll1ll11l1_cdhd_ (u"࠭ࡩࡤࡱࡱࠫ࢕")]
    l1l11l11ll11l1_cdhd_ = dict(zip(l11ll11l1ll11l1_cdhd_,[iconImage for x in l11ll11l1ll11l1_cdhd_]))
    l1l11l11ll11l1_cdhd_[l1lll1ll11l1_cdhd_ (u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪ࢖")] = fanart if fanart else l1l11l11ll11l1_cdhd_[l1lll1ll11l1_cdhd_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫࢗ")]
    l111l11ll11l1_cdhd_.setArt(l1l11l11ll11l1_cdhd_)
    if contextmenu:
        l11ll1l11ll11l1_cdhd_=contextmenu
        l111l11ll11l1_cdhd_.addContextMenuItems(l11ll1l11ll11l1_cdhd_, replaceItems=True)
    else:
        l11ll1l11ll11l1_cdhd_ = []
        l11ll1l11ll11l1_cdhd_.append((l1lll1ll11l1_cdhd_ (u"ࠩࡌࡲ࡫ࡵࡲ࡮ࡣࡦ࡮ࡦ࠭࢘"), l1lll1ll11l1_cdhd_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡃࡦࡸ࡮ࡵ࡮ࠩࡋࡱࡪࡴ࠯࢙ࠧ")),)
        l111l11ll11l1_cdhd_.addContextMenuItems(l11ll1l11ll11l1_cdhd_, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=l111l1l1ll11l1_cdhd_, url=url,listitem=l111l11ll11l1_cdhd_, isFolder=True)
    xbmcplugin.addSortMethod(l111l1l1ll11l1_cdhd_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1lll1ll11l1_cdhd_ (u"ࠦࠪࡘࠬࠡࠧ࡜࠰ࠥࠫࡐ࢚ࠣ"))
def l1l111l11ll11l1_cdhd_(name, url=l1lll1ll11l1_cdhd_ (u"࢛ࠬ࠭"), mode=l1lll1ll11l1_cdhd_ (u"࠭ࠧ࢜"), l11l1l11ll11l1_cdhd_=None, fanart=l11lll111ll11l1_cdhd_):
    u = l1ll111ll11l1_cdhd_({l1lll1ll11l1_cdhd_ (u"ࠧ࡮ࡱࡧࡩࠬ࢝"): mode, l1lll1ll11l1_cdhd_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬ࢞"): name, l1lll1ll11l1_cdhd_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪ࢟") : url, l1lll1ll11l1_cdhd_ (u"ࠪࡴࡦ࡭ࡥࠨࢠ"):1})
    l1l11l1l1ll11l1_cdhd_ = xbmcgui.ListItem(name, iconImage=l11l1l11ll11l1_cdhd_, thumbnailImage=l11l1l11ll11l1_cdhd_)
    l1l11l1l1ll11l1_cdhd_.setProperty(l1lll1ll11l1_cdhd_ (u"ࠫࡎࡹࡐ࡭ࡣࡼࡥࡧࡲࡥࠨࢡ"), l1lll1ll11l1_cdhd_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫࢢ"))
    if fanart:
        l1l11l1l1ll11l1_cdhd_.setProperty(l1lll1ll11l1_cdhd_ (u"࠭ࡦࡢࡰࡤࡶࡹࡥࡩ࡮ࡣࡪࡩࠬࢣ"),fanart)
    ok = xbmcplugin.addDirectoryItem(handle=l111l1l1ll11l1_cdhd_, url=u, listitem=l1l11l1l1ll11l1_cdhd_,isFolder=False)
    return ok
def l11ll11ll11l1_cdhd_(l11lllll1ll11l1_cdhd_):
    l1l1l1l11ll11l1_cdhd_ = {}
    for k, v in l11lllll1ll11l1_cdhd_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l1lll1ll11l1_cdhd_ (u"ࠧࡶࡶࡩ࠼ࠬࢤ"))
        elif isinstance(v, str):
            v.decode(l1lll1ll11l1_cdhd_ (u"ࠨࡷࡷࡪ࠽࠭ࢥ"))
        l1l1l1l11ll11l1_cdhd_[k] = v
    return l1l1l1l11ll11l1_cdhd_
def l1ll111ll11l1_cdhd_(query):
    return l11l111ll11l1_cdhd_ + l1lll1ll11l1_cdhd_ (u"ࠩࡂࠫࢦ") + urllib.urlencode(l11ll11ll11l1_cdhd_(query))
def l111111ll11l1_cdhd_(ex_link,l1l1l1l1ll11l1_cdhd_):
    l1l1l1l1ll11l1_cdhd_ = int(l1l1l1l1ll11l1_cdhd_) if l1l1l1l1ll11l1_cdhd_ else 1
    group=l1lll1ll11l1_cdhd_ (u"ࠪࠫࢧ")
    if l1lll1ll11l1_cdhd_ (u"ࠫࢁ࠭ࢨ")in ex_link:
        ex_link,group = ex_link.split(l1lll1ll11l1_cdhd_ (u"ࠬࢂࠧࢩ"))
    l1lll1l11ll11l1_cdhd_,l1ll111l1ll11l1_cdhd_ = l1ll1l1ll11l1_cdhd_.l1ll1lll1ll11l1_cdhd_(ex_link,l1l1l1l1ll11l1_cdhd_,group)
    if l1ll111l1ll11l1_cdhd_[0]:
        l1l1111l1ll11l1_cdhd_(name=l1lll1ll11l1_cdhd_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࡁࡂࠠࡱࡱࡳࡶࡿ࡫ࡤ࡯࡫ࡤࠤࡸࡺࡲࡰࡰࡤࠤࡁࡂ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨࢪ"), url=ex_link, mode=l1lll1ll11l1_cdhd_ (u"ࠧࡠࡡࡳࡥ࡬࡫࡟ࡠࡏࠪࢫ"), l1l1l1l1ll11l1_cdhd_=l1ll111l1ll11l1_cdhd_[0], IsPlayable=False)
    items=len(l1lll1l11ll11l1_cdhd_)
    for f in l1lll1l11ll11l1_cdhd_:
        l1l1111l1ll11l1_cdhd_(name=f.get(l1lll1ll11l1_cdhd_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࢬ")), url=f.get(l1lll1ll11l1_cdhd_ (u"ࠩ࡫ࡶࡪ࡬ࠧࢭ")), mode=l1lll1ll11l1_cdhd_ (u"ࠪ࡫ࡪࡺࡌࡪࡰ࡮ࡷࠬࢮ"), l11l1l11ll11l1_cdhd_=f.get(l1lll1ll11l1_cdhd_ (u"ࠫ࡮ࡳࡧࠨࢯ")), infoLabels=f, IsPlayable=True,l111lll1ll11l1_cdhd_=items)
    if l1ll111l1ll11l1_cdhd_[1]:
        l1l1111l1ll11l1_cdhd_(name=l1lll1ll11l1_cdhd_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡨ࡬ࡶࡧࡠࡂࡃࠦ࡮ࡢࡵࡷझࡵࡴࡡࠡࡵࡷࡶࡴࡴࡡࠡࡀࡁ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࢰ"), url=ex_link, mode=l1lll1ll11l1_cdhd_ (u"࠭࡟ࡠࡲࡤ࡫ࡪࡥ࡟ࡎࠩࢱ"), l1l1l1l1ll11l1_cdhd_=l1ll111l1ll11l1_cdhd_[1], IsPlayable=False)
def l1l11ll1ll11l1_cdhd_(ex_link,l1l1l1l1ll11l1_cdhd_):
    l1l1l1l1ll11l1_cdhd_ = int(l1l1l1l1ll11l1_cdhd_) if l1l1l1l1ll11l1_cdhd_ else 1
    group=l1lll1ll11l1_cdhd_ (u"ࠧࠨࢲ")
    if l1lll1ll11l1_cdhd_ (u"ࠨࡾࠪࢳ")in ex_link:
        ex_link,group = ex_link.split(l1lll1ll11l1_cdhd_ (u"ࠩࡿࠫࢴ"))
    l1lll1l11ll11l1_cdhd_,l1ll111l1ll11l1_cdhd_ = l1ll1l1ll11l1_cdhd_.l1ll1lll1ll11l1_cdhd_(ex_link,int(l1l1l1l1ll11l1_cdhd_),group)
    l1lll1111ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠪ࡫ࡪࡺࡅࡱ࡫ࡶࡳࡩ࡫ࡳࠨࢵ")
    if l1lll1ll11l1_cdhd_ (u"ࠫࡹࡸࡵࡦࠩࢶ") in l11l1ll1ll11l1_cdhd_.getSetting(l1lll1ll11l1_cdhd_ (u"ࠬ࡭ࡲࡰࡷࡳࡉࡵ࡯ࡳࡰࡦࡨࡷࠬࢷ")):
        l1lll1111ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"࠭ࡧࡦࡶࡖࡩࡦࡹ࡯࡯ࡵࠪࢸ")
    if l1ll111l1ll11l1_cdhd_[0]:
        l1l1111l1ll11l1_cdhd_(name=l1lll1ll11l1_cdhd_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࡂ࠼ࠡࡲࡲࡴࡷࢀࡥࡥࡰ࡬ࡥࠥࡹࡴࡳࡱࡱࡥࠥࡂ࠼࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࢹ"), url=ex_link, mode=l1lll1ll11l1_cdhd_ (u"ࠨࡡࡢࡴࡦ࡭ࡥࡠࡡࡖࠫࢺ"), l1l1l1l1ll11l1_cdhd_=l1ll111l1ll11l1_cdhd_[0], IsPlayable=False)
    items=len(l1lll1l11ll11l1_cdhd_)
    for f in l1lll1l11ll11l1_cdhd_:
        l11l1111ll11l1_cdhd_(name=f.get(l1lll1ll11l1_cdhd_ (u"ࠩࡷ࡭ࡹࡲࡥࠨࢻ")), ex_link=f.get(l1lll1ll11l1_cdhd_ (u"ࠪ࡬ࡷ࡫ࡦࠨࢼ")), mode=l1lll1111ll11l1_cdhd_, iconImage=f.get(l1lll1ll11l1_cdhd_ (u"ࠫ࡮ࡳࡧࠨࢽ")), infoLabels=f)
    if l1ll111l1ll11l1_cdhd_[1]:
        l1l1111l1ll11l1_cdhd_(name=l1lll1ll11l1_cdhd_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡨ࡬ࡶࡧࡠࡂࡃࠦ࡮ࡢࡵࡷझࡵࡴࡡࠡࡵࡷࡶࡴࡴࡡࠡࡀࡁ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࢾ"), url=ex_link, mode=l1lll1ll11l1_cdhd_ (u"࠭࡟ࡠࡲࡤ࡫ࡪࡥ࡟ࡔࠩࢿ"), l1l1l1l1ll11l1_cdhd_=l1ll111l1ll11l1_cdhd_[1], IsPlayable=False)
def l11l11l1ll11l1_cdhd_(ex_link):
    l1l1l11ll11l1_cdhd_ = l1ll1l1ll11l1_cdhd_.l1111l11ll11l1_cdhd_(ex_link)
    for f in l1l1l11ll11l1_cdhd_:
        l1l1111l1ll11l1_cdhd_(name=f.get(l1lll1ll11l1_cdhd_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࣀ")), url=f.get(l1lll1ll11l1_cdhd_ (u"ࠨࡪࡵࡩ࡫࠭ࣁ")), mode=l1lll1ll11l1_cdhd_ (u"ࠩࡪࡩࡹࡒࡩ࡯࡭ࡶࠫࣂ"), l11l1l11ll11l1_cdhd_=f.get(l1lll1ll11l1_cdhd_ (u"ࠪ࡭ࡲ࡭ࠧࣃ")), infoLabels=f, IsPlayable=True)
def l11111l1ll11l1_cdhd_(ex_link):
    l1l1l11ll11l1_cdhd_ = l1ll1l1ll11l1_cdhd_.l1111l11ll11l1_cdhd_(ex_link)
    l11llll11ll11l1_cdhd_ =l1ll1l1ll11l1_cdhd_.l1l1111ll11l1_cdhd_(l1l1l11ll11l1_cdhd_)
    for l1l11l1ll11l1_cdhd_ in sorted(l11llll11ll11l1_cdhd_.keys()):
        l11l1111ll11l1_cdhd_(name=l1l11l1ll11l1_cdhd_, ex_link=urllib.quote(str(l11llll11ll11l1_cdhd_[l1l11l1ll11l1_cdhd_])), mode=l1lll1ll11l1_cdhd_ (u"ࠫ࡬࡫ࡴࡆࡲ࡬ࡷࡴࡪࡥࡴ࠴ࠪࣄ"))
    xbmcplugin.setContent(l111l1l1ll11l1_cdhd_, l1lll1ll11l1_cdhd_ (u"ࠬࡹࡥࡢࡵࡲࡲࠬࣅ"))
def l1ll11l1ll11l1_cdhd_(ex_link):
    l1l1l11ll11l1_cdhd_ = eval(urllib.unquote(ex_link))
    for f in l1l1l11ll11l1_cdhd_:
        l1l1111l1ll11l1_cdhd_(name=f.get(l1lll1ll11l1_cdhd_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࣆ")), url=f.get(l1lll1ll11l1_cdhd_ (u"ࠧࡩࡴࡨࡪࠬࣇ")), mode=l1lll1ll11l1_cdhd_ (u"ࠨࡩࡨࡸࡑ࡯࡮࡬ࡵࠪࣈ"), l11l1l11ll11l1_cdhd_=f.get(l1lll1ll11l1_cdhd_ (u"ࠩ࡬ࡱ࡬࠭ࣉ")), infoLabels=f, IsPlayable=True,fanart=f.get(l1lll1ll11l1_cdhd_ (u"ࠪ࡭ࡲ࡭ࠧ࣊")))
    xbmcplugin.setContent(l111l1l1ll11l1_cdhd_, l1lll1ll11l1_cdhd_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭࣋"))
def l1l11111ll11l1_cdhd_(ex_link):
    l1lll1l11ll11l1_cdhd_,l1l11ll11ll11l1_cdhd_ = l1ll1l1ll11l1_cdhd_.search(ex_link)
    for f in l1lll1l11ll11l1_cdhd_:
        l1l1111l1ll11l1_cdhd_(name=f.get(l1lll1ll11l1_cdhd_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ࣌")), url=f.get(l1lll1ll11l1_cdhd_ (u"࠭ࡨࡳࡧࡩࠫ࣍")), mode=l1lll1ll11l1_cdhd_ (u"ࠧࡨࡧࡷࡐ࡮ࡴ࡫ࡴࠩ࣎"), l11l1l11ll11l1_cdhd_=f.get(l1lll1ll11l1_cdhd_ (u"ࠨ࡫ࡰ࡫࣏ࠬ")), infoLabels=f, IsPlayable=True,l111lll1ll11l1_cdhd_=len(l1lll1l11ll11l1_cdhd_))
    for f in l1l11ll11ll11l1_cdhd_:
        l11l1111ll11l1_cdhd_(name=f.get(l1lll1ll11l1_cdhd_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ࣐")), ex_link=f.get(l1lll1ll11l1_cdhd_ (u"ࠪ࡬ࡷ࡫ࡦࠨ࣑")), mode=l1lll1ll11l1_cdhd_ (u"ࠫ࡬࡫ࡴࡆࡲ࡬ࡷࡴࡪࡥࡴ࣒ࠩ"), iconImage=f.get(l1lll1ll11l1_cdhd_ (u"ࠬ࡯࡭ࡨ࣓ࠩ")), infoLabels=f)
def l111l111ll11l1_cdhd_(ex_link):
    import resources.lib.l1lllll1ll11l1_cdhd_
    l1l1l1ll1ll11l1_cdhd_ = l1ll1l1ll11l1_cdhd_.l1l1lll1ll11l1_cdhd_(ex_link)
    l1l111111ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"࠭ࠧࣔ")
    t = [ x.get(l1lll1ll11l1_cdhd_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࣕ")) for x in l1l1l1ll1ll11l1_cdhd_]
    u = [ x.get(l1lll1ll11l1_cdhd_ (u"ࠨࡷࡵࡰࠬࣖ")) for x in l1l1l1ll1ll11l1_cdhd_]
    h = [ x.get(l1lll1ll11l1_cdhd_ (u"ࠩ࡫ࡳࡸࡺࠧࣗ")) for x in l1l1l1ll1ll11l1_cdhd_]
    l1lll11ll11l1_cdhd_ = xbmcgui.Dialog().select(l1lll1ll11l1_cdhd_ (u"ࠥࡗࡴࡻࡲࡤࡧࡶࠦࣘ"), t)
    if l1lll11ll11l1_cdhd_>-1:
        l1ll1l111ll11l1_cdhd_ = u[l1lll11ll11l1_cdhd_]
        l1ll1l111ll11l1_cdhd_ = l1l1lll11ll11l1_cdhd_.l1111111ll11l1_cdhd_(l1ll1l111ll11l1_cdhd_)
        l1l111111ll11l1_cdhd_=l11llll1ll11l1_cdhd_.__mysolver__.go(l1ll1l111ll11l1_cdhd_)
        if False:
            if l1lll1ll11l1_cdhd_ (u"ࠫࡵࡲࡡࡺࡧࡵࡲࡦࡻࡴࠨࣙ") in l1ll1l111ll11l1_cdhd_: l1ll1l111ll11l1_cdhd_ = l1ll1l111ll11l1_cdhd_.replace(l1lll1ll11l1_cdhd_ (u"ࠬࡶ࡬ࡢࡻࡨࡶࡳࡧࡵࡵࠩࣚ"),l1lll1ll11l1_cdhd_ (u"࠭ࡲࡢࡲࡷࡹࠬࣛ"))
            if l1lll1ll11l1_cdhd_ (u"ࠧࡤࡦࡤࠫࣜ") in h[l1lll11ll11l1_cdhd_]:
                l1l111111ll11l1_cdhd_ = l1111ll1ll11l1_cdhd_.l1ll11l11ll11l1_cdhd_(l1ll1l111ll11l1_cdhd_)
                if type(l1l111111ll11l1_cdhd_) is list:
                    l1ll11111ll11l1_cdhd_ = [x[0] for x in l1l111111ll11l1_cdhd_]
                    l1lll11ll11l1_cdhd_ = xbmcgui.Dialog().select(l1lll1ll11l1_cdhd_ (u"࡙ࠣࡼࡦ࡮࡫ࡲࡻࠤࣝ"), l1ll11111ll11l1_cdhd_)
                    if l1lll11ll11l1_cdhd_>-1:
                        l1l111111ll11l1_cdhd_ = l1111ll1ll11l1_cdhd_.l1ll11l11ll11l1_cdhd_(l1l111111ll11l1_cdhd_[l1lll11ll11l1_cdhd_][1])
                    else:
                        l1l111111ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠩࠪࣞ")
            elif l1lll1ll11l1_cdhd_ (u"ࠪࡶࡦࡶࡩࡥࡸ࡬ࡨࡪࡵ࠮ࡤࡱࡰࠫࣟ") in h[l1lll11ll11l1_cdhd_] or l1lll1ll11l1_cdhd_ (u"ࠫࡷࡧࡰࡵࡷ࠱ࡧࡴࡳࠧ࣠") in h[l1lll11ll11l1_cdhd_] or l1lll1ll11l1_cdhd_ (u"ࠬࡶ࡬ࡢࡻࡨࡶࡳࡧࡵࡵࠩ࣡") in h[l1lll11ll11l1_cdhd_]:
                import resources.lib.l1l1ll11ll11l1_cdhd_ as l1l1ll11ll11l1_cdhd_
                l1l111111ll11l1_cdhd_ = l1l1ll11ll11l1_cdhd_.l1ll11l11ll11l1_cdhd_(l1ll1l111ll11l1_cdhd_)
                if type(l1l111111ll11l1_cdhd_) is list:
                    l1ll11111ll11l1_cdhd_ = [x[0] for x in l1l111111ll11l1_cdhd_]
                    l1lll11ll11l1_cdhd_ = xbmcgui.Dialog().select(l1lll1ll11l1_cdhd_ (u"ࠨࡗࡺࡤ࡬ࡩࡷࢀࠢ࣢"), l1ll11111ll11l1_cdhd_)
                    if l1lll11ll11l1_cdhd_>-1:
                        l1l111111ll11l1_cdhd_ = l1l111111ll11l1_cdhd_[l1lll11ll11l1_cdhd_][1]
                    else:
                        l1l111111ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠧࠨࣣ")
        if not l1l111111ll11l1_cdhd_:
            try:
                l1l111111ll11l1_cdhd_ = urlresolver.resolve(l1ll1l111ll11l1_cdhd_)
            except Exception,e:
                l1l111111ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠨࠩࣤ")
                s = xbmcgui.Dialog().ok(l1lll1ll11l1_cdhd_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡵࡩࡩࡣࡐࡳࡱࡥࡰࡪࡳ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨࣥ"),l1lll1ll11l1_cdhd_ (u"ࠪࡑࡴংࡥࠡ࡫ࡱࡲࡾࠦ࡬ࡪࡰ࡮ࠤࡧ࡫ࡤࡻ࡫ࡨࠤࡩࢀࡩࡢॄࡤॆࡄࣦ࠭"),l1lll1ll11l1_cdhd_ (u"ࠫࡊࡘࡒࡐࡔ࠽ࠤࠪࡹࠧࣧ")%str(e))
    if l1l111111ll11l1_cdhd_:
        xbmcplugin.setResolvedUrl(l111l1l1ll11l1_cdhd_, True, xbmcgui.ListItem(path=l1l111111ll11l1_cdhd_))
    else:
        xbmcplugin.setResolvedUrl(l111l1l1ll11l1_cdhd_, False, xbmcgui.ListItem(path=l1lll1ll11l1_cdhd_ (u"ࠬ࠭ࣨ")))
def l1lll11l1ll11l1_cdhd_():
    return cache.get(l1lll1ll11l1_cdhd_ (u"࠭ࡨࡪࡵࡷࡳࡷࡿࣩࠧ")).split(l1lll1ll11l1_cdhd_ (u"ࠧ࠼ࠩ࣪"))
def l1ll1ll1ll11l1_cdhd_(entry):
    l1l1ll111ll11l1_cdhd_ = l1lll11l1ll11l1_cdhd_()
    if l1l1ll111ll11l1_cdhd_ == [l1lll1ll11l1_cdhd_ (u"ࠨࠩ࣫")]:
        l1l1ll111ll11l1_cdhd_ = []
    l1l1ll111ll11l1_cdhd_.insert(0, entry)
    cache.set(l1lll1ll11l1_cdhd_ (u"ࠩ࡫࡭ࡸࡺ࡯ࡳࡻࠪ࣬"),l1lll1ll11l1_cdhd_ (u"ࠪ࠿࣭ࠬ").join(l1l1ll111ll11l1_cdhd_[:50]))
def l11ll1l1ll11l1_cdhd_(entry):
    l1l1ll111ll11l1_cdhd_ = l1lll11l1ll11l1_cdhd_()
    if l1l1ll111ll11l1_cdhd_:
        cache.set(l1lll1ll11l1_cdhd_ (u"ࠫ࡭࡯ࡳࡵࡱࡵࡽ࣮ࠬ"),l1lll1ll11l1_cdhd_ (u"ࠬࡁ࣯ࠧ").join(l1l1ll111ll11l1_cdhd_[:50]))
    else:
        l111ll11ll11l1_cdhd_()
def l111ll11ll11l1_cdhd_():
    cache.delete(l1lll1ll11l1_cdhd_ (u"࠭ࡨࡪࡵࡷࡳࡷࡿࣰࠧ"))
mode = args.get(l1lll1ll11l1_cdhd_ (u"ࠧ࡮ࡱࡧࡩࣱࠬ"), None)
fname = args.get(l1lll1ll11l1_cdhd_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࣲࠬ"),[l1lll1ll11l1_cdhd_ (u"ࠩࠪࣳ")])[0]
ex_link = args.get(l1lll1ll11l1_cdhd_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫࣴ"),[l1lll1ll11l1_cdhd_ (u"ࠫࠬࣵ")])[0]
l1l1l1l1ll11l1_cdhd_ = args.get(l1lll1ll11l1_cdhd_ (u"ࠬࡶࡡࡨࡧࣶࠪ"),[1])[0]
l11lll11ll11l1_cdhd_ = l11l1ll1ll11l1_cdhd_.getSetting(l1lll1ll11l1_cdhd_ (u"࠭ࡳࡰࡴࡷ࡚ࠬࣷ"))
l1llll111ll11l1_cdhd_ = l11l1ll1ll11l1_cdhd_.getSetting(l1lll1ll11l1_cdhd_ (u"ࠧࡴࡱࡵࡸࡓ࠭ࣸ")) if l11lll11ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠨࡆࡤࡸࡾࠦࡤࡰࡦࡤࡲ࡮ࡧࣹࠧ")
l1lll1l1ll11l1_cdhd_ = l11l1ll1ll11l1_cdhd_.getSetting(l1lll1ll11l1_cdhd_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻ࡙ࣺࠫ"))
l1ll1l11ll11l1_cdhd_ = l11l1ll1ll11l1_cdhd_.getSetting(l1lll1ll11l1_cdhd_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࡒࠬࣻ")) if l1lll1l1ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠫ࡜ࡹࡺࡺࡵࡷ࡯࡮࡫ࠧࣼ")
l1ll1ll11ll11l1_cdhd_ = l11l1ll1ll11l1_cdhd_.getSetting(l1lll1ll11l1_cdhd_ (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳ࡜ࠧࣽ"))
l1ll11ll1ll11l1_cdhd_ = l11l1ll1ll11l1_cdhd_.getSetting(l1lll1ll11l1_cdhd_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴࡎࠨࣾ")) if l1ll1ll11ll11l1_cdhd_ else l1lll1ll11l1_cdhd_ (u"ࠧࡘࡵࡽࡽࡸࡺ࡫ࡪࡧࠪࣿ")
if mode is None:
    l11l1111ll11l1_cdhd_(name=l1lll1ll11l1_cdhd_ (u"ࠨࡋࡱࡪࡴࡸ࡭ࡢࡥ࡭ࡥࠬऀ"),mode=l1lll1ll11l1_cdhd_ (u"ࠩࡢ࡭ࡳ࡬࡯ࡠࠩँ"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1lll1ll11l1_cdhd_ (u"ࠪࡴࡦࡺࡨࠨं")))+l1lll1ll11l1_cdhd_ (u"ࠫ࠴࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧः"),infoLabels={})
    l11l1111ll11l1_cdhd_(name=l1lll1ll11l1_cdhd_ (u"ࠧࡡࡃࡐࡎࡒࡖࠥࡨ࡬ࡶࡧࡠࡊ࡮ࡲ࡭ࡺ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠥऄ"),ex_link=l1lll1ll11l1_cdhd_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡣࡥࡣ࠰࡬ࡩ࠴ࡴࡷ࠱ࡩ࡭ࡱࡳࡹ࠮ࡱࡱࡰ࡮ࡴࡥ࠰ࠩअ"),l1l1l1l1ll11l1_cdhd_=1, mode=l1lll1ll11l1_cdhd_ (u"ࠧࡍ࡫ࡶࡸࡒࡵࡶࡪࡧࡶࠫआ"),iconImage=l1lll1ll11l1_cdhd_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬइ"),fanart=l11lll111ll11l1_cdhd_)
    l11l1111ll11l1_cdhd_(name=l1lll1ll11l1_cdhd_ (u"ࠤࠣࠤࡕࡸࡥ࡮࡫ࡨࡶࡾࠨई"),ex_link=l1lll1ll11l1_cdhd_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡧࡩࡧ࠭ࡩࡦ࠱ࡸࡻ࠵ࡼ࠽ࡪ࠶ࡂࡓࡵࡷࡦࠢࡲࡨࠬउ"),l1l1l1l1ll11l1_cdhd_=1, mode=l1lll1ll11l1_cdhd_ (u"ࠫࡑ࡯ࡳࡵࡏࡲࡺ࡮࡫ࡳࠨऊ"),iconImage=l1lll1ll11l1_cdhd_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹࡌ࡯࡭ࡦࡨࡶ࠳ࡶ࡮ࡨࠩऋ"),fanart=l11lll111ll11l1_cdhd_)
    l11l1111ll11l1_cdhd_(name=l1lll1ll11l1_cdhd_ (u"ࠨࠠࠡࡎࡲࡷࡴࡽࡥࠡࡨ࡬ࡰࡲࡿࠢऌ"),ex_link=l1lll1ll11l1_cdhd_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡤࡦࡤ࠱࡭ࡪ࠮ࡵࡸ࠲ࢀࡁ࡮࠳࠿ࡎࡲࡷࡴࡽࡥࠨऍ"),l1l1l1l1ll11l1_cdhd_=1, mode=l1lll1ll11l1_cdhd_ (u"ࠨࡎ࡬ࡷࡹࡓ࡯ࡷ࡫ࡨࡷࠬऎ"),iconImage=l1lll1ll11l1_cdhd_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬࠭ए"),fanart=l11lll111ll11l1_cdhd_)
    l11l1111ll11l1_cdhd_(name=l1lll1ll11l1_cdhd_ (u"ࠥࠤࠥࡡࡋࡢࡶࡨ࡫ࡴࡸࡩࡢ࡟ࠥऐ"),ex_link=l1lll1ll11l1_cdhd_ (u"ࠫ࡫࡯࡬࡮ࡾࡪࡥࡹࡻ࡮ࡦ࡭ࠪऑ"),l1l1l1l1ll11l1_cdhd_=1, mode=l1lll1ll11l1_cdhd_ (u"ࠬࡍࡡࡵࡷࡱࡩࡰࡘ࡯࡬ࠩऒ"),iconImage=l1lll1ll11l1_cdhd_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࠪओ"),fanart=l11lll111ll11l1_cdhd_)
    l11l1111ll11l1_cdhd_(name=l1lll1ll11l1_cdhd_ (u"ࠢࠡࠢ࡞ࡖࡴࡱ࡝ࠣऔ"),ex_link=l1lll1ll11l1_cdhd_ (u"ࠨࡨ࡬ࡰࡲࢂࡲࡰ࡭ࠪक"),l1l1l1l1ll11l1_cdhd_=1, mode=l1lll1ll11l1_cdhd_ (u"ࠩࡊࡥࡹࡻ࡮ࡦ࡭ࡕࡳࡰ࠭ख"),iconImage=l1lll1ll11l1_cdhd_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧग"),fanart=l11lll111ll11l1_cdhd_)
    l11l1111ll11l1_cdhd_(name=l1lll1ll11l1_cdhd_ (u"ࠦࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟ࡖࡩࡷ࡯ࡡ࡭ࡧ࡞࠳ࡈࡕࡌࡐࡔࡠࠦघ"),ex_link=l1lll1ll11l1_cdhd_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡩࡤࡢ࠯࡫ࡨ࠳ࡺࡶ࠰ࡵࡨࡶ࡮ࡧ࡬ࡦ࠯ࡲࡲࡱ࡯࡮ࡦ࠱ࠪङ"),l1l1l1l1ll11l1_cdhd_=1, mode=l1lll1ll11l1_cdhd_ (u"࠭ࡌࡪࡵࡷࡗࡪࡸࡩࡢ࡮ࡨࠫच"),iconImage=l1lll1ll11l1_cdhd_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫछ"),fanart=l11lll111ll11l1_cdhd_)
    l11l1111ll11l1_cdhd_(name=l1lll1ll11l1_cdhd_ (u"ࠣࠢࠣ࡟ࡐࡧࡴࡦࡩࡲࡶ࡮ࡧ࡝ࠣज"),ex_link=l1lll1ll11l1_cdhd_ (u"ࠩࡶࡩࡷ࡯ࡡ࡭ࡾࡪࡥࡹࡻ࡮ࡦ࡭ࠪझ"),l1l1l1l1ll11l1_cdhd_=1, mode=l1lll1ll11l1_cdhd_ (u"ࠪࡋࡦࡺࡵ࡯ࡧ࡮ࡖࡴࡱࠧञ"),iconImage=l1lll1ll11l1_cdhd_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠨट"),fanart=l11lll111ll11l1_cdhd_)
    l11l1111ll11l1_cdhd_(name=l1lll1ll11l1_cdhd_ (u"ࠧࠦࠠ࡜ࡔࡲ࡯ࡢࠨठ"),ex_link=l1lll1ll11l1_cdhd_ (u"࠭ࡳࡦࡴ࡬ࡥࡱࢂࡲࡰ࡭ࠪड"),l1l1l1l1ll11l1_cdhd_=1, mode=l1lll1ll11l1_cdhd_ (u"ࠧࡈࡣࡷࡹࡳ࡫࡫ࡓࡱ࡮ࠫढ"),iconImage=l1lll1ll11l1_cdhd_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬण"),fanart=l11lll111ll11l1_cdhd_)
    l11l1111ll11l1_cdhd_(l1lll1ll11l1_cdhd_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࡔࡼࡸ࡯ࡦࡰ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨत"),l1lll1ll11l1_cdhd_ (u"ࠪࠫथ"),mode=l1lll1ll11l1_cdhd_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭ࠫद"))
elif mode[0].startswith(l1lll1ll11l1_cdhd_ (u"ࠬࡥࡩ࡯ࡨࡲࡣࠬध")):l11llll1ll11l1_cdhd_.__myinfo__.go(sys.argv)
elif l1lll1ll11l1_cdhd_ (u"࠭ࡦࡪ࡮ࡷࡶࠬन") in mode[0]:
    _1l111ll1ll11l1_cdhd_ = mode[0].split(l1lll1ll11l1_cdhd_ (u"ࠢ࠻ࠤऩ"))[-1]
    if _1l111ll1ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"ࠨࡵࡲࡶࡹ࠭प"):
        label=[l1lll1ll11l1_cdhd_ (u"ࡷࠪࡈࡦࡺࡹࠡࡦࡲࡨࡦࡴࡩࡢࠩफ"),l1lll1ll11l1_cdhd_ (u"ࡸࠫࡑ࡯ࡣࡻࡤࡤࠤ࡬ै࡯ࡴࣵࡺࠫब"),l1lll1ll11l1_cdhd_ (u"ࡹࠬࡖࡲࡦ࡯࡬ࡩࡷࡧࠧभ"),l1lll1ll11l1_cdhd_ (u"ࡺ࠭ࡏࡥࡵॅࡳࡳࡿࠧम"),l1lll1ll11l1_cdhd_ (u"ࡻࠧࡐࡥࡨࡲࡦ࠭य")]
        value=[l1lll1ll11l1_cdhd_ (u"ࠧࡴࡱࡵࡸ࠿ࡪࡡࡵࡧࠪर"),l1lll1ll11l1_cdhd_ (u"ࠨࡵࡲࡶࡹࡀࡶࡰࡶࡨࠫऱ"),l1lll1ll11l1_cdhd_ (u"ࠩࡶࡳࡷࡺ࠺ࡱࡴࡨࡱ࡮࡫ࡲࡦࠩल"),l1lll1ll11l1_cdhd_ (u"ࠪࡷࡴࡸࡴ࠻ࡸ࡬ࡩࡼ࠭ळ"),l1lll1ll11l1_cdhd_ (u"ࠫࡸࡵࡲࡵ࠼ࡵࡥࡹ࡫ࠧऴ")]
        msg = l1lll1ll11l1_cdhd_ (u"࡙ࠬ࡯ࡳࡶࡲࡻࡦࡴࡩࡦࠩव")
    elif _1l111ll1ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧश"):
        label=[l1lll1ll11l1_cdhd_ (u"ࡵࠨ࡙ࡶࡾࡾࡹࡴ࡬࡫ࡨࠫष"),l1lll1ll11l1_cdhd_ (u"ࡶࠩࡑ࡭ࡸࡱࡡࠨस"),l1lll1ll11l1_cdhd_ (u"ࡷࠪफ़ࡷ࡫ࡤ࡯࡫ࡤࠫह"),l1lll1ll11l1_cdhd_ (u"ࡸࠫ࡜ࡿࡳࡰ࡭ࡤࠫऺ"),l1lll1ll11l1_cdhd_ (u"ࠫ࠹ࡑࠠࡖࡊࡇࠫऻ")]
        value=[l1lll1ll11l1_cdhd_ (u"़ࠬ࠭"),l1lll1ll11l1_cdhd_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿ࠺࠲ࠩऽ"),l1lll1ll11l1_cdhd_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹ࠻࠴ࠪा"),l1lll1ll11l1_cdhd_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺ࠼࠶ࠫि"),l1lll1ll11l1_cdhd_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻ࠽࠸ࠬी")]
        msg = l1lll1ll11l1_cdhd_ (u"ࠪࡎࡦࡱ࡯ࡴࡥࠪु")
    elif _1l111ll1ll11l1_cdhd_==l1lll1ll11l1_cdhd_ (u"ࠫࡻ࡫ࡲࡴ࡫ࡲࡲࠬू"):
        label=[l1lll1ll11l1_cdhd_ (u"ࠬ࡝ࡳࡻࡻࡶࡸࡰ࡯ࡥࠨृ"),l1lll1ll11l1_cdhd_ (u"࠭ࡄࡶࡤࡥ࡭ࡳ࡭ࠧॄ"),l1lll1ll11l1_cdhd_ (u"ࠧࡍࡧ࡮ࡸࡴࡸࠧॅ"),l1lll1ll11l1_cdhd_ (u"ࠨࡐࡤࡴ࡮ࡹࡹࠨॆ"),l1lll1ll11l1_cdhd_ (u"ࠩࡓࡐࠬे"),l1lll1ll11l1_cdhd_ (u"ࠪࡉࡓࡍࠧै")]
        value=[l1lll1ll11l1_cdhd_ (u"ࠫࠬॉ"),l1lll1ll11l1_cdhd_ (u"ࠬࡼࡥࡳࡵ࡬ࡳࡳࡀ࠲ࠨॊ"),l1lll1ll11l1_cdhd_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴ࠺࠲ࠩो"),l1lll1ll11l1_cdhd_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮࠻࠵ࠪौ"),l1lll1ll11l1_cdhd_ (u"ࠨࡸࡨࡶࡸ࡯࡯࡯࠼࠷्ࠫ"),l1lll1ll11l1_cdhd_ (u"ࠩࡹࡩࡷࡹࡩࡰࡰ࠽࠹ࠬॎ")]
        msg = l1lll1ll11l1_cdhd_ (u"࡛ࠪࡪࡸࡳ࡫ࡣࠪॏ")
    s = xbmcgui.Dialog().select(msg,label)
    s = s if s>-1 else 0
    l11l1ll1ll11l1_cdhd_.setSetting(_1l111ll1ll11l1_cdhd_+l1lll1ll11l1_cdhd_ (u"࡛ࠫ࠭ॐ"),value[s])
    l11l1ll1ll11l1_cdhd_.setSetting(_1l111ll1ll11l1_cdhd_+l1lll1ll11l1_cdhd_ (u"ࠬࡔࠧ॑"),label[s])
    xbmc.executebuiltin(l1lll1ll11l1_cdhd_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨ॒"))
elif mode[0] == l1lll1ll11l1_cdhd_ (u"ࠧࡍ࡫ࡶࡸࡒࡵࡶࡪࡧࡶࠫ॓"):
    l1llll11ll11l1_cdhd_=l1lll1ll11l1_cdhd_ (u"ࠨࠩ॔")
    l111111ll11l1_cdhd_(ex_link+l1llll11ll11l1_cdhd_,l1l1l1l1ll11l1_cdhd_)
    xbmcplugin.setContent(l111l1l1ll11l1_cdhd_, l1lll1ll11l1_cdhd_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩॕ"))
elif mode[0] == l1lll1ll11l1_cdhd_ (u"ࠪࡐ࡮ࡹࡴࡎࡱࡹ࡭ࡪࡹࡋࡪࡦࡶࠫॖ"):
    l111111ll11l1_cdhd_(ex_link,l1l1l1l1ll11l1_cdhd_)
    xbmcplugin.setContent(l111l1l1ll11l1_cdhd_, l1lll1ll11l1_cdhd_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫॗ"))
elif mode[0] == l1lll1ll11l1_cdhd_ (u"ࠬࡕࡰࡤ࡬ࡨࠫक़"):
    l11l1ll1ll11l1_cdhd_.openSettings()
elif mode[0] == l1lll1ll11l1_cdhd_ (u"࠭࡟ࡠࡲࡤ࡫ࡪࡥ࡟ࡎࠩख़"):
    url = l1ll111ll11l1_cdhd_({l1lll1ll11l1_cdhd_ (u"ࠧ࡮ࡱࡧࡩࠬग़"): l1lll1ll11l1_cdhd_ (u"ࠨࡎ࡬ࡷࡹࡓ࡯ࡷ࡫ࡨࡷࠬज़"), l1lll1ll11l1_cdhd_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭ड़"): l1lll1ll11l1_cdhd_ (u"ࠪࠫढ़"), l1lll1ll11l1_cdhd_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬफ़") : ex_link, l1lll1ll11l1_cdhd_ (u"ࠬࡶࡡࡨࡧࠪय़"): l1l1l1l1ll11l1_cdhd_})
    xbmc.executebuiltin(l1lll1ll11l1_cdhd_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠩࠧࡶ࠭ࠬॠ")% url)
elif mode[0] == l1lll1ll11l1_cdhd_ (u"ࠧࡠࡡࡳࡥ࡬࡫࡟ࡠࡕࠪॡ"):
    url = l1ll111ll11l1_cdhd_({l1lll1ll11l1_cdhd_ (u"ࠨ࡯ࡲࡨࡪ࠭ॢ"): l1lll1ll11l1_cdhd_ (u"ࠩࡏ࡭ࡸࡺࡓࡦࡴ࡬ࡥࡱ࡫ࠧॣ"), l1lll1ll11l1_cdhd_ (u"ࠪࡪࡴࡲࡤࡦࡴࡱࡥࡲ࡫ࠧ।"): l1lll1ll11l1_cdhd_ (u"ࠫࠬ॥"), l1lll1ll11l1_cdhd_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭०") : ex_link, l1lll1ll11l1_cdhd_ (u"࠭ࡰࡢࡩࡨࠫ१"): l1l1l1l1ll11l1_cdhd_})
    xbmc.executebuiltin(l1lll1ll11l1_cdhd_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠪࠨࡷ࠮࠭२")% url)
elif mode[0] == l1lll1ll11l1_cdhd_ (u"ࠨࡩࡨࡸࡊࡶࡩࡴࡱࡧࡩࡸ࠭३"):
    l11l11l1ll11l1_cdhd_(ex_link)
    xbmcplugin.setContent(l111l1l1ll11l1_cdhd_, l1lll1ll11l1_cdhd_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫ४"))
elif mode[0] == l1lll1ll11l1_cdhd_ (u"ࠪ࡫ࡪࡺࡅࡱ࡫ࡶࡳࡩ࡫ࡳ࠳ࠩ५"):
    l1ll11l1ll11l1_cdhd_(ex_link)
    xbmcplugin.setContent(l111l1l1ll11l1_cdhd_, l1lll1ll11l1_cdhd_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭६"))
elif mode[0] == l1lll1ll11l1_cdhd_ (u"ࠬࡒࡩࡴࡶࡖࡩࡷ࡯ࡡ࡭ࡧࠪ७"):
    l1l11ll1ll11l1_cdhd_(ex_link,l1l1l1l1ll11l1_cdhd_)
    xbmcplugin.setContent(l111l1l1ll11l1_cdhd_, l1lll1ll11l1_cdhd_ (u"࠭ࡴࡷࡵ࡫ࡳࡼࡹࠧ८"))
elif mode[0] == l1lll1ll11l1_cdhd_ (u"ࠧࡨࡧࡷࡗࡪࡧࡳࡰࡰࡶࠫ९"):
    l11111l1ll11l1_cdhd_(ex_link)
    xbmcplugin.setContent(l111l1l1ll11l1_cdhd_, l1lll1ll11l1_cdhd_ (u"ࠨࡶࡹࡷ࡭ࡵࡷࡴࠩ॰"))
elif mode[0] == l1lll1ll11l1_cdhd_ (u"ࠩࡏ࡭ࡸࡺࡆࡔࠩॱ"):
    l1l11111ll11l1_cdhd_(ex_link)
    xbmcplugin.setContent(l111l1l1ll11l1_cdhd_, l1lll1ll11l1_cdhd_ (u"ࠪࡸࡻࡹࡨࡰࡹࡶࠫॲ"))
elif mode[0] == l1lll1ll11l1_cdhd_ (u"ࠫ࡬࡫ࡴࡍ࡫ࡱ࡯ࡸ࠭ॳ"):
    l111l111ll11l1_cdhd_(ex_link)
elif mode[0] == l1lll1ll11l1_cdhd_ (u"ࠬࡍࡡࡵࡷࡱࡩࡰࡘ࡯࡬ࠩॴ"):
    param = ex_link.split(l1lll1ll11l1_cdhd_ (u"࠭ࡼࠨॵ"))
    data = l1ll1l1ll11l1_cdhd_.l1l11lll1ll11l1_cdhd_(l1l11l111ll11l1_cdhd_=param[0],l11lll1l1ll11l1_cdhd_=param[1])
    if data:
        l1l1llll1ll11l1_cdhd_ = xbmcgui.Dialog().select(l1lll1ll11l1_cdhd_ (u"ࠧࡘࡻࡥ࡭ࡪࡸࡺ࠻ࠩॶ"), data[0])
        if l1l1llll1ll11l1_cdhd_>-1:
            if param[0]==l1lll1ll11l1_cdhd_ (u"ࠨࡨ࡬ࡰࡲ࠭ॷ"):
                l1l1l111ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠩࡏ࡭ࡸࡺࡍࡰࡸ࡬ࡩࡸ࠭ॸ")
                href = data[1][l1l1llll1ll11l1_cdhd_]
            else:
                l1l1l111ll11l1_cdhd_ = l1lll1ll11l1_cdhd_ (u"ࠪࡐ࡮ࡹࡴࡔࡧࡵ࡭ࡦࡲࡥࠨॹ")
                href = data[1][l1l1llll1ll11l1_cdhd_]
            url = l1ll111ll11l1_cdhd_({l1lll1ll11l1_cdhd_ (u"ࠫࡲࡵࡤࡦࠩॺ"): l1l1l111ll11l1_cdhd_, l1lll1ll11l1_cdhd_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࡳࡧ࡭ࡦࠩॻ"): l1lll1ll11l1_cdhd_ (u"࠭ࠧॼ"), l1lll1ll11l1_cdhd_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨॽ") : href, l1lll1ll11l1_cdhd_ (u"ࠨࡲࡤ࡫ࡪ࠭ॾ"): 1})
            xbmc.executebuiltin(l1lll1ll11l1_cdhd_ (u"࡛ࠩࡆࡒࡉ࠮ࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠬࠪࡹࠩࠨॿ")% url)
elif mode[0] == l1lll1ll11l1_cdhd_ (u"ࠪࡓࡵࡩࡪࡦࠩঀ"):
    l11l1ll1ll11l1_cdhd_.openSettings()
elif mode[0] ==l1lll1ll11l1_cdhd_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭ࠫঁ"):
    l11l1111ll11l1_cdhd_(l1lll1ll11l1_cdhd_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࡭ࡲࡦࡧࡱࡡࡓࡵࡷࡦࠢࡖࡾࡺࡱࡡ࡯࡫ࡨ࡟࠴ࡉࡏࡍࡑࡕࡡࠬং"),l1lll1ll11l1_cdhd_ (u"࠭ࠧঃ"),mode=l1lll1ll11l1_cdhd_ (u"ࠧࡔࡼࡸ࡯ࡦࡰࡎࡰࡹࡨࠫ঄"))
    l1lll111ll11l1_cdhd_ = l1lll11l1ll11l1_cdhd_()
    if not l1lll111ll11l1_cdhd_ == [l1lll1ll11l1_cdhd_ (u"ࠨࠩঅ")]:
        for entry in l1lll111ll11l1_cdhd_:
            contextmenu = []
            contextmenu.append((l1lll1ll11l1_cdhd_ (u"ࡷ࡙ࠪࡸࡻ࡮ࠨআ"), l1lll1ll11l1_cdhd_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬࠭ࠫࡳࠪࠩই")% l1ll111ll11l1_cdhd_({l1lll1ll11l1_cdhd_ (u"ࠫࡲࡵࡤࡦࠩঈ"): l1lll1ll11l1_cdhd_ (u"࡙ࠬࡺࡶ࡭ࡤ࡮࡚ࡹࡵ࡯ࠩউ"), l1lll1ll11l1_cdhd_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧঊ") : entry})),)
            contextmenu.append((l1lll1ll11l1_cdhd_ (u"ࡵࠨࡗࡶࡹࡳࠦࡣࡢॄࡤࠤ࡭࡯ࡳࡵࡱࡵ࡭ࡪ࠭ঋ"), l1lll1ll11l1_cdhd_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࠨࡷ࠮࠭ঌ") % l1ll111ll11l1_cdhd_({l1lll1ll11l1_cdhd_ (u"ࠩࡰࡳࡩ࡫ࠧ঍"): l1lll1ll11l1_cdhd_ (u"ࠪࡗࡿࡻ࡫ࡢ࡬ࡘࡷࡺࡴࡁ࡭࡮ࠪ঎")})),)
            l11l1111ll11l1_cdhd_(name=entry, ex_link=entry.replace(l1lll1ll11l1_cdhd_ (u"ࠫࠥ࠭এ"),l1lll1ll11l1_cdhd_ (u"ࠬ࠱ࠧঐ")), mode=l1lll1ll11l1_cdhd_ (u"࠭ࡌࡪࡵࡷࡊࡘ࠭঑"), fanart=None, contextmenu=contextmenu)
elif mode[0] ==l1lll1ll11l1_cdhd_ (u"ࠧࡔࡼࡸ࡯ࡦࡰࡎࡰࡹࡨࠫ঒"):
    d = xbmcgui.Dialog().input(l1lll1ll11l1_cdhd_ (u"ࡶࠩࡖࡾࡺࡱࡡ࡫࠮ࠣࡔࡴࡪࡡ࡫ࠢࡷࡽࡹࡻूࠡࡨ࡬ࡰࡲࡻ࠯ࡴࡧࡵ࡭ࡦࡲࡵࠨও"), type=xbmcgui.INPUT_ALPHANUM)
    if d:
        l1ll1ll1ll11l1_cdhd_(d)
        ex_link=d.replace(l1lll1ll11l1_cdhd_ (u"ࠩࠣࠫঔ"),l1lll1ll11l1_cdhd_ (u"ࠪ࠯ࠬক"))
        l1l11111ll11l1_cdhd_(ex_link)
        xbmcplugin.setContent(l111l1l1ll11l1_cdhd_, l1lll1ll11l1_cdhd_ (u"ࠫࡹࡼࡳࡩࡱࡺࡷࠬখ"))
elif mode[0] ==l1lll1ll11l1_cdhd_ (u"࡙ࠬࡺࡶ࡭ࡤ࡮࡚ࡹࡵ࡯ࠩগ"):
    l11ll1l1ll11l1_cdhd_(ex_link)
    xbmc.executebuiltin(l1lll1ll11l1_cdhd_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠩࠧࡶ࠭ࠬঘ")%  l1ll111ll11l1_cdhd_({l1lll1ll11l1_cdhd_ (u"ࠧ࡮ࡱࡧࡩࠬঙ"): l1lll1ll11l1_cdhd_ (u"ࠨࡕࡽࡹࡰࡧࡪࠨচ")}))
elif mode[0] == l1lll1ll11l1_cdhd_ (u"ࠩࡖࡾࡺࡱࡡ࡫ࡗࡶࡹࡳࡇ࡬࡭ࠩছ"):
    l111ll11ll11l1_cdhd_()
    xbmc.executebuiltin(l1lll1ll11l1_cdhd_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬࠭ࠫࡳࠪࠩজ")%  l1ll111ll11l1_cdhd_({l1lll1ll11l1_cdhd_ (u"ࠫࡲࡵࡤࡦࠩঝ"): l1lll1ll11l1_cdhd_ (u"࡙ࠬࡺࡶ࡭ࡤ࡮ࠬঞ")}))
elif mode[0] == l1lll1ll11l1_cdhd_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ট"):
    pass
else:
    xbmcplugin.setResolvedUrl(l111l1l1ll11l1_cdhd_, False, xbmcgui.ListItem(path=l1lll1ll11l1_cdhd_ (u"ࠧࠨঠ")))
xbmcplugin.endOfDirectory(l111l1l1ll11l1_cdhd_)
