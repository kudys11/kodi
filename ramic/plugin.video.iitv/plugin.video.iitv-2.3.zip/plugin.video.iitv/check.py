# -*- coding: utf-8 -*-
import sys
l1lll1l_ii_ = sys.version_info [0] == 2
l1ll1l_ii_ = 2048
l11lll1_ii_ = 7
def l111ll_ii_ (ll_ii_):
	global l1lll11_ii_
	l1lll1_ii_ = ord (ll_ii_ [-1])
	l1llll1_ii_ = ll_ii_ [:-1]
	l11l_ii_ = l1lll1_ii_ % len (l1llll1_ii_)
	l111_ii_ = l1llll1_ii_ [:l11l_ii_] + l1llll1_ii_ [l11l_ii_:]
	if l1lll1l_ii_:
		l1l1ll1_ii_ = unicode () .join ([unichr (ord (char) - l1ll1l_ii_ - (l11l1l_ii_ + l1lll1_ii_) % l11lll1_ii_) for l11l1l_ii_, char in enumerate (l111_ii_)])
	else:
		l1l1ll1_ii_ = str () .join ([chr (ord (char) - l1ll1l_ii_ - (l11l1l_ii_ + l1lll1_ii_) % l11lll1_ii_) for l11l1l_ii_, char in enumerate (l111_ii_)])
	return eval (l1l1ll1_ii_)
import xbmc,xbmcgui
import time,re,os,threading
try: from shutil import rmtree
except: rmtree = False
def _11111l_ii_(l1l1lll_ii_):
    import json,xbmcplugin,urllib2
    url=l111ll_ii_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡧࡶ࡮ࡼࡥ࠯ࡩࡲࡳ࡬ࡲࡥ࠯ࡥࡲࡱ࠴ࡻࡣࡀࡧࡻࡴࡴࡸࡴ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࠩ࡭ࡩࡃࠧࡴ")
    try:
        l1llll11_ii_ = json.load(urllib2.urlopen(url+l111ll_ii_ (u"ࠩ࠳ࡆ࠵ࡖ࡭࡭ࡘࡌࡼࡾ࡭࡫ࡵࡧࡱࡊࡐࡕࡓ࠲ࡴࡦ࠷ࡊ࠶ࡕࡖ࠲ࠪࡵ")))
    except:
        l1llll11_ii_=[{l111ll_ii_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩࡶ"):l111ll_ii_ (u"ࠫࡒࡵॼࡦࠢࡦࡳॠࠦࡳࡪछࠣࡸࡺࠦࡰࡰ࡬ࡤࡻ࡮࠭ࡷ")}]
    for l1lll1ll_ii_ in l1llll11_ii_:
        l1lllll_ii_ = xbmcgui.ListItem(l1lll1ll_ii_.get(l111ll_ii_ (u"ࠬࡺࡩࡵ࡮ࡨࠫࡸ")), iconImage=l1lll1ll_ii_.get(l111ll_ii_ (u"࠭ࡩ࡮ࡩࠪࡹ")) , thumbnailImage=l1lll1ll_ii_.get(l111ll_ii_ (u"ࠧࡧࡣࡱࡥࡷࡺࠧࡺ")) )
        l1lllll_ii_.setInfo(type=l111ll_ii_ (u"ࠣࡘ࡬ࡨࡪࡵࠢࡻ"), infoLabels=l1lll1ll_ii_)
        l1lllll_ii_.setProperty(l111ll_ii_ (u"ࠩࡌࡷࡕࡲࡡࡺࡣࡥࡰࡪ࠭ࡼ"), l111ll_ii_ (u"ࠪࡪࡦࡲࡳࡦࠩࡽ"))
        l1lllll_ii_.setProperty(l111ll_ii_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࡣ࡮ࡳࡡࡨࡧࠪࡾ"),l1lll1ll_ii_.get(l111ll_ii_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࠬࡿ")))
        xbmcplugin.addDirectoryItem(handle=l1l1lll_ii_, url=l1lll1ll_ii_.get(l111ll_ii_ (u"࠭ࡵࡳ࡮ࠪࢀ")), listitem=l1lllll_ii_, isFolder=False)
def l1111ll_ii_(l1lll11l_ii_,l1lll111_ii_=[l111ll_ii_ (u"ࠧࠨࢁ")]):
    debug=1
def l111l11_ii_(name=l111ll_ii_ (u"ࠨࠩࢂ")):
    debug=1
def l111111_ii_(top):
    debug=1
def check():
    debug=1
try:
    debug=1
except: pass
def run():
    try:
        debug=1
    except: pass
