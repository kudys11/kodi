# -*- coding: utf-8 -*-
import sys
l1lll1l_ii_ = sys.version_info [0] == 2
l1ll1l_ii_ = 2048
l11lll1_ii_ = 7
def l111ll_ii_ (ll_ii_):
	global l1lll11_ii_
	l1lll1_ii_ = ord (ll_ii_ [-1])
	l1llll1_ii_ = ll_ii_ [:-1]
	l11l_ii_ = l1lll1_ii_ % len (l1llll1_ii_)
	l111_ii_ = l1llll1_ii_ [:l11l_ii_] + l1llll1_ii_ [l11l_ii_:]
	if l1lll1l_ii_:
		l1l1ll1_ii_ = unicode () .join ([unichr (ord (char) - l1ll1l_ii_ - (l11l1l_ii_ + l1lll1_ii_) % l11lll1_ii_) for l11l1l_ii_, char in enumerate (l111_ii_)])
	else:
		l1l1ll1_ii_ = str () .join ([chr (ord (char) - l1ll1l_ii_ - (l11l1l_ii_ + l1lll1_ii_) % l11lll1_ii_) for l11l1l_ii_, char in enumerate (l111_ii_)])
	return eval (l1l1ll1_ii_)
import sys,re,os
import urllib,urllib2
import urlparse,time
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import urlresolver
l1l11l_ii_        = sys.argv[0]
l1l1lll_ii_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l11l11l_ii_        = xbmcaddon.Addon()
l11_ii_       = l11l11l_ii_.getAddonInfo(l111ll_ii_ (u"ࠫࡳࡧ࡭ࡦࠩࠀ"))
l11l111_ii_     = l11l11l_ii_.getAddonInfo(l111ll_ii_ (u"ࠬ࡯ࡤࠨࠁ"))
l11ll1l_ii_      = None
import resources.lib.l11l11_ii_ as l11l11_ii_
import resources.lib.l1ll11l_ii_ as l1ll11l_ii_
import ramic as l111l_ii_
def l1ll1ll_ii_(name, url, mode, l111ll1_ii_=1, l1l_ii_=None, infoLabels=False, IsPlayable=True,fanart=l11ll1l_ii_,l11111_ii_=1):
    u = l1l1_ii_({l111ll_ii_ (u"࠭࡭ࡰࡦࡨࠫࠂ"): mode, l111ll_ii_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫࠃ"): name, l111ll_ii_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩࠄ") : url, l111ll_ii_ (u"ࠩࡳࡥ࡬࡫ࠧࠅ"):l111ll1_ii_})
    if l1l_ii_==None:
        l1l_ii_=l111ll_ii_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧࠆ")
    l1lllll_ii_ = xbmcgui.ListItem(name, iconImage=l1l_ii_, thumbnailImage=l1l_ii_)
    if not infoLabels:
        infoLabels={l111ll_ii_ (u"ࠦࡹ࡯ࡴ࡭ࡧࠥࠇ"): name}
    l1lllll_ii_.setInfo(type=l111ll_ii_ (u"ࠧࡼࡩࡥࡧࡲࠦࠈ"), infoLabels=infoLabels)
    if IsPlayable:
        l1lllll_ii_.setProperty(l111ll_ii_ (u"࠭ࡉࡴࡒ࡯ࡥࡾࡧࡢ࡭ࡧࠪࠉ"), l111ll_ii_ (u"ࠧࡵࡴࡸࡩࠬࠊ"))
    if fanart:
        l1lllll_ii_.setProperty(l111ll_ii_ (u"ࠨࡨࡤࡲࡦࡸࡴࡠ࡫ࡰࡥ࡬࡫ࠧࠋ"),fanart)
    l1ll11_ii_ = []
    l1ll11_ii_.append((l111ll_ii_ (u"ࠩࡌࡲ࡫ࡵࡲ࡮ࡣࡦ࡮ࡦ࠭ࠌ"), l111ll_ii_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡃࡦࡸ࡮ࡵ࡮ࠩࡋࡱࡪࡴ࠯ࠧࠍ")))
    l1lllll_ii_.addContextMenuItems(l1ll11_ii_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l1l1lll_ii_, url=u, listitem=l1lllll_ii_,isFolder=False,totalItems=l11111_ii_)
    xbmcplugin.addSortMethod(l1l1lll_ii_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l111ll_ii_ (u"ࠦࠪࡘࠬࠡࠧ࡜࠰ࠥࠫࡐࠣࠎ"))
    return ok
def l11ll1_ii_(name,ex_link=None, l111ll1_ii_=0, mode=l111ll_ii_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬࠏ"),iconImage=l111ll_ii_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࠪࠐ"), infoLabels=None, fanart=l11ll1l_ii_,contextmenu=None,l11111_ii_=1):
    url = l1l1_ii_({l111ll_ii_ (u"ࠧ࡮ࡱࡧࡩࠬࠑ"): mode, l111ll_ii_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬࠒ"): name, l111ll_ii_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪࠓ") : ex_link, l111ll_ii_ (u"ࠪࡴࡦ࡭ࡥࠨࠔ") : l111ll1_ii_})
    l11lll_ii_ = xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconImage)
    if infoLabels:
        l11lll_ii_.setInfo(type=l111ll_ii_ (u"ࠦࡲࡵࡶࡪࡧࠥࠕ"), infoLabels=infoLabels)
    if fanart:
        l11lll_ii_.setProperty(l111ll_ii_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࡤ࡯࡭ࡢࡩࡨࠫࠖ"), fanart )
    if contextmenu:
        l1ll11_ii_=contextmenu
        l11lll_ii_.addContextMenuItems(l1ll11_ii_, replaceItems=True)
    else:
        l1ll11_ii_ = []
        l1ll11_ii_.append((l111ll_ii_ (u"࠭ࡉ࡯ࡨࡲࡶࡲࡧࡣ࡫ࡣࠪࠗ"), l111ll_ii_ (u"࡙ࠧࡄࡐࡇ࠳ࡇࡣࡵ࡫ࡲࡲ࠭ࡏ࡮ࡧࡱࠬࠫ࠘")),)
        l11lll_ii_.addContextMenuItems(l1ll11_ii_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l1l1lll_ii_, url=url,listitem=l11lll_ii_, isFolder=True,totalItems=l11111_ii_)
    xbmcplugin.addSortMethod(l1l1lll_ii_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l111ll_ii_ (u"ࠣࠧࡕ࠰࡙ࠥࠫ࠭ࠢࠨࡔࠧ࠙"))
    return ok
def l1l1ll_ii_(l1l11ll_ii_):
    l1l11l1_ii_ = {}
    for k, v in l1l11ll_ii_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l111ll_ii_ (u"ࠩࡸࡸ࡫࠾ࠧࠚ"))
        elif isinstance(v, str):
            v.decode(l111ll_ii_ (u"ࠪࡹࡹ࡬࠸ࠨࠛ"))
        l1l11l1_ii_[k] = v
    return l1l11l1_ii_
def l1l1_ii_(query):
    return l1l11l_ii_ + l111ll_ii_ (u"ࠫࡄ࠭ࠜ") + urllib.urlencode(l1l1ll_ii_(query))
l1l11_ii_ = lambda x,y: ord(x)+8*y if ord(x)%2 else ord(x)
l1ll_ii_ = lambda l11l1_ii_: l111ll_ii_ (u"ࠬ࠭ࠝ").join([chr(l1l11_ii_(x,1) ) for x in l11l1_ii_.encode(l111ll_ii_ (u"࠭ࡢࡢࡵࡨ࠺࠹࠭ࠞ")).strip()])
l111lll_ii_ = lambda l11l1_ii_: l111ll_ii_ (u"ࠧࠨࠟ").join([chr(l1l11_ii_(x,-1) ) for x in l11l1_ii_]).decode(l111ll_ii_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨࠠ"))
if not os.path.exists(l111ll_ii_ (u"ࠩ࠲࡬ࡴࡳࡥ࠰ࡱࡶࡱࡨ࠭ࠡ")):
    tm=time.gmtime()
    try:    l1l111_ii_,l1l111l_ii_,l1l1l1_ii_ = l111lll_ii_(l11l11l_ii_.getSetting(l111ll_ii_ (u"ࠪ࡯ࡴࡪࠧࠢ"))).split(l111ll_ii_ (u"ࠫ࠿࠭ࠣ"))
    except: l1l111_ii_,l1l111l_ii_,l1l1l1_ii_ =  [l111ll_ii_ (u"ࠬ࠳࠱ࠨࠤ"),l111ll_ii_ (u"࠭ࠧࠥ"),l111ll_ii_ (u"ࠧ࠮࠳ࠪࠦ")]
    if int(l1l111_ii_) != tm.tm_hour:
        try:    l1ll1l1_ii_ = re.findall(l111ll_ii_ (u"ࠨࡍࡒࡈ࠿ࠦࠨ࠯ࠬࡂ࠭ࡡࡴࠧࠧ"),urllib2.urlopen(l111ll_ii_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡶࡦࡽ࠮ࡨ࡫ࡷ࡬ࡺࡨࡵࡴࡧࡵࡧࡴࡴࡴࡦࡰࡷ࠲ࡨࡵ࡭࠰ࡴࡤࡱ࡮ࡩࡳࡱࡣ࠲࡯ࡴࡪࡩ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡔࡈࡅࡉࡓࡅ࠯࡯ࡧࠫࠨ")).read())[0].strip(l111ll_ii_ (u"ࠪ࠮ࠬࠩ"))
        except: l1ll1l1_ii_ = l111ll_ii_ (u"ࠫࠬࠪ")
        l1llll_ii_ = l1ll_ii_(l111ll_ii_ (u"࠭ࠥࡥ࠼ࠨࡷ࠿ࠫࡤࠨ࠳")%(tm.tm_hour,l1ll1l1_ii_,tm.tm_min))
        l11l11l_ii_.setSetting(l111ll_ii_ (u"ࠧ࡬ࡱࡧࠫ࠴"),l1llll_ii_)
def l1111_ii_(ex_link):
    l111l1_ii_,l11llll_ii_ = l11l11_ii_.l1l1111_ii_(ex_link)
    if l11llll_ii_[0]:
        l1ll1ll_ii_(name=l111ll_ii_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣ࠼࠽ࠢࡓࡳࡵࡸࡺࡦࡦࡱ࡭ࡦࠦࡳࡵࡴࡲࡲࡦࠦ࠼࠽࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ࠵"), url=l11llll_ii_[0], mode=l111ll_ii_ (u"ࠩࡢࡣࡵࡧࡧࡦࡡࡢࠫ࠶"), IsPlayable=False)
    for f in l111l1_ii_:
        l1ll1ll_ii_(name=f.get(l111ll_ii_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ࠷")), url=f.get(l111ll_ii_ (u"ࠫࡺࡸ࡬ࠨ࠸")), mode=l111ll_ii_ (u"ࠬ࡭ࡥࡵࡎ࡬ࡲࡰࡹࠧ࠹"), l1l_ii_=f.get(l111ll_ii_ (u"࠭ࡩ࡮ࡩࠪ࠺")), infoLabels=f, IsPlayable=True)
    if l11llll_ii_[1]:
        l1ll1ll_ii_(name=l111ll_ii_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࡄ࠾ࠡࡐࡤࡷࡹटࡰ࡯ࡣࠣࡷࡹࡸ࡯࡯ࡣࠣࡂࡃࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࠻"), url=l11llll_ii_[1], mode=l111ll_ii_ (u"ࠨࡡࡢࡴࡦ࡭ࡥࡠࡡࠪ࠼"), IsPlayable=False)
def l1_ii_(ex_link):
    if ex_link==l111ll_ii_ (u"ࠩ࡯࡭ࡸࡺࠧ࠽"):
        l111l1_ii_ = l11l11_ii_.l11ll11_ii_()
    elif ex_link==l111ll_ii_ (u"ࠪࡴࡴࡶࡵ࡭ࡣࡵࠫ࠾"):
        l111l1_ii_ = l11l11_ii_.l11ll_ii_()
    items=len(l111l1_ii_)
    for f in l111l1_ii_:
        l11ll1_ii_(name=f.get(l111ll_ii_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ࠿")), ex_link=f.get(l111ll_ii_ (u"ࠬࡻࡲ࡭ࠩࡀ")), mode=l111ll_ii_ (u"࠭ࡧࡦࡶࡈࡴ࡮ࡹ࡯ࡥࡧࡶࠫࡁ"), iconImage=f.get(l111ll_ii_ (u"ࠧࡪ࡯ࡪࠫࡂ")), infoLabels=f,l11111_ii_=items)
def l1l1l_ii_(ex_link):
    l1lll_ii_ = l11l11_ii_.l1l1l_ii_(ex_link)
    for f in l1lll_ii_:
        l1ll1ll_ii_(name=f.get(l111ll_ii_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࡃ")), url=f.get(l111ll_ii_ (u"ࠩࡸࡶࡱ࠭ࡄ")), mode=l111ll_ii_ (u"ࠪ࡫ࡪࡺࡌࡪࡰ࡮ࡷࠬࡅ"), l1l_ii_=f.get(l111ll_ii_ (u"ࠫ࡮ࡳࡧࠨࡆ")), infoLabels=f, IsPlayable=True)
def l1ll111_ii_(ex_link):
    l1ll11l_ii_.run()
    l1ll1_ii_ = l11l11_ii_.l1ll111_ii_(ex_link)
    l1l1l1l_ii_=l111ll_ii_ (u"ࠬ࠭ࡇ")
    if len(l1ll1_ii_):
        l1111l_ii_ = [x.get(l111ll_ii_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࡈ")) for x in l1ll1_ii_]
        s = xbmcgui.Dialog().select(l111ll_ii_ (u"ࠧࡍ࡫ࡱ࡯࡮࠭ࡉ"),l1111l_ii_)
        l1l1l11_ii_=l1ll1_ii_[s].get(l111ll_ii_ (u"ࠨࡷࡵࡰࠬࡊ")) if s>-1 else l111ll_ii_ (u"ࠩࠪࡋ")
        if l1l1l11_ii_:
            l1l1l11_ii_ = l11l11_ii_.l11l1ll_ii_(l1l1l11_ii_)
            if not l1l1l1l_ii_:
                try:
                    l1l1l1l_ii_ = urlresolver.resolve(l1l1l11_ii_)
                except Exception,e:
                    xbmcgui.Dialog().ok(l111ll_ii_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࡑࡴࡲࡦࡱ࡫࡭࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࡌ"),l111ll_ii_ (u"࡚ࠫࡘࡌࡓࡧࡶࡳࡱࡼࡥࡳࠢࡈࡖࡗࡕࡒ࠻ࠢ࡞ࠩࡸࡣࠧࡍ")%str(e))
                    l1l1l1l_ii_=l111ll_ii_ (u"ࠬ࠭ࡎ")
    print l111ll_ii_ (u"࠭ࡳࡵࡴࡨࡥࡲࡥࡵࡳ࡮ࠪࡏ"),l1l1l1l_ii_
    if l1l1l1l_ii_:
        xbmcplugin.setResolvedUrl(l1l1lll_ii_, True, xbmcgui.ListItem(path=l1l1l1l_ii_))
    else:
        xbmcplugin.setResolvedUrl(l1l1lll_ii_, False, xbmcgui.ListItem(path=l111ll_ii_ (u"ࠧࠨࡐ")))
xbmcplugin.setContent(l1l1lll_ii_, l111ll_ii_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨࡑ"))
mode = args.get(l111ll_ii_ (u"ࠩࡰࡳࡩ࡫ࠧࡒ"), None)
fname = args.get(l111ll_ii_ (u"ࠪࡪࡴࡲࡤࡦࡴࡱࡥࡲ࡫ࠧࡓ"),[l111ll_ii_ (u"ࠫࠬࡔ")])[0]
ex_link = args.get(l111ll_ii_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭ࡕ"),[l111ll_ii_ (u"࠭ࠧࡖ")])[0]
if mode is None:
    l11ll1_ii_(name=l111ll_ii_ (u"ࠧࡊࡰࡩࡳࡷࡳࡡࡤ࡬ࡤࠫࡗ"),mode=l111ll_ii_ (u"ࠨࡡ࡬ࡲ࡫ࡵ࡟ࠨࡘ"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l111ll_ii_ (u"ࠩࡳࡥࡹ࡮࡙ࠧ")))+l111ll_ii_ (u"ࠪ࠳࡮ࡩ࡯࡯࠰ࡳࡲ࡬࡚࠭"),infoLabels={})
    l11ll1_ii_(name=l111ll_ii_ (u"ࠦࡔࡹࡴࡢࡶࡱ࡭ࡴࠦࡤࡰࡦࡤࡲࡪࠨ࡛"),ex_link=l111ll_ii_ (u"ࠬ࠷ࠧ࡜"), mode=l111ll_ii_ (u"࠭ࡏࡴࡶࡤࡸࡳ࡯ࡥࡔࡧࡵ࡭ࡦࡲࡥࠨ࡝"),iconImage=l111ll_ii_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫ࡞"),fanart=l11ll1l_ii_)
    l11ll1_ii_(name=l111ll_ii_ (u"ࠣࡒࡲࡴࡺࡲࡡࡳࡰࡨࠦ࡟"),ex_link=l111ll_ii_ (u"ࠩࡳࡳࡵࡻ࡬ࡢࡴࠪࡠ"), mode=l111ll_ii_ (u"ࠪࡐ࡮ࡹࡴࡔࡧࡵ࡭ࡦࡲࡥࠨࡡ"),iconImage=l111ll_ii_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠨࡢ"),fanart=l11ll1l_ii_)
    l11ll1_ii_(name=l111ll_ii_ (u"ࠧ࡝ࡳࡻࡻࡶࡸࡰ࡯ࡥࠣࡣ"),ex_link=l111ll_ii_ (u"࠭࡬ࡪࡵࡷࠫࡤ"), mode=l111ll_ii_ (u"ࠧࡍ࡫ࡶࡸࡘ࡫ࡲࡪࡣ࡯ࡩࠬࡥ"),iconImage=l111ll_ii_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬࡦ"),fanart=l11ll1l_ii_)
elif mode[0].startswith(l111ll_ii_ (u"ࠩࡢ࡭ࡳ࡬࡯ࡠࠩࡧ")):l111l_ii_.__myinfo__.go(sys.argv)
elif mode[0] == l111ll_ii_ (u"ࠪࡣࡤࡶࡡࡨࡧࡢࡣࠬࡨ"):
    url = l1l1_ii_({l111ll_ii_ (u"ࠫࡲࡵࡤࡦࠩࡩ"): l111ll_ii_ (u"ࠬࡕࡳࡵࡣࡷࡲ࡮࡫ࡓࡦࡴ࡬ࡥࡱ࡫ࠧࡪ"), l111ll_ii_ (u"࠭ࡦࡰ࡮ࡧࡩࡷࡴࡡ࡮ࡧࠪ࡫"): l111ll_ii_ (u"ࠧࠨ࡬"), l111ll_ii_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩ࡭") : ex_link})
    xbmc.executebuiltin(l111ll_ii_ (u"࡛ࠩࡆࡒࡉ࠮ࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠬࠪࡹࠩࠨ࡮")% url)
elif mode[0] == l111ll_ii_ (u"ࠪࡓࡸࡺࡡࡵࡰ࡬ࡩࡘ࡫ࡲࡪࡣ࡯ࡩࠬ࡯"): l1111_ii_(ex_link)
elif mode[0] == l111ll_ii_ (u"ࠫࡑ࡯ࡳࡵࡕࡨࡶ࡮ࡧ࡬ࡦࠩࡰ"): l1_ii_(ex_link)
elif mode[0] == l111ll_ii_ (u"ࠬ࡭ࡥࡵࡇࡳ࡭ࡸࡵࡤࡦࡵࠪࡱ"): l1l1l_ii_(ex_link)
elif mode[0] == l111ll_ii_ (u"࠭ࡧࡦࡶࡏ࡭ࡳࡱࡳࠨࡲ"): l1ll111_ii_(ex_link)
elif mode[0] == l111ll_ii_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧࡳ"): pass
xbmcplugin.endOfDirectory(l1l1lll_ii_)
