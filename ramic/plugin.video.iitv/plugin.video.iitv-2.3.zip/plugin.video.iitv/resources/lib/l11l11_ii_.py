# -*- coding: utf-8 -*-
import sys
l1lll1l_ii_ = sys.version_info [0] == 2
l1ll1l_ii_ = 2048
l11lll1_ii_ = 7
def l111ll_ii_ (ll_ii_):
	global l1lll11_ii_
	l1lll1_ii_ = ord (ll_ii_ [-1])
	l1llll1_ii_ = ll_ii_ [:-1]
	l11l_ii_ = l1lll1_ii_ % len (l1llll1_ii_)
	l111_ii_ = l1llll1_ii_ [:l11l_ii_] + l1llll1_ii_ [l11l_ii_:]
	if l1lll1l_ii_:
		l1l1ll1_ii_ = unicode () .join ([unichr (ord (char) - l1ll1l_ii_ - (l11l1l_ii_ + l1lll1_ii_) % l11lll1_ii_) for l11l1l_ii_, char in enumerate (l111_ii_)])
	else:
		l1l1ll1_ii_ = str () .join ([chr (ord (char) - l1ll1l_ii_ - (l11l1l_ii_ + l1lll1_ii_) % l11lll1_ii_) for l11l1l_ii_, char in enumerate (l111_ii_)])
	return eval (l1l1ll1_ii_)
import sys,os,re
import urllib,urllib2
import urlparse
import cookielib
import time
import json
l11l1l1l1_ii_=l111ll_ii_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡮࡯ࡴࡷࡺ࠱ࡴࡱ࠵ࠧद")
def l11ll1l1l_ii_(url, l1l11111l_ii_=None,l11l1lll1_ii_=None, headers=None,timeout=20):
    if l1l11111l_ii_ is not None:
        l11ll1lll_ii_ = urllib2.HTTPCookieProcessor(l1l11111l_ii_)
        opener = urllib2.build_opener(l11ll1lll_ii_,urllib2.HTTPHandler())
        print (l111ll_ii_ (u"ࠬ࡭ࡥࡵࡗࡵࡰࠬध"), url)
        req = urllib2.Request(url)
        req.add_header(l111ll_ii_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪन"),l111ll_ii_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠺࠳࠷࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠹࠳࠯࠲࠱࠵࠼࠻࠰࠯࠳࠸࠸࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬऩ"))
        if headers:
            for h,l11ll11l1_ii_ in headers:
                req.add_header(h,l11ll11l1_ii_)
        response = opener.open(req,l11l1lll1_ii_,timeout=timeout)
        l1l1l11_ii_=response.read()
        response.close()
    else:
        print (l111ll_ii_ (u"ࠨࡩࡨࡸ࡚ࡸ࡬ࡠࡤࡤࡷ࡮ࡩࠧप"), url)
        l1l1l11_ii_= l1l111111_ii_(url,l11l1lll1_ii_,timeout)
    return l1l1l11_ii_;
def l1l111111_ii_(url,data=None,timeout=10):
    req = urllib2.Request(url,data)
    print (l111ll_ii_ (u"ࠩࡪࡩࡹ࡛ࡲ࡭ࡡࡥࡥࡸ࡯ࡣࠨफ"), url)
    req.add_header(l111ll_ii_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧब"), l111ll_ii_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠷࠰࠴࠿ࠥ࡝ࡏࡘ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠶࠷࠳࠶࠮࠲࠹࠸࠴࠳࠷࠵࠵ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩभ"))
    try:
        response = urllib2.urlopen(req,timeout=timeout)
        l1l1l11_ii_ = response.read()
        response.close()
    except:
        l1l1l11_ii_=l111ll_ii_ (u"ࠬ࠭म")
    return l1l1l11_ii_
def l1l1111_ii_(l111ll1_ii_=1):
    l111ll1_ii_=int(l111ll1_ii_)
    url=l111ll_ii_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡩࡪࡶࡹࡼ࠳ࡶ࡬࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶࡆࡩࡱࡲࡳࡍ࡫ࡶࡸ࠴ࠫࡤࡀ࡫ࡱ࡭ࡹࡃࡦࡢ࡮ࡶࡩࠬय")%int(l111ll1_ii_)
    out=[]
    l11l1ll1l_ii_=False
    l11lllll1_ii_=False
    headers=[[l111ll_ii_ (u"ࠧࡂࡥࡦࡩࡵࡺࠧर"),l111ll_ii_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡪࡴࡱࡱ࠰ࠥࡺࡥࡹࡶ࠲ࡴࡱࡧࡩ࡯࠮ࠣ࠮࠴࠰ࠧऱ")],
            [l111ll_ii_ (u"ࠩࡆࡳࡳࡴࡥࡤࡶ࡬ࡳࡳ࠭ल"),l111ll_ii_ (u"ࠪ࡯ࡪ࡫ࡰ࠮ࡣ࡯࡭ࡻ࡫ࠧळ")],
            [l111ll_ii_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧऴ"),l111ll_ii_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭व")],
            [l111ll_ii_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧश"),l11l1l1l1_ii_]]
    l1l11111l_ii_=cookielib.LWPCookieJar()
    content  = l11ll1l1l_ii_(url,l1l11111l_ii_,headers=headers)
    if content:
        data=json.loads(content)
        for k,v in data[l111ll_ii_ (u"ࠧࡳࡧࡶࡹࡱࡺࡳࠨष")].iteritems():
            l1lll1ll_ii_={}
            l1lll1ll_ii_[l111ll_ii_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧस")] = l111ll_ii_ (u"ࠩࠨࡷࠥࠫࡳࠨह")%(v.get(l111ll_ii_ (u"ࠪࡷࡪࡧࡳࡰࡰࡄࡲࡩࡋࡰࡪࡵࡲࡨࡪࡉ࡯ࡥࡧࠪऺ"),l111ll_ii_ (u"ࠫࠬऻ")),v.get(l111ll_ii_ (u"ࠬࡹࡥࡳ࡫ࡨࡷ࡙࡯ࡴ࡭ࡧ़ࠪ")))
            l1lll1ll_ii_[l111ll_ii_ (u"࠭ࡰ࡭ࡱࡷࠫऽ")]=v.get(l111ll_ii_ (u"ࠧࡥࡧࡶࡧࡷ࡯ࡰࡵ࡫ࡲࡲࠬा"),l111ll_ii_ (u"ࠨࠩि"))
            l11lll1l1_ii_ = v.get(l111ll_ii_ (u"ࠩ࡬ࡱࡦ࡭ࡥࡖࡴ࡯ࠫी"),l111ll_ii_ (u"ࠪࠫु"))
            l1lll1ll_ii_[l111ll_ii_ (u"ࠫ࡮ࡳࡧࠨू")]=l11lll1l1_ii_
            l1lll1ll_ii_[l111ll_ii_ (u"ࠬࡻࡲ࡭ࠩृ")]=v.get(l111ll_ii_ (u"࠭ࡵࡳ࡮ࠪॄ"),l111ll_ii_ (u"ࠧࠨॅ"))
            l1lll1ll_ii_[l111ll_ii_ (u"ࠨࡦࡤࡸࡦ࠭ॆ")]=v.get(l111ll_ii_ (u"ࠩࡧࡥࡹ࡫ࠧे"),l111ll_ii_ (u"ࠪࠫै"))
            l1lll1ll_ii_[l111ll_ii_ (u"ࠫࡨࡵࡤࡦࠩॉ")]=v.get(l111ll_ii_ (u"ࠬ࡬࡬ࡢࡩࠪॊ"),l111ll_ii_ (u"࠭ࠧो"))
            l1lll1ll_ii_[l111ll_ii_ (u"ࠧࡶࡴ࡯ࡗࡪࡸࡩࡦࡵࠪौ")]=v.get(l111ll_ii_ (u"ࠨࡶ࡫ࡩࡘ࡫ࡲࡪࡧࡶ࡙ࡷࡲ्ࠧ"),l111ll_ii_ (u"ࠩࠪॎ"))
            out.append(l1lll1ll_ii_)
    l11l1ll1l_ii_=int(l111ll1_ii_)+1 if len(out) else False
    l11lllll1_ii_ = l111ll1_ii_-1 if l111ll1_ii_>1 else False
    return (out,(l11lllll1_ii_,l11l1ll1l_ii_))
def l11ll_ii_():
    content  = l11ll1l1l_ii_(l11l1l1l1_ii_)
    l11l1l111_ii_ = re.compile(l111ll_ii_ (u"ࠪࡀࡺࡲࠠࡪࡦࡀࠦࡵࡵࡰࡶ࡮ࡤࡶ࠲ࡲࡩࡴࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾ࠨॏ"),re.DOTALL).findall(content)
    out=[]
    for u in l11l1l111_ii_:
        l11llll11_ii_=re.compile(l111ll_ii_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴ࠿࠴ࠪࡀࠫࠥࡂ࠭ࡡ࡞࠽࡟࠮࠭ࡁ࠭ॐ")).findall(u)
        for u,t in l11llll11_ii_:
            out.append({l111ll_ii_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ॑"):l11lll111_ii_(t) ,l111ll_ii_ (u"࠭ࡵࡳ࡮॒ࠪ"):u})
    return out
def l11ll11_ii_():
    content  = l11ll1l1l_ii_(l11l1l1l1_ii_)
    l11l1l111_ii_ = re.compile(l111ll_ii_ (u"ࠧ࠽ࡷ࡯ࠤ࡮ࡪ࠽ࠣ࡮࡬ࡷࡹࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ॓"),re.DOTALL).findall(content)
    out=[]
    for u in l11l1l111_ii_:
        l11llll11_ii_=re.compile(l111ll_ii_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠼࠱࠮ࡄ࠯ࠢ࠿ࠪ࡞ࡢࡁࡣࠫࠪ࠾ࠪ॔")).findall(u)
        for u,t in l11llll11_ii_:
            out.append({l111ll_ii_ (u"ࠩࡷ࡭ࡹࡲࡥࠨॕ"):l11lll111_ii_(t) ,l111ll_ii_ (u"ࠪࡹࡷࡲࠧॖ"):u})
    return out
url=l111ll_ii_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡩࡵ࡫࠸࠲࠺࠲ࡨࡵ࡭࠰ࡵࡷࡥࡷ࠳ࡴࡳࡧ࡮࠱ࡩ࡯ࡳࡤࡱࡹࡩࡷࡿࠧॗ")
def l1l1l_ii_(url):
    content  = l11ll1l1l_ii_(url)
    out=[]
    l1l111l11_ii_ = re.compile(l111ll_ii_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡩࡵ࡯ࡳࡰࡦࡨࡷ࠲ࡲࡩࡴࡶࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩक़"),re.DOTALL).findall(content)
    l11lll1l1_ii_ = re.findall(l111ll_ii_ (u"࠭ࡩ࡮ࡩࠣࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡼࡥࡳࠤࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨख़"),content)
    l11lll1l1_ii_ =l111ll_ii_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪ࡫ࡷࡺ࠳ࡶ࡬ࠨग़")+l11lll1l1_ii_ if l11lll1l1_ii_[0].startswith(l111ll_ii_ (u"ࠨ࠱ࠪज़")) else l11lll1l1_ii_[0]
    if l1l111l11_ii_:
        for l11lll_ii_ in re.compile(l111ll_ii_ (u"ࠩ࠿ࡰ࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪड़"),re.DOTALL).findall(l1l111l11_ii_[0]):
            l11ll1111_ii_ = re.compile(l111ll_ii_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡲࡵ࡮ࡰࠣࡨࡦࡺࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩढ़")).search(l11lll_ii_)
            l11lll11l_ii_ = re.compile(l111ll_ii_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩ࠲ࡩ࡯ࡥࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫफ़")).search(l11lll_ii_)
            href = re.compile(l111ll_ii_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࡜ࡠࡁࡡ࠯ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭य़")).search(l11lll_ii_)
            if href:
                code = l11ll1111_ii_.group(1) if l11ll1111_ii_ else l111ll_ii_ (u"࠭ࠧॠ")
                title = l11lll11l_ii_.group(1) if l11ll1111_ii_ else l111ll_ii_ (u"ࠧࠨॡ")
                title += l111ll_ii_ (u"ࠨࠢࠪॢ")+href.group(2) if l11ll1111_ii_ else l111ll_ii_ (u"ࠩࠪॣ")
                out.append({l111ll_ii_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ।"):l11lll111_ii_(title) ,l111ll_ii_ (u"ࠫࡺࡸ࡬ࠨ॥"):href.group(1),l111ll_ii_ (u"ࠬࡩ࡯ࡥࡧࠪ०"):code,l111ll_ii_ (u"࠭ࡩ࡮ࡩࠪ१"):l11lll1l1_ii_})
    return out
def l1ll111_ii_(url):
    content  = l11ll1l1l_ii_(url)
    print content
    l11l1l111_ii_ = re.compile(l111ll_ii_ (u"ࠧ࠽ࡷ࡯ࠤࡨࡲࡡࡴࡵࡀࠦࡹࡧࡢ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭२"),re.DOTALL).findall(content)
    out=[]
    for u in l11l1l111_ii_:
        l11l1ll11_ii_ = re.compile(l111ll_ii_ (u"ࠨ࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ३")).search(u)
        l11l1ll11_ii_ = l11l1ll11_ii_.group(1) if l11l1ll11_ii_ else l111ll_ii_ (u"ࠩࠪ४")
        l11l1ll11_ii_ = l11l1ll11_ii_.replace(l111ll_ii_ (u"ࠪࡳࡷ࡭ࠧ५"),l111ll_ii_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤ࡬ࡸࡥࡺ࡟ࡒࡖ࡞ࡍࡉࡏࡃॄ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ६"))
        l11l1ll11_ii_ = l11l1ll11_ii_.replace(l111ll_ii_ (u"ࠬࡲࡥࡤࡒࡏࠫ७"),l111ll_ii_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸ࡬ࡸࡥࡦࡰࡠࡐࡪࡱࡴࡰࡴ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ८"))
        l11l1ll11_ii_ = l11l1ll11_ii_.replace(l111ll_ii_ (u"ࠧࡴࡷࡥࡔࡑ࠭९"),l111ll_ii_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡱࡵࡥࡳ࡭ࡥ࡞ࡐࡤࡴ࡮ࡹࡹ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ॰"))
        l1l1111l1_ii_ = re.compile(l111ll_ii_ (u"ࠩ࠿ࡥࠥ࠴ࠫࡀࡥ࡯ࡥࡸࡹ࠽ࠣࡡࡨࡴ࡮ࡹ࡯ࡥࡧ࠰ࡰ࡮ࡴ࡫ࠣ࠰࠮ࡃ࡭ࡸࡥࡧ࠿࡞ࡠࠬࠨ࡝ࠩ࡝ࡡࠦࡢ࠰ࠩ࡜ࠤ࡟ࠫࡢ࠴ࠫࡀࡦࡤࡸࡦ࠳࡬ࡪࡰ࡮࠱࡮ࡪ࠮ࠬࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ॱ")).findall(u)
        for l in l1l1111l1_ii_:
            out.append({l111ll_ii_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩॲ"): l111ll_ii_ (u"ࠫࡠࠫࡳ࡞ࠢࠨࡷࠬॳ")%(l11l1ll11_ii_,l[-1]),l111ll_ii_ (u"ࠬࡻࡲ࡭ࠩॴ"):l[0]})
    return out
def l11ll11ll_ii_(url):
    content  = l11ll1l1l_ii_(url)
    src=l111ll_ii_ (u"࠭ࠧॵ")
    l11lll1ll_ii_ = re.compile(l111ll_ii_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠩ࠰࠭ࡃ࠮ࡂ࠯ࡪࡨࡵࡥࡲ࡫࠾ࠨॶ"),re.DOTALL).findall(content)
    for l11llllll_ii_ in l11lll1ll_ii_:
        src = re.compile(l111ll_ii_ (u"ࠨࡵࡵࡧࡂࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣࠧॷ")).search(l11llllll_ii_)
        src = src.group(1) if src else l111ll_ii_ (u"ࠩࠪॸ")
    return src
def l11l1llll_ii_(url=l111ll_ii_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡨࡻࡴ࠯ࡵࡲ࠳ࡲࡸࡋࡇࡥࠪॹ")):
    l1l1111ll_ii_=url
    if l111ll_ii_ (u"ࠫࡨࡻࡴ࠯ࡵࡲࠫॺ") in url:
        req = urllib2.Request(url,None,{l111ll_ii_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩॻ"): l111ll_ii_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠹࠲࠷ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠸࠶࠮࠱࠰࠴࠹࠾࠿࠮࠷࠻ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪॼ")})
        try:
            response = urllib2.urlopen(req, timeout=10)
            l1l1111ll_ii_ = response.url
            response.close()
        except:
            l1l1111ll_ii_=l111ll_ii_ (u"ࠧࠨॽ")
    else:
        l1l1111ll_ii_=l11ll11ll_ii_(url)
    return l1l1111ll_ii_
def l11l1ll_ii_(url):
    try:
        l1l11111l_ii_ = cookielib.LWPCookieJar()
        l11l11lll_ii_ = urlparse.urljoin(l11l1l1l1_ii_,url) if url.startswith(l111ll_ii_ (u"ࠨ࠱ࠪॾ")) else url
        l11ll1lll_ii_ = urllib2.HTTPCookieProcessor(l1l11111l_ii_)
        opener = urllib2.build_opener(l11ll1lll_ii_, urllib2.HTTPHandler())
        req = urllib2.Request(l11l11lll_ii_)
        req.add_header(l111ll_ii_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ॿ"),l111ll_ii_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠶࠯࠳࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠵࠶࠲࠵࠴࠱࠸࠷࠳࠲࠶࠻࠴ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨঀ"))
        response = opener.open(req,timeout=10)
        l1l1l11_ii_=response.read()
        response.close()
        l11ll111l_ii_ = l111ll_ii_ (u"ࠫࠬঁ").join([l111ll_ii_ (u"ࠬࠫࡳ࠾ࠧࡶ࠿ࠬং")%(c.name, c.value) for c in l1l11111l_ii_ ])
        l11l1l11l_ii_= re.findall(l111ll_ii_ (u"࠭ࡤࡢࡶࡤ࠱ࡸࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪঃ"),l1l1l11_ii_)[0]
        l11l1l1ll_ii_= re.findall(l111ll_ii_ (u"ࠧࡥࡣࡷࡥ࠲ࡺࡩ࡮ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ঄"),l1l1l11_ii_)[0]
        l11l11ll1_ii_= re.findall(l111ll_ii_ (u"ࠨࡦࡤࡸࡦ࠳ࡡࡤࡶ࡬ࡳࡳࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧঅ"),l1l1l11_ii_)[0]
        time.sleep(int(l11l1l1ll_ii_))
        data=l111ll_ii_ (u"ࠩࠩࡷࡦࡲࡴ࠾ࠧࡶࠪࡧࡲ࡯ࡤ࡭ࡨࡶࡂ࠶ࠧআ")%(l11l1l11l_ii_)
        req = urllib2.Request(url,headers={l111ll_ii_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧই"): l111ll_ii_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡪࡰ࠹࠸ࡀࠦࡸ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠸࠳࠲࠵࠴࠳࠲࠳࠵࠲࠶࠷࠳ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨঈ"),
            l111ll_ii_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬউ"):l11ll111l_ii_,
            l111ll_ii_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩঊ"):l111ll_ii_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨঋ"),
            l111ll_ii_ (u"ࠨ࡚࠰ࡓࡈ࡚ࡏࡃࡇࡕ࠱ࡗࡋࡑࡖࡇࡖࡘ࠲ࡎࡁࡏࡆࡏࡉࡗ࠭ঌ"):l11l11ll1_ii_,
            l111ll_ii_ (u"࡛ࠩ࠱ࡔࡉࡔࡐࡄࡈࡖ࠲ࡘࡅࡒࡗࡈࡗ࡙࠳ࡐࡂࡔࡗࡍࡆࡒࡓࠨ঍"):l111ll_ii_ (u"ࠪࡷ࡭ࡵࡲࡵࡥࡸࡸ࠴ࡲࡩ࡯࡭ࡢࡷ࡭ࡵࡷࠨ঎"),
            l111ll_ii_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬএ"):url}
            )
        response = urllib2.urlopen(req,data)
        l11ll1l11_ii_ = response.headers.get(l111ll_ii_ (u"ࠬࡹࡥࡵ࠯ࡦࡳࡴࡱࡩࡦࠩঐ"),l111ll_ii_ (u"࠭ࠧ঑"))
        response.headers.keys()
        l11ll1ll1_ii_ = response.read()
        l11ll1ll1_ii_ = l11ll1ll1_ii_.replace(l111ll_ii_ (u"ࠧ࡝࡞ࠪ঒"),l111ll_ii_ (u"ࠨࠩও"))
        response.close()
        href = re.findall(l111ll_ii_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫঔ"),l11ll1ll1_ii_)[0]
        href=l111ll_ii_ (u"ࠪ࡬ࡹࡺࡰࠨক")+href.split(l111ll_ii_ (u"ࠫ࡭ࡺࡴࡱࠩখ"))[-1]
    except:
        href=l111ll_ii_ (u"ࠬ࠭গ")
    return href
def l11lll111_ii_(l11llll1l_ii_):
    l11llll1l_ii_ = l11llll1l_ii_.replace(l111ll_ii_ (u"࠭ࠦ࡯ࡤࡶࡴࡀ࠭ঘ"),l111ll_ii_ (u"ࠧࠨঙ"))
    l11llll1l_ii_ = l11llll1l_ii_.replace(l111ll_ii_ (u"ࠨࠨ࡯ࡸࡀࡨࡲ࠰ࠨࡪࡸࡀ࠭চ"),l111ll_ii_ (u"ࠩࠣࠫছ"))
    l11llll1l_ii_ = l11llll1l_ii_.replace(l111ll_ii_ (u"ࠪࠪࡶࡻ࡯ࡵ࠽ࠪজ"),l111ll_ii_ (u"ࠫࠧ࠭ঝ")).replace(l111ll_ii_ (u"ࠬࠬࡡ࡮ࡲ࠾ࡵࡺࡵࡴ࠼ࠩঞ"),l111ll_ii_ (u"࠭ࠢࠨট"))
    l11llll1l_ii_ = l11llll1l_ii_.replace(l111ll_ii_ (u"ࠧࠧࡱࡤࡧࡺࡺࡥ࠼ࠩঠ"),l111ll_ii_ (u"ࠨࣵࠪড")).replace(l111ll_ii_ (u"ࠩࠩࡓࡦࡩࡵࡵࡧ࠾ࠫঢ"),l111ll_ii_ (u"ࠪࣗࠬণ"))
    l11llll1l_ii_ = l11llll1l_ii_.replace(l111ll_ii_ (u"ࠫࠫࡧ࡭ࡱ࠽ࡲࡥࡨࡻࡴࡦ࠽ࠪত"),l111ll_ii_ (u"ࣹࠬࠧথ")).replace(l111ll_ii_ (u"࠭ࠦࡢ࡯ࡳ࠿ࡔࡧࡣࡶࡶࡨ࠿ࠬদ"),l111ll_ii_ (u"ࠧࣔࠩধ"))
    l11llll1l_ii_ = l11llll1l_ii_.replace(l111ll_ii_ (u"ࠨ࡞ࡸ࠴࠶࠶࠵ࠨন"),l111ll_ii_ (u"ࠩईࠫ঩")).replace(l111ll_ii_ (u"ࠪࡠࡺ࠶࠱࠱࠶ࠪপ"),l111ll_ii_ (u"ࠫउ࠭ফ"))
    l11llll1l_ii_ = l11llll1l_ii_.replace(l111ll_ii_ (u"ࠬࡢࡵ࠱࠳࠳࠻ࠬব"),l111ll_ii_ (u"࠭इࠨভ")).replace(l111ll_ii_ (u"ࠧ࡝ࡷ࠳࠵࠵࠼ࠧম"),l111ll_ii_ (u"ࠨईࠪয"))
    l11llll1l_ii_ = l11llll1l_ii_.replace(l111ll_ii_ (u"ࠩ࡟ࡹ࠵࠷࠱࠺ࠩর"),l111ll_ii_ (u"ࠪझࠬ঱")).replace(l111ll_ii_ (u"ࠫࡡࡻ࠰࠲࠳࠻ࠫল"),l111ll_ii_ (u"ࠬञࠧ঳"))
    l11llll1l_ii_ = l11llll1l_ii_.replace(l111ll_ii_ (u"࠭࡜ࡶ࠲࠴࠸࠷࠭঴"),l111ll_ii_ (u"ࠧृࠩ঵")).replace(l111ll_ii_ (u"ࠨ࡞ࡸ࠴࠶࠺࠱ࠨশ"),l111ll_ii_ (u"ࠩॄࠫষ"))
    l11llll1l_ii_ = l11llll1l_ii_.replace(l111ll_ii_ (u"ࠪࡠࡺ࠶࠱࠵࠶ࠪস"),l111ll_ii_ (u"ࠫॉ࠭হ")).replace(l111ll_ii_ (u"ࠬࡢࡵ࠱࠳࠷࠸ࠬ঺"),l111ll_ii_ (u"࠭ृࠨ঻"))
    l11llll1l_ii_ = l11llll1l_ii_.replace(l111ll_ii_ (u"ࠧ࡝ࡷ࠳࠴࡫࠹়ࠧ"),l111ll_ii_ (u"ࠨࣵࠪঽ")).replace(l111ll_ii_ (u"ࠩ࡟ࡹ࠵࠶ࡤ࠴ࠩা"),l111ll_ii_ (u"ࠪࣗࠬি"))
    l11llll1l_ii_ = l11llll1l_ii_.replace(l111ll_ii_ (u"ࠫࡡࡻ࠰࠲࠷ࡥࠫী"),l111ll_ii_ (u"ࠬॡࠧু")).replace(l111ll_ii_ (u"࠭࡜ࡶ࠲࠴࠹ࡦ࠭ূ"),l111ll_ii_ (u"ࠧज़ࠩৃ"))
    l11llll1l_ii_ = l11llll1l_ii_.replace(l111ll_ii_ (u"ࠨ࡞ࡸ࠴࠶࠽ࡡࠨৄ"),l111ll_ii_ (u"ࠩॽࠫ৅")).replace(l111ll_ii_ (u"ࠪࡠࡺ࠶࠱࠸࠻ࠪ৆"),l111ll_ii_ (u"ࠫॾ࠭ে"))
    l11llll1l_ii_ = l11llll1l_ii_.replace(l111ll_ii_ (u"ࠬࡢࡵ࠱࠳࠺ࡧࠬৈ"),l111ll_ii_ (u"࠭ॼࠨ৉")).replace(l111ll_ii_ (u"ࠧ࡝ࡷ࠳࠵࠼ࡨࠧ৊"),l111ll_ii_ (u"ࠨॽࠪো"))
    return l11llll1l_ii_
