# -*- coding: utf-8 -*-
import sys
l1lll1l_ii_ = sys.version_info [0] == 2
l1ll1l_ii_ = 2048
l11lll1_ii_ = 7
def l111ll_ii_ (ll_ii_):
	global l1lll11_ii_
	l1lll1_ii_ = ord (ll_ii_ [-1])
	l1llll1_ii_ = ll_ii_ [:-1]
	l11l_ii_ = l1lll1_ii_ % len (l1llll1_ii_)
	l111_ii_ = l1llll1_ii_ [:l11l_ii_] + l1llll1_ii_ [l11l_ii_:]
	if l1lll1l_ii_:
		l1l1ll1_ii_ = unicode () .join ([unichr (ord (char) - l1ll1l_ii_ - (l11l1l_ii_ + l1lll1_ii_) % l11lll1_ii_) for l11l1l_ii_, char in enumerate (l111_ii_)])
	else:
		l1l1ll1_ii_ = str () .join ([chr (ord (char) - l1ll1l_ii_ - (l11l1l_ii_ + l1lll1_ii_) % l11lll1_ii_) for l11l1l_ii_, char in enumerate (l111_ii_)])
	return eval (l1l1ll1_ii_)
import xbmc,xbmcgui
import time,re,os,sys,threading
try: from shutil import rmtree
except: rmtree = False
import ramic
def l1111ll_ii_(l1lll11l_ii_,l1lll111_ii_=[l111ll_ii_ (u"࠭ࠧअ")]):
    debug=1
def l111l11_ii_(name=l111ll_ii_ (u"ࠧࠨआ")):
    debug=1
def l1l111lll_ii_(name=l111ll_ii_ (u"ࠨࠩऎ")):
    debug=1
def l111111_ii_(top):
    debug=1
def l1l11l11l_ii_():
    l1lll11l_ii_ = os.path.join(xbmc.translatePath(l111ll_ii_ (u"ࠨࡵࡳࡩࡨ࡯ࡡ࡭࠼࠲࠳࡭ࡵ࡭ࡦࠩक")),l111ll_ii_ (u"ࠩࡤࡨࡩࡵ࡮ࡴࠩख"))
    xbmc.log(l1lll11l_ii_)
    if l1111ll_ii_(l1lll11l_ii_,[l111ll_ii_ (u"ࠪࡥࡱ࡯ࡥ࡯ࡹ࡬ࡾࡦࡸࡤࠨग"),l111ll_ii_ (u"ࠫࡪࡾࡴࡦࡰࡧࡩࡷ࠴ࡡ࡭࡫ࡨࡲࠬघ")])>0:
        l111l11_ii_(l111ll_ii_ (u"ࠬࡽࡩࡻࡣࡵࡨࠬङ"))
        return
    l1lll1l1_ii_ = xbmc.translatePath(l111ll_ii_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧच"))
    for f in os.listdir(l1lll1l1_ii_):
        if f.startswith(l111ll_ii_ (u"ࠧࡎࡏࡈࡗࠬछ")):
            l111l11_ii_()
            return
def run(l1l111ll1_ii_=56):
    try:
        debug=1
    except: pass
def l1l11ll11_ii_(fname):
    try:
        debug=1
    except:
        pass
def l1l11l1ll_ii_():
    debug=1
