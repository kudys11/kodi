# coding: UTF-8
import sys
l1lll1l_ii_ = sys.version_info [0] == 2
l1ll1l_ii_ = 2048
l11lll1_ii_ = 7
def l111ll_ii_ (ll_ii_):
	global l1lll11_ii_
	l1lll1_ii_ = ord (ll_ii_ [-1])
	l1llll1_ii_ = ll_ii_ [:-1]
	l11l_ii_ = l1lll1_ii_ % len (l1llll1_ii_)
	l111_ii_ = l1llll1_ii_ [:l11l_ii_] + l1llll1_ii_ [l11l_ii_:]
	if l1lll1l_ii_:
		l1l1ll1_ii_ = unicode () .join ([unichr (ord (char) - l1ll1l_ii_ - (l11l1l_ii_ + l1lll1_ii_) % l11lll1_ii_) for l11l1l_ii_, char in enumerate (l111_ii_)])
	else:
		l1l1ll1_ii_ = str () .join ([chr (ord (char) - l1ll1l_ii_ - (l11l1l_ii_ + l1lll1_ii_) % l11lll1_ii_) for l11l1l_ii_, char in enumerate (l111_ii_)])
	return eval (l1l1ll1_ii_)