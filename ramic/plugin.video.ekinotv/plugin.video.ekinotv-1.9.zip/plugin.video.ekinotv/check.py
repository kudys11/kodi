# -*- coding: utf-8 -*-
import sys
l11111_ef_ = sys.version_info [0] == 2
l1l11l1_ef_ = 2048
l1lllll_ef_ = 7
def l11l1l1_ef_ (ll_ef_):
	global l11lll1_ef_
	l11l1ll_ef_ = ord (ll_ef_ [-1])
	l111l1_ef_ = ll_ef_ [:-1]
	l111_ef_ = l11l1ll_ef_ % len (l111l1_ef_)
	l1lll_ef_ = l111l1_ef_ [:l111_ef_] + l111l1_ef_ [l111_ef_:]
	if l11111_ef_:
		l1ll111_ef_ = unicode () .join ([unichr (ord (char) - l1l11l1_ef_ - (l1ll1l_ef_ + l11l1ll_ef_) % l1lllll_ef_) for l1ll1l_ef_, char in enumerate (l1lll_ef_)])
	else:
		l1ll111_ef_ = str () .join ([chr (ord (char) - l1l11l1_ef_ - (l1ll1l_ef_ + l11l1ll_ef_) % l1lllll_ef_) for l1ll1l_ef_, char in enumerate (l1lll_ef_)])
	return eval (l1ll111_ef_)
import sys,os,re
import urllib,urllib2
import urlparse
l1l111l1_ef_=l11l1l1_ef_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧ࡮࡭ࡳࡵ࠭ࡵࡸ࠱ࡴࡱ࠭ࢺ")
l1l11111_ef_=l11l1l1_ef_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠼࠮࠲࠽ࠣࡶࡻࡀ࠲࠳࠰࠳࠭ࠥࡍࡥࡤ࡭ࡲ࠳࠷࠶࠱࠱࠲࠴࠴࠶ࠦࡆࡪࡴࡨࡪࡴࡾ࠯࠳࠴࠱࠴ࠬࢻ")
def l1l1ll1l_ef_(l1ll1l11_ef_):
    s=l11l1l1_ef_ (u"ࠪࡎ࡮ࡔࡣ࡛ࡅࡶ࠻ࠬࢼ")
    l1ll1l11_ef_ = re.sub(s.decode(l11l1l1_ef_ (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫࢽ")),l11l1l1_ef_ (u"ࠬ࠭ࢾ"),l1ll1l11_ef_)
    l1ll1l11_ef_ = l1ll1l11_ef_.replace(l11l1l1_ef_ (u"࠭ࠦ࡯ࡤࡶࡴࡀ࠭ࢿ"),l11l1l1_ef_ (u"ࠧࠨࣀ"))
    l1ll1l11_ef_ = l1ll1l11_ef_.replace(l11l1l1_ef_ (u"ࠨࠨ࡯ࡸࡀࡨࡲ࠰ࠨࡪࡸࡀ࠭ࣁ"),l11l1l1_ef_ (u"ࠩࠣࠫࣂ"))
    l1ll1l11_ef_ = l1ll1l11_ef_.replace(l11l1l1_ef_ (u"ࠪࠪࡳࡪࡡࡴࡪ࠾ࠫࣃ"),l11l1l1_ef_ (u"ࠫ࠲࠭ࣄ"))
    l1ll1l11_ef_ = l1ll1l11_ef_.replace(l11l1l1_ef_ (u"ࠬࠬࡱࡶࡱࡷ࠿ࠬࣅ"),l11l1l1_ef_ (u"࠭ࠢࠨࣆ")).replace(l11l1l1_ef_ (u"ࠧࠧࡣࡰࡴࡀࡷࡵࡰࡶ࠾ࠫࣇ"),l11l1l1_ef_ (u"ࠨࠤࠪࣈ"))
    l1ll1l11_ef_ = l1ll1l11_ef_.replace(l11l1l1_ef_ (u"ࠩࠩࡳࡦࡩࡵࡵࡧ࠾ࠫࣉ"),l11l1l1_ef_ (u"ࠪࣷࠬ࣊")).replace(l11l1l1_ef_ (u"ࠫࠫࡕࡡࡤࡷࡷࡩࡀ࠭࣋"),l11l1l1_ef_ (u"ࠬࣙࠧ࣌"))
    l1ll1l11_ef_ = l1ll1l11_ef_.replace(l11l1l1_ef_ (u"࠭ࠦࡢ࡯ࡳ࠿ࡴࡧࡣࡶࡶࡨ࠿ࠬ࣍"),l11l1l1_ef_ (u"ࠧࣴࠩ࣎")).replace(l11l1l1_ef_ (u"ࠨࠨࡤࡱࡵࡁࡏࡢࡥࡸࡸࡪࡁ࣏ࠧ"),l11l1l1_ef_ (u"࣐ࠩࣖࠫ"))
    l1ll1l11_ef_ = l1ll1l11_ef_.replace(l11l1l1_ef_ (u"ࠪࠪࡦࡳࡰ࠼࣑ࠩ"),l11l1l1_ef_ (u"࣒ࠫࠫ࠭"))
    l1ll1l11_ef_ = l1ll1l11_ef_.replace(l11l1l1_ef_ (u"ࠬࡢࡵ࠱࠳࠳࠹࣓ࠬ"),l11l1l1_ef_ (u"࠭अࠨࣔ")).replace(l11l1l1_ef_ (u"ࠧ࡝ࡷ࠳࠵࠵࠺ࠧࣕ"),l11l1l1_ef_ (u"ࠨआࠪࣖ"))
    l1ll1l11_ef_ = l1ll1l11_ef_.replace(l11l1l1_ef_ (u"ࠩ࡟ࡹ࠵࠷࠰࠸ࠩࣗ"),l11l1l1_ef_ (u"ࠪऋࠬࣘ")).replace(l11l1l1_ef_ (u"ࠫࡡࡻ࠰࠲࠲࠹ࠫࣙ"),l11l1l1_ef_ (u"ࠬऌࠧࣚ"))
    l1ll1l11_ef_ = l1ll1l11_ef_.replace(l11l1l1_ef_ (u"࠭࡜ࡶ࠲࠴࠵࠾࠭ࣛ"),l11l1l1_ef_ (u"ࠧचࠩࣜ")).replace(l11l1l1_ef_ (u"ࠨ࡞ࡸ࠴࠶࠷࠸ࠨࣝ"),l11l1l1_ef_ (u"ࠩछࠫࣞ"))
    l1ll1l11_ef_ = l1ll1l11_ef_.replace(l11l1l1_ef_ (u"ࠪࡠࡺ࠶࠱࠵࠴ࠪࣟ"),l11l1l1_ef_ (u"ࠫे࠭࣠")).replace(l11l1l1_ef_ (u"ࠬࡢࡵ࠱࠳࠷࠵ࠬ࣡"),l11l1l1_ef_ (u"࠭ुࠨ࣢"))
    l1ll1l11_ef_ = l1ll1l11_ef_.replace(l11l1l1_ef_ (u"ࠧ࡝ࡷ࠳࠵࠹࠺ࣣࠧ"),l11l1l1_ef_ (u"ࠨॆࠪࣤ")).replace(l11l1l1_ef_ (u"ࠩ࡟ࡹ࠵࠷࠴࠵ࠩࣥ"),l11l1l1_ef_ (u"ࠪेࣦࠬ"))
    l1ll1l11_ef_ = l1ll1l11_ef_.replace(l11l1l1_ef_ (u"ࠫࡡࡻ࠰࠱ࡨ࠶ࠫࣧ"),l11l1l1_ef_ (u"ࣹࠬࠧࣨ")).replace(l11l1l1_ef_ (u"࠭࡜ࡶ࠲࠳ࡨ࠸ࣩ࠭"),l11l1l1_ef_ (u"ࠧࣔࠩ࣪"))
    l1ll1l11_ef_ = l1ll1l11_ef_.replace(l11l1l1_ef_ (u"ࠨ࡞ࡸ࠴࠶࠻ࡢࠨ࣫"),l11l1l1_ef_ (u"ࠩफ़ࠫ࣬")).replace(l11l1l1_ef_ (u"ࠪࡠࡺ࠶࠱࠶ࡣ࣭ࠪ"),l11l1l1_ef_ (u"ࠫय़࣮࠭"))
    l1ll1l11_ef_ = l1ll1l11_ef_.replace(l11l1l1_ef_ (u"ࠬࡢࡵ࠱࠳࠺ࡥ࣯ࠬ"),l11l1l1_ef_ (u"࠭ॺࠨࣰ")).replace(l11l1l1_ef_ (u"ࠧ࡝ࡷ࠳࠵࠼࠿ࣱࠧ"),l11l1l1_ef_ (u"ࠨॻࣲࠪ"))
    l1ll1l11_ef_ = l1ll1l11_ef_.replace(l11l1l1_ef_ (u"ࠩ࡟ࡹ࠵࠷࠷ࡤࠩࣳ"),l11l1l1_ef_ (u"ࠪঀࠬࣴ")).replace(l11l1l1_ef_ (u"ࠫࡡࡻ࠰࠲࠹ࡥࠫࣵ"),l11l1l1_ef_ (u"ࠬঁࣶࠧ"))
    return l1ll1l11_ef_
def l1l1l1ll_ef_(url,l1ll1lll_ef_=None):
    if l1ll1lll_ef_:
        l1l1111l_ef_ = urllib.urlencode(l1ll1lll_ef_)
        req = urllib2.Request(url,l1l1111l_ef_)
    else:
        req = urllib2.Request(url)
    req.add_header(l11l1l1_ef_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪࣷ"), l11l1l1_ef_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠺࠳࠷࠻ࠡࡴࡹ࠾࠷࠸࠮࠱ࠫࠣࡋࡪࡩ࡫ࡰ࠱࠵࠴࠶࠶࠰࠲࠲࠴ࠤࡋ࡯ࡲࡦࡨࡲࡼ࠴࠸࠲࠯࠲ࠪࣸ"))
    response = urllib2.urlopen(req)
    l1l1l11_ef_ = response.read()
    response.close()
    return l1l1l11_ef_
def l111ll_ef_(l1l11ll_ef_=l11l1l1_ef_ (u"ࠨࣹࠩ"),l11l11_ef_=l11l1l1_ef_ (u"ࣺࠩࠪ"), l1111ll_ef_=l11l1l1_ef_ (u"ࠪ࠵ࠬࣻ"), url=l11l1l1_ef_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡱࡩ࡯ࡱ࠰ࡸࡻ࠴ࡰ࡭࠱ࡰࡳࡻ࡯ࡥ࠰ࡥࡤࡸ࠴࠭ࣼ")):
    if l1l11ll_ef_ or l11l11_ef_:
        l1ll11ll_ef_ = l11l1l1_ef_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡫ࡪࡰࡲ࠱ࡹࡼ࠮ࡱ࡮࠲ࡱࡴࡼࡩࡦ࠱ࡦࡥࡹ࠵࡫ࡢࡶࡨ࡫ࡴࡸࡩࡢ࡝ࠨࡷࡢ࠱ࡷࡦࡴࡶ࡮ࡦࡡࠥࡴ࡟࠮ࡷࡹࡸ࡯࡯ࡣ࡞ࠩࡸࡣࠫࠨࣽ") %(l1l11ll_ef_,l11l11_ef_,l1111ll_ef_)
    else:
        l1ll11ll_ef_ = url
    print l1ll11ll_ef_
    content  = l1l1l1ll_ef_(l1ll11ll_ef_)
    return _1l11l11_ef_(content)
def _1l11l11_ef_(content):
    l11lllll_ef_ = [(a.start(), a.end()) for a in re.finditer(l11l1l1_ef_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡲࡵࡶࡪࡧࡶ࠱ࡱ࡯ࡳࡵ࠯࡬ࡸࡪࡳࠢࠨࣾ"), content)]
    l11lllll_ef_.append( (-1,-1) )
    res=[]
    for i in range(len(l11lllll_ef_[:-1])):
        l111111_ef_ = content[ l11lllll_ef_[i][1]:l11lllll_ef_[i+1][0] ]
        l1l1lll1_ef_ = re.compile(l11l1l1_ef_ (u"ࠧ࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠴ࡹࡴࡢࡶ࡬ࡧ࠴ࡺࡨࡶ࡯ࡥ࠳࠳࠰࠮࡫ࡲࡪ࠭ࠧࠦࡡ࡭ࡶࡀࠫࣿ")).findall(l111111_ef_)
        title = re.compile(l11l1l1_ef_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡴࡪࡶ࡯ࡩࠧࡄ࡛࡝ࡵࡠ࠮ࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠾ࡥࡶࡃ࠭ऀ")).findall(l111111_ef_)
        l1l111ll_ef_ = re.compile(l11l1l1_ef_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡱࡹ࡭ࡪࡊࡥࡴࡥࠥࡂࡠࡢࡳ࡝ࡰࡠ࠮࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩँ")).findall(l111111_ef_)
        l1llllll_ef_ = re.compile(l11l1l1_ef_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡵࡸࡱ࠲ࡼ࡯ࡵࡧࠥࡂࡁࡡ࡞࠿࡟࠭ࡂ࠭ࡡ࡞࠿࡟࠭࠭ࡁ࠵ࡤࡪࡸࡁࠫं")).findall(l111111_ef_)
        l1lllll1_ef_ = re.compile(l11l1l1_ef_ (u"ࠫࡁࡶࠠࡤ࡮ࡤࡷࡸࡃࠢࡤࡣࡷࡩࡸࠨ࠾ࠩ࠰࠭࠭ࠥࡢࡼࠨः")).findall(l111111_ef_)
        l1l1l1l1_ef_ = re.compile(l11l1l1_ef_ (u"ࠬࡂࡰࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡤࡸࡪࡹࠢ࠿ࠪ࠱࠮࠮ࠦ࡜ࡽࠢࠫࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠵࡭ࡰࡸ࡬ࡩ࠴ࡩࡡࡵ࠱࡮ࡥࡹ࡫ࡧࡰࡴ࡬ࡥࡡࡡ࡜ࡥ࠭࡟ࡡࠧࡄ࠮ࠫ࠾࠲ࡥࡃࡡࠬ࡞ࠬࠬ࠮ࡁ࠵ࡰ࠿ࠩऄ")).findall(l111111_ef_)
        l1lll11l_ef_ = re.compile(l11l1l1_ef_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦ࡮ࡴࡦࡰ࠯ࡦࡥࡹ࡫ࡧࡰࡴ࡬ࡩࡸࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫअ"),re.DOTALL).findall(l111111_ef_)
        if l1lll11l_ef_:
            l1lll11l_ef_ = l11l1l1_ef_ (u"ࠧࠨआ").join(re.compile(l11l1l1_ef_ (u"ࠨࡀࠫ࠲࠯ࡅࠩ࠽ࠩइ")).findall(l1lll11l_ef_[0]))
        if title:
            out={}
            out[l11l1l1_ef_ (u"ࠩ࡫ࡶࡪ࡬ࠧई")] = title[0][0]
            out[l11l1l1_ef_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩउ")] = l1l1ll1l_ef_(title[0][1].replace(l11l1l1_ef_ (u"ࠫ࠲ࠦࡈࡅࠩऊ"),l11l1l1_ef_ (u"ࠬ࠭ऋ"))).strip(l11l1l1_ef_ (u"࠭࡜࡯ࠢࠪऌ"))
            out[l11l1l1_ef_ (u"ࠧࡺࡧࡤࡶࠬऍ")] = l1lllll1_ef_[0] if l1lllll1_ef_ else l11l1l1_ef_ (u"ࠨࠩऎ")
            out[l11l1l1_ef_ (u"ࠩࡪࡩࡳࡸࡥࠨए")] = l11l1l1_ef_ (u"ࠪࠫऐ").join(re.compile(l11l1l1_ef_ (u"ࠫࡃ࠮࠮ࠫࡁࠬࡀࠬऑ")).findall(l1l1l1l1_ef_[0][1])) if l1l1l1l1_ef_ else l11l1l1_ef_ (u"ࠬ࠭ऒ")
            out[l11l1l1_ef_ (u"࠭ࡣࡰࡦࡨࠫओ")] = l11l1l1_ef_ (u"ࠧࡉࡆࠪऔ") if l11l1l1_ef_ (u"ࠨࡊࡇࠫक") in out[l11l1l1_ef_ (u"ࠩࡪࡩࡳࡸࡥࠨख")] else l11l1l1_ef_ (u"ࠪࠫग")
            out[l11l1l1_ef_ (u"ࠫࡵࡲ࡯ࡵࠩघ")] = l1l1ll1l_ef_(l1l111ll_ef_[0].strip(l11l1l1_ef_ (u"ࠬࡢ࡮ࠡࠩङ"))) if l1l111ll_ef_ else l11l1l1_ef_ (u"࠭ࠧच")
            out[l11l1l1_ef_ (u"ࠧࡳࡣࡷ࡭ࡳ࡭ࠧछ")] = l1llllll_ef_[0].strip() if l1llllll_ef_ else l11l1l1_ef_ (u"ࠨࠩज")
            out[l11l1l1_ef_ (u"ࠩ࡬ࡱ࡬࠭झ")] = l1l111l1_ef_+l1l1lll1_ef_[0].replace(l11l1l1_ef_ (u"ࠪ࠳ࡹ࡮ࡵ࡮ࡤ࠲ࠫञ"),l11l1l1_ef_ (u"ࠫ࠴ࡴ࡯ࡳ࡯ࡤࡰ࠴࠭ट")) if l1l1lll1_ef_ else l11l1l1_ef_ (u"ࠬ࠭ठ")
            res.append(out)
    return res
def l11l1_ef_(url=l11l1l1_ef_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡬࡫ࡱࡳ࠲ࡺࡶ࠯ࡲ࡯࠳ࡲࡵࡶࡪࡧ࠲ࡷ࡭ࡵࡷ࠰࡯ࡲ࡮࠲ࡶࡲࡻࡻ࡭ࡥࡨ࡯ࡥ࡭࠯ࡶࡱࡴࡱ࠭ࡩࡦ࠰ࡴࡪࡺࡥࡴ࠯ࡧࡶࡦ࡭࡯࡯࠯࠵࠴࠶࠼࠭ࡥࡷࡥࡦ࡮ࡴࡧ࠰࠳࠼࠼࠽࠽ࠧड")):
    if not url.startswith(l11l1l1_ef_ (u"ࠧࡩࡶࡷࡴ࠿࠭ढ")):
        url = urlparse.urljoin(l1l111l1_ef_,url)
    content  = l1l1l1ll_ef_(url)
    l1ll1111_ef_ = re.compile(l11l1l1_ef_ (u"ࠨࡕ࡫ࡳࡼࡖ࡬ࡢࡻࡨࡶࡡ࠮࡛ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝࠭࡝ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟࡟࠭ࠬण")).findall(content)
    _1ll11l_ef_=[]
    _111l1l_ef_=[]
    for host,l1l1l11_ef_ in l1ll1111_ef_:
        _111l1l_ef_.append(l1l1l11_ef_)
        _1ll11l_ef_.append(host)
    return (_1ll11l_ef_,_111l1l_ef_)
def l11ll1l_ef_(host=l11l1l1_ef_ (u"ࠩࡲࡴࡪࡴ࡬ࡰࡣࡧࠫत"),id=l11l1l1_ef_ (u"ࠪࡧࡍࡲ࠱࡛ࡗ࡙࠹࡙࠹ࡨࡃࡧࡗࡰࡹࡘ࠱ࡗࡹࡓࡕࡨࡲ࡭࡯ࠩथ")):
    l1l1l111_ef_=l11l1l1_ef_ (u"ࠫࠬद")
    url=urlparse.urljoin(l1l111l1_ef_,l11l1l1_ef_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࡬࠯ࠨध")) + host + l11l1l1_ef_ (u"࠭࠯ࠨन") + id
    content  = l1l1l1ll_ef_(url)
    l1l1l11_ef_ = re.compile(l11l1l1_ef_ (u"ࠧࡷࡣࡵࠤࡺࡸ࡬࡝ࡵ࠭ࡁࡡࡹࠪ࡜࡞ࠪࠦࡢ࠮࠮ࠫࡁࠬ࡟ࡡ࠭ࠢ࡞ࠩऩ")).findall(content)
    if l1l1l11_ef_:
        if l1l1l11_ef_[0].startswith(l11l1l1_ef_ (u"ࠨ࠱ࡺࡥࡹࡩࡨ࠯ࡲ࡫ࡴࡄ࠭प")):
            data  = l1l1l1ll_ef_(urlparse.urljoin(l1l111l1_ef_,l1l1l11_ef_[0]) )
            l1l11lll_ef_ = re.findall(l11l1l1_ef_ (u"ࠩࡶࡶࡨࡃ࡛ࠣ࡞ࠪࡡ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࠬफ"),data,re.I)
            for s in l1l11lll_ef_:
                l1l1l111_ef_ = s
                if l11l1l1_ef_ (u"ࠪ࡬ࡴࡹࡴࠨब") in l1l1l111_ef_:
                    break
        else:
            l1l1l111_ef_= l1l1l11_ef_[0]
    return l1l1l111_ef_
def _1ll1ll1_ef_(url=l11l1l1_ef_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳ࡸ࡮࡯ࡸ࠱ࡳࡥࡷࡺࡹࡻࡣࡱࡸ࠲ࡴࡡࡱ࡫ࡶࡽ࠲ࡶ࡬࠮ࡲࡤࡶࡹ࡯ࡳࡢࡰ࠰࠶࠵࠷࠵࠮ࡰࡤࡴ࡮ࡹࡹ࠰࠹࠼࠴࠾࠭भ")):
    content  = l1l1l1ll_ef_(l1l111l1_ef_+url)
    l1ll1111_ef_ = re.compile(l11l1l1_ef_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪ࠮࠮ࠫࠫࡁࡀ࠴࡯ࡦࡳࡣࡰࡩࡃࡢ࡮ࠨम"), re.DOTALL).findall(content)
    _1ll11l_ef_=[]
    _111l1l_ef_=[]
    for f in l1ll1111_ef_:
        l1llll11_ef_ = re.compile(l11l1l1_ef_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫय"), re.DOTALL).findall(content)
        for l1lll1l1_ef_ in l1llll11_ef_:
            if l11l1l1_ef_ (u"ࠧࡩࡱࡶࡸ࡮ࡴࡧ࠾ࡸࡶ࡬ࡦࡸࡥࠨर") in l1lll1l1_ef_:
                l1lll1l1_ef_=l11l1l1_ef_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡸࡶ࡬ࡦࡸࡥ࠯࡫ࡲ࠳ࡻ࠵ࠥࡴ࠱ࡺ࡭ࡩࡺࡨ࠮࠸࠷࠴࠴࡮ࡥࡪࡩ࡫ࡸ࠲࠺࠰࠱࠱ࠪऱ")  % (l1lll1l1_ef_.split(l11l1l1_ef_ (u"ࠩࡀࠫल"))[-1])
            if l1lll1l1_ef_.startswith(l11l1l1_ef_ (u"ࠪ࡬ࡹࡺࡰࠨळ")):
                _111l1l_ef_.append(l1lll1l1_ef_)
                _1ll11l_ef_.append(l1lll1l1_ef_.split(l11l1l1_ef_ (u"ࠫ࠴࠭ऴ"))[2])
    return (_1ll11l_ef_,_111l1l_ef_)
def l1l1ll1_ef_(url=l11l1l1_ef_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡫ࡪࡰࡲ࠱ࡹࡼ࠮ࡱ࡮࠲ࡱࡴࡼࡩࡦ࠱ࡦࡥࡹ࠵ࠧव")):
    content  = l1l1l1ll_ef_(url)
    l1l1ll11_ef_ = re.compile(l11l1l1_ef_ (u"࠭࠼࡭࡫ࠣࡨࡦࡺࡡ࠮࡫ࡧࡁࠧ࠮࡜ࡥ࠭ࠬࠦࡃࡡ࡜ࡴ࡞ࡱࡡ࠰ࡂࡡࠡࡪࡵࡩ࡫ࡃࠢ࠰࡯ࡲࡺ࡮࡫࠯ࡤࡣࡷ࠳ࡰࡧࡴࡦࡩࡲࡶ࡮ࡧ࡜࡜࡞ࡧ࠯ࡡࡣࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁ࡟ࡡࡹ࡜࡯࡟࠭ࡀ࠴ࡲࡩ࠿ࠩश")).findall(content)
    l1lll1ll_ef_ = [x[0] for x in l1l1ll11_ef_]
    l1ll1l1l_ef_ = [x[1] for x in l1l1ll11_ef_]
    return (l1ll1l1l_ef_,l1lll1ll_ef_)
def l1111l_ef_(l1ll11l1_ef_=l11l1l1_ef_ (u"ࠧࡑ࡫ࡵࡥࡨ࡯ࠧष")):
    l1l1llll_ef_ = {l11l1l1_ef_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡨ࡬ࡩࡱࡪࠧस"): l1ll11l1_ef_}
    content = l1l1l1ll_ef_(l11l1l1_ef_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨ࡯࡮ࡴ࡯࠮ࡶࡹ࠲ࡵࡲ࠯ࡴࡧࡤࡶࡨ࡮࠯ࠨह"), l1l1llll_ef_)
    return _1l11l11_ef_(content)
def l1llll_ef_(url=l11l1l1_ef_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧ࠲ࡧࡦࡺࡡ࡭ࡱࡪ࠳࡜࠭ऺ")):
    content  = l1l1l1ll_ef_(l1l111l1_ef_+url)
    out = _1l11l11_ef_(content)
    return out
def l11l_ef_():
    content  = l1l1l1ll_ef_(l11l1l1_ef_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡱࡩ࡯ࡱ࠰ࡸࡻ࠴ࡰ࡭࠱ࡶࡩࡷ࡯ࡥ࠰ࠩऻ"))
    l1llll1l_ef_ = re.compile(l11l1l1_ef_ (u"ࠬࡂࡵ࡭ࠢࡦࡰࡦࡹࡳ࠾ࠤࡶࡩࡷ࡯ࡡ࡭ࡵࡰࡩࡳࡻࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂ़ࠬ"),re.DOTALL).findall(content)
    out=[]
    if l1llll1l_ef_:
        items = re.compile(l11l1l1_ef_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿࠾ࡶࡴࡦࡴࠠࡤ࡮ࡤࡷࡸࡃࠢ࡯ࡣࡰࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡱࡣࡱࡂࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡻ࡮ࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿࠾࠲ࡥࡃ࠭ऽ")).findall(l1llll1l_ef_[0])
        for item in items:
            out.append({l11l1l1_ef_ (u"ࠧࡩࡴࡨࡪࠬा"):item[0],l11l1l1_ef_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧि"):l11l1l1_ef_ (u"ࠩࠨࡷࠥ࠮࡛ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࠪࡹ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠪࠩी")%(item[1],item[2])})
    return out
def l1lll1l_ef_(url):
    content = l1l1l1ll_ef_(l1l111l1_ef_+url)
    l1l11l1l_ef_ = re.compile(l11l1l1_ef_ (u"ࠪࡀࡺࡲࠠࡤ࡮ࡤࡷࡸࡃࠢ࡭࡫ࡶࡸ࠲ࡹࡥࡳ࡫ࡨࡷࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡵ࡭ࡀࠪु"),re.DOTALL).findall(content)
    out=[]
    for l1l1l11l_ef_ in l1l11l1l_ef_:
        l1lll111_ef_ = re.compile(l11l1l1_ef_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩू")).findall(l1l1l11l_ef_)
        for e in l1lll111_ef_:
            href = e[0]
            title = e[1]
            l1l11ll1_ef_ = re.compile(l11l1l1_ef_ (u"ࠬࡹࡥࡢࡵࡲࡲࡡࡡࠨ࡝ࡦ࠮࠭ࡡࡣࠧृ")).findall(href)
            l1l11ll1_ef_ = int(l1l11ll1_ef_[0]) if l1l11ll1_ef_ else l11l1l1_ef_ (u"࠭ࠧॄ")
            l1ll111l_ef_ = re.compile(l11l1l1_ef_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥ࡝࡝ࠫࡠࡩ࠱ࠩ࡝࡟ࠪॅ")).findall(href)
            l1ll111l_ef_ = int(l1ll111l_ef_[0]) if l1ll111l_ef_ else l11l1l1_ef_ (u"ࠨࠩॆ")
            l1lll1l1_ef_ = { l11l1l1_ef_ (u"ࠩ࡫ࡶࡪ࡬ࠧे")  : href,
                    l11l1l1_ef_ (u"ࠪࡷࡪࡧࡳࡰࡰࠪै") : l1l11ll1_ef_,
                    l11l1l1_ef_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࠬॉ") : l1ll111l_ef_,
                    l11l1l1_ef_ (u"ࠬࡳࡥࡥ࡫ࡤࡸࡾࡶࡥࠨॊ"): l11l1l1_ef_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࠧो"),
                    l11l1l1_ef_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ौ") : l11l1l1_ef_ (u"ࠨࡕࠨ࠴࠷ࡪࡅࠦ࠲࠵ࡨࠥࠫࡳࠨ्")%(l1l11ll1_ef_,l1ll111l_ef_, l1l1ll1l_ef_(title.strip()))}
            out.append(l1lll1l1_ef_)
    return out
