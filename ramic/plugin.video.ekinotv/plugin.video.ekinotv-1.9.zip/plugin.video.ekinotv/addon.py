# -*- coding: utf-8 -*-
import sys
l11111_ef_ = sys.version_info [0] == 2
l1l11l1_ef_ = 2048
l1lllll_ef_ = 7
def l11l1l1_ef_ (ll_ef_):
	global l11lll1_ef_
	l11l1ll_ef_ = ord (ll_ef_ [-1])
	l111l1_ef_ = ll_ef_ [:-1]
	l111_ef_ = l11l1ll_ef_ % len (l111l1_ef_)
	l1lll_ef_ = l111l1_ef_ [:l111_ef_] + l111l1_ef_ [l111_ef_:]
	if l11111_ef_:
		l1ll111_ef_ = unicode () .join ([unichr (ord (char) - l1l11l1_ef_ - (l1ll1l_ef_ + l11l1ll_ef_) % l1lllll_ef_) for l1ll1l_ef_, char in enumerate (l1lll_ef_)])
	else:
		l1ll111_ef_ = str () .join ([chr (ord (char) - l1l11l1_ef_ - (l1ll1l_ef_ + l11l1ll_ef_) % l1lllll_ef_) for l1ll1l_ef_, char in enumerate (l1lll_ef_)])
	return eval (l1ll111_ef_)
import sys,os,re
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import urlresolver,time
import check as l1lll1_ef_
import ramic as l111l_ef_
import resources.lib.l1ll1l1_ef_ as l1ll1_ef_
l1l111_ef_ = sys.argv[0]
l1lll11_ef_ = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])
l1l1ll_ef_ = xbmcaddon.Addon()
def l11l1l_ef_(name,mode=l11l1l1_ef_ (u"ࠫࠬࠀ"),l1l11ll_ef_=l11l1l1_ef_ (u"ࠬ࠭ࠁ"),l11l11_ef_=l11l1l1_ef_ (u"࠭ࠧࠂ"),l1111ll_ef_=l11l1l1_ef_ (u"ࠧ࠲ࠩࠃ"),ex_link=None,infoLabels=None,iconImage=l11l1l1_ef_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬࠄ")):
    url = l1l1_ef_({l11l1l1_ef_ (u"ࠩࡰࡳࡩ࡫ࠧࠅ"): mode, l11l1l1_ef_ (u"ࠪࡪࡴࡲࡤࡦࡴࡱࡥࡲ࡫ࠧࠆ"): name, l11l1l1_ef_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬࠇ") : ex_link,l11l1l1_ef_ (u"ࠬࡱࡡࡵࠩࠈ") : l1l11ll_ef_,l11l1l1_ef_ (u"࠭ࡷࡦࡴࠪࠉ") : l11l11_ef_,l11l1l1_ef_ (u"ࠧࡱࡣࡪࡩࠬࠊ") : l1111ll_ef_})
    l11ll1_ef_ = xbmcgui.ListItem(name)
    l1111l1_ef_=[l11l1l1_ef_ (u"ࠨࡶ࡫ࡹࡲࡨࠧࠋ"),l11l1l1_ef_ (u"ࠩࡳࡳࡸࡺࡥࡳࠩࠌ"),l11l1l1_ef_ (u"ࠪࡦࡦࡴ࡮ࡦࡴࠪࠍ"),l11l1l1_ef_ (u"ࠫࡨࡲࡥࡢࡴࡤࡶࡹ࠭ࠎ"),l11l1l1_ef_ (u"ࠬࡩ࡬ࡦࡣࡵࡰࡴ࡭࡯ࠨࠏ"),l11l1l1_ef_ (u"࠭ࡩࡤࡱࡱࠫࠐ")]
    l1l_ef_ = dict(zip(l1111l1_ef_,[iconImage for x in l1111l1_ef_]))
    l11ll1_ef_.setArt(l1l_ef_)
    if not infoLabels:
        infoLabels={l11l1l1_ef_ (u"ࠢࡕ࡫ࡷࡰࡪࠨࠑ"): name}
    l11ll1_ef_.setInfo(type=l11l1l1_ef_ (u"ࠣࡘ࡬ࡨࡪࡵࠢࠒ"), infoLabels=infoLabels)
    xbmcplugin.addDirectoryItem(handle=l1lll11_ef_, url=url,listitem=l11ll1_ef_, isFolder=True)
def l1l1_ef_(query):
    return l1l111_ef_ + l11l1l1_ef_ (u"ࠩࡂࠫࠓ") + urllib.urlencode(query)
l1l11_ef_ = lambda x,y: ord(x)+10*y if ord(x)%2 else ord(x)
l11_ef_ = lambda l11ll_ef_: l11l1l1_ef_ (u"ࠪࠫࠔ").join([chr(l1l11_ef_(x,1) ) for x in l11ll_ef_.encode(l11l1l1_ef_ (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫࠕ")).strip()])
l111l11_ef_ = lambda l11ll_ef_: l11l1l1_ef_ (u"ࠬ࠭ࠖ").join([chr(l1l11_ef_(x,-1) ) for x in l11ll_ef_]).decode(l11l1l1_ef_ (u"࠭ࡢࡢࡵࡨ࠺࠹࠭ࠗ"))
if not os.path.exists(l11l1l1_ef_ (u"ࠧ࠰ࡪࡲࡱࡪ࠵࡯ࡴ࡯ࡦࠫ࠘")):
    tm=time.gmtime()
    try:    l11lll_ef_,l11llll_ef_,l1l1l1_ef_ = l111l11_ef_(l1l1ll_ef_.getSetting(l11l1l1_ef_ (u"ࠨ࡭ࡲࡨࠬ࠙"))).split(l11l1l1_ef_ (u"ࠩ࠽ࠫࠚ"))
    except: l11lll_ef_,l11llll_ef_,l1l1l1_ef_ =  [l11l1l1_ef_ (u"ࠪ࠱࠶࠭ࠛ"),l11l1l1_ef_ (u"ࠫࠬࠜ"),l11l1l1_ef_ (u"ࠬ࠳࠱ࠨࠝ")]
    if int(l11lll_ef_) != tm.tm_hour:
        try:    l1ll1ll_ef_ = re.findall(l11l1l1_ef_ (u"࠭ࡋࡐࡆ࠽ࠤ࠭࠴ࠪࡀࠫ࡟ࡲࠬࠞ"),urllib2.urlopen(l11l1l1_ef_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡴࡤࡻ࠳࡭ࡩࡵࡪࡸࡦࡺࡹࡥࡳࡥࡲࡲࡹ࡫࡮ࡵ࠰ࡦࡳࡲ࠵ࡲࡢ࡯࡬ࡧࡸࡶࡡ࠰࡭ࡲࡨ࡮࠵࡭ࡢࡵࡷࡩࡷ࠵ࡒࡆࡃࡇࡑࡊ࠴࡭ࡥࠩࠟ")).read())[0].strip(l11l1l1_ef_ (u"ࠨࠬࠪࠠ"))
        except: l1ll1ll_ef_ = l11l1l1_ef_ (u"ࠩࠪࠡ")
def l1l111l_ef_(ex_link):
    (_1ll11l_ef_,_111l1l_ef_)=l1lll1_ef_.l11l1_ef_(ex_link)
    if _1ll11l_ef_:
        l1llll1_ef_=l11l1l1_ef_ (u"࠭ࠧࠬ")
        l1l1l_ef_ = xbmcgui.Dialog().select(l11l1l1_ef_ (u"ࠧࡘࡻࡥ࡭ࡪࡸࡺࠡॼࡵࣷࡩै࡯ࠨ࠭"), _1ll11l_ef_)
        if l1l1l_ef_>-1:
            l1l1l11_ef_ = l1lll1_ef_.l11ll1l_ef_(_1ll11l_ef_[l1l1l_ef_],_111l1l_ef_[l1l1l_ef_])
            if l1l1l11_ef_:
                l1llll1_ef_ = l111l_ef_.__mysolver__.go(l1l1l11_ef_)
                if not l1llll1_ef_:
                    try:
                        l111ll1_ef_ = urlresolver.resolve(l1l1l11_ef_)
                    except Exception,e:
                        l1llll1_ef_=l11l1l1_ef_ (u"ࠨࠩ࠮")
                        s = xbmcgui.Dialog().ok(l11l1l1_ef_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡵࡩࡩࡣࡐࡳࡱࡥࡰࡪࡳ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ࠯"),l11l1l1_ef_ (u"ࠪࡑࡴংࡥࠡ࡫ࡱࡲࡾࠦ࡬ࡪࡰ࡮ࠤࡧटࡤࡻ࡫ࡨࠤࡩࢀࡩࡢॄࡤॆࡄ࠭࠰"),l11l1l1_ef_ (u"࡚ࠫࡘࡌࠡࡴࡨࡷࡴࡲࡶࡦࡴࠣࡉࡗࡘࡏࡓ࠼ࠣ࡟ࠪࡹ࡝ࠨ࠱")%str(e))
                if l1llll1_ef_:
                    xbmcplugin.setResolvedUrl(l1lll11_ef_, True, xbmcgui.ListItem(path=l1llll1_ef_))
                else:
                    xbmcplugin.setResolvedUrl(l1lll11_ef_, False, xbmcgui.ListItem(path=l11l1l1_ef_ (u"ࠬ࠭࠲")))
    else:
        xbmcgui.Dialog().ok(l11l1l1_ef_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠࡔࡷࡵࡢ࡭ࡧࡰ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ࠳"),l11l1l1_ef_ (u"ࠧࡃࡴࡤ࡯ࠥࡲࡩ࡯࡭ࣶࡻࡄ࠭࠴"))
        xbmcplugin.setResolvedUrl(l1lll11_ef_, False, xbmcgui.ListItem(path=l11l1l1_ef_ (u"ࠨࠩ࠵")))
def l11ll11_ef_(name, url, mode, l1_ef_=l11l1l1_ef_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬࠭࠶"), infoLabels={}, IsPlayable=True, fanart=None, l1l11ll_ef_=l11l1l1_ef_ (u"ࠪࠫ࠷"),l11l11_ef_=l11l1l1_ef_ (u"ࠫࠬ࠸"),l1111ll_ef_=l11l1l1_ef_ (u"ࠬ࠷ࠧ࠹")):
    u = l1l1_ef_({l11l1l1_ef_ (u"࠭࡭ࡰࡦࡨࠫ࠺"): mode, l11l1l1_ef_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫ࠻"): name, l11l1l1_ef_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩ࠼") : url,l11l1l1_ef_ (u"ࠩ࡮ࡥࡹ࠭࠽") : l1l11ll_ef_,l11l1l1_ef_ (u"ࠪࡻࡪࡸࠧ࠾") : l11l11_ef_,l11l1l1_ef_ (u"ࠫࡵࡧࡧࡦࠩ࠿") : l1111ll_ef_})
    l11l111_ef_ = xbmcgui.ListItem(name)
    l1111l1_ef_=[l11l1l1_ef_ (u"ࠬࡺࡨࡶ࡯ࡥࠫࡀ"),l11l1l1_ef_ (u"࠭ࡰࡰࡵࡷࡩࡷ࠭ࡁ"),l11l1l1_ef_ (u"ࠧࡣࡣࡱࡲࡪࡸࠧࡂ"),l11l1l1_ef_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨࡃ"),l11l1l1_ef_ (u"ࠩࡦࡰࡪࡧࡲࡢࡴࡷࠫࡄ"),l11l1l1_ef_ (u"ࠪࡧࡱ࡫ࡡࡳ࡮ࡲ࡫ࡴ࠭ࡅ"),l11l1l1_ef_ (u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫ࠧࡆ"),l11l1l1_ef_ (u"ࠬ࡯ࡣࡰࡰࠪࡇ")]
    l1l_ef_ = dict(zip(l1111l1_ef_,[l1_ef_ for x in l1111l1_ef_]))
    l1l_ef_[l11l1l1_ef_ (u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦࠩࡈ")] = fanart if fanart else l1l_ef_[l11l1l1_ef_ (u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪࡉ")]
    l11l111_ef_.setArt(l1l_ef_)
    if not infoLabels:
        infoLabels={l11l1l1_ef_ (u"ࠣࡖ࡬ࡸࡱ࡫ࠢࡊ"): name}
    l11l111_ef_.setInfo(type=l11l1l1_ef_ (u"ࠤ࡙࡭ࡩ࡫࡯ࠣࡋ"), infoLabels=infoLabels)
    if IsPlayable:
        l11l111_ef_.setProperty(l11l1l1_ef_ (u"ࠪࡍࡸࡖ࡬ࡢࡻࡤࡦࡱ࡫ࠧࡌ"), l11l1l1_ef_ (u"ࠫࡹࡸࡵࡦࠩࡍ"))
    if fanart:
        l11l111_ef_.setProperty(l11l1l1_ef_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࡤ࡯࡭ࡢࡩࡨࠫࡎ"),fanart)
    l1ll11_ef_ = []
    l1ll11_ef_.append((l11l1l1_ef_ (u"࠭ࡉ࡯ࡨࡲࡶࡲࡧࡣ࡫ࡣࠪࡏ"), l11l1l1_ef_ (u"࡙ࠧࡄࡐࡇ࠳ࡇࡣࡵ࡫ࡲࡲ࠭ࡏ࡮ࡧࡱࠬࠫࡐ")))
    l11l111_ef_.addContextMenuItems(l1ll11_ef_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l1lll11_ef_, url=u, listitem=l11l111_ef_)
    xbmcplugin.addSortMethod(l1lll11_ef_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l11l1l1_ef_ (u"ࠣࠧࡕ࠰ࠪ࡟ࠬࠦࡒࠥࡑ"))
    return ok
def l1l11l_ef_(l1l11ll_ef_,l11l11_ef_,l1111ll_ef_,ex_link):
    l11111l_ef_= l1lll1_ef_.l111ll_ef_(l1l11ll_ef_=l1l11ll_ef_,l11l11_ef_=l11l11_ef_, l1111ll_ef_=l1111ll_ef_,url=ex_link)
    if int(l1111ll_ef_)>1:
        l11ll11_ef_(l11l1l1_ef_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡪࡳࡱࡪ࡝࠽࠾ࠣࡔࡴࡶࡲࡻࡧࡧࡲ࡮ࡧࠠࡔࡶࡵࡳࡳࡧࠠࠦࡦࠣࡀࡁࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࡒ") %(int(l1111ll_ef_)-1), url=ex_link , mode=l11l1l1_ef_ (u"ࠪࡣࡤࡶࡡࡨࡧࡢࡣࠬࡓ"), l1l11ll_ef_=l1l11ll_ef_,l11l11_ef_=l11l11_ef_,l1111ll_ef_= int(l1111ll_ef_)-1, IsPlayable=False)
    for p in l11111l_ef_:
        l11ll11_ef_(name=p[l11l1l1_ef_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪࡔ")],url=p[l11l1l1_ef_ (u"ࠬ࡮ࡲࡦࡨࠪࡕ")],mode=l11l1l1_ef_ (u"࠭ࡃࡩࡱࡲࡷࡪࡇ࡮ࡥࡒ࡯ࡥࡾ࠭ࡖ"),l1_ef_=p[l11l1l1_ef_ (u"ࠧࡪ࡯ࡪࠫࡗ")],infoLabels=p,fanart=p[l11l1l1_ef_ (u"ࠨ࡫ࡰ࡫ࠬࡘ")])
    l11ll11_ef_(l11l1l1_ef_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡪࡳࡱࡪ࡝࠿ࡀࠣࡒࡦࡹࡴचࡲࡱࡥ࡙ࠥࡴࡳࡱࡱࡥࠥࠫࡤࠡࡀࡁ࡟࠴ࡉࡏࡍࡑࡕࡡ࡙ࠬ") %(int(l1111ll_ef_)+1), url=ex_link , mode=l11l1l1_ef_ (u"ࠪࡣࡤࡶࡡࡨࡧࡢࡣ࡚ࠬ"), l1l11ll_ef_=l1l11ll_ef_,l11l11_ef_=l11l11_ef_,l1111ll_ef_= int(l1111ll_ef_)+1, IsPlayable=False)
    xbmcplugin.addSortMethod( handle=l1lll11_ef_, sortMethod=xbmcplugin.SORT_METHOD_GENRE )
def l1l1l1l_ef_(ex_link):
    if l11l1l1_ef_ (u"ࠫࡴࡶࡥ࡯࡮ࡲࡥࡩ࠴ࡣࡰ࠱ࡶࡸࡷ࡫ࡡ࡮࡛ࠩ") in ex_link:
        l1llll1_ef_=ex_link
    else:
        l1llll1_ef_ = urlresolver.resolve(ex_link)
    if l1llll1_ef_:
        listitem = xbmcgui.ListItem(path=l1llll1_ef_)
        xbmcplugin.setResolvedUrl(l1lll11_ef_, True, listitem)
xbmcplugin.setContent(l1lll11_ef_, l11l1l1_ef_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࠬ࡜"))
mode = args.get(l11l1l1_ef_ (u"࠭࡭ࡰࡦࡨࠫ࡝"), None)
fname = args.get(l11l1l1_ef_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫ࡞"),[l11l1l1_ef_ (u"ࠨࠩ࡟")])[0]
ex_link = args.get(l11l1l1_ef_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪࡠ"),[l11l1l1_ef_ (u"ࠪࠫࡡ")])[0]
l1l11ll_ef_ = args.get(l11l1l1_ef_ (u"ࠫࡰࡧࡴࠨࡢ"),[l11l1l1_ef_ (u"ࠬ࠭ࡣ")])[0]
l11l11_ef_ = args.get(l11l1l1_ef_ (u"࠭ࡷࡦࡴࠪࡤ"),[l11l1l1_ef_ (u"ࠧࠨࡥ")])[0]
l1111ll_ef_ = args.get(l11l1l1_ef_ (u"ࠨࡲࡤ࡫ࡪ࠭ࡦ"),[l11l1l1_ef_ (u"ࠩࠪࡧ")])[0]
def l1l1111_ef_():
    _1l1lll_ef_=[l11l1l1_ef_ (u"ࠪࡒࡦࡶࡩࡴࡻࠪࡨ"),l11l1l1_ef_ (u"ࠫࡑ࡫࡫ࡵࡱࡵࠫࡩ"),l11l1l1_ef_ (u"ࠬࡊࡵࡣࡤ࡬ࡲ࡬࠭ࡪ"),l11l1l1_ef_ (u"࠭ࡅࡏࡉࠪ࡫"),l11l1l1_ef_ (u"ࠧࡑࡎࠪ࡬")]
    l1ll_ef_=l11l1l1_ef_ (u"ࠨࠩ࡭")
    for w in _1l1lll_ef_:
        if l1l1ll_ef_.getSetting(w)==l11l1l1_ef_ (u"ࠩࡷࡶࡺ࡫ࠧ࡮"):
            if l1ll_ef_:
                l1ll_ef_ += l11l1l1_ef_ (u"ࠪ࠰ࠬ࡯")
            l1ll_ef_ += w
    return l1ll_ef_
l1ll_ef_  = l1l1111_ef_()
if mode is None:
    l11l1l_ef_(l11l1l1_ef_ (u"ࠫࡎࡴࡦࡰࡴࡰࡥࡨࡰࡡࠨࡰ"),mode=l11l1l1_ef_ (u"ࠬࡥࡩ࡯ࡨࡲࡣࠬࡱ"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l11l1l1_ef_ (u"࠭ࡰࡢࡶ࡫ࠫࡲ")))+l11l1l1_ef_ (u"ࠧ࠰࡫ࡦࡳࡳ࠴ࡰ࡯ࡩࠪࡳ"),)
    l11l1l_ef_(l11l1l1_ef_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣࡆࡪ࡮ࡰࡽࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࡴ"),mode=l11l1l1_ef_ (u"ࠩࡩ࡭ࡱࡳࡹࠨࡵ"),l1l11ll_ef_=l11l1l1_ef_ (u"ࠪࠫࡶ"),l11l11_ef_=l1ll_ef_)
    l11l1l_ef_(l11l1l1_ef_ (u"ࠫࡋ࡯࡬࡮ࡻࠣࡌࡉ࠭ࡷ"),mode=l11l1l1_ef_ (u"ࠬ࡬ࡩ࡭࡯ࡼࠫࡸ"),l1l11ll_ef_=l11l1l1_ef_ (u"࠭࠳࠶ࠩࡹ"),l11l11_ef_=l1ll_ef_)
    l11l1l_ef_(l11l1l1_ef_ (u"ࠧࡇ࡫࡯ࡱࡾࠦ࠳ࡅࠩࡺ"),mode=l11l1l1_ef_ (u"ࠨࡨ࡬ࡰࡲࡿࠧࡻ"),l1l11ll_ef_=l11l1l1_ef_ (u"ࠩ࠶࠺ࠬࡼ"),l11l11_ef_=l1ll_ef_)
    l11l1l_ef_(l11l1l1_ef_ (u"ࠪࡊ࡮ࡲ࡭ࡺࠢࡇࡰࡦࠦࡄࡻ࡫ࡨࡧ࡮ࠦࡈࡅࠩࡽ"),mode=l11l1l1_ef_ (u"ࠫ࡫࡯࡬࡮ࡻࠪࡾ"),l1l11ll_ef_=l11l1l1_ef_ (u"ࠬ࠸ࠬ࠴࠮࠸࠰࠻࠭ࡿ"),l11l11_ef_=l1ll_ef_)
    l11l1l_ef_(l11l1l1_ef_ (u"࠭ࡆࡪ࡮ࡰࡽࠥࡡࡋࡢࡶࡨ࡫ࡴࡸࡩࡢ࡟ࠪࢀ"),mode=l11l1l1_ef_ (u"ࠧࡧ࡫࡯ࡱࡾࡥ࡫ࡢࡶࡨ࡫ࡴࡸࡩࡢࠩࢁ"),l1l11ll_ef_=l11l1l1_ef_ (u"ࠨࠩࢂ"),l11l11_ef_=l1ll_ef_)
    l11l1l_ef_(l11l1l1_ef_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࡔࡧࡵ࡭ࡦࡲࡥࠡࡍࡤࡸࡦࡲ࡯ࡨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢃ"),mode=l11l1l1_ef_ (u"ࠪࡷࡪࡸࡩࡢ࡮ࡨࡣࡰࡺࡡ࡭ࡱࡪࠫࢄ"))
    l11l1l_ef_(l11l1l1_ef_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤ࡬ࡸࡥࡦࡰࡠࡗࡿࡻ࡫ࡢ࡬࡞࠳ࡈࡕࡌࡐࡔࡠࠫࢅ"),mode=l11l1l1_ef_ (u"ࠬࡹࡺࡶ࡭ࡤ࡮ࠬࢆ"))
    url = l1l1_ef_({l11l1l1_ef_ (u"࠭࡭ࡰࡦࡨࠫࢇ"): l11l1l1_ef_ (u"ࠧࡐࡲࡦ࡮ࡪ࠭࢈")})
    l11ll1_ef_ = xbmcgui.ListItem(label = l11l1l1_ef_ (u"ࠨ࠯ࡀࡓࡵࡩࡪࡦ࠿࠰ࠫࢉ"), iconImage=l11l1l1_ef_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࡖࡧࡷ࡯ࡰࡵ࠰ࡳࡲ࡬࠭ࢊ"))
    xbmcplugin.addDirectoryItem(handle=l1lll11_ef_, url=url,listitem=l11ll1_ef_)
elif mode[0].startswith(l11l1l1_ef_ (u"ࠪࡣ࡮ࡴࡦࡰࡡࠪࢋ")):l111l_ef_.__myinfo__.go(sys.argv)
elif mode[0] == l11l1l1_ef_ (u"ࠫࡤࡥࡰࡢࡩࡨࡣࡤ࠭ࢌ"):
    url = l1l1_ef_({l11l1l1_ef_ (u"ࠬࡳ࡯ࡥࡧࠪࢍ"): l11l1l1_ef_ (u"࠭ࡦࡪ࡮ࡰࡽࠬࢎ"), l11l1l1_ef_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫ࢏"): l11l1l1_ef_ (u"ࠨࠩ࢐"), l11l1l1_ef_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪ࢑") : ex_link,l11l1l1_ef_ (u"ࠪ࡯ࡦࡺࠧ࢒") : l1l11ll_ef_,l11l1l1_ef_ (u"ࠫࡼ࡫ࡲࠨ࢓") : l11l11_ef_,l11l1l1_ef_ (u"ࠬࡶࡡࡨࡧࠪ࢔") : l1111ll_ef_})
    xbmc.executebuiltin(l11l1l1_ef_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠩࠧࡶ࠭ࠬ࢕")% url)
elif mode[0] == l11l1l1_ef_ (u"ࠧࡵࡧࡶࡸࡕࡲࡡࡺࠩ࢖"):
    l1l1l1l_ef_(ex_link)
elif mode[0] == l11l1l1_ef_ (u"ࠨࡅ࡫ࡳࡴࡹࡥࡂࡰࡧࡔࡱࡧࡹࠨࢗ"):
    l1l111l_ef_(ex_link)
elif mode[0] == l11l1l1_ef_ (u"ࠩࡒࡴࡨࡰࡥࠨ࢘"):
    l1l1ll_ef_.openSettings()
    url = l1l1_ef_({l11l1l1_ef_ (u"ࠪࡱࡴࡪࡥࠨ࢙"): l11l1l1_ef_ (u"࢚ࠫࠬ"), l11l1l1_ef_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࡳࡧ࡭ࡦ࢛ࠩ"): l11l1l1_ef_ (u"࠭ࠧ࢜"), l11l1l1_ef_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨ࢝") : l11l1l1_ef_ (u"ࠨࠩ࢞"), l11l1l1_ef_ (u"ࠩࡳࡥ࡬࡫ࠧ࢟"): 1})
    xbmc.executebuiltin(l11l1l1_ef_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲ࡗ࡫ࡦࡳࡧࡶ࡬࠭ࠫࡳࠪࠩࢠ")% url)
elif mode[0]==l11l1l1_ef_ (u"ࠫ࡫࡯࡬࡮ࡻࠪࢡ"):
    l1l11l_ef_(l1l11ll_ef_,l11l11_ef_,l1111ll_ef_,ex_link)
elif mode[0]==l11l1l1_ef_ (u"ࠬ࡬ࡩ࡭࡯ࡼࡣࡰࡧࡴࡦࡩࡲࡶ࡮ࡧࠧࢢ"):
    data = l1lll1_ef_.l1l1ll1_ef_()
    l1l1l_ef_ = xbmcgui.Dialog().select(l11l1l1_ef_ (u"࠭ࡗࡺࡤ࡬ࡩࡷࢀ࠺ࠨࢣ"), data[0])
    if l1l1l_ef_>-1:
        l1l11l_ef_(data[1][l1l1l_ef_],l11l11_ef_,l1111ll_ef_,ex_link)
elif mode[0]==l11l1l1_ef_ (u"ࠧࡴࡼࡸ࡯ࡦࡰࠧࢤ"):
    l111lll_ef_ = xbmcgui.Dialog()
    d = l111lll_ef_.input(l11l1l1_ef_ (u"ࠨࡕࡽࡹࡰࡧࡪ࠭ࠢࡓࡳࡩࡧࡪࠡࡶࡼࡸࡺैࠠࡧ࡫࡯ࡱࡺ࠭ࢥ"), type=xbmcgui.INPUT_ALPHANUM)
    l11111l_ef_ = l1lll1_ef_.l1111l_ef_(d.replace(l11l1l1_ef_ (u"ࠩࠣࠫࢦ"),l11l1l1_ef_ (u"ࠪࠩ࠷࠶ࠧࢧ")))
    for p in l11111l_ef_:
        l11ll11_ef_(p[l11l1l1_ef_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪࢨ")],p[l11l1l1_ef_ (u"ࠬ࡮ࡲࡦࡨࠪࢩ")],l11l1l1_ef_ (u"࠭ࡃࡩࡱࡲࡷࡪࡇ࡮ࡥࡒ࡯ࡥࡾ࠭ࢪ"),p[l11l1l1_ef_ (u"ࠧࡪ࡯ࡪࠫࢫ")],p)
elif mode[0]==l11l1l1_ef_ (u"ࠨࡵࡨࡶ࡮ࡧ࡬ࡦࡡ࡮ࡸࡦࡲ࡯ࡨࠩࢬ"):
    l11111l_ef_ = l1lll1_ef_.l11l_ef_()
    for p in l11111l_ef_:
        l11l1l_ef_(p.get(l11l1l1_ef_ (u"ࠩࡷ࡭ࡹࡲࡥࠨࢭ")),ex_link=p.get(l11l1l1_ef_ (u"ࠪ࡬ࡷ࡫ࡦࠨࢮ")),mode=l11l1l1_ef_ (u"ࠫࡸ࡫ࡲࡪࡣ࡯ࡩࠬࢯ"))
elif mode[0]==l11l1l1_ef_ (u"ࠬࡹࡥࡳ࡫ࡤࡰࡪ࠭ࢰ"):
    l11111l_ef_ = l1lll1_ef_.l1llll_ef_(ex_link)
    for p in l11111l_ef_:
        l11l1l_ef_(p.get(l11l1l1_ef_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࢱ")),ex_link=p.get(l11l1l1_ef_ (u"ࠧࡩࡴࡨࡪࠬࢲ")),mode=l11l1l1_ef_ (u"ࠨࡧࡳ࡭ࡿࡵࡤࡺࠩࢳ"),infoLabels=p,iconImage=p.get(l11l1l1_ef_ (u"ࠩ࡬ࡱ࡬࠭ࢴ")))
elif mode[0]==l11l1l1_ef_ (u"ࠪࡩࡵ࡯ࡺࡰࡦࡼࠫࢵ"):
    l11111l_ef_ = l1lll1_ef_.l1lll1l_ef_(ex_link)
    for p in l11111l_ef_:
        l11ll11_ef_(p[l11l1l1_ef_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪࢶ")],p[l11l1l1_ef_ (u"ࠬ࡮ࡲࡦࡨࠪࢷ")],l11l1l1_ef_ (u"࠭ࡃࡩࡱࡲࡷࡪࡇ࡮ࡥࡒ࡯ࡥࡾ࠭ࢸ"),p.get(l11l1l1_ef_ (u"ࠧࡪ࡯ࡪࠫࢹ")),p)
xbmcplugin.endOfDirectory(l1lll11_ef_)
