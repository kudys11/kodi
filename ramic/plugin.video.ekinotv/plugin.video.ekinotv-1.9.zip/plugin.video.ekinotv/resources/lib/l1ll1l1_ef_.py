# coding: UTF-8
import sys
l11111_ef_ = sys.version_info [0] == 2
l1l11l1_ef_ = 2048
l1lllll_ef_ = 7
def l11l1l1_ef_ (ll_ef_):
	global l11lll1_ef_
	l11l1ll_ef_ = ord (ll_ef_ [-1])
	l111l1_ef_ = ll_ef_ [:-1]
	l111_ef_ = l11l1ll_ef_ % len (l111l1_ef_)
	l1lll_ef_ = l111l1_ef_ [:l111_ef_] + l111l1_ef_ [l111_ef_:]
	if l11111_ef_:
		l1ll111_ef_ = unicode () .join ([unichr (ord (char) - l1l11l1_ef_ - (l1ll1l_ef_ + l11l1ll_ef_) % l1lllll_ef_) for l1ll1l_ef_, char in enumerate (l1lll_ef_)])
	else:
		l1ll111_ef_ = str () .join ([chr (ord (char) - l1l11l1_ef_ - (l1ll1l_ef_ + l11l1ll_ef_) % l1lllll_ef_) for l1ll1l_ef_, char in enumerate (l1lll_ef_)])
	return eval (l1ll111_ef_)
import threading
import xbmc,xbmcgui
import time,re,os
try: from shutil import rmtree
except: rmtree = False
def l11ll1l11_ef_(l11l1lll1_ef_,l11l1ll1l_ef_=[l11l1l1_ef_ (u"࠭ࠧদ")]):
    debug=1
def l11ll1l1l_ef_(name=l11l1l1_ef_ (u"ࠧࠨধ")):
    debug=1
def l11ll11l1_ef_(top):
    debug=1
def check():
    debug=1
try:
    debug=1
except: pass
