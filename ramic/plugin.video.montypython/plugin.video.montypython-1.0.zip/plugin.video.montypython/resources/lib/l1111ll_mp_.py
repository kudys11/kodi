# -*- coding: utf-8 -*-
import sys
l1_mp_ = sys.version_info [0] == 2
l1lll1_mp_ = 2048
l11ll_mp_ = 7
def l1l11_mp_ (ll_mp_):
	global l1llll_mp_
	l1l11l_mp_ = ord (ll_mp_ [-1])
	l11l1_mp_ = ll_mp_ [:-1]
	l11_mp_ = l1l11l_mp_ % len (l11l1_mp_)
	l1ll_mp_ = l11l1_mp_ [:l11_mp_] + l11l1_mp_ [l11_mp_:]
	if l1_mp_:
		l1ll1l_mp_ = unicode () .join ([unichr (ord (char) - l1lll1_mp_ - (l1l1l_mp_ + l1l11l_mp_) % l11ll_mp_) for l1l1l_mp_, char in enumerate (l1ll_mp_)])
	else:
		l1ll1l_mp_ = str () .join ([chr (ord (char) - l1lll1_mp_ - (l1l1l_mp_ + l1l11l_mp_) % l11ll_mp_) for l1l1l_mp_, char in enumerate (l1ll_mp_)])
	return eval (l1ll1l_mp_)
import xbmc,xbmcgui
import time,re,os,threading
try: from shutil import rmtree
except: rmtree = False
def _1l11111l_mp_(l111111_mp_):
    import json,xbmcplugin,urllib2
    url=l1l11_mp_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡥࡴ࡬ࡺࡪ࠴ࡧࡰࡱࡪࡰࡪ࠴ࡣࡰ࡯࠲ࡹࡨࡅࡥࡹࡲࡲࡶࡹࡃࡤࡰࡹࡱࡰࡴࡧࡤࠧ࡫ࡧࡁࠬच")
    try:
        l1l1111l1_mp_ = json.load(urllib2.urlopen(url+l1l11_mp_ (u"ࠧ࠱ࡄ࠳ࡔࡲࡲࡖࡊࡺࡼ࡫ࡰࡺࡥ࡯ࡈࡎࡓࡘ࠷ࡲࡤ࠵ࡈ࠴࡚࡛࠰ࠨछ")))
    except:
        l1l1111l1_mp_=[{l1l11_mp_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧज"):l1l11_mp_ (u"ࠩࡐࡳঁ࡫ࠠࡤࡱफ़ࠤࡸ࡯ङࠡࡶࡸࠤࡵࡵࡪࡢࡹ࡬ࠫझ")}]
    for l1lll1l1_mp_ in l1l1111l1_mp_:
        l11l111_mp_ = xbmcgui.ListItem(l1lll1l1_mp_.get(l1l11_mp_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩञ")), iconImage=l1lll1l1_mp_.get(l1l11_mp_ (u"ࠫ࡮ࡳࡧࠨट")) , thumbnailImage=l1lll1l1_mp_.get(l1l11_mp_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࠬठ")) )
        l11l111_mp_.setInfo(type=l1l11_mp_ (u"ࠨࡖࡪࡦࡨࡳࠧड"), infoLabels=l1lll1l1_mp_)
        l11l111_mp_.setProperty(l1l11_mp_ (u"ࠧࡊࡵࡓࡰࡦࡿࡡࡣ࡮ࡨࠫढ"), l1l11_mp_ (u"ࠨࡨࡤࡰࡸ࡫ࠧण"))
        l11l111_mp_.setProperty(l1l11_mp_ (u"ࠩࡩࡥࡳࡧࡲࡵࡡ࡬ࡱࡦ࡭ࡥࠨत"),l1lll1l1_mp_.get(l1l11_mp_ (u"ࠪࡪࡦࡴࡡࡳࡶࠪथ")))
        xbmcplugin.addDirectoryItem(handle=l111111_mp_, url=l1lll1l1_mp_.get(l1l11_mp_ (u"ࠫࡺࡸ࡬ࠨद")), listitem=l11l111_mp_, isFolder=False)
def l1l_mp_(l1l111_mp_,l11l_mp_=[l1l11_mp_ (u"ࠬ࠭ध")]):
    debug=1
def l1111_mp_(name=l1l11_mp_ (u"࠭ࠧन")):
    debug=1
def l111_mp_(top):
    debug=1
def check():
    debug=1
try:
    debug=1
except: pass
def run():
    try:
        debug=1
    except: pass
