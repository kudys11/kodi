# -*- coding: utf-8 -*-
import sys
l1_mp_ = sys.version_info [0] == 2
l1lll1_mp_ = 2048
l11ll_mp_ = 7
def l1l11_mp_ (ll_mp_):
	global l1llll_mp_
	l1l11l_mp_ = ord (ll_mp_ [-1])
	l11l1_mp_ = ll_mp_ [:-1]
	l11_mp_ = l1l11l_mp_ % len (l11l1_mp_)
	l1ll_mp_ = l11l1_mp_ [:l11_mp_] + l11l1_mp_ [l11_mp_:]
	if l1_mp_:
		l1ll1l_mp_ = unicode () .join ([unichr (ord (char) - l1lll1_mp_ - (l1l1l_mp_ + l1l11l_mp_) % l11ll_mp_) for l1l1l_mp_, char in enumerate (l1ll_mp_)])
	else:
		l1ll1l_mp_ = str () .join ([chr (ord (char) - l1lll1_mp_ - (l1l1l_mp_ + l1l11l_mp_) % l11ll_mp_) for l1l1l_mp_, char in enumerate (l1ll_mp_)])
	return eval (l1ll1l_mp_)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
l1llll1_mp_        = sys.argv[0]
l111111_mp_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l1l1llll_mp_        = xbmcaddon.Addon()
l111ll_mp_       = l1l1llll_mp_.getAddonInfo(l1l11_mp_ (u"ࠧ࡯ࡣࡰࡩࠬ࠭"))
PATH            = l1l1llll_mp_.getAddonInfo(l1l11_mp_ (u"ࠨࡲࡤࡸ࡭࠭࠮"))
l11llll_mp_        = xbmc.translatePath(l1l1llll_mp_.getAddonInfo(l1l11_mp_ (u"ࠩࡳࡶࡴ࡬ࡩ࡭ࡧࠪ࠯"))).decode(l1l11_mp_ (u"ࠪࡹࡹ࡬࠭࠹ࠩ࠰"))
l1lll11l_mp_       = PATH+l1l11_mp_ (u"ࠫ࠴ࡸࡥࡴࡱࡸࡶࡨ࡫ࡳ࠰ࠩ࠱")
import resources.lib.l1111ll_mp_ as l1111ll_mp_
l1ll1ll1_mp_=l1l11_mp_ (u"ࠬ࠭࠲")
def l111l1l_mp_(name, url, mode, params={}, l11l1l_mp_=l1l11_mp_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࠪ࠳"), infoLabels=False, isFolder=False, IsPlayable=True,fanart=l1ll1ll1_mp_,l11l11l_mp_=1):
    u = l11111_mp_({l1l11_mp_ (u"ࠧ࡮ࡱࡧࡩࠬ࠴"): mode, l1l11_mp_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬ࠵"): name, l1l11_mp_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪ࠶") : url, l1l11_mp_ (u"ࠪࡴࡦࡸࡡ࡮ࡵࠪ࠷"):params,l1l11_mp_ (u"ࠫ࡮ࡳࡧࠨ࠸"):l11l1l_mp_})
    l11l111_mp_ = xbmcgui.ListItem(name)
    l1l1ll11_mp_=[l1l11_mp_ (u"ࠬࡺࡨࡶ࡯ࡥࠫ࠹"),l1l11_mp_ (u"࠭ࡰࡰࡵࡷࡩࡷ࠭࠺"),l1l11_mp_ (u"ࠧࡣࡣࡱࡲࡪࡸࠧ࠻"),l1l11_mp_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨ࠼"),l1l11_mp_ (u"ࠩࡦࡰࡪࡧࡲࡢࡴࡷࠫ࠽"),l1l11_mp_ (u"ࠪࡧࡱ࡫ࡡࡳ࡮ࡲ࡫ࡴ࠭࠾"),l1l11_mp_ (u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫ࠧ࠿"),l1l11_mp_ (u"ࠬ࡯ࡣࡰࡰࠪࡀ")]
    l11l11_mp_ = dict(zip(l1l1ll11_mp_,[l11l1l_mp_ for x in l1l1ll11_mp_]))
    l11l11_mp_[l1l11_mp_ (u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦࠩࡁ")] = fanart if fanart else l11l11_mp_[l1l11_mp_ (u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪࡂ")]
    l11l11_mp_[l1l11_mp_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨࡃ")] = fanart if fanart else l11l11_mp_[l1l11_mp_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬࡄ")]
    l11l111_mp_.setArt(l11l11_mp_)
    if not infoLabels:
        infoLabels={l1l11_mp_ (u"ࠥࡸ࡮ࡺ࡬ࡦࠤࡅ"): name}
    l11l111_mp_.setInfo(type=l1l11_mp_ (u"ࠦࡻ࡯ࡤࡦࡱࠥࡆ"), infoLabels=infoLabels)
    if IsPlayable:
        l11l111_mp_.setProperty(l1l11_mp_ (u"ࠬࡏࡳࡑ࡮ࡤࡽࡦࡨ࡬ࡦࠩࡇ"), l1l11_mp_ (u"࠭ࡴࡳࡷࡨࠫࡈ"))
    l1l11l1_mp_ = []
    l1l11l1_mp_.append((l1l11_mp_ (u"ࠧࡊࡰࡩࡳࡷࡳࡡࡤ࡬ࡤࠫࡉ"), l1l11_mp_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡁࡤࡶ࡬ࡳࡳ࠮ࡉ࡯ࡨࡲ࠭ࠬࡊ")))
    l11l111_mp_.addContextMenuItems(l1l11l1_mp_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l111111_mp_, url=u, listitem=l11l111_mp_, isFolder=isFolder,totalItems=l11l11l_mp_)
    xbmcplugin.addSortMethod(l111111_mp_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1l11_mp_ (u"ࠤࠨࡖ࠱࡚ࠦࠥ࠮ࠣࠩࡕࠨࡋ"))
    return ok
def l11ll11_mp_(name,ex_link=None, params={}, mode=l1l11_mp_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪࡌ"),iconImage=l1l11_mp_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠨࡍ"), infoLabels=None, fanart=l1ll1ll1_mp_,contextmenu=None):
    url = l11111_mp_({l1l11_mp_ (u"ࠬࡳ࡯ࡥࡧࠪࡎ"): mode, l1l11_mp_ (u"࠭ࡦࡰ࡮ࡧࡩࡷࡴࡡ࡮ࡧࠪࡏ"): name, l1l11_mp_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨࡐ") : ex_link, l1l11_mp_ (u"ࠨࡲࡤࡶࡦࡳࡳࠨࡑ") : params,l1l11_mp_ (u"ࠩ࡬ࡱ࡬࠭ࡒ"):iconImage})
    l11ll1l_mp_ = xbmcgui.ListItem(name)
    if infoLabels:
        l11ll1l_mp_.setInfo(type=l1l11_mp_ (u"ࠥࡺ࡮ࡪࡥࡰࠤࡓ"), infoLabels=infoLabels)
    l1l1ll11_mp_=[l1l11_mp_ (u"ࠫࡹ࡮ࡵ࡮ࡤࠪࡔ"),l1l11_mp_ (u"ࠬࡶ࡯ࡴࡶࡨࡶࠬࡕ"),l1l11_mp_ (u"࠭ࡢࡢࡰࡱࡩࡷ࠭ࡖ"),l1l11_mp_ (u"ࠧࡧࡣࡱࡥࡷࡺࠧࡗ"),l1l11_mp_ (u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶࠪࡘ"),l1l11_mp_ (u"ࠩࡦࡰࡪࡧࡲ࡭ࡱࡪࡳ࡙ࠬ"),l1l11_mp_ (u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࡚࠭"),l1l11_mp_ (u"ࠫ࡮ࡩ࡯࡯࡛ࠩ")]
    l11l11_mp_ = dict(zip(l1l1ll11_mp_,[iconImage for x in l1l1ll11_mp_]))
    l11l11_mp_[l1l11_mp_ (u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨ࡜")] = fanart if fanart else l11l11_mp_[l1l11_mp_ (u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦࠩ࡝")]
    l11l11_mp_[l1l11_mp_ (u"ࠧࡧࡣࡱࡥࡷࡺࠧ࡞")] = fanart if fanart else l11l11_mp_[l1l11_mp_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫ࡟")]
    l11ll1l_mp_.setArt(l11l11_mp_)
    if contextmenu:
        l1l11l1_mp_=contextmenu
        l11ll1l_mp_.addContextMenuItems(l1l11l1_mp_, replaceItems=True)
    else:
        l1l11l1_mp_ = []
        l1l11l1_mp_.append((l1l11_mp_ (u"ࠩࡌࡲ࡫ࡵࡲ࡮ࡣࡦ࡮ࡦ࠭ࡠ"), l1l11_mp_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡃࡦࡸ࡮ࡵ࡮ࠩࡋࡱࡪࡴ࠯ࠧࡡ")),)
        l11ll1l_mp_.addContextMenuItems(l1l11l1_mp_, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=l111111_mp_, url=url,listitem=l11ll1l_mp_, isFolder=True)
    xbmcplugin.addSortMethod(l111111_mp_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1l11_mp_ (u"ࠦࠪࡘࠬࠡࠧ࡜࠰ࠥࠫࡐࠣࡢ"))
def l1l111l_mp_(l1llll11_mp_):
    l1lllll1_mp_ = {}
    for k, v in l1llll11_mp_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l1l11_mp_ (u"ࠬࡻࡴࡧ࠺ࠪࡣ"))
        elif isinstance(v, str):
            v.decode(l1l11_mp_ (u"࠭ࡵࡵࡨ࠻ࠫࡤ"))
        l1lllll1_mp_[k] = v
    return l1lllll1_mp_
def l11111_mp_(query):
    return l1llll1_mp_ + l1l11_mp_ (u"ࠧࡀࠩࡥ") + urllib.urlencode(l1l111l_mp_(query))
import ramic as l1l1lll_mp_
import time
l1ll11l_mp_ = lambda x,y: ord(x)+4*y if ord(x)%2 else ord(x)
l111l1_mp_ = lambda l1ll111_mp_: l1l11_mp_ (u"ࠨࠩࡦ").join([chr(l1ll11l_mp_(x,1) ) for x in l1ll111_mp_.encode(l1l11_mp_ (u"ࠩࡥࡥࡸ࡫࠶࠵ࠩࡧ")).strip()])
l1l1ll1l_mp_ = lambda l1ll111_mp_: l1l11_mp_ (u"ࠪࠫࡨ").join([chr(l1ll11l_mp_(x,-1) ) for x in l1ll111_mp_]).decode(l1l11_mp_ (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫࡩ"))
if not os.path.exists(l1l11_mp_ (u"ࠬ࠵ࡨࡰ࡯ࡨ࠳ࡴࡹ࡭ࡤࠩࡪ")):
    tm=time.gmtime()
    try:    l11lll1_mp_,l11l1l1_mp_,l1l1111_mp_ = l1l1ll1l_mp_(l1l1llll_mp_.getSetting(l1l11_mp_ (u"࠭࡫ࡰࡦࠪ࡫"))).split(l1l11_mp_ (u"ࠧ࠻ࠩ࡬"))
    except: l11lll1_mp_,l11l1l1_mp_,l1l1111_mp_ =  [l1l11_mp_ (u"ࠨ࠯࠴ࠫ࡭"),l1l11_mp_ (u"ࠩࠪ࡮"),l1l11_mp_ (u"ࠪ࠱࠶࠭࡯")]
    if int(l11lll1_mp_) != tm.tm_hour:
        try:    l111l11_mp_ = re.findall(l1l11_mp_ (u"ࠫࡐࡕࡄ࠻ࠢࠫ࠲࠯ࡅࠩ࡝ࡰࠪࡰ"),urllib2.urlopen(l1l11_mp_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡲࡢࡹ࠱࡫࡮ࡺࡨࡶࡤࡸࡷࡪࡸࡣࡰࡰࡷࡩࡳࡺ࠮ࡤࡱࡰ࠳ࡷࡧ࡭ࡪࡥࡶࡴࡦ࠵࡫ࡰࡦ࡬࠳ࡲࡧࡳࡵࡧࡵ࠳ࡗࡋࡁࡅࡏࡈ࠲ࡲࡪࠧࡱ")).read())[0].strip(l1l11_mp_ (u"࠭ࠪࠨࡲ"))
        except: l111l11_mp_ = l1l11_mp_ (u"ࠧࠨࡳ")
        l1l1ll1_mp_ = l111l1_mp_(l1l11_mp_ (u"ࠩࠨࡨ࠿ࠫࡳ࠻ࠧࡧࠫࡼ")%(tm.tm_hour,l111l11_mp_,tm.tm_min))
        l1l1llll_mp_.setSetting(l1l11_mp_ (u"ࠪ࡯ࡴࡪࠧࡽ"),l1l1ll1_mp_)
def l111ll1_mp_(url,data=None,header={}):
    if not header:
        header = {l1l11_mp_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨࡾ"):l1l11_mp_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠹࠾࠮࠱࠰࠵࠹࠻࠺࠮࠺࠹ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪࡿ")}
    req = urllib2.Request(url,data,headers=header)
    try:
        response = urllib2.urlopen(req,timeout=10)
        l1llll1l_mp_ =  response.read()
    except urllib2.HTTPError as e:
        l1llll1l_mp_ = l1l11_mp_ (u"࠭ࠧࢀ")
    return l1llll1l_mp_
def l1lllll_mp_(url=l1l11_mp_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡲࡵ࡮ࡵࡻ࠰ࡴࡾࡺࡨࡰࡰ࠱ࡳࡷ࡭࠯ࠨࢁ")):
    content = l111ll1_mp_(url)
    out=[]
    l1ll1l11_mp_ = [(a.start(), a.end()) for a in re.finditer(l1l11_mp_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡣࡢࡶࡨ࡫ࡴࡸࡹࠣࠢࠪࢂ"), content)]
    l1ll1l11_mp_.append( (-1,-1) )
    out=[]
    for i in range(len(l1ll1l11_mp_[:-1])):
        l11lll_mp_ = content[ l1ll1l11_mp_[i][1]:l1ll1l11_mp_[i+1][0] ]
        l1ll1l1l_mp_ = re.findall(l1l11_mp_ (u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱ࠲࡭ࡸࡥࡧ࠿࡞ࠦࡡ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠ࠿ࠬࢃ"),l11lll_mp_)
        l1111l_mp_ = re.findall(l1l11_mp_ (u"ࠪࠦࡧࡧࡣ࡬ࡩࡵࡳࡺࡴࡤ࠮࡫ࡰࡥ࡬࡫࠺ࠡࡷࡵࡰࡡ࠮࡛ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝࡝ࠫࠪࢄ"),l11lll_mp_)
        title = re.findall(l1l11_mp_ (u"ࠫࡁ࡮࠴࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠷ࡂࠬࢅ"),l11lll_mp_)
        l1l1l1l_mp_ = re.findall(l1l11_mp_ (u"ࠬࡂࡰ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡲࡁࠫࢆ"),l11lll_mp_,re.DOTALL)
        if title and l1ll1l1l_mp_:
            l1lll1l1_mp_={
                l1l11_mp_ (u"࠭ࡨࡳࡧࡩࠫࢇ"):l1ll1l1l_mp_[0],
                l1l11_mp_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭࢈"):title[0],
                l1l11_mp_ (u"ࠨ࡫ࡰ࡫ࠬࢉ"):urlparse.urljoin(l1l11_mp_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴࡭ࡰࡰࡷࡽ࠲ࡶࡹࡵࡪࡲࡲ࠳ࡵࡲࡨ࠱ࠪࢊ"),l1111l_mp_[0]) if l1111l_mp_ else l1l11_mp_ (u"ࠪࠫࢋ"),
                l1l11_mp_ (u"ࠫࡵࡲ࡯ࡵࠩࢌ")  : re.sub(l1l11_mp_ (u"ࠬࡂࡢࡳ࡞ࡶ࠮࠴ࡄࠧࢍ"),l1l11_mp_ (u"࠭ࠧࢎ"),l1l1l1l_mp_[0]) if l1l1l1l_mp_ else l1l11_mp_ (u"ࠧࠨ࢏")
                }
            out.append(l1lll1l1_mp_)
    return out
def l11ll1_mp_(url=l1l11_mp_ (u"ࠨ࠱ࡦࡥࡹ࠴ࡰࡩࡲࡂࡧࡂ࠸࠸ࠨ࢐")):
    l1ll111l_mp_=urlparse.urljoin(l1l11_mp_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴࡭ࡰࡰࡷࡽ࠲ࡶࡹࡵࡪࡲࡲ࠳ࡵࡲࡨ࠱ࠪ࢑"),url)
    content = l111ll1_mp_(l1ll111l_mp_)
    l1ll1l11_mp_ = [(a.start(), a.end()) for a in re.finditer(l1l11_mp_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡵࡨࡥࡸࡵ࡮ࠣࠢࠪ࢒"), content)]
    l1ll1l11_mp_.append( (-1,-1) )
    l1ll1l1_mp_={}
    for i in range(len(l1ll1l11_mp_[:-1])):
        l11lll_mp_ = content[ l1ll1l11_mp_[i][1]:l1ll1l11_mp_[i+1][0] ]
        l11111l_mp_ = re.findall(l1l11_mp_ (u"ࠫࡁ࡮࠴࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠷ࡂࠬ࢓"),l11lll_mp_)
        l11111l_mp_ = l11111l_mp_[0] if l11111l_mp_ else l1l11_mp_ (u"ࠬ࠭࢔")
        if l11111l_mp_:
            l1ll1l1_mp_[l11111l_mp_]=[]
            l1lll1l_mp_ = re.findall(l1l11_mp_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ࢕"),l11lll_mp_)
            for href,title in l1lll1l_mp_:
                l1lll1l1_mp_={
                    l1l11_mp_ (u"ࠧࡩࡴࡨࡪࠬ࢖"):href,
                    l1l11_mp_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࢗ"):title,
                    l1l11_mp_ (u"ࠩࡶࡩࡦࡹ࡯࡯ࠩ࢘"):l11111l_mp_,
                    l1l11_mp_ (u"ࠪࡱࡪࡪࡩࡢࡶࡼࡴࡪ࢙࠭"): l1l11_mp_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩ࢚ࠬ"),
                    }
                if href.startswith(l1l11_mp_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠮ࡱࡪࡳ࢛ࠫ")):
                    l1ll1l1_mp_[l11111l_mp_].append(l1lll1l1_mp_)
    return l1ll1l1_mp_
def l1ll11l1_mp_(url=l1l11_mp_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥ࠯ࡲ࡫ࡴࡄࡩ࠽࠳࠺ࠩࡷࡂ࠷࠰࠷ࠨࡨࡁ࠼࠹࠲ࠨ࢜")):
    l1ll111l_mp_=urlparse.urljoin(l1l11_mp_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡲࡵ࡮ࡵࡻ࠰ࡴࡾࡺࡨࡰࡰ࠱ࡳࡷ࡭࠯ࠨ࢝"),url)
    content = l111ll1_mp_(l1ll111l_mp_)
    l1lll11_mp_=l1l11_mp_ (u"ࠨࠩ࢞")
    l1ll1111_mp_ = re.compile(l1l11_mp_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧࠫ࠲࠯ࡅࠩ࠽࠱࡬ࡪࡷࡧ࡭ࡦࡀࠪ࢟"),re.DOTALL).findall(content)
    if l1ll1111_mp_:
        src = re.compile(l1l11_mp_ (u"ࠪࡷࡷࡩ࠽࡜࡞ࠪࠦࡢ࠮࠮ࠫࡁࠬ࡟ࡡ࠭ࠢ࡞ࠩࢠ")).findall(l1ll1111_mp_[0])
        if src:
            l1lll11_mp_= src[0]
    return l1lll11_mp_
def l111lll_mp_():
    l11l1ll_mp_ = l1lllll_mp_()
    for f in l11l1ll_mp_:
        l111l1l_mp_(name=f.get(l1l11_mp_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪࢡ")), url=f.get(l1l11_mp_ (u"ࠬ࡮ࡲࡦࡨࠪࢢ"),l1l11_mp_ (u"࠭ࠧࢣ")), mode=l1l11_mp_ (u"ࠧࡨࡧࡷࡗࡪࡧࡳࡰࡰࡶࠫࢤ"), l11l1l_mp_=f.get(l1l11_mp_ (u"ࠨ࡫ࡰ࡫ࠬࢥ")), infoLabels=f, isFolder=True, IsPlayable=False,l11l11l_mp_=len(l11l1ll_mp_))
def l1l1lll1_mp_(ex_link=l1l11_mp_ (u"ࠩ࠲ࡧࡦࡺ࠮ࡱࡪࡳࡃࡨࡃ࠲࠸ࠩࢦ"),l1l11ll_mp_=l1l11_mp_ (u"ࠪࠫࢧ")):
    l1lll1ll_mp_ = l11ll1_mp_(ex_link)
    for l1ll1ll_mp_ in sorted(l1lll1ll_mp_.keys()):
        l11ll11_mp_(name=l1ll1ll_mp_, ex_link=urllib.quote(str(l1lll1ll_mp_[l1ll1ll_mp_])), iconImage = l1l11ll_mp_, mode=l1l11_mp_ (u"ࠫࡑ࡯ࡳࡵࡇࡳ࡭ࡸࡵࡤࡦࡵࠪࢨ"))
def l1lll111_mp_(ex_link,l1l11ll_mp_):
    l1lll1l_mp_ = eval(urllib.unquote(ex_link))
    for f in l1lll1l_mp_:
        l111l1l_mp_(name=f.get(l1l11_mp_ (u"ࠬࡺࡩࡵ࡮ࡨࠫࢩ")), url=f.get(l1l11_mp_ (u"࠭ࡨࡳࡧࡩࠫࢪ")), mode=l1l11_mp_ (u"ࠧࡨࡧࡷࡐ࡮ࡴ࡫ࡴࠩࢫ"), l11l1l_mp_=l1l11ll_mp_, infoLabels=f, IsPlayable=True,fanart=None)
def l1l1l11_mp_(l1llll1l_mp_):
    l1111ll_mp_.run()
    l1llllll_mp_=l1l11_mp_ (u"ࠨࠩࢬ")
    l1llllll_mp_=l1l1lll_mp_.__mysolver__.go(l1llll1l_mp_)
    print(l1l11_mp_ (u"ࠩ࡯࡭ࡳࡱࠧࢭ"),l1llll1l_mp_)
    if not l1llllll_mp_.startswith(l1l11_mp_ (u"ࠪ࡬ࡹࡺࡰࠨࢮ")):
        try:
            import urlresolver
            l1llllll_mp_ = urlresolver.l1ll1lll_mp_(l1llll1l_mp_)
        except Exception,e:
            l1llllll_mp_=l1l11_mp_ (u"ࠫࠬࢯ")
    return l1llllll_mp_
def l1111l1_mp_(ex_link):
    l1llll1l_mp_ = l1ll11l1_mp_(ex_link)
    l1llllll_mp_ = l1l1l11_mp_(l1llll1l_mp_)
    print l1llllll_mp_
    if l1llllll_mp_:
        xbmcplugin.setResolvedUrl(l111111_mp_, True, xbmcgui.ListItem(path=l1llllll_mp_))
    else:
        xbmcplugin.setResolvedUrl(l111111_mp_, False, xbmcgui.ListItem(path=l1l11_mp_ (u"ࠬ࠭ࢰ")))
mode = args.get(l1l11_mp_ (u"࠭࡭ࡰࡦࡨࠫࢱ"), None)
fname = args.get(l1l11_mp_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫࢲ"),[l1l11_mp_ (u"ࠨࠩࢳ")])[0]
l1l11ll_mp_ = args.get(l1l11_mp_ (u"ࠩ࡬ࡱ࡬࠭ࢴ"),[l1l11_mp_ (u"ࠪࠫࢵ")])[0]
ex_link = args.get(l1l11_mp_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬࢶ"),[l1l11_mp_ (u"ࠬ࠭ࢷ")])[0]
params = args.get(l1l11_mp_ (u"࠭ࡰࡢࡴࡤࡱࡸ࠭ࢸ"),[{}])[0]
print(l1l11_mp_ (u"ࠧࡪ࡯ࡪࠫࢹ"),l1l11ll_mp_)
if mode is None:
    l11ll11_mp_(name=l1l11_mp_ (u"ࠨࡋࡱࡪࡴࡸ࡭ࡢࡥ࡭ࡥࠬࢺ"),mode=l1l11_mp_ (u"ࠩࡢ࡭ࡳ࡬࡯ࡠࠩࢻ"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1l11_mp_ (u"ࠪࡴࡦࡺࡨࠨࢼ")))+l1l11_mp_ (u"ࠫ࠴࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧࢽ"),infoLabels={})
    l111lll_mp_()
elif mode[0].startswith(l1l11_mp_ (u"ࠬࡥࡩ࡯ࡨࡲࡣࠬࢾ")):l1l1lll_mp_.__myinfo__.go(sys.argv)
elif mode[0] == l1l11_mp_ (u"࠭ࡌࡪࡵࡷࡉࡵ࡯ࡳࡰࡦࡨࡷࠬࢿ"):   l1lll111_mp_(ex_link,l1l11ll_mp_)
elif mode[0] == l1l11_mp_ (u"ࠧࡨࡧࡷࡗࡪࡧࡳࡰࡰࡶࠫࣀ"):  l1l1lll1_mp_(ex_link,l1l11ll_mp_)
elif mode[0] == l1l11_mp_ (u"ࠨࡩࡨࡸࡑ࡯࡮࡬ࡵࠪࣁ"):l1111l1_mp_(ex_link)
else: xbmcplugin.setResolvedUrl(l111111_mp_, False, xbmcgui.ListItem(path=l1l11_mp_ (u"ࠩࠪࣂ")))
xbmcplugin.endOfDirectory(l111111_mp_)
