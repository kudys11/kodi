# -*- coding: utf-8 -*-
import sys
l111ll_iptv_ = sys.version_info [0] == 2
l1l11_iptv_ = 2048
l111l1l_iptv_ = 7
def l1l1111_iptv_ (ll_iptv_):
	global l1lllll1_iptv_
	l11111l_iptv_ = ord (ll_iptv_ [-1])
	l1lll11_iptv_ = ll_iptv_ [:-1]
	l111_iptv_ = l11111l_iptv_ % len (l1lll11_iptv_)
	l1lll_iptv_ = l1lll11_iptv_ [:l111_iptv_] + l1lll11_iptv_ [l111_iptv_:]
	if l111ll_iptv_:
		l1l1l11_iptv_ = unicode () .join ([unichr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	else:
		l1l1l11_iptv_ = str () .join ([chr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	return eval (l1l1l11_iptv_)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import json,time
l1l111_iptv_        = sys.argv[0]
l1ll11l_iptv_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l1llll11_iptv_        = xbmcaddon.Addon()
PATH        = l1llll11_iptv_.getAddonInfo(l1l1111_iptv_ (u"ࠫࡵࡧࡴࡩࠩࠀ"))
l1111l_iptv_   = PATH+l1l1111_iptv_ (u"ࠬ࠵ࡲࡦࡵࡲࡹࡷࡩࡥࡴ࠱ࠪࠁ")
sys.path.append( os.path.join( l1111l_iptv_, l1l1111_iptv_ (u"ࠨ࡬ࡪࡤࠥࠂ") ) )
l1ll111_iptv_    = xbmc.translatePath(l1llll11_iptv_.getAddonInfo(l1l1111_iptv_ (u"ࠧࡱࡴࡲࡪ࡮ࡲࡥࠨࠃ"))).decode(l1l1111_iptv_ (u"ࠨࡷࡷࡪ࠲࠾ࠧࠄ"))
if not os.path.exists(l1ll111_iptv_):
    os.makedirs(l1ll111_iptv_)
def l1ll1ll_iptv_(url,data=None):
    req = urllib2.Request(url,data)
    req.add_header(l1l1111_iptv_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ࠅ"), l1l1111_iptv_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠶࠯࠳࠾ࠤࡷࡼ࠺࠳࠴࠱࠴࠮ࠦࡇࡦࡥ࡮ࡳ࠴࠸࠰࠲࠲࠳࠵࠵࠷ࠠࡇ࡫ࡵࡩ࡫ࡵࡸ࠰࠴࠵࠲࠵࠭ࠆ"))
    response = urllib2.urlopen(req)
    l1l111l_iptv_ = response.read()
    response.close()
    return l1l111l_iptv_
def l1111l1_iptv_(name, url, mode, params={}, l1l_iptv_=None, infoLabels={}, IsPlayable=True,fanart=None):
    u = l11ll1l_iptv_({l1l1111_iptv_ (u"ࠫࡲࡵࡤࡦࠩࠇ"): mode, l1l1111_iptv_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࡳࡧ࡭ࡦࠩࠈ"): name, l1l1111_iptv_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧࠉ") : url, l1l1111_iptv_ (u"ࠧࡱࡣࡵࡥࡲࡹࠧࠊ"):params})
    if l1l_iptv_==None:
        l1l_iptv_=l1l1111_iptv_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬࠋ")
    l1lll1l_iptv_ = xbmcgui.ListItem(name, iconImage=l1l_iptv_, thumbnailImage=l1l_iptv_)
    if not infoLabels:
        infoLabels={l1l1111_iptv_ (u"ࠤࡗ࡭ࡹࡲࡥࠣࠌ"): name}
    l1lll1l_iptv_.setInfo(type=l1l1111_iptv_ (u"࡚ࠥ࡮ࡪࡥࡰࠤࠍ"), infoLabels=infoLabels)
    if IsPlayable:
        l1lll1l_iptv_.setProperty(l1l1111_iptv_ (u"ࠫࡎࡹࡐ࡭ࡣࡼࡥࡧࡲࡥࠨࠎ"), l1l1111_iptv_ (u"ࠬࡺࡲࡶࡧࠪࠏ"))
    if fanart:
        l1lll1l_iptv_.setProperty(l1l1111_iptv_ (u"࠭ࡦࡢࡰࡤࡶࡹࡥࡩ࡮ࡣࡪࡩࠬࠐ"),fanart)
    ok = xbmcplugin.addDirectoryItem(handle=l1ll11l_iptv_, url=u, listitem=l1lll1l_iptv_)
    xbmcplugin.addSortMethod(l1ll11l_iptv_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1l1111_iptv_ (u"ࠢࠦࡒࠥࠑ"))
    return ok
def l1l1_iptv_():
    if not os.path.exists(l1l1111_iptv_ (u"ࠨ࠱࡫ࡳࡲ࡫࠯ࡰࡵࡰࡧࠬࠒ")):
        tm=time.gmtime()
        try:    l11lll_iptv_,l11ll11_iptv_,l1l11l_iptv_ = l1lll1l1_iptv_(l1llll11_iptv_.getSetting(l1l1111_iptv_ (u"ࠩ࡮ࡳࡩ࠭ࠓ"))).split(l1l1111_iptv_ (u"ࠪ࠾ࠬࠔ"))
        except: l11lll_iptv_,l11ll11_iptv_,l1l11l_iptv_ =  [l1l1111_iptv_ (u"ࠫ࠲࠷ࠧࠕ"),l1l1111_iptv_ (u"ࠬ࠭ࠖ"),l1l1111_iptv_ (u"࠭࠭࠲ࠩࠗ")]
        if int(l11lll_iptv_) != tm.tm_hour:
            try:    l1llll_iptv_ = re.findall(l1l1111_iptv_ (u"ࠧࡌࡑࡇ࠾ࠥ࠮࠮ࠫࡁࠬࡠࡳ࠭࠘"),urllib2.urlopen(l1l1111_iptv_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡵࡥࡼ࠴ࡧࡪࡶ࡫ࡹࡧࡻࡳࡦࡴࡦࡳࡳࡺࡥ࡯ࡶ࠱ࡧࡴࡳ࠯ࡳࡣࡰ࡭ࡨࡹࡰࡢ࠱࡮ࡳࡩ࡯࠯࡮ࡣࡶࡸࡪࡸ࠯ࡓࡇࡄࡈࡒࡋ࠮࡮ࡦࠪ࠙")).read())[0].strip(l1l1111_iptv_ (u"ࠩ࠭ࠫࠚ"))
            except: l1llll_iptv_ = l1l1111_iptv_ (u"ࠪࠫࠛ")
def l1ll1l1_iptv_(url):
    req = urllib2.Request(url)
    req.add_header(l1l1111_iptv_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫࠦ"), l1l1111_iptv_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠻࠴࠱࠼ࠢࡵࡺ࠿࠸࠲࠯࠲ࠬࠤࡌ࡫ࡣ࡬ࡱ࠲࠶࠵࠷࠰࠱࠳࠳࠵ࠥࡌࡩࡳࡧࡩࡳࡽ࠵࠲࠳࠰࠳ࠫࠧ"))
    try:
        response = urllib2.urlopen(req,timeout=5)
        code = response.code
        response.close()
    except urllib2.HTTPError as e:
        code= e.code
    return code
def l11l1l_iptv_(name,ex_link=None,mode=l1l1111_iptv_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩࠨ"),params={}, iconImage=l1l1111_iptv_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧࠩ"),contextO=[l1l1111_iptv_ (u"ࠫࠬࠪ")],fanart=l1l1111_iptv_ (u"ࠬ࠭ࠫ")):
    url = l11ll1l_iptv_({l1l1111_iptv_ (u"࠭࡭ࡰࡦࡨࠫࠬ"): mode, l1l1111_iptv_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫ࠭"): name, l1l1111_iptv_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩ࠮") : ex_link,l1l1111_iptv_ (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩ࠯"):params})
    l11ll1_iptv_ = xbmcgui.ListItem(name, iconImage=iconImage)
    if fanart:
        l11ll1_iptv_.setProperty(l1l1111_iptv_ (u"ࠪࡪࡦࡴࡡࡳࡶࡢ࡭ࡲࡧࡧࡦࠩ࠰"), fanart )
    l1l1ll_iptv_ = []
    content=urllib.quote_plus(json.dumps({l1l1111_iptv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ࠱"):name,l1l1111_iptv_ (u"ࠬࡻࡲ࡭ࠩ࠲"):ex_link}))
    if l1l1111_iptv_ (u"࠭ࡆࡠࡃࡇࡈࠬ࠳") in contextO:
        l1l1ll_iptv_.append((l1l1111_iptv_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠ࡭࡫ࡪ࡬ࡹࡨ࡬ࡶࡧࡠ࡟ࡇࡣࡓࡢࡸࡨ࡟࠴ࡈ࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ࠴"), l1l1111_iptv_ (u"ࠨࡔࡸࡲࡕࡲࡵࡨ࡫ࡱࠬࠪࡹࠩࠨ࠵")%l11ll1l_iptv_({l1l1111_iptv_ (u"ࠩࡰࡳࡩ࡫ࠧ࠶"): l1l1111_iptv_ (u"ࠪࡊࡤࡇࡄࡅࠩ࠷"), l1l1111_iptv_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨ࠸"): name, l1l1111_iptv_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭࠹") : ex_link})))
        l1l1ll_iptv_.append((l1l1111_iptv_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸࡧࡲࡵࡦ࡟࡞ࡆࡢ࡚ࡥࡴࡶࠣࡐ࡮ࡴ࡫ࡴ࡝࠲ࡆࡢࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࠺"), l1l1111_iptv_ (u"ࠧࡓࡷࡱࡔࡱࡻࡧࡪࡰࠫࠩࡸ࠯ࠧ࠻")%l11ll1l_iptv_({l1l1111_iptv_ (u"ࠨ࡯ࡲࡨࡪ࠭࠼"): mode, l1l1111_iptv_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭࠽"): name, l1l1111_iptv_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫ࠾") : ex_link, l1l1111_iptv_ (u"ࠫࡵࡧࡲࡢ࡯ࡶࠫ࠿"):{l1l1111_iptv_ (u"ࠬࡥࡳࡦࡴࡹ࡭ࡨ࡫ࠧࡀ"): params.get(l1l1111_iptv_ (u"࠭࡟ࡴࡧࡵࡺ࡮ࡩࡥࠨࡁ"),l1l1111_iptv_ (u"ࠧࠨࡂ")),l1l1111_iptv_ (u"ࠨࡡࡤࡧࡹ࠭ࡃ"):l1l1111_iptv_ (u"ࠩࡷࡩࡸࡺࡌࡪࡰ࡮ࡷࠬࡄ")}} )))
    if l1l1111_iptv_ (u"ࠪࡊࡤࡘࡅࡎࠩࡅ") in contextO:
        l1l1ll_iptv_.append((l1l1111_iptv_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡷ࡫ࡤ࡞ࡔࡨࡱࡴࡼࡥ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࡆ"), l1l1111_iptv_ (u"ࠬࡘࡵ࡯ࡒ࡯ࡹ࡬࡯࡮ࠩࠧࡶ࠭ࠬࡇ")%l11ll1l_iptv_({l1l1111_iptv_ (u"࠭࡭ࡰࡦࡨࠫࡈ"): l1l1111_iptv_ (u"ࠧࡇࡡࡕࡉࡒ࠭ࡉ"), l1l1111_iptv_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬࡊ"): name, l1l1111_iptv_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪࡋ") : ex_link})))
    l11ll1_iptv_.addContextMenuItems(l1l1ll_iptv_, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=l1ll11l_iptv_, url=url,listitem=l11ll1_iptv_, isFolder=True)
l1lll1l1_iptv_ = lambda l111l_iptv_: l1l1111_iptv_ (u"ࠪࠫࡌ").join([chr(l1ll1_iptv_(x,-1) ) for x in l111l_iptv_]).decode(l1l1111_iptv_ (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫࡍ"))
def l1l1l1_iptv_(l1llll1l_iptv_):
    l1_iptv_ = {}
    for k, v in l1llll1l_iptv_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l1l1111_iptv_ (u"ࠬࡻࡴࡧ࠺ࠪࡎ"))
        elif isinstance(v, str):
            v.decode(l1l1111_iptv_ (u"࠭ࡵࡵࡨ࠻ࠫࡏ"))
        l1_iptv_[k] = v
    return l1_iptv_
def l11ll1l_iptv_(query):
    return l1l111_iptv_ + l1l1111_iptv_ (u"ࠧࡀࠩࡐ") + urllib.urlencode(l1l1l1_iptv_(query))
l1ll_iptv_ = lambda l111l_iptv_: l1l1111_iptv_ (u"ࠨࠩࡑ").join([chr(l1ll1_iptv_(x,1) ) for x in l111l_iptv_.encode(l1l1111_iptv_ (u"ࠩࡥࡥࡸ࡫࠶࠵ࠩࡒ")).strip()])
import check
def l1lll1ll_iptv_(url):
    l11111_iptv_=l1l1111_iptv_ (u"ࠪࠫࡓ")
    if os.path.exists(url):
        with open(url,l1l1111_iptv_ (u"ࠫࡷ࠭ࡔ")) as f:
             l11111_iptv_ = f.read()
    out = []
    l1l1lll_iptv_=re.compile(l1l1111_iptv_ (u"ࠬࡤࠧࡕ")+l1l1111_iptv_ (u"࠭ࡉ࠱ࡘ࡜࡚ࡊࡲࡏࡓࡩࡀࡁࠬࡖ").decode(l1l1111_iptv_ (u"ࠧࡣࡣࡶࡩ࠻࠺ࠧࡗ"))+l1l1111_iptv_ (u"ࠨ࠼࠰ࡃࡠ࠶࠭࠺࡟࠭ࠬ࠳࠰࠿ࠪ࠮ࠫ࠲࠯ࡅࠩ࡝ࡰࠫ࠲࠯ࡅࠩࠥࠩࡘ"),re.I+re.M+re.U+re.S).findall(l11111_iptv_)
    l111ll1_iptv_={l1l1111_iptv_ (u"ࠩࡷࡺ࡬࠳ࡩࡥ࡙ࠩ"):l1l1111_iptv_ (u"ࠪࡸࡻ࡯ࡤࠨ࡚"),l1l1111_iptv_ (u"ࠫࡦࡻࡤࡪࡱ࠰ࡸࡷࡧࡣ࡬࡛ࠩ"):l1l1111_iptv_ (u"ࠬࡧࡵࡥ࡫ࡲ࠱ࡹࡸࡡࡤ࡭ࠪ࡜"),l1l1111_iptv_ (u"࠭ࡧࡳࡱࡸࡴ࠲ࡺࡩࡵ࡮ࡨࠫ࡝"):l1l1111_iptv_ (u"ࠧࡨࡴࡲࡹࡵ࠭࡞"),l1l1111_iptv_ (u"ࠨࡶࡹ࡫࠲ࡲ࡯ࡨࡱࠪ࡟"):l1l1111_iptv_ (u"ࠩ࡬ࡱ࡬࠭ࡠ")}
    for params, title, url in l1l1lll_iptv_:
        l11lll1_iptv_  = {l1l1111_iptv_ (u"ࠥࡸ࡮ࡺ࡬ࡦࠤࡡ"): title, l1l1111_iptv_ (u"ࠦࡺࡸ࡬ࠣࡢ"): url}
        l1111ll_iptv_ =re.compile(l1l1111_iptv_ (u"ࠬࠦࠨ࠯࠭ࡂ࠭ࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࡣ"),re.I+re.M+re.U+re.S).findall(params)
        for field, value in l1111ll_iptv_:
            l11lll1_iptv_[l111ll1_iptv_.get(field.strip().lower(),l1l1111_iptv_ (u"࠭ࡢࡢࡦࠪࡤ"))] = value.strip()
        if not l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠧࡵࡸ࡬ࡨࠬࡥ")):
            l11lll1_iptv_[l1l1111_iptv_ (u"ࠨࡶࡹ࡭ࡩ࠭ࡦ")]=title
        l11lll1_iptv_[l1l1111_iptv_ (u"ࠩࡸࡶࡱ࡫ࡰࡨࠩࡧ")]=l1l1111_iptv_ (u"ࠪࠫࡨ")
        l11lll1_iptv_[l1l1111_iptv_ (u"ࠫࡺࡸ࡬ࠨࡩ")]=l11lll1_iptv_[l1l1111_iptv_ (u"ࠬࡻࡲ࡭ࠩࡪ")].strip()
        l11lll1_iptv_[l1l1111_iptv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ࡫")]=l11lll1_iptv_[l1l1111_iptv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭࡬")].strip()
        out.append(l11lll1_iptv_)
    return out
import ramic as l1111_iptv_
def play(ex_link):
    if ex_link.endswith(l1l1111_iptv_ (u"ࠨ࠰ࡷࡷࠬ࡭")):
        try:
            xbmcaddon.Addon(l1l1111_iptv_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡨ࠷ࡱ࡙࡫ࡳࡵࡧࡵࠫ࡮"))
            l111l11_iptv_=l1l1111_iptv_ (u"ࠪࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲࡫࠺࡭ࡕࡧࡶࡸࡪࡸ࠯ࡀࡰࡤࡱࡪࡃࠥࡴࠨࡸࡶࡱࡃࠥࡴࠨࡶࡸࡷ࡫ࡡ࡮ࡶࡼࡴࡪࡃࡔࡔࡆࡒ࡛ࡓࡒࡏࡂࡆࡈࡖࠬ࡯")%(urllib.quote_plus(fname),urllib.quote_plus(ex_link))
            xbmc.sleep(500)
        except:
            l111l11_iptv_ = ex_link
        xbmcplugin.setResolvedUrl(l1ll11l_iptv_, True, xbmcgui.ListItem(path=l111l11_iptv_))
    else:
        if ex_link:
            xbmcplugin.setResolvedUrl(l1ll11l_iptv_, True, xbmcgui.ListItem(path=ex_link))
        else:
            xbmcplugin.setResolvedUrl(l1ll11l_iptv_, False, xbmcgui.ListItem(path=l1l1111_iptv_ (u"ࠫࠬࡰ")))
l1ll1_iptv_ = lambda x,y: ord(x)+4*y if ord(x)%2 else ord(x)
def _111l1_iptv_(s):
    l11l1ll_iptv_={}
    if   s==l1l1111_iptv_ (u"ࠬ࡯ࡰࡵࡸࡶࡥࡹࡲࡩ࡯࡭ࡶࠫࡱ"):     import l11llll_iptv_ as l11l1ll_iptv_
    elif s==l1l1111_iptv_ (u"࠭ࡩࡱࡶࡹࡷࡴࡻࡲࡤࡧࠪࡲ"):               import l1l11l1_iptv_ as l11l1ll_iptv_
    elif s==l1l1111_iptv_ (u"ࠧࡪࡲࡷࡺࡱ࡯࡮࡬ࡵࡶࠫࡳ"): import l1lll11l_iptv_ as l11l1ll_iptv_
    return l11l1ll_iptv_
xbmcplugin.setContent(l1ll11l_iptv_, l1l1111_iptv_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨࡴ"))
mode = args.get(l1l1111_iptv_ (u"ࠩࡰࡳࡩ࡫ࠧࡵ"), None)
l1l1_iptv_()
fname = args.get(l1l1111_iptv_ (u"ࠪࡪࡴࡲࡤࡦࡴࡱࡥࡲ࡫ࠧࡶ"),[l1l1111_iptv_ (u"ࠫࠬࡷ")])[0]
ex_link = args.get(l1l1111_iptv_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭ࡸ"),[l1l1111_iptv_ (u"࠭ࠧࡹ")])[0]
params = args.get(l1l1111_iptv_ (u"ࠧࡱࡣࡵࡥࡲࡹࠧࡺ"),[{}])[0]
if mode is None:
    l11l1l_iptv_(l1l1111_iptv_ (u"ࠨࡋࡱࡪࡴࡸ࡭ࡢࡥ࡭ࡥࠬࡻ"),mode=l1l1111_iptv_ (u"ࠩࡢ࡭ࡳ࡬࡯ࡠࠩࡼ"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1l1111_iptv_ (u"ࠪࡴࡦࡺࡨࠨࡽ")))+l1l1111_iptv_ (u"ࠫ࠴࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧࡾ"))
    l11l1l_iptv_(l1l1111_iptv_ (u"ࠬࡏࡐࡕࡘ࠽ࠤ࡮ࡶࡴࡷࡵࡤࡸࡱ࡯࡮࡬ࡵࠪࡿ"),params={l1l1111_iptv_ (u"࠭࡟ࡴࡧࡵࡺ࡮ࡩࡥࠨࢀ"):l1l1111_iptv_ (u"ࠧࡪࡲࡷࡺࡸࡧࡴ࡭࡫ࡱ࡯ࡸ࠭ࢁ"),l1l1111_iptv_ (u"ࠨࡡࡤࡧࡹ࠭ࢂ"):l1l1111_iptv_ (u"ࠩࡰࡥ࡮ࡴࠧࢃ")}, mode=l1l1111_iptv_ (u"ࠪࡷ࡮ࡺࡥࠨࢄ"),iconImage=l1111l_iptv_+l1l1111_iptv_ (u"ࠫ࡮ࡶࡴࡷࡵࡤࡸࡱ࡯࡮࡬ࡵ࠱࡮ࡵ࡭ࠧࢅ"))
    l11l1l_iptv_(l1l1111_iptv_ (u"ࠬࡏࡐࡕࡘ࠽ࠤ࡮ࡶࡴࡷ࡮࡬ࡲࡰࡹࡳࠨࢆ")  ,params={l1l1111_iptv_ (u"࠭࡟ࡴࡧࡵࡺ࡮ࡩࡥࠨࢇ"):l1l1111_iptv_ (u"ࠧࡪࡲࡷࡺࡱ࡯࡮࡬ࡵࡶࠫ࢈"),l1l1111_iptv_ (u"ࠨࡡࡤࡧࡹ࠭ࢉ"):l1l1111_iptv_ (u"ࠩࡰࡥ࡮ࡴࠧࢊ")}, mode=l1l1111_iptv_ (u"ࠪࡷ࡮ࡺࡥࠨࢋ"),iconImage=l1111l_iptv_+l1l1111_iptv_ (u"ࠫ࡮ࡶࡴࡷ࡮࡬ࡲࡰࡹࡳ࠯ࡲࡱ࡫ࠬࢌ"))
    l11l1l_iptv_(l1l1111_iptv_ (u"ࠬࡏࡐࡕࡘ࠽ࠤࡎࡖࡔࡗࡵࡲࡹࡷࡩࡥࠡࡒࡲࡰࡦࡴࡤࠨࢍ") , params={l1l1111_iptv_ (u"࠭࡟ࡴࡧࡵࡺ࡮ࡩࡥࠨࢎ"):l1l1111_iptv_ (u"ࠧࡪࡲࡷࡺࡸࡵࡵࡳࡥࡨࠫ࢏"),l1l1111_iptv_ (u"ࠨࡡࡤࡧࡹ࠭࢐"):l1l1111_iptv_ (u"ࠩࡰࡥ࡮ࡴࠧ࢑")}, mode=l1l1111_iptv_ (u"ࠪࡷ࡮ࡺࡥࠨ࢒"),iconImage=l1111l_iptv_+l1l1111_iptv_ (u"ࠫ࡮ࡶࡴࡷࡵࡲࡹࡷࡩࡥ࠯ࡲࡱ࡫ࠬ࢓"))
    l11l1l_iptv_(l1l1111_iptv_ (u"ࠬ࡝ࡥࡣࡖ࡙࠾ࠥࡉࡂࡔࠢࡑࡩࡼࡹࠧ࢔"),mode=l1l1111_iptv_ (u"࠭ࡣࡣࡵࡱࡩࡼࡹࠧ࢕"), iconImage=l1l1111_iptv_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡤࡤࡶࡲ࠷࠴ࡣࡣࡵ࡬ࡷࡹࡧࡴࡪࡥ࠱ࡧࡴࡳ࠯ࡪ࡯ࡤ࡫ࡪࡹ࠯ࡪࡱࡶ࠱ࡧࡵ࡯࡬࡯ࡤࡶࡰ࠳࠱࠲࠶࠱࡮ࡵ࡭ࠧ࢖"))
    if [f for f in os.listdir(l1ll111_iptv_) if f.endswith(l1l1111_iptv_ (u"ࠨ࡯࠶ࡹࠬࢗ"))]:
        l11l1l_iptv_(l1l1111_iptv_ (u"ࠩࡀࡁࡲ࠹ࡵ࠾࠿ࠪ࢘"),mode=l1l1111_iptv_ (u"ࠪࡷࡦࡼࡥࡥ࢙ࠩ"), iconImage=l1111l_iptv_+l1l1111_iptv_ (u"ࠫࡲ࠹ࡵ࠯࡬ࡳ࡫࢚ࠬ"))
elif mode[0].startswith(l1l1111_iptv_ (u"ࠬࡥࡩ࡯ࡨࡲࡣ࢛ࠬ")):l1111_iptv_.__myinfo__.go(sys.argv)
elif mode[0] == l1l1111_iptv_ (u"࠭ࡏࡱࡥ࡭ࡩࠬ࢜"):  l1llll11_iptv_.openSettings()
elif mode[0] == l1l1111_iptv_ (u"ࠧࡱ࡮ࡤࡽ࡚ࡸ࡬ࠨ࢝"): play(ex_link)
elif mode[0] == l1l1111_iptv_ (u"ࠨ࡯࠶ࡹࠬ࢞"):
    l1l1ll1_iptv_=l1lll1ll_iptv_(ex_link)
    for l11lll1_iptv_ in l1l1ll1_iptv_:
        l1111l1_iptv_(l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ࢟"),l1l1111_iptv_ (u"ࠪࠫࢠ")),  l11lll1_iptv_[l1l1111_iptv_ (u"ࠫࡺࡸ࡬ࠨࢡ")], l1l1111_iptv_ (u"ࠬࡶ࡬ࡢࡻࡘࡶࡱ࠭ࢢ"), IsPlayable=True,infoLabels=l11lll1_iptv_, l1l_iptv_=l11lll1_iptv_.get(l1l1111_iptv_ (u"࠭ࡩ࡮ࡩࠪࢣ")))
elif mode[0].startswith(l1l1111_iptv_ (u"ࠧࡤࡤࡶࡲࡪࡽࡳࠨࢤ")):
    import l1ll1l_iptv_
    if l1l1111_iptv_ (u"ࠨࡡࡳࡰࡦࡿ࡟ࠨࢥ") in mode[0]:
        l1l111l_iptv_=l1ll1l_iptv_.l1l1l_iptv_(ex_link)
        if isinstance(l1l111l_iptv_,list):
            l11ll_iptv_ = [x.get(l1l1111_iptv_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨࢦ")) for x in l1l111l_iptv_]
            s = xbmcgui.Dialog().select(l1l1111_iptv_ (u"ࠪࡗࡴࡻࡲࡤࡧࠪࢧ"),l11ll_iptv_)
            l1l111l_iptv_=l1l111l_iptv_[s].get(l1l1111_iptv_ (u"ࠫࡺࡸ࡬ࠨࢨ")) if s>-1 else l1l1111_iptv_ (u"ࠬ࠭ࢩ")
        play(l1l111l_iptv_)
    else:
        items = l1ll1l_iptv_.l11l11l_iptv_()
        for l11lll1_iptv_ in items:
            l1111l1_iptv_(l11lll1_iptv_.get(l1l1111_iptv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࢪ"),l1l1111_iptv_ (u"ࠧࠨࢫ")),  l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠨࡷࡵࡰࠬࢬ")), l1l1111_iptv_ (u"ࠩࡦࡦࡸࡴࡥࡸࡵࡢࡴࡱࡧࡹࡠࠩࢭ"), IsPlayable=True,infoLabels=l11lll1_iptv_, l1l_iptv_=l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠪ࡭ࡲ࡭ࠧࢮ")),fanart=l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫࢯ")))
elif mode[0].startswith(l1l1111_iptv_ (u"ࠬࡸࡴࡷࡧࠪࢰ")):
    import l1lll111_iptv_
    if l1l1111_iptv_ (u"࠭࡟ࡱ࡮ࡤࡽࡤ࠭ࢱ") in mode[0]:
        play(ex_link)
    else:
        items = l1lll111_iptv_.l1llll1_iptv_()
        for l11lll1_iptv_ in items:
            l1111l1_iptv_(l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࢲ"),l1l1111_iptv_ (u"ࠨࠩࢳ")),  l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠩࡸࡶࡱ࠭ࢴ")), l1l1111_iptv_ (u"ࠪࡶࡹࡼࡥࡠࡲ࡯ࡥࡾࡥࠧࢵ"), IsPlayable=True,infoLabels=l11lll1_iptv_, l1l_iptv_=l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠫ࡮ࡳࡧࠨࢶ")),fanart=l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࠬࢷ")))
elif mode[0].startswith(l1l1111_iptv_ (u"࠭ࡣࡻࡧࡶ࡯ࡦ࠭ࢸ")):
    import l11l1_iptv_
    if l1l1111_iptv_ (u"ࠧࡱ࡮ࡤࡽࠬࢹ") in mode[0]:
        l11_iptv_ = l11l1_iptv_.l11l111_iptv_(ex_link)
        print l11_iptv_
        if l11_iptv_.get(l1l1111_iptv_ (u"ࠨࡷࡵࡰࠬࢺ"),l1l1111_iptv_ (u"ࠩࠪࢻ")):
            l111lll_iptv_=l11_iptv_.get(l1l1111_iptv_ (u"ࠪࡹࡷࡲࠧࢼ"),l1l1111_iptv_ (u"ࠫࠬࢽ"))
            play(l111lll_iptv_)
        else:
            xbmcgui.Dialog().ok(l1l1111_iptv_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡸࡥࡥ࡟ࡓࡶࡴࡨ࡬ࡦ࡯࡞࠳ࡈࡕࡌࡐࡔࡠࠫࢾ"),l11_iptv_.get(l1l1111_iptv_ (u"࠭࡭ࡴࡩࠪࢿ"),l1l1111_iptv_ (u"ࠧࠨࣀ")))
    else:
        items = l11l1_iptv_.l1llllll_iptv_()
        for l11lll1_iptv_ in items:
            l1111l1_iptv_(l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࣁ"),l1l1111_iptv_ (u"ࠩࠪࣂ")),  l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠪࡹࡷࡲࠧࣃ")), l1l1111_iptv_ (u"ࠫࡨࢀࡥࡴ࡭ࡤࡣࡵࡲࡡࡺࠩࣄ"), IsPlayable=True,infoLabels=l11lll1_iptv_, l1l_iptv_=l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠬ࡯࡭ࡨࠩࣅ")))
elif mode[0] ==l1l1111_iptv_ (u"࠭ࡳࡪࡶࡨࠫࣆ"):
    params = eval(params)
    l1ll11_iptv_ = params.get(l1l1111_iptv_ (u"ࠧࡠࡵࡨࡶࡻ࡯ࡣࡦࠩࣇ"))
    l1l1l1l_iptv_ = params.get(l1l1111_iptv_ (u"ࠨࡡࡤࡧࡹ࠭ࣈ"))
    l11l1ll_iptv_ = _111l1_iptv_(l1ll11_iptv_)
    if l1l1l1l_iptv_ == l1l1111_iptv_ (u"ࠩࡰࡥ࡮ࡴࠧࣉ"):
        params[l1l1111_iptv_ (u"ࠪࡣࡦࡩࡴࠨ࣊")]=l1l1111_iptv_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬ࣋")
        content = l11l1ll_iptv_.l1llllll_iptv_()
        for l11lll1_iptv_ in content:
            if l11lll1_iptv_[l1l1111_iptv_ (u"ࠬࡻࡲ࡭ࠩ࣌")]: l11l1l_iptv_(l11lll1_iptv_.get(l1l1111_iptv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ࣍"),l1l1111_iptv_ (u"ࠧࠨ࣎")),  l11lll1_iptv_[l1l1111_iptv_ (u"ࠨࡷࡵࡰ࣏ࠬ")], params=params, mode=l1l1111_iptv_ (u"ࠩࡶ࡭ࡹ࡫࣐ࠧ"),contextO=[l1l1111_iptv_ (u"ࠪࡊࡤࡇࡄࡅ࣑ࠩ")])
            else: l1111l1_iptv_(l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠫࡹ࡯ࡴ࡭ࡧ࣒ࠪ"),l1l1111_iptv_ (u"࣓ࠬ࠭")),  l1l1111_iptv_ (u"࠭ࠧࣔ"), l1l1111_iptv_ (u"ࠧࠨࣕ"), IsPlayable=False)
    if l1l1l1l_iptv_ == l1l1111_iptv_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࣖ"):
        params[l1l1111_iptv_ (u"ࠩࡢࡥࡨࡺࠧࣗ")]=l1l1111_iptv_ (u"ࠪࡴࡱࡧࡹࠨࣘ")
        l1l1ll1_iptv_ = l11l1ll_iptv_.l1lll1ll_iptv_(ex_link)
        for l11lll1_iptv_ in l1l1ll1_iptv_:
            l1111l1_iptv_(l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪࣙ"),l1l1111_iptv_ (u"ࠬ࠭ࣚ")),  l11lll1_iptv_[l1l1111_iptv_ (u"࠭ࡵࡳ࡮ࠪࣛ")], params=params, mode=l1l1111_iptv_ (u"ࠧࡴ࡫ࡷࡩࠬࣜ"), IsPlayable=True,infoLabels=l11lll1_iptv_, l1l_iptv_=l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠨ࡫ࡰ࡫ࠬࣝ")))
    elif l1l1l1l_iptv_ == l1l1111_iptv_ (u"ࠩࡷࡩࡸࡺࡌࡪࡰ࡮ࡷࠬࣞ"):
        l11l1l1_iptv_ = xbmcgui.DialogProgress()
        l11l1l1_iptv_.create(l1l1111_iptv_ (u"ࠪࡱ࠸ࡻࠠࡍ࡫ࡶࡸ࡚ࠥࡅࡔࡖࠪࣟ"), l1l1111_iptv_ (u"ࠫࡷ࡫ࡴࡳ࡫ࡨࡺ࡮ࡴࡧࠡࡵࡲࡹࡷࡩࡥࡴࠢ࠱࠲࠳࠭࣠"))
        l1l1ll1_iptv_ = l11l1ll_iptv_.l1lll1ll_iptv_(ex_link)
        l11l1l1_iptv_.create(l1l1111_iptv_ (u"ࠬࡳ࠳ࡶࠢࡏ࡭ࡸࡺࠠࡕࡇࡖࡘࠬ࣡"), l1l1111_iptv_ (u"࠭ࡆࡰࡷࡱࡨࠥࢁࡽ࠭ࠢࡷࡩࡸࡺࡩ࡯ࡩࠣ࡭ࡳࠦࡰࡳࡱࡪࡶࡪࡹࡳࠡ࠰࠱࠲ࠬ࣢").format(len(l1l1ll1_iptv_)))
        for index, l11lll1_iptv_ in enumerate(l1l1ll1_iptv_):
            try: code = l1ll1l1_iptv_(l11lll1_iptv_[l1l1111_iptv_ (u"ࠧࡶࡴ࡯ࣣࠫ")]) if l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠨࡷࡵࡰࠬࣤ")) else l1l1111_iptv_ (u"ࠩࡖࡏࡎࡖࠧࣥ")
            except: code = l1l1111_iptv_ (u"ࠪࡘ࡮ࡳࡥࡰࡷࡷࠤࡪࡾࡥࡦࡦࡨࡨࣦࠬ")
            l1lllll_iptv_ = int(index*100.0/len(l1l1ll1_iptv_))
            msg = l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪࣧ"),l1l1111_iptv_ (u"ࠬ࠭ࣨ"))
            msg += l1l1111_iptv_ (u"࠭ࠠ࡜ࡅࡒࡐࡔࡘࠠࡨࡴࡨࡩࡳࡣࠠࡐࡍࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࣩࠬ") if code == 200 else l1l1111_iptv_ (u"ࠧࠡ࡝ࡆࡓࡑࡕࡒࠡࡴࡨࡨࡢࠦࡕࡓࡎࡈࡶࡷࡵࡲ࠻ࠢࠨࡷࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࣪")%code
            l11l1l1_iptv_.update(l1lllll_iptv_,msg)
            if (l11l1l1_iptv_.iscanceled()): break
        l11l1l1_iptv_.close()
    elif l1l1l1l_iptv_ ==  l1l1111_iptv_ (u"ࠨࡲ࡯ࡥࡾ࠭࣫") :
        play(ex_link)
elif mode[0].startswith(l1l1111_iptv_ (u"ࠩ࡬ࡴࡹࡼࡳࡢࡶ࡯࡭ࡳࡱࡳࠨ࣬")):
    import l11llll_iptv_
    if l1l1111_iptv_ (u"ࠪࡣࡵࡲࡡࡺࡡ࣭ࠪ") in mode[0]:
        play(ex_link)
    elif l1l1111_iptv_ (u"ࠫࡤࡩ࡯࡯ࡶࡨࡲࡹࡥ࣮ࠧ") in mode[0]:
        l1l1ll1_iptv_ = l11llll_iptv_.l1lll1ll_iptv_(ex_link)
        for l11lll1_iptv_ in l1l1ll1_iptv_:
            l1111l1_iptv_(l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠬࡺࡩࡵ࡮ࡨ࣯ࠫ"),l1l1111_iptv_ (u"ࣰ࠭ࠧ")),  l11lll1_iptv_[l1l1111_iptv_ (u"ࠧࡶࡴ࡯ࣱࠫ")], l1l1111_iptv_ (u"ࠨ࡫ࡳࡸࡻࡹࡡࡵ࡮࡬ࡲࡰࡹ࡟ࡱ࡮ࡤࡽࡤࣲ࠭"), IsPlayable=True,infoLabels=l11lll1_iptv_, l1l_iptv_=l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠩ࡬ࡱ࡬࠭ࣳ")))
    else:
        content = l11llll_iptv_.l1l11ll_iptv_()
        for l11lll1_iptv_ in content:
            if l11lll1_iptv_[l1l1111_iptv_ (u"ࠪࡹࡷࡲࠧࣴ")]: l11l1l_iptv_(l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪࣵ"),l1l1111_iptv_ (u"ࣶࠬ࠭")),  l11lll1_iptv_[l1l1111_iptv_ (u"࠭ࡵࡳ࡮ࠪࣷ")], l1l1111_iptv_ (u"ࠧࡪࡲࡷࡺࡸࡧࡴ࡭࡫ࡱ࡯ࡸࡥࡣࡰࡰࡷࡩࡳࡺ࡟ࠨࣸ"),contextO=[l1l1111_iptv_ (u"ࠨࡈࡢࡅࡉࡊࣹࠧ")])
            else: l1111l1_iptv_(l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨࣺ"),l1l1111_iptv_ (u"ࠪࠫࣻ")),  l1l1111_iptv_ (u"ࠫࠬࣼ"), l1l1111_iptv_ (u"ࠬ࠭ࣽ"), IsPlayable=False)
elif mode[0].startswith(l1l1111_iptv_ (u"࠭ࡩࡱࡶࡹࡷࡴࡻࡲࡤࡧࠪࣾ")):
    import l1l11l1_iptv_
    if l1l1111_iptv_ (u"ࠧࡠࡲ࡯ࡥࡾࡥࠧࣿ") in mode[0]:
        play(ex_link)
    elif l1l1111_iptv_ (u"ࠨࡡࡦࡳࡳࡺࡥ࡯ࡶࡢࠫऀ") in mode[0]:
        l1l1ll1_iptv_ = l1l11l1_iptv_.l1lll1ll_iptv_(ex_link)
        for l11lll1_iptv_ in l1l1ll1_iptv_:
            l1111l1_iptv_(l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨँ"),l1l1111_iptv_ (u"ࠪࠫं")),  l11lll1_iptv_[l1l1111_iptv_ (u"ࠫࡺࡸ࡬ࠨः")], l1l1111_iptv_ (u"ࠬ࡯ࡰࡵࡸࡶࡥࡹࡲࡩ࡯࡭ࡶࡣࡵࡲࡡࡺࡡࠪऄ"), IsPlayable=True,infoLabels=l11lll1_iptv_, l1l_iptv_=l11lll1_iptv_.get(l1l1111_iptv_ (u"࠭ࡩ࡮ࡩࠪअ")))
    else:
        content = l1l11l1_iptv_.l1llllll_iptv_()
        for l11lll1_iptv_ in content:
            if l11lll1_iptv_[l1l1111_iptv_ (u"ࠧࡶࡴ࡯ࠫआ")]: l11l1l_iptv_(l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧइ"),l1l1111_iptv_ (u"ࠩࠪई")),  l11lll1_iptv_[l1l1111_iptv_ (u"ࠪࡹࡷࡲࠧउ")], l1l1111_iptv_ (u"ࠫ࡮ࡶࡴࡷࡵࡤࡸࡱ࡯࡮࡬ࡵࡢࡧࡴࡴࡴࡦࡰࡷࡣࠬऊ"),contextO=[l1l1111_iptv_ (u"ࠬࡌ࡟ࡂࡆࡇࠫऋ")])
            else: l1111l1_iptv_(l11lll1_iptv_.get(l1l1111_iptv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬऌ"),l1l1111_iptv_ (u"ࠧࠨऍ")),  l1l1111_iptv_ (u"ࠨࠩऎ"), l1l1111_iptv_ (u"ࠩࠪए"), IsPlayable=False)
elif mode[0].startswith(l1l1111_iptv_ (u"ࠪ࡭ࡵࡺࡶ࡭࡫ࡱ࡯ࡸࡹࠧऐ")):
    import l1lll11l_iptv_
    if l1l1111_iptv_ (u"ࠫࡤࡶ࡬ࡢࡻࡢࠫऑ") in mode[0]:
        play(ex_link)
    elif l1l1111_iptv_ (u"ࠬࡥࡣࡰࡰࡷࡩࡳࡺ࡟ࠨऒ") in mode[0]:
        l1l1ll1_iptv_ = l1lll11l_iptv_.l1lll1ll_iptv_(ex_link)
        for l11lll1_iptv_ in l1l1ll1_iptv_:
            l1111l1_iptv_(l11lll1_iptv_.get(l1l1111_iptv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬओ"),l1l1111_iptv_ (u"ࠧࠨऔ")),  l11lll1_iptv_[l1l1111_iptv_ (u"ࠨࡷࡵࡰࠬक")], l1l1111_iptv_ (u"ࠩ࡬ࡴࡹࡼ࡬ࡪࡰ࡮ࡷࡸࡥࡰ࡭ࡣࡼࡣࠬख"), IsPlayable=True,infoLabels=l11lll1_iptv_, l1l_iptv_=l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠪ࡭ࡲ࡭ࠧग")))
    else:
        content = l1lll11l_iptv_.l1llllll_iptv_()
        for l11lll1_iptv_ in content:
            l11l1l_iptv_(l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪघ"),l1l1111_iptv_ (u"ࠬ࠭ङ")),  l11lll1_iptv_.get(l1l1111_iptv_ (u"࠭ࡵࡳ࡮ࠪच")), l1l1111_iptv_ (u"ࠧࡪࡲࡷࡺࡱ࡯࡮࡬ࡵࡶࡣࡨࡵ࡮ࡵࡧࡱࡸࡤ࠭छ"),iconImage=l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠨ࡫ࡰ࡫ࠬज")),contextO=[l1l1111_iptv_ (u"ࠩࡉࡣࡆࡊࡄࠨझ")])
elif mode[0] == l1l1111_iptv_ (u"ࠪࡊࡤࡇࡄࡅࠩञ"):
    try:
        content = l1ll1ll_iptv_(ex_link)
    except:
        content = l1l1111_iptv_ (u"ࠫࠬट")
    if content:
        import base64
        fname = re.sub(l1l1111_iptv_ (u"ࠬࡢ࡛࠯ࠬ࡟ࡡࠬठ"),l1l1111_iptv_ (u"࠭ࠧड"),fname)+l1l1111_iptv_ (u"ࠧ࠯࡯࠶ࡹࠬढ")
        filename = xbmcgui.Dialog().input(l1l1111_iptv_ (u"ࠨࡨ࡬ࡰࡪࠦ࡮ࡢ࡯ࡨࠤࡲ࠹ࡵࠨण"), fname, type=xbmcgui.INPUT_ALPHANUM)
        if filename:
            try:
                with open(os.path.join(l1ll111_iptv_,filename), l1l1111_iptv_ (u"ࠩࡺࠫत")) as f:
                    f.write(content)
            except:
                xbmcgui.Dialog().ok(l1l1111_iptv_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࡑࡴࡲࡦࡱ࡫࡭࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩथ"),l1l1111_iptv_ (u"࡚ࠫࡴࡡࡣ࡮ࡨࠤࡹࡵࠠࡴࡣࡹࡩࠬद"))
elif mode[0] == l1l1111_iptv_ (u"ࠬࡌ࡟ࡓࡇࡐࠫध"):
    if os.path.exists(ex_link):
        xbmc.executebuiltin(l1l1111_iptv_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠨन"))
elif mode[0] == l1l1111_iptv_ (u"ࠧࡴࡣࡹࡩࡩ࠭ऩ"):
    if os.path.exists(l1ll111_iptv_):
        l11l_iptv_ = [f for f in os.listdir(l1ll111_iptv_) if f.endswith(l1l1111_iptv_ (u"ࠨ࡯࠶ࡹࠬप"))]
        for l11lll1_iptv_ in l11l_iptv_:
            l11l1l_iptv_(l11lll1_iptv_,  os.path.join(l1ll111_iptv_,l11lll1_iptv_), l1l1111_iptv_ (u"ࠩࡰ࠷ࡺ࠭फ"),contextO=[l1l1111_iptv_ (u"ࠪࡊࡤࡘࡅࡎࠩब")])
xbmcplugin.endOfDirectory(l1ll11l_iptv_)
