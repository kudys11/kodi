# -*- coding: utf-8 -*-
import sys
l111ll_iptv_ = sys.version_info [0] == 2
l1l11_iptv_ = 2048
l111l1l_iptv_ = 7
def l1l1111_iptv_ (ll_iptv_):
	global l1lllll1_iptv_
	l11111l_iptv_ = ord (ll_iptv_ [-1])
	l1lll11_iptv_ = ll_iptv_ [:-1]
	l111_iptv_ = l11111l_iptv_ % len (l1lll11_iptv_)
	l1lll_iptv_ = l1lll11_iptv_ [:l111_iptv_] + l1lll11_iptv_ [l111_iptv_:]
	if l111ll_iptv_:
		l1l1l11_iptv_ = unicode () .join ([unichr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	else:
		l1l1l11_iptv_ = str () .join ([chr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	return eval (l1l1l11_iptv_)
import urllib2,urllib
import re
import urlparse
l111lllll_iptv_ = l1l1111_iptv_ (u"ࠬࡏ࠰ࡗ࡛࡙ࡉࡱࡕࡒࡨ࠿ࡀࠫ੾").decode(l1l1111_iptv_ (u"࠭ࡢࡢࡵࡨ࠺࠹࠭੿"))
def l1ll1ll_iptv_(url,data=None):
    req = urllib2.Request(url,data)
    req.add_header(l1l1111_iptv_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ઀"), l1l1111_iptv_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠻࠴࠱࠼ࠢࡵࡺ࠿࠸࠲࠯࠲ࠬࠤࡌ࡫ࡣ࡬ࡱ࠲࠶࠵࠷࠰࠱࠳࠳࠵ࠥࡌࡩࡳࡧࡩࡳࡽ࠵࠲࠳࠰࠳ࠫઁ"))
    try:
        response = urllib2.urlopen(req, timeout=10)
        l1l111l_iptv_ = response.read()
        response.close()
    except:
        l1l111l_iptv_=l1l1111_iptv_ (u"ࠩࠪં")
    return l1l111l_iptv_
def l1l11ll_iptv_():
    url=l1l1111_iptv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡭ࡵࡺࡶࡴࡣࡷࡰ࡮ࡴ࡫ࡴ࠰ࡥࡰࡴ࡭ࡳࡱࡱࡷ࠲ࡧ࡫࠯ࡴࡧࡤࡶࡨ࡮࠯࡭ࡣࡥࡩࡱ࠵࡭࠴ࡷࠨ࠶࠵ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨઃ")
    content = l1ll1ll_iptv_(url)
    l111lll1l_iptv_ = re.compile(l1l1111_iptv_ (u"ࠫࡁ࡮࠳ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠵ࡁࠫ઄"),re.DOTALL).findall(content)
    out=[]
    for i,item in enumerate(l111lll1l_iptv_):
        l11l11lll_iptv_ = re.compile(l1l1111_iptv_ (u"ࠬ࡮ࡲࡦࡨࡀ࡟ࡡ࠭ࠢ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠩࠥࡡࡃ࠮࠮ࠫࡁࠬࡀࠬઅ")).findall(item)
        if l11l11lll_iptv_:
            l111ll1l1_iptv_=l11l11lll_iptv_[0]
            l111ll11l_iptv_ = l111ll1ll_iptv_(l111ll1l1_iptv_[0])
            if l111ll11l_iptv_:
                out.append({l1l1111_iptv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬઆ"):l1l1111_iptv_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢ࠭ઇ")+l111ll1l1_iptv_[1]+l1l1111_iptv_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪઈ"),l1l1111_iptv_ (u"ࠩࡸࡶࡱ࠭ઉ"):l1l1111_iptv_ (u"ࠪࠫઊ")})
                out.extend(l111ll11l_iptv_)
        if i>1:
            break
    return out
l1llllll_iptv_ = l1l11ll_iptv_
def l1ll1l1_iptv_(url):
    req = urllib2.Request(url)
    req.add_header(l1l1111_iptv_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨઋ"), l11l11l1l_iptv_)
    try:
        response = urllib2.urlopen(req,timeout=l11l111l1_iptv_)
        code = response.code
        response.close()
    except urllib2.HTTPError as e:
        code= e.code
    return code
def l111ll1ll_iptv_(url):
    content = l1ll1ll_iptv_(url)
    l11ll1l1l_iptv_=re.compile(l1l1111_iptv_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡪࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧઌ"),re.DOTALL).findall(content)
    out=[]
    if l11ll1l1l_iptv_:
        l111lll11_iptv_=re.compile(l1l1111_iptv_ (u"࠭ࠨࡩࡶࡷࡴࡠࡤ࠼࡞ࠬࠬࠫઍ")).findall(l11ll1l1l_iptv_[0])
        for i,l1l111l_iptv_ in enumerate(l111lll11_iptv_):
            title = l1l1111_iptv_ (u"ࠧࠩࡵࡨࡶࡻ࡫ࡲࠡࠧࡧ࠭ࠥࠫࡳࠨ઎")%(i+1,urlparse.urlparse(l1l111l_iptv_).netloc.split(l1l1111_iptv_ (u"ࠨ࠼ࠪએ"))[0])
            href = l1l111l_iptv_.replace(l1l1111_iptv_ (u"ࠩࠩࡥࡲࡶ࠻ࠨઐ"),l1l1111_iptv_ (u"ࠪࠪࠬઑ"))
            out.append({l1l1111_iptv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ઒"):title,l1l1111_iptv_ (u"ࠬࡻࡲ࡭ࠩઓ"):href})
    return out
def l11l111ll_iptv_(out,l11l11ll1_iptv_=5):
    for l11lll1_iptv_ in out[:min( len(out),l11l11ll1_iptv_)]:
        try:
            code= l1ll1l1_iptv_(l11lll1_iptv_.get(l1l1111_iptv_ (u"࠭ࡵࡳ࡮ࠪઔ")))
            l11lll1_iptv_[l1l1111_iptv_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ક")] = code + l1l1111_iptv_ (u"ࠨࠢࠪખ") + l11lll1_iptv_[l1l1111_iptv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨગ")]
            print l1l1111_iptv_ (u"ࠪࡿࢂࠦ࠭ࠡࡽࢀࠫઘ").format(code,l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠫࡺࡸ࡬ࠨઙ")))
        except:
            pass
    return out
def l1lll1ll_iptv_(url):
    l11111_iptv_ = l1ll1ll_iptv_(url)
    out = []
    l1l1lll_iptv_=re.compile(l1l1111_iptv_ (u"ࠬࡤࠧચ")+l111lllll_iptv_+l1l1111_iptv_ (u"࠭࠺࠮ࡁ࡞࠴࠲࠿࡝ࠫࠪ࠱࠮ࡄ࠯ࠬࠩ࠰࠭ࡃ࠮ࡢ࡮ࠩ࠰࠭ࡃ࠮ࠪࠧછ"),re.I+re.M+re.U+re.S).findall(l11111_iptv_)
    l111ll1_iptv_={l1l1111_iptv_ (u"ࠧࡵࡸࡪ࠱࡮ࡪࠧજ"):l1l1111_iptv_ (u"ࠨࡶࡹ࡭ࡩ࠭ઝ"),
             l1l1111_iptv_ (u"ࠩࡤࡹࡩ࡯࡯࠮ࡶࡵࡥࡨࡱࠧઞ"):l1l1111_iptv_ (u"ࠪࡥࡺࡪࡩࡰ࠯ࡷࡶࡦࡩ࡫ࠨટ"),
             l1l1111_iptv_ (u"ࠫ࡬ࡸ࡯ࡶࡲ࠰ࡸ࡮ࡺ࡬ࡦࠩઠ"):l1l1111_iptv_ (u"ࠬ࡭ࡲࡰࡷࡳࠫડ"),
             l1l1111_iptv_ (u"࠭ࡴࡷࡩ࠰ࡰࡴ࡭࡯ࠨઢ"):l1l1111_iptv_ (u"ࠧࡪ࡯ࡪࠫણ")}
    for params, title, url in l1l1lll_iptv_:
        l11lll1_iptv_  = {l1l1111_iptv_ (u"ࠣࡶ࡬ࡸࡱ࡫ࠢત"): title, l1l1111_iptv_ (u"ࠤࡸࡶࡱࠨથ"): url}
        l1111ll_iptv_ =re.compile(l1l1111_iptv_ (u"ࠪࠤ࠭࠴ࠫࡀࠫࡀࠦ࠭࠴ࠪࡀࠫࠥࠫદ"),re.I+re.M+re.U+re.S).findall(params)
        for field, value in l1111ll_iptv_:
            l11lll1_iptv_[l111ll1_iptv_.get(field.strip().lower(),l1l1111_iptv_ (u"ࠫࡧࡧࡤࠨધ"))] = value.strip()
        if not l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠬࡺࡶࡪࡦࠪન")):
            l11lll1_iptv_[l1l1111_iptv_ (u"࠭ࡴࡷ࡫ࡧࠫ઩")]=title
        l11lll1_iptv_[l1l1111_iptv_ (u"ࠧࡶࡴ࡯ࡩࡵ࡭ࠧપ")]=l1l1111_iptv_ (u"ࠨࠩફ")
        l11lll1_iptv_[l1l1111_iptv_ (u"ࠩࡸࡶࡱ࠭બ")]=l11lll1_iptv_[l1l1111_iptv_ (u"ࠪࡹࡷࡲࠧભ")].strip()
        l11lll1_iptv_[l1l1111_iptv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪમ")]=l11lll1_iptv_[l1l1111_iptv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫય")].strip()
        out.append(l11lll1_iptv_)
    return out
