# -*- coding: utf-8 -*-
import sys
l111ll_iptv_ = sys.version_info [0] == 2
l1l11_iptv_ = 2048
l111l1l_iptv_ = 7
def l1l1111_iptv_ (ll_iptv_):
	global l1lllll1_iptv_
	l11111l_iptv_ = ord (ll_iptv_ [-1])
	l1lll11_iptv_ = ll_iptv_ [:-1]
	l111_iptv_ = l11111l_iptv_ % len (l1lll11_iptv_)
	l1lll_iptv_ = l1lll11_iptv_ [:l111_iptv_] + l1lll11_iptv_ [l111_iptv_:]
	if l111ll_iptv_:
		l1l1l11_iptv_ = unicode () .join ([unichr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	else:
		l1l1l11_iptv_ = str () .join ([chr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	return eval (l1l1l11_iptv_)
import urllib2,urllib,json
import re,os
from urlparse import urlparse
l11llllll_iptv_= l1l1111_iptv_ (u"ࠧ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡩࡱࡶࡹࡰ࡮ࡴ࡫ࡴࡵ࠱ࡦࡱࡵࡧࡴࡲࡲࡸ࠳ࡨࡥ࠰ࠤ਱")
l11l111l1_iptv_ = 10
l11l11l1l_iptv_=l1l1111_iptv_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠺࠸࠯࠲࠱࠶࠺࠼࠴࠯࠻࠺ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫਲ")
l111lllll_iptv_ = l1l1111_iptv_ (u"ࠧࡊ࠲࡙࡝࡛ࡋ࡬ࡐࡔࡪࡁࡂ࠭ਲ਼").decode(l1l1111_iptv_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨ਴"))
def l1ll1ll_iptv_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l1l1111_iptv_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ਵ"), l11l11l1l_iptv_)
    if cookies:
        req.add_header(l1l1111_iptv_ (u"ࠥࡇࡴࡵ࡫ࡪࡧࠥਸ਼"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11l111l1_iptv_)
        l1l111l_iptv_ = response.read()
        response.close()
    except:
        l1l111l_iptv_=l1l1111_iptv_ (u"ࠫࠬ਷")
    return l1l111l_iptv_
def l1llllll_iptv_():
    content = l1ll1ll_iptv_(l1l1111_iptv_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡩࡱࡶࡹࡰ࡮ࡴ࡫ࡴࡵ࠱ࡦࡱࡵࡧࡴࡲࡲࡸ࠳ࡨࡥ࠰ࡨࡨࡩࡩࡹ࠯ࡱࡱࡶࡸࡸ࠵ࡳࡶ࡯ࡰࡥࡷࡿ࠿ࡢ࡮ࡷࡁ࡯ࡹ࡯࡯࠯࡬ࡲ࠲ࡹࡣࡳ࡫ࡳࡸࠫࡩࡡ࡭࡮ࡥࡥࡨࡱ࠽ࡱࡣࡪࡩࡓࡧࡶࡪࠨࡰࡥࡽ࠳ࡲࡦࡵࡸࡰࡹࡹ࠽࠳࠲ࠪਸ"))
    data=json.loads(re.search(l1l1111_iptv_ (u"࠭࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠽ࠧࠫਹ"),content).group(1))
    l1l111lll_iptv_ = data.get(l1l1111_iptv_ (u"ࠧࡧࡧࡨࡨࠬ਺"),{}).get(l1l1111_iptv_ (u"ࠨࡧࡱࡸࡷࡿࠧ਻"),[])
    out=[]
    for l11lll1_iptv_ in l1l111lll_iptv_:
        if l1l1111_iptv_ (u"ࠩ࡬ࡴࡹࡼࠠ࡭࡫ࡱ࡯ࡸ਼࠭") in l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ਽"),[{}])[0].get(l1l1111_iptv_ (u"ࠫࡹ࡫ࡲ࡮ࠩਾ"),l1l1111_iptv_ (u"ࠬ࠭ਿ")):
            l11ll1lll_iptv_ = l11lll1_iptv_.get(l1l1111_iptv_ (u"࠭࡭ࡦࡦ࡬ࡥࠩࡺࡨࡶ࡯ࡥࡲࡦ࡯࡬ࠨੀ"),{}).get(l1l1111_iptv_ (u"ࠧࡶࡴ࡯ࠫੁ"),l1l1111_iptv_ (u"ࠨࠩੂ"))
            l111llll1_iptv_ = l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ੃"),{}).get(l1l1111_iptv_ (u"ࠪࠨࡹ࠭੄"),l1l1111_iptv_ (u"ࠫࠬ੅"))
            title = l111llll1_iptv_.split(l1l1111_iptv_ (u"ࠬࡒࡩ࡯࡭ࡶࠫ੆"))[0].strip()
            code = l11lll1_iptv_.get(l1l1111_iptv_ (u"࠭ࡵࡱࡦࡤࡸࡪࡪࠧੇ"),{}).get(l1l1111_iptv_ (u"ࠧࠥࡶࠪੈ"),l1l1111_iptv_ (u"ࠨࠩ੉")).split(l1l1111_iptv_ (u"ࠩࡗࠫ੊"))[0].strip()
            if code:
                title = l1l1111_iptv_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡰ࡮࡭ࡨࡵࡤ࡯ࡹࡪࡣࠥࡴ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࠩࡸ࠭ੋ")%(code,title)
            for l in l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠫࡱ࡯࡮࡬ࠩੌ"),[]):
                if l1l1111_iptv_ (u"ࠬࡺࡥࡹࡶ࠲࡬ࡹࡳ࡬ࠨ੍") in l.get(l1l1111_iptv_ (u"࠭ࡴࡺࡲࡨࠫ੎"),l1l1111_iptv_ (u"ࠧࠨ੏")):
                    url = l.get(l1l1111_iptv_ (u"ࠨࡪࡵࡩ࡫࠭੐"),l1l1111_iptv_ (u"ࠩࠪੑ"))
            if url and l11ll1lll_iptv_ and title:
                out.append({l1l1111_iptv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ੒"):title,l1l1111_iptv_ (u"ࠫ࡮ࡳࡧࠨ੓"):l11ll1lll_iptv_.replace(l1l1111_iptv_ (u"ࠬ࠵ࡳ࠸࠴࠰ࡧ࠴࠭੔"),l1l1111_iptv_ (u"࠭࠯ࡴ࠵࠳࠴࠴࠭੕")),l1l1111_iptv_ (u"ࠧࡶࡴ࡯ࠫ੖"):url,l1l1111_iptv_ (u"ࠨࡥࡲࡨࡪ࠭੗"):code})
    return out
def l11l11111_iptv_():
    content = l1ll1ll_iptv_(l11llllll_iptv_)
    out=[]
    l11l1l111_iptv_ = re.compile(l1l1111_iptv_ (u"ࠩ࠿ࡥࡷࡺࡩࡤ࡮ࡨࠤࡨࡲࡡࡴࡵࡀ࡟ࠧࡢࠧ࡞ࡲࡲࡷࡹࠦࡨࡦࡰࡷࡶࡾࡡࠢ࡝ࠩࡠࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡸࡴࡪࡥ࡯ࡩࡃ࠭੘"),re.DOTALL).findall(content)
    for l11l1111l_iptv_ in l11l1l111_iptv_:
        l11l11lll_iptv_ = re.search(l1l1111_iptv_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࡠࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢࠦࡴࡪࡶ࡯ࡩࡂࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣ࠾ࠨਖ਼"),l11l1111l_iptv_)
        l11ll1lll_iptv_ = re.search(l1l1111_iptv_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿࡫ࡲࡪ࠭ࡠࠨ࡜ࠨ࡟ࠣ࡭ࡲࡧࡧࡦࡣࡱࡧ࡭ࡵࡲ࠾࡝ࠥࡠࠬࡣ࠱࡜ࠤ࡟ࠫࡢ࠭ਗ਼"),l11l1111l_iptv_)
        if l11l11lll_iptv_ and l11ll1lll_iptv_:
            l11lll1_iptv_={l1l1111_iptv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫਜ਼"):l11l11lll_iptv_.group(2),l1l1111_iptv_ (u"࠭ࡩ࡮ࡩࠪੜ"):l11ll1lll_iptv_.group(1),l1l1111_iptv_ (u"ࠧࡶࡴ࡯ࠫ੝"):l11l11lll_iptv_.group(1)}
            out.append(l11lll1_iptv_)
    return out
def l1ll1l1_iptv_(url):
    req = urllib2.Request(url)
    req.add_header(l1l1111_iptv_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬਫ਼"), l11l11l1l_iptv_)
    try:
        response = urllib2.urlopen(req,timeout=l11l111l1_iptv_)
        code = response.code
        response.close()
    except urllib2.HTTPError as e:
        code= e.code
    return code
def l1lll1ll_iptv_(url):
    l11111_iptv_ = l1ll1ll_iptv_(url)
    out = []
    l1l1lll_iptv_=re.compile(l1l1111_iptv_ (u"ࠩࡡࠫ੟")+l111lllll_iptv_+l1l1111_iptv_ (u"ࠪ࠾࠲ࡅ࡛࠱࠯࠼ࡡ࠯࠮࠮ࠫࡁࠬ࠰࠭࠴ࠪࡀࠫ࡟ࡲ࠭࠴ࠪࡀࠫࠧࠫ੠"),re.I+re.M+re.U+re.S).findall(l11111_iptv_)
    l111ll1_iptv_={l1l1111_iptv_ (u"ࠫࡹࡼࡧ࠮࡫ࡧࠫ੡"):l1l1111_iptv_ (u"ࠬࡺࡶࡪࡦࠪ੢"),
             l1l1111_iptv_ (u"࠭ࡡࡶࡦ࡬ࡳ࠲ࡺࡲࡢࡥ࡮ࠫ੣"):l1l1111_iptv_ (u"ࠧࡢࡷࡧ࡭ࡴ࠳ࡴࡳࡣࡦ࡯ࠬ੤"),
             l1l1111_iptv_ (u"ࠨࡩࡵࡳࡺࡶ࠭ࡵ࡫ࡷࡰࡪ࠭੥"):l1l1111_iptv_ (u"ࠩࡪࡶࡴࡻࡰࠨ੦"),
             l1l1111_iptv_ (u"ࠪࡸࡻ࡭࠭࡭ࡱࡪࡳࠬ੧"):l1l1111_iptv_ (u"ࠫ࡮ࡳࡧࠨ੨")}
    for params, title, url in l1l1lll_iptv_:
        l11lll1_iptv_  = {l1l1111_iptv_ (u"ࠧࡺࡩࡵ࡮ࡨࠦ੩"): title, l1l1111_iptv_ (u"ࠨࡵࡳ࡮ࠥ੪"): url.split(l1l1111_iptv_ (u"ࠧ࠽ࠩ੫"))[0]}
        l1111ll_iptv_ =re.compile(l1l1111_iptv_ (u"ࠨࠢࠫ࠲࠰ࡅࠩ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ੬"),re.I+re.M+re.U+re.S).findall(params)
        for field, value in l1111ll_iptv_:
            l11lll1_iptv_[l111ll1_iptv_.get(field.strip().lower(),l1l1111_iptv_ (u"ࠩࡥࡥࡩ࠭੭"))] = value.strip()
        if not l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠪࡸࡻ࡯ࡤࠨ੮")):
            l11lll1_iptv_[l1l1111_iptv_ (u"ࠫࡹࡼࡩࡥࠩ੯")]=title
        l11lll1_iptv_[l1l1111_iptv_ (u"ࠬࡻࡲ࡭ࡧࡳ࡫ࠬੰ")]=l1l1111_iptv_ (u"࠭ࠧੱ")
        l11lll1_iptv_[l1l1111_iptv_ (u"ࠧࡶࡴ࡯ࠫੲ")]=l11lll1_iptv_[l1l1111_iptv_ (u"ࠨࡷࡵࡰࠬੳ")].strip()
        l11lll1_iptv_[l1l1111_iptv_ (u"ࠩࡷ࡭ࡹࡲࡥࠨੴ")]=l11lll1_iptv_[l1l1111_iptv_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩੵ")].strip()
        out.append(l11lll1_iptv_)
    return out
def l11l111ll_iptv_(out,l11l11ll1_iptv_=5):
    l11l11l11_iptv_ (u"ࠫࡹ࡫ࡳࡵ࡫ࡱ࡫ࠥࡻ࡬ࡳࡵࠪ੶")
    for l11lll1_iptv_ in out[:min( len(out),l11l11ll1_iptv_)]:
        try:
            code= l1ll1l1_iptv_(l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠬࡻࡲ࡭ࠩ੷")))
            l11lll1_iptv_[l1l1111_iptv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ੸")] = code + l1l1111_iptv_ (u"ࠧࠡࠩ੹") + l11lll1_iptv_[l1l1111_iptv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ੺")]
            print l1l1111_iptv_ (u"ࠩࡾࢁࠥ࠳ࠠࡼࡿࠪ੻").format(code,l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠪࡹࡷࡲࠧ੼")))
        except:
            pass
    return out
def test():
    out = l1llllll_iptv_()
    url=out[3].get(l1l1111_iptv_ (u"ࠫࡺࡸ࡬ࠨ੽"))
