# -*- coding: utf-8 -*-
import sys
l111ll_iptv_ = sys.version_info [0] == 2
l1l11_iptv_ = 2048
l111l1l_iptv_ = 7
def l1l1111_iptv_ (ll_iptv_):
	global l1lllll1_iptv_
	l11111l_iptv_ = ord (ll_iptv_ [-1])
	l1lll11_iptv_ = ll_iptv_ [:-1]
	l111_iptv_ = l11111l_iptv_ % len (l1lll11_iptv_)
	l1lll_iptv_ = l1lll11_iptv_ [:l111_iptv_] + l1lll11_iptv_ [l111_iptv_:]
	if l111ll_iptv_:
		l1l1l11_iptv_ = unicode () .join ([unichr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	else:
		l1l1l11_iptv_ = str () .join ([chr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	return eval (l1l1l11_iptv_)
import urllib2,urllib,json
import re,os
from urlparse import urlparse
l11llllll_iptv_= l1l1111_iptv_ (u"ࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯࡮࡬ࡺࡪࡵ࡮࡭࡫ࡱࡩࡹࡼ࠲࠵࠹࠱࡭ࡳ࡬࡯ࠣଂ")
l11l111l1_iptv_ = 10
l11l11l1l_iptv_=l1l1111_iptv_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠹࠾࠮࠱࠰࠵࠹࠻࠺࠮࠺࠹ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪଃ")
def l1ll1ll_iptv_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l1l1111_iptv_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ଄"), l11l11l1l_iptv_)
    if cookies:
        req.add_header(l1l1111_iptv_ (u"ࠢࡄࡱࡲ࡯࡮࡫ࠢଅ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11l111l1_iptv_)
        l1l111l_iptv_ = response.read()
        response.close()
    except:
        l1l111l_iptv_=l1l1111_iptv_ (u"ࠨࠩଆ")
    return l1l111l_iptv_
def l1llllll_iptv_():
    content = l1ll1ll_iptv_(l11llllll_iptv_+l1l1111_iptv_ (u"ࠩ࠲ࡸࡻࡩࡨࡢࡰࡱࡩࡱࡹ࠮ࡱࡪࡳࠫଇ"))
    out=[]
    l11ll11l1_iptv_ = re.compile(l1l1111_iptv_ (u"ࠪࡀࡹࡪ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡽࡩࡥࡶ࡫ࡁࠧ࠷࠰࠱ࠤࠣ࡬ࡪ࡯ࡧࡩࡶࡀࠦ࠶࠶࠰ࠣࠢࡥࡳࡷࡪࡥࡳ࠿ࠥ࠴ࠧࡄ࠼ࡣࡴࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃࡂ࠯ࡵࡦࡁࠫଈ")).findall(content)
    for href,l11ll1lll_iptv_,title in l11ll11l1_iptv_:
        l11lll1_iptv_={l1l1111_iptv_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪଉ"):title,l1l1111_iptv_ (u"ࠬ࡯࡭ࡨࠩଊ"):l11ll1lll_iptv_,l1l1111_iptv_ (u"࠭ࡵࡳ࡮ࠪଋ"):l11llllll_iptv_+href}
        out.append(l11lll1_iptv_)
    return out
def l1111l1ll_iptv_(url):
    content = l1ll1ll_iptv_(url)
    l1111ll11_iptv_ = re.compile(l1l1111_iptv_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠩ࠰࠭ࡃ࠮ࡂ࠯ࡪࡨࡵࡥࡲ࡫࠾ࠨଌ"),re.DOTALL).findall(content)
    if l1111ll11_iptv_:
        l1111lll1_iptv_ = re.compile(l1l1111_iptv_ (u"ࠨࡵࡵࡧࡂࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣࠧ଍")).findall(l1111ll11_iptv_[0])
        if l1111lll1_iptv_:
            data = l1ll1ll_iptv_(l1111lll1_iptv_[0])
            l111l111l_iptv_ = re.compile(l1l1111_iptv_ (u"ࠩ࠿ࡷࡴࡻࡲࡤࡧࠣࡸࡾࡶࡥ࠾ࠤࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡰࡴࡪ࡭ࡵࡳ࡮ࠥࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ଎")).findall(data)
            if l111l111l_iptv_:
                print l111l111l_iptv_[0]
            else:
                l1111llll_iptv_=re.compile(l1l1111_iptv_ (u"ࠪࡷࡷࡩ࠽࡜ࠤ࡟ࠫࡢ࠮ࡨࡵࡶࡳ࠾࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣࠧଏ")).findall(data)
                l1111llll_iptv_=re.compile(l1l1111_iptv_ (u"ࠫࡸࡸࡣ࠾࡝ࠥࡠࠬࡣࠨࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡱ࡯ࡶࡦࡱࡱࡰ࡮ࡴࡥࡵࡸ࠵࠸࠼࠴ࡩ࡯ࡨࡲ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢ࠭ଐ"),re.I).findall(data)
                for src in l1111llll_iptv_:
                    if l1l1111_iptv_ (u"ࠬ࡫ࡸࡵࡧࡵࡲࡦࡲࡵࡳ࡮ࠪ଑") in src:
                        l111l1111_iptv_=src[src.find(l1l1111_iptv_ (u"࠭ࡥࡹࡶࡨࡶࡳࡧ࡬ࡶࡴ࡯ࠫ଒"))+12:]
                        print l111l1111_iptv_
                        break
                    elif l1l1111_iptv_ (u"ࠧࡦ࡯ࡥࡩࡩ࠭ଓ") in src:
                        print src
                        data = l1ll1ll_iptv_(src)
                        break
def test():
    out=l1llllll_iptv_()
    for l11lll1_iptv_ in out[:10]:
        url=l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠨࡷࡵࡰࠬଔ"))
        print url
        l1111l1ll_iptv_(url)
        print l1l1111_iptv_ (u"ࠩ࡟ࡲࡡࡴࠧକ")
