# -*- coding: utf-8 -*-
import sys
l111ll_iptv_ = sys.version_info [0] == 2
l1l11_iptv_ = 2048
l111l1l_iptv_ = 7
def l1l1111_iptv_ (ll_iptv_):
	global l1lllll1_iptv_
	l11111l_iptv_ = ord (ll_iptv_ [-1])
	l1lll11_iptv_ = ll_iptv_ [:-1]
	l111_iptv_ = l11111l_iptv_ % len (l1lll11_iptv_)
	l1lll_iptv_ = l1lll11_iptv_ [:l111_iptv_] + l1lll11_iptv_ [l111_iptv_:]
	if l111ll_iptv_:
		l1l1l11_iptv_ = unicode () .join ([unichr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	else:
		l1l1l11_iptv_ = str () .join ([chr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	return eval (l1l1l11_iptv_)
import urllib2,urllib,json
import re,os
from urlparse import urlparse
l11llllll_iptv_= l1l1111_iptv_ (u"ࠨࡨࡵࡶࡳࡷ࠿࠵࠯ࡪࡲࡷࡺࡱ࡯࡮࡬ࡵࡶ࠲ࡧࡲ࡯ࡨࡵࡳࡳࡹ࠴ࡢࡦ࠱ࠥર")
l11l111l1_iptv_ = 10
l11l11l1l_iptv_=l1l1111_iptv_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠴࠹࠰࠳࠲࠷࠻࠶࠵࠰࠼࠻࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬ઱")
l111lllll_iptv_ = l1l1111_iptv_ (u"ࠨࡋ࠳࡚࡞࡜ࡅ࡭ࡑࡕ࡫ࡂࡃࠧલ").decode(l1l1111_iptv_ (u"ࠩࡥࡥࡸ࡫࠶࠵ࠩળ"))
def l1ll1ll_iptv_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l1l1111_iptv_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ઴"), l11l11l1l_iptv_)
    if cookies:
        req.add_header(l1l1111_iptv_ (u"ࠦࡈࡵ࡯࡬࡫ࡨࠦવ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11l111l1_iptv_)
        l1l111l_iptv_ = response.read()
        response.close()
    except:
        l1l111l_iptv_=l1l1111_iptv_ (u"ࠬ࠭શ")
    return l1l111l_iptv_
def l1llllll_iptv_():
    content = l1ll1ll_iptv_(l1l1111_iptv_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲࡮ࡶࡴࡷࡵࡲࡹࡷࡩࡥ࠯ࡥࡲࡱ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ࡦࡷࡵࡳࡵ࡫࠭ࡪࡲࡷࡺ࠲ࡲࡩࡴࡶࡶ࠳ࡵࡵ࡬ࡢࡰࡧ࠱࡮ࡶࡴࡷ࠯࡯࡭ࡸࡺࡳ࠰ࠩષ"))
    out=[]
    l11l1l111_iptv_ = re.compile(l1l1111_iptv_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡺࡤ࠮࡯ࡲࡨࡺࡲࡥ࠮ࡶ࡫ࡹࡲࡨࠢ࠿࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠮ࡃ࠮ࠨ࠮ࠬࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠰ࡅࠩࠣ࠰࠮ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠰ࡅࠩࠣࠢࠪસ"),re.DOTALL).findall(content)
    for href,title,l11ll1lll_iptv_ in l11l1l111_iptv_:
        l11lll1_iptv_={l1l1111_iptv_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧહ"):title.strip(),l1l1111_iptv_ (u"ࠩ࡬ࡱ࡬࠭઺"):l11ll1lll_iptv_,l1l1111_iptv_ (u"ࠪࡹࡷࡲࠧ઻"):href}
        out.append(l11lll1_iptv_)
    return out
def l1lll1ll_iptv_(url):
    url = l1l1111_iptv_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰࡬ࡴࡹࡼࡳࡰࡷࡵࡧࡪ࠴ࡣࡰ࡯࠲ࡴࡴࡲࡡ࡯ࡦ࠰ࡴࡨ࠳ࡳ࡮ࡣࡵࡸ࠲ࡺࡶ࠮ࡨࡵࡩࡪ࠳ࡩࡱࡶࡹ࠱ࡸࡵࡵࡳࡥࡨ࠱ࡱ࡯ࡳࡵ࠯࠳࠺࠲࠷࠲࠮࠳࠺࠳઼ࠬ")
    l11111_iptv_ = l1ll1ll_iptv_(url)
    out = []
    l1l1lll_iptv_=re.compile(l1l1111_iptv_ (u"ࠬࡤࠧઽ")+l111lllll_iptv_+l1l1111_iptv_ (u"࠭࠺࠮ࡁ࡞࠴࠲࠿࡝ࠫࠪ࠱࠮ࡄ࠯ࠬࠩ࠰࠭ࡃ࠮ࡢ࡮ࠩ࠰࠭ࡃ࠮ࠪࠧા"),re.I+re.M+re.U+re.S).findall(l11111_iptv_)
    l111ll1_iptv_={l1l1111_iptv_ (u"ࠧࡵࡸࡪ࠱࡮ࡪࠧિ"):l1l1111_iptv_ (u"ࠨࡶࡹ࡭ࡩ࠭ી"),
             l1l1111_iptv_ (u"ࠩࡤࡹࡩ࡯࡯࠮ࡶࡵࡥࡨࡱࠧુ"):l1l1111_iptv_ (u"ࠪࡥࡺࡪࡩࡰ࠯ࡷࡶࡦࡩ࡫ࠨૂ"),
             l1l1111_iptv_ (u"ࠫ࡬ࡸ࡯ࡶࡲ࠰ࡸ࡮ࡺ࡬ࡦࠩૃ"):l1l1111_iptv_ (u"ࠬ࡭ࡲࡰࡷࡳࠫૄ"),
             l1l1111_iptv_ (u"࠭ࡴࡷࡩ࠰ࡰࡴ࡭࡯ࠨૅ"):l1l1111_iptv_ (u"ࠧࡪ࡯ࡪࠫ૆")}
    for params, title, url in l1l1lll_iptv_:
        l11lll1_iptv_  = {l1l1111_iptv_ (u"ࠣࡶ࡬ࡸࡱ࡫ࠢે"): title, l1l1111_iptv_ (u"ࠤࡸࡶࡱࠨૈ"): url.split(l1l1111_iptv_ (u"ࠪࡀࠬૉ"))[0]}
        l1111ll_iptv_ =re.compile(l1l1111_iptv_ (u"ࠫࠥ࠮࠮ࠬࡁࠬࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ૊"),re.I+re.M+re.U+re.S).findall(params)
        for field, value in l1111ll_iptv_:
            l11lll1_iptv_[l111ll1_iptv_.get(field.strip().lower(),l1l1111_iptv_ (u"ࠬࡨࡡࡥࠩો"))] = value.strip()
        if not l11lll1_iptv_.get(l1l1111_iptv_ (u"࠭ࡴࡷ࡫ࡧࠫૌ")):
            l11lll1_iptv_[l1l1111_iptv_ (u"ࠧࡵࡸ࡬ࡨ્ࠬ")]=title
        l11lll1_iptv_[l1l1111_iptv_ (u"ࠨࡷࡵࡰࡪࡶࡧࠨ૎")]=l1l1111_iptv_ (u"ࠩࠪ૏")
        l11lll1_iptv_[l1l1111_iptv_ (u"ࠪࡹࡷࡲࠧૐ")]=l11lll1_iptv_[l1l1111_iptv_ (u"ࠫࡺࡸ࡬ࠨ૑")].strip()
        l11lll1_iptv_[l1l1111_iptv_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ૒")]=l11lll1_iptv_[l1l1111_iptv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ૓")].strip()
        out.append(l11lll1_iptv_)
    return out
def test():
    out = l1llllll_iptv_()
    url=out[-3].get(l1l1111_iptv_ (u"ࠧࡶࡴ࡯ࠫ૔"))
