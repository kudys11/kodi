# -*- coding: utf-8 -*-
import sys
l111ll_iptv_ = sys.version_info [0] == 2
l1l11_iptv_ = 2048
l111l1l_iptv_ = 7
def l1l1111_iptv_ (ll_iptv_):
	global l1lllll1_iptv_
	l11111l_iptv_ = ord (ll_iptv_ [-1])
	l1lll11_iptv_ = ll_iptv_ [:-1]
	l111_iptv_ = l11111l_iptv_ % len (l1lll11_iptv_)
	l1lll_iptv_ = l1lll11_iptv_ [:l111_iptv_] + l1lll11_iptv_ [l111_iptv_:]
	if l111ll_iptv_:
		l1l1l11_iptv_ = unicode () .join ([unichr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	else:
		l1l1l11_iptv_ = str () .join ([chr (ord (char) - l1l11_iptv_ - (l11l11_iptv_ + l11111l_iptv_) % l111l1l_iptv_) for l11l11_iptv_, char in enumerate (l1lll_iptv_)])
	return eval (l1l1l11_iptv_)
import urllib2,urllib
import re,json
import urlparse,cookielib
l11llllll_iptv_=l1l1111_iptv_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡣࡦࡵ࡮ࡥࡹ࡫࡬ࡦࡸ࡬ࡾࡪ࠴ࡣࡻ࠱ࠪ৓")
def l1ll1ll_iptv_(url,data={},headers={}):
    if headers:
        l11lll1ll_iptv_=headers
    else:
        l11lll1ll_iptv_ = {l1l1111_iptv_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ৔"):l1l1111_iptv_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡐ࡙࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠸࠽࠴࠰࠯࠴࠸࠺࠹࠴࠹࠸ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩ৕")}
    req = urllib2.Request(url,urllib.urlencode(data),l11lll1ll_iptv_)
    try:
        response = urllib2.urlopen(req,timeout=10)
        l1l111l_iptv_ =  response.read()
        response.close()
    except:
        l1l111l_iptv_=l1l1111_iptv_ (u"ࠬ࠭৖")
    return l1l111l_iptv_
def l1llllll_iptv_(url=l11llllll_iptv_):
    content = l1ll1ll_iptv_(url)
    out=[]
    l11l1ll1l_iptv_ = re.compile(l1l1111_iptv_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡵࡧ࡮ࡦ࡮࠰ࡳࡳࡧࡩࡳࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃࡡ࡜࡯࡞ࡷࠤࡢ࠰࠼࠰ࡦ࡬ࡺࡃ࠭ৗ"),re.DOTALL).findall(content)
    for l11ll111l_iptv_ in l11l1ll1l_iptv_:
        href = re.compile(l1l1111_iptv_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠱࠮ࡄࠨࠠࡰࡰࡦࡰ࡮ࡩ࡫࠾ࠤࡧࡩࡱࡧࡹࡖࡃࡈࡺࡪࡴࡴ࡝ࠪࡷ࡬࡮ࡹࠬࠡࡽ࡟ࠫࡪࡼࡥ࡯ࡶ࡟ࠫ࠿ࡢࠧࡉࡱࡰࡩࡵࡧࡧࡦ࠰࡯࡭ࡻ࡫࡜ࠨ࠮࡟ࠫࡪࡇࡣࡵ࡫ࡲࡲࡡ࠭࠺࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࠯ࠫ৘")).findall(l11ll111l_iptv_)
        l11ll1lll_iptv_ = re.compile(l1l1111_iptv_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭৙")).findall(l11ll111l_iptv_)
        title  = re.compile(l1l1111_iptv_ (u"ࠩࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ৚")).findall(l11ll111l_iptv_)
        l11ll1ll1_iptv_ = re.compile(l1l1111_iptv_ (u"ࠪࡀࡸࡶࡡ࡯ࠢࡦࡰࡦࡹࡳ࠾ࠤࡶࡣ࠶࠹࠰ࡱࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ৛")).findall(l11ll111l_iptv_)
        if href and title:
            href = href[0]
            l11ll1lll_iptv_ = l11ll1lll_iptv_[0] if l11ll1lll_iptv_ else l1l1111_iptv_ (u"ࠫࠬড়")
            title = title[0].strip()
            if l11ll1ll1_iptv_:
                title +=l1l1111_iptv_ (u"࡛ࠬࠦࡄࡑࡏࡓࡗࠦ࡬ࡪࡩ࡫ࡸࡧࡲࡵࡦ࡟ࠨࡷࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ঢ়")%l11ll1ll1_iptv_[0].strip()
            out.append({l1l1111_iptv_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ৞"):title,l1l1111_iptv_ (u"ࠧࡶࡴ࡯ࠫয়"):href,l1l1111_iptv_ (u"ࠨ࡫ࡰ࡫ࠬৠ"):l11ll1lll_iptv_})
    return out
def test():
    out = l1llllll_iptv_()
    for l11lll1_iptv_ in out:
        url=l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠩࡸࡶࡱ࠭ৡ"))
        print url
        l11l111_iptv_(l11lll1_iptv_.get(l1l1111_iptv_ (u"ࠪࡹࡷࡲࠧৢ")))
def l11l111_iptv_(l11lll11l_iptv_=l1l1111_iptv_ (u"ࠫࡨࡺ࠲࠵ࠩৣ")):
    l11ll11l1_iptv_={l1l1111_iptv_ (u"ࠬࡩࡴ࠲ࠩ৤"):l1l1111_iptv_ (u"࠭࠱ࠨ৥"),l1l1111_iptv_ (u"ࠧࡤࡶ࠵ࠫ০"):l1l1111_iptv_ (u"ࠨ࠴ࠪ১"),l1l1111_iptv_ (u"ࠩࡦࡸ࠷࠺ࠧ২"):l1l1111_iptv_ (u"ࠪ࠶࠹࠭৩"),l1l1111_iptv_ (u"ࠫࡸࡶ࡯ࡳࡶࠪ৪"):l1l1111_iptv_ (u"ࠬ࠺ࠧ৫"),l1l1111_iptv_ (u"࠭ࡣࡵ࠷ࠪ৬"):l1l1111_iptv_ (u"ࠧ࠶ࠩ৭"),l1l1111_iptv_ (u"ࠨࡆࠪ৮"):l1l1111_iptv_ (u"ࠩ࠸ࠫ৯"),l1l1111_iptv_ (u"ࠪࡥࡷࡺࠧৰ"):l1l1111_iptv_ (u"ࠫ࠻࠭ৱ")}
    l11lll111_iptv_={l1l1111_iptv_ (u"ࠬࡳࡳࡨࠩ৲"):l1l1111_iptv_ (u"࠭ࠧ৳"),l1l1111_iptv_ (u"ࠧࡶࡴ࡯ࠫ৴"):l1l1111_iptv_ (u"ࠨࠩ৵")}
    if l11lll11l_iptv_ in l11ll11l1_iptv_.keys():
        print l1l1111_iptv_ (u"ࠩࡦࡾࡪࡹ࡫ࡢࡶࡹࠫ৶"),l11ll11l1_iptv_[l11lll11l_iptv_]
        url=l1l1111_iptv_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡤࡧࡶ࡯ࡦࡺࡥ࡭ࡧࡹ࡭ࡿ࡫࠮ࡤࡼ࠲࡭ࡻࡿࡳࡪ࡮ࡤࡲ࡮࠵ࡡ࡫ࡣࡻ࠳࡬࡫ࡴ࠮ࡥ࡯࡭ࡪࡴࡴ࠮ࡲ࡯ࡥࡾࡲࡩࡴࡶࠪ৷")
        l11l1l1l1_iptv_=l1l1111_iptv_ (u"ࠫ࠴࡯ࡶࡺࡵ࡬ࡰࡦࡴࡩ࠰ࡧࡰࡦࡪࡪ࠯ࡪࡈࡵࡥࡲ࡫ࡐ࡭ࡣࡼࡩࡷࡉࡔ࠳࠶࠱ࡴ࡭ࡶࠧ৸")
        header={ l1l1111_iptv_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ৹"):l1l1111_iptv_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠻࠲࠯࠲࠱࠶࠼࠺࠳࠯࠳࠴࠺࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬ৺"),l1l1111_iptv_ (u"ࠧࡹ࠯ࡤࡨࡩࡸࠧ৻"): l1l1111_iptv_ (u"ࠨ࠳࠵࠻࠳࠶࠮࠱࠰࠴ࠫৼ"),}
        l11l1llll_iptv_ = {l1l1111_iptv_ (u"ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࡟࠵ࡣ࡛ࡪࡦࡠࠫ৽"): l11ll11l1_iptv_[l11lll11l_iptv_],l1l1111_iptv_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸࡠ࠶࡝࡜ࡶࡼࡴࡪࡣࠧ৾"): l1l1111_iptv_ (u"ࠦࡨ࡮ࡡ࡯ࡰࡨࡰࠧ৿"),l1l1111_iptv_ (u"ࠬࡸࡥࡲࡷࡨࡷࡹ࡛ࡲ࡭ࠩ਀"): l11l1l1l1_iptv_,l1l1111_iptv_ (u"࠭ࡲࡦࡳࡸࡩࡸࡺࡓࡰࡷࡵࡧࡪ࠭ਁ"): l1l1111_iptv_ (u"ࠢࡪࡘࡼࡷ࡮ࡲࡡ࡯࡫ࠥਂ"),l1l1111_iptv_ (u"ࠨࡣࡧࡨࡈࡵ࡭࡮ࡧࡵࡧ࡮ࡧ࡬ࡴࠩਃ"): 0,l1l1111_iptv_ (u"ࠩࡷࡽࡵ࡫ࠧ਄"): l1l1111_iptv_ (u"ࠥ࡬ࡹࡳ࡬ࠣਅ")}
        content = l1ll1ll_iptv_(url, l11l1llll_iptv_, headers=header)
        l11l1l1ll_iptv_=json.loads(content).get(l1l1111_iptv_ (u"ࠫࡺࡸ࡬ࠨਆ"))
        if l11l1l1ll_iptv_.startswith(l1l1111_iptv_ (u"ࠬ࡮ࡴࡵࡲࠪਇ")):
            data = l1ll1ll_iptv_(l11l1l1ll_iptv_)
            if data:
                data = json.loads(data)
                src=data[l1l1111_iptv_ (u"࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࠨਈ")][0][l1l1111_iptv_ (u"ࠧࡴࡶࡵࡩࡦࡳࡕࡳ࡮ࡶࠫਉ")][l1l1111_iptv_ (u"ࠨ࡯ࡤ࡭ࡳ࠭ਊ")]
                src=src.replace(l1l1111_iptv_ (u"ࠩࡶ࡯࡮ࡶࡉࡱࡃࡧࡨࡷ࡫ࡳࡴࡅ࡫ࡩࡨࡱ࠽ࡧࡣ࡯ࡷࡪ࠭਋"),l1l1111_iptv_ (u"ࠪࡷࡰ࡯ࡰࡊࡲࡄࡨࡩࡸࡥࡴࡵࡆ࡬ࡪࡩ࡫࠾ࡶࡵࡹࡪ࠭਌"))
                l11ll1l1l_iptv_=l1ll1ll_iptv_(src)
                l11ll1l11_iptv_=re.compile(l1l1111_iptv_ (u"ࠫࡁࡈࡡࡴࡧࡘࡖࡑࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡂࡢࡵࡨ࡙ࡗࡒ࠾ࠨ਍"),re.IGNORECASE).findall(l11ll1l1l_iptv_)
                id = re.compile(l1l1111_iptv_ (u"ࠬࡂࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴࠠࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ਎")).findall(l11ll1l1l_iptv_)
                ref=l1l1111_iptv_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡧࡪࡹ࡫ࡢࡶࡨࡰࡪࡼࡩࡻࡧ࠱ࡧࡿ࠵ࡩࡷࡻࡶ࡭ࡱࡧ࡮ࡪ࠱ࡨࡱࡧ࡫ࡤ࠰࡫ࡉࡶࡦࡳࡥࡑ࡮ࡤࡽࡪࡸ࠮ࡱࡪࡳࡃࡸࡱࡩ࡯ࡋࡇࡁ࠸ࠬࠦࡵࡲ࡯ࡁࡱ࡯ࡶࡦࠨࡰࡹࡱࡺࡩ࡮ࡧࡧ࡭ࡦࡃ࠱ࠧࡹ࡬ࡨࡹ࡮࠽࠲࠲࠳ࠩ࠷࠻ࠦࡩࡣࡶ࡬ࡂ࠻࠵࠲࠳ࡩ࠺ࡪ࠼ࡡࡣ࠵࠷ࡦ࠹࠽࠲ࡢ࠺࠴࠵࠻ࡨ࠴ࡥ࠶࠴࠴ࡧ࠷࠵࠴࠴࠶ࡥ࠷ࡨࡥ࠶࠲ࡧࠪࡻ࡯ࡤࡦࡱࡌࡈࡂࡉࡔ࠳࠶ࠪਏ")
                l11lll111_iptv_[l1l1111_iptv_ (u"ࠧࡶࡴ࡯ࠫਐ")] = src+l1l1111_iptv_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠩࡸࠬࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡏࡘ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠸࠶࠳࠶࠮࠳࠹࠷࠷࠳࠷࠱࠷ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩ਑")%ref
        else:
            l11lll111_iptv_[l1l1111_iptv_ (u"ࠩࡰࡷ࡬࠭਒")] = l11l1l1ll_iptv_
    else:
        l11lll111_iptv_[l1l1111_iptv_ (u"ࠪࡱࡸ࡭ࠧਓ")]=l1l1111_iptv_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠥࡩࡨࡢࡰࡱࡩࡱ࡛ࠦࠦࡵࡠࠫਔ")%l11lll11l_iptv_
    return l11lll111_iptv_
def l11l1lll1_iptv_(l11l1l11l_iptv_=l1l1111_iptv_ (u"ࠬ࠷ࠧਕ"),l11ll11ll_iptv_=l1l1111_iptv_ (u"࠭ࡣࡩࡣࡱࡲࡪࡲࠧਖ"),l11l1ll11_iptv_=l1l1111_iptv_ (u"ࠧ࠰࡫ࡹࡽࡸ࡯࡬ࡢࡰ࡬࠳ࡪࡳࡢࡦࡦ࠲࡭ࡋࡸࡡ࡮ࡧࡓࡰࡦࡿࡥࡳࡅࡗ࠶࠹࠴ࡰࡩࡲࠪਗ")):
    l11lll111_iptv_={l1l1111_iptv_ (u"ࠨ࡯ࡶ࡫ࠬਘ"):l1l1111_iptv_ (u"ࠩࠪਙ"),l1l1111_iptv_ (u"ࠪࡹࡷࡲࠧਚ"):l1l1111_iptv_ (u"ࠫࠬਛ")}
    url=l1l1111_iptv_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡦࡩࡸࡱࡡࡵࡧ࡯ࡩࡻ࡯ࡺࡦ࠰ࡦࡾ࠴࡯ࡶࡺࡵ࡬ࡰࡦࡴࡩ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶ࠰ࡧࡱ࡯ࡥ࡯ࡶ࠰ࡴࡱࡧࡹ࡭࡫ࡶࡸࠬਜ")
    header={ l1l1111_iptv_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪਝ"):l1l1111_iptv_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠵࠳࠰࠳࠲࠷࠽࠴࠴࠰࠴࠵࠻ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ਞ"),l1l1111_iptv_ (u"ࠨࡺ࠰ࡥࡩࡪࡲࠨਟ"): l1l1111_iptv_ (u"ࠩ࠴࠶࠼࠴࠰࠯࠲࠱࠵ࠬਠ"),}
    l11l1llll_iptv_ = {l1l1111_iptv_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸࡠ࠶࡝࡜࡫ࡧࡡࠬਡ"): l11l1l11l_iptv_,l1l1111_iptv_ (u"ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹࡡ࠰࡞࡝ࡷࡽࡵ࡫࡝ࠨਢ"): l11ll11ll_iptv_,l1l1111_iptv_ (u"ࠬࡸࡥࡲࡷࡨࡷࡹ࡛ࡲ࡭ࠩਣ"): l11l1ll11_iptv_,l1l1111_iptv_ (u"࠭ࡲࡦࡳࡸࡩࡸࡺࡓࡰࡷࡵࡧࡪ࠭ਤ"): l1l1111_iptv_ (u"ࠢࡪࡘࡼࡷ࡮ࡲࡡ࡯࡫ࠥਥ"),l1l1111_iptv_ (u"ࠨࡣࡧࡨࡈࡵ࡭࡮ࡧࡵࡧ࡮ࡧ࡬ࡴࠩਦ"): 0,l1l1111_iptv_ (u"ࠩࡷࡽࡵ࡫ࠧਧ"): l1l1111_iptv_ (u"ࠥ࡬ࡹࡳ࡬ࠣਨ")}
    content = l1ll1ll_iptv_(url, l11l1llll_iptv_, headers=header)
    l11l1l1ll_iptv_=json.loads(content).get(l1l1111_iptv_ (u"ࠫࡺࡸ࡬ࠨ਩"))
    if l11l1l1ll_iptv_.startswith(l1l1111_iptv_ (u"ࠬ࡮ࡴࡵࡲࠪਪ")):
        data = l1ll1ll_iptv_(l11l1l1ll_iptv_)
        if data:
            data = json.loads(data)
            src=data[l1l1111_iptv_ (u"࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࠨਫ")][0][l1l1111_iptv_ (u"ࠧࡴࡶࡵࡩࡦࡳࡕࡳ࡮ࡶࠫਬ")][l1l1111_iptv_ (u"ࠨ࡯ࡤ࡭ࡳ࠭ਭ")]
            l11ll1l1l_iptv_=l1ll1ll_iptv_(src)
            l11ll1111_iptv_=re.compile(l1l1111_iptv_ (u"ࠩࠫࡆࡆࡔࡄࡘࡋࡇࡘࡍࡃ࠮ࠫࡁࠬࡠࡳ࠮࠮ࠫࡁࠬࡠࡳ࠭ਮ")).findall(l11ll1l1l_iptv_)
            l11lll111_iptv_[l1l1111_iptv_ (u"ࠪࡹࡷࡲࠧਯ")] = l11ll1111_iptv_
    else:
        l11lll111_iptv_[l1l1111_iptv_ (u"ࠫࡲࡹࡧࠨਰ")] = l11l1l1ll_iptv_
    return l11lll111_iptv_
