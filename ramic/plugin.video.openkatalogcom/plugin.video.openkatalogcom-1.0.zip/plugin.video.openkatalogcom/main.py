# -*- coding: utf-8 -*-
import sys
l1l11l11l1_ok_ = sys.version_info [0] == 2
l1l1lll11l1_ok_ = 2048
l11lll11l1_ok_ = 7
def l11l11l1_ok_ (keyedStringLiteral):
	global l11l1ll11l1_ok_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l11l11l1_ok_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l1lll11l1_ok_ - (charIndex + stringNr) % l11lll11l1_ok_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l1lll11l1_ok_ - (charIndex + stringNr) % l11lll11l1_ok_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urlparse,sys,urllib
params = dict(urlparse.parse_qsl(sys.argv[2].replace(l11l11l1_ok_ (u"ࠫࡄ࠭ࠀ"),l11l11l1_ok_ (u"ࠬ࠭ࠁ"))))
mode = params.get(l11l11l1_ok_ (u"࠭࡭ࡰࡦࡨࠫࠂ"))
fname = params.get(l11l11l1_ok_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫࠃ"))
ex_link = params.get(l11l11l1_ok_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩࠄ"))
l111lll11l1_ok_ = params.get(l11l11l1_ok_ (u"ࠩࡳࡥ࡬࡫ࠧࠅ"))
import xbmcgui,xbmc
import time,os
l1ll11l1_ok_ = xbmcgui.Dialog()
import time,threading
try: from shutil import rmtree
except: rmtree = False
def lll11l1_ok_(l111l1l11l1_ok_,l11ll11l1_ok_=[l11l11l1_ok_ (u"ࠪࠫࠆ")]):
    debug=1
def l1111l11l1_ok_(name=l11l11l1_ok_ (u"ࠫࠬࠇ")):
    debug=1
def l1llll11l1_ok_(top):
    debug=1
def l11llll11l1_ok_():
    l111l1l11l1_ok_ = os.path.join(xbmc.translatePath(l11l11l1_ok_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭ࠏ")),l11l11l1_ok_ (u"࠭ࡡࡥࡦࡲࡲࡸ࠭ࠐ"))
    debug=1
    l1l111l11l1_ok_ = os.path.join(xbmc.translatePath(l11l11l1_ok_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡵࡴࡧࡵࡨࡦࡺࡡࠨࠔ")),l11l11l1_ok_ (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨࠕ"),l11l11l1_ok_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡥࡪࡵ࡮࠯ࡰࡲࡼ࠳࠻ࠧࠖ"),l11l11l1_ok_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬࠗ"))
    debug=1
    l1l111l11l1_ok_ = os.path.join(xbmc.translatePath(l11l11l1_ok_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡹࡸ࡫ࡲࡥࡣࡷࡥࠬࠟ")),l11l11l1_ok_ (u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬࠠ"),l11l11l1_ok_ (u"ࠩࡶ࡯࡮ࡴ࠮ࡹࡱࡱࡪࡱࡻࡥ࡯ࡥࡨࠫࠡ"),l11l11l1_ok_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩࠢ"))
    debug=1
    l111l1l11l1_ok_ = os.path.join(xbmc.translatePath(l11l11l1_ok_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡻࡳࡦࡴࡧࡥࡹࡧࠧࠨ")),l11l11l1_ok_ (u"ࠪࡴࡷࡵࡦࡪ࡮ࡨࡷࠬࠩ"))
    debug=1
    l1lll11l1_ok_ = xbmc.translatePath(l11l11l1_ok_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧࠬ"))
    debug=1
def l111l11l1_ok_():
    try:
        debug=1
    except: pass
import resources.lib.l1ll11l11l1_ok_
if mode is None:
    from resources.lib import l1l1l11l1_ok_
    l1l1l11l1_ok_.l1l1l11l1_ok_().root()
elif mode.startswith(l11l11l1_ok_ (u"ࠩࡢ࡭ࡳ࡬࡯ࡠࠩ࠯"))  :
    from resources.lib import l1l1l11l1_ok_
    l1l1l11l1_ok_.l1l1l11l1_ok_().info()
elif mode == l11l11l1_ok_ (u"ࠪ࡯ࡦࡺࡥࡨࡱࡵ࡭ࡪ࠭࠰"):
    from resources.lib import l1l1l11l1_ok_
    l1l1l11l1_ok_.l1l1l11l1_ok_().l11l11l11l1_ok_()
elif mode == l11l11l1_ok_ (u"ࠫࡷࡵ࡫ࠨ࠱"):
    from resources.lib import l1l1l11l1_ok_
    l1l1l11l1_ok_.l1l1l11l1_ok_().l1l11l1_ok_()
elif mode == l11l11l1_ok_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࠲"):
    from resources.lib import l1l1l11l1_ok_
    l1l1l11l1_ok_.l1l1l11l1_ok_().content(ex_link)
elif mode.startswith(l11l11l1_ok_ (u"࠭࡟ࡠࡲࡤ࡫ࡪࡥ࡟࠻ࠩ࠳")):
    from resources.lib import l1l1l11l1_ok_
    l1l1l11l1_ok_.l1l1l11l1_ok_().l11l1l11l1_ok_(mode,ex_link)
elif mode.startswith(l11l11l1_ok_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ࠴")):
    from resources.lib import l1l1l11l1_ok_
    l1l1l11l1_ok_.l1l1l11l1_ok_().l1lllll11l1_ok_(mode,ex_link)
elif mode == l11l11l1_ok_ (u"ࠨࡲ࡯ࡥࡾࡕࡰࡦࡰࡎࡥࡹࡧ࡬ࡰࡩࠪ࠵"):
    from resources.lib import l1l1l11l1_ok_
    l1l1l11l1_ok_.l1l1l11l1_ok_().l1lll1l11l1_ok_(ex_link)
elif mode == l11l11l1_ok_ (u"ࠩࡶࡩࡷ࡯ࡡ࡭ࡧࡢࡷࡪࡧࡳࡰࡰࡶࠫ࠶"):
    from resources.lib import l1l1l11l1_ok_
    l1l1l11l1_ok_.l1l1l11l1_ok_().l1ll1ll11l1_ok_(ex_link)
elif mode == l11l11l1_ok_ (u"ࠪࡷࡪࡸࡩࡢ࡮ࡨࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭࠷"):
    from resources.lib import l1l1l11l1_ok_
    l1l1l11l1_ok_.l1l1l11l1_ok_().l11ll1l11l1_ok_(ex_link)
