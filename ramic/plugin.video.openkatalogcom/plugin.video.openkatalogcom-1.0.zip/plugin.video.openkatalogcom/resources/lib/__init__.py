# coding: UTF-8
import sys
l1l11l11l1_ok_ = sys.version_info [0] == 2
l1l1lll11l1_ok_ = 2048
l11lll11l1_ok_ = 7
def l11l11l1_ok_ (keyedStringLiteral):
	global l11l1ll11l1_ok_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l11l11l1_ok_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l1lll11l1_ok_ - (charIndex + stringNr) % l11lll11l1_ok_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l1lll11l1_ok_ - (charIndex + stringNr) % l11lll11l1_ok_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)