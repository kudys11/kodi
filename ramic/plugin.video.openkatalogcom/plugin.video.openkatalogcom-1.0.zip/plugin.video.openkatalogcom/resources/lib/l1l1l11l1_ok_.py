# -*- coding: utf-8 -*-
import sys
l1l11l11l1_ok_ = sys.version_info [0] == 2
l1l1lll11l1_ok_ = 2048
l11lll11l1_ok_ = 7
def l11l11l1_ok_ (keyedStringLiteral):
	global l11l1ll11l1_ok_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l11l11l1_ok_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l1lll11l1_ok_ - (charIndex + stringNr) % l11lll11l1_ok_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l1lll11l1_ok_ - (charIndex + stringNr) % l11lll11l1_ok_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import ramic as l11lll1l11l1_ok_
l111l1ll11l1_ok_        = sys.argv[0]
l1lll1l1l11l1_ok_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l11llllll11l1_ok_        = xbmcaddon.Addon()
l11llll1l11l1_ok_     = l11llllll11l1_ok_.getAddonInfo(l11l11l1_ok_ (u"ࠨ࡫ࡧࠫ࡟"))
l1lll11l11l1_ok_       = l11llllll11l1_ok_.getAddonInfo(l11l11l1_ok_ (u"ࠩࡱࡥࡲ࡫ࠧࡠ"))
PATH        = l11llllll11l1_ok_.getAddonInfo(l11l11l1_ok_ (u"ࠪࡴࡦࡺࡨࠨࡡ")).decode(l11l11l1_ok_ (u"ࠫࡺࡺࡦ࠮࠺ࠪࡢ"))
l1lll111l11l1_ok_    = xbmc.translatePath(l11llllll11l1_ok_.getAddonInfo(l11l11l1_ok_ (u"ࠬࡶࡲࡰࡨ࡬ࡰࡪ࠭ࡣ"))).decode(l11l11l1_ok_ (u"࠭ࡵࡵࡨ࠰࠼ࠬࡤ"))
l1l1ll11l11l1_ok_   = PATH+l11l11l1_ok_ (u"ࠧ࠰ࡴࡨࡷࡴࡻࡲࡤࡧࡶ࠳ࠬࡥ")
l1l11llll11l1_ok_=l1l1ll11l11l1_ok_+l11l11l1_ok_ (u"ࠨࡨࡤࡲࡦࡸࡴ࠯ࡲࡱ࡫ࠬࡦ")
sys.path.append(l1l1ll11l11l1_ok_+l11l11l1_ok_ (u"ࠩ࡯࡭ࡧ࠵ࠧࡧ"))
l1l1111ll11l1_ok_ = urllib2.urlopen
l11111ll11l1_ok_ = urllib2.Request
l1ll11l1_ok_ = xbmcgui.Dialog()
import time,threading
l1l111ll11l1_ok_ = lambda x,y: ord(x)+16*y if ord(x)%2 else ord(x)
l11lll11l11l1_ok_ = lambda l11l1l1l11l1_ok_: l11l11l1_ok_ (u"ࠪࠫࡨ").join([chr(l1l111ll11l1_ok_(x,1) ) for x in l11l1l1l11l1_ok_.encode(l11l11l1_ok_ (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫࡩ")).strip()])
l1ll1lll11l1_ok_ = lambda l11l1l1l11l1_ok_: l11lll11l11l1_ok_(l11l1l1l11l1_ok_).encode(l11l11l1_ok_ (u"ࠬ࡮ࡥࡹࠩࡪ"))
l111111l11l1_ok_ = lambda l11l1l1l11l1_ok_: l11l11l1_ok_ (u"࠭ࠧ࡫").join([chr(l1l111ll11l1_ok_(x,-1) ) for x in l11l1l1l11l1_ok_]).decode(l11l11l1_ok_ (u"ࠧࡣࡣࡶࡩ࠻࠺ࠧ࡬"))
l11lll1ll11l1_ok_ = lambda l11l1l1l11l1_ok_: l111111l11l1_ok_(l11l1l1l11l1_ok_.decode(l11l11l1_ok_ (u"ࠨࡪࡨࡼࠬ࡭")))
if not os.path.exists(l11l11l1_ok_ (u"ࠩ࠲࡬ࡴࡳࡥ࠰ࡱࡶࡱࡨ࠭࡮")):
    tm=time.gmtime()
    try:    l111l11l11l1_ok_,l1ll1l1ll11l1_ok_,l111ll1l11l1_ok_ = l11lll1ll11l1_ok_(l11llllll11l1_ok_.getSetting(l11l11l1_ok_ (u"ࠪ࡯ࡴࡪࠧ࡯"))).split(l11l11l1_ok_ (u"ࠫ࠿࠭ࡰ"))
    except: l111l11l11l1_ok_,l1ll1l1ll11l1_ok_,l111ll1l11l1_ok_ =  [l11l11l1_ok_ (u"ࠬ࠳࠱ࠨࡱ"),l11l11l1_ok_ (u"࠭ࠧࡲ"),l11l11l1_ok_ (u"ࠧ࠮࠳ࠪࡳ")]
    if int(l111l11l11l1_ok_) != tm.tm_hour:
        try:    l11ll11l11l1_ok_ = re.findall(l11l11l1_ok_ (u"ࠨࡍࡒࡈ࠿ࠦࠨ࠯ࠬࡂ࠭ࡡࡴࠧࡴ"),l1l1111ll11l1_ok_(l11l11l1_ok_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡶࡦࡽ࠮ࡨ࡫ࡷ࡬ࡺࡨࡵࡴࡧࡵࡧࡴࡴࡴࡦࡰࡷ࠲ࡨࡵ࡭࠰ࡴࡤࡱ࡮ࡩࡳࡱࡣ࠲࡯ࡴࡪࡩ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡔࡈࡅࡉࡓࡅ࠯࡯ࡧࠫࡵ")).read())[0].strip(l11l11l1_ok_ (u"ࠪ࠮ࠬࡶ"))
        except: l11ll11l11l1_ok_ = l11l11l1_ok_ (u"ࠫࠬࡷ")
        l11l1lll11l1_ok_ = l1ll1lll11l1_ok_(l11l11l1_ok_ (u"࠭ࠥࡥ࠼ࠨࡷ࠿ࠫࡤࠨࢀ")%(tm.tm_hour,l11ll11l11l1_ok_,tm.tm_min))
        l11llllll11l1_ok_.setSetting(l11l11l1_ok_ (u"ࠧ࡬ࡱࡧࠫࢁ"),l11l1lll11l1_ok_)
def l1ll1ll1l11l1_ok_(name, url, mode, l111lll11l1_ok_=1, l1l1111l11l1_ok_=l11l11l1_ok_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬࢂ"), infoLabels={}, IsPlayable=True, fanart=l1l11llll11l1_ok_,l1llll1ll11l1_ok_=1):
    u = l1ll111l11l1_ok_({l11l11l1_ok_ (u"ࠩࡰࡳࡩ࡫ࠧࢃ"): mode, l11l11l1_ok_ (u"ࠪࡪࡴࡲࡤࡦࡴࡱࡥࡲ࡫ࠧࢄ"): name, l11l11l1_ok_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬࢅ") : url, l11l11l1_ok_ (u"ࠬࡶࡡࡨࡧࠪࢆ"):l111lll11l1_ok_,l11l11l1_ok_ (u"࠭࡭ࡪࡰࡩࡳࠬࢇ"):str(infoLabels)})
    isFolder = infoLabels.get(l11l11l1_ok_ (u"ࠧࡪࡵࡉࡳࡱࡪࡥࡳࠩ࢈"),False)
    if isFolder and infoLabels.get(l11l11l1_ok_ (u"ࠨࡻࡨࡥࡷ࠭ࢉ"),False):
        name += l11l11l1_ok_ (u"ࠩࠣࠬࠪࡹࠩࠨࢊ")%infoLabels.get(l11l11l1_ok_ (u"ࠪࡽࡪࡧࡲࠨࢋ"))
    l1llll11l11l1_ok_ = xbmcgui.ListItem(name)
    l1ll11ll11l1_ok_=[l11l11l1_ok_ (u"ࠫࡹ࡮ࡵ࡮ࡤࠪࢌ"),l11l11l1_ok_ (u"ࠬࡶ࡯ࡴࡶࡨࡶࠬࢍ"),l11l11l1_ok_ (u"࠭ࡢࡢࡰࡱࡩࡷ࠭ࢎ"),l11l11l1_ok_ (u"ࠧࡧࡣࡱࡥࡷࡺࠧ࢏"),l11l11l1_ok_ (u"ࠨࡥ࡯ࡩࡦࡸࡡࡳࡶࠪ࢐"),l11l11l1_ok_ (u"ࠩࡦࡰࡪࡧࡲ࡭ࡱࡪࡳࠬ࢑"),l11l11l1_ok_ (u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭࢒"),l11l11l1_ok_ (u"ࠫ࡮ࡩ࡯࡯ࠩ࢓")]
    l1lll1ll11l1_ok_ = dict(zip(l1ll11ll11l1_ok_,[infoLabels.get(x,l1l1111l11l1_ok_) for x in l1ll11ll11l1_ok_]))
    l1lll1ll11l1_ok_[l11l11l1_ok_ (u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨ࢔")] = fanart if fanart else l1lll1ll11l1_ok_[l11l11l1_ok_ (u"࠭࡬ࡢࡰࡧࡷࡨࡧࡰࡦࠩ࢕")]
    l1llll11l11l1_ok_.setArt(l1lll1ll11l1_ok_)
    l1llll11l11l1_ok_.setInfo(type=l11l11l1_ok_ (u"ࠢࡷ࡫ࡧࡩࡴࠨ࢖"), infoLabels=infoLabels)
    if IsPlayable and not isFolder:
        l1llll11l11l1_ok_.setProperty(l11l11l1_ok_ (u"ࠨࡋࡶࡔࡱࡧࡹࡢࡤ࡯ࡩࠬࢗ"), l11l11l1_ok_ (u"ࠩࡷࡶࡺ࡫ࠧ࢘"))
    ok = xbmcplugin.addDirectoryItem(handle=l1lll1l1l11l1_ok_, url=u, listitem=l1llll11l11l1_ok_,isFolder=isFolder,totalItems=l1llll1ll11l1_ok_)
    xbmcplugin.addSortMethod(l1lll1l1l11l1_ok_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l11l11l1_ok_ (u"ࠥࠩࡗ࠲࡛ࠠࠦ࠯ࠤࠪࡖ࢙ࠢ"))
    return ok
def l1111l1l11l1_ok_(name,ex_link=None, l111lll11l1_ok_=1, mode=l11l11l1_ok_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵ࢚ࠫ"),iconImage=l11l11l1_ok_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹࡌ࡯࡭ࡦࡨࡶ࠳ࡶ࡮ࡨ࢛ࠩ"), infoLabels={}, fanart=l1l11llll11l1_ok_,contextmenu=None):
    url = l1ll111l11l1_ok_({l11l11l1_ok_ (u"࠭࡭ࡰࡦࡨࠫ࢜"): mode, l11l11l1_ok_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫ࢝"): name, l11l11l1_ok_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩ࢞") : ex_link, l11l11l1_ok_ (u"ࠩࡳࡥ࡬࡫ࠧ࢟") : l111lll11l1_ok_})
    l1111lll11l1_ok_ = xbmcgui.ListItem(name)
    if infoLabels:
        l1111lll11l1_ok_.setInfo(type=l11l11l1_ok_ (u"ࠥࡺ࡮ࡪࡥࡰࠤࢠ"), infoLabels=infoLabels)
    l1ll11ll11l1_ok_=[l11l11l1_ok_ (u"ࠫࡹ࡮ࡵ࡮ࡤࠪࢡ"),l11l11l1_ok_ (u"ࠬࡶ࡯ࡴࡶࡨࡶࠬࢢ"),l11l11l1_ok_ (u"࠭ࡢࡢࡰࡱࡩࡷ࠭ࢣ"),l11l11l1_ok_ (u"ࠧࡤ࡮ࡨࡥࡷࡧࡲࡵࠩࢤ"),l11l11l1_ok_ (u"ࠨࡥ࡯ࡩࡦࡸ࡬ࡰࡩࡲࠫࢥ"),l11l11l1_ok_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬࢦ"),l11l11l1_ok_ (u"ࠪ࡭ࡨࡵ࡮ࠨࢧ")]
    l1lll1ll11l1_ok_ = dict(zip(l1ll11ll11l1_ok_,[infoLabels.get(x,iconImage) for x in l1ll11ll11l1_ok_]))
    l1lll1ll11l1_ok_[l11l11l1_ok_ (u"ࠫࡱࡧ࡮ࡥࡵࡦࡥࡵ࡫ࠧࢨ")] = fanart if fanart else l1lll1ll11l1_ok_[l11l11l1_ok_ (u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨࢩ")]
    l1111lll11l1_ok_.setArt(l1lll1ll11l1_ok_)
    if contextmenu:
        l11l111l11l1_ok_=contextmenu
        l1111lll11l1_ok_.addContextMenuItems(l11l111l11l1_ok_, replaceItems=True)
    else:
        l11l111l11l1_ok_ = []
        l11l111l11l1_ok_.append((l11l11l1_ok_ (u"࠭ࡉ࡯ࡨࡲࡶࡲࡧࡣ࡫ࡣࠪࢪ"), l11l11l1_ok_ (u"࡙ࠧࡄࡐࡇ࠳ࡇࡣࡵ࡫ࡲࡲ࠭ࡏ࡮ࡧࡱࠬࠫࢫ")),)
        l1111lll11l1_ok_.addContextMenuItems(l11l111l11l1_ok_, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=l1lll1l1l11l1_ok_, url=url,listitem=l1111lll11l1_ok_, isFolder=True)
    xbmcplugin.addSortMethod(l1lll1l1l11l1_ok_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l11l11l1_ok_ (u"ࠣࠧࡕ࠰࡙ࠥࠫ࠭ࠢࠨࡔࠧࢬ"))
def l1ll1llll11l1_ok_(name, url=l11l11l1_ok_ (u"ࠩࠪࢭ"), mode=l11l11l1_ok_ (u"ࠪࠫࢮ"), l1l1111l11l1_ok_=None, fanart=l1l11llll11l1_ok_):
    u = l1ll111l11l1_ok_({l11l11l1_ok_ (u"ࠫࡲࡵࡤࡦࠩࢯ"): mode, l11l11l1_ok_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࡳࡧ࡭ࡦࠩࢰ"): name, l11l11l1_ok_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧࢱ") : url, l11l11l1_ok_ (u"ࠧࡱࡣࡪࡩࠬࢲ"):1})
    l1llll11l11l1_ok_ = xbmcgui.ListItem(name, iconImage=l1l1111l11l1_ok_, thumbnailImage=l1l1111l11l1_ok_)
    l1llll11l11l1_ok_.setProperty(l11l11l1_ok_ (u"ࠨࡋࡶࡔࡱࡧࡹࡢࡤ࡯ࡩࠬࢳ"), l11l11l1_ok_ (u"ࠩࡩࡥࡱࡹࡥࠨࢴ"))
    if fanart:
        l1llll11l11l1_ok_.setProperty(l11l11l1_ok_ (u"ࠪࡪࡦࡴࡡࡳࡶࡢ࡭ࡲࡧࡧࡦࠩࢵ"),fanart)
    ok = xbmcplugin.addDirectoryItem(handle=l1lll1l1l11l1_ok_, url=u, listitem=l1llll11l11l1_ok_,isFolder=False)
    return ok
def l111llll11l1_ok_(l1l11111l11l1_ok_):
    l1l1ll1ll11l1_ok_ = {}
    for k, v in l1l11111l11l1_ok_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l11l11l1_ok_ (u"ࠫࡺࡺࡦ࠹ࠩࢶ"))
        elif isinstance(v, str):
            v.decode(l11l11l1_ok_ (u"ࠬࡻࡴࡧ࠺ࠪࢷ"))
        l1l1ll1ll11l1_ok_[k] = v
    return l1l1ll1ll11l1_ok_
def l1ll111l11l1_ok_(query):
    return l111l1ll11l1_ok_ + l11l11l1_ok_ (u"࠭࠿ࠨࢸ") + urllib.urlencode(l111llll11l1_ok_(query))
class l1l1l11l1_ok_():
    @staticmethod
    def root():
        l1111l1l11l1_ok_(name=l11l11l1_ok_ (u"ࠧࡊࡰࡩࡳࡷࡳࡡࡤ࡬ࡤࠫࢹ"),mode=l11l11l1_ok_ (u"ࠨࡡ࡬ࡲ࡫ࡵ࡟ࠨࢺ"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l11l11l1_ok_ (u"ࠩࡳࡥࡹ࡮ࠧࢻ")))+l11l11l1_ok_ (u"ࠪ࠳࡮ࡩ࡯࡯࠰ࡳࡲ࡬࠭ࢼ"),infoLabels={})
        l1111l1l11l1_ok_(name=l11l11l1_ok_ (u"ࠫࡠࡈ࡝ࡇ࡫࡯ࡱࡾࡡ࠯ࡃ࡟ࠣࠫࢽ"),mode=l11l11l1_ok_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭ࢾ"),ex_link=l11l11l1_ok_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡰࡲࡨࡲࡰࡧࡴࡢ࡮ࡲ࡫࠳ࡩ࡯࡮࠱ࡩ࡭ࡱࡳࡹ࠰ࠩࢿ"))
        l1111l1l11l1_ok_(name=l11l11l1_ok_ (u"ࠧࠡࠢࡊࡥࡹࡻ࡮ࡦ࡭ࠪࣀ"),mode=l11l11l1_ok_ (u"ࠨ࡭ࡤࡸࡪ࡭࡯ࡳ࡫ࡨࠫࣁ"),ex_link=None)
        l1111l1l11l1_ok_(name=l11l11l1_ok_ (u"ࠩࠣࠤࡗࡵ࡫ࠨࣂ"),mode=l11l11l1_ok_ (u"ࠪࡶࡴࡱࠧࣃ"),ex_link=None)
        l1111l1l11l1_ok_(name=l11l11l1_ok_ (u"ࠫࡠࡈ࡝ࡔࡧࡵ࡭ࡦࡲࡥ࡜࠱ࡅࡡࠬࣄ"),mode=l11l11l1_ok_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭ࣅ"),ex_link=l11l11l1_ok_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡰࡲࡨࡲࡰࡧࡴࡢ࡮ࡲ࡫࠳ࡩ࡯࡮࠱ࡶࡩࡷ࡯ࡡ࡭ࡧ࠲ࠫࣆ"))
        l1111l1l11l1_ok_(name=l11l11l1_ok_ (u"ࠧࡕࡴࡨࡲࡩࡿࠠࡇ࡫࡯ࡱࡾ࠭ࣇ"),mode=l11l11l1_ok_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࣈ"),ex_link=l11l11l1_ok_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡳࡵ࡫࡮࡬ࡣࡷࡥࡱࡵࡧ࠯ࡥࡲࡱ࠴ࡺࡲࡦࡰࡧࡽ࠴ࡅࡧࡦࡶࡀࡱࡴࡼࡩࡦࡵࠪࣉ"))
        l1111l1l11l1_ok_(name=l11l11l1_ok_ (u"ࠪࡘࡷ࡫࡮ࡥࡻࠣࡗࡪࡸࡩࡢ࡮ࡨࠫ࣊"),mode=l11l11l1_ok_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬ࣋"),ex_link=l11l11l1_ok_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡯ࡱࡧࡱ࡯ࡦࡺࡡ࡭ࡱࡪ࠲ࡨࡵ࡭࠰ࡶࡵࡩࡳࡪࡹ࠰ࡁࡪࡩࡹࡃࡴࡷࠩ࣌"))
        l1111l1l11l1_ok_(name=l11l11l1_ok_ (u"࠭ࡒࡢࡰ࡮࡭ࡳ࡭ࠠࡇ࡫࡯ࡱࡾ࠭࣍"),mode=l11l11l1_ok_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ࣎"),ex_link=l11l11l1_ok_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡲࡴࡪࡴ࡫ࡢࡶࡤࡰࡴ࡭࠮ࡤࡱࡰ࠳ࡷࡧ࡮࡬࡫ࡱ࡫࠴ࡅࡧࡦࡶࡀࡱࡴࡼࡩࡦࡵ࣏ࠪ"))
        l1111l1l11l1_ok_(name=l11l11l1_ok_ (u"ࠩࡕࡥࡳࡱࡩ࡯ࡩࠣࡗࡪࡸࡩࡢ࡮ࡨ࣐ࠫ"),mode=l11l11l1_ok_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷ࣑ࠫ"),ex_link=l11l11l1_ok_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡵࡰࡦࡰ࡮ࡥࡹࡧ࡬ࡰࡩ࠱ࡧࡴࡳ࠯ࡳࡣࡱ࡯࡮ࡴࡧ࠰ࡁࡪࡩࡹࡃࡴࡷ࣒ࠩ"))
        l1111l1l11l1_ok_(name=l11l11l1_ok_ (u"࡙ࠬࡺࡶ࡭ࡤ࡮࣓ࠬ"),mode=l11l11l1_ok_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭ࣔ"),ex_link=None)
        xbmcplugin.endOfDirectory(l1lll1l1l11l1_ok_)
    @staticmethod
    def info():
        l11lll1l11l1_ok_.__myinfo__.go(sys.argv)
        xbmcplugin.endOfDirectory(l1lll1l1l11l1_ok_)
    @staticmethod
    def content(ex_link):
        from l11ll1ll11l1_ok_ import l1l1l1l1l11l1_ok_
        l1llllll11l1_ok_,l1l1lllll11l1_ok_,l1l1l1lll11l1_ok_ = l1l1l1l1l11l1_ok_().l1l1lll1l11l1_ok_(ex_link)
        l1l11l1l11l1_ok_=l11l11l1_ok_ (u"ࠧࡠࡡࡳࡥ࡬࡫࡟ࡠ࠼ࡦࡳࡳࡺࡥ࡯ࡶࠪࣕ")
        if l1l1l1lll11l1_ok_[0]:
            l1ll1ll1l11l1_ok_(name=l11l11l1_ok_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣ࠼࠽ࠢࡳࡳࡵࡸࡺࡦࡦࡱ࡭ࡦࠦࡳࡵࡴࡲࡲࡦࠦ࠼࠽࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࣖ"), url=l1l1l1lll11l1_ok_[0], mode=l1l11l1l11l1_ok_, IsPlayable=False)
        for f in l1llllll11l1_ok_:
            l1ll1ll1l11l1_ok_(name=f.get(l11l11l1_ok_ (u"ࠩࡷ࡭ࡹࡲࡥࠨࣗ")), url=f.get(l11l11l1_ok_ (u"ࠪ࡬ࡷ࡫ࡦࠨࣘ")), mode=l11l11l1_ok_ (u"ࠫࡵࡲࡡࡺࡑࡳࡩࡳࡑࡡࡵࡣ࡯ࡳ࡬࠭ࣙ"), l1l1111l11l1_ok_=f.get(l11l11l1_ok_ (u"ࠬ࡯࡭ࡨࠩࣚ")), infoLabels=f, IsPlayable=True)
        for f in l1l1lllll11l1_ok_:
            l1111l1l11l1_ok_(f.get(l11l11l1_ok_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࣛ")),f.get(l11l11l1_ok_ (u"ࠧࡩࡴࡨࡪࠬࣜ")), l111lll11l1_ok_=1, mode=l11l11l1_ok_ (u"ࠨࡵࡨࡶ࡮ࡧ࡬ࡦࡡࡶࡩࡦࡹ࡯࡯ࡵࠪࣝ"),iconImage=f.get(l11l11l1_ok_ (u"ࠩ࡬ࡱ࡬࠭ࣞ")), infoLabels=f)
        if l1l1l1lll11l1_ok_[1]:
            l1ll1ll1l11l1_ok_(name=l11l11l1_ok_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞ࡀࡁࠤࡳࡧࡳࡵछࡳࡲࡦࠦࡳࡵࡴࡲࡲࡦࠦ࠾࠿࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࣟ"), url=l1l1l1lll11l1_ok_[1], mode=l1l11l1l11l1_ok_, IsPlayable=False)
        xbmcplugin.setContent(l1lll1l1l11l1_ok_, l11l11l1_ok_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫ࣠"))
        xbmcplugin.endOfDirectory(l1lll1l1l11l1_ok_)
    @staticmethod
    def l11l11l11l1_ok_(ex_link=l11l11l1_ok_ (u"ࠬ࠭࣡")):
        from l11ll1ll11l1_ok_ import l1l1l1l1l11l1_ok_
        out = l1l1l1l1l11l1_ok_().l1l11l11l11l1_ok_()
        for l1l1ll1l11l1_ok_ in out:
            l1111l1l11l1_ok_(name=l1l1ll1l11l1_ok_.get(l11l11l1_ok_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ࣢")),mode=l11l11l1_ok_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨࣣ"),ex_link=l1l1ll1l11l1_ok_.get(l11l11l1_ok_ (u"ࠨࡪࡵࡩ࡫࠭ࣤ")))
        xbmcplugin.endOfDirectory(l1lll1l1l11l1_ok_)
    @staticmethod
    def l1l11l1_ok_(ex_link=l11l11l1_ok_ (u"ࠩࠪࣥ")):
        from l11ll1ll11l1_ok_ import l1l1l1l1l11l1_ok_
        out = l1l1l1l1l11l1_ok_().l1lllll1l11l1_ok_()
        for l1l1ll1l11l1_ok_ in out:
            l1111l1l11l1_ok_(name=l1l1ll1l11l1_ok_.get(l11l11l1_ok_ (u"ࠪࡸ࡮ࡺ࡬ࡦࣦࠩ")),mode=l11l11l1_ok_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࣧ"),ex_link=l1l1ll1l11l1_ok_.get(l11l11l1_ok_ (u"ࠬ࡮ࡲࡦࡨࠪࣨ")))
        xbmcplugin.endOfDirectory(l1lll1l1l11l1_ok_)
    @staticmethod
    def l11l1l11l1_ok_(mode,ex_link):
        _1llll1l11l1_ok_=mode.split(l11l11l1_ok_ (u"ࠨ࠺ࣩࠣ"))[-1]
        url = l1ll111l11l1_ok_({l11l11l1_ok_ (u"ࠧ࡮ࡱࡧࡩࠬ࣪"): _1llll1l11l1_ok_, l11l11l1_ok_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬ࣫"): l11l11l1_ok_ (u"ࠩࠪ࣬"), l11l11l1_ok_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮࣭ࠫ") : ex_link })
        xbmc.executebuiltin(l11l11l1_ok_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠮ࠥࡴ࣮ࠫࠪ")% url)
    @staticmethod
    def l1lllll11l1_ok_(mode,ex_link):
        from l1ll1111l11l1_ok_ import l1l11ll1l11l1_ok_
        l1l111l1l11l1_ok_=mode.split(l11l11l1_ok_ (u"ࠧࡀ࣯ࠢ"))[-1] if l11l11l1_ok_ (u"࠭࠺ࠨࣰ") in mode else l11l11l1_ok_ (u"ࠧࠨࣱ")
        if l1l111l1l11l1_ok_ == l11l11l1_ok_ (u"ࠨࣲࠩ"):
            l1111l1l11l1_ok_(l11l11l1_ok_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢ࡯࡭࡬࡮ࡴࡨࡴࡨࡩࡳࡣࡎࡰࡹࡨࠤࡘࢀࡵ࡬ࡣࡱ࡭ࡪࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࣳ"),ex_link=l11l11l1_ok_ (u"ࠪࠫࣴ"),mode=l11l11l1_ok_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫࠾ࡳ࡫ࡷࠨࣵ"))
            l1l1l111l11l1_ok_ = l1l11ll1l11l1_ok_().l1lllllll11l1_ok_()
            if not l1l1l111l11l1_ok_ == [l11l11l1_ok_ (u"ࣶࠬ࠭")]:
                for entry in l1l1l111l11l1_ok_:
                    contextmenu = []
                    contextmenu.append((l11l11l1_ok_ (u"ࡻࠧࡖࡵࡸࡲࠬࣷ"), l11l11l1_ok_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡔࡨࡪࡷ࡫ࡳࡩࠪࠨࡷ࠮࠭ࣸ")% l1ll111l11l1_ok_({l11l11l1_ok_ (u"ࠨ࡯ࡲࡨࡪࣹ࠭"): l11l11l1_ok_ (u"ࠩࡶࡩࡦࡸࡣࡩ࠼ࡧࡩࡱࡕ࡮ࡦࣺࠩ"), l11l11l1_ok_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫࣻ") : entry})),)
                    contextmenu.append((l11l11l1_ok_ (u"ࡹ࡛ࠬࡳࡶࡰࠣࡧࡦैࡡࠡࡪ࡬ࡷࡹࡵࡲࡪࡧࠪࣼ"), l11l11l1_ok_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡕࡱࡦࡤࡸࡪ࠮ࠥࡴࠫࠪࣽ") % l1ll111l11l1_ok_({l11l11l1_ok_ (u"࠭࡭ࡰࡦࡨࠫࣾ"): l11l11l1_ok_ (u"ࠧࡴࡧࡤࡶࡨ࡮࠺ࡥࡧ࡯ࡅࡱࡲࠧࣿ")})),)
                    l1111l1l11l1_ok_(name=entry, ex_link=entry.replace(l11l11l1_ok_ (u"ࠨࠢࠪऀ"),l11l11l1_ok_ (u"ࠩ࠮ࠫँ")), mode=l11l11l1_ok_ (u"ࠪࡷࡪࡧࡲࡤࡪ࠽ࡲࡪࡽࠧं"), fanart=None, contextmenu=contextmenu)
            xbmcplugin.endOfDirectory(l1lll1l1l11l1_ok_)
        elif l1l111l1l11l1_ok_ ==l11l11l1_ok_ (u"ࠫࡳ࡫ࡷࠨः"):
            if not ex_link:
                l1l11l1ll11l1_ok_ = l1ll11l1_ok_.input(l11l11l1_ok_ (u"ࡺ࠭ࡓࡻࡷ࡮ࡥ࡯࠲ࠠࡑࡱࡧࡥ࡯ࠦࡴࡺࡶࡸॆࠥ࡬ࡩ࡭࡯ࡸࠫऄ"), type=xbmcgui.INPUT_ALPHANUM)
                if l1l11l1ll11l1_ok_: l1l11ll1l11l1_ok_().l1ll11lll11l1_ok_(l1l11l1ll11l1_ok_)
            else:
                l1l11l1ll11l1_ok_ = ex_link
            if l1l11l1ll11l1_ok_:
                from l11ll1ll11l1_ok_ import l1l1l1l1l11l1_ok_
                l1llllll11l1_ok_,l1l1lllll11l1_ok_,l1l1l1lll11l1_ok_ = l1l1l1l1l11l1_ok_().l1l1lll1l11l1_ok_(l11l11l1_ok_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡰࡲࡨࡲࡰࡧࡴࡢ࡮ࡲ࡫࠳ࡩ࡯࡮࠱ࡂࡷࡂ࠭अ")+l1l11l1ll11l1_ok_.replace(l11l11l1_ok_ (u"ࠧࠡࠩआ"),l11l11l1_ok_ (u"ࠨ࠭ࠪइ")))
                for f in l1llllll11l1_ok_: l1ll1ll1l11l1_ok_(name=f.get(l11l11l1_ok_ (u"ࠩࡷ࡭ࡹࡲࡥࠨई")), url=f.get(l11l11l1_ok_ (u"ࠪ࡬ࡷ࡫ࡦࠨउ")), mode=l11l11l1_ok_ (u"ࠫࡵࡲࡡࡺࡑࡳࡩࡳࡑࡡࡵࡣ࡯ࡳ࡬࠭ऊ"), l1l1111l11l1_ok_=f.get(l11l11l1_ok_ (u"ࠬ࡯࡭ࡨࠩऋ")), infoLabels=f, IsPlayable=True)
                for f in l1l1lllll11l1_ok_: l1111l1l11l1_ok_(f.get(l11l11l1_ok_ (u"࠭ࡴࡪࡶ࡯ࡩࠬऌ")),f.get(l11l11l1_ok_ (u"ࠧࡩࡴࡨࡪࠬऍ")), l111lll11l1_ok_=1, mode=l11l11l1_ok_ (u"ࠨࡵࡨࡶ࡮ࡧ࡬ࡦࡡࡶࡩࡦࡹ࡯࡯ࡵࠪऎ"),iconImage=f.get(l11l11l1_ok_ (u"ࠩ࡬ࡱ࡬࠭ए")), infoLabels=f)
            xbmcplugin.endOfDirectory(l1lll1l1l11l1_ok_)
        elif l1l111l1l11l1_ok_ ==l11l11l1_ok_ (u"ࠪࡨࡪࡲࡏ࡯ࡧࠪऐ"):
            l1l11ll1l11l1_ok_().l11l11ll11l1_ok_(ex_link)
            xbmc.executebuiltin(l11l11l1_ok_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠮ࠥࡴࠫࠪऑ")%  l1ll111l11l1_ok_({l11l11l1_ok_ (u"ࠬࡳ࡯ࡥࡧࠪऒ"): l11l11l1_ok_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭ओ")}))
        elif l1l111l1l11l1_ok_ ==l11l11l1_ok_ (u"ࠧࡥࡧ࡯ࡅࡱࡲࠧऔ"):
            l1l11ll1l11l1_ok_().l1l1llll11l1_ok_()
            xbmc.executebuiltin(l11l11l1_ok_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠫࠩࡸ࠯ࠧक")%  l1ll111l11l1_ok_({l11l11l1_ok_ (u"ࠩࡰࡳࡩ࡫ࠧख"): l11l11l1_ok_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪग")}))
        xbmcplugin.setContent(l1lll1l1l11l1_ok_, l11l11l1_ok_ (u"ࠫࡲࡵࡶࡪࡧࡶࠫघ"))
    @staticmethod
    def l1lll1l11l1_ok_(ex_link):
        from l11ll1ll11l1_ok_ import l1l1l1l1l11l1_ok_
        l1lll1lll11l1_ok_ = l1l1l1l1l11l1_ok_().l1ll1l1l11l1_ok_(ex_link)
        l1ll11l1l11l1_ok_=l11l11l1_ok_ (u"ࠬ࠭ङ")
        if len(l1lll1lll11l1_ok_)>0:
            l1l1l11l11l1_ok_ = xbmcgui.Dialog().select(l11l11l1_ok_ (u"ࠨࡗࡺࡤࣶࡶࠧच"), [ x.get(l11l11l1_ok_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭छ")) for x in l1lll1lll11l1_ok_])
            if l1l1l11l11l1_ok_>-1:
                l1ll11l1l11l1_ok_ = l1lll1lll11l1_ok_[l1l1l11l11l1_ok_].get(l11l11l1_ok_ (u"ࠨࡪࡵࡩ࡫࠭ज"))
                if l1lll1lll11l1_ok_[l1l1l11l11l1_ok_].get(l11l11l1_ok_ (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫझ")) == False:
                    l1ll11l1l11l1_ok_ = l1l1l1l1l11l1_ok_().l11lllll11l1_ok_(l1ll11l1l11l1_ok_)
        if l1ll11l1l11l1_ok_:
            try:
                import urlresolver
                l1ll1l11l11l1_ok_ = urlresolver.resolve(l1ll11l1l11l1_ok_)
            except Exception,e:
                l1ll1l11l11l1_ok_=l11l11l1_ok_ (u"ࠪࠫञ")
            if l1ll1l11l11l1_ok_:
                xbmcplugin.setResolvedUrl(l1lll1l1l11l1_ok_, True, xbmcgui.ListItem(path=l1ll1l11l11l1_ok_))
            else:
                xbmcplugin.setResolvedUrl(l1lll1l1l11l1_ok_, False, xbmcgui.ListItem(path=l11l11l1_ok_ (u"ࠫࠬट")))
        else:
            l1ll11l1_ok_.notification(l1lll11l11l1_ok_, l11l11l1_ok_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡸࡥࡥ࡟࡞ࡆࡢࠦࡂࡳࡣ࡮ࠤॿࡸࣳࡥࡧॅࠤࡠ࠵ࡂ࡞࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪठ") , xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l11l11l1_ok_ (u"࠭ࡰࡢࡶ࡫ࠫड")))+l11l11l1_ok_ (u"ࠧ࠰࡫ࡦࡳࡳ࠴ࡰ࡯ࡩࠪढ"), 5000, False)
    @staticmethod
    def l1ll1ll11l1_ok_(ex_link):
        from l11ll1ll11l1_ok_ import l1l1l1l1l11l1_ok_
        out = l1l1l1l1l11l1_ok_().l1lll11ll11l1_ok_(ex_link)
        l1ll111ll11l1_ok_ = l1l1l1l1l11l1_ok_().l1l1l11ll11l1_ok_(out)
        for l1l11lll11l1_ok_ in sorted(l1ll111ll11l1_ok_.keys()):
            l1111l1l11l1_ok_(name=l1l11lll11l1_ok_, ex_link=urllib.quote(str(l1ll111ll11l1_ok_[l1l11lll11l1_ok_])), mode=l11l11l1_ok_ (u"ࠨࡵࡨࡶ࡮ࡧ࡬ࡦࡡࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫण"))
        xbmcplugin.setContent(l1lll1l1l11l1_ok_, l11l11l1_ok_ (u"ࠩࡷࡺࡸ࡮࡯ࡸࡵࠪत"))
        xbmcplugin.endOfDirectory(l1lll1l1l11l1_ok_)
    @staticmethod
    def l11ll1l11l1_ok_(ex_link):
        l1l1l1ll11l1_ok_ = eval(urllib.unquote(ex_link))
        for f in l1l1l1ll11l1_ok_:
            l1ll1ll1l11l1_ok_(name=f.get(l11l11l1_ok_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩथ")), url=f.get(l11l11l1_ok_ (u"ࠫ࡭ࡸࡥࡧࠩद")), mode=l11l11l1_ok_ (u"ࠬࡶ࡬ࡢࡻࡒࡴࡪࡴࡋࡢࡶࡤࡰࡴ࡭ࠧध"), l1l1111l11l1_ok_=f.get(l11l11l1_ok_ (u"࠭ࡩ࡮ࡩࠪन")), infoLabels=f, IsPlayable=True)
        xbmcplugin.setContent(l1lll1l1l11l1_ok_, l11l11l1_ok_ (u"ࠧࡦࡲ࡬ࡷࡴࡪࡥࡴࠩऩ"))
        xbmcplugin.endOfDirectory(l1lll1l1l11l1_ok_)
