# -*- coding: utf-8 -*-
import sys
l1l11l11l1_ok_ = sys.version_info [0] == 2
l1l1lll11l1_ok_ = 2048
l11lll11l1_ok_ = 7
def l11l11l1_ok_ (keyedStringLiteral):
	global l11l1ll11l1_ok_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l11l11l1_ok_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l1lll11l1_ok_ - (charIndex + stringNr) % l11lll11l1_ok_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l1lll11l1_ok_ - (charIndex + stringNr) % l11lll11l1_ok_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os,json,base64
import cookielib
from urlparse import urlparse,urljoin
l11l1llll11l1_ok_ = 15
l1llll111l11l1_ok_=l11l11l1_ok_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠻࠴࠱࠼࡚ࠢ࡭ࡳ࠼࠴࠼ࠢࡻ࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠻࠷࠮࠱࠰࠶࠵࠻࠹࠮࠲࠲࠳ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫप")
l1111l11l11l1_ok_=l11l11l1_ok_ (u"ࡴࠪࠫफ")
class l1llll1lll11l1_ok_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
def l111l1l1l11l1_ok_(url,data=None):
    l11ll1l1l11l1_ok_ = cookielib.LWPCookieJar()
    if data:
        opener = urllib2.build_opener(l1llll1lll11l1_ok_, urllib2.HTTPCookieProcessor(l11ll1l1l11l1_ok_))
    else:
        opener = urllib2.build_opener( urllib2.HTTPCookieProcessor(l11ll1l1l11l1_ok_))
    opener.addheaders = [(l11l11l1_ok_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧब"), l1llll111l11l1_ok_)]
    try:
        response = opener.open(url,data,l11l1llll11l1_ok_)
        result= response.read()
        response.close()
    except:
        result=l11111lll11l1_ok_ = e.read()
    return result
def l111lllll11l1_ok_(l11l1ll1l11l1_ok_):
    if isinstance(l11l1ll1l11l1_ok_, unicode):
        l11l1ll1l11l1_ok_ = l11l1ll1l11l1_ok_.encode(l11l11l1_ok_ (u"ࠫࡺࡺࡦ࠮࠺ࠪभ"))
    l11l1ll1l11l1_ok_ = l11l1ll1l11l1_ok_.replace(l11l11l1_ok_ (u"ࠬࠬ࡬ࡵ࠽ࡥࡶ࠴ࠬࡧࡵ࠽ࠪम"),l11l11l1_ok_ (u"࠭ࠠࠨय"))
    s=l11l11l1_ok_ (u"ࠧࡋ࡫ࡑࡧ࡟ࡉࡳ࠸ࠩर")
    l11l1ll1l11l1_ok_ = re.sub(s.decode(l11l11l1_ok_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨऱ")),l11l11l1_ok_ (u"ࠩࠪल"),l11l1ll1l11l1_ok_)
    l11l1ll1l11l1_ok_ = l11l1ll1l11l1_ok_.replace(l11l11l1_ok_ (u"ࠪࡠࡳ࠭ळ"),l11l11l1_ok_ (u"ࠫࠬऴ")).replace(l11l11l1_ok_ (u"ࠬࡢࡲࠨव"),l11l11l1_ok_ (u"࠭ࠧश"))
    l11l1ll1l11l1_ok_ = l11l1ll1l11l1_ok_.replace(l11l11l1_ok_ (u"ࠧࠧࡰࡥࡷࡵࡁࠧष"),l11l11l1_ok_ (u"ࠨࠩस"))
    l11l1ll1l11l1_ok_ = l11l1ll1l11l1_ok_.replace(l11l11l1_ok_ (u"ࠩࠩࡵࡺࡵࡴ࠼ࠩह"),l11l11l1_ok_ (u"ࠪࠦࠬऺ")).replace(l11l11l1_ok_ (u"ࠫࠫࡧ࡭ࡱ࠽ࡴࡹࡴࡺ࠻ࠨऻ"),l11l11l1_ok_ (u"ࠬࠨ़ࠧ"))
    l11l1ll1l11l1_ok_ = l11l1ll1l11l1_ok_.replace(l11l11l1_ok_ (u"࠭ࠦࡰࡣࡦࡹࡹ࡫࠻ࠨऽ"),l11l11l1_ok_ (u"ࠧࣴࠩा")).replace(l11l11l1_ok_ (u"ࠨࠨࡒࡥࡨࡻࡴࡦ࠽ࠪि"),l11l11l1_ok_ (u"ࠩࣖࠫी"))
    l11l1ll1l11l1_ok_ = l11l1ll1l11l1_ok_.replace(l11l11l1_ok_ (u"ࠪࠪࡦࡳࡰ࠼ࡱࡤࡧࡺࡺࡥ࠼ࠩु"),l11l11l1_ok_ (u"ࠫࣸ࠭ू")).replace(l11l11l1_ok_ (u"ࠬࠬࡡ࡮ࡲ࠾ࡓࡦࡩࡵࡵࡧ࠾ࠫृ"),l11l11l1_ok_ (u"࣓࠭ࠨॄ"))
    l11l1ll1l11l1_ok_ = l11l1ll1l11l1_ok_.replace(l11l11l1_ok_ (u"ࠧࠧࡣࡰࡴࡀ࠭ॅ"),l11l11l1_ok_ (u"ࠨࠨࠪॆ"))
    l11l1ll1l11l1_ok_ = l11l1ll1l11l1_ok_.replace(l11l11l1_ok_ (u"ࠩ࡟ࡹ࠵࠷࠰࠶ࠩे"),l11l11l1_ok_ (u"ࠪउࠬै")).replace(l11l11l1_ok_ (u"ࠫࡡࡻ࠰࠲࠲࠷ࠫॉ"),l11l11l1_ok_ (u"ࠬऊࠧॊ"))
    l11l1ll1l11l1_ok_ = l11l1ll1l11l1_ok_.replace(l11l11l1_ok_ (u"࠭࡜ࡶ࠲࠴࠴࠼࠭ो"),l11l11l1_ok_ (u"ࠧईࠩौ")).replace(l11l11l1_ok_ (u"ࠨ࡞ࡸ࠴࠶࠶࠶ࠨ्"),l11l11l1_ok_ (u"ࠩउࠫॎ"))
    l11l1ll1l11l1_ok_ = l11l1ll1l11l1_ok_.replace(l11l11l1_ok_ (u"ࠪࡠࡺ࠶࠱࠲࠻ࠪॏ"),l11l11l1_ok_ (u"ࠫञ࠭ॐ")).replace(l11l11l1_ok_ (u"ࠬࡢࡵ࠱࠳࠴࠼ࠬ॑"),l11l11l1_ok_ (u"࠭घࠨ॒"))
    l11l1ll1l11l1_ok_ = l11l1ll1l11l1_ok_.replace(l11l11l1_ok_ (u"ࠧ࡝ࡷ࠳࠵࠹࠸ࠧ॓"),l11l11l1_ok_ (u"ࠨॄࠪ॔")).replace(l11l11l1_ok_ (u"ࠩ࡟ࡹ࠵࠷࠴࠲ࠩॕ"),l11l11l1_ok_ (u"ࠪॅࠬॖ"))
    l11l1ll1l11l1_ok_ = l11l1ll1l11l1_ok_.replace(l11l11l1_ok_ (u"ࠫࡡࡻ࠰࠲࠶࠷ࠫॗ"),l11l11l1_ok_ (u"ࠬॊࠧक़")).replace(l11l11l1_ok_ (u"࠭࡜ࡶ࠲࠴࠸࠹࠭ख़"),l11l11l1_ok_ (u"ࠧॄࠩग़"))
    l11l1ll1l11l1_ok_ = l11l1ll1l11l1_ok_.replace(l11l11l1_ok_ (u"ࠨ࡞ࡸ࠴࠵࡬࠳ࠨज़"),l11l11l1_ok_ (u"ࣶࠩࠫड़")).replace(l11l11l1_ok_ (u"ࠪࡠࡺ࠶࠰ࡥ࠵ࠪढ़"),l11l11l1_ok_ (u"ࠫࣘ࠭फ़"))
    l11l1ll1l11l1_ok_ = l11l1ll1l11l1_ok_.replace(l11l11l1_ok_ (u"ࠬࡢࡵ࠱࠳࠸ࡦࠬय़"),l11l11l1_ok_ (u"࠭ज़ࠨॠ")).replace(l11l11l1_ok_ (u"ࠧ࡝ࡷ࠳࠵࠺ࡧࠧॡ"),l11l11l1_ok_ (u"ࠨड़ࠪॢ"))
    l11l1ll1l11l1_ok_ = l11l1ll1l11l1_ok_.replace(l11l11l1_ok_ (u"ࠩ࡟ࡹ࠵࠷࠷ࡢࠩॣ"),l11l11l1_ok_ (u"ࠪॾࠬ।")).replace(l11l11l1_ok_ (u"ࠫࡡࡻ࠰࠲࠹࠼ࠫ॥"),l11l11l1_ok_ (u"ࠬॿࠧ०"))
    l11l1ll1l11l1_ok_ = l11l1ll1l11l1_ok_.replace(l11l11l1_ok_ (u"࠭࡜ࡶ࠲࠴࠻ࡨ࠭१"),l11l11l1_ok_ (u"ࠧॽࠩ२")).replace(l11l11l1_ok_ (u"ࠨ࡞ࡸ࠴࠶࠽ࡢࠨ३"),l11l11l1_ok_ (u"ࠩॾࠫ४"))
    return l11l1ll1l11l1_ok_
url=l11l11l1_ok_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡴࡶࡥ࡯࡭ࡤࡸࡦࡲ࡯ࡨ࠰ࡦࡳࡲ࠵ࡦࡪ࡮ࡰࡽ࠴࠭५")
class l1l1l1l1l11l1_ok_:
    url=l11l11l1_ok_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡵࡰࡦࡰ࡮ࡥࡹࡧ࡬ࡰࡩ࠱ࡧࡴࡳ࠯ࡀࡵࡀ࡭ࡳࡪࡩࡢࡰࡤ࠯࡯ࡵ࡮ࡦࡵࠪ६")
    @staticmethod
    def l1l1lll1l11l1_ok_(url=l11l11l1_ok_ (u"ࠬ࠭७")):
        content = l111l1l1l11l1_ok_(url)
        l1l1lllll11l1_ok_=[]
        l1llllll11l1_ok_=[]
        l1111111l11l1_ok_ = re.compile(l11l11l1_ok_ (u"࠭࠼ࡢࡴࡷ࡭ࡨࡲࡥࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡴࡷ࡭ࡨࡲࡥ࠿ࠩ८"),re.DOTALL).findall(content)
        for item in l1111111l11l1_ok_:
            l111l11ll11l1_ok_=re.findall(l11l11l1_ok_ (u"ࠧ࠽ࡪ࠶ࡂࡡࡹࠪ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡴࡶࡥ࡯࡭ࡤࡸࡦࡲ࡯ࡨ࠰ࡦࡳࡲ࠵࠮ࠫࡁࠬࠦࡃ࠮࠮ࠬࡁࠬࡀ࠴ࡧ࠾ࠨ९"),item)
            year = re.findall(l11l11l1_ok_ (u"ࠨ࠾ࡶࡴࡦࡴ࡛࡟ࡀࡠ࠮ࡃ࠮࡜ࡥࡽ࠷ࢁ࠮ࡂ࠯ࠨ॰"),item)
            l11l111ll11l1_ok_ = re.findall(l11l11l1_ok_ (u"ࠩ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࡠࠨ࡜ࠨ࡟ࠫ࠲࠰ࡅࠩ࡜ࠤ࡟ࠫࡢ࠭ॱ"),item)
            l11ll1lll11l1_ok_ = re.findall(l11l11l1_ok_ (u"ࠪࡀࡸࡶࡡ࡯ࠢࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡧࡴࡴ࠭ࡴࡶࡤࡶ࠷ࠨ࠾࡝ࡵ࠭ࡀ࠴ࡹࡰࡢࡰࡁࠬ࠳࠱࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨॲ"),item,re.DOTALL)
            l11l1l11l11l1_ok_ = re.findall(l11l11l1_ok_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡷࡩࡽࡺ࡯ࠣࡀࠫ࠲࠰ࡅࠩ࠽ࠩॳ"),item,re.DOTALL)
            if l111l11ll11l1_ok_:
                href = l111l11ll11l1_ok_[0][0]
                title= l111lllll11l1_ok_(l111l11ll11l1_ok_[0][1])
                l11l111ll11l1_ok_ = l11l111ll11l1_ok_[0] if l11l111ll11l1_ok_ else l11l11l1_ok_ (u"ࠬ࠭ॴ")
                l11ll1lll11l1_ok_ = l11ll1lll11l1_ok_[0].strip() if l11ll1lll11l1_ok_ else l11l11l1_ok_ (u"࠭ࠧॵ")
                l1l1ll1l11l1_ok_={l11l11l1_ok_ (u"ࠧࡩࡴࡨࡪࠬॶ"):href,
                    l11l11l1_ok_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧॷ"):title,
                    l11l11l1_ok_ (u"ࠩ࡬ࡱ࡬࠭ॸ"):l11l111ll11l1_ok_,
                    l11l11l1_ok_ (u"ࠪࡧࡴࡪࡥࠨॹ"):l11ll1lll11l1_ok_,
                    l11l11l1_ok_ (u"ࠫࡾ࡫ࡡࡳࠩॺ"):year[0] if year else l11l11l1_ok_ (u"ࠬ࠭ॻ"),
                    l11l11l1_ok_ (u"࠭ࡰ࡭ࡱࡷࠫॼ"):l111lllll11l1_ok_(l11l1l11l11l1_ok_[0]).strip() if l11l1l11l11l1_ok_ else l11l11l1_ok_ (u"ࠧࠨॽ")
                }
                if l11l11l1_ok_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡡ࡭ࡧ࠲ࠫॾ") in href:
                    l1l1lllll11l1_ok_.append(l1l1ll1l11l1_ok_)
                else:
                    l1llllll11l1_ok_.append(l1l1ll1l11l1_ok_)
        l11ll111l11l1_ok_ = re.findall(l11l11l1_ok_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀ࡟ࠧࡢࠧ࡞ࠪ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡳࡵ࡫࡮࡬ࡣࡷࡥࡱࡵࡧ࠯ࡥࡲࡱ࠴࠴ࠫࡀࠫ࡞ࠦࡡ࠭࡝࠿࠾ࡶࡴࡦࡴࠠࡤ࡮ࡤࡷࡸࡃࠢࡪࡥࡲࡲ࠲ࡩࡨࡦࡸࡵࡳࡳ࠳࡬ࡦࡨࡷࠦࡃ࠭ॿ"),content)
        l11ll111l11l1_ok_ = l11ll111l11l1_ok_[0] if l11ll111l11l1_ok_ else False
        l111111ll11l1_ok_ = re.findall(l11l11l1_ok_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࡠࠨ࡜ࠨ࡟ࠫ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡴࡶࡥ࡯࡭ࡤࡸࡦࡲ࡯ࡨ࠰ࡦࡳࡲ࠵࠮ࠬࡁࠬ࡟ࠧࡢࠧ࡞ࡀ࠿ࡷࡵࡧ࡮ࠡࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡦࡳࡳ࠳ࡣࡩࡧࡹࡶࡴࡴ࠭ࡳ࡫ࡪ࡬ࡹࠨ࠾ࠨঀ"),content)
        l111111ll11l1_ok_ = l111111ll11l1_ok_[0] if l111111ll11l1_ok_ else False
        return l1llllll11l1_ok_,l1l1lllll11l1_ok_,(l11ll111l11l1_ok_,l111111ll11l1_ok_)
    @staticmethod
    def l1lll11ll11l1_ok_(url=l11l11l1_ok_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡵࡰࡦࡰ࡮ࡥࡹࡧ࡬ࡰࡩ࠱ࡧࡴࡳ࠯ࡴࡧࡵ࡭ࡦࡲࡥ࠰࡯࡬ࡲࡩ࡮ࡵ࡯ࡶࡨࡶ࠴࠭ঁ")):
        if not l11l11l1_ok_ (u"ࠬࡅࡴࡢࡤࡀࡩࡵ࡯ࡳࡰࡦࡨࡷࠬং") in url:
            url +=l11l11l1_ok_ (u"࠭࠿ࡵࡣࡥࡁࡪࡶࡩࡴࡱࡧࡩࡸ࠭ঃ")
        out = []
        content = l111l1l1l11l1_ok_(url)
        l1ll111ll11l1_ok_ = re.findall(l11l11l1_ok_ (u"ࠧ࠽ࡷ࡯ࠤࡨࡲࡡࡴࡵࡀࠦࡪࡶࡩࡴࡱࡧ࡭ࡴࡹࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࠫ঄"),content,re.DOTALL)
        for l1111llll11l1_ok_ in l1ll111ll11l1_ok_:
            l111lll1l11l1_ok_ = re.findall(l11l11l1_ok_ (u"ࠨ࠾࡯࡭ࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩঅ"),l1111llll11l1_ok_,re.DOTALL)
            for l1111lll11l1_ok_ in l111lll1l11l1_ok_:
                l11l111ll11l1_ok_ = re.findall(l11l11l1_ok_ (u"ࠩ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬআ"),l1111lll11l1_ok_)
                l111l111l11l1_ok_ = re.findall(l11l11l1_ok_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡰࡸࡱࡪࡸࡡ࡯ࡦࡲࠦࡃࡢࡳࠫࠪ࡟ࡨ࠰࠯࡜ࡴࠬ࠰ࡠࡸ࠰ࠨ࡝ࡦ࠮࠭ࡡࡹࠪ࠽࠱ࡧ࡭ࡻࡄࠧই"),l1111lll11l1_ok_)
                l111l11ll11l1_ok_ = re.findall(l11l11l1_ok_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨࡩࡶࡷࡴࡸࡀ࠯࠰ࡱࡳࡩࡳࡱࡡࡵࡣ࡯ࡳ࡬࠴ࡣࡰ࡯࠲࠲࠯ࡅࠩࠣࡀࠫ࡟ࡣࡂ࡝ࠬࠫ࠿࠳ࡦࡄࠧঈ"),l1111lll11l1_ok_)
                data = re.findall(l11l11l1_ok_ (u"ࠬࡂࡳࡱࡣࡱࠤࡨࡲࡡࡴࡵࡀࠦࡩࡧࡴࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩউ"),l1111lll11l1_ok_)
                if l111l11ll11l1_ok_:
                    l1llllllll11l1_ok_,l1llll11ll11l1_ok_ = l111l111l11l1_ok_[0] if l111l111l11l1_ok_ else (l11l11l1_ok_ (u"࠭ࠧঊ"),l11l11l1_ok_ (u"ࠧࠨঋ"))
                    l11l111ll11l1_ok_ = l11l111ll11l1_ok_[0] if l11l111ll11l1_ok_ else l11l11l1_ok_ (u"ࠨࠩঌ")
                    out.append({l11l11l1_ok_ (u"ࠩ࡫ࡶࡪ࡬ࠧ঍"):l111l11ll11l1_ok_[0][0],l11l11l1_ok_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ঎"):l111l11ll11l1_ok_[0][1],l11l11l1_ok_ (u"ࠫ࡮ࡳࡧࠨএ"):l11l111ll11l1_ok_,
                        l11l11l1_ok_ (u"ࠬࡹࡥࡢࡵࡲࡲࠬঐ"):int(l1llllllll11l1_ok_),l11l11l1_ok_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࠧ঑"):int(l1llll11ll11l1_ok_)})
        return out
    @staticmethod
    def l1l1l11ll11l1_ok_(out):
        l1l1lllll11l1_ok_={}
        l1ll111ll11l1_ok_ = [x.get(l11l11l1_ok_ (u"ࠧࡴࡧࡤࡷࡴࡴࠧ঒")) for x in out]
        for s in set(l1ll111ll11l1_ok_):
            l1l1lllll11l1_ok_[l11l11l1_ok_ (u"ࠨࡕࡨࡾࡴࡴࠠࠦ࠲࠵ࡨࠬও")%s]=[out[i] for i, j in enumerate(l1ll111ll11l1_ok_) if j == s]
        return l1l1lllll11l1_ok_
    @staticmethod
    def l1l11l11l11l1_ok_():
        content = l111l1l1l11l1_ok_(l11l11l1_ok_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡳࡵ࡫࡮࡬ࡣࡷࡥࡱࡵࡧ࠯ࡥࡲࡱࠬঔ"))
        stuff = re.compile(l11l11l1_ok_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳࡷ࠿࠵࠯ࡰࡲࡨࡲࡰࡧࡴࡢ࡮ࡲ࡫࠳ࡩ࡯࡮࠱ࡪࡥࡹࡻ࡮ࡦ࡭࠲࠲࠰ࡅࠩࠣ࡞ࡶ࠮ࡠࡤ࠾࡞ࠬࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃࡡ࡜ࡴ࡞ࡱࠤࡢ࠰࠼ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠱࡬ࡂࠬক")).findall(content)
        out=[]
        for l1111ll1l11l1_ok_, title, l1llll1l1l11l1_ok_ in stuff:
            out.append({l11l11l1_ok_ (u"ࠦ࡭ࡸࡥࡧࠤখ"):l1111ll1l11l1_ok_,l11l11l1_ok_ (u"ࠧࡺࡩࡵ࡮ࡨࠦগ"):l11l11l1_ok_ (u"ࠨࡻࡾࠢࠫࡿࢂ࠯ࠢঘ").format(title,l1llll1l1l11l1_ok_.replace(l11l11l1_ok_ (u"ࠧࠧࡰࡥࡷࡵࡁࠧঙ"),l11l11l1_ok_ (u"ࠨࠩচ")))})
        return out
    @staticmethod
    def l1lllll1l11l1_ok_():
        content = l111l1l1l11l1_ok_(l11l11l1_ok_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡳࡵ࡫࡮࡬ࡣࡷࡥࡱࡵࡧ࠯ࡥࡲࡱࠬছ"))
        stuff = re.compile(l11l11l1_ok_ (u"ࠪࡀࡱ࡯࠾࡝ࡵ࠭ࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳࡷ࠿࠵࠯ࡰࡲࡨࡲࡰࡧࡴࡢ࡮ࡲ࡫࠳ࡩ࡯࡮࠱ࡵࡳࡰ࠵࠮ࠬࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾࠽࠱࡯࡭ࡃ࠭জ")).findall(content)
        out=[]
        for l1111ll1l11l1_ok_, title, in stuff:
            out.append({l11l11l1_ok_ (u"ࠦ࡭ࡸࡥࡧࠤঝ"):l1111ll1l11l1_ok_,l11l11l1_ok_ (u"ࠧࡺࡩࡵ࡮ࡨࠦঞ"):title})
        return out
    @staticmethod
    def l1ll1l1l11l1_ok_(url):
        if not l11l11l1_ok_ (u"࠭࠿ࡵࡣࡥࡁࡻ࡯ࡤࡦࡱࠩࡴࡱࡧࡹࡦࡴࡀࡳࡵࡺࡩࡰࡰࠪট") in url:
            url+=l11l11l1_ok_ (u"ࠧࡀࡶࡤࡦࡂࡼࡩࡥࡧࡲࠪࡵࡲࡡࡺࡧࡵࡁࡴࡶࡴࡪࡱࡱ࠱࠶࠭ঠ")
        content = l111l1l1l11l1_ok_(url)
        l1lllll1ll11l1_ok_ = re.compile(l11l11l1_ok_ (u"ࠨ࠾ࡸࡰࠥࡩ࡬ࡢࡵࡶࡁࠧࡶ࡬ࡢࡻࡨࡶࡤࡻ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ড"),re.DOTALL).findall(content)
        l111l1lll11l1_ok_=l11l11l1_ok_ (u"ࠩࠪঢ")
        l1llllll1l11l1_ok_=[]
        for l11ll11ll11l1_ok_ in l1lllll1ll11l1_ok_:
            l111ll1ll11l1_ok_ =re.findall(l11l11l1_ok_ (u"ࠪࡀࡦࠦࡣ࡭ࡣࡶࡷࡂࠨࡡࡤࡶ࡬ࡺࡪࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠾࠲ࡰ࡮ࡄࠧণ"),l11ll11ll11l1_ok_)
            if l111ll1ll11l1_ok_ and not l111l1lll11l1_ok_:
                l111l1lll11l1_ok_ = l111ll1ll11l1_ok_[0][1]
            l11l11l1l11l1_ok_ = re.findall(l11l11l1_ok_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠾࠲ࡰ࡮ࡄࠧত"),l11ll11ll11l1_ok_)
            if l11l11l1l11l1_ok_:
                l1llllll1l11l1_ok_.append({l11l11l1_ok_ (u"ࠬ࡮ࡲࡦࡨࠪথ"):l11l11l1l11l1_ok_[0][0],l11l11l1_ok_ (u"࠭ࡴࡪࡶ࡯ࡩࠬদ"):l11l11l1l11l1_ok_[0][1],l11l11l1_ok_ (u"ࠧࡳࡧࡶࡳࡱࡼࡥࡥࠩধ"):False})
        stuff = re.compile(l11l11l1_ok_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠪ࠱࠮ࡄ࠯࠼࠰࡫ࡩࡶࡦࡳࡥ࠿ࠩন"),re.I).findall(content)
        if stuff:
            src = re.findall(l11l11l1_ok_ (u"ࠩࡶࡶࡨࡃ࡛ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝ࠨ঩"),stuff[0],re.I)
            if src:
                l1llllll1l11l1_ok_.append({l11l11l1_ok_ (u"ࠪ࡬ࡷ࡫ࡦࠨপ"):src[0],l11l11l1_ok_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪফ"):l111l1lll11l1_ok_ if l111l1lll11l1_ok_ else l11l11l1_ok_ (u"ࠬࡶ࡬ࡢࡻࡨࡶࠬব"),l11l11l1_ok_ (u"࠭ࡲࡦࡵࡲࡰࡻ࡫ࡤࠨভ"):True})
        return l1llllll1l11l1_ok_
    @staticmethod
    def l11lllll11l1_ok_(url):
        content = l111l1l1l11l1_ok_(url)
        stuff = re.compile(l11l11l1_ok_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠩ࠰࠭ࡃ࠮ࡂ࠯ࡪࡨࡵࡥࡲ࡫࠾ࠨম"),re.I).findall(content)
        if stuff:
            src = re.findall(l11l11l1_ok_ (u"ࠨࡵࡵࡧࡂࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣࠧয"),stuff[0],re.I)
            if src:
                return src[0] if src else l11l11l1_ok_ (u"ࠩࠪর")
        return l11l11l1_ok_ (u"ࠪࠫ঱")
class l1111l1ll11l1_ok_:
    def l11l11lll11l1_ok_(self,url):
        if not url:
            url = l11l11l1_ok_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩল")
        elif url.startswith(l11l11l1_ok_ (u"ࠬ࠵࠯ࠨ঳")):
            url = l11l11l1_ok_ (u"࠭ࡨࡵࡶࡳࠫ঴")+url
        elif url.startswith(l11l11l1_ok_ (u"ࠧ࠰ࠩ঵")):
            url = urljoin(l11l11l1_ok_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡬ࡥࡳ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭শ"),url)
        return url
    @staticmethod
    def l1l1lll1l11l1_ok_(url=l11l11l1_ok_ (u"ࠩࠪষ")):
        if not url:
            url = l11l11l1_ok_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡮ࡧࡵࡦࡪ࡮ࡰ࠲ࡵࡲ࠯ࠨস")
        elif url.startswith(l11l11l1_ok_ (u"ࠫ࠴࠭হ")):
            url = urljoin(l11l11l1_ok_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡰࡢࡰࡨ࡬ࡰࡲ࠴ࡰ࡭࠱ࠪ঺"),url)
        content = l111l1l1l11l1_ok_(url)
        out=[]
        l111ll11l11l1_ok_ = re.compile(l11l11l1_ok_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡮ࡵࡧࡱࡸ࠲࡭ࡲࡪࡦࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ঻"),re.DOTALL).findall(content)
        for show in l111ll11l11l1_ok_:
            l11l1111l11l1_ok_ = re.findall(l11l11l1_ok_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠳ࡸ࡫ࡲࡪࡣ࡯ࡩ࠴࠴ࠪࠪࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ়࠭ࠧ࠭"),show)
            if l11l1111l11l1_ok_:
                l11l111ll11l1_ok_ = l11l1111l11l1_ok_[0][1]
                l11l111ll11l1_ok_ = urljoin(l11l11l1_ok_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡬ࡥࡳ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭ঽ"),l11l111ll11l1_ok_) if not l11l111ll11l1_ok_.startswith(l11l11l1_ok_ (u"ࠩ࡫ࡸࡹࡶࠧা")) else l11l111ll11l1_ok_
                title = l11l1111l11l1_ok_[0][0].replace(l11l11l1_ok_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡣ࡯ࡩ࠴࠭ি"),l11l11l1_ok_ (u"ࠫࠬী")).replace(l11l11l1_ok_ (u"ࠬ࠳ࠧু"),l11l11l1_ok_ (u"࠭ࠠࠨূ")).replace(l11l11l1_ok_ (u"ࠧ࠰ࠩৃ"),l11l11l1_ok_ (u"ࠨࠩৄ")).title()
                out.append({l11l11l1_ok_ (u"ࠩ࡫ࡶࡪ࡬ࠧ৅"):l11l1111l11l1_ok_[0][0],l11l11l1_ok_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ৆"):title,l11l11l1_ok_ (u"ࠫ࡮ࡳࡧࠨে"):l11l111ll11l1_ok_})
        idx = content.find(l11l11l1_ok_ (u"ࠬ࡮࠳࠿ࡕࡨࡶ࡮ࡧ࡬ࡦ࠾࠲࡬࠸ࡄࠧৈ"))
        if idx:
            l1lll1llll11l1_ok_ = re.compile(l11l11l1_ok_ (u"࠭࠼ࡶ࡮ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧ৉"),re.DOTALL).search(content[idx:-1])
            l1lll1llll11l1_ok_ = l1lll1llll11l1_ok_.group(1) if l1lll1llll11l1_ok_ else l11l11l1_ok_ (u"ࠧࠨ৊")
            l1lll1llll11l1_ok_ = re.sub(l11l11l1_ok_ (u"ࡳࠤ࠿ࠥ࠲࠳ࠨ࠯ࡾ࡟ࡷࢁࡢ࡮ࠪࠬࡂ࠱࠲ࡄࠢো"), l11l11l1_ok_ (u"ࠤࠥৌ"), l1lll1llll11l1_ok_)
            l1lllll11l11l1_ok_ = re.compile(l11l11l1_ok_ (u"ࠪࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠳ࡸ࡫ࡲࡪࡣ࡯ࡩ࠴࠴ࠪࡀࠫࠥࡂ࠭ࡡ࡞࠿࡟࠭࠭ࡁ࠵ࡡ࠿࠾࠲ࡰ࡮ࡄ্ࠧ")).findall(l1lll1llll11l1_ok_)
            for href,title in l1lllll11l11l1_ok_:
                out.append({l11l11l1_ok_ (u"ࠫ࡭ࡸࡥࡧࠩৎ"):href,l11l11l1_ok_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ৏"):title})
        return out
    @staticmethod
    def l11111l1l11l1_ok_(url=l11l11l1_ok_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡪࡣࡱࡩ࡭ࡱࡳ࠮ࡱ࡮࠲ࡷࡪࡸࡩࡢ࡮ࡨ࠳ࡩ࡫ࡴࡦ࡭ࡷࡽࡼ࠵ࠧ৐")):
        if not url:
            url = l11l11l1_ok_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡫ࡤࡲࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࠬ৑")
        if url.startswith(l11l11l1_ok_ (u"ࠨ࠱࠲ࠫ৒")):
            url = l11l11l1_ok_ (u"ࠩ࡫ࡸࡹࡶࠧ৓")+url
        if url.startswith(l11l11l1_ok_ (u"ࠪ࠳ࠬ৔")):
            url = urljoin(l11l11l1_ok_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩ৕"),url)
        url += l11l11l1_ok_ (u"ࠬ࠵ࠧ৖") if not url.endswith(l11l11l1_ok_ (u"࠭࠯ࠨৗ")) else l11l11l1_ok_ (u"ࠧࠨ৘")
        content = l111l1l1l11l1_ok_(url)
        out=[]
        l1l1l1ll11l1_ok_ = re.compile(l11l11l1_ok_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺ࠭ࡨࡴ࡬ࡨࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ৙"),re.DOTALL).findall(content)
        for l11l1l1ll11l1_ok_ in l1l1l1ll11l1_ok_:
            l1llllllll11l1_ok_ = re.findall(l11l11l1_ok_ (u"ࠩࡶࡩࡿࡵ࡮࡝ࡵ࠭ࠬࡡࡪࠫࠪࠩ৚"),l11l1l1ll11l1_ok_,re.I)
            l1llllllll11l1_ok_ = l1llllllll11l1_ok_[0] if l1llllllll11l1_ok_ else l11l11l1_ok_ (u"ࠪࠫ৛")
            l1llll11ll11l1_ok_ = re.findall(l11l11l1_ok_ (u"ࠫࡔࡪࡣࡪࡰࡨ࡯ࡡࡹࠪࠩ࡞ࡧ࠯࠮࠭ড়"),l11l1l1ll11l1_ok_,re.I)
            l1llll11ll11l1_ok_ = l1llll11ll11l1_ok_[0] if l1llll11ll11l1_ok_ else l11l11l1_ok_ (u"ࠬ࠭ঢ়")
            href = re.compile(l11l11l1_ok_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪࡶ࡭ࡳ࡭࡬ࡦࡲࡤ࡫ࡪ࠴ࡰࡩࡲ࡟ࡃ࡮ࡪ࠽࡝ࡦ࠮࠭ࠧ࠭৞")).findall(l11l1l1ll11l1_ok_)
            l11l111ll11l1_ok_ = re.findall(l11l11l1_ok_ (u"ࠧ࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪয়"),l11l1l1ll11l1_ok_)
            if href and l1llllllll11l1_ok_ and l1llll11ll11l1_ok_:
                l11l111ll11l1_ok_ = urljoin(l11l11l1_ok_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡬ࡥࡳ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭ৠ"),l11l111ll11l1_ok_[0]) if not l11l111ll11l1_ok_[0].startswith(l11l11l1_ok_ (u"ࠩ࡫ࡸࡹࡶࠧৡ")) else l11l11l1_ok_ (u"ࠪࠫৢ")
                out.append({l11l11l1_ok_ (u"ࠫ࡭ࡸࡥࡧࠩৣ"):url+href[0],l11l11l1_ok_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ৤"):l11l11l1_ok_ (u"࠭ࡓࡦࡼࡲࡲࠥࠫࡳ࠭ࠢࡈࡴ࡮ࢀ࡯ࡥࠢࠨࡷࠬ৥")%(l1llllllll11l1_ok_,l1llll11ll11l1_ok_),l11l11l1_ok_ (u"ࠧࡪ࡯ࡪࠫ০"):l11l111ll11l1_ok_,
                l11l11l1_ok_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࠨ১"):int(l1llllllll11l1_ok_),l11l11l1_ok_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࠪ২"):int(l1llll11ll11l1_ok_)})
        return out
