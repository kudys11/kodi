# -*- coding: utf-8 -*-
import sys
l1lll11_fd_ = sys.version_info [0] == 2
l1ll1l_fd_ = 2048
l1111_fd_ = 7
def l1111l_fd_ (l1_fd_):
	global l1ll1l1_fd_
	l11111l_fd_ = ord (l1_fd_ [-1])
	l1lll1l_fd_ = l1_fd_ [:-1]
	l1ll1_fd_ = l11111l_fd_ % len (l1lll1l_fd_)
	l1l1l_fd_ = l1lll1l_fd_ [:l1ll1_fd_] + l1lll1l_fd_ [l1ll1_fd_:]
	if l1lll11_fd_:
		l1l11ll_fd_ = unicode () .join ([unichr (ord (char) - l1ll1l_fd_ - (l111ll_fd_ + l11111l_fd_) % l1111_fd_) for l111ll_fd_, char in enumerate (l1l1l_fd_)])
	else:
		l1l11ll_fd_ = str () .join ([chr (ord (char) - l1ll1l_fd_ - (l111ll_fd_ + l11111l_fd_) % l1111_fd_) for l111ll_fd_, char in enumerate (l1l1l_fd_)])
	return eval (l1l11ll_fd_)
import sys,re,os,time
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import json, htmlentitydefs
try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
cache = StorageServer.StorageServer(l1111l_fd_ (u"ࠦ࡫ࡸࡥࡦࡦ࡬ࡷࡰࠨࠀ"))
import resources.lib.l11ll1l_fd_ as l11ll1l_fd_
l11lll_fd_        = sys.argv[0]
l1ll11l_fd_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l1llll1l_fd_        = xbmcaddon.Addon()
l1llll11_fd_     = l1llll1l_fd_.getAddonInfo(l1111l_fd_ (u"ࠬ࡯ࡤࠨࠁ"))
l11_fd_       = l1llll1l_fd_.getAddonInfo(l1111l_fd_ (u"࠭࡮ࡢ࡯ࡨࠫࠂ"))
PATH        = l1llll1l_fd_.getAddonInfo(l1111l_fd_ (u"ࠧࡱࡣࡷ࡬ࠬࠃ"))
l1ll111_fd_    = xbmc.translatePath(l1llll1l_fd_.getAddonInfo(l1111l_fd_ (u"ࠨࡲࡵࡳ࡫࡯࡬ࡦࠩࠄ"))).decode(l1111l_fd_ (u"ࠩࡸࡸ࡫࠳࠸ࠨࠅ"))
l11l1ll_fd_   = PATH+l1111l_fd_ (u"ࠪ࠳ࡷ࡫ࡳࡰࡷࡵࡧࡪࡹ࠯ࠨࠆ")
l111l1l_fd_      = None
l1l111_fd_    = os.path.join(l1ll111_fd_,l1111l_fd_ (u"ࠫ࡫ࡧࡶࡰࡴ࡬ࡸࡪࡹ࠮࡫ࡵࡲࡲࠬࠇ"))
def l1ll1ll_fd_(url,data=None):
    req = urllib2.Request(url,data)
    req.add_header(l1111l_fd_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩࠈ"), l1111l_fd_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠺࠸࠯࠲࠱࠶࠺࠼࠴࠯࠻࠺ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫࠉ"))
    response = urllib2.urlopen(req)
    l11llll_fd_ = response.read()
    response.close()
    return l11llll_fd_
def l1l1l1l_fd_(name, url, mode, l1lll11l_fd_=1, l1l11l_fd_=None, infoLabels=False, contextO=[l1111l_fd_ (u"ࠧࡇࡡࡄࡈࡉ࠭ࠊ")], IsPlayable=True,fanart=l111l1l_fd_,l1lllll_fd_=1):
    u = l111_fd_({l1111l_fd_ (u"ࠨ࡯ࡲࡨࡪ࠭ࠋ"): mode, l1111l_fd_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭ࠌ"): name, l1111l_fd_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫࠍ") : url, l1111l_fd_ (u"ࠫࡵࡧࡧࡦࠩࠎ"):l1lll11l_fd_})
    if l1l11l_fd_==None:
        l1l11l_fd_=l1111l_fd_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹࡌ࡯࡭ࡦࡨࡶ࠳ࡶ࡮ࡨࠩࠏ")
    l1llll1_fd_ = xbmcgui.ListItem(name, iconImage=l1l11l_fd_, thumbnailImage=l1l11l_fd_)
    if not infoLabels:
        infoLabels={l1111l_fd_ (u"ࠨࡴࡪࡶ࡯ࡩࠧࠐ"): name}
    l1llll1_fd_.setInfo(type=l1111l_fd_ (u"ࠢࡷ࡫ࡧࡩࡴࠨࠑ"), infoLabels=infoLabels)
    if IsPlayable:
        l1llll1_fd_.setProperty(l1111l_fd_ (u"ࠨࡋࡶࡔࡱࡧࡹࡢࡤ࡯ࡩࠬࠒ"), l1111l_fd_ (u"ࠩࡷࡶࡺ࡫ࠧࠓ"))
    if fanart:
        l1llll1_fd_.setProperty(l1111l_fd_ (u"ࠪࡪࡦࡴࡡࡳࡶࡢ࡭ࡲࡧࡧࡦࠩࠔ"),fanart)
    l1l1ll_fd_ = []
    l1l1ll_fd_.append((l1111l_fd_ (u"ࠫࡎࡴࡦࡰࡴࡰࡥࡨࡰࡡࠨࠕ"), l1111l_fd_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡅࡨࡺࡩࡰࡰࠫࡍࡳ࡬࡯ࠪࠩࠖ")))
    content=urllib.quote_plus(json.dumps(infoLabels))
    if l1111l_fd_ (u"࠭ࡆࡠࡃࡇࡈࠬࠗ") in contextO:
        l1l1ll_fd_.append((l1111l_fd_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡨࡴࡨࡩࡳࡣࡄࡰࡦࡤ࡮ࠥࡪ࡯࡙ࠡࡼࡦࡷࡧ࡮ࡺࡥ࡫࡟࠴ࡉࡏࡍࡑࡕࡡࠬ࠘"), l1111l_fd_ (u"ࠨࡔࡸࡲࡕࡲࡵࡨ࡫ࡱࠬࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴࡁࡰࡳࡩ࡫࠽ࡧࡣࡹࡳࡷ࡯ࡴࡦࡵࡄࡈࡉࠬࡥࡹࡡ࡯࡭ࡳࡱ࠽ࠦࡵࠬࠫ࠙")%(l1llll11_fd_,content)))
    if l1111l_fd_ (u"ࠩࡉࡣࡗࡋࡍࠨࠚ") in contextO:
        l1l1ll_fd_.append((l1111l_fd_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࡖࡵࡸैࠥࢀࠠࡘࡻࡥࡶࡦࡴࡹࡤࡪ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࠛ"), l1111l_fd_ (u"ࠫࡗࡻ࡮ࡑ࡮ࡸ࡫࡮ࡴࠨࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷࡄࡳ࡯ࡥࡧࡀࡪࡦࡼ࡯ࡳ࡫ࡷࡩࡸࡘࡅࡎࠨࡨࡼࡤࡲࡩ࡯࡭ࡀࠩࡸ࠯ࠧࠜ")%(l1llll11_fd_,content)))
    if l1111l_fd_ (u"ࠬࡌ࡟ࡅࡇࡏࠫࠝ") in contextO:
        l1l1ll_fd_.append((l1111l_fd_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠ࡙ࡸࡻॄ࡙ࠡࡶࡾࡾࡹࡴ࡬ࡱ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࠞ"), l1111l_fd_ (u"ࠧࡓࡷࡱࡔࡱࡻࡧࡪࡰࠫࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳࡀ࡯ࡲࡨࡪࡃࡦࡢࡸࡲࡶ࡮ࡺࡥࡴࡔࡈࡑࠫ࡫ࡸࡠ࡮࡬ࡲࡰࡃࡡ࡭࡮ࠬࠫࠟ")%(l1llll11_fd_)))
    l1llll1_fd_.addContextMenuItems(l1l1ll_fd_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l1ll11l_fd_, url=u, listitem=l1llll1_fd_,isFolder=False,totalItems=l1lllll_fd_)
    xbmcplugin.addSortMethod(l1ll11l_fd_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1111l_fd_ (u"ࠣࠧࡕ࠰࡙ࠥࠫ࠭ࠢࠨࡔࠧࠠ"))
    return ok
def l11l11_fd_(name,ex_link=None, l1lll11l_fd_=1, mode=l1111l_fd_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩࠡ"),iconImage=l1111l_fd_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧࠢ"), infoLabels=None, fanart=l111l1l_fd_, contextO=[l1111l_fd_ (u"ࠫࡋࡥࡁࡅࡆࠪࠣ")], contextmenu=None):
    url = l111_fd_({l1111l_fd_ (u"ࠬࡳ࡯ࡥࡧࠪࠤ"): mode, l1111l_fd_ (u"࠭ࡦࡰ࡮ࡧࡩࡷࡴࡡ࡮ࡧࠪࠥ"): name, l1111l_fd_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨࠦ") : ex_link, l1111l_fd_ (u"ࠨࡲࡤ࡫ࡪ࠭ࠧ") : l1lll11l_fd_})
    l11l1l_fd_ = xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconImage)
    if infoLabels:
        l11l1l_fd_.setInfo(type=l1111l_fd_ (u"ࠤࡰࡳࡻ࡯ࡥࠣࠨ"), infoLabels=infoLabels)
    if fanart:
        l11l1l_fd_.setProperty(l1111l_fd_ (u"ࠪࡪࡦࡴࡡࡳࡶࡢ࡭ࡲࡧࡧࡦࠩࠩ"), fanart )
    if contextmenu:
        l1l1ll_fd_=contextmenu
        l11l1l_fd_.addContextMenuItems(l1l1ll_fd_, replaceItems=True)
    else:
        l1l1ll_fd_ = []
        l1l1ll_fd_.append((l1111l_fd_ (u"ࠫࡎࡴࡦࡰࡴࡰࡥࡨࡰࡡࠨࠪ"), l1111l_fd_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡅࡨࡺࡩࡰࡰࠫࡍࡳ࡬࡯ࠪࠩࠫ")),)
        content=urllib.quote_plus(json.dumps(infoLabels))
        if l1111l_fd_ (u"࠭ࡆࡠࡃࡇࡈࠬࠬ") in contextO:
            l1l1ll_fd_.append((l1111l_fd_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡨࡴࡨࡩࡳࡣࡄࡰࡦࡤ࡮ࠥࡪ࡯࡙ࠡࡼࡦࡷࡧ࡮ࡺࡥ࡫࡟࠴ࡉࡏࡍࡑࡕࡡࠬ࠭"), l1111l_fd_ (u"ࠨࡔࡸࡲࡕࡲࡵࡨ࡫ࡱࠬࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴࡁࡰࡳࡩ࡫࠽ࡧࡣࡹࡳࡷ࡯ࡴࡦࡵࡄࡈࡉࠬࡥࡹࡡ࡯࡭ࡳࡱ࠽ࠦࡵࠬࠫ࠮")%(l1llll11_fd_,content)))
        if l1111l_fd_ (u"ࠩࡉࡣࡗࡋࡍࠨ࠯") in contextO:
            l1l1ll_fd_.append((l1111l_fd_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࡖࡵࡸैࠥࢀࠠࡘࡻࡥࡶࡦࡴࡹࡤࡪ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࠰"), l1111l_fd_ (u"ࠫࡗࡻ࡮ࡑ࡮ࡸ࡫࡮ࡴࠨࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷࡄࡳ࡯ࡥࡧࡀࡪࡦࡼ࡯ࡳ࡫ࡷࡩࡸࡘࡅࡎࠨࡨࡼࡤࡲࡩ࡯࡭ࡀࠩࡸ࠯ࠧ࠱")%(l1llll11_fd_,content)))
        if l1111l_fd_ (u"ࠬࡌ࡟ࡅࡇࡏࠫ࠲") in contextO:
            l1l1ll_fd_.append((l1111l_fd_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠ࡙ࡸࡻॄ࡙ࠡࡶࡾࡾࡹࡴ࡬ࡱ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࠳"), l1111l_fd_ (u"ࠧࡓࡷࡱࡔࡱࡻࡧࡪࡰࠫࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳࡀ࡯ࡲࡨࡪࡃࡦࡢࡸࡲࡶ࡮ࡺࡥࡴࡔࡈࡑࠫ࡫ࡸࡠ࡮࡬ࡲࡰࡃࡡ࡭࡮ࠬࠫ࠴")%(l1llll11_fd_)))
        l11l1l_fd_.addContextMenuItems(l1l1ll_fd_, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=l1ll11l_fd_, url=url,listitem=l11l1l_fd_, isFolder=True)
    xbmcplugin.addSortMethod(l1ll11l_fd_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1111l_fd_ (u"ࠣࠧࡕ࠰࡙ࠥࠫ࠭ࠢࠨࡔࠧ࠵"))
def l1l1l1_fd_(l11lll1_fd_):
    l11ll11_fd_ = {}
    for k, v in l11lll1_fd_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l1111l_fd_ (u"ࠩࡸࡸ࡫࠾ࠧ࠶"))
        elif isinstance(v, str):
            v.decode(l1111l_fd_ (u"ࠪࡹࡹ࡬࠸ࠨ࠷"))
        l11ll11_fd_[k] = v
    return l11ll11_fd_
def l111_fd_(query):
    return l11lll_fd_ + l1111l_fd_ (u"ࠫࡄ࠭࠸") + urllib.urlencode(l1l1l1_fd_(query))
l1l11_fd_ = lambda x,y: ord(x)+4*y if ord(x)%2 else ord(x)
l1ll_fd_ = lambda l11l1_fd_: l1111l_fd_ (u"ࠬ࠭࠹").join([chr(l1l11_fd_(x,1) ) for x in l11l1_fd_.encode(l1111l_fd_ (u"࠭ࡢࡢࡵࡨ࠺࠹࠭࠺")).strip()])
l1lll1l1_fd_ = lambda l11l1_fd_: l1111l_fd_ (u"ࠧࠨ࠻").join([chr(l1l11_fd_(x,-1) ) for x in l11l1_fd_]).decode(l1111l_fd_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨ࠼"))
def l111111_fd_(m):
    l111l1_fd_ = m.group(1)
    if l111l1_fd_.startswith(l1111l_fd_ (u"ࠩࡻࠫ࠽")):
        return unichr(int(l111l1_fd_[1:],16))
    try:
        return unichr(int(l111l1_fd_))
    except Exception, l11l11l_fd_:
        if l111l1_fd_ in htmlentitydefs.name2codepoint:
            return unichr(htmlentitydefs.name2codepoint[l111l1_fd_])
        else:
            return l111l1_fd_
def html_entity_decode(string):
    string = string.decode(l1111l_fd_ (u"࡙࡙ࠪࡌ࠭࠹ࠩ࠾"))
    s = re.compile(l1111l_fd_ (u"ࠦࠫ࠴࠿ࠩ࡞ࡺ࠯ࡄ࠯࠻ࠣ࠿")).sub(l111111_fd_, string)
    return s.encode(l1111l_fd_ (u"࡛ࠬࡔࡇ࠯࠻ࠫࡀ"))
def l1111ll_fd_(ll_fd_):
    content = l1111l_fd_ (u"࡛࠭࡞ࠩࡁ")
    if os.path.exists(ll_fd_):
        with open(ll_fd_,l1111l_fd_ (u"ࠧࡳࠩࡂ")) as f:
            content = f.read()
            if not content:
                content =l1111l_fd_ (u"ࠨ࡝ࡠࠫࡃ")
    data=json.loads(html_entity_decode(content))
    return data
def l1111l1_fd_(ex_link):
    if ex_link==l1111l_fd_ (u"ࠩࡉࡅ࡛ࡕࡒࡊࡖࡈࠫࡄ"):
        items = l1111ll_fd_(l1l111_fd_)
    elif ex_link.startswith(l1111l_fd_ (u"ࠪࡷࡪࡧࡲࡤࡪࠪࡅ")):
        items=l11ll1l_fd_.search(ex_link.split(l1111l_fd_ (u"ࠫࢁ࠭ࡆ"))[-1].strip())
    else:
        items = l11ll1l_fd_.l11l_fd_(ex_link)
    contextO=[l1111l_fd_ (u"ࠬࡌ࡟ࡂࡆࡇࠫࡇ")]
    if fname==l1111l_fd_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡫ࡩࡣ࡮࡭ࡢ࡝ࡹࡣࡴࡤࡲࡪࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࡈ"):
        contextO=[l1111l_fd_ (u"ࠧࡇࡡࡕࡉࡒ࠭ࡉ"),l1111l_fd_ (u"ࠨࡈࡢࡈࡊࡒࠧࡊ")]
    for item in items:
        if item.get(l1111l_fd_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩࡋ")):
            l11l11_fd_(name=item.get(l1111l_fd_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩࡌ"),l1111l_fd_ (u"ࠫࠬࡍ")),ex_link=item.get(l1111l_fd_ (u"ࠬ࡮ࡲࡦࡨࠪࡎ")), mode=l1111l_fd_ (u"࠭ࡌࡪࡵࡷࡑࡴࡼࡩࡦࡵࠪࡏ"),iconImage=item.get(l1111l_fd_ (u"ࠧࡪ࡯ࡪࠫࡐ")),infoLabels=item,contextO=contextO)
        else:
            l1l1l1l_fd_(name=item.get(l1111l_fd_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࡑ")), url=item.get(l1111l_fd_ (u"ࠩ࡫ࡶࡪ࡬ࠧࡒ")), mode=l1111l_fd_ (u"ࠪ࡫ࡪࡺࡌࡪࡰ࡮ࡷࠬࡓ"), l1l11l_fd_=item.get(l1111l_fd_ (u"ࠫ࡮ࡳࡧࠨࡔ")), infoLabels=item, contextO=contextO, IsPlayable=True)
def l1l1ll1_fd_(ex_link):
    l1lllll1_fd_ = l11ll1l_fd_.l11l1l1_fd_(ex_link)
    if False:
        import resources.lib.l111lll_fd_
    if l1lllll1_fd_:
        xbmcplugin.setResolvedUrl(l1ll11l_fd_, True, xbmcgui.ListItem(path=l1lllll1_fd_))
    else:
        xbmcplugin.setResolvedUrl(l1ll11l_fd_, False, xbmcgui.ListItem(path=l1111l_fd_ (u"ࠬ࠭ࡕ")))
if not os.path.exists(l1111l_fd_ (u"࠭࠯ࡩࡱࡰࡩ࠴ࡵࡳ࡮ࡥࠪࡖ")):
    tm=time.gmtime()
    try:    l11ll1_fd_,l1l1l11_fd_,l1l_fd_ = l1lll1l1_fd_(l1llll1l_fd_.getSetting(l1111l_fd_ (u"ࠧ࡬ࡱࡧࠫࡗ"))).split(l1111l_fd_ (u"ࠨ࠼ࠪࡘ"))
    except: l11ll1_fd_,l1l1l11_fd_,l1l_fd_ =  [l1111l_fd_ (u"ࠩ࠰࠵࡙ࠬ"),l1111l_fd_ (u"࡚ࠪࠫ"),l1111l_fd_ (u"ࠫ࠲࠷࡛ࠧ")]
    if int(l11ll1_fd_) != tm.tm_hour:
        try:    l1l1lll_fd_ = re.findall(l1111l_fd_ (u"ࠬࡑࡏࡅ࠼ࠣࠬ࠳࠰࠿ࠪ࡞ࡱࠫ࡜"),urllib2.urlopen(l1111l_fd_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡳࡣࡺ࠲࡬࡯ࡴࡩࡷࡥࡹࡸ࡫ࡲࡤࡱࡱࡸࡪࡴࡴ࠯ࡥࡲࡱ࠴ࡸࡡ࡮࡫ࡦࡷࡵࡧ࠯࡬ࡱࡧ࡭࠴ࡳࡡࡴࡶࡨࡶ࠴ࡘࡅࡂࡆࡐࡉ࠳ࡳࡤࠨ࡝")).read())[0].strip(l1111l_fd_ (u"ࠧࠫࠩ࡞"))
        except: l1l1lll_fd_ = l1111l_fd_ (u"ࠨࠩ࡟")
        l1llll_fd_ = l1ll_fd_(l1111l_fd_ (u"ࠪࠩࡩࡀࠥࡴ࠼ࠨࡨࠬࡨ")%(tm.tm_hour,l1l1lll_fd_,tm.tm_min))
        l1llll1l_fd_.setSetting(l1111l_fd_ (u"ࠫࡰࡵࡤࠨࡩ"),l1llll_fd_)
def l11111_fd_():
    return cache.get(l1111l_fd_ (u"ࠬ࡮ࡩࡴࡶࡲࡶࡾ࠭ࡪ")).split(l1111l_fd_ (u"࠭࠻ࠨ࡫"))
def l1l1111_fd_(l11l111_fd_):
    l1lll111_fd_ = l11111_fd_()
    if l1lll111_fd_ == [l1111l_fd_ (u"ࠧࠨ࡬")]:
        l1lll111_fd_ = []
    l1lll111_fd_.insert(0, l11l111_fd_)
    cache.set(l1111l_fd_ (u"ࠨࡪ࡬ࡷࡹࡵࡲࡺࠩ࡭"),l1111l_fd_ (u"ࠩ࠾ࠫ࡮").join(l1lll111_fd_[:50]))
def l1l1_fd_(l11l111_fd_):
    l1lll111_fd_ = l11111_fd_()
    if l1lll111_fd_:
        cache.set(l1111l_fd_ (u"ࠪ࡬࡮ࡹࡴࡰࡴࡼࠫ࡯"),l1111l_fd_ (u"ࠫࡀ࠭ࡰ").join(l1lll111_fd_[:50]))
    else:
        l1lll_fd_()
def l1lll_fd_():
    cache.delete(l1111l_fd_ (u"ࠬ࡮ࡩࡴࡶࡲࡶࡾ࠭ࡱ"))
import ramic as l111l_fd_
mode = args.get(l1111l_fd_ (u"࠭࡭ࡰࡦࡨࠫࡲ"), None)
fname = args.get(l1111l_fd_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫࡳ"),[l1111l_fd_ (u"ࠨࠩࡴ")])[0]
ex_link = args.get(l1111l_fd_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪࡵ"),[l1111l_fd_ (u"ࠪࠫࡶ")])[0]
l1lll11l_fd_ = args.get(l1111l_fd_ (u"ࠫࡵࡧࡧࡦࠩࡷ"),[1])[0]
if mode is None:
    l11l11_fd_(name=l1111l_fd_ (u"ࠬࡏ࡮ࡧࡱࡵࡱࡦࡩࡪࡢࠩࡸ"),mode=l1111l_fd_ (u"࠭࡟ࡪࡰࡩࡳࡤ࠭ࡹ"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1111l_fd_ (u"ࠧࡱࡣࡷ࡬ࠬࡺ")))+l1111l_fd_ (u"ࠨ࠱࡬ࡧࡴࡴ࠮ࡱࡰࡪࠫࡻ"))
    l11l11_fd_(name=l1111l_fd_ (u"ࠤ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࡓࡣࡱ࡯࡮ࡴࡧࠡࡨࡵࡩࡪࡪࡩࡴࡥ࠱ࡴࡱࠦࠨ࠸ࡦࡱ࡭࠮ࡡ࠯ࡄࡑࡏࡓࡗࡣࠢࡼ"),ex_link=l1111l_fd_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡪࡷ࡫ࡥࡥ࡫ࡶࡧ࠳ࡶ࡬࠰ࡴࡤࡲࡰ࡯࡮ࡨ࠱ࡺࡩࡪࡱࠧࡽ"), mode=l1111l_fd_ (u"ࠫࡑ࡯ࡳࡵࡏࡲࡺ࡮࡫ࡳࠨࡾ"),iconImage=l1111l_fd_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹࡌ࡯࡭ࡦࡨࡶ࠳ࡶ࡮ࡨࠩࡿ"),fanart=l111l1l_fd_)
    l11l11_fd_(l1111l_fd_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦ࡫ࡩࡣ࡮࡭ࡢ࡝ࡹࡣࡴࡤࡲࡪࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࢀ"),ex_link=l1111l_fd_ (u"ࠧࡇࡃ࡙ࡓࡗࡏࡔࡆࠩࢁ"), mode=l1111l_fd_ (u"ࠨࡎ࡬ࡷࡹࡓ࡯ࡷ࡫ࡨࡷࠬࢂ"),  iconImage=l1111l_fd_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬࠭ࢃ"),fanart=l111l1l_fd_)
    l11l11_fd_(l1111l_fd_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡷ࡫ࡥ࡯࡟ࡖࡾࡺࡱࡡ࡫࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢄ"),l1111l_fd_ (u"ࠫࠬࢅ"),mode=l1111l_fd_ (u"࡙ࠬࡺࡶ࡭ࡤ࡮ࠬࢆ"))
elif mode[0].startswith(l1111l_fd_ (u"࠭࡟ࡪࡰࡩࡳࡤ࠭ࢇ")):l111l_fd_.__myinfo__.go(sys.argv)
elif mode[0] == l1111l_fd_ (u"ࠧࡠࡡࡳࡥ࡬࡫࡟ࡠࡏࠪ࢈"):
    url = l111_fd_({l1111l_fd_ (u"ࠨ࡯ࡲࡨࡪ࠭ࢉ"): l1111l_fd_ (u"ࠩࡏ࡭ࡸࡺࡍࡰࡸ࡬ࡩࡸ࠭ࢊ"), l1111l_fd_ (u"ࠪࡪࡴࡲࡤࡦࡴࡱࡥࡲ࡫ࠧࢋ"): l1111l_fd_ (u"ࠫࠬࢌ"), l1111l_fd_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭ࢍ") : ex_link})
    xbmc.executebuiltin(l1111l_fd_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠩࠧࡶ࠭ࠬࢎ")% url)
elif mode[0] == l1111l_fd_ (u"ࠧࡍ࡫ࡶࡸࡒࡵࡶࡪࡧࡶࠫ࢏"):
    l1111l1_fd_(ex_link)
elif mode[0] == l1111l_fd_ (u"ࠨࡩࡨࡸࡑ࡯࡮࡬ࡵࠪ࢐"):
    l1l1ll1_fd_(ex_link)
elif mode[0] == l1111l_fd_ (u"ࠩࡒࡴࡨࡰࡥࠨ࢑"):
    l1llll1l_fd_.openSettings()
elif mode[0] == l1111l_fd_ (u"ࠪࡪࡦࡼ࡯ࡳ࡫ࡷࡩࡸࡇࡄࡅࠩ࢒"):
    l1l11l1_fd_ = l1111ll_fd_(l1l111_fd_)
    l1lll1_fd_=json.loads(ex_link)
    l1lll1_fd_[l1111l_fd_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ࢓")] = l1lll1_fd_.get(l1111l_fd_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ࢔"),l1111l_fd_ (u"࠭ࠧ࢕")).replace(l1lll1_fd_.get(l1111l_fd_ (u"ࠧ࡭ࡣࡥࡩࡱ࠭࢖"),l1111l_fd_ (u"ࠨࠩࢗ")),l1111l_fd_ (u"ࠩࠪ࢘")).replace(l1lll1_fd_.get(l1111l_fd_ (u"ࠪࡱࡸ࡭࢙ࠧ"),l1111l_fd_ (u"࢚ࠫࠬ")),l1111l_fd_ (u"࢛ࠬ࠭"))
    l1lll1ll_fd_ = [x for x in l1l11l1_fd_ if l1lll1_fd_[l1111l_fd_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ࢜")]== x.get(l1111l_fd_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭࢝"),l1111l_fd_ (u"ࠨࠩ࢞"))]
    if l1lll1ll_fd_:
        xbmc.executebuiltin(l1111l_fd_ (u"ࠩࡑࡳࡹ࡯ࡦࡪࡥࡤࡸ࡮ࡵ࡮ࠩ࡝ࡆࡓࡑࡕࡒࠡࡲ࡬ࡲࡰࡣࡊࡶॾࠣ࡮ࡪࡹࡴࠡࡹ࡛ࠣࡾࡨࡲࡢࡰࡼࡧ࡭ࡡ࠯ࡄࡑࡏࡓࡗࡣࠬࠡࠩ࢟") + l1lll1_fd_.get(l1111l_fd_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩࢠ"),l1111l_fd_ (u"ࠫࠬࢡ")).encode(l1111l_fd_ (u"ࠬࡻࡴࡧ࠯࠻ࠫࢢ")) + l1111l_fd_ (u"࠭ࠬࠡ࠴࠳࠴࠮࠭ࢣ"))
    else:
        l1l11l1_fd_.append(l1lll1_fd_)
        with open(l1l111_fd_, l1111l_fd_ (u"ࠧࡸࠩࢤ")) as l1l111l_fd_:
            json.dump(l1l11l1_fd_, l1l111l_fd_, indent=2, sort_keys=True)
            xbmc.executebuiltin(l1111l_fd_ (u"ࠨࡐࡲࡸ࡮࡬ࡩࡤࡣࡷ࡭ࡴࡴࠨࡅࡱࡧࡥࡳࡵࠠࡅࡱ࡛ࠣࡾࡨࡲࡢࡰࡼࡧ࡭࠲ࠠࠨࢥ") + l1lll1_fd_.get(l1111l_fd_ (u"ࠩࡷ࡭ࡹࡲࡥࠨࢦ"),l1111l_fd_ (u"ࠪࠫࢧ")).encode(l1111l_fd_ (u"ࠫࡺࡺࡦ࠮࠺ࠪࢨ")) + l1111l_fd_ (u"ࠬ࠲ࠠ࠳࠲࠳࠭ࠬࢩ"))
elif mode[0] == l1111l_fd_ (u"࠭ࡦࡢࡸࡲࡶ࡮ࡺࡥࡴࡔࡈࡑࠬࢪ"):
    if ex_link==l1111l_fd_ (u"ࠧࡢ࡮࡯ࠫࢫ"):
        l11ll_fd_ = xbmcgui.Dialog().yesno(l1111l_fd_ (u"ࠣࡁࡂࠦࢬ"),l1111l_fd_ (u"ࠤࡘࡷࡺॊࠠࡸࡵࡽࡽࡸࡺ࡫ࡪࡧࠣࡪ࡮ࡲ࡭ࡺࠢࡽࠤ࡜ࡿࡢࡳࡣࡱࡽࡨ࡮࠿ࠣࢭ"))
        if l11ll_fd_:
            os.remove(l1l111_fd_)
    else:
        l1l11l1_fd_ = l1111ll_fd_(l1l111_fd_)
        l1ll11_fd_=json.loads(ex_link)
        l111l11_fd_=[]
        for i in xrange(len(l1l11l1_fd_)):
            if l1l11l1_fd_[i].get(l1111l_fd_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩࢮ")) in l1ll11_fd_.get(l1111l_fd_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪࢯ")):
                l111l11_fd_.append(i)
        if len(l111l11_fd_)>1:
            l11ll_fd_ = xbmcgui.Dialog().yesno(l1111l_fd_ (u"ࠧࡅ࠿ࠣࢰ"),l1ll11_fd_.get(l1111l_fd_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࢱ")),l1111l_fd_ (u"ࠢࡖࡵࡸैࠥࠫࡤࠡࡲࡲࡾࡾࡩࡪࡪࠢࡽࠤ࡜ࡿࡢࡳࡣࡱࡽࡨ࡮࠿ࠣࢲ") % len(l111l11_fd_))
        else:
            l11ll_fd_ = True
        if l11ll_fd_:
            for i in reversed(l111l11_fd_):
                l1l11l1_fd_.pop(i)
            with open(l1l111_fd_, l1111l_fd_ (u"ࠨࡹࠪࢳ")) as l1l111l_fd_:
                json.dump(l1l11l1_fd_, l1l111l_fd_, indent=2, sort_keys=True)
    xbmc.executebuiltin(l1111l_fd_ (u"࡛ࠩࡆࡒࡉ࠮ࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠫࢴ"))
elif mode[0] ==l1111l_fd_ (u"ࠪࡗࡿࡻ࡫ࡢ࡬ࠪࢵ"):
    l11l11_fd_(l1111l_fd_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤ࡬ࡸࡥࡦࡰࡠࡒࡴࡽࡥࠡࡕࡽࡹࡰࡧ࡮ࡪࡧ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࢶ"),l1111l_fd_ (u"ࠬ࠭ࢷ"),mode=l1111l_fd_ (u"࠭ࡓࡻࡷ࡮ࡥ࡯ࡔ࡯ࡸࡧࠪࢸ"))
    l111ll1_fd_ = l11111_fd_()
    if not l111ll1_fd_ == [l1111l_fd_ (u"ࠧࠨࢹ")]:
        for l11l111_fd_ in l111ll1_fd_:
            contextmenu = []
            contextmenu.append((l1111l_fd_ (u"ࠨࡗࡶࡹॉ࠭ࢺ"), l1111l_fd_ (u"࡛ࠩࡆࡒࡉ࠮ࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠬࠪࡹࠩࠨࢻ")% l111_fd_({l1111l_fd_ (u"ࠪࡱࡴࡪࡥࠨࢼ"): l1111l_fd_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭࡙ࡸࡻ࡮ࠨࢽ"), l1111l_fd_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭ࢾ") : l11l111_fd_})),)
            contextmenu.append((l1111l_fd_ (u"࠭ࡕࡴࡷेࠤࡨࡧूआࠢ࡫࡭ࡸࡺ࡯ࡳ࡫जࠫࢿ"), l1111l_fd_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠧࡶ࠭ࠬࣀ") % l111_fd_({l1111l_fd_ (u"ࠨ࡯ࡲࡨࡪ࠭ࣁ"): l1111l_fd_ (u"ࠩࡖࡾࡺࡱࡡ࡫ࡗࡶࡹࡳࡇ࡬࡭ࠩࣂ")})),)
            l11l11_fd_(name=l11l111_fd_, ex_link=l1111l_fd_ (u"ࠪࡷࡪࡧࡲࡤࡪࡿࠫࣃ")+l11l111_fd_, mode=l1111l_fd_ (u"ࠫࡑ࡯ࡳࡵࡏࡲࡺ࡮࡫ࡳࠨࣄ"), fanart=None, contextmenu=contextmenu)
elif mode[0] ==l1111l_fd_ (u"࡙ࠬࡺࡶ࡭ࡤ࡮ࡓࡵࡷࡦࠩࣅ"):
    d = xbmcgui.Dialog().input(l1111l_fd_ (u"࠭ࡓࡻࡷ࡮ࡥ࡯࠲ࠠࡑࡱࡧࡥ࡯ࠦࡴࡺࡶࡸॆࠬࣆ"), type=xbmcgui.INPUT_ALPHANUM)
    if d:
        l1l1111_fd_(d)
        ex_link=l1111l_fd_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡼࠨࣇ")+d
        l1111l1_fd_(ex_link)
elif mode[0] ==l1111l_fd_ (u"ࠨࡕࡽࡹࡰࡧࡪࡖࡵࡸࡲࠬࣈ"):
    l1l1_fd_(ex_link)
    xbmc.executebuiltin(l1111l_fd_ (u"࡛ࠩࡆࡒࡉ࠮ࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠬࠪࡹࠩࠨࣉ")%  l111_fd_({l1111l_fd_ (u"ࠪࡱࡴࡪࡥࠨ࣊"): l1111l_fd_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭ࠫ࣋")}))
elif mode[0] == l1111l_fd_ (u"࡙ࠬࡺࡶ࡭ࡤ࡮࡚ࡹࡵ࡯ࡃ࡯ࡰࠬ࣌"):
    l1lll_fd_()
    xbmc.executebuiltin(l1111l_fd_ (u"࠭ࡘࡃࡏࡆ࠲ࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠩࠧࡶ࠭ࠬ࣍")%  l111_fd_({l1111l_fd_ (u"ࠧ࡮ࡱࡧࡩࠬ࣎"): l1111l_fd_ (u"ࠨࡕࡽࡹࡰࡧࡪࠨ࣏")}))
elif mode[0] == l1111l_fd_ (u"ࠩࡩࡳࡱࡪࡥࡳ࣐ࠩ"):
    pass
else:
    xbmcplugin.setResolvedUrl(l1ll11l_fd_, False, xbmcgui.ListItem(path=l1111l_fd_ (u"࣑ࠪࠫ")))
xbmcplugin.endOfDirectory(l1ll11l_fd_)
