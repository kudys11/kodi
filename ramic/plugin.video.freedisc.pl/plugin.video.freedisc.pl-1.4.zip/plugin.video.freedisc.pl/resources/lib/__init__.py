# coding: UTF-8
import sys
l1lll11_fd_ = sys.version_info [0] == 2
l1ll1l_fd_ = 2048
l1111_fd_ = 7
def l1111l_fd_ (l1_fd_):
	global l1ll1l1_fd_
	l11111l_fd_ = ord (l1_fd_ [-1])
	l1lll1l_fd_ = l1_fd_ [:-1]
	l1ll1_fd_ = l11111l_fd_ % len (l1lll1l_fd_)
	l1l1l_fd_ = l1lll1l_fd_ [:l1ll1_fd_] + l1lll1l_fd_ [l1ll1_fd_:]
	if l1lll11_fd_:
		l1l11ll_fd_ = unicode () .join ([unichr (ord (char) - l1ll1l_fd_ - (l111ll_fd_ + l11111l_fd_) % l1111_fd_) for l111ll_fd_, char in enumerate (l1l1l_fd_)])
	else:
		l1l11ll_fd_ = str () .join ([chr (ord (char) - l1ll1l_fd_ - (l111ll_fd_ + l11111l_fd_) % l1111_fd_) for l111ll_fd_, char in enumerate (l1l1l_fd_)])
	return eval (l1l11ll_fd_)