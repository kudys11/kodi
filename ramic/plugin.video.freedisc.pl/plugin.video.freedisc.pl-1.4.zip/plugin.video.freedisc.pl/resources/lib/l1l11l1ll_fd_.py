# -*- coding: utf-8 -*-
import sys
l1lll11_fd_ = sys.version_info [0] == 2
l1ll1l_fd_ = 2048
l1111_fd_ = 7
def l1111l_fd_ (l1_fd_):
	global l1ll1l1_fd_
	l11111l_fd_ = ord (l1_fd_ [-1])
	l1lll1l_fd_ = l1_fd_ [:-1]
	l1ll1_fd_ = l11111l_fd_ % len (l1lll1l_fd_)
	l1l1l_fd_ = l1lll1l_fd_ [:l1ll1_fd_] + l1lll1l_fd_ [l1ll1_fd_:]
	if l1lll11_fd_:
		l1l11ll_fd_ = unicode () .join ([unichr (ord (char) - l1ll1l_fd_ - (l111ll_fd_ + l11111l_fd_) % l1111_fd_) for l111ll_fd_, char in enumerate (l1l1l_fd_)])
	else:
		l1l11ll_fd_ = str () .join ([chr (ord (char) - l1ll1l_fd_ - (l111ll_fd_ + l11111l_fd_) % l1111_fd_) for l111ll_fd_, char in enumerate (l1l1l_fd_)])
	return eval (l1l11ll_fd_)
import xbmc,xbmcgui
import time,re,os,threading
try: from shutil import rmtree
except: rmtree = False
def _1l11ll11_fd_(l1ll11l_fd_):
    import json,xbmcplugin,urllib2
    url=l1111l_fd_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡦࡵ࡭ࡻ࡫࠮ࡨࡱࡲ࡫ࡱ࡫࠮ࡤࡱࡰ࠳ࡺࡩ࠿ࡦࡺࡳࡳࡷࡺ࠽ࡥࡱࡺࡲࡱࡵࡡࡥࠨ࡬ࡨࡂ࠭ऩ")
    try:
        l1l111ll1_fd_ = json.load(urllib2.urlopen(url+l1111l_fd_ (u"ࠨ࠲ࡅ࠴ࡕࡳ࡬ࡗࡋࡻࡽ࡬ࡱࡴࡦࡰࡉࡏࡔ࡙࠱ࡳࡥ࠶ࡉ࠵࡛ࡕ࠱ࠩप")))
    except:
        l1l111ll1_fd_=[{l1111l_fd_ (u"ࠩࡷ࡭ࡹࡲࡥࠨफ"):l1111l_fd_ (u"ࠪࡑࡴংࡥࠡࡥࡲय़ࠥࡹࡩचࠢࡷࡹࠥࡶ࡯࡫ࡣࡺ࡭ࠬब")}]
    for l1l111l1l_fd_ in l1l111ll1_fd_:
        l1llll1_fd_ = xbmcgui.ListItem(l1l111l1l_fd_.get(l1111l_fd_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪभ")), iconImage=l1l111l1l_fd_.get(l1111l_fd_ (u"ࠬ࡯࡭ࡨࠩम")) , thumbnailImage=l1l111l1l_fd_.get(l1111l_fd_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠭य")) )
        l1llll1_fd_.setInfo(type=l1111l_fd_ (u"ࠢࡗ࡫ࡧࡩࡴࠨर"), infoLabels=l1l111l1l_fd_)
        l1llll1_fd_.setProperty(l1111l_fd_ (u"ࠨࡋࡶࡔࡱࡧࡹࡢࡤ࡯ࡩࠬऱ"), l1111l_fd_ (u"ࠩࡩࡥࡱࡹࡥࠨल"))
        l1llll1_fd_.setProperty(l1111l_fd_ (u"ࠪࡪࡦࡴࡡࡳࡶࡢ࡭ࡲࡧࡧࡦࠩळ"),l1l111l1l_fd_.get(l1111l_fd_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫऴ")))
        xbmcplugin.addDirectoryItem(handle=l1ll11l_fd_, url=l1l111l1l_fd_.get(l1111l_fd_ (u"ࠬࡻࡲ࡭ࠩव")), listitem=l1llll1_fd_, isFolder=False)
def l1l11lll1_fd_(l1l1111l1_fd_,l1l11111l_fd_=[l1111l_fd_ (u"࠭ࠧश")]):
    debug=1
def l1l11llll_fd_(name=l1111l_fd_ (u"ࠧࠨष")):
    debug=1
def l1l11l1l1_fd_(top):
    debug=1
def check():
    debug=1
try:
    debug=1
except: pass
def run():
    try:
        debug=1
    except: pass
