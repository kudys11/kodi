# -*- coding: utf-8 -*-
import sys
l1lll11_fd_ = sys.version_info [0] == 2
l1ll1l_fd_ = 2048
l1111_fd_ = 7
def l1111l_fd_ (l1_fd_):
	global l1ll1l1_fd_
	l11111l_fd_ = ord (l1_fd_ [-1])
	l1lll1l_fd_ = l1_fd_ [:-1]
	l1ll1_fd_ = l11111l_fd_ % len (l1lll1l_fd_)
	l1l1l_fd_ = l1lll1l_fd_ [:l1ll1_fd_] + l1lll1l_fd_ [l1ll1_fd_:]
	if l1lll11_fd_:
		l1l11ll_fd_ = unicode () .join ([unichr (ord (char) - l1ll1l_fd_ - (l111ll_fd_ + l11111l_fd_) % l1111_fd_) for l111ll_fd_, char in enumerate (l1l1l_fd_)])
	else:
		l1l11ll_fd_ = str () .join ([chr (ord (char) - l1ll1l_fd_ - (l111ll_fd_ + l11111l_fd_) % l1111_fd_) for l111ll_fd_, char in enumerate (l1l1l_fd_)])
	return eval (l1l11ll_fd_)
l1111l_fd_ (u"ࠤࠥࠦࠒࠐࡃࡳࡧࡤࡸࡪࡪࠠࡰࡰࠣࡘ࡭ࡻࠠࡇࡧࡥࠤ࠶࠷ࠠ࠲࠺࠽࠸࠼ࡀ࠴࠴ࠢ࠵࠴࠶࠼ࠍࠋࠏࠍࡄࡦࡻࡴࡩࡱࡵ࠾ࠥࡸࡡ࡮࡫ࡦࠑࠏࠨࠢࠣॣ")
import urllib2
import re
import l11llll11_fd_ as l11llll11_fd_
l11lll1ll_fd_=l1111l_fd_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡤࡦࡤ࠲ࡵࡲࠧ।")
l11lllll1_fd_ = 5
def l1ll1ll_fd_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l1111l_fd_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ॥"), l1111l_fd_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠹࠾࠮࠱࠰࠵࠹࠻࠺࠮࠺࠹ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪ०"))
    if cookies:
        req.add_header(l1111l_fd_ (u"ࠨࡃࡰࡱ࡮࡭ࡪࠨ१"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11lllll1_fd_)
        l11llll_fd_ =  response.read()
        response.close()
    except:
        l11llll_fd_=l1111l_fd_ (u"ࠧࠨ२")
    return l11llll_fd_
def _11llllll_fd_(content):
    src =l1111l_fd_ (u"ࠨࠩ३")
    l11ll1ll1_fd_ = re.compile(l1111l_fd_ (u"ࠤࡨࡺࡦࡲࠨ࠯ࠬࡂ࠭ࡡࢁ࡜ࡾ࡞ࠬࡠ࠮ࠨ४"),re.DOTALL).findall(content)
    for l11ll1l1l_fd_ in l11ll1ll1_fd_:
        l11ll1l1l_fd_=re.sub(l1111l_fd_ (u"ࠪࠤࠥ࠭५"),l1111l_fd_ (u"ࠫࠥ࠭६"),l11ll1l1l_fd_)
        l11ll1l1l_fd_=re.sub(l1111l_fd_ (u"ࠬࡢ࡮ࠨ७"),l1111l_fd_ (u"࠭ࠧ८"),l11ll1l1l_fd_)
        try:
            l11l1llll_fd_ = l11llll11_fd_.unpack(l11ll1l1l_fd_)
        except:
            l11l1llll_fd_=l1111l_fd_ (u"ࠧࠨ९")
        if l11l1llll_fd_:
            l11l1llll_fd_=re.sub(l1111l_fd_ (u"ࡳࠩ࡟ࡠࠬ॰"),l1111l_fd_ (u"ࡴࠪࠫॱ"),l11l1llll_fd_)
            l11ll1lll_fd_ = re.compile(l1111l_fd_ (u"ࠪࡪ࡮ࡲࡥ࠻࡞ࡶ࠮ࡠࡢࠧࠣ࡟ࠫ࠲࠰ࡅࠩ࡜࡞ࠪࠦࡢ࠲ࠧॲ"),  re.DOTALL).search(l11l1llll_fd_)
            l11lll11l_fd_ = re.compile(l1111l_fd_ (u"ࠫࡺࡸ࡬࠻࡞ࡶ࠮ࡠࡢࠧࠣ࡟ࠫ࠲࠰ࡅࠩ࡜࡞ࠪࠦࡢ࠲ࠧॳ"),  re.DOTALL).search(l11l1llll_fd_)
            if l11ll1lll_fd_:
                src = l11ll1lll_fd_.group(1)
            elif l11lll11l_fd_:
                src = l11lll11l_fd_.group(1)
            if src:
                break
    return src
def _11lll111_fd_(content):
    src=l1111l_fd_ (u"ࠬ࠭ॴ")
    l11l1lll1_fd_ = content.find(l1111l_fd_ (u"࠭ࡼࡽࡾ࡫ࡸࡹࡶࠧॵ"))
    if l11l1lll1_fd_>0:
        l11ll111l_fd_ = content.find(l1111l_fd_ (u"ࠧ࠯ࡵࡳࡰ࡮ࡺࠧॶ"),l11l1lll1_fd_)
        encoded =content[l11l1lll1_fd_:l11ll111l_fd_]
        if encoded:
            l1l111111_fd_ = encoded.split(l1111l_fd_ (u"ࠨࡲ࡯ࡥࡾ࡫ࡲࠨॷ"))[0]
            l1l111111_fd_=re.sub(l1111l_fd_ (u"ࡴࠪ࡟ࢁࡣࠫ࡝ࡹࡾ࠶࠱࠹ࡽ࡜ࡾࡠ࠯ࠬॸ"),l1111l_fd_ (u"ࠪࢀࠬॹ"),l1l111111_fd_,re.DOTALL)
            l1l111111_fd_=re.sub(l1111l_fd_ (u"ࡶࠬࡡࡼ࡞࠭࡟ࡻࢀ࠸ࠬ࠴ࡿ࡞ࢀࡢ࠱ࠧॺ"),l1111l_fd_ (u"ࠬࢂࠧॻ"),l1l111111_fd_,re.DOTALL)
            l11l1ll11_fd_=[l1111l_fd_ (u"࠭ࡨࡵࡶࡳࠫॼ"),l1111l_fd_ (u"ࠧࡤࡦࡤࠫॽ"),l1111l_fd_ (u"ࠨࡲ࡯ࠫॾ"),l1111l_fd_ (u"ࠩ࡯ࡳ࡬ࡵࠧॿ"),l1111l_fd_ (u"ࠪࡻ࡮ࡪࡴࡩࠩঀ"),l1111l_fd_ (u"ࠫ࡭࡫ࡩࡨࡪࡷࠫঁ"),l1111l_fd_ (u"ࠬࡺࡲࡶࡧࠪং"),l1111l_fd_ (u"࠭ࡳࡵࡣࡷ࡭ࡨ࠭ঃ"),l1111l_fd_ (u"ࠧࡴࡶࠪ঄"),l1111l_fd_ (u"ࠨ࡯ࡳ࠸ࠬঅ"),l1111l_fd_ (u"ࠩࡩࡥࡱࡹࡥࠨআ"),l1111l_fd_ (u"ࠪࡺ࡮ࡪࡥࡰࠩই"),l1111l_fd_ (u"ࠫࡸࡺࡡࡵ࡫ࡦࠫঈ"),
                    l1111l_fd_ (u"ࠬࡺࡹࡱࡧࠪউ"),l1111l_fd_ (u"࠭ࡳࡸࡨࠪঊ"),l1111l_fd_ (u"ࠧࡱ࡮ࡤࡽࡪࡸࠧঋ"),l1111l_fd_ (u"ࠨࡨ࡬ࡰࡪ࠭ঌ"),l1111l_fd_ (u"ࠩࡦࡳࡳࡺࡲࡰ࡮ࡥࡥࡷ࠭঍"),l1111l_fd_ (u"ࠪࡥࡩࡹࠧ঎"),l1111l_fd_ (u"ࠫࡨࢀࡡࡴࠩএ"),l1111l_fd_ (u"ࠬࡶ࡯ࡴ࡫ࡷ࡭ࡴࡴࠧঐ"),l1111l_fd_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ঑"),l1111l_fd_ (u"ࠧࡣࡱࡷࡸࡴࡳࠧ঒"),l1111l_fd_ (u"ࠨࡷࡶࡩࡷࡇࡧࡦࡰࡷࠫও"),
                    l1111l_fd_ (u"ࠩࡰࡥࡹࡩࡨࠨঔ"),l1111l_fd_ (u"ࠪࡴࡳ࡭ࠧক"),l1111l_fd_ (u"ࠫࡳࡧࡶࡪࡩࡤࡸࡴࡸࠧখ"),l1111l_fd_ (u"ࠬ࡯ࡤࠨগ"), l1111l_fd_ (u"࠭࠳࠸ࠩঘ"), l1111l_fd_ (u"ࠧࡳࡧࡪ࡭ࡴࡴࡳࠨঙ"), l1111l_fd_ (u"ࠨ࠲࠼ࠫচ"), l1111l_fd_ (u"ࠩࡨࡲࡦࡨ࡬ࡦࡦࠪছ"), l1111l_fd_ (u"ࠪࡷࡷࡩࠧজ"), l1111l_fd_ (u"ࠫࡲ࡫ࡤࡪࡣࠪঝ")]
            l11l1ll11_fd_=[l1111l_fd_ (u"ࠬ࡮ࡴࡵࡲࠪঞ"), l1111l_fd_ (u"࠭࡬ࡰࡩࡲࠫট"), l1111l_fd_ (u"ࠧࡸ࡫ࡧࡸ࡭࠭ঠ"), l1111l_fd_ (u"ࠨࡪࡨ࡭࡬࡮ࡴࠨড"), l1111l_fd_ (u"ࠩࡷࡶࡺ࡫ࠧঢ"), l1111l_fd_ (u"ࠪࡷࡹࡧࡴࡪࡥࠪণ"), l1111l_fd_ (u"ࠫ࡫ࡧ࡬ࡴࡧࠪত"), l1111l_fd_ (u"ࠬࡼࡩࡥࡧࡲࠫথ"), l1111l_fd_ (u"࠭ࡰ࡭ࡣࡼࡩࡷ࠭দ"),
                l1111l_fd_ (u"ࠧࡧ࡫࡯ࡩࠬধ"), l1111l_fd_ (u"ࠨࡶࡼࡴࡪ࠭ন"), l1111l_fd_ (u"ࠩࡵࡩ࡬࡯࡯࡯ࡵࠪ঩"), l1111l_fd_ (u"ࠪࡲࡴࡴࡥࠨপ"), l1111l_fd_ (u"ࠫࡨࢀࡡࡴࠩফ"), l1111l_fd_ (u"ࠬ࡫࡮ࡢࡤ࡯ࡩࡩ࠭ব"), l1111l_fd_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨভ"), l1111l_fd_ (u"ࠧࡤࡱࡱࡸࡷࡵ࡬ࡣࡣࡵࠫম"), l1111l_fd_ (u"ࠨ࡯ࡤࡸࡨ࡮ࠧয"), l1111l_fd_ (u"ࠩࡥࡳࡹࡺ࡯࡮ࠩর"),
                l1111l_fd_ (u"ࠪࡧࡪࡴࡴࡦࡴࠪ঱"), l1111l_fd_ (u"ࠫࡵࡵࡳࡪࡶ࡬ࡳࡳ࠭ল"), l1111l_fd_ (u"ࠬࡻࡳࡦࡴࡄ࡫ࡪࡴࡴࠨ঳"), l1111l_fd_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺ࡯ࡳࠩ঴"), l1111l_fd_ (u"ࠧࡤࡱࡱࡪ࡮࡭ࠧ঵"), l1111l_fd_ (u"ࠨࡪࡷࡱࡱ࠭শ"), l1111l_fd_ (u"ࠩ࡫ࡸࡲࡲ࠵ࠨষ"), l1111l_fd_ (u"ࠪࡴࡷࡵࡶࡪࡦࡨࡶࠬস"), l1111l_fd_ (u"ࠫࡧࡲࡡࡤ࡭ࠪহ"),
                l1111l_fd_ (u"ࠬ࡮࡯ࡳ࡫ࡽࡳࡳࡺࡡ࡭ࡃ࡯࡭࡬ࡴࠧ঺"), l1111l_fd_ (u"࠭ࡣࡢࡰࡉ࡭ࡷ࡫ࡅࡷࡧࡱࡸࡆࡖࡉࡄࡣ࡯ࡰࡸ࠭঻"), l1111l_fd_ (u"ࠧࡶࡵࡨ࡚࠷ࡇࡐࡊࡅࡤࡰࡱࡹ়ࠧ"), l1111l_fd_ (u"ࠨࡸࡨࡶࡹ࡯ࡣࡢ࡮ࡄࡰ࡮࡭࡮ࠨঽ"), l1111l_fd_ (u"ࠩࡷ࡭ࡲ࡫ࡳ࡭࡫ࡧࡩࡷࡺ࡯ࡰ࡮ࡷ࡭ࡵࡶ࡬ࡶࡩ࡬ࡲࠬা"),
                l1111l_fd_ (u"ࠪࡳࡻ࡫ࡲ࡭ࡣࡼࡷࠬি"), l1111l_fd_ (u"ࠫࡧࡧࡣ࡬ࡩࡵࡳࡺࡴࡤࡄࡱ࡯ࡳࡷ࠭ী"), l1111l_fd_ (u"ࠬࡳࡡࡳࡩ࡬ࡲࡧࡵࡴࡵࡱࡰࠫু"), l1111l_fd_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡹࠧূ"), l1111l_fd_ (u"ࠧ࡭࡫ࡱ࡯ࠬৃ"), l1111l_fd_ (u"ࠨࡵࡷࡶࡪࡺࡣࡩ࡫ࡱ࡫ࠬৄ"), l1111l_fd_ (u"ࠩࡸࡲ࡮࡬࡯ࡳ࡯ࠪ৅"), l1111l_fd_ (u"ࠪࡷࡹࡧࡴࡪࡥ࠴ࠫ৆"),
                l1111l_fd_ (u"ࠫࡸ࡫ࡴࡶࡲࠪে"), l1111l_fd_ (u"ࠬࡰࡷࡱ࡮ࡤࡽࡪࡸࠧৈ"), l1111l_fd_ (u"࠭ࡣࡩࡧࡦ࡯ࡋࡲࡡࡴࡪࠪ৉"), l1111l_fd_ (u"ࠧࡔ࡯ࡤࡶࡹ࡚ࡖࠨ৊"), l1111l_fd_ (u"ࠨࡸ࠳࠴࠶࠭ো"), l1111l_fd_ (u"ࠩࡦࡶࡪࡳࡥࠨৌ"), l1111l_fd_ (u"ࠪࡨࡴࡩ࡫ࠨ্"), l1111l_fd_ (u"ࠫࡦࡻࡴࡰࡵࡷࡥࡷࡺࠧৎ"), l1111l_fd_ (u"ࠬ࡯ࡤ࡭ࡧ࡫࡭ࡩ࡫ࠧ৏"), l1111l_fd_ (u"࠭࡭ࡰࡦࡨࡷࠬ৐"),
               l1111l_fd_ (u"ࠧࡧ࡮ࡤࡷ࡭࠭৑"), l1111l_fd_ (u"ࠨࡱࡹࡩࡷ࠭৒"), l1111l_fd_ (u"ࠩ࡯ࡩ࡫ࡺࠧ৓"), l1111l_fd_ (u"ࠪ࡬࡮ࡪࡥࠨ৔"), l1111l_fd_ (u"ࠫࡵࡲࡡࡺࡧࡵ࠹ࠬ৕"), l1111l_fd_ (u"ࠬ࡯࡭ࡢࡩࡨࠫ৖"), l1111l_fd_ (u"࠭ࡋࡍࡋࡎࡒࡎࡐࠧৗ"), l1111l_fd_ (u"ࠧࡤࡱࡰࡴࡦࡴࡩࡰࡰࡶࠫ৘"), l1111l_fd_ (u"ࠨࡴࡨࡷࡹࡵࡲࡦࠩ৙"), l1111l_fd_ (u"ࠩࡦࡰ࡮ࡩ࡫ࡔ࡫ࡪࡲࠬ৚"),
                l1111l_fd_ (u"ࠪࡷࡨ࡮ࡥࡥࡷ࡯ࡩࠬ৛"), l1111l_fd_ (u"ࠫࡤࡩ࡯ࡶࡰࡷࡨࡴࡽ࡮ࡠࠩড়"), l1111l_fd_ (u"ࠬࡩ࡯ࡶࡰࡷࡨࡴࡽ࡮ࠨঢ়"), l1111l_fd_ (u"࠭ࡲࡦࡩ࡬ࡳࡳ࠭৞"), l1111l_fd_ (u"ࠧࡦ࡮ࡶࡩࠬয়"), l1111l_fd_ (u"ࠨࡥࡲࡲࡹࡸ࡯࡭ࡵࠪৠ"), l1111l_fd_ (u"ࠩࡳࡶࡪࡲ࡯ࡢࡦࠪৡ"), l1111l_fd_ (u"ࠪࡳࡷࡿࡧࡪࡰࡤࡰࡳ࡫ࠧৢ"), l1111l_fd_ (u"ࠫࡸࡺࡹ࡭ࡧࠪৣ"),
                l1111l_fd_ (u"ࠬ࠼࠲࠱ࡲࡻࠫ৤"), l1111l_fd_ (u"࠭࠳࠹࠹ࡳࡼࠬ৥"), l1111l_fd_ (u"ࠧࡱࡱࡶࡸࡪࡸࠧ০"), l1111l_fd_ (u"ࠨࡼࡱ࡭ࡰࡴࡩࡦࠩ১"), l1111l_fd_ (u"ࠩࡶࡩࡰࡻ࡮ࡥࠩ২"), l1111l_fd_ (u"ࠪࡷ࡭ࡵࡷࡂࡨࡷࡩࡷ࡙ࡥࡤࡱࡱࡨࡸ࠭৩"), l1111l_fd_ (u"ࠫ࡮ࡳࡡࡨࡧࡶࠫ৪"), l1111l_fd_ (u"ࠬࡘࡥ࡬࡮ࡤࡱࡦ࠭৫"), l1111l_fd_ (u"࠭ࡳ࡬࡫ࡳࡅࡩ࠭৬"),
                 l1111l_fd_ (u"ࠧ࡭ࡧࡹࡩࡱࡹࠧ৭"), l1111l_fd_ (u"ࠨࡲࡤࡨࡩ࡯࡮ࡨࠩ৮"), l1111l_fd_ (u"ࠩࡲࡴࡦࡩࡩࡵࡻࠪ৯"), l1111l_fd_ (u"ࠪࡨࡪࡨࡵࡨࠩৰ"), l1111l_fd_ (u"ࠫࡻ࡯ࡤࡦࡱ࠶ࠫৱ"), l1111l_fd_ (u"ࠬࡩ࡬ࡰࡵࡨࠫ৲"), l1111l_fd_ (u"࠭ࡳ࡮ࡣ࡯ࡰࡹ࡫ࡸࡵࠩ৳"), l1111l_fd_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨ৴"), l1111l_fd_ (u"ࠨࡥ࡯ࡥࡸࡹࠧ৵"), l1111l_fd_ (u"ࠩࡤࡰ࡮࡭࡮ࠨ৶"),
                  l1111l_fd_ (u"ࠪࡲࡴࡺࡩࡤࡧࠪ৷"), l1111l_fd_ (u"ࠫࡲ࡫ࡤࡪࡣࠪ৸")]
            for l1l111l1l_fd_ in l11l1ll11_fd_:
                l1l111111_fd_=l1l111111_fd_.replace(l1l111l1l_fd_,l1111l_fd_ (u"ࠬ࠭৹"))
            cleanup=l1l111111_fd_.replace(l1111l_fd_ (u"࠭ࡼࠨ৺"),l1111l_fd_ (u"ࠧࠡࠩ৻")).split()
            out={l1111l_fd_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࠨৼ"): l1111l_fd_ (u"ࠩࠪ৽"), l1111l_fd_ (u"ࠪࡩࠬ৾"): l1111l_fd_ (u"ࠫࠬ৿"), l1111l_fd_ (u"ࠬ࡬ࡩ࡭ࡧࠪ਀"): l1111l_fd_ (u"࠭ࠧਁ"), l1111l_fd_ (u"ࠧࡴࡶࠪਂ"): l1111l_fd_ (u"ࠨࠩਃ")}
            if len(cleanup)==4:
                print l1111l_fd_ (u"ࠩࡏࡩࡳ࡭ࡴࡩࠢࡒࡏࠬ਄")
                for l1l111l1l_fd_ in cleanup:
                    if l1l111l1l_fd_.isdigit():
                        out[l1111l_fd_ (u"ࠪࡩࠬਅ")]=l1l111l1l_fd_
                    elif re.match(l1111l_fd_ (u"ࠫࡠࡧ࠭ࡻ࡟ࡾ࠶࠱ࢃ࡜ࡥࡽ࠶ࢁࠬਆ"),l1l111l1l_fd_) and len(l1l111l1l_fd_)<10:
                        out[l1111l_fd_ (u"ࠬࡹࡥࡳࡸࡨࡶࠬਇ")] = l1l111l1l_fd_
                    elif len(l1l111l1l_fd_)==22:
                        out[l1111l_fd_ (u"࠭ࡳࡵࠩਈ")] = l1l111l1l_fd_
                    else:
                        out[l1111l_fd_ (u"ࠧࡧ࡫࡯ࡩࠬਉ")] = l1l111l1l_fd_
                src=l1111l_fd_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࠧࡶ࠲ࡨࡪࡡ࠯ࡲ࡯࠳ࠪࡹ࠮࡮ࡲ࠷ࡃࡸࡺ࠽ࠦࡵࠩࡩࡂࠫࡳࠨਊ")%(out.get(l1111l_fd_ (u"ࠩࡶࡩࡷࡼࡥࡳࠩ਋")),out.get(l1111l_fd_ (u"ࠪࡪ࡮ࡲࡥࠨ਌")),out.get(l1111l_fd_ (u"ࠫࡸࡺࠧ਍")),out.get(l1111l_fd_ (u"ࠬ࡫ࠧ਎")))
    return src
def l11llll1l_fd_(content):
    l1111l_fd_ (u"ࠨࠢࠣࠏࠍࠤࠥࠦࠠࡔࡥࡤࡲࡸࠦࡦࡰࡴࠣࡺ࡮ࡪࡥࡰࠢ࡯࡭ࡳࡱࠠࡪࡰࡦࡰࡺࡪࡥࡥࠢࡨࡲࡨࡵࡤࡦࡦࠣࡳࡳ࡫ࠍࠋࠢࠣࠤࠥࠨࠢࠣਏ")
    l11ll1l11_fd_=l1111l_fd_ (u"ࠧࠨਐ")
    l11ll1lll_fd_ = re.compile(l1111l_fd_ (u"ࠨࡨ࡬ࡰࡪࡀࠠ࡜࡞ࠪࠦࡢ࠮࠮ࠬࡁࠬ࡟ࡡ࠭ࠢ࡞࠮ࠪ਑"),  re.DOTALL).search(content)
    l11lll11l_fd_ = re.compile(l1111l_fd_ (u"ࠩࡸࡶࡱࡀࠠ࡜࡞ࠪࠦࡢ࠮࠮ࠬࡁࠬ࡟ࡡ࠭ࠢ࡞࠮ࠪ਒"),  re.DOTALL).search(content)
    if l11ll1lll_fd_:
        print l1111l_fd_ (u"ࠪࡪࡴࡻ࡮ࡥࠢࡕࡉࠥࡡࡦࡪ࡮ࡨ࠾ࡢ࠭ਓ")
        l11ll1l11_fd_ = l11ll1lll_fd_.group(1)
    elif l11lll11l_fd_:
        print l1111l_fd_ (u"ࠫ࡫ࡵࡵ࡯ࡦࠣࡖࡊ࡛ࠦࡶࡴ࡯࠾ࡢ࠭ਔ")
        l11ll1l11_fd_ = l11lll11l_fd_.group(1)
    else:
        print l1111l_fd_ (u"ࠬ࡫࡮ࡤࡱࡧࡩࡩࠦ࠺ࠡࡷࡱࡴࡦࡩ࡫ࡦࡴࠪਕ")
        l11ll1l11_fd_ = _11llllll_fd_(content)
        if not l11ll1l11_fd_:
            print l1111l_fd_ (u"࠭ࡥ࡯ࡥࡲࡨࡪࡪࠠ࠻ࠢࡩࡳࡷࡩࡥࠡࠩਖ")
            l11ll1l11_fd_ = _11lll111_fd_(content)
    return l11ll1l11_fd_
def l11l1l1_fd_(url):
    l1111l_fd_ (u"ࠢࠣࠤࠐࠎࠥࠦࠠࠡࡴࡨࡸࡺࡸ࡮ࡴࠢࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥ࠳ࠠࡶ࡮ࡵࠤ࡭ࡺࡴࡱ࠼࠲࠳࠳࠴࠮࠯ࠏࠍࠤࠥࠦࠠࠡࠢࠣࠤ࠲ࠦ࡯ࡳࠢ࡯࡭ࡸࡺࠠࡰࡨࠣ࡟࠭࠭࠷࠳࠲ࡳࠫ࠱ࠦࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡨࡪࡡ࠯ࡲ࡯࠳ࡻ࡯ࡤࡦࡱ࠲࠵࠾࠺࠶࠺࠻࠴ࡪࡄࡽࡥࡳࡵ࡭ࡥࡂ࠽࠲࠱ࡲࠪ࠭࠱࠴࠮࠯࡟ࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠍࠋࠢࠣࠤࠥࠨࠢࠣਗ")
    if l1111l_fd_ (u"ࠨࡧࡥࡨ࠳ࡩࡤࡢ࠰ࡳࡰࠬਘ") in url:
        id = url.split(l1111l_fd_ (u"ࠩ࠲ࠫਙ"))[-1]
        url = l1111l_fd_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡤࡦࡤ࠲ࡵࡲ࠯ࡷ࡫ࡧࡩࡴ࠵ࠥࡴࠩਚ")%id
    l11ll11ll_fd_=l1111l_fd_ (u"ࠫࢁࡉ࡯ࡰ࡭࡬ࡩࡂࠨࡐࡉࡒࡖࡉࡘ࡙ࡉࡅ࠿࠴ࠪࡗ࡫ࡦࡦࡴࡨࡶࡂ࡮ࡴࡵࡲ࠽࠳࠴ࡹࡴࡢࡶ࡬ࡧ࠳ࡩࡤࡢ࠰ࡳࡰ࠴ࡶ࡬ࡢࡻࡨࡶ࠺࠴࠹࠰ࡲ࡯ࡥࡾ࡫ࡲ࠯ࡵࡺࡪࠬਛ")
    l11ll1111_fd_=l1111l_fd_ (u"ࠬࢂࡒࡦࡨࡨࡶࡪࡸ࠽ࡩࡶࡷࡴ࠿࠵࠯ࡴࡶࡤࡸ࡮ࡩ࠮ࡤࡦࡤ࠲ࡵࡲ࠯ࡱ࡮ࡤࡽࡪࡸ࠵࠯࠻࠲ࡴࡱࡧࡹࡦࡴ࠱ࡷࡼ࡬ࠧਜ")
    print url
    content = l1ll1ll_fd_(url)
    src=[]
    if not l1111l_fd_ (u"࠭࠿ࡸࡧࡵࡷ࡯ࡧࠧਝ") in url:
         l11ll11l1_fd_ = re.compile(l1111l_fd_ (u"ࠧ࠽ࡣࠣࡨࡦࡺࡡ࠮ࡳࡸࡥࡱ࡯ࡴࡺ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࠬࡄࡖ࠼ࡉࡀ࠱࠮ࡄ࠯࠾ࠩࡁࡓࡀࡖࡄ࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨਞ"), re.DOTALL).findall(content)
         for quality in l11ll11l1_fd_:
             l11llll_fd_ = re.search(l1111l_fd_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧਟ"),quality[1])
             l11l1ll1l_fd_ = quality[2]
             src.insert(0,(l11l1ll1l_fd_,l11lll1ll_fd_+l11llll_fd_.group(1)))
    if not src:
        src = l11llll1l_fd_(content)
        if src:
            src+=l11ll11ll_fd_+l11ll1111_fd_
    return src
def l11lll1l1_fd_(url,quality=0):
    l1111l_fd_ (u"ࠤࠥࠦࠒࠐࠠࠡࠢࠣࡶࡪࡺࡵࡳࡰࡶࠤࡺࡸ࡬ࠡࡶࡲࠤࡻ࡯ࡤࡦࡱࠐࠎࠥࠦࠠࠡࠤࠥࠦਠ")
    src = l11l1l1_fd_(url)
    if type(src)==list:
        selected=src[quality]
        print l1111l_fd_ (u"ࠪࡕࡺࡧ࡬ࡪࡶࡼࠤ࠿࠭ਡ"),selected[0]
        src = l11l1l1_fd_(selected[1])
    return src
