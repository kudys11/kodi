# -*- coding: utf-8 -*-
import sys
l1lll11_fd_ = sys.version_info [0] == 2
l1ll1l_fd_ = 2048
l1111_fd_ = 7
def l1111l_fd_ (l1_fd_):
	global l1ll1l1_fd_
	l11111l_fd_ = ord (l1_fd_ [-1])
	l1lll1l_fd_ = l1_fd_ [:-1]
	l1ll1_fd_ = l11111l_fd_ % len (l1lll1l_fd_)
	l1l1l_fd_ = l1lll1l_fd_ [:l1ll1_fd_] + l1lll1l_fd_ [l1ll1_fd_:]
	if l1lll11_fd_:
		l1l11ll_fd_ = unicode () .join ([unichr (ord (char) - l1ll1l_fd_ - (l111ll_fd_ + l11111l_fd_) % l1111_fd_) for l111ll_fd_, char in enumerate (l1l1l_fd_)])
	else:
		l1l11ll_fd_ = str () .join ([chr (ord (char) - l1ll1l_fd_ - (l111ll_fd_ + l11111l_fd_) % l1111_fd_) for l111ll_fd_, char in enumerate (l1l1l_fd_)])
	return eval (l1l11ll_fd_)
l1111l_fd_ (u"ࠦࠧࠨࠍࠋࠏࠍࡄࡦࡻࡴࡩࡱࡵ࠾ࠥࡸࡡ࡮࡫ࡦࡷࡵࡧࠍࠋࠤࠥࠦਢ")
import urllib2,urllib
import re
import json as json
import htmlentitydefs
import l1l11l1ll_fd_
l111l1lll_fd_=l1111l_fd_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠹࠾࠮࠱࠰࠵࠹࠻࠺࠮࠺࠹ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪਣ")
l11lll1ll_fd_=l1111l_fd_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡦࡳࡧࡨࡨ࡮ࡹࡣ࠯ࡲ࡯ࠫਤ")
l11lllll1_fd_ = 30
def l1ll1ll_fd_(url,data=None,headers={},cookies=None):
    if headers:
        l111l1l11_fd_=headers
    else:
        l111l1l11_fd_ = {l1111l_fd_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫਥ"):l1111l_fd_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠵࠺࠱࠴࠳࠸࠵࠷࠶࠱࠽࠼ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ਦ")}
    req = urllib2.Request(url,data,l111l1l11_fd_)
    if cookies:
        req.add_header(l1111l_fd_ (u"ࠤࡆࡳࡴࡱࡩࡦࠤਧ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11lllll1_fd_)
        l11llll_fd_ =  response.read()
        response.close()
    except:
        l11llll_fd_=l1111l_fd_ (u"ࠪࠫਨ")
    return l11llll_fd_
def _111l1ll1_fd_(l11l1l1l1_fd_):
    out=[]
    for item in l11l1l1l1_fd_:
        href = re.compile(l1111l_fd_ (u"ࠫࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࠬ਩")).findall(item)
        l11l11l1l_fd_ = re.compile(l1111l_fd_ (u"ࠬࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽࡜ࠤ࡟ࠫࡢ࠮࠮ࠫࡁࠬ࡟ࠧࡢࠧ࡞ࠢࡤࡰࡹࡃ࡛ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝ࠨਪ")).findall(item)
        if href and l11l11l1l_fd_:
            l1l111l1l_fd_ = {l1111l_fd_ (u"࠭ࡨࡳࡧࡩࠫਫ")   : l11lll1ll_fd_+href[0],
                   l1111l_fd_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ਬ") : l11l111ll_fd_(l11l11l1l_fd_[0][1]).strip(),
                   l1111l_fd_ (u"ࠨ࡫ࡰ࡫ࠬਭ") : l11l11l1l_fd_[0][0],
                   l1111l_fd_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩਮ"): True,
                }
            out.append(l1l111l1l_fd_)
    return out
def _111ll1l1_fd_(l11l111l1_fd_):
    out=[]
    item=l11l111l1_fd_[0]
    for item in l11l111l1_fd_:
        href = re.compile(l1111l_fd_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࡠࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢ࠭ਯ")).findall(item)
        title = re.compile(l1111l_fd_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࡡ࡞࠿࡟࠮ࡂ࠭࠴ࠪࡀࠫ࠿ࠫਰ")).findall(item)
        id = re.compile(l1111l_fd_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿࡞ࠦࡡ࠭࡝ࡥࡣࡷࡥࡠࠨ࡜ࠨ࡟ࠣ࡭ࡩࡃ࡛ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝࠿ࠩ਱")).findall(item)
        l11l11l1l_fd_ = re.compile(l1111l_fd_ (u"࠭ࡳࡳࡥࡀ࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࠬਲ")).findall(item)
        info = re.compile(l1111l_fd_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࡠࠨ࡜ࠨ࡟࡬ࡲ࡫ࡵ࡛ࠣ࡞ࠪࡡࡠࡤ࠾࡞ࠬࡁࠬ࠳࠰࠿ࠪ࠾ࠪਲ਼")).findall(item)
        if href and title:
            if id:
                url=l1111l_fd_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡨࡵࡩࡪࡪࡩࡴࡥ࠱ࡴࡱ࠵ࡥ࡮ࡤࡨࡨ࠴ࡼࡩࡥࡧࡲ࠳ࠬ਴")+id[0].split(l1111l_fd_ (u"ࠩ࠰ࠫਵ"))[-1]
                l111ll11l_fd_ = False
            else:
                url = l11lll1ll_fd_ + l1111l_fd_ (u"ࠪ࠳ࠬਸ਼") if not href[0].startswith(l1111l_fd_ (u"ࠫ࠴࠭਷")) else l11lll1ll_fd_
                url = url + href[0]
                l111ll11l_fd_ = True if re.search(l1111l_fd_ (u"ࠬ࠲ࡤ࠮࡞ࡧ࠯ࠬਸ"),url) else False
            title = l11l111ll_fd_(title[0])
            if info:
                title +=l1111l_fd_ (u"࠭ࠠ࡜ࡅࡒࡐࡔࡘࠠ࡭࡫ࡪ࡬ࡹࡨ࡬ࡶࡧࡠࠩࡸࡡ࠯ࡄࡑࡏࡓࡗࡣࠧਹ")%(info[0])
            l11l11l1l_fd_ = l11l11l1l_fd_[0] if l11l11l1l_fd_ else l1111l_fd_ (u"ࠧࠨ਺")
            if l11l11l1l_fd_.startswith(l1111l_fd_ (u"ࠨ࠱ࠪ਻")):
                l11l11l1l_fd_ = l11lll1ll_fd_ + l11l11l1l_fd_
            l1l111l1l_fd_ = {l1111l_fd_ (u"ࠩ࡫ࡶࡪ࡬਼ࠧ")   : url,
                   l1111l_fd_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ਽") : l11l111ll_fd_(title.strip()),
                   l1111l_fd_ (u"ࠫ࡮ࡳࡧࠨਾ") : l11l11l1l_fd_,
                   l1111l_fd_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬਿ"): l111ll11l_fd_,
                   }
            out.append(l1l111l1l_fd_)
    return out
def _11l11l11_fd_(l11l1l1ll_fd_,content):
    l11l1l1ll_fd_.append( (-1,-1) )
    out=[]
    for i in range(len(l11l1l1ll_fd_[:-1])):
        item = content[ l11l1l1ll_fd_[i][1]:l11l1l1ll_fd_[i+1][0] ]
        l11l11l1l_fd_ = re.compile(l1111l_fd_ (u"࠭ࡳࡳࡥࡀ࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࠬੀ")).findall(item)
        href = re.compile(l1111l_fd_ (u"ࠧࡩࡴࡨࡪࡂࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣࠧੁ")).findall(item)
        title = re.compile(l1111l_fd_ (u"ࠨࡶ࡬ࡸࡱ࡫࠽࡜ࠤ࡟ࠫࡢ࠮࠮ࠫࡁࠬ࡟ࠧࡢࠧ࡞ࠩੂ")).findall(item)
        info = re.compile(l1111l_fd_ (u"ࠩ࠿ࡨ࡮ࡼ࡜ࡴ࠭ࡦࡰࡦࡹࡳ࠾࡝ࠥࡠࠬࡣࡳࡪࡼࡨ࡟ࠧࡢࠧ࡞࡝ࡡࡂࡢ࠰࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ੃"),re.DOTALL).findall(item)
        if href and title:
            id = re.search(l1111l_fd_ (u"ࠪ࠰࡫࠳ࠨ࡝ࡦ࠮࠭ࠬ੄"),href[0])
            if id:
                url=l1111l_fd_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡫ࡸࡥࡦࡦ࡬ࡷࡨ࠴ࡰ࡭࠱ࡨࡱࡧ࡫ࡤ࠰ࡸ࡬ࡨࡪࡵ࠯ࠨ੅")+id.group(1)
                l111ll11l_fd_ = False
            else:
                url = l11lll1ll_fd_ + l1111l_fd_ (u"ࠬ࠵ࠧ੆") if not href[0].startswith(l1111l_fd_ (u"࠭࠯ࠨੇ")) else l11lll1ll_fd_
                url = url + href[0]
                l111ll11l_fd_ = True if re.search(l1111l_fd_ (u"ࠧ࠭ࡦ࠰ࡠࡩ࠱ࠧੈ"),url) else False
            title = l11l111ll_fd_(title[0])
            if info:
                title +=l1111l_fd_ (u"ࠨࠢ࡞ࡇࡔࡒࡏࡓࠢ࡯࡭࡬࡮ࡴࡣ࡮ࡸࡩࡢࠫࡳ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ੉")%(info[0].strip())
            l11l11l1l_fd_ = l11l11l1l_fd_[0] if l11l11l1l_fd_ else l1111l_fd_ (u"ࠩࠪ੊")
            if l11l11l1l_fd_.startswith(l1111l_fd_ (u"ࠪ࠳ࠬੋ")):
                l11l11l1l_fd_ = l11lll1ll_fd_ + l11l11l1l_fd_
            l1l111l1l_fd_ = {l1111l_fd_ (u"ࠫ࡭ࡸࡥࡧࠩੌ")   : url,
                   l1111l_fd_ (u"ࠬࡺࡩࡵ࡮ࡨ੍ࠫ") : l11l111ll_fd_(title.strip()),
                   l1111l_fd_ (u"࠭ࡩ࡮ࡩࠪ੎") : l11l11l1l_fd_,
                   l1111l_fd_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ੏"): l111ll11l_fd_,
                   }
            out.append(l1l111l1l_fd_)
    return out
def _11l11ll1_fd_(l11l1l1ll_fd_,content):
    l11l1l1ll_fd_.append( (-1,-1) )
    out=[]
    for i in range(len(l11l1l1ll_fd_[:-1])):
        item = content[ l11l1l1ll_fd_[i][1]:l11l1l1ll_fd_[i+1][0] ]
        href = re.compile(l1111l_fd_ (u"ࠨࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠩ੐")).findall(item)
        l11l11l1l_fd_ = re.compile(l1111l_fd_ (u"ࠩ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࡠࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢࠦࡡ࡭ࡶࡀ࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࠬੑ")).findall(item)
        if href and l11l11l1l_fd_:
            l1l111l1l_fd_ = {l1111l_fd_ (u"ࠪ࡬ࡷ࡫ࡦࠨ੒")   : l11lll1ll_fd_+href[0],
                   l1111l_fd_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ੓") : l11l111ll_fd_(l11l11l1l_fd_[0][1]).strip(),
                   l1111l_fd_ (u"ࠬ࡯࡭ࡨࠩ੔") : l11l11l1l_fd_[0][0],
                   l1111l_fd_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭੕"): True,
                }
            out.append(l1l111l1l_fd_)
    return out
def _111llll1_fd_(l11l1l1ll_fd_,content):
    l11l1l1ll_fd_.append( (-1,-1) )
    out=[]
    for i in range(len(l11l1l1ll_fd_[:-1])):
        item = content[ l11l1l1ll_fd_[i][1]:l11l1l1ll_fd_[i+1][0] ]
        href = re.compile(l1111l_fd_ (u"ࠧࡩࡴࡨࡪࡂࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣࠧ੖")).findall(item)
        l11l11l1l_fd_ = re.compile(l1111l_fd_ (u"ࠨ࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀ࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࠬ੗")).findall(item)
        title = re.compile(l1111l_fd_ (u"ࠩ࠿ࡥࠥࡺࡩࡵ࡮ࡨࡁࡠࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢ࠭੘")).findall(item)
        if href and title:
            l1l111l1l_fd_ = {l1111l_fd_ (u"ࠪ࡬ࡷ࡫ࡦࠨਖ਼")   : l11lll1ll_fd_+href[0],
                   l1111l_fd_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪਗ਼") : l11l111ll_fd_(title[0]).strip(),
                   l1111l_fd_ (u"ࠬ࡯࡭ࡨࠩਜ਼") : l11l11l1l_fd_[0],
                   l1111l_fd_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ੜ"): False,
                   }
            out.append(l1l111l1l_fd_)
    return out
def _111lll1l_fd_(l11l1l1ll_fd_,content):
    l11l1l1ll_fd_.append( (-1,-1) )
    out=[]
    for i in range(len(l11l1l1ll_fd_[:-1])):
        item = content[ l11l1l1ll_fd_[i][1]:l11l1l1ll_fd_[i+1][0] ]
        href = re.compile(l1111l_fd_ (u"ࠧ࠽ࡣ࡟ࡷ࠰࡮ࡲࡦࡨࡀ࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࠬ੝")).findall(item)
        title = re.compile(l1111l_fd_ (u"ࠨ࠾ࡤࡠࡸ࠱ࡨࡳࡧࡩࡁࡠࡤ࠾࡞࠭ࡁࠬ࠳࠰࠿ࠪ࠾ࠪਫ਼"),re.DOTALL).findall(item)
        id = re.compile(l1111l_fd_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃ࡛ࠣ࡞ࠪࡡࡩࡧࡴࡢ࡝ࠥࡠࠬࡣ࡜ࡴ࠭࡬ࡨࡂࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣ࡜ࡴࠬࡁࠫ੟")).findall(item)
        l11l11l1l_fd_ = re.compile(l1111l_fd_ (u"ࠪࡷࡷࡩ࡜ࡴࠬࡀࡠࡸ࠰࡛ࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝ࠨ੠")).findall(item)
        info = re.compile(l1111l_fd_ (u"ࠫࡁࡪࡩࡷ࡞ࡶ࠯ࡨࡲࡡࡴࡵࡀ࡟ࠧࡢࠧ࡞࡫ࡱࡪࡴࡡࠢ࡝ࠩࡠ࡟ࡣࡄ࡝ࠫࡀࠫ࠲࠯ࡅࠩ࠽ࠩ੡")).findall(item)
        if href and title:
            if id:
                url=l1111l_fd_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡬ࡲࡦࡧࡧ࡭ࡸࡩ࠮ࡱ࡮࠲ࡩࡲࡨࡥࡥ࠱ࡹ࡭ࡩ࡫࡯࠰ࠩ੢")+id[0].split(l1111l_fd_ (u"࠭࠭ࠨ੣"))[-1]
                l111ll11l_fd_ = False
            else:
                url = l11lll1ll_fd_ + l1111l_fd_ (u"ࠧ࠰ࠩ੤") if not href[0].startswith(l1111l_fd_ (u"ࠨ࠱ࠪ੥")) else l11lll1ll_fd_
                url = url + href[0]
                l111ll11l_fd_ = True if re.search(l1111l_fd_ (u"ࠩ࠯ࡨ࠲ࡢࡤࠬࠩ੦"),url) else False
            title = l11l111ll_fd_(title[0]).strip()
            if info:
                title +=l1111l_fd_ (u"ࠪࠤࡠࡉࡏࡍࡑࡕࠤࡱ࡯ࡧࡩࡶࡥࡰࡺ࡫࡝ࠦࡵ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ੧")%(info[0])
            l11l11l1l_fd_ = l11l11l1l_fd_[0] if l11l11l1l_fd_ else l1111l_fd_ (u"ࠫࠬ੨")
            if l11l11l1l_fd_.startswith(l1111l_fd_ (u"ࠬ࠵ࠧ੩")):
                l11l11l1l_fd_ = l11lll1ll_fd_ + l11l11l1l_fd_
            l1l111l1l_fd_ = {l1111l_fd_ (u"࠭ࡨࡳࡧࡩࠫ੪")   : url,
                   l1111l_fd_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭੫") : l11l111ll_fd_(title.strip()),
                   l1111l_fd_ (u"ࠨ࡫ࡰ࡫ࠬ੬") : l11l11l1l_fd_,
                   l1111l_fd_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ੭"): l111ll11l_fd_,
                   }
            out.append(l1l111l1l_fd_)
    return out
url=l1111l_fd_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡪࡷ࡫ࡥࡥ࡫ࡶࡧ࠳ࡶ࡬࠰ࡆࡵࡥࡧ࡫ࡸ࠶࠸࠯ࡨ࠲࠸࠳࠶࠵࠶࠴࠽࠲ࡢࡢ࡬࡮࡭ࠬ੮")
url=l1111l_fd_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡫ࡸࡥࡦࡦ࡬ࡷࡨ࠴ࡰ࡭࠱ࡇࡶࡦࡨࡥࡹ࠷࠹࠳࡫ࡧࡶࡰࡷࡵ࡭ࡹ࡫ࡳࠨ੯")
def l11l_fd_(url):
    out=[]
    content=l1ll1ll_fd_(url)
    l111l11l1_fd_ = re.compile(l1111l_fd_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿࡞ࠦࡡ࠭࡝ࡤࡱࡱࡸࡪࡴࡴ࠮ࡧ࡯ࡩࡲ࡫࡮ࡵࠢࡳࡥࡩࡪࡩ࡯ࡩ࠰࠹ࡠࡤࠢ࡝ࠩࡠ࠯ࡠࠨ࡜ࠨ࡟ࡁࠬ࠳࠰࠿࠽࠱ࡧ࡭ࡻࡄࠩ࠽࠱ࡧ࡭ࡻࡄࠧੰ"),re.DOTALL).findall(content)
    l11l1l11l_fd_ = [(a.start(), a.end()) for a in re.finditer(l1111l_fd_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦ࡫ࡸࡩࡦࡰࡧࡷ࠲࡯ࡴࡦ࡯ࠣ࡬ࡴࡼࡥࡳࠢࡳࡥࡩࡪࡩ࡯ࡩ࠰࠹ࠥࡵࡶࡦࡴࡩࡰࡴࡽ࠭ࡢࠤࡁࠫੱ"), content)]
    l111lll11_fd_ = [(a.start(), a.end()) for a in re.finditer(l1111l_fd_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡽ࠭࠲࠲࠳࠱ࡵࠦ࡯ࡷࡧࡵࡪࡱࡵࡷ࠮ࡣࠣ࡬ࡴࡼࡥࡳࠢࡰࡥࡷ࡭ࡩ࡯࠯ࡷ࠱ࡲ࡯࡮ࡶࡵ࠰࠵ࠧࠦࡳࡵࡻ࡯ࡩࡂࠨࡢࡰࡴࡧࡩࡷ࠳ࡢࡰࡶࡷࡳࡲࡀࠠ࠲ࡲࡻࠤࡸࡵ࡬ࡪࡦࠣ࠲ࡩ࡬ࡥ࠱ࡦࡩ࠿ࡧࡵࡲࡥࡧࡵ࠱ࡹࡵࡰ࠻ࠢ࠴ࡴࡽࠦࡳࡰ࡮࡬ࡨࠥ࠴ࡤࡧࡧ࠳ࡨ࡫ࡁࠢ࠿ࠩੲ"), content)]
    l111ll111_fd_ = [(a.start(), a.end()) for a in re.finditer(l1111l_fd_ (u"ࠨ࠾ࡧ࡭ࡻࡢࡳࠬࡥ࡯ࡥࡸࡹ࠽ࠣࡦ࡬ࡶ࠲࡯ࡴࡦ࡯ࠥࡂࠬੳ"), content)]
    l11l1111l_fd_ = [(a.start(), a.end()) for a in re.finditer(l1111l_fd_ (u"ࠩ࠿ࡨ࡮ࡼ࡜ࡴ࠭ࡦࡰࡦࡹࡳ࠾࡝ࠥࡠࠬࡣࡣࡰࡰࡷࡩࡳࡺ࠭ࡦ࡮ࡨࡱࡪࡴࡴࠡࡲࡤࡨࡩ࡯࡮ࡨ࠯࠸࡟ࡣࠨ࡜ࠨ࡟࠮࡟ࠧࡢࠧ࡞࡞ࡶ࠮ࡃ࠭ੴ"), content)]
    if l11l1l11l_fd_:
        out = _11l11ll1_fd_(l11l1l11l_fd_,content)
    elif l111lll11_fd_:
        out = _111llll1_fd_(l111lll11_fd_,content)
        l11l11111_fd_ = re.compile(l1111l_fd_ (u"ࠪࡀࡦࠦࡣ࡭ࡣࡶࡷࡂࡡࠢ࡝ࠩࡠࡱࡪࡴࡵ࠮ࡵࡼࡷࡹ࡫࡭࡜ࠤ࡟ࠫࡢࠦࡨࡳࡧࡩࡁࡠࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢࡄࠧੵ")).findall(content)
        if l11l11111_fd_:
            l111l11ll_fd_ = {l1111l_fd_ (u"ࠫ࡭ࡸࡥࡧࠩ੶"):l11lll1ll_fd_+l11l11111_fd_[0],l1111l_fd_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ੷"):l1111l_fd_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࡠ࡙ࡹࡴࡶࡨࡱࠥࡖ࡬ࡪ࡭ࣶࡻࡢࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ੸"),l1111l_fd_ (u"ࠧࡪ࡯ࡪࠫ੹"):l1111l_fd_ (u"ࠨࠩ੺"),l1111l_fd_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ੻"):True}
            out.insert(0,l111l11ll_fd_)
        l111ll1ll_fd_ = re.compile(l1111l_fd_ (u"ࠪࡀࡦࠦࡣ࡭ࡣࡶࡷࡂࡡࠢ࡝ࠩࡠࡱࡪࡴࡵ࠮ࡨࡤࡺࡠࠨ࡜ࠨ࡟ࠣ࡬ࡷ࡫ࡦ࠾࡝ࠥࡠࠬࡣࠨ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟ࡁࠫ੼")).findall(content)
        if l111ll1ll_fd_:
            l111l11ll_fd_ = {l1111l_fd_ (u"ࠫ࡭ࡸࡥࡧࠩ੽"):l11lll1ll_fd_+l111ll1ll_fd_[0],l1111l_fd_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ੾"):l1111l_fd_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࡠ࡛࡬ࡶࡤ࡬ࡳࡳ࡫࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ੿"),l1111l_fd_ (u"ࠧࡪ࡯ࡪࠫ઀"):l1111l_fd_ (u"ࠨࠩઁ"),l1111l_fd_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩં"):True}
            out.insert(1,l111l11ll_fd_)
    elif l111ll111_fd_:
        out = _111lll1l_fd_(l111ll111_fd_,content)
    elif l11l1111l_fd_:
        out = _11l11l11_fd_(l11l1111l_fd_,content)
    return out
def search(l11l1l111_fd_=l1111l_fd_ (u"ࠪࡾ࡮ࡵ࡭ࡦ࡭࠺࠶ࠬઃ"),l111l111l_fd_=l1111l_fd_ (u"ࠫࡩࡧࡴࡢࡡࡩ࡭ࡱ࡫ࡳࠨ઄")):
    out=[]
    url=l1111l_fd_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡬ࡲࡦࡧࡧ࡭ࡸࡩ࠮ࡱ࡮࠲ࡷࡪࡧࡲࡤࡪ࠲࡫ࡪࡺࠧઅ")
    l11l11lll_fd_ = {l1111l_fd_ (u"ࠨࡳࡦࡣࡵࡧ࡭ࡥࡰࡩࡴࡤࡷࡪࠨઆ"):l11l1l111_fd_,l1111l_fd_ (u"ࠢࡴࡧࡤࡶࡨ࡮࡟ࡵࡻࡳࡩࠧઇ"):l1111l_fd_ (u"ࠣ࡯ࡲࡺ࡮࡫ࡳࠣઈ"),l1111l_fd_ (u"ࠤࡶࡩࡦࡸࡣࡩࡡࡶࡥࡻ࡫ࡤࠣઉ"):0,l1111l_fd_ (u"ࠥࡴࡦ࡭ࡥࡴࠤઊ"):1,l1111l_fd_ (u"ࠦࡱ࡯࡭ࡪࡶࠥઋ"):150}
    headers= {l1111l_fd_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩઌ"):l1111l_fd_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠺࠸࠯࠲࠱࠶࠺࠼࠴࠯࠻࠺ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫઍ"),
            l1111l_fd_ (u"࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪ઎"):l1111l_fd_ (u"ࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩએ")}
    content=l1ll1ll_fd_(url,data=json.dumps(l11l11lll_fd_),headers=headers)
    if content:
        data=json.loads(content)
        l111lllll_fd_ = data.get(l1111l_fd_ (u"ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫઐ"),{}).get(l111l111l_fd_,{}).get(l1111l_fd_ (u"ࠪࡨࡦࡺࡡࠨઑ"),[])
        for item in l111lllll_fd_:
            l1l111l1l_fd_ = {l1111l_fd_ (u"ࠫ࡭ࡸࡥࡧࠩ઒")  : l1111l_fd_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡬ࡲࡦࡧࡧ࡭ࡸࡩ࠮ࡱ࡮࠲ࡩࡲࡨࡥࡥ࠱ࡹ࡭ࡩ࡫࡯࠰ࠩઓ")+item.get(l1111l_fd_ (u"࠭ࡩࡥࠩઔ"),l1111l_fd_ (u"ࠧࠨક")),
                   l1111l_fd_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧખ") : l11l111ll_fd_(item.get(l1111l_fd_ (u"ࠩࡱࡥࡲ࡫ࠧગ"),l1111l_fd_ (u"ࠪࠫઘ")).encode(l1111l_fd_ (u"ࠫࡺࡺࡦ࠮࠺ࠪઙ"))).replace(l1111l_fd_ (u"ࠬ࠭ચ"),l1111l_fd_ (u"࠭ࠧછ")),
                   l1111l_fd_ (u"ࠧࡪ࡯ࡪࠫજ") : l1111l_fd_ (u"ࠨࠩઝ"),
                   l1111l_fd_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩઞ"): l1111l_fd_ (u"ࠪࠫટ"),
                   l1111l_fd_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭ઠ"): item.get(l1111l_fd_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧડ"),l1111l_fd_ (u"࠭ࠧઢ")),
                   l1111l_fd_ (u"ࠧࡱ࡮ࡲࡸࠬણ") : l1111l_fd_ (u"ࠨࠩત"),
                   }
            if l1l111l1l_fd_.get(l1111l_fd_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩથ")):
                l1l111l1l_fd_[l1111l_fd_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩદ")] = l1111l_fd_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟ࠨࡷࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࠭ࠡ࡝ࡆࡓࡑࡕࡒࠡࡩࡵࡩࡪࡴ࡝ࠦࡵ࡞࠳ࡈࡕࡌࡐࡔࡠࠫધ") %(l1l111l1l_fd_[l1111l_fd_ (u"ࠬࡺࡩࡵ࡮ࡨࠫન")], l1l111l1l_fd_.get(l1111l_fd_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭઩")))
            out.append(l1l111l1l_fd_)
    return out
def l11l1l1_fd_(url):
    l1111l_fd_ (u"ࠢࠣࠤࠣࠤࠥࠦࠍࠋࠢࠣࠤࠥࡸࡥࡵࡷࡵࡲࡸࠦࠍࠋࠢࠣࠤࠥࠦࠠࠡࠢ࠰ࠤࡺࡲࡲࠡࡪࡷࡸࡵࡀ࠯࠰࠰࠱࠲࠳ࠓࠊࠡࠢࠣࠤࠧࠨࠢપ")
    l11ll1l11_fd_=l1111l_fd_ (u"ࠨࠩફ")
    if not l1111l_fd_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠱ࠪબ") in url:
        content = l1ll1ll_fd_(url)
        l111l1l1l_fd_ = re.compile(l1111l_fd_ (u"ࠪࡀ࡮࡬ࡲࡢ࡯ࡨࡠࡸ࠱ࡳࡳࡥࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴࡬ࡲࡦࡧࡧ࡭ࡸࡩ࠮ࡱ࡮࠲ࡩࡲࡨࡥࡥ࠱ࡹ࡭ࡩ࡫࡯࠰࠰࠭ࡃ࠮ࠨࠧભ")).findall(content)
        if l111l1l1l_fd_:
            url = l111l1l1l_fd_[0]
    content = l1ll1ll_fd_(url)
    data = re.compile(l1111l_fd_ (u"ࠫࡁࡲࡩ࡯࡭ࠣࡶࡪࡲ࠽ࠣࡸ࡬ࡨࡪࡵ࡟ࡴࡴࡦࠦࠥ࠴ࠫࡀࠢ࡫ࡶࡪ࡬࠽࡜ࠤ࡟ࠫࡢ࠮࠮ࠫࠫ࡞ࠦࡡ࠭࡝ࠡ࠱ࡁࠫમ")).findall(content)
    if data:
        data = data[0]
        file = re.search(l1111l_fd_ (u"ࠬ࡬ࡩ࡭ࡧࡀࠬ࡭ࡺࡴࡱࠪࡶ࠭࠯ࡀ࠯࠰࡝ࡡࠦࡡ࠭࡝ࠬࠫࠪય"),data)
        if file:
            l11ll1l11_fd_=file.group(1)+l1111l_fd_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩર")+url +l1111l_fd_ (u"ࠧࠡࡵࡺࡪ࡚ࡸ࡬࠾ࡪࡷࡸࡵࡀ࠯࠰ࡪࡷࡸࡵࡀ࠯࠰ࡨࡵࡩࡪࡪࡩࡴࡥ࠱ࡴࡱ࠵ࡳࡵࡣࡷ࡭ࡨ࠵ࡰ࡭ࡣࡼࡩࡷ࠵ࡶ࠶࠺࠲ࡴࡱࡧࡹࡦࡴ࠱ࡷࡼ࡬ࠧ઱")
            l11ll1l11_fd_=file.group(1)+l1111l_fd_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࡿࢂࠬࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࡀࡿࢂ࠭લ").format(url,l111l1lll_fd_)
    return l11ll1l11_fd_
def l111111_fd_(m):
    l111l1_fd_ = m.group(1)
    if l111l1_fd_.startswith(l1111l_fd_ (u"ࠩࡻࠫળ")):
        return unichr(int(l111l1_fd_[1:],16))
    try:
        return unichr(int(l111l1_fd_))
    except Exception, l11l11l_fd_:
        if l111l1_fd_ in htmlentitydefs.name2codepoint:
            return unichr(htmlentitydefs.name2codepoint[l111l1_fd_])
        else:
            return l111l1_fd_
def html_entity_decode(string):
    string = string.decode(l1111l_fd_ (u"࡙࡙ࠪࡌ࠭࠹ࠩ઴"))
    s = re.compile(l1111l_fd_ (u"ࠦࠫ࠴࠿ࠩ࡞ࡺ࠯ࡄ࠯࠻ࠣવ")).sub(l111111_fd_, string)
    return s.encode(l1111l_fd_ (u"࡛ࠬࡔࡇ࠯࠻ࠫશ"))
def l11l111ll_fd_(l11l1l111_fd_):
    l11l1l111_fd_ = html_entity_decode(l11l1l111_fd_)
    if type(l11l1l111_fd_) is not str:
        l11l1l111_fd_=l11l1l111_fd_.encode(l1111l_fd_ (u"࠭ࡵࡵࡨ࠰࠼ࠬષ"))
    s=l1111l_fd_ (u"ࠧࡋ࡫ࡑࡧ࡟ࡉࡳ࠸ࠩસ")
    l11l1l111_fd_ = re.sub(s.decode(l1111l_fd_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨહ")),l1111l_fd_ (u"ࠩࠪ઺"),l11l1l111_fd_)
    l11l1l111_fd_ = l11l1l111_fd_.replace(l1111l_fd_ (u"ࠪࠪࡱࡺ࠻ࡩ࠷ࠩ࡫ࡹࡁࠧ઻"),l1111l_fd_ (u"઼ࠫࠬ"))
    l11l1l111_fd_ = l11l1l111_fd_.replace(l1111l_fd_ (u"ࠬࠬ࡬ࡵ࠽࠲࡬࠺ࠬࡧࡵ࠽ࠪઽ"),l1111l_fd_ (u"࠭ࠧા"))
    l11l1l111_fd_ = l11l1l111_fd_.replace(l1111l_fd_ (u"ࠧࠧࡰࡥࡷࡵࡁࠧિ"),l1111l_fd_ (u"ࠨࠩી"))
    l11l1l111_fd_ = l11l1l111_fd_.replace(l1111l_fd_ (u"ࠩࠩࡰࡹࡁࡢࡳ࠱ࠩ࡫ࡹࡁࠧુ"),l1111l_fd_ (u"ࠪࠤࠬૂ"))
    l11l1l111_fd_ = l11l1l111_fd_.replace(l1111l_fd_ (u"ࠫࠫࡷࡵࡰࡶ࠾ࠫૃ"),l1111l_fd_ (u"ࠬࠨࠧૄ")).replace(l1111l_fd_ (u"࠭ࠦࡢ࡯ࡳ࠿ࡶࡻ࡯ࡵ࠽ࠪૅ"),l1111l_fd_ (u"ࠧࠣࠩ૆"))
    l11l1l111_fd_ = l11l1l111_fd_.replace(l1111l_fd_ (u"ࠨࠨࡲࡥࡨࡻࡴࡦ࠽ࠪે"),l1111l_fd_ (u"ࣶࠩࠫૈ")).replace(l1111l_fd_ (u"ࠪࠪࡔࡧࡣࡶࡶࡨ࠿ࠬૉ"),l1111l_fd_ (u"ࠫࣘ࠭૊"))
    l11l1l111_fd_ = l11l1l111_fd_.replace(l1111l_fd_ (u"ࠬࠬࡡ࡮ࡲ࠾ࡳࡦࡩࡵࡵࡧ࠾ࠫો"),l1111l_fd_ (u"࠭ࣳࠨૌ")).replace(l1111l_fd_ (u"ࠧࠧࡣࡰࡴࡀࡕࡡࡤࡷࡷࡩࡀ્࠭"),l1111l_fd_ (u"ࠨࣕࠪ૎"))
    l11l1l111_fd_ = l11l1l111_fd_.replace(l1111l_fd_ (u"ࠩ࡟ࡹ࠵࠷࠰࠶ࠩ૏"),l1111l_fd_ (u"ࠪउࠬૐ")).replace(l1111l_fd_ (u"ࠫࡡࡻ࠰࠲࠲࠷ࠫ૑"),l1111l_fd_ (u"ࠬऊࠧ૒"))
    l11l1l111_fd_ = l11l1l111_fd_.replace(l1111l_fd_ (u"࠭࡜ࡶ࠲࠴࠴࠼࠭૓"),l1111l_fd_ (u"ࠧईࠩ૔")).replace(l1111l_fd_ (u"ࠨ࡞ࡸ࠴࠶࠶࠶ࠨ૕"),l1111l_fd_ (u"ࠩउࠫ૖"))
    l11l1l111_fd_ = l11l1l111_fd_.replace(l1111l_fd_ (u"ࠪࡠࡺ࠶࠱࠲࠻ࠪ૗"),l1111l_fd_ (u"ࠫञ࠭૘")).replace(l1111l_fd_ (u"ࠬࡢࡵ࠱࠳࠴࠼ࠬ૙"),l1111l_fd_ (u"࠭घࠨ૚"))
    l11l1l111_fd_ = l11l1l111_fd_.replace(l1111l_fd_ (u"ࠧ࡝ࡷ࠳࠵࠹࠸ࠧ૛"),l1111l_fd_ (u"ࠨॄࠪ૜")).replace(l1111l_fd_ (u"ࠩ࡟ࡹ࠵࠷࠴࠲ࠩ૝"),l1111l_fd_ (u"ࠪॅࠬ૞"))
    l11l1l111_fd_ = l11l1l111_fd_.replace(l1111l_fd_ (u"ࠫࡡࡻ࠰࠲࠶࠷ࠫ૟"),l1111l_fd_ (u"ࠬॊࠧૠ")).replace(l1111l_fd_ (u"࠭࡜ࡶ࠲࠴࠸࠹࠭ૡ"),l1111l_fd_ (u"ࠧॄࠩૢ"))
    l11l1l111_fd_ = l11l1l111_fd_.replace(l1111l_fd_ (u"ࠨ࡞ࡸ࠴࠵࡬࠳ࠨૣ"),l1111l_fd_ (u"ࣶࠩࠫ૤")).replace(l1111l_fd_ (u"ࠪࡠࡺ࠶࠰ࡥ࠵ࠪ૥"),l1111l_fd_ (u"ࠫࣘ࠭૦"))
    l11l1l111_fd_ = l11l1l111_fd_.replace(l1111l_fd_ (u"ࠬࡢࡵ࠱࠳࠸ࡦࠬ૧"),l1111l_fd_ (u"࠭ज़ࠨ૨")).replace(l1111l_fd_ (u"ࠧ࡝ࡷ࠳࠵࠺ࡧࠧ૩"),l1111l_fd_ (u"ࠨड़ࠪ૪"))
    l11l1l111_fd_ = l11l1l111_fd_.replace(l1111l_fd_ (u"ࠩ࡟ࡹ࠵࠷࠷ࡢࠩ૫"),l1111l_fd_ (u"ࠪॾࠬ૬")).replace(l1111l_fd_ (u"ࠫࡡࡻ࠰࠲࠹࠼ࠫ૭"),l1111l_fd_ (u"ࠬॿࠧ૮"))
    l11l1l111_fd_ = l11l1l111_fd_.replace(l1111l_fd_ (u"࠭࡜ࡶ࠲࠴࠻ࡨ࠭૯"),l1111l_fd_ (u"ࠧॽࠩ૰")).replace(l1111l_fd_ (u"ࠨ࡞ࡸ࠴࠶࠽ࡢࠨ૱"),l1111l_fd_ (u"ࠩॾࠫ૲"))
    return l11l1l111_fd_
