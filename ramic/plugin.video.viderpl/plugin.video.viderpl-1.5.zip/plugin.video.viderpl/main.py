# -*- coding: utf-8 -*-
import sys
l1ll111i1i11i1_vr_ = sys.version_info [0] == 2
l1l1l1i1i11i1_vr_ = 2048
l1ll1li1i11i1_vr_ = 7
def l1llll1i1i11i1_vr_ (l1i1i11i1_vr_):
	global l1l1ll1i1i11i1_vr_
	l1lll11li1i11i1_vr_ = ord (l1i1i11i1_vr_ [-1])
	l1ll11li1i11i1_vr_ = l1i1i11i1_vr_ [:-1]
	l1l1li1i11i1_vr_ = l1lll11li1i11i1_vr_ % len (l1ll11li1i11i1_vr_)
	l1l11i1i11i1_vr_ = l1ll11li1i11i1_vr_ [:l1l1li1i11i1_vr_] + l1ll11li1i11i1_vr_ [l1l1li1i11i1_vr_:]
	if l1ll111i1i11i1_vr_:
		l11lllli1i11i1_vr_ = unicode () .join ([unichr (ord (char) - l1l1l1i1i11i1_vr_ - (l11111i1i11i1_vr_ + l1lll11li1i11i1_vr_) % l1ll1li1i11i1_vr_) for l11111i1i11i1_vr_, char in enumerate (l1l11i1i11i1_vr_)])
	else:
		l11lllli1i11i1_vr_ = str () .join ([chr (ord (char) - l1l1l1i1i11i1_vr_ - (l11111i1i11i1_vr_ + l1lll11li1i11i1_vr_) % l1ll1li1i11i1_vr_) for l11111i1i11i1_vr_, char in enumerate (l1l11i1i11i1_vr_)])
	return eval (l11lllli1i11i1_vr_)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import json, htmlentitydefs
import time
try:
   import StorageServer
except:
   import storageserverdummy as StorageServer
cache = StorageServer.StorageServer(l1llll1i1i11i1_vr_ (u"ࠦࡻ࡯ࡤࡦࡴࡳࡰࠧࠀ"))
import resources.lib.l11l1i1i11i1_vr_ as l11li1i11i1_vr_
l11l11i1i11i1_vr_        = sys.argv[0]
l1l1l1li1i11i1_vr_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l1ll1l11i1i11i1_vr_        = xbmcaddon.Addon()
l1ll11lli1i11i1_vr_     = l1ll1l11i1i11i1_vr_.getAddonInfo(l1llll1i1i11i1_vr_ (u"ࠬ࡯ࡤࠨࠁ"))
l1lli1i11i1_vr_       = l1ll1l11i1i11i1_vr_.getAddonInfo(l1llll1i1i11i1_vr_ (u"࠭࡮ࡢ࡯ࡨࠫࠂ"))
PATH        = l1ll1l11i1i11i1_vr_.getAddonInfo(l1llll1i1i11i1_vr_ (u"ࠧࡱࡣࡷ࡬ࠬࠃ"))
l1l1l11i1i11i1_vr_    = xbmc.translatePath(l1ll1l11i1i11i1_vr_.getAddonInfo(l1llll1i1i11i1_vr_ (u"ࠨࡲࡵࡳ࡫࡯࡬ࡦࠩࠄ"))).decode(l1llll1i1i11i1_vr_ (u"ࠩࡸࡸ࡫࠳࠸ࠨࠅ"))
l111ll1i1i11i1_vr_   = PATH+l1llll1i1i11i1_vr_ (u"ࠪ࠳ࡷ࡫ࡳࡰࡷࡵࡧࡪࡹ࠯ࠨࠆ")
l1lllll1i1i11i1_vr_      = None
l11l1li1i11i1_vr_    = os.path.join(l1l1l11i1i11i1_vr_,l1llll1i1i11i1_vr_ (u"ࠫ࡫ࡧࡶࡰࡴ࡬ࡸࡪࡹ࠮࡫ࡵࡲࡲࠬࠇ"))
def l1l1llli1i11i1_vr_(url,data=None):
    req = urllib2.Request(url,data)
    req.add_header(l1llll1i1i11i1_vr_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩࠈ"), l1llll1i1i11i1_vr_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠺࠸࠯࠲࠱࠶࠺࠼࠴࠯࠻࠺ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫࠉ"))
    response = urllib2.urlopen(req)
    l11l1lli1i11i1_vr_ = response.read()
    response.close()
    return l11l1lli1i11i1_vr_
def l1l111li1i11i1_vr_(name, url, mode, l1ll1111i1i11i1_vr_=1, l11ll1i1i11i1_vr_=None, infoLabels=False, contextO=[l1llll1i1i11i1_vr_ (u"ࠧࡇࡡࡄࡈࡉ࠭ࠊ")], IsPlayable=True,fanart=l1lllll1i1i11i1_vr_,l1lll11i1i11i1_vr_=1):
    u = l111llli1i11i1_vr_({l1llll1i1i11i1_vr_ (u"ࠨ࡯ࡲࡨࡪ࠭ࠋ"): mode, l1llll1i1i11i1_vr_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭ࠌ"): name, l1llll1i1i11i1_vr_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫࠍ") : url, l1llll1i1i11i1_vr_ (u"ࠫࡵࡧࡧࡦࠩࠎ"):l1ll1111i1i11i1_vr_})
    if l11ll1i1i11i1_vr_==None:
        l11ll1i1i11i1_vr_=l1llll1i1i11i1_vr_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹࡌ࡯࡭ࡦࡨࡶ࠳ࡶ࡮ࡨࠩࠏ")
    l1ll1l1i1i11i1_vr_ = xbmcgui.ListItem(name, iconImage=l11ll1i1i11i1_vr_, thumbnailImage=l11ll1i1i11i1_vr_)
    if not infoLabels:
        infoLabels={l1llll1i1i11i1_vr_ (u"ࠨࡴࡪࡶ࡯ࡩࠧࠐ"): name}
    l1ll1l1i1i11i1_vr_.setInfo(type=l1llll1i1i11i1_vr_ (u"ࠢࡷ࡫ࡧࡩࡴࠨࠑ"), infoLabels=infoLabels)
    if IsPlayable:
        l1ll1l1i1i11i1_vr_.setProperty(l1llll1i1i11i1_vr_ (u"ࠨࡋࡶࡔࡱࡧࡹࡢࡤ࡯ࡩࠬࠒ"), l1llll1i1i11i1_vr_ (u"ࠩࡷࡶࡺ࡫ࠧࠓ"))
    if fanart:
        l1ll1l1i1i11i1_vr_.setProperty(l1llll1i1i11i1_vr_ (u"ࠪࡪࡦࡴࡡࡳࡶࡢ࡭ࡲࡧࡧࡦࠩࠔ"),fanart)
    l1l111i1i11i1_vr_ = []
    l1l111i1i11i1_vr_.append((l1llll1i1i11i1_vr_ (u"ࠫࡎࡴࡦࡰࡴࡰࡥࡨࡰࡡࠨࠕ"), l1llll1i1i11i1_vr_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡅࡨࡺࡩࡰࡰࠫࡍࡳ࡬࡯ࠪࠩࠖ")))
    content=urllib.quote_plus(json.dumps(infoLabels))
    if l1llll1i1i11i1_vr_ (u"࠭ࡆࡠࡃࡇࡈࠬࠗ") in contextO:
        l1l111i1i11i1_vr_.append((l1llll1i1i11i1_vr_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡨࡴࡨࡩࡳࡣࡄࡰࡦࡤ࡮ࠥࡪ࡯࡙ࠡࡼࡦࡷࡧ࡮ࡺࡥ࡫࡟࠴ࡉࡏࡍࡑࡕࡡࠬ࠘"), l1llll1i1i11i1_vr_ (u"ࠨࡔࡸࡲࡕࡲࡵࡨ࡫ࡱࠬࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴࡁࡰࡳࡩ࡫࠽ࡧࡣࡹࡳࡷ࡯ࡴࡦࡵࡄࡈࡉࠬࡥࡹࡡ࡯࡭ࡳࡱ࠽ࠦࡵࠬࠫ࠙")%(l1ll11lli1i11i1_vr_,content)))
    if l1llll1i1i11i1_vr_ (u"ࠩࡉࡣࡗࡋࡍࠨࠚ") in contextO:
        l1l111i1i11i1_vr_.append((l1llll1i1i11i1_vr_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࡖࡵࡸैࠥࢀࠠࡘࡻࡥࡶࡦࡴࡹࡤࡪ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࠛ"), l1llll1i1i11i1_vr_ (u"ࠫࡗࡻ࡮ࡑ࡮ࡸ࡫࡮ࡴࠨࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷࡄࡳ࡯ࡥࡧࡀࡪࡦࡼ࡯ࡳ࡫ࡷࡩࡸࡘࡅࡎࠨࡨࡼࡤࡲࡩ࡯࡭ࡀࠩࡸ࠯ࠧࠜ")%(l1ll11lli1i11i1_vr_,content)))
    if l1llll1i1i11i1_vr_ (u"ࠬࡌ࡟ࡅࡇࡏࠫࠝ") in contextO:
        l1l111i1i11i1_vr_.append((l1llll1i1i11i1_vr_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠ࡙ࡸࡻॄ࡙ࠡࡶࡾࡾࡹࡴ࡬ࡱ࡞࠳ࡈࡕࡌࡐࡔࡠࠫࠞ"), l1llll1i1i11i1_vr_ (u"ࠧࡓࡷࡱࡔࡱࡻࡧࡪࡰࠫࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳࡀ࡯ࡲࡨࡪࡃࡦࡢࡸࡲࡶ࡮ࡺࡥࡴࡔࡈࡑࠫ࡫ࡸࡠ࡮࡬ࡲࡰࡃࡡ࡭࡮ࠬࠫࠟ")%(l1ll11lli1i11i1_vr_)))
    l1ll1l1i1i11i1_vr_.addContextMenuItems(l1l111i1i11i1_vr_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l1l1l1li1i11i1_vr_, url=u, listitem=l1ll1l1i1i11i1_vr_,isFolder=False,totalItems=l1lll11i1i11i1_vr_)
    xbmcplugin.addSortMethod(l1l1l1li1i11i1_vr_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1llll1i1i11i1_vr_ (u"ࠣࠧࡕ࠰࡙ࠥࠫ࠭ࠢࠨࡔࠧࠠ"))
    return ok
def l1111li1i11i1_vr_(name,ex_link=None, l1ll1111i1i11i1_vr_=1, mode=l1llll1i1i11i1_vr_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩࠡ"),iconImage=l1llll1i1i11i1_vr_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧࠢ"), infoLabels=None, fanart=l1lllll1i1i11i1_vr_, contextO=[l1llll1i1i11i1_vr_ (u"ࠫࡋࡥࡁࡅࡆࠪࠣ")], contextmenu=None):
    url = l111llli1i11i1_vr_({l1llll1i1i11i1_vr_ (u"ࠬࡳ࡯ࡥࡧࠪࠤ"): mode, l1llll1i1i11i1_vr_ (u"࠭ࡦࡰ࡮ࡧࡩࡷࡴࡡ࡮ࡧࠪࠥ"): name, l1llll1i1i11i1_vr_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨࠦ") : ex_link, l1llll1i1i11i1_vr_ (u"ࠨࡲࡤ࡫ࡪ࠭ࠧ") : l1ll1111i1i11i1_vr_})
    l111l1i1i11i1_vr_ = xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconImage)
    if infoLabels:
        l111l1i1i11i1_vr_.setInfo(type=l1llll1i1i11i1_vr_ (u"ࠤࡰࡳࡻ࡯ࡥࠣࠨ"), infoLabels=infoLabels)
    if fanart:
        l111l1i1i11i1_vr_.setProperty(l1llll1i1i11i1_vr_ (u"ࠪࡪࡦࡴࡡࡳࡶࡢ࡭ࡲࡧࡧࡦࠩࠩ"), fanart )
    if contextmenu:
        l1l111i1i11i1_vr_=contextmenu
        l111l1i1i11i1_vr_.addContextMenuItems(l1l111i1i11i1_vr_, replaceItems=True)
    else:
        l1l111i1i11i1_vr_ = []
        l1l111i1i11i1_vr_.append((l1llll1i1i11i1_vr_ (u"ࠫࡎࡴࡦࡰࡴࡰࡥࡨࡰࡡࠨࠪ"), l1llll1i1i11i1_vr_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡅࡨࡺࡩࡰࡰࠫࡍࡳ࡬࡯ࠪࠩࠫ")),)
        content=urllib.quote_plus(json.dumps(infoLabels))
        if l1llll1i1i11i1_vr_ (u"࠭ࡆࡠࡃࡇࡈࠬࠬ") in contextO:
            l1l111i1i11i1_vr_.append((l1llll1i1i11i1_vr_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡨࡴࡨࡩࡳࡣࡄࡰࡦࡤ࡮ࠥࡪ࡯࡙ࠡࡼࡦࡷࡧ࡮ࡺࡥ࡫࡟࠴ࡉࡏࡍࡑࡕࡡࠬ࠭"), l1llll1i1i11i1_vr_ (u"ࠨࡔࡸࡲࡕࡲࡵࡨ࡫ࡱࠬࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠥࡴࡁࡰࡳࡩ࡫࠽ࡧࡣࡹࡳࡷ࡯ࡴࡦࡵࡄࡈࡉࠬࡥࡹࡡ࡯࡭ࡳࡱ࠽ࠦࡵࠬࠫ࠮")%(l1ll11lli1i11i1_vr_,content)))
        if l1llll1i1i11i1_vr_ (u"ࠩࡉࡣࡗࡋࡍࠨ࠯") in contextO:
            l1l111i1i11i1_vr_.append((l1llll1i1i11i1_vr_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࡖࡵࡸैࠥࢀࠠࡘࡻࡥࡶࡦࡴࡹࡤࡪ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࠰"), l1llll1i1i11i1_vr_ (u"ࠫࡗࡻ࡮ࡑ࡮ࡸ࡫࡮ࡴࠨࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࠨࡷࡄࡳ࡯ࡥࡧࡀࡪࡦࡼ࡯ࡳ࡫ࡷࡩࡸࡘࡅࡎࠨࡨࡼࡤࡲࡩ࡯࡭ࡀࠩࡸ࠯ࠧ࠱")%(l1ll11lli1i11i1_vr_,content)))
        if l1llll1i1i11i1_vr_ (u"ࠬࡌ࡟ࡅࡇࡏࠫ࠲") in contextO:
            l1l111i1i11i1_vr_.append((l1llll1i1i11i1_vr_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠ࡙ࡸࡻॄ࡙ࠡࡶࡾࡾࡹࡴ࡬ࡱ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࠳"), l1llll1i1i11i1_vr_ (u"ࠧࡓࡷࡱࡔࡱࡻࡧࡪࡰࠫࡴࡱࡻࡧࡪࡰ࠽࠳࠴ࠫࡳࡀ࡯ࡲࡨࡪࡃࡦࡢࡸࡲࡶ࡮ࡺࡥࡴࡔࡈࡑࠫ࡫ࡸࡠ࡮࡬ࡲࡰࡃࡡ࡭࡮ࠬࠫ࠴")%(l1ll11lli1i11i1_vr_)))
        l111l1i1i11i1_vr_.addContextMenuItems(l1l111i1i11i1_vr_, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=l1l1l1li1i11i1_vr_, url=url,listitem=l111l1i1i11i1_vr_, isFolder=True)
    xbmcplugin.addSortMethod(l1l1l1li1i11i1_vr_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l1llll1i1i11i1_vr_ (u"ࠣࠧࡕ࠰࡙ࠥࠫ࠭ࠢࠨࡔࠧ࠵"))
def l11llli1i11i1_vr_(l11l1l1i1i11i1_vr_):
    l11l111i1i11i1_vr_ = {}
    for k, v in l11l1l1i1i11i1_vr_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l1llll1i1i11i1_vr_ (u"ࠩࡸࡸ࡫࠾ࠧ࠶"))
        elif isinstance(v, str):
            v.decode(l1llll1i1i11i1_vr_ (u"ࠪࡹࡹ࡬࠸ࠨ࠷"))
        l11l111i1i11i1_vr_[k] = v
    return l11l111i1i11i1_vr_
def l111llli1i11i1_vr_(query):
    return l11l11i1i11i1_vr_ + l1llll1i1i11i1_vr_ (u"ࠫࡄ࠭࠸") + urllib.urlencode(l11llli1i11i1_vr_(query))
l111li1i11i1_vr_ = lambda x,y: ord(x)+6*y if ord(x)%2 else ord(x)
l1l1i1i11i1_vr_ = lambda l1lllli1i11i1_vr_: l1llll1i1i11i1_vr_ (u"ࠬ࠭࠹").join([chr(l111li1i11i1_vr_(x,1) ) for x in l1lllli1i11i1_vr_.encode(l1llll1i1i11i1_vr_ (u"࠭ࡢࡢࡵࡨ࠺࠹࠭࠺")).strip()])
l1ll111li1i11i1_vr_ = lambda l1lllli1i11i1_vr_: l1llll1i1i11i1_vr_ (u"ࠧࠨ࠻").join([chr(l111li1i11i1_vr_(x,-1) ) for x in l1lllli1i11i1_vr_]).decode(l1llll1i1i11i1_vr_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨ࠼"))
def l1lll111i1i11i1_vr_(m):
    l1llllli1i11i1_vr_ = m.group(1)
    if l1llllli1i11i1_vr_.startswith(l1llll1i1i11i1_vr_ (u"ࠩࡻࠫ࠽")):
        return unichr(int(l1llllli1i11i1_vr_[1:],16))
    try:
        return unichr(int(l1llllli1i11i1_vr_))
    except Exception, l1111lli1i11i1_vr_:
        if l1llllli1i11i1_vr_ in htmlentitydefs.name2codepoint:
            return unichr(htmlentitydefs.name2codepoint[l1llllli1i11i1_vr_])
        else:
            return l1llllli1i11i1_vr_
if not os.path.exists(l1llll1i1i11i1_vr_ (u"ࠪ࠳࡭ࡵ࡭ࡦ࠱ࡲࡷࡲࡩࠧ࠾")):
    tm=time.gmtime()
    try:    l111lli1i11i1_vr_,l1l1111i1i11i1_vr_,l111l11i1i11i1_vr_ = l1ll111li1i11i1_vr_(l1ll1l11i1i11i1_vr_.getSetting(l1llll1i1i11i1_vr_ (u"ࠫࡰࡵࡤࠨ࠿"))).split(l1llll1i1i11i1_vr_ (u"ࠬࡀࠧࡀ"))
    except: l111lli1i11i1_vr_,l1l1111i1i11i1_vr_,l111l11i1i11i1_vr_ =  [l1llll1i1i11i1_vr_ (u"࠭࠭࠲ࠩࡁ"),l1llll1i1i11i1_vr_ (u"ࠧࠨࡂ"),l1llll1i1i11i1_vr_ (u"ࠨ࠯࠴ࠫࡃ")]
    if int(l111lli1i11i1_vr_) != tm.tm_hour:
        try:    l1llli1i11i1_vr_ = re.findall(l1llll1i1i11i1_vr_ (u"ࠩࡎࡓࡉࡀࠠࠩ࠰࠭ࡃ࠮ࡢ࡮ࠨࡄ"),urllib2.urlopen(l1llll1i1i11i1_vr_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡷࡧࡷ࠯ࡩ࡬ࡸ࡭ࡻࡢࡶࡵࡨࡶࡨࡵ࡮ࡵࡧࡱࡸ࠳ࡩ࡯࡮࠱ࡵࡥࡲ࡯ࡣࡴࡲࡤ࠳ࡰࡵࡤࡪ࠱ࡰࡥࡸࡺࡥࡳ࠱ࡕࡉࡆࡊࡍࡆ࠰ࡰࡨࠬࡅ")).read())[0].strip(l1llll1i1i11i1_vr_ (u"ࠫ࠯࠭ࡆ"))
        except: l1llli1i11i1_vr_ = l1llll1i1i11i1_vr_ (u"ࠬ࠭ࡇ")
        l1ll11i1i11i1_vr_ = l1l1i1i11i1_vr_(l1llll1i1i11i1_vr_ (u"ࠧࠦࡦ࠽ࠩࡸࡀࠥࡥࠩࡐ")%(tm.tm_hour,l1llli1i11i1_vr_,tm.tm_min))
        l1ll1l11i1i11i1_vr_.setSetting(l1llll1i1i11i1_vr_ (u"ࠨ࡭ࡲࡨࠬࡑ"),l1ll11i1i11i1_vr_)
def html_entity_decode(string):
    string = string.decode(l1llll1i1i11i1_vr_ (u"ࠩࡘࡘࡋ࠳࠸ࠨࡒ"))
    s = re.compile(l1llll1i1i11i1_vr_ (u"ࠥࠪ࠳ࡅࠨ࡝ࡹ࠮ࡃ࠮ࡁࠢࡓ")).sub(l1lll111i1i11i1_vr_, string)
    return s.encode(l1llll1i1i11i1_vr_ (u"࡚࡚ࠫࡆ࠮࠺ࠪࡔ"))
def l1llll11i1i11i1_vr_(lli1i11i1_vr_):
    content = l1llll1i1i11i1_vr_ (u"ࠬࡡ࡝ࠨࡕ")
    if os.path.exists(lli1i11i1_vr_):
        with open(lli1i11i1_vr_,l1llll1i1i11i1_vr_ (u"࠭ࡲࠨࡖ")) as f:
            content = f.read()
            if not content:
                content =l1llll1i1i11i1_vr_ (u"ࠧ࡜࡟ࠪࡗ")
    data=json.loads(html_entity_decode(content))
    return data
def l1lll1l1i1i11i1_vr_(ex_link):
    if ex_link==l1llll1i1i11i1_vr_ (u"ࠨࡈࡄ࡚ࡔࡘࡉࡕࡇࠪࡘ"):
        items = l1llll11i1i11i1_vr_(l11l1li1i11i1_vr_)
    elif ex_link.startswith(l1llll1i1i11i1_vr_ (u"ࠩࡶࡩࡦࡸࡣࡩ࡙ࠩ")):
        items=l11li1i11i1_vr_.search(ex_link.split(l1llll1i1i11i1_vr_ (u"ࠪࢀ࡚ࠬ"))[-1].strip())
    else:
        items = l11li1i11i1_vr_.l111i1i11i1_vr_(ex_link)
    contextO=[l1llll1i1i11i1_vr_ (u"ࠫࡋࡥࡁࡅࡆ࡛ࠪ")]
    if fname==l1llll1i1i11i1_vr_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡱࡨࡢ࡭࡬ࡡ࡜ࡿࡢࡳࡣࡱࡩࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࡜"):
        contextO=[l1llll1i1i11i1_vr_ (u"࠭ࡆࡠࡔࡈࡑࠬ࡝"),l1llll1i1i11i1_vr_ (u"ࠧࡇࡡࡇࡉࡑ࠭࡞")]
    for item in items:
        if item.get(l1llll1i1i11i1_vr_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࡟")):
            l1111li1i11i1_vr_(name=item.get(l1llll1i1i11i1_vr_ (u"ࠩࡷ࡭ࡹࡲࡥࠨࡠ"),l1llll1i1i11i1_vr_ (u"ࠪࠫࡡ")),ex_link=item.get(l1llll1i1i11i1_vr_ (u"ࠫ࡭ࡸࡥࡧࠩࡢ")), mode=l1llll1i1i11i1_vr_ (u"ࠬࡒࡩࡴࡶࡐࡳࡻ࡯ࡥࡴࠩࡣ"),iconImage=item.get(l1llll1i1i11i1_vr_ (u"࠭ࡩ࡮ࡩࠪࡤ")),infoLabels=item,contextO=contextO)
        else:
            l1l111li1i11i1_vr_(name=item.get(l1llll1i1i11i1_vr_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࡥ")), url=item.get(l1llll1i1i11i1_vr_ (u"ࠨࡪࡵࡩ࡫࠭ࡦ")), mode=l1llll1i1i11i1_vr_ (u"ࠩࡪࡩࡹࡒࡩ࡯࡭ࡶࠫࡧ"), l11ll1i1i11i1_vr_=item.get(l1llll1i1i11i1_vr_ (u"ࠪ࡭ࡲ࡭ࠧࡨ")), infoLabels=item, contextO=contextO, IsPlayable=True)
def l1l11l1i1i11i1_vr_(ex_link):
    l1ll1lli1i11i1_vr_ = l11li1i11i1_vr_.l111l1li1i11i1_vr_(ex_link)
    import resources.lib.l111111i1i11i1_vr_
    if l1ll1lli1i11i1_vr_:
        xbmcplugin.setResolvedUrl(l1l1l1li1i11i1_vr_, True, xbmcgui.ListItem(path=l1ll1lli1i11i1_vr_))
    else:
        xbmcgui.Dialog().ok(l1llll1i1i11i1_vr_ (u"ࠫࡕࡸ࡯ࡣ࡮ࡨࡱࠬࡩ"),l1llll1i1i11i1_vr_ (u"ࠬࡈࡲࡢ࡭ࠣॾࡷࣹࡤृࡣࠪࡪ"))
        xbmcplugin.setResolvedUrl(l1l1l1li1i11i1_vr_, False, xbmcgui.ListItem(path=l1ll1lli1i11i1_vr_))
def l1lll1li1i11i1_vr_():
    return cache.get(l1llll1i1i11i1_vr_ (u"࠭ࡨࡪࡵࡷࡳࡷࡿࠧ࡫")).split(l1llll1i1i11i1_vr_ (u"ࠧ࠼ࠩ࡬"))
def l11ll11i1i11i1_vr_(l11111li1i11i1_vr_):
    l1l1lllli1i11i1_vr_ = l1lll1li1i11i1_vr_()
    if l1l1lllli1i11i1_vr_ == [l1llll1i1i11i1_vr_ (u"ࠨࠩ࡭")]:
        l1l1lllli1i11i1_vr_ = []
    l1l1lllli1i11i1_vr_.insert(0, l11111li1i11i1_vr_)
    cache.set(l1llll1i1i11i1_vr_ (u"ࠩ࡫࡭ࡸࡺ࡯ࡳࡻࠪ࡮"),l1llll1i1i11i1_vr_ (u"ࠪ࠿ࠬ࡯").join(l1l1lllli1i11i1_vr_[:50]))
def l11l11li1i11i1_vr_(l11111li1i11i1_vr_):
    l1l1lllli1i11i1_vr_ = l1lll1li1i11i1_vr_()
    if l1l1lllli1i11i1_vr_:
        cache.set(l1llll1i1i11i1_vr_ (u"ࠫ࡭࡯ࡳࡵࡱࡵࡽࠬࡰ"),l1llll1i1i11i1_vr_ (u"ࠬࡁࠧࡱ").join(l1l1lllli1i11i1_vr_[:50]))
    else:
        l1ll1i1i11i1_vr_()
def l1ll1i1i11i1_vr_():
    cache.delete(l1llll1i1i11i1_vr_ (u"࠭ࡨࡪࡵࡷࡳࡷࡿࠧࡲ"))
import ramic as l1lll1i1i11i1_vr_
mode = args.get(l1llll1i1i11i1_vr_ (u"ࠧ࡮ࡱࡧࡩࠬࡳ"), None)
fname = args.get(l1llll1i1i11i1_vr_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬࡴ"),[l1llll1i1i11i1_vr_ (u"ࠩࠪࡵ")])[0]
ex_link = args.get(l1llll1i1i11i1_vr_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫࡶ"),[l1llll1i1i11i1_vr_ (u"ࠫࠬࡷ")])[0]
l1ll1111i1i11i1_vr_ = args.get(l1llll1i1i11i1_vr_ (u"ࠬࡶࡡࡨࡧࠪࡸ"),[1])[0]
if mode is None:
    l1111li1i11i1_vr_(name=l1llll1i1i11i1_vr_ (u"࠭ࡉ࡯ࡨࡲࡶࡲࡧࡣ࡫ࡣࠪࡹ"),mode=l1llll1i1i11i1_vr_ (u"ࠧࡠ࡫ࡱࡪࡴࡥࠧࡺ"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l1llll1i1i11i1_vr_ (u"ࠨࡲࡤࡸ࡭࠭ࡻ")))+l1llll1i1i11i1_vr_ (u"ࠩ࠲࡭ࡨࡵ࡮࠯ࡲࡱ࡫ࠬࡼ"))
    l1111li1i11i1_vr_(name=l1llll1i1i11i1_vr_ (u"ࠥࡗࡹࡸ࡯࡯ࡣࠣࡋेࣹࡷ࡯ࡣࠥࡽ"),ex_link=l1llll1i1i11i1_vr_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼࡩࡥࡧࡵ࠲࡮ࡴࡦࡰࠩࡾ"), mode=l1llll1i1i11i1_vr_ (u"ࠬࡒࡩࡴࡶࡐࡳࡻ࡯ࡥࡴࠩࡿ"),iconImage=l1llll1i1i11i1_vr_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࠪࢀ"),fanart=l1lllll1i1i11i1_vr_)
    l1111li1i11i1_vr_(name=l1llll1i1i11i1_vr_ (u"ࠢࡓࡣࡱ࡯࡮ࡴࡧࠡࡘ࡬ࡨࡪࡸ࠮ࡱ࡮ࠣࠬ࠸࠶ࡤ࡯࡫ࠬࠦࢁ"),ex_link=l1llll1i1i11i1_vr_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫ࡲ࠯࡫ࡱࡪࡴ࠵ࡲࡢࡰ࡮࡭ࡳ࡭࠯࡮ࡱࡱࡸ࡭࠭ࢂ"), mode=l1llll1i1i11i1_vr_ (u"ࠩࡏ࡭ࡸࡺࡍࡰࡸ࡬ࡩࡸ࠭ࢃ"),iconImage=l1llll1i1i11i1_vr_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧࢄ"),fanart=l1lllll1i1i11i1_vr_)
    l1111li1i11i1_vr_(l1llll1i1i11i1_vr_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡰ࡮ࡡ࡬࡫ࡠ࡛ࡾࡨࡲࡢࡰࡨ࡟࠴ࡉࡏࡍࡑࡕࡡࠬࢅ"),ex_link=l1llll1i1i11i1_vr_ (u"ࠬࡌࡁࡗࡑࡕࡍ࡙ࡋࠧࢆ"), mode=l1llll1i1i11i1_vr_ (u"࠭ࡌࡪࡵࡷࡑࡴࡼࡩࡦࡵࠪࢇ"),  iconImage=l1llll1i1i11i1_vr_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫ࢈"),fanart=l1lllll1i1i11i1_vr_)
    l1111li1i11i1_vr_(l1llll1i1i11i1_vr_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡ࡮࡬࡫࡭ࡺࡧࡳࡧࡨࡲࡢ࡙ࡺࡶ࡭ࡤ࡮ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࢉ"),l1llll1i1i11i1_vr_ (u"ࠩࠪࢊ"),mode=l1llll1i1i11i1_vr_ (u"ࠪࡗࡿࡻ࡫ࡢ࡬ࠪࢋ"))
elif mode[0].startswith(l1llll1i1i11i1_vr_ (u"ࠫࡤ࡯࡮ࡧࡱࡢࠫࢌ")):l1lll1i1i11i1_vr_.__myinfo__.go(sys.argv)
elif mode[0] == l1llll1i1i11i1_vr_ (u"ࠬࡥ࡟ࡱࡣࡪࡩࡤࡥࡍࠨࢍ"):
    url = l111llli1i11i1_vr_({l1llll1i1i11i1_vr_ (u"࠭࡭ࡰࡦࡨࠫࢎ"): l1llll1i1i11i1_vr_ (u"ࠧࡍ࡫ࡶࡸࡒࡵࡶࡪࡧࡶࠫ࢏"), l1llll1i1i11i1_vr_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬ࢐"): l1llll1i1i11i1_vr_ (u"ࠩࠪ࢑"), l1llll1i1i11i1_vr_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫ࢒") : ex_link})
    xbmc.executebuiltin(l1llll1i1i11i1_vr_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠮ࠥࡴࠫࠪ࢓")% url)
elif mode[0] == l1llll1i1i11i1_vr_ (u"ࠬࡒࡩࡴࡶࡐࡳࡻ࡯ࡥࡴࠩ࢔"):
    l1lll1l1i1i11i1_vr_(ex_link)
elif mode[0] == l1llll1i1i11i1_vr_ (u"࠭ࡌࡪࡵࡷࡗࡪࡸࡩࡢ࡮ࡨࠫ࢕"):
    l1li1i11i1_vr_(ex_link,l1ll1111i1i11i1_vr_)
elif mode[0] == l1llll1i1i11i1_vr_ (u"ࠧࡨࡧࡷࡐ࡮ࡴ࡫ࡴࠩ࢖"):
    l1l11l1i1i11i1_vr_(ex_link)
elif mode[0] == l1llll1i1i11i1_vr_ (u"ࠨࡉࡤࡸࡺࡴࡥ࡬ࡔࡲ࡯ࠬࢗ"):
    (l1l11lli1i11i1_vr_,l11i1i11i1_vr_,l1ll1l1li1i11i1_vr_) = l1111l1i1i11i1_vr_.l1ll1ll1i1i11i1_vr_()
    if ex_link==l1llll1i1i11i1_vr_ (u"ࠩࡗࡽࡵ࠭࢘"):
        data = l1l11lli1i11i1_vr_
    elif ex_link==l1llll1i1i11i1_vr_ (u"ࠪࡖࡴࡱ࢙ࠧ"):
        data = l11i1i11i1_vr_
    elif ex_link==l1llll1i1i11i1_vr_ (u"ࠫࡐࡧࡴࡦࡩࡲࡶ࡮࡫࢚ࠧ"):
        data = l1ll1l1li1i11i1_vr_
    if data:
        label = [x[1].strip() for x in data]
        url = [x[0].strip() for x in data]
        l11lli1i11i1_vr_ = xbmcgui.Dialog().select(l1llll1i1i11i1_vr_ (u"ࠬ࡝ࡹࡣ࡫ࡨࡶࡿࡀࠠࠨ࢛")+ex_link,label)
        if l11lli1i11i1_vr_>-1:
            url = l111llli1i11i1_vr_({l1llll1i1i11i1_vr_ (u"࠭࡭ࡰࡦࡨࠫ࢜"): l1llll1i1i11i1_vr_ (u"ࠧࡍ࡫ࡶࡸࡒࡵࡶࡪࡧࡶࠫ࢝"), l1llll1i1i11i1_vr_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬ࢞"): l1llll1i1i11i1_vr_ (u"ࠩࠪ࢟"), l1llll1i1i11i1_vr_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫࢠ") : l1111l1i1i11i1_vr_.l1lll1lli1i11i1_vr_+ url[l11lli1i11i1_vr_]})
            xbmc.executebuiltin(l1llll1i1i11i1_vr_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠮ࠥࡴࠫࠪࢡ")% url)
elif mode[0] == l1llll1i1i11i1_vr_ (u"ࠬࡕࡰࡤ࡬ࡨࠫࢢ"):
    l1ll1l11i1i11i1_vr_.openSettings()
elif mode[0] == l1llll1i1i11i1_vr_ (u"࠭ࡦࡢࡸࡲࡶ࡮ࡺࡥࡴࡃࡇࡈࠬࢣ"):
    l11lll1i1i11i1_vr_ = l1llll11i1i11i1_vr_(l11l1li1i11i1_vr_)
    l1l1lli1i11i1_vr_=json.loads(ex_link)
    l1l1lli1i11i1_vr_[l1llll1i1i11i1_vr_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࢤ")] = l1l1lli1i11i1_vr_.get(l1llll1i1i11i1_vr_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࢥ"),l1llll1i1i11i1_vr_ (u"ࠩࠪࢦ")).replace(l1l1lli1i11i1_vr_.get(l1llll1i1i11i1_vr_ (u"ࠪࡰࡦࡨࡥ࡭ࠩࢧ"),l1llll1i1i11i1_vr_ (u"ࠫࠬࢨ")),l1llll1i1i11i1_vr_ (u"ࠬ࠭ࢩ")).replace(l1l1lli1i11i1_vr_.get(l1llll1i1i11i1_vr_ (u"࠭࡭ࡴࡩࠪࢪ"),l1llll1i1i11i1_vr_ (u"ࠧࠨࢫ")),l1llll1i1i11i1_vr_ (u"ࠨࠩࢬ"))
    l1ll11l1i1i11i1_vr_ = [x for x in l11lll1i1i11i1_vr_ if l1l1lli1i11i1_vr_[l1llll1i1i11i1_vr_ (u"ࠩࡷ࡭ࡹࡲࡥࠨࢭ")]== x.get(l1llll1i1i11i1_vr_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩࢮ"),l1llll1i1i11i1_vr_ (u"ࠫࠬࢯ"))]
    if l1ll11l1i1i11i1_vr_:
        xbmc.executebuiltin(l1llll1i1i11i1_vr_ (u"ࠬࡔ࡯ࡵ࡫ࡩ࡭ࡨࡧࡴࡪࡱࡱࠬࡠࡉࡏࡍࡑࡕࠤࡵ࡯࡮࡬࡟ࡍࡹঁࠦࡪࡦࡵࡷࠤࡼࠦࡗࡺࡤࡵࡥࡳࡿࡣࡩ࡝࠲ࡇࡔࡒࡏࡓ࡟࠯ࠤࠬࢰ") + l1l1lli1i11i1_vr_.get(l1llll1i1i11i1_vr_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࢱ"),l1llll1i1i11i1_vr_ (u"ࠧࠨࢲ")).encode(l1llll1i1i11i1_vr_ (u"ࠨࡷࡷࡪ࠲࠾ࠧࢳ")) + l1llll1i1i11i1_vr_ (u"ࠩ࠯ࠤ࠷࠶࠰ࠪࠩࢴ"))
    else:
        l11lll1i1i11i1_vr_.append(l1l1lli1i11i1_vr_)
        with open(l11l1li1i11i1_vr_, l1llll1i1i11i1_vr_ (u"ࠪࡻࠬࢵ")) as l11ll1li1i11i1_vr_:
            json.dump(l11lll1i1i11i1_vr_, l11ll1li1i11i1_vr_, indent=2, sort_keys=True)
            xbmc.executebuiltin(l1llll1i1i11i1_vr_ (u"ࠫࡓࡵࡴࡪࡨ࡬ࡧࡦࡺࡩࡰࡰࠫࡈࡴࡪࡡ࡯ࡱࠣࡈࡴࠦࡗࡺࡤࡵࡥࡳࡿࡣࡩ࠮ࠣࠫࢶ") + l1l1lli1i11i1_vr_.get(l1llll1i1i11i1_vr_ (u"ࠬࡺࡩࡵ࡮ࡨࠫࢷ"),l1llll1i1i11i1_vr_ (u"࠭ࠧࢸ")).encode(l1llll1i1i11i1_vr_ (u"ࠧࡶࡶࡩ࠱࠽࠭ࢹ")) + l1llll1i1i11i1_vr_ (u"ࠨ࠮ࠣ࠶࠵࠶ࠩࠨࢺ"))
elif mode[0] == l1llll1i1i11i1_vr_ (u"ࠩࡩࡥࡻࡵࡲࡪࡶࡨࡷࡗࡋࡍࠨࢻ"):
    if ex_link==l1llll1i1i11i1_vr_ (u"ࠪࡥࡱࡲࠧࢼ"):
        l1111i1i11i1_vr_ = xbmcgui.Dialog().yesno(l1llll1i1i11i1_vr_ (u"ࠦࡄࡅࠢࢽ"),l1llll1i1i11i1_vr_ (u"࡛ࠧࡳࡶॆࠣࡻࡸࢀࡹࡴࡶ࡮࡭ࡪࠦࡦࡪ࡮ࡰࡽࠥࢀࠠࡘࡻࡥࡶࡦࡴࡹࡤࡪࡂࠦࢾ"))
        if l1111i1i11i1_vr_:
            debug=1
    else:
        l11lll1i1i11i1_vr_ = l1llll11i1i11i1_vr_(l11l1li1i11i1_vr_)
        l1l11li1i11i1_vr_=json.loads(ex_link)
        l1llll1li1i11i1_vr_=[]
        for i in xrange(len(l11lll1i1i11i1_vr_)):
            if l11lll1i1i11i1_vr_[i].get(l1llll1i1i11i1_vr_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࢿ")) in l1l11li1i11i1_vr_.get(l1llll1i1i11i1_vr_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࣀ")):
                l1llll1li1i11i1_vr_.append(i)
        if len(l1llll1li1i11i1_vr_)>1:
            l1111i1i11i1_vr_ = xbmcgui.Dialog().yesno(l1llll1i1i11i1_vr_ (u"ࠣࡁࡂࠦࣁ"),l1l11li1i11i1_vr_.get(l1llll1i1i11i1_vr_ (u"ࠩࡷ࡭ࡹࡲࡥࠨࣂ")),l1llll1i1i11i1_vr_ (u"࡙ࠥࡸࡻॄࠡࠧࡧࠤࡵࡵࡺࡺࡥ࡭࡭ࠥࢀࠠࡘࡻࡥࡶࡦࡴࡹࡤࡪࡂࠦࣃ") % len(l1llll1li1i11i1_vr_))
        else:
            l1111i1i11i1_vr_ = True
        if l1111i1i11i1_vr_:
            for i in reversed(l1llll1li1i11i1_vr_):
                l11lll1i1i11i1_vr_.pop(i)
            with open(l11l1li1i11i1_vr_, l1llll1i1i11i1_vr_ (u"ࠫࡼ࠭ࣄ")) as l11ll1li1i11i1_vr_:
                json.dump(l11lll1i1i11i1_vr_, l11ll1li1i11i1_vr_, indent=2, sort_keys=True)
    xbmc.executebuiltin(l1llll1i1i11i1_vr_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧࣅ"))
elif mode[0] ==l1llll1i1i11i1_vr_ (u"࠭ࡓࡻࡷ࡮ࡥ࡯࠭ࣆ"):
    l1111li1i11i1_vr_(l1llll1i1i11i1_vr_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡨࡴࡨࡩࡳࡣࡎࡰࡹࡨࠤࡘࢀࡵ࡬ࡣࡱ࡭ࡪࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࣇ"),l1llll1i1i11i1_vr_ (u"ࠨࠩࣈ"),mode=l1llll1i1i11i1_vr_ (u"ࠩࡖࡾࡺࡱࡡ࡫ࡐࡲࡻࡪ࠭ࣉ"))
    l1lllllli1i11i1_vr_ = l1lll1li1i11i1_vr_()
    if not l1lllllli1i11i1_vr_ == [l1llll1i1i11i1_vr_ (u"ࠪࠫ࣊")]:
        for l11111li1i11i1_vr_ in l1lllllli1i11i1_vr_:
            contextmenu = []
            contextmenu.append((l1llll1i1i11i1_vr_ (u"࡚ࠫࡹࡵॅࠩ࣋"), l1llll1i1i11i1_vr_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠨࠦࡵࠬࠫ࣌")% l111llli1i11i1_vr_({l1llll1i1i11i1_vr_ (u"࠭࡭ࡰࡦࡨࠫ࣍"): l1llll1i1i11i1_vr_ (u"ࠧࡔࡼࡸ࡯ࡦࡰࡕࡴࡷࡱࠫ࣎"), l1llll1i1i11i1_vr_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬࣏ࠩ") : l11111li1i11i1_vr_})),)
            contextmenu.append((l1llll1i1i11i1_vr_ (u"ࠩࡘࡷࡺॊࠠࡤࡣॅउࠥ࡮ࡩࡴࡶࡲࡶ࡮ट࣐ࠧ"), l1llll1i1i11i1_vr_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࠪࡹࠩࠨ࣑") % l111llli1i11i1_vr_({l1llll1i1i11i1_vr_ (u"ࠫࡲࡵࡤࡦ࣒ࠩ"): l1llll1i1i11i1_vr_ (u"࡙ࠬࡺࡶ࡭ࡤ࡮࡚ࡹࡵ࡯ࡃ࡯ࡰ࣓ࠬ")})),)
            l1111li1i11i1_vr_(name=l11111li1i11i1_vr_, ex_link=l1llll1i1i11i1_vr_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࢂࠧࣔ")+l11111li1i11i1_vr_, mode=l1llll1i1i11i1_vr_ (u"ࠧࡍ࡫ࡶࡸࡒࡵࡶࡪࡧࡶࠫࣕ"), fanart=None, contextmenu=contextmenu)
elif mode[0] ==l1llll1i1i11i1_vr_ (u"ࠨࡕࡽࡹࡰࡧࡪࡏࡱࡺࡩࠬࣖ"):
    d = xbmcgui.Dialog().input(l1llll1i1i11i1_vr_ (u"ࠩࡖࡾࡺࡱࡡ࡫࠮ࠣࡔࡴࡪࡡ࡫ࠢࡷࡽࡹࡻ࡬ࠨࣗ"), type=xbmcgui.INPUT_ALPHANUM)
    if d:
        l11ll11i1i11i1_vr_(d)
        ex_link=l1llll1i1i11i1_vr_ (u"ࠪࡷࡪࡧࡲࡤࡪࡿࠫࣘ")+d
        l1lll1l1i1i11i1_vr_(ex_link)
elif mode[0] ==l1llll1i1i11i1_vr_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭࡙ࡸࡻ࡮ࠨࣙ"):
    l11l11li1i11i1_vr_(ex_link)
    xbmc.executebuiltin(l1llll1i1i11i1_vr_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠨࠦࡵࠬࠫࣚ")%  l111llli1i11i1_vr_({l1llll1i1i11i1_vr_ (u"࠭࡭ࡰࡦࡨࠫࣛ"): l1llll1i1i11i1_vr_ (u"ࠧࡔࡼࡸ࡯ࡦࡰࠧࣜ")}))
elif mode[0] == l1llll1i1i11i1_vr_ (u"ࠨࡕࡽࡹࡰࡧࡪࡖࡵࡸࡲࡆࡲ࡬ࠨࣝ"):
    l1ll1i1i11i1_vr_()
    xbmc.executebuiltin(l1llll1i1i11i1_vr_ (u"࡛ࠩࡆࡒࡉ࠮ࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠬࠪࡹࠩࠨࣞ")%  l111llli1i11i1_vr_({l1llll1i1i11i1_vr_ (u"ࠪࡱࡴࡪࡥࠨࣟ"): l1llll1i1i11i1_vr_ (u"ࠫࡘࢀࡵ࡬ࡣ࡭ࠫ࣠")}))
elif mode[0] == l1llll1i1i11i1_vr_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ࣡"):
    pass
else:
    xbmcplugin.setResolvedUrl(l1l1l1li1i11i1_vr_, False, xbmcgui.ListItem(path=l1llll1i1i11i1_vr_ (u"࠭ࠧ࣢")))
xbmcplugin.endOfDirectory(l1l1l1li1i11i1_vr_)
