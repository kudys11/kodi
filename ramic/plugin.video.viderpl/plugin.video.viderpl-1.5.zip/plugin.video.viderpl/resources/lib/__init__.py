# coding: UTF-8
import sys
l1ll111i1i11i1_vr_ = sys.version_info [0] == 2
l1l1l1i1i11i1_vr_ = 2048
l1ll1li1i11i1_vr_ = 7
def l1llll1i1i11i1_vr_ (l1i1i11i1_vr_):
	global l1l1ll1i1i11i1_vr_
	l1lll11li1i11i1_vr_ = ord (l1i1i11i1_vr_ [-1])
	l1ll11li1i11i1_vr_ = l1i1i11i1_vr_ [:-1]
	l1l1li1i11i1_vr_ = l1lll11li1i11i1_vr_ % len (l1ll11li1i11i1_vr_)
	l1l11i1i11i1_vr_ = l1ll11li1i11i1_vr_ [:l1l1li1i11i1_vr_] + l1ll11li1i11i1_vr_ [l1l1li1i11i1_vr_:]
	if l1ll111i1i11i1_vr_:
		l11lllli1i11i1_vr_ = unicode () .join ([unichr (ord (char) - l1l1l1i1i11i1_vr_ - (l11111i1i11i1_vr_ + l1lll11li1i11i1_vr_) % l1ll1li1i11i1_vr_) for l11111i1i11i1_vr_, char in enumerate (l1l11i1i11i1_vr_)])
	else:
		l11lllli1i11i1_vr_ = str () .join ([chr (ord (char) - l1l1l1i1i11i1_vr_ - (l11111i1i11i1_vr_ + l1lll11li1i11i1_vr_) % l1ll1li1i11i1_vr_) for l11111i1i11i1_vr_, char in enumerate (l1l11i1i11i1_vr_)])
	return eval (l11lllli1i11i1_vr_)