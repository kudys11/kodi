# -*- coding: utf-8 -*-
import sys
l1ll111i1i11i1_vr_ = sys.version_info [0] == 2
l1l1l1i1i11i1_vr_ = 2048
l1ll1li1i11i1_vr_ = 7
def l1llll1i1i11i1_vr_ (l1i1i11i1_vr_):
	global l1l1ll1i1i11i1_vr_
	l1lll11li1i11i1_vr_ = ord (l1i1i11i1_vr_ [-1])
	l1ll11li1i11i1_vr_ = l1i1i11i1_vr_ [:-1]
	l1l1li1i11i1_vr_ = l1lll11li1i11i1_vr_ % len (l1ll11li1i11i1_vr_)
	l1l11i1i11i1_vr_ = l1ll11li1i11i1_vr_ [:l1l1li1i11i1_vr_] + l1ll11li1i11i1_vr_ [l1l1li1i11i1_vr_:]
	if l1ll111i1i11i1_vr_:
		l11lllli1i11i1_vr_ = unicode () .join ([unichr (ord (char) - l1l1l1i1i11i1_vr_ - (l11111i1i11i1_vr_ + l1lll11li1i11i1_vr_) % l1ll1li1i11i1_vr_) for l11111i1i11i1_vr_, char in enumerate (l1l11i1i11i1_vr_)])
	else:
		l11lllli1i11i1_vr_ = str () .join ([chr (ord (char) - l1l1l1i1i11i1_vr_ - (l11111i1i11i1_vr_ + l1lll11li1i11i1_vr_) % l1ll1li1i11i1_vr_) for l11111i1i11i1_vr_, char in enumerate (l1l11i1i11i1_vr_)])
	return eval (l11lllli1i11i1_vr_)
import xbmc,xbmcgui
import time,re,os,threading
try: from shutil import rmtree
except: rmtree = False
def _1l1111lli1i11i1_vr_(l1l1l1li1i11i1_vr_):
    import json,xbmcplugin,urllib2
    url=l1llll1i1i11i1_vr_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡩࡸࡩࡷࡧ࠱࡫ࡴࡵࡧ࡭ࡧ࠱ࡧࡴࡳ࠯ࡶࡥࡂࡩࡽࡶ࡯ࡳࡶࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࠫ࡯ࡤ࠾ࠩऺ")
    try:
        l11llll1li1i11i1_vr_ = json.load(urllib2.urlopen(url+l1llll1i1i11i1_vr_ (u"ࠫ࠵ࡈ࠰ࡑ࡯࡯࡚ࡎࡾࡹࡨ࡭ࡷࡩࡳࡌࡋࡐࡕ࠴ࡶࡨ࠹ࡅ࠱ࡗࡘ࠴ࠬऻ")))
    except:
        l11llll1li1i11i1_vr_=[{l1llll1i1i11i1_vr_ (u"ࠬࡺࡩࡵ࡮ࡨ़ࠫ"):l1llll1i1i11i1_vr_ (u"࠭ࡍࡰॾࡨࠤࡨࡵज़ࠡࡵ࡬झࠥࡺࡵࠡࡲࡲ࡮ࡦࡽࡩࠨऽ")}]
    for l11llll11i1i11i1_vr_ in l11llll1li1i11i1_vr_:
        l1ll1l1i1i11i1_vr_ = xbmcgui.ListItem(l11llll11i1i11i1_vr_.get(l1llll1i1i11i1_vr_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ा")), iconImage=l11llll11i1i11i1_vr_.get(l1llll1i1i11i1_vr_ (u"ࠨ࡫ࡰ࡫ࠬि")) , thumbnailImage=l11llll11i1i11i1_vr_.get(l1llll1i1i11i1_vr_ (u"ࠩࡩࡥࡳࡧࡲࡵࠩी")) )
        l1ll1l1i1i11i1_vr_.setInfo(type=l1llll1i1i11i1_vr_ (u"࡚ࠥ࡮ࡪࡥࡰࠤु"), infoLabels=l11llll11i1i11i1_vr_)
        l1ll1l1i1i11i1_vr_.setProperty(l1llll1i1i11i1_vr_ (u"ࠫࡎࡹࡐ࡭ࡣࡼࡥࡧࡲࡥࠨू"), l1llll1i1i11i1_vr_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫृ"))
        l1ll1l1i1i11i1_vr_.setProperty(l1llll1i1i11i1_vr_ (u"࠭ࡦࡢࡰࡤࡶࡹࡥࡩ࡮ࡣࡪࡩࠬॄ"),l11llll11i1i11i1_vr_.get(l1llll1i1i11i1_vr_ (u"ࠧࡧࡣࡱࡥࡷࡺࠧॅ")))
        xbmcplugin.addDirectoryItem(handle=l1l1l1li1i11i1_vr_, url=l11llll11i1i11i1_vr_.get(l1llll1i1i11i1_vr_ (u"ࠨࡷࡵࡰࠬॆ")), listitem=l1ll1l1i1i11i1_vr_, isFolder=False)
def l1l111l1li1i11i1_vr_(l11lll11li1i11i1_vr_,l11lll111i1i11i1_vr_=[l1llll1i1i11i1_vr_ (u"ࠩࠪे")]):
    debug=1
def l1l111ll1i1i11i1_vr_(name=l1llll1i1i11i1_vr_ (u"ࠪࠫै")):
    debug=1
def l1l11111li1i11i1_vr_(top):
    debug=1
def check():
    debug=1
try:
    debug=1
except: pass
def run():
    try:
        debug=1
    except: pass
