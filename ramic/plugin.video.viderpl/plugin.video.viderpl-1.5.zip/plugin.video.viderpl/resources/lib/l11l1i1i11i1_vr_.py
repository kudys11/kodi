# -*- coding: utf-8 -*-
import sys
l1ll111i1i11i1_vr_ = sys.version_info [0] == 2
l1l1l1i1i11i1_vr_ = 2048
l1ll1li1i11i1_vr_ = 7
def l1llll1i1i11i1_vr_ (l1i1i11i1_vr_):
	global l1l1ll1i1i11i1_vr_
	l1lll11li1i11i1_vr_ = ord (l1i1i11i1_vr_ [-1])
	l1ll11li1i11i1_vr_ = l1i1i11i1_vr_ [:-1]
	l1l1li1i11i1_vr_ = l1lll11li1i11i1_vr_ % len (l1ll11li1i11i1_vr_)
	l1l11i1i11i1_vr_ = l1ll11li1i11i1_vr_ [:l1l1li1i11i1_vr_] + l1ll11li1i11i1_vr_ [l1l1li1i11i1_vr_:]
	if l1ll111i1i11i1_vr_:
		l11lllli1i11i1_vr_ = unicode () .join ([unichr (ord (char) - l1l1l1i1i11i1_vr_ - (l11111i1i11i1_vr_ + l1lll11li1i11i1_vr_) % l1ll1li1i11i1_vr_) for l11111i1i11i1_vr_, char in enumerate (l1l11i1i11i1_vr_)])
	else:
		l11lllli1i11i1_vr_ = str () .join ([chr (ord (char) - l1l1l1i1i11i1_vr_ - (l11111i1i11i1_vr_ + l1lll11li1i11i1_vr_) % l1ll1li1i11i1_vr_) for l11111i1i11i1_vr_, char in enumerate (l1l11i1i11i1_vr_)])
	return eval (l11lllli1i11i1_vr_)
l1llll1i1i11i1_vr_ (u"ࠨࠢࠣࠏࠍࡇࡷ࡫ࡡࡵࡧࡧࠤࡴࡴࠠࡕࡪࡸࠤࡆࡶࡲࠡ࠯࠴࠼ࠥ࠸࠰࠲࠸ࠐࠎࠒࠐࡀࡢࡷࡷ࡬ࡴࡸ࠺ࠡࡴࡤࡱ࡮ࡩࡳࡱࡣࠐࠎࠧࠨࠢ૶")
import urllib2,urllib
import re
import l1l1111l1i1i11i1_vr_
import json as json
l1lllll111i1i11i1_vr_=l1llll1i1i11i1_vr_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠴࠹࠰࠳࠲࠷࠻࠶࠵࠰࠼࠻࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬ૷")
l1lll1lli1i11i1_vr_=l1llll1i1i11i1_vr_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫ࡲ࠯࡫ࡱࡪࡴ࠭૸")
l11ll1l1li1i11i1_vr_ = 30
def l1l1llli1i11i1_vr_(url,data=None,headers={},cookies=None):
    if headers:
        l1111l1l1i1i11i1_vr_=headers
    else:
        l1111l1l1i1i11i1_vr_ = {l1llll1i1i11i1_vr_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ૹ"):l1llll1i1i11i1_vr_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡏࡘ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠷࠼࠳࠶࠮࠳࠷࠹࠸࠳࠿࠷ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨૺ")}
    req = urllib2.Request(url,data,l1111l1l1i1i11i1_vr_)
    if cookies:
        req.add_header(l1llll1i1i11i1_vr_ (u"ࠦࡈࡵ࡯࡬࡫ࡨࠦૻ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11ll1l1li1i11i1_vr_)
        l11l1lli1i11i1_vr_ =  response.read()
        response.close()
    except:
        l11l1lli1i11i1_vr_=l1llll1i1i11i1_vr_ (u"ࠬ࠭ૼ")
    return l11l1lli1i11i1_vr_
def _111ll1l1i1i11i1_vr_(l1111lll1i1i11i1_vr_):
    out=[]
    item = l1111lll1i1i11i1_vr_[0]
    for item in l1111lll1i1i11i1_vr_:
        href = re.compile(l1llll1i1i11i1_vr_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࡝ࡵ࠭ࡂࠬ૽")).findall(item)
        l111lll11i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠧ࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠫ૾")).findall(item)
        title = re.compile(l1llll1i1i11i1_vr_ (u"ࠨ࠾ࡶࡴࡦࡴࠠࡤ࡮ࡤࡷࡸࡃࠢࡵࡺࡷࡣࡲࡪࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡵࡳࡥࡳࡄࠧ૿")).findall(item)
        l11l11111i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠩ࠿࡭ࠥࡩ࡬ࡢࡵࡶࡁࠧ࡬ࡡࠡࡨࡤ࠱ࡨࡲ࡯ࡤ࡭࠰ࡳࠧࡄ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ଀"),).findall(item)
        if href and title:
            l11llll11i1i11i1_vr_ = {l1llll1i1i11i1_vr_ (u"ࠪ࡬ࡷ࡫ࡦࠨଁ")   : l1lll1lli1i11i1_vr_+href[0],
                   l1llll1i1i11i1_vr_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪଂ") : l111ll1lli1i11i1_vr_(title[0]).strip() if title else l1llll1i1i11i1_vr_ (u"ࠬ࠭ଃ"),
                   l1llll1i1i11i1_vr_ (u"࠭ࡩ࡮ࡩࠪ଄") : l111lll11i1i11i1_vr_[0],
                   l1llll1i1i11i1_vr_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩଅ"): l11l11111i1i11i1_vr_[0].strip() if l11l11111i1i11i1_vr_ else l1llll1i1i11i1_vr_ (u"ࠨࠩଆ")
                   }
            out.append(l11llll11i1i11i1_vr_)
    return out
def _111l11l1i1i11i1_vr_(l111l11lli1i11i1_vr_):
    out=[]
    for item in l111l11lli1i11i1_vr_:
        l111l1ll1i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠫࡀࠫࠥࡠࡸ࠰ࡣ࡭ࡣࡶࡷࡂࠨ࠮ࠫࠤ࡟ࡷ࠯ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩଇ")).findall(item)
        l111lll11i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠪࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࠧଈ")).findall(item)
        l11l111l1i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠫࡁࡶࠠࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡷࡥࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡰ࠿ࠩଉ"),re.DOTALL).findall(item)
        l11l11111i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡨࡺࡸࡡࡵ࡫ࡲࡲࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫଊ")).findall(item)
        l111lll1li1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"࠭࠼ࡱࠢࡦࡰࡦࡹࡳ࠾ࠤࡧࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡲࡁࠫଋ")).findall(item)
        status = re.findall(l1llll1i1i11i1_vr_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧ࡬࡬ࡰࡣࡷ࠱ࡷࠦࡢࡢࡦࡪࡩࡤࡴࡥࡸࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨଌ"),item)
        if l111l1ll1i1i11i1_vr_:
            l1111ll1li1i11i1_vr_ =l1llll1i1i11i1_vr_ (u"ࠨࠩ଍")
            if l11l111l1i1i11i1_vr_:
                l111llllli1i11i1_vr_ = l1llll1i1i11i1_vr_ (u"ࠩࠣࠫ଎").join(x.strip() for x in re.compile(l1llll1i1i11i1_vr_ (u"ࠪࡂ࠭࠴ࠪࡀࠫ࠿ࠫଏ"),re.DOTALL).findall(l11l111l1i1i11i1_vr_[0])).strip()
                l111l1l11i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠫࡐࡧࡴࡢ࡮ࡲ࡫ࣸࡽ࠺ࠡ࡞ࡧ࠯ࠥ࠵ࠠࡑ࡮࡬࡯ࣸࡽ࠺ࠡ࡞ࡧ࠯ࠬଐ")).findall(l111llllli1i11i1_vr_)
                l111l1l1li1i11i1_vr_ = True if l1llll1i1i11i1_vr_ (u"ࠬࡌࡩ࡭࡯ࡼ࠾ࠬ଑") in l111llllli1i11i1_vr_ and l1llll1i1i11i1_vr_ (u"࠭ࡒࡰࡼࡰ࡭ࡦࡸ࠺ࠨ଒") in l111llllli1i11i1_vr_ else False
                if l111l1l11i1i11i1_vr_:
                    l1111ll1li1i11i1_vr_ = l111l1l11i1i11i1_vr_[0]
                elif l111l1l1li1i11i1_vr_:
                    l1111ll1li1i11i1_vr_ = status[0] if status else l1llll1i1i11i1_vr_ (u"ࠧࠨଓ")
                    l111lll1li1i11i1_vr_.append(l111llllli1i11i1_vr_)
            l11l111lli1i11i1_vr_=l1llll1i1i11i1_vr_ (u"ࠨࠩଔ")
            if l111lll11i1i11i1_vr_:
                l11l111lli1i11i1_vr_ = l111lll11i1i11i1_vr_[0]
                if not l1llll1i1i11i1_vr_ (u"ࠩ࡫ࡸࡹࡶࠧକ") in l11l111lli1i11i1_vr_:
                   l11l111lli1i11i1_vr_ =  l1lll1lli1i11i1_vr_ + l11l111lli1i11i1_vr_
            l11llll11i1i11i1_vr_ = {l1llll1i1i11i1_vr_ (u"ࠪ࡬ࡷ࡫ࡦࠨଖ")  : l1lll1lli1i11i1_vr_+l111l1ll1i1i11i1_vr_[0][0],
                   l1llll1i1i11i1_vr_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪଗ") : l111ll1lli1i11i1_vr_(l111l1ll1i1i11i1_vr_[0][1]).strip() if l111l1ll1i1i11i1_vr_ else l1llll1i1i11i1_vr_ (u"ࠬ࠭ଘ"),
                   l1llll1i1i11i1_vr_ (u"࠭ࡩ࡮ࡩࠪଙ") : l11l111lli1i11i1_vr_,
                   l1llll1i1i11i1_vr_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧଚ"): l111ll1lli1i11i1_vr_(l1111ll1li1i11i1_vr_).strip(),
                   l1llll1i1i11i1_vr_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪଛ"): l11l11111i1i11i1_vr_[0] if l11l11111i1i11i1_vr_ else l1llll1i1i11i1_vr_ (u"ࠩࠪଜ"),
                   l1llll1i1i11i1_vr_ (u"ࠪࡴࡱࡵࡴࠨଝ") :l111ll1lli1i11i1_vr_(l111lll1li1i11i1_vr_[0]).strip() if l111lll1li1i11i1_vr_ else l1llll1i1i11i1_vr_ (u"ࠫࠬଞ"),
                   }
            if l11llll11i1i11i1_vr_.get(l1llll1i1i11i1_vr_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬଟ")):
                l11llll11i1i11i1_vr_[l1llll1i1i11i1_vr_ (u"࠭ࡴࡪࡶ࡯ࡩࠬଠ")] = l1llll1i1i11i1_vr_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠ࡭࡫ࡪ࡬ࡹࡨ࡬ࡶࡧࡠࠩࡸࡡ࠯ࡄࡑࡏࡓࡗࡣࠠ࠮ࠢ࡞ࡇࡔࡒࡏࡓࠢ࡯࡭࡬࡮ࡴࡨࡴࡨࡩࡳࡣࠥࡴ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪଡ") %(l11llll11i1i11i1_vr_[l1llll1i1i11i1_vr_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧଢ")], l11llll11i1i11i1_vr_.get(l1llll1i1i11i1_vr_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩଣ")))
            out.append(l11llll11i1i11i1_vr_)
    return out
def l111i1i11i1_vr_(url):
    out=[]
    l1111l11li1i11i1_vr_={}
    content=l1l1llli1i11i1_vr_(url)
    l1111lll1i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡱࡹࡩࡷ࡬࡬ࡰࡹࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩତ"),re.DOTALL).findall(content)
    l111l11lli1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠫࡁࡲࡩࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡥ࡯ࡩࡦࡸࡦࡪࡺࠣࡻ࠲࠷࠰࠱࠯ࡳࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡲࡩ࠿ࠩଥ"),re.DOTALL).findall(content)
    if l1111lll1i1i11i1_vr_:
        out = _111ll1l1i1i11i1_vr_(l1111lll1i1i11i1_vr_)
        l111ll111i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡇࡸࡹࡔࡳࡧࡨ࡚ࡦࡲࡵࡦࠢࡆࡷࡸ࡚ࡲࡦࡧ࡙ࡥࡱࡻࡥࡎࡣ࡬ࡲࠧࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࡝ࡵ࠭ࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࡟ࡷ࠯ࡩ࡬ࡢࡵࡶࡁࠧ࡬ࡩ࡭ࡧࡗࡶࡪ࡫ࡌࡪࡰ࡮ࠦࡃ࠭ଦ")).findall(content)
        if l111ll111i1i11i1_vr_:
            l111lll11i1i11i1_vr_ = re.findall(l1llll1i1i11i1_vr_ (u"࠭ࡳࡳࡥࡀࠦ࠭࡮ࡴࡵࡲࡶ࠾࠴࠵ࡩ࡮ࡩ࠱ࡺ࡮ࡪࡥࡳ࠰࡬ࡲ࡫ࡵ࠯ࡢࡸࡤࡸࡦࡸ࠯࠯ࠬࡂ࠭ࠧ࠭ଧ"),content)
            l111lll11i1i11i1_vr_ = l111lll11i1i11i1_vr_[0] if l111lll11i1i11i1_vr_ else l1llll1i1i11i1_vr_ (u"ࠧࠨନ")
            l1111l11li1i11i1_vr_ = {l1llll1i1i11i1_vr_ (u"ࠨࡪࡵࡩ࡫࠭଩"):l1lll1lli1i11i1_vr_+l111ll111i1i11i1_vr_[0][0],l1llll1i1i11i1_vr_ (u"ࠩࡷ࡭ࡹࡲࡥࠨପ"):l1llll1i1i11i1_vr_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞࡝ࡎࡳࡱ࡫࡫ࡤ࡬ࡨࠤࡻ࡯ࡤࡦࡱࡠ࡟࠴ࡉࡏࡍࡑࡕࡡࠬଫ"),l1llll1i1i11i1_vr_ (u"ࠫ࡮ࡳࡧࠨବ"):l111lll11i1i11i1_vr_,l1llll1i1i11i1_vr_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬଭ"):l1llll1i1i11i1_vr_ (u"࠭ࡹࡦࡵࠪମ")}
            out.insert(0,l1111l11li1i11i1_vr_)
    elif l111l11lli1i11i1_vr_:
        out = _111l11l1i1i11i1_vr_(l111l11lli1i11i1_vr_)
    return out
def search(l111llllli1i11i1_vr_=l1llll1i1i11i1_vr_ (u"ࠧࡵࡣࡱ࡫ࡱ࡫ࡤࠡࡧࡹࡩࡷࠦࡡࡧࡶࡨࡶࠬଯ")):
    out=[]
    url=l1llll1i1i11i1_vr_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫ࡲ࠯࡫ࡱࡪࡴ࠵ࡳࡦࡣࡵࡧ࡭࠵ࡧࡦࡶࠪର")
    l111llll1i1i11i1_vr_ = {l1llll1i1i11i1_vr_ (u"ࠤࡶࡩࡦࡸࡣࡩࡡࡳ࡬ࡷࡧࡳࡦࠤ଱"):l111llllli1i11i1_vr_,l1llll1i1i11i1_vr_ (u"ࠥࡷࡪࡧࡲࡤࡪࡢࡸࡾࡶࡥࠣଲ"):l1llll1i1i11i1_vr_ (u"ࠦࡦࡲ࡬ࠣଳ"),l1llll1i1i11i1_vr_ (u"ࠧࡹࡥࡢࡴࡦ࡬ࡤࡹࡡࡷࡧࡧࠦ଴"):0,l1llll1i1i11i1_vr_ (u"ࠨࡰࡢࡩࡨࡷࠧଵ"):1,l1llll1i1i11i1_vr_ (u"ࠢ࡭࡫ࡰ࡭ࡹࠨଶ"):150}
    headers= {l1llll1i1i11i1_vr_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬଷ"):l1llll1i1i11i1_vr_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠶࠻࠲࠵࠴࠲࠶࠸࠷࠲࠾࠽ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧସ"),
            l1llll1i1i11i1_vr_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭ହ"):l1llll1i1i11i1_vr_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ଺")}
    content=l1l1llli1i11i1_vr_(url,data=json.dumps(l111llll1i1i11i1_vr_),headers=headers)
    if content:
        data=json.loads(content)
        print data.keys()
        l111l1llli1i11i1_vr_ = data.get(l1llll1i1i11i1_vr_ (u"ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧ଻"),{}).get(l1llll1i1i11i1_vr_ (u"࠭ࡤࡢࡶࡤࡣ࡫࡯࡬ࡦࡵ଼ࠪ"),{}).get(l1llll1i1i11i1_vr_ (u"ࠧࡥࡣࡷࡥࠬଽ"),[])
        for item in l111l1llli1i11i1_vr_:
            l11llll11i1i11i1_vr_ = {l1llll1i1i11i1_vr_ (u"ࠨࡪࡵࡩ࡫࠭ା")  : l1llll1i1i11i1_vr_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡹ࡭ࡩ࡫ࡲ࠯࡫ࡱࡪࡴ࠵ࡥ࡮ࡤࡨࡨ࠴ࡼࡩࡥࡧࡲ࠳ࠬି")+item.get(l1llll1i1i11i1_vr_ (u"ࠪ࡭ࡩࡥࡵࡳ࡮ࠪୀ"),l1llll1i1i11i1_vr_ (u"ࠫࠬୁ")),
                   l1llll1i1i11i1_vr_ (u"ࠬࡺࡩࡵ࡮ࡨࠫୂ") : l111ll1lli1i11i1_vr_(item.get(l1llll1i1i11i1_vr_ (u"࠭࡮ࡢ࡯ࡨࠫୃ"),l1llll1i1i11i1_vr_ (u"ࠧࠨୄ"))).replace(l1llll1i1i11i1_vr_ (u"ࠨࠩ୅"),l1llll1i1i11i1_vr_ (u"ࠩࠪ୆")),
                   l1llll1i1i11i1_vr_ (u"ࠪ࡭ࡲ࡭ࠧେ") : l1llll1i1i11i1_vr_ (u"ࠫࠬୈ"),
                   l1llll1i1i11i1_vr_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ୉"): l1llll1i1i11i1_vr_ (u"࠭ࠧ୊"),
                   l1llll1i1i11i1_vr_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩୋ"): item.get(l1llll1i1i11i1_vr_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪୌ"),l1llll1i1i11i1_vr_ (u"୍ࠩࠪ")),
                   l1llll1i1i11i1_vr_ (u"ࠪࡴࡱࡵࡴࠨ୎") : l1llll1i1i11i1_vr_ (u"ࠫࠬ୏"),
                   }
            if l11llll11i1i11i1_vr_.get(l1llll1i1i11i1_vr_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ୐")):
                l11llll11i1i11i1_vr_[l1llll1i1i11i1_vr_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ୑")] = l1llll1i1i11i1_vr_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࠫࡳ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࠰ࠤࡠࡉࡏࡍࡑࡕࠤ࡬ࡸࡥࡦࡰࡠࠩࡸࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ୒") %(l11llll11i1i11i1_vr_[l1llll1i1i11i1_vr_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ୓")], l11llll11i1i11i1_vr_.get(l1llll1i1i11i1_vr_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ୔")))
            out.append(l11llll11i1i11i1_vr_)
    return out
import cookielib
url=l1llll1i1i11i1_vr_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻ࡯ࡤࡦࡴ࠱࡭ࡳ࡬࡯࠰ࡸ࡬ࡨ࠴࠱ࡦ࡯࠳࠻ࡼࡳࡴࠧ୕")
def l111l1li1i11i1_vr_(url):
    l1llll1i1i11i1_vr_ (u"ࠦࠧࠨࠠࠡࠢࠣࠑࠏࠦࠠࠡࠢࡵࡩࡹࡻࡲ࡯ࡵࠣࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦ࠭ࠡࡷ࡯ࡶࠥ࡮ࡴࡵࡲ࠽࠳࠴࠴࠮࠯࠰ࠐࠎࠥࠦࠠࠡࠤࠥࠦୖ")
    if l1llll1i1i11i1_vr_ (u"ࠬ࠵ࡶࡪࡦ࠲ࠫୗ") in url:
        url=url.replace(l1llll1i1i11i1_vr_ (u"࠭࠯ࡷ࡫ࡧ࠳ࠬ୘"),l1llll1i1i11i1_vr_ (u"ࠧ࠰ࡧࡰࡦࡪࡪ࠯ࡷ࡫ࡧࡩࡴ࠵ࠧ୙"))
    l11l1l1lli1i11i1_vr_=l1llll1i1i11i1_vr_ (u"ࠨࠩ୚")
    if not l1llll1i1i11i1_vr_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠱ࠪ୛") in url:
        content = l1l1llli1i11i1_vr_(url)
        l111l111li1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡸ࡬ࡨࡪࡵ࠭ࡧࡴࡤࡱࡪࠦࠢ࠿࡝࡟ࡷࡡࡴ࡝ࠫ࠾࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠱ࡨࡱࡧ࡫ࡤ࠰ࡸ࡬ࡨࡪࡵ࠯࠯ࠬࡂ࠭ࠧ࠭ଡ଼")).findall(content)
        if not l111l111li1i11i1_vr_:
            l111l111li1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠫࡁ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻ࡯ࡤࡦࡴ࠱࡭ࡳ࡬࡯ࠩ࠱ࡨࡱࡧ࡫ࡤ࠰ࡸ࡬ࡨࡪࡵ࠯࠯ࠬࡂ࠭ࠧ࠭ଢ଼")).findall(content)
        if l111l111li1i11i1_vr_:
            url = l1lll1lli1i11i1_vr_+l111l111li1i11i1_vr_[0]
    content = l1l1llli1i11i1_vr_(url)
    data = re.compile(l1llll1i1i11i1_vr_ (u"ࠬࡪࡡࡵࡣ࠰ࡺ࡮ࡪࡥࡰ࠯ࡸࡶࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ୞")).findall(content)
    if data:
        l11l1l1lli1i11i1_vr_=data[0]+l1llll1i1i11i1_vr_ (u"࠭ࡼࡓࡧࡩࡩࡷ࡫ࡲ࠾ࡽࢀ࡚ࠪࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࡽࢀࠫୟ").format(url,l1lllll111i1i11i1_vr_)
    return l11l1l1lli1i11i1_vr_
def l111ll1lli1i11i1_vr_(l111llllli1i11i1_vr_):
    if type(l111llllli1i11i1_vr_) is not str:
        l111llllli1i11i1_vr_=l111llllli1i11i1_vr_.encode(l1llll1i1i11i1_vr_ (u"ࠧࡶࡶࡩ࠱࠽࠭ୠ"))
    s=l1llll1i1i11i1_vr_ (u"ࠨࡌ࡬ࡒࡨࡠࡃࡴ࠹ࠪୡ")
    l111llllli1i11i1_vr_ = re.sub(s.decode(l1llll1i1i11i1_vr_ (u"ࠩࡥࡥࡸ࡫࠶࠵ࠩୢ")),l1llll1i1i11i1_vr_ (u"ࠪࠫୣ"),l111llllli1i11i1_vr_)
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠫࠫࡲࡴ࠼ࡪ࠸ࠪ࡬ࡺ࠻ࠨ୤"),l1llll1i1i11i1_vr_ (u"ࠬ࠭୥"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"࠭ࠦ࡭ࡶ࠾࠳࡭࠻ࠦࡨࡶ࠾ࠫ୦"),l1llll1i1i11i1_vr_ (u"ࠧࠨ୧"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠨࠨࡱࡦࡸࡶ࠻ࠨ୨"),l1llll1i1i11i1_vr_ (u"ࠩࠪ୩"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠪࠪࡱࡺ࠻ࡣࡴ࠲ࠪ࡬ࡺ࠻ࠨ୪"),l1llll1i1i11i1_vr_ (u"ࠫࠥ࠭୫"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠬࠬࡱࡶࡱࡷ࠿ࠬ୬"),l1llll1i1i11i1_vr_ (u"࠭ࠢࠨ୭")).replace(l1llll1i1i11i1_vr_ (u"ࠧࠧࡣࡰࡴࡀࡷࡵࡰࡶ࠾ࠫ୮"),l1llll1i1i11i1_vr_ (u"ࠨࠤࠪ୯"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠩࠩࡳࡦࡩࡵࡵࡧ࠾ࠫ୰"),l1llll1i1i11i1_vr_ (u"ࠪࣷࠬୱ")).replace(l1llll1i1i11i1_vr_ (u"ࠫࠫࡕࡡࡤࡷࡷࡩࡀ࠭୲"),l1llll1i1i11i1_vr_ (u"ࠬࣙࠧ୳"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"࠭ࠦࡢ࡯ࡳ࠿ࡴࡧࡣࡶࡶࡨ࠿ࠬ୴"),l1llll1i1i11i1_vr_ (u"ࠧࣴࠩ୵")).replace(l1llll1i1i11i1_vr_ (u"ࠨࠨࡤࡱࡵࡁࡏࡢࡥࡸࡸࡪࡁࠧ୶"),l1llll1i1i11i1_vr_ (u"ࠩࣖࠫ୷"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠪࡠࡺ࠶࠱࠱࠷ࠪ୸"),l1llll1i1i11i1_vr_ (u"ࠫऊ࠭୹")).replace(l1llll1i1i11i1_vr_ (u"ࠬࡢࡵ࠱࠳࠳࠸ࠬ୺"),l1llll1i1i11i1_vr_ (u"࠭ऄࠨ୻"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠧ࡝ࡷ࠳࠵࠵࠽ࠧ୼"),l1llll1i1i11i1_vr_ (u"ࠨउࠪ୽")).replace(l1llll1i1i11i1_vr_ (u"ࠩ࡟ࡹ࠵࠷࠰࠷ࠩ୾"),l1llll1i1i11i1_vr_ (u"ࠪऊࠬ୿"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠫࡡࡻ࠰࠲࠳࠼ࠫ஀"),l1llll1i1i11i1_vr_ (u"ࠬटࠧ஁")).replace(l1llll1i1i11i1_vr_ (u"࠭࡜ࡶ࠲࠴࠵࠽࠭ஂ"),l1llll1i1i11i1_vr_ (u"ࠧङࠩஃ"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠨ࡞ࡸ࠴࠶࠺࠲ࠨ஄"),l1llll1i1i11i1_vr_ (u"ࠩॅࠫஅ")).replace(l1llll1i1i11i1_vr_ (u"ࠪࡠࡺ࠶࠱࠵࠳ࠪஆ"),l1llll1i1i11i1_vr_ (u"ࠫॆ࠭இ"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠬࡢࡵ࠱࠳࠷࠸ࠬஈ"),l1llll1i1i11i1_vr_ (u"࠭ॄࠨஉ")).replace(l1llll1i1i11i1_vr_ (u"ࠧ࡝ࡷ࠳࠵࠹࠺ࠧஊ"),l1llll1i1i11i1_vr_ (u"ࠨॅࠪ஋"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠩ࡟ࡹ࠵࠶ࡦ࠴ࠩ஌"),l1llll1i1i11i1_vr_ (u"ࠪࣷࠬ஍")).replace(l1llll1i1i11i1_vr_ (u"ࠫࡡࡻ࠰࠱ࡦ࠶ࠫஎ"),l1llll1i1i11i1_vr_ (u"ࠬࣙࠧஏ"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"࠭࡜ࡶ࠲࠴࠹ࡧ࠭ஐ"),l1llll1i1i11i1_vr_ (u"ࠧड़ࠩ஑")).replace(l1llll1i1i11i1_vr_ (u"ࠨ࡞ࡸ࠴࠶࠻ࡡࠨஒ"),l1llll1i1i11i1_vr_ (u"ࠩढ़ࠫஓ"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠪࡠࡺ࠶࠱࠸ࡣࠪஔ"),l1llll1i1i11i1_vr_ (u"ࠫॿ࠭க")).replace(l1llll1i1i11i1_vr_ (u"ࠬࡢࡵ࠱࠳࠺࠽ࠬ஖"),l1llll1i1i11i1_vr_ (u"࠭ॹࠨ஗"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠧ࡝ࡷ࠳࠵࠼ࡩࠧ஘"),l1llll1i1i11i1_vr_ (u"ࠨॾࠪங")).replace(l1llll1i1i11i1_vr_ (u"ࠩ࡟ࡹ࠵࠷࠷ࡣࠩச"),l1llll1i1i11i1_vr_ (u"ࠪॿࠬ஛"))
    return l111llllli1i11i1_vr_
