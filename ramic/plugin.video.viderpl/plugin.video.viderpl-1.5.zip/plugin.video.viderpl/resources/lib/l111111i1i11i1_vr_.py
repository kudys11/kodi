# -*- coding: utf-8 -*-
import sys
l1ll111i1i11i1_vr_ = sys.version_info [0] == 2
l1l1l1i1i11i1_vr_ = 2048
l1ll1li1i11i1_vr_ = 7
def l1llll1i1i11i1_vr_ (l1i1i11i1_vr_):
	global l1l1ll1i1i11i1_vr_
	l1lll11li1i11i1_vr_ = ord (l1i1i11i1_vr_ [-1])
	l1ll11li1i11i1_vr_ = l1i1i11i1_vr_ [:-1]
	l1l1li1i11i1_vr_ = l1lll11li1i11i1_vr_ % len (l1ll11li1i11i1_vr_)
	l1l11i1i11i1_vr_ = l1ll11li1i11i1_vr_ [:l1l1li1i11i1_vr_] + l1ll11li1i11i1_vr_ [l1l1li1i11i1_vr_:]
	if l1ll111i1i11i1_vr_:
		l11lllli1i11i1_vr_ = unicode () .join ([unichr (ord (char) - l1l1l1i1i11i1_vr_ - (l11111i1i11i1_vr_ + l1lll11li1i11i1_vr_) % l1ll1li1i11i1_vr_) for l11111i1i11i1_vr_, char in enumerate (l1l11i1i11i1_vr_)])
	else:
		l11lllli1i11i1_vr_ = str () .join ([chr (ord (char) - l1l1l1i1i11i1_vr_ - (l11111i1i11i1_vr_ + l1lll11li1i11i1_vr_) % l1ll1li1i11i1_vr_) for l11111i1i11i1_vr_, char in enumerate (l1l11i1i11i1_vr_)])
	return eval (l11lllli1i11i1_vr_)
l1llll1i1i11i1_vr_ (u"ࠧࠨࠢࠎࠌࡆࡶࡪࡧࡴࡦࡦࠣࡳࡳࠦࡔࡩࡷࠣࡊࡪࡨࠠ࠲࠳ࠣ࠵࠽ࡀ࠴࠸࠼࠷࠷ࠥ࠸࠰࠲࠸ࠐࠎࠒࠐࡀࡢࡷࡷ࡬ࡴࡸ࠺ࠡࡴࡤࡱ࡮ࡩࠍࠋࠤࠥࠦॴ")
import urllib2
import re
import l11ll11lli1i11i1_vr_ as l11ll11lli1i11i1_vr_
l1lll1lli1i11i1_vr_=l1llll1i1i11i1_vr_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡧࡩࡧ࠮ࡱ࡮ࠪॵ")
l11ll1l1li1i11i1_vr_ = 5
def l1l1llli1i11i1_vr_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l1llll1i1i11i1_vr_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫॶ"), l1llll1i1i11i1_vr_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠵࠺࠱࠴࠳࠸࠵࠷࠶࠱࠽࠼ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ॷ"))
    if cookies:
        req.add_header(l1llll1i1i11i1_vr_ (u"ࠤࡆࡳࡴࡱࡩࡦࠤॸ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11ll1l1li1i11i1_vr_)
        l11l1lli1i11i1_vr_ =  response.read()
        response.close()
    except:
        l11l1lli1i11i1_vr_=l1llll1i1i11i1_vr_ (u"ࠪࠫॹ")
    return l11l1lli1i11i1_vr_
def _11ll1ll1i1i11i1_vr_(content):
    src =l1llll1i1i11i1_vr_ (u"ࠫࠬॺ")
    l11l1ll1li1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠧ࡫ࡶࡢ࡮ࠫ࠲࠯ࡅࠩ࡝ࡽ࡟ࢁࡡ࠯࡜ࠪࠤॻ"),re.DOTALL).findall(content)
    for l11l1ll11i1i11i1_vr_ in l11l1ll1li1i11i1_vr_:
        l11l1ll11i1i11i1_vr_=re.sub(l1llll1i1i11i1_vr_ (u"࠭ࠠࠡࠩॼ"),l1llll1i1i11i1_vr_ (u"ࠧࠡࠩॽ"),l11l1ll11i1i11i1_vr_)
        l11l1ll11i1i11i1_vr_=re.sub(l1llll1i1i11i1_vr_ (u"ࠨ࡞ࡱࠫॾ"),l1llll1i1i11i1_vr_ (u"ࠩࠪॿ"),l11l1ll11i1i11i1_vr_)
        try:
            l11ll111li1i11i1_vr_ = l11ll11lli1i11i1_vr_.unpack(l11l1ll11i1i11i1_vr_)
        except:
            l11ll111li1i11i1_vr_=l1llll1i1i11i1_vr_ (u"ࠪࠫঀ")
        if l11ll111li1i11i1_vr_:
            l11ll111li1i11i1_vr_=re.sub(l1llll1i1i11i1_vr_ (u"ࡶࠬࡢ࡜ࠨঁ"),l1llll1i1i11i1_vr_ (u"ࡷ࠭ࠧং"),l11ll111li1i11i1_vr_)
            l11l1lll1i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"࠭ࡦࡪ࡮ࡨ࠾ࡡࡹࠪ࡜࡞ࠪࠦࡢ࠮࠮ࠬࡁࠬ࡟ࡡ࠭ࠢ࡞࠮ࠪঃ"),  re.DOTALL).search(l11ll111li1i11i1_vr_)
            l11ll1111i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠧࡶࡴ࡯࠾ࡡࡹࠪ࡜࡞ࠪࠦࡢ࠮࠮ࠬࡁࠬ࡟ࡡ࠭ࠢ࡞࠮ࠪ঄"),  re.DOTALL).search(l11ll111li1i11i1_vr_)
            if l11l1lll1i1i11i1_vr_:
                src = l11l1lll1i1i11i1_vr_.group(1)
            elif l11ll1111i1i11i1_vr_:
                src = l11ll1111i1i11i1_vr_.group(1)
            if src:
                break
    return src
def _11l1lllli1i11i1_vr_(content):
    src=l1llll1i1i11i1_vr_ (u"ࠨࠩঅ")
    l11l11ll1i1i11i1_vr_ = content.find(l1llll1i1i11i1_vr_ (u"ࠩࡿࢀࢁ࡮ࡴࡵࡲࠪআ"))
    if l11l11ll1i1i11i1_vr_>0:
        l11l1l111i1i11i1_vr_ = content.find(l1llll1i1i11i1_vr_ (u"ࠪ࠲ࡸࡶ࡬ࡪࡶࠪই"),l11l11ll1i1i11i1_vr_)
        encoded =content[l11l11ll1i1i11i1_vr_:l11l1l111i1i11i1_vr_]
        if encoded:
            l11ll1llli1i11i1_vr_ = encoded.split(l1llll1i1i11i1_vr_ (u"ࠫࡵࡲࡡࡺࡧࡵࠫঈ"))[0]
            l11ll1llli1i11i1_vr_=re.sub(l1llll1i1i11i1_vr_ (u"ࡷ࡛࠭ࡽ࡟࠮ࡠࡼࢁ࠲࠭࠵ࢀ࡟ࢁࡣࠫࠨউ"),l1llll1i1i11i1_vr_ (u"࠭ࡼࠨঊ"),l11ll1llli1i11i1_vr_,re.DOTALL)
            l11ll1llli1i11i1_vr_=re.sub(l1llll1i1i11i1_vr_ (u"ࡲࠨ࡝ࡿࡡ࠰ࡢࡷࡼ࠴࠯࠷ࢂࡡࡼ࡞࠭ࠪঋ"),l1llll1i1i11i1_vr_ (u"ࠨࡾࠪঌ"),l11ll1llli1i11i1_vr_,re.DOTALL)
            l11l11l11i1i11i1_vr_=[l1llll1i1i11i1_vr_ (u"ࠩ࡫ࡸࡹࡶࠧ঍"),l1llll1i1i11i1_vr_ (u"ࠪࡧࡩࡧࠧ঎"),l1llll1i1i11i1_vr_ (u"ࠫࡵࡲࠧএ"),l1llll1i1i11i1_vr_ (u"ࠬࡲ࡯ࡨࡱࠪঐ"),l1llll1i1i11i1_vr_ (u"࠭ࡷࡪࡦࡷ࡬ࠬ঑"),l1llll1i1i11i1_vr_ (u"ࠧࡩࡧ࡬࡫࡭ࡺࠧ঒"),l1llll1i1i11i1_vr_ (u"ࠨࡶࡵࡹࡪ࠭ও"),l1llll1i1i11i1_vr_ (u"ࠩࡶࡸࡦࡺࡩࡤࠩঔ"),l1llll1i1i11i1_vr_ (u"ࠪࡷࡹ࠭ক"),l1llll1i1i11i1_vr_ (u"ࠫࡲࡶ࠴ࠨখ"),l1llll1i1i11i1_vr_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫগ"),l1llll1i1i11i1_vr_ (u"࠭ࡶࡪࡦࡨࡳࠬঘ"),l1llll1i1i11i1_vr_ (u"ࠧࡴࡶࡤࡸ࡮ࡩࠧঙ"),
                    l1llll1i1i11i1_vr_ (u"ࠨࡶࡼࡴࡪ࠭চ"),l1llll1i1i11i1_vr_ (u"ࠩࡶࡻ࡫࠭ছ"),l1llll1i1i11i1_vr_ (u"ࠪࡴࡱࡧࡹࡦࡴࠪজ"),l1llll1i1i11i1_vr_ (u"ࠫ࡫࡯࡬ࡦࠩঝ"),l1llll1i1i11i1_vr_ (u"ࠬࡩ࡯࡯ࡶࡵࡳࡱࡨࡡࡳࠩঞ"),l1llll1i1i11i1_vr_ (u"࠭ࡡࡥࡵࠪট"),l1llll1i1i11i1_vr_ (u"ࠧࡤࡼࡤࡷࠬঠ"),l1llll1i1i11i1_vr_ (u"ࠨࡲࡲࡷ࡮ࡺࡩࡰࡰࠪড"),l1llll1i1i11i1_vr_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫঢ"),l1llll1i1i11i1_vr_ (u"ࠪࡦࡴࡺࡴࡰ࡯ࠪণ"),l1llll1i1i11i1_vr_ (u"ࠫࡺࡹࡥࡳࡃࡪࡩࡳࡺࠧত"),
                    l1llll1i1i11i1_vr_ (u"ࠬࡳࡡࡵࡥ࡫ࠫথ"),l1llll1i1i11i1_vr_ (u"࠭ࡰ࡯ࡩࠪদ"),l1llll1i1i11i1_vr_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡰࡴࠪধ"),l1llll1i1i11i1_vr_ (u"ࠨ࡫ࡧࠫন"), l1llll1i1i11i1_vr_ (u"ࠩ࠶࠻ࠬ঩"), l1llll1i1i11i1_vr_ (u"ࠪࡶࡪ࡭ࡩࡰࡰࡶࠫপ"), l1llll1i1i11i1_vr_ (u"ࠫ࠵࠿ࠧফ"), l1llll1i1i11i1_vr_ (u"ࠬ࡫࡮ࡢࡤ࡯ࡩࡩ࠭ব"), l1llll1i1i11i1_vr_ (u"࠭ࡳࡳࡥࠪভ"), l1llll1i1i11i1_vr_ (u"ࠧ࡮ࡧࡧ࡭ࡦ࠭ম")]
            l11l11l11i1i11i1_vr_=[l1llll1i1i11i1_vr_ (u"ࠨࡪࡷࡸࡵ࠭য"), l1llll1i1i11i1_vr_ (u"ࠩ࡯ࡳ࡬ࡵࠧর"), l1llll1i1i11i1_vr_ (u"ࠪࡻ࡮ࡪࡴࡩࠩ঱"), l1llll1i1i11i1_vr_ (u"ࠫ࡭࡫ࡩࡨࡪࡷࠫল"), l1llll1i1i11i1_vr_ (u"ࠬࡺࡲࡶࡧࠪ঳"), l1llll1i1i11i1_vr_ (u"࠭ࡳࡵࡣࡷ࡭ࡨ࠭঴"), l1llll1i1i11i1_vr_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭঵"), l1llll1i1i11i1_vr_ (u"ࠨࡸ࡬ࡨࡪࡵࠧশ"), l1llll1i1i11i1_vr_ (u"ࠩࡳࡰࡦࡿࡥࡳࠩষ"),
                l1llll1i1i11i1_vr_ (u"ࠪࡪ࡮ࡲࡥࠨস"), l1llll1i1i11i1_vr_ (u"ࠫࡹࡿࡰࡦࠩহ"), l1llll1i1i11i1_vr_ (u"ࠬࡸࡥࡨ࡫ࡲࡲࡸ࠭঺"), l1llll1i1i11i1_vr_ (u"࠭࡮ࡰࡰࡨࠫ঻"), l1llll1i1i11i1_vr_ (u"ࠧࡤࡼࡤࡷ়ࠬ"), l1llll1i1i11i1_vr_ (u"ࠨࡧࡱࡥࡧࡲࡥࡥࠩঽ"), l1llll1i1i11i1_vr_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫা"), l1llll1i1i11i1_vr_ (u"ࠪࡧࡴࡴࡴࡳࡱ࡯ࡦࡦࡸࠧি"), l1llll1i1i11i1_vr_ (u"ࠫࡲࡧࡴࡤࡪࠪী"), l1llll1i1i11i1_vr_ (u"ࠬࡨ࡯ࡵࡶࡲࡱࠬু"),
                l1llll1i1i11i1_vr_ (u"࠭ࡣࡦࡰࡷࡩࡷ࠭ূ"), l1llll1i1i11i1_vr_ (u"ࠧࡱࡱࡶ࡭ࡹ࡯࡯࡯ࠩৃ"), l1llll1i1i11i1_vr_ (u"ࠨࡷࡶࡩࡷࡇࡧࡦࡰࡷࠫৄ"), l1llll1i1i11i1_vr_ (u"ࠩࡱࡥࡻ࡯ࡧࡢࡶࡲࡶࠬ৅"), l1llll1i1i11i1_vr_ (u"ࠪࡧࡴࡴࡦࡪࡩࠪ৆"), l1llll1i1i11i1_vr_ (u"ࠫ࡭ࡺ࡭࡭ࠩে"), l1llll1i1i11i1_vr_ (u"ࠬ࡮ࡴ࡮࡮࠸ࠫৈ"), l1llll1i1i11i1_vr_ (u"࠭ࡰࡳࡱࡹ࡭ࡩ࡫ࡲࠨ৉"), l1llll1i1i11i1_vr_ (u"ࠧࡣ࡮ࡤࡧࡰ࠭৊"),
                l1llll1i1i11i1_vr_ (u"ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡆࡲࡩࡨࡰࠪো"), l1llll1i1i11i1_vr_ (u"ࠩࡦࡥࡳࡌࡩࡳࡧࡈࡺࡪࡴࡴࡂࡒࡌࡇࡦࡲ࡬ࡴࠩৌ"), l1llll1i1i11i1_vr_ (u"ࠪࡹࡸ࡫ࡖ࠳ࡃࡓࡍࡈࡧ࡬࡭ࡵ্ࠪ"), l1llll1i1i11i1_vr_ (u"ࠫࡻ࡫ࡲࡵ࡫ࡦࡥࡱࡇ࡬ࡪࡩࡱࠫৎ"), l1llll1i1i11i1_vr_ (u"ࠬࡺࡩ࡮ࡧࡶࡰ࡮ࡪࡥࡳࡶࡲࡳࡱࡺࡩࡱࡲ࡯ࡹ࡬࡯࡮ࠨ৏"),
                l1llll1i1i11i1_vr_ (u"࠭࡯ࡷࡧࡵࡰࡦࡿࡳࠨ৐"), l1llll1i1i11i1_vr_ (u"ࠧࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧࡇࡴࡲ࡯ࡳࠩ৑"), l1llll1i1i11i1_vr_ (u"ࠨ࡯ࡤࡶ࡬࡯࡮ࡣࡱࡷࡸࡴࡳࠧ৒"), l1llll1i1i11i1_vr_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯ࡵࠪ৓"), l1llll1i1i11i1_vr_ (u"ࠪࡰ࡮ࡴ࡫ࠨ৔"), l1llll1i1i11i1_vr_ (u"ࠫࡸࡺࡲࡦࡶࡦ࡬࡮ࡴࡧࠨ৕"), l1llll1i1i11i1_vr_ (u"ࠬࡻ࡮ࡪࡨࡲࡶࡲ࠭৖"), l1llll1i1i11i1_vr_ (u"࠭ࡳࡵࡣࡷ࡭ࡨ࠷ࠧৗ"),
                l1llll1i1i11i1_vr_ (u"ࠧࡴࡧࡷࡹࡵ࠭৘"), l1llll1i1i11i1_vr_ (u"ࠨ࡬ࡺࡴࡱࡧࡹࡦࡴࠪ৙"), l1llll1i1i11i1_vr_ (u"ࠩࡦ࡬ࡪࡩ࡫ࡇ࡮ࡤࡷ࡭࠭৚"), l1llll1i1i11i1_vr_ (u"ࠪࡗࡲࡧࡲࡵࡖ࡙ࠫ৛"), l1llll1i1i11i1_vr_ (u"ࠫࡻ࠶࠰࠲ࠩড়"), l1llll1i1i11i1_vr_ (u"ࠬࡩࡲࡦ࡯ࡨࠫঢ়"), l1llll1i1i11i1_vr_ (u"࠭ࡤࡰࡥ࡮ࠫ৞"), l1llll1i1i11i1_vr_ (u"ࠧࡢࡷࡷࡳࡸࡺࡡࡳࡶࠪয়"), l1llll1i1i11i1_vr_ (u"ࠨ࡫ࡧࡰࡪ࡮ࡩࡥࡧࠪৠ"), l1llll1i1i11i1_vr_ (u"ࠩࡰࡳࡩ࡫ࡳࠨৡ"),
               l1llll1i1i11i1_vr_ (u"ࠪࡪࡱࡧࡳࡩࠩৢ"), l1llll1i1i11i1_vr_ (u"ࠫࡴࡼࡥࡳࠩৣ"), l1llll1i1i11i1_vr_ (u"ࠬࡲࡥࡧࡶࠪ৤"), l1llll1i1i11i1_vr_ (u"࠭ࡨࡪࡦࡨࠫ৥"), l1llll1i1i11i1_vr_ (u"ࠧࡱ࡮ࡤࡽࡪࡸ࠵ࠨ০"), l1llll1i1i11i1_vr_ (u"ࠨ࡫ࡰࡥ࡬࡫ࠧ১"), l1llll1i1i11i1_vr_ (u"ࠩࡎࡐࡎࡑࡎࡊࡌࠪ২"), l1llll1i1i11i1_vr_ (u"ࠪࡧࡴࡳࡰࡢࡰ࡬ࡳࡳࡹࠧ৩"), l1llll1i1i11i1_vr_ (u"ࠫࡷ࡫ࡳࡵࡱࡵࡩࠬ৪"), l1llll1i1i11i1_vr_ (u"ࠬࡩ࡬ࡪࡥ࡮ࡗ࡮࡭࡮ࠨ৫"),
                l1llll1i1i11i1_vr_ (u"࠭ࡳࡤࡪࡨࡨࡺࡲࡥࠨ৬"), l1llll1i1i11i1_vr_ (u"ࠧࡠࡥࡲࡹࡳࡺࡤࡰࡹࡱࡣࠬ৭"), l1llll1i1i11i1_vr_ (u"ࠨࡥࡲࡹࡳࡺࡤࡰࡹࡱࠫ৮"), l1llll1i1i11i1_vr_ (u"ࠩࡵࡩ࡬࡯࡯࡯ࠩ৯"), l1llll1i1i11i1_vr_ (u"ࠪࡩࡱࡹࡥࠨৰ"), l1llll1i1i11i1_vr_ (u"ࠫࡨࡵ࡮ࡵࡴࡲࡰࡸ࠭ৱ"), l1llll1i1i11i1_vr_ (u"ࠬࡶࡲࡦ࡮ࡲࡥࡩ࠭৲"), l1llll1i1i11i1_vr_ (u"࠭࡯ࡳࡻࡪ࡭ࡳࡧ࡬࡯ࡧࠪ৳"), l1llll1i1i11i1_vr_ (u"ࠧࡴࡶࡼࡰࡪ࠭৴"),
                l1llll1i1i11i1_vr_ (u"ࠨ࠸࠵࠴ࡵࡾࠧ৵"), l1llll1i1i11i1_vr_ (u"ࠩ࠶࠼࠼ࡶࡸࠨ৶"), l1llll1i1i11i1_vr_ (u"ࠪࡴࡴࡹࡴࡦࡴࠪ৷"), l1llll1i1i11i1_vr_ (u"ࠫࡿࡴࡩ࡬ࡰ࡬ࡩࠬ৸"), l1llll1i1i11i1_vr_ (u"ࠬࡹࡥ࡬ࡷࡱࡨࠬ৹"), l1llll1i1i11i1_vr_ (u"࠭ࡳࡩࡱࡺࡅ࡫ࡺࡥࡳࡕࡨࡧࡴࡴࡤࡴࠩ৺"), l1llll1i1i11i1_vr_ (u"ࠧࡪ࡯ࡤ࡫ࡪࡹࠧ৻"), l1llll1i1i11i1_vr_ (u"ࠨࡔࡨ࡯ࡱࡧ࡭ࡢࠩৼ"), l1llll1i1i11i1_vr_ (u"ࠩࡶ࡯࡮ࡶࡁࡥࠩ৽"),
                 l1llll1i1i11i1_vr_ (u"ࠪࡰࡪࡼࡥ࡭ࡵࠪ৾"), l1llll1i1i11i1_vr_ (u"ࠫࡵࡧࡤࡥ࡫ࡱ࡫ࠬ৿"), l1llll1i1i11i1_vr_ (u"ࠬࡵࡰࡢࡥ࡬ࡸࡾ࠭਀"), l1llll1i1i11i1_vr_ (u"࠭ࡤࡦࡤࡸ࡫ࠬਁ"), l1llll1i1i11i1_vr_ (u"ࠧࡷ࡫ࡧࡩࡴ࠹ࠧਂ"), l1llll1i1i11i1_vr_ (u"ࠨࡥ࡯ࡳࡸ࡫ࠧਃ"), l1llll1i1i11i1_vr_ (u"ࠩࡶࡱࡦࡲ࡬ࡵࡧࡻࡸࠬ਄"), l1llll1i1i11i1_vr_ (u"ࠪࡱࡪࡹࡳࡢࡩࡨࠫਅ"), l1llll1i1i11i1_vr_ (u"ࠫࡨࡲࡡࡴࡵࠪਆ"), l1llll1i1i11i1_vr_ (u"ࠬࡧ࡬ࡪࡩࡱࠫਇ"),
                  l1llll1i1i11i1_vr_ (u"࠭࡮ࡰࡶ࡬ࡧࡪ࠭ਈ"), l1llll1i1i11i1_vr_ (u"ࠧ࡮ࡧࡧ࡭ࡦ࠭ਉ")]
            for l11llll11i1i11i1_vr_ in l11l11l11i1i11i1_vr_:
                l11ll1llli1i11i1_vr_=l11ll1llli1i11i1_vr_.replace(l11llll11i1i11i1_vr_,l1llll1i1i11i1_vr_ (u"ࠨࠩਊ"))
            cleanup=l11ll1llli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠩࡿࠫ਋"),l1llll1i1i11i1_vr_ (u"ࠪࠤࠬ਌")).split()
            out={l1llll1i1i11i1_vr_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࠫ਍"): l1llll1i1i11i1_vr_ (u"ࠬ࠭਎"), l1llll1i1i11i1_vr_ (u"࠭ࡥࠨਏ"): l1llll1i1i11i1_vr_ (u"ࠧࠨਐ"), l1llll1i1i11i1_vr_ (u"ࠨࡨ࡬ࡰࡪ࠭਑"): l1llll1i1i11i1_vr_ (u"ࠩࠪ਒"), l1llll1i1i11i1_vr_ (u"ࠪࡷࡹ࠭ਓ"): l1llll1i1i11i1_vr_ (u"ࠫࠬਔ")}
            if len(cleanup)==4:
                print l1llll1i1i11i1_vr_ (u"ࠬࡒࡥ࡯ࡩࡷ࡬ࠥࡕࡋࠨਕ")
                for l11llll11i1i11i1_vr_ in cleanup:
                    if l11llll11i1i11i1_vr_.isdigit():
                        out[l1llll1i1i11i1_vr_ (u"࠭ࡥࠨਖ")]=l11llll11i1i11i1_vr_
                    elif re.match(l1llll1i1i11i1_vr_ (u"ࠧ࡜ࡣ࠰ࡾࡢࢁ࠲࠭ࡿ࡟ࡨࢀ࠹ࡽࠨਗ"),l11llll11i1i11i1_vr_) and len(l11llll11i1i11i1_vr_)<10:
                        out[l1llll1i1i11i1_vr_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࠨਘ")] = l11llll11i1i11i1_vr_
                    elif len(l11llll11i1i11i1_vr_)==22:
                        out[l1llll1i1i11i1_vr_ (u"ࠩࡶࡸࠬਙ")] = l11llll11i1i11i1_vr_
                    else:
                        out[l1llll1i1i11i1_vr_ (u"ࠪࡪ࡮ࡲࡥࠨਚ")] = l11llll11i1i11i1_vr_
                src=l1llll1i1i11i1_vr_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࠪࡹ࠮ࡤࡦࡤ࠲ࡵࡲ࠯ࠦࡵ࠱ࡱࡵ࠺࠿ࡴࡶࡀࠩࡸࠬࡥ࠾ࠧࡶࠫਛ")%(out.get(l1llll1i1i11i1_vr_ (u"ࠬࡹࡥࡳࡸࡨࡶࠬਜ")),out.get(l1llll1i1i11i1_vr_ (u"࠭ࡦࡪ࡮ࡨࠫਝ")),out.get(l1llll1i1i11i1_vr_ (u"ࠧࡴࡶࠪਞ")),out.get(l1llll1i1i11i1_vr_ (u"ࠨࡧࠪਟ")))
    return src
def l11ll1l11i1i11i1_vr_(content):
    l1llll1i1i11i1_vr_ (u"ࠤࠥࠦࠒࠐࠠࠡࠢࠣࡗࡨࡧ࡮ࡴࠢࡩࡳࡷࠦࡶࡪࡦࡨࡳࠥࡲࡩ࡯࡭ࠣ࡭ࡳࡩ࡬ࡶࡦࡨࡨࠥ࡫࡮ࡤࡱࡧࡩࡩࠦ࡯࡯ࡧࠐࠎࠥࠦࠠࠡࠤࠥࠦਠ")
    l11l1l1lli1i11i1_vr_=l1llll1i1i11i1_vr_ (u"ࠪࠫਡ")
    l11l1lll1i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠫ࡫࡯࡬ࡦ࠼ࠣ࡟ࡡ࠭ࠢ࡞ࠪ࠱࠯ࡄ࠯࡛࡝ࠩࠥࡡ࠱࠭ਢ"),  re.DOTALL).search(content)
    l11ll1111i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠬࡻࡲ࡭࠼ࠣ࡟ࡡ࠭ࠢ࡞ࠪ࠱࠯ࡄ࠯࡛࡝ࠩࠥࡡ࠱࠭ਣ"),  re.DOTALL).search(content)
    if l11l1lll1i1i11i1_vr_:
        print l1llll1i1i11i1_vr_ (u"࠭ࡦࡰࡷࡱࡨࠥࡘࡅࠡ࡝ࡩ࡭ࡱ࡫࠺࡞ࠩਤ")
        l11l1l1lli1i11i1_vr_ = l11l1lll1i1i11i1_vr_.group(1)
    elif l11ll1111i1i11i1_vr_:
        print l1llll1i1i11i1_vr_ (u"ࠧࡧࡱࡸࡲࡩࠦࡒࡆࠢ࡞ࡹࡷࡲ࠺࡞ࠩਥ")
        l11l1l1lli1i11i1_vr_ = l11ll1111i1i11i1_vr_.group(1)
    else:
        print l1llll1i1i11i1_vr_ (u"ࠨࡧࡱࡧࡴࡪࡥࡥࠢ࠽ࠤࡺࡴࡰࡢࡥ࡮ࡩࡷ࠭ਦ")
        l11l1l1lli1i11i1_vr_ = _11ll1ll1i1i11i1_vr_(content)
        if not l11l1l1lli1i11i1_vr_:
            print l1llll1i1i11i1_vr_ (u"ࠩࡨࡲࡨࡵࡤࡦࡦࠣ࠾ࠥ࡬࡯ࡳࡥࡨࠤࠬਧ")
            l11l1l1lli1i11i1_vr_ = _11l1lllli1i11i1_vr_(content)
    return l11l1l1lli1i11i1_vr_
def l111l1li1i11i1_vr_(url):
    l1llll1i1i11i1_vr_ (u"ࠥࠦࠧࠓࠊࠡࠢࠣࠤࡷ࡫ࡴࡶࡴࡱࡷࠥࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡ࠯ࠣࡹࡱࡸࠠࡩࡶࡷࡴ࠿࠵࠯࠯࠰࠱࠲ࠒࠐࠠࠡࠢࠣࠤࠥࠦࠠ࠮ࠢࡲࡶࠥࡲࡩࡴࡶࠣࡳ࡫࡛ࠦࠩࠩ࠺࠶࠵ࡶࠧ࠭ࠢࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡤࡦࡤ࠲ࡵࡲ࠯ࡷ࡫ࡧࡩࡴ࠵࠱࠺࠶࠹࠽࠾࠷ࡦࡀࡹࡨࡶࡸࡰࡡ࠾࠹࠵࠴ࡵ࠭ࠩ࠭࠰࠱࠲ࡢࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠐࠎࠥࠦࠠࠡࠤࠥࠦਨ")
    if l1llll1i1i11i1_vr_ (u"ࠫࡪࡨࡤ࠯ࡥࡧࡥ࠳ࡶ࡬ࠨ਩") in url:
        id = url.split(l1llll1i1i11i1_vr_ (u"ࠬ࠵ࠧਪ"))[-1]
        url = l1llll1i1i11i1_vr_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡧࡩࡧ࠮ࡱ࡮࠲ࡺ࡮ࡪࡥࡰ࠱ࠨࡷࠬਫ")%id
    l11l1l1l1i1i11i1_vr_=l1llll1i1i11i1_vr_ (u"ࠧࡽࡅࡲࡳࡰ࡯ࡥ࠾ࠤࡓࡌࡕ࡙ࡅࡔࡕࡌࡈࡂ࠷ࠦࡓࡧࡩࡩࡷ࡫ࡲ࠾ࡪࡷࡸࡵࡀ࠯࠰ࡵࡷࡥࡹ࡯ࡣ࠯ࡥࡧࡥ࠳ࡶ࡬࠰ࡲ࡯ࡥࡾ࡫ࡲ࠶࠰࠼࠳ࡵࡲࡡࡺࡧࡵ࠲ࡸࡽࡦࠨਬ")
    l11l11llli1i11i1_vr_=l1llll1i1i11i1_vr_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀ࡬ࡹࡺࡰ࠻࠱࠲ࡷࡹࡧࡴࡪࡥ࠱ࡧࡩࡧ࠮ࡱ࡮࠲ࡴࡱࡧࡹࡦࡴ࠸࠲࠾࠵ࡰ࡭ࡣࡼࡩࡷ࠴ࡳࡸࡨࠪਭ")
    print url
    content = l1l1llli1i11i1_vr_(url)
    src=[]
    if not l1llll1i1i11i1_vr_ (u"ࠩࡂࡻࡪࡸࡳ࡫ࡣࠪਮ") in url:
         l11l1l11li1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠪࡀࡦࠦࡤࡢࡶࡤ࠱ࡶࡻࡡ࡭࡫ࡷࡽࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࠨࡀࡒ࠿ࡌࡃ࠴ࠪࡀࠫࡁࠬࡄࡖ࠼ࡒࡀ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫਯ"), re.DOTALL).findall(content)
         for quality in l11l1l11li1i11i1_vr_:
             l11l1lli1i11i1_vr_ = re.search(l1llll1i1i11i1_vr_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪਰ"),quality[1])
             l11l11l1li1i11i1_vr_ = quality[2]
             src.insert(0,(l11l11l1li1i11i1_vr_,l1lll1lli1i11i1_vr_+l11l1lli1i11i1_vr_.group(1)))
    if not src:
        src = l11ll1l11i1i11i1_vr_(content)
        if src:
            src+=l11l1l1l1i1i11i1_vr_+l11l11llli1i11i1_vr_
    return src
def l11ll11l1i1i11i1_vr_(url,quality=0):
    l1llll1i1i11i1_vr_ (u"ࠧࠨࠢࠎࠌࠣࠤࠥࠦࡲࡦࡶࡸࡶࡳࡹࠠࡶࡴ࡯ࠤࡹࡵࠠࡷ࡫ࡧࡩࡴࠓࠊࠡࠢࠣࠤࠧࠨࠢ਱")
    src = l111l1li1i11i1_vr_(url)
    if type(src)==list:
        selected=src[quality]
        print l1llll1i1i11i1_vr_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࠠ࠻ࠩਲ"),selected[0]
        src = l111l1li1i11i1_vr_(selected[1])
    return src
