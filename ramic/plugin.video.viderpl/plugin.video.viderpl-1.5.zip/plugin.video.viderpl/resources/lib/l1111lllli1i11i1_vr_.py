# -*- coding: utf-8 -*-
import sys
l1ll111i1i11i1_vr_ = sys.version_info [0] == 2
l1l1l1i1i11i1_vr_ = 2048
l1ll1li1i11i1_vr_ = 7
def l1llll1i1i11i1_vr_ (l1i1i11i1_vr_):
	global l1l1ll1i1i11i1_vr_
	l1lll11li1i11i1_vr_ = ord (l1i1i11i1_vr_ [-1])
	l1ll11li1i11i1_vr_ = l1i1i11i1_vr_ [:-1]
	l1l1li1i11i1_vr_ = l1lll11li1i11i1_vr_ % len (l1ll11li1i11i1_vr_)
	l1l11i1i11i1_vr_ = l1ll11li1i11i1_vr_ [:l1l1li1i11i1_vr_] + l1ll11li1i11i1_vr_ [l1l1li1i11i1_vr_:]
	if l1ll111i1i11i1_vr_:
		l11lllli1i11i1_vr_ = unicode () .join ([unichr (ord (char) - l1l1l1i1i11i1_vr_ - (l11111i1i11i1_vr_ + l1lll11li1i11i1_vr_) % l1ll1li1i11i1_vr_) for l11111i1i11i1_vr_, char in enumerate (l1l11i1i11i1_vr_)])
	else:
		l11lllli1i11i1_vr_ = str () .join ([chr (ord (char) - l1l1l1i1i11i1_vr_ - (l11111i1i11i1_vr_ + l1lll11li1i11i1_vr_) % l1ll1li1i11i1_vr_) for l11111i1i11i1_vr_, char in enumerate (l1l11i1i11i1_vr_)])
	return eval (l11lllli1i11i1_vr_)
l1llll1i1i11i1_vr_ (u"ࠢࠣࠤࠐࠎࠒࠐࡀࡢࡷࡷ࡬ࡴࡸ࠺ࠡࡴࡤࡱ࡮ࡩࡳࡱࡣࠐࠎࠧࠨࠢਲ਼")
import urllib2,urllib
import re
import json as json
l1lll1lli1i11i1_vr_=l1llll1i1i11i1_vr_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡨࡵࡩࡪࡪࡩࡴࡥ࠱ࡴࡱ࠭਴")
l11ll1l1li1i11i1_vr_ = 30
def l1l1llli1i11i1_vr_(url,data=None,headers={},cookies=None):
    if headers:
        l1111l1l1i1i11i1_vr_=headers
    else:
        l1111l1l1i1i11i1_vr_ = {l1llll1i1i11i1_vr_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ਵ"):l1llll1i1i11i1_vr_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡏࡘ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠷࠼࠳࠶࠮࠳࠷࠹࠸࠳࠿࠷ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨਸ਼")}
    req = urllib2.Request(url,data,l1111l1l1i1i11i1_vr_)
    if cookies:
        req.add_header(l1llll1i1i11i1_vr_ (u"ࠦࡈࡵ࡯࡬࡫ࡨࠦ਷"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l11ll1l1li1i11i1_vr_)
        l11l1lli1i11i1_vr_ =  response.read()
        response.close()
    except:
        l11l1lli1i11i1_vr_=l1llll1i1i11i1_vr_ (u"ࠬ࠭ਸ")
    return l11l1lli1i11i1_vr_
def _111l11l1i1i11i1_vr_(l111l11lli1i11i1_vr_):
    out=[]
    for item in l111l11lli1i11i1_vr_:
        l111l1ll1i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"࠭࠼ࡱࠢࡦࡰࡦࡹࡳ࠾ࠤࡷ࡭ࡹࡲࡥࠣࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡨࡲࡡࡴࡵࡀࠦ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩਹ")).findall(item)
        l111lll11i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠧ࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࠫ਺")).findall(item)
        l11l111l1i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠨ࠾ࡳࠤࡨࡲࡡࡴࡵࡀࠦࡲ࡫ࡴࡢࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡴࡃ࠭਻")).findall(item)
        l11l11111i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡥࡷࡵࡥࡹ࡯࡯࡯ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ਼")).findall(item)
        l111lll1li1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠪࡀࡵࠦࡣ࡭ࡣࡶࡷࡂࠨࡤࡦࡵࡦࡶ࡮ࡶࡴࡪࡱࡱࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡶ࠾ࠨ਽")).findall(item)
        if l111l1ll1i1i11i1_vr_:
            l1111ll1li1i11i1_vr_ =l1llll1i1i11i1_vr_ (u"ࠫࠬਾ")
            if l11l111l1i1i11i1_vr_:
                l111llllli1i11i1_vr_ = l1llll1i1i11i1_vr_ (u"ࠬࠦࠧਿ").join(re.compile(l1llll1i1i11i1_vr_ (u"࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧੀ")).findall(l11l111l1i1i11i1_vr_[0])).strip()
                l111l1l11i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠧࡌࡣࡷࡥࡱࡵࡧࣴࡹ࠽ࠤࡡࡪࠫࠡ࠱ࠣࡔࡱ࡯࡫ࣴࡹ࠽ࠤࡡࡪࠫࠨੁ")).findall(l111llllli1i11i1_vr_)
                l111l1l1li1i11i1_vr_ = True if l1llll1i1i11i1_vr_ (u"ࠨࡈ࡬ࡰࡲࡿ࠺ࠨੂ") in l111llllli1i11i1_vr_ and l1llll1i1i11i1_vr_ (u"ࠩࡕࡳࡿࡳࡩࡢࡴ࠽ࠫ੃") in l111llllli1i11i1_vr_ else False
                if l111l1l11i1i11i1_vr_:
                    l1111ll1li1i11i1_vr_ = l111l1l11i1i11i1_vr_[0]
                elif l111l1l1li1i11i1_vr_:
                    l1111ll1li1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠪࠤࠥ࠭੄"),l1llll1i1i11i1_vr_ (u"ࠫࠥ࠭੅"))
            l11l111lli1i11i1_vr_=l1llll1i1i11i1_vr_ (u"ࠬ࠭੆")
            if l111lll11i1i11i1_vr_:
                l11l111lli1i11i1_vr_ = l111lll11i1i11i1_vr_[0]
                if not l1llll1i1i11i1_vr_ (u"࠭ࡨࡵࡶࡳࠫੇ") in l11l111lli1i11i1_vr_:
                   l11l111lli1i11i1_vr_ =  l1lll1lli1i11i1_vr_ + l11l111lli1i11i1_vr_
            l11llll11i1i11i1_vr_ = {l1llll1i1i11i1_vr_ (u"ࠧࡩࡴࡨࡪࠬੈ")  : l1lll1lli1i11i1_vr_+l111l1ll1i1i11i1_vr_[0][0],
                   l1llll1i1i11i1_vr_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ੉") : l111ll1lli1i11i1_vr_(l111l1ll1i1i11i1_vr_[0][1]).strip() if l111l1ll1i1i11i1_vr_ else l1llll1i1i11i1_vr_ (u"ࠩࠪ੊"),
                   l1llll1i1i11i1_vr_ (u"ࠪ࡭ࡲ࡭ࠧੋ") : l11l111lli1i11i1_vr_,
                   l1llll1i1i11i1_vr_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫੌ"): l111ll1lli1i11i1_vr_(l1111ll1li1i11i1_vr_).strip(),
                   l1llll1i1i11i1_vr_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴ੍ࠧ"): l11l11111i1i11i1_vr_[0] if l11l11111i1i11i1_vr_ else l1llll1i1i11i1_vr_ (u"࠭ࠧ੎"),
                   l1llll1i1i11i1_vr_ (u"ࠧࡱ࡮ࡲࡸࠬ੏") :l111ll1lli1i11i1_vr_(l111lll1li1i11i1_vr_[0]).strip() if l111lll1li1i11i1_vr_ else l1llll1i1i11i1_vr_ (u"ࠨࠩ੐"),
                   }
            if l11llll11i1i11i1_vr_.get(l1llll1i1i11i1_vr_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩੑ")):
                l11llll11i1i11i1_vr_[l1llll1i1i11i1_vr_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ੒")] = l1llll1i1i11i1_vr_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟ࠨࡷࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࠭ࠡ࡝ࡆࡓࡑࡕࡒࠡࡩࡵࡩࡪࡴ࡝ࠦࡵ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ੓") %(l11llll11i1i11i1_vr_[l1llll1i1i11i1_vr_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ੔")], l11llll11i1i11i1_vr_.get(l1llll1i1i11i1_vr_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭੕")))
            out.append(l11llll11i1i11i1_vr_)
    return out
def _1111ll11i1i11i1_vr_(l11l1111li1i11i1_vr_):
    out=[]
    for item in l11l1111li1i11i1_vr_:
        href = re.compile(l1llll1i1i11i1_vr_ (u"ࠧࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠨ੖")).findall(item)
        l111lll11i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠨ࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀ࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࠥࡧ࡬ࡵ࠿࡞ࠦࡡ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠࠫ੗")).findall(item)
        if href and l111lll11i1i11i1_vr_:
            l11llll11i1i11i1_vr_ = {l1llll1i1i11i1_vr_ (u"ࠩ࡫ࡶࡪ࡬ࠧ੘")   : l1lll1lli1i11i1_vr_+href[0],
                   l1llll1i1i11i1_vr_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩਖ਼") : l111ll1lli1i11i1_vr_(l111lll11i1i11i1_vr_[0][1]).strip(),
                   l1llll1i1i11i1_vr_ (u"ࠫ࡮ࡳࡧࠨਗ਼") : l111lll11i1i11i1_vr_[0][0],
                   l1llll1i1i11i1_vr_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬਜ਼"): True,
                }
            out.append(l11llll11i1i11i1_vr_)
    return out
def _111ll1l1i1i11i1_vr_(l1111lll1i1i11i1_vr_):
    out=[]
    for item in l1111lll1i1i11i1_vr_:
        href = re.compile(l1llll1i1i11i1_vr_ (u"࠭ࡨࡳࡧࡩࡁࡠࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢ࠭ੜ")).findall(item)
        l111lll11i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠧ࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿࡞ࠦࡡ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠࠫ੝")).findall(item)
        title = re.compile(l1llll1i1i11i1_vr_ (u"ࠨ࠾ࡤࠤࡹ࡯ࡴ࡭ࡧࡀ࡟ࠧࡢࠧ࡞ࠪ࠱࠮ࡄ࠯࡛ࠣ࡞ࠪࡡࠬਫ਼")).findall(item)
        if href and title:
            l11llll11i1i11i1_vr_ = {l1llll1i1i11i1_vr_ (u"ࠩ࡫ࡶࡪ࡬ࠧ੟")   : l1lll1lli1i11i1_vr_+href[0],
                   l1llll1i1i11i1_vr_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ੠") : l111ll1lli1i11i1_vr_(title[0]).strip(),
                   l1llll1i1i11i1_vr_ (u"ࠫ࡮ࡳࡧࠨ੡") : l111lll11i1i11i1_vr_[0],
                   l1llll1i1i11i1_vr_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ੢"): False,
                   }
            out.append(l11llll11i1i11i1_vr_)
    return out
def _111l1111i1i11i1_vr_(l111ll11li1i11i1_vr_):
    out=[]
    for item in l111ll11li1i11i1_vr_:
        href = re.compile(l1llll1i1i11i1_vr_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽࡜ࠤ࡟ࠫࡢ࠮࠮ࠫࡁࠬ࡟ࠧࡢࠧ࡞ࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬ੣")).findall(item)
        l111lll11i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠧ࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿࡞ࠦࡡ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠࠫ੤")).findall(item)
        info = re.compile(l1llll1i1i11i1_vr_ (u"ࠨࡵࡷࡽࡱ࡫࠽࡜ࠤ࡟ࠫࡢࡡࠢ࡝ࠩࡠࡂ࠭࠴ࠪࡀࠫࠧࠫ੥")).findall(item)
        print href
        if href and title and info:
            h= l1lll1lli1i11i1_vr_ + l1llll1i1i11i1_vr_ (u"ࠩ࠲ࠫ੦") if not href[0][0].startswith(l1llll1i1i11i1_vr_ (u"ࠪ࠳ࠬ੧")) else l1lll1lli1i11i1_vr_
            info = info[0]
            l11llll11i1i11i1_vr_ = {l1llll1i1i11i1_vr_ (u"ࠫ࡭ࡸࡥࡧࠩ੨")   : h+href[0][0],
                   l1llll1i1i11i1_vr_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ੩") : l111ll1lli1i11i1_vr_(href[0][1].strip()),
                   l1llll1i1i11i1_vr_ (u"࠭ࡩ࡮ࡩࠪ੪") : l111lll11i1i11i1_vr_[0],
                   l1llll1i1i11i1_vr_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ੫"): False,
                   }
            out.append(l11llll11i1i11i1_vr_)
    return out
def l111i1i11i1_vr_(url):
    out=[]
    l1111l11li1i11i1_vr_={}
    print l1llll1i1i11i1_vr_ (u"ࠨࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯࠰ࠪࠫࠬ࠭࠮࠯ࡹࡣࡢࡰࡘࡷࡪࡸࠧ੬"), url
    content=l1l1llli1i11i1_vr_(url)
    l11l1111li1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡧࡴ࡬ࡩࡳࡪࡳ࠮࡫ࡷࡩࡲࠦࡨࡰࡸࡨࡶࠥࡶࡡࡥࡦ࡬ࡲ࡬࠳࠵ࠡࡱࡹࡩࡷ࡬࡬ࡰࡹ࠰ࡥࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩ੭"),re.DOTALL).findall(content)
    l1111lll1i1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡹ࠰࠵࠵࠶࠭ࡱࠢࡲࡺࡪࡸࡦ࡭ࡱࡺ࠱ࡦࠦࡨࡰࡸࡨࡶࠥࡳࡡࡳࡩ࡬ࡲ࠲ࡺ࠭࡮࡫ࡱࡹࡸ࠳࠱ࠣࠢࡶࡸࡾࡲࡥ࠾ࠤࡥࡳࡷࡪࡥࡳ࠯ࡥࡳࡹࡺ࡯࡮࠼ࠣ࠵ࡵࡾࠠࡴࡱ࡯࡭ࡩࠦࠊࠡࠢࠣࠤࡩ࡯ࡲࡠ࡫ࡷࡩࡲࠦ࠽ࠡࡴࡨ࠲ࡨࡵ࡭ࡱ࡫࡯ࡩ࠭࠭੮")<l1111l1lli1i11i1_vr_ class=l1llll1i1i11i1_vr_ (u"ࠦࡩ࡯ࡲ࠮࡫ࡷࡩࡲࠨ੯")>(.*?)</l1111l1lli1i11i1_vr_></l1111l1lli1i11i1_vr_>l1llll1i1i11i1_vr_ (u"ࠬ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࡨࡵ࡮ࡵࡧࡱࡸ࠮ࠓࠊࠡࠢࠣࠤࠒࠐࠠࠡࠢࠣࠑࠏࠦࠠࠡࠢ࡬ࡪࠥࡻࡳࡦࡴࡵࡥࡳࡱࡩ࡯ࡩ࠽ࠑࠏࠦࠠࠡࠢࠣࠤࠥࠦ࡯ࡶࡶࠣࡁࠥࡥࡧࡦࡶࡢࡹࡸ࡫ࡲࡳࡣࡱ࡯࡮ࡴࡧࠩࡷࡶࡩࡷࡸࡡ࡯࡭࡬ࡲ࡬࠯ࠍࠋࠢࠣࠤࠥ࡫࡬ࡪࡨࠣࡳࡻ࡫ࡲࡧ࡮ࡲࡻ࠿ࠓࠊࠡࠢࠣࠤࠥࠦࠠࠡࡱࡸࡸࠥࡃࠠࡠࡩࡨࡸࡤࡵࡶࡦࡴࡩࡰࡴࡽࡴࡺࡲࡨࠬࡴࡼࡥࡳࡨ࡯ࡳࡼ࠯ࠠࠡࠢࠣࠑࠏࠦࠠࠡࠢࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥ࡬ࡩ࡭ࡧࡗࡶࡪ࡫ࡌࡪࡰ࡮ࠤࡂࠦࡲࡦ࠰ࡦࡳࡲࡶࡩ࡭ࡧࠫࠫੰ")<a class=[l1llll1i1i11i1_vr_ (u"ࠨ࡜ࠨ࡟ࡰࡩࡳࡻ࠭ࡴࡻࡶࡸࡪࡳ࡛ࠣੱ")\l1llll1i1i11i1_vr_ (u"ࠧ࡞ࠢ࡫ࡶࡪ࡬࠽࡜ࠤ࡟ࠫࡢ࠮࠮ࠫࡁࠬ࡟ࠧࡢࠧ࡞ࡀࠪੲ")).findall(content)
        if l111ll111i1i11i1_vr_:
            l1111l11li1i11i1_vr_ = {l1llll1i1i11i1_vr_ (u"ࠨࡪࡵࡩ࡫࠭ੳ"):l1lll1lli1i11i1_vr_+l111ll111i1i11i1_vr_[0],l1llll1i1i11i1_vr_ (u"ࠩࡷ࡭ࡹࡲࡥࠨੴ"):l1llll1i1i11i1_vr_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞࡝ࡖࡽࡸࡺࡥ࡮ࠢࡓࡰ࡮ࡱࣳࡸ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫੵ"),l1llll1i1i11i1_vr_ (u"ࠫ࡮ࡳࡧࠨ੶"):l1llll1i1i11i1_vr_ (u"ࠬ࠭੷"),l1llll1i1i11i1_vr_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭੸"):True}
            out.insert(0,l1111l11li1i11i1_vr_)
    elif l111l11lli1i11i1_vr_:
        out = _111l11l1i1i11i1_vr_(l111l11lli1i11i1_vr_)
    return out
def search(l111llllli1i11i1_vr_=l1llll1i1i11i1_vr_ (u"ࠧࡵࡣࡱ࡫ࡱ࡫ࡤࠡࡧࡹࡩࡷࠦࡡࡧࡶࡨࡶࠬ੹")):
    out=[]
    url=l1llll1i1i11i1_vr_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡸ࡬ࡨࡪࡸ࠮ࡱ࡮࠲ࡷࡪࡧࡲࡤࡪ࠲࡫ࡪࡺࠧ੺")
    l111llll1i1i11i1_vr_ = {l1llll1i1i11i1_vr_ (u"ࠤࡶࡩࡦࡸࡣࡩࡡࡳ࡬ࡷࡧࡳࡦࠤ੻"):l111llllli1i11i1_vr_,l1llll1i1i11i1_vr_ (u"ࠥࡷࡪࡧࡲࡤࡪࡢࡸࡾࡶࡥࠣ੼"):l1llll1i1i11i1_vr_ (u"ࠦࡦࡲ࡬ࠣ੽"),l1llll1i1i11i1_vr_ (u"ࠧࡹࡥࡢࡴࡦ࡬ࡤࡹࡡࡷࡧࡧࠦ੾"):0,l1llll1i1i11i1_vr_ (u"ࠨࡰࡢࡩࡨࡷࠧ੿"):1,l1llll1i1i11i1_vr_ (u"ࠢ࡭࡫ࡰ࡭ࡹࠨ઀"):150}
    headers= {l1llll1i1i11i1_vr_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬઁ"):l1llll1i1i11i1_vr_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠶࠻࠲࠵࠴࠲࠶࠸࠷࠲࠾࠽ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧં"),
            l1llll1i1i11i1_vr_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭ઃ"):l1llll1i1i11i1_vr_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ઄")}
    content=l1l1llli1i11i1_vr_(url,data=json.dumps(l111llll1i1i11i1_vr_),headers=headers)
    if content:
        data=json.loads(content)
        print data.keys()
        l111l1llli1i11i1_vr_ = data.get(l1llll1i1i11i1_vr_ (u"ࠬࡸࡥࡴࡲࡲࡲࡸ࡫ࠧઅ"),{}).get(l1llll1i1i11i1_vr_ (u"࠭ࡤࡢࡶࡤࡣ࡫࡯࡬ࡦࡵࠪઆ"),{}).get(l1llll1i1i11i1_vr_ (u"ࠧࡥࡣࡷࡥࠬઇ"),[])
        for item in l111l1llli1i11i1_vr_:
            l11llll11i1i11i1_vr_ = {l1llll1i1i11i1_vr_ (u"ࠨࡪࡵࡩ࡫࠭ઈ")  : l1llll1i1i11i1_vr_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡹ࡭ࡩ࡫ࡲ࠯ࡲ࡯࠳ࡪࡳࡢࡦࡦ࠲ࡺ࡮ࡪࡥࡰ࠱ࠪઉ")+item.get(l1llll1i1i11i1_vr_ (u"ࠪ࡭ࡩࡥࡵࡳ࡮ࠪઊ"),l1llll1i1i11i1_vr_ (u"ࠫࠬઋ")),
                   l1llll1i1i11i1_vr_ (u"ࠬࡺࡩࡵ࡮ࡨࠫઌ") : l111ll1lli1i11i1_vr_(item.get(l1llll1i1i11i1_vr_ (u"࠭࡮ࡢ࡯ࡨࠫઍ"),l1llll1i1i11i1_vr_ (u"ࠧࠨ઎"))).replace(l1llll1i1i11i1_vr_ (u"ࠨࠩએ"),l1llll1i1i11i1_vr_ (u"ࠩࠪઐ")),
                   l1llll1i1i11i1_vr_ (u"ࠪ࡭ࡲ࡭ࠧઑ") : l1llll1i1i11i1_vr_ (u"ࠫࠬ઒"),
                   l1llll1i1i11i1_vr_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬઓ"): l1llll1i1i11i1_vr_ (u"࠭ࠧઔ"),
                   l1llll1i1i11i1_vr_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࠩક"): item.get(l1llll1i1i11i1_vr_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪખ"),l1llll1i1i11i1_vr_ (u"ࠩࠪગ")),
                   l1llll1i1i11i1_vr_ (u"ࠪࡴࡱࡵࡴࠨઘ") : l1llll1i1i11i1_vr_ (u"ࠫࠬઙ"),
                   }
            if l11llll11i1i11i1_vr_.get(l1llll1i1i11i1_vr_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬચ")):
                l11llll11i1i11i1_vr_[l1llll1i1i11i1_vr_ (u"࠭ࡴࡪࡶ࡯ࡩࠬછ")] = l1llll1i1i11i1_vr_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࠫࡳ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢ࠰ࠤࡠࡉࡏࡍࡑࡕࠤ࡬ࡸࡥࡦࡰࡠࠩࡸࡡ࠯ࡄࡑࡏࡓࡗࡣࠧજ") %(l11llll11i1i11i1_vr_[l1llll1i1i11i1_vr_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧઝ")], l11llll11i1i11i1_vr_.get(l1llll1i1i11i1_vr_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩઞ")))
            out.append(l11llll11i1i11i1_vr_)
    return out
def l111l1li1i11i1_vr_(url):
    l1llll1i1i11i1_vr_ (u"ࠥࠦࠧࠦࠠࠡࠢࠐࠎࠥࠦࠠࠡࡴࡨࡸࡺࡸ࡮ࡴࠢࠐࠎࠥࠦࠠࠡࠢࠣࠤࠥ࠳ࠠࡶ࡮ࡵࠤ࡭ࡺࡴࡱ࠼࠲࠳࠳࠴࠮࠯ࠏࠍࠤࠥࠦࠠࠣࠤࠥટ")
    l11l1l1lli1i11i1_vr_=l1llll1i1i11i1_vr_ (u"ࠫࠬઠ")
    if not l1llll1i1i11i1_vr_ (u"ࠬ࠵ࡥ࡮ࡤࡨࡨ࠴࠭ડ") in url:
        content = l1l1llli1i11i1_vr_(url)
        l111l111li1i11i1_vr_ = re.compile(l1llll1i1i11i1_vr_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡻ࡯ࡤࡦࡱ࠰ࡪࡷࡧ࡭ࡦࠢࠥࡂࡁ࡯ࡦࡳࡣࡰࡩࠥࡹࡲࡤ࠿ࠥࠬ࠴࡫࡭ࡣࡧࡧ࠳ࡻ࡯ࡤࡦࡱ࠲࠲࠯ࡅࠩࠣࠩઢ")).findall(content)
        if l111l111li1i11i1_vr_:
            url = l1lll1lli1i11i1_vr_+l111l111li1i11i1_vr_[0]
    content = l1l1llli1i11i1_vr_(url)
    data = re.compile(l1llll1i1i11i1_vr_ (u"ࠧࡥࡣࡷࡥ࠲ࡼࡩࡥࡧࡲ࠱ࡺࡸ࡬࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩણ")).findall(content)
    if data:
        l11l1l1lli1i11i1_vr_=data[0]+l1llll1i1i11i1_vr_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴ࠽ࠩࡸ࠭ત")%url + l1llll1i1i11i1_vr_ (u"ࠩࠣࡷࡼ࡬ࡕࡳ࡮ࡀ࡬ࡹࡺࡰ࠻࠱࠲ࡺ࡮ࡪࡥࡳ࠰ࡳࡰ࠴ࡹࡴࡢࡶ࡬ࡧ࠴ࡶ࡬ࡢࡻࡨࡶ࠴ࡼ࠵࠹࠱ࡳࡰࡦࡿࡥࡳ࠰ࡶࡻ࡫࠭થ")
    return l11l1l1lli1i11i1_vr_
def l111ll1lli1i11i1_vr_(l111llllli1i11i1_vr_):
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.decode(l1llll1i1i11i1_vr_ (u"ࠥࡹࡹ࡬࠭࠹ࠤદ")).replace(l1llll1i1i11i1_vr_ (u"ࡹࠧࡢࡵ࠳࠸࠸࠸ࠧધ"), l1llll1i1i11i1_vr_ (u"ࠧࠨન")).encode(l1llll1i1i11i1_vr_ (u"ࠨࡵࡵࡨ࠰࠼ࠧ઩"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠧࠤ࠲࠶࠼ࡀ࠭પ"),l1llll1i1i11i1_vr_ (u"ࠨࠩફ"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠩࠩࡰࡹࡁࡢࡳ࠱ࠩ࡫ࡹࡁࠧબ"),l1llll1i1i11i1_vr_ (u"ࠪࠤࠬભ"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠫࠫࠐࠠࠡࠢࠣࡸࡽࡺࠠ࠾ࠢࡷࡼࡹ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨમ")&
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠬࠬࠊࠡࠢࠣࠤࡹࡾࡴࠡ࠿ࠣࡸࡽࡺ࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩય")&
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"࠭ࠦࠋࠢࠣࠤࠥࡺࡸࡵࠢࡀࠤࡹࡾࡴ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪર")&
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠧࠧࡳࡸࡳࡹࡁࠧ઱"),l1llll1i1i11i1_vr_ (u"ࠨࠤࠪલ")).replace(l1llll1i1i11i1_vr_ (u"ࠩࠩࡥࡲࡶ࠻ࡲࡷࡲࡸࡀ࠭ળ"),l1llll1i1i11i1_vr_ (u"ࠪࠦࠬ઴"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠫࡡࡻ࠰࠲࠲࠸ࠫવ"),l1llll1i1i11i1_vr_ (u"ࠬऋࠧશ")).replace(l1llll1i1i11i1_vr_ (u"࠭࡜ࡶ࠲࠴࠴࠹࠭ષ"),l1llll1i1i11i1_vr_ (u"ࠧअࠩસ"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠨ࡞ࡸ࠴࠶࠶࠷ࠨહ"),l1llll1i1i11i1_vr_ (u"ࠩऊࠫ઺")).replace(l1llll1i1i11i1_vr_ (u"ࠪࡠࡺ࠶࠱࠱࠸ࠪ઻"),l1llll1i1i11i1_vr_ (u"ࠫऋ઼࠭"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠬࡢࡵ࠱࠳࠴࠽ࠬઽ"),l1llll1i1i11i1_vr_ (u"࠭ङࠨા")).replace(l1llll1i1i11i1_vr_ (u"ࠧ࡝ࡷ࠳࠵࠶࠾ࠧિ"),l1llll1i1i11i1_vr_ (u"ࠨचࠪી"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠩ࡟ࡹ࠵࠷࠴࠳ࠩુ"),l1llll1i1i11i1_vr_ (u"ࠪॆࠬૂ")).replace(l1llll1i1i11i1_vr_ (u"ࠫࡡࡻ࠰࠲࠶࠴ࠫૃ"),l1llll1i1i11i1_vr_ (u"ࠬेࠧૄ"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"࠭࡜ࡶ࠲࠴࠸࠹࠭ૅ"),l1llll1i1i11i1_vr_ (u"ࠧॅࠩ૆")).replace(l1llll1i1i11i1_vr_ (u"ࠨ࡞ࡸ࠴࠶࠺࠴ࠨે"),l1llll1i1i11i1_vr_ (u"ࠩॆࠫૈ"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠪࡠࡺ࠶࠰ࡧ࠵ࠪૉ"),l1llll1i1i11i1_vr_ (u"ࠫࣸ࠭૊")).replace(l1llll1i1i11i1_vr_ (u"ࠬࡢࡵ࠱࠲ࡧ࠷ࠬો"),l1llll1i1i11i1_vr_ (u"࣓࠭ࠨૌ"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠧ࡝ࡷ࠳࠵࠺ࡨ્ࠧ"),l1llll1i1i11i1_vr_ (u"ࠨढ़ࠪ૎")).replace(l1llll1i1i11i1_vr_ (u"ࠩ࡟ࡹ࠵࠷࠵ࡢࠩ૏"),l1llll1i1i11i1_vr_ (u"ࠪफ़ࠬૐ"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠫࡡࡻ࠰࠲࠹ࡤࠫ૑"),l1llll1i1i11i1_vr_ (u"ࠬঀࠧ૒")).replace(l1llll1i1i11i1_vr_ (u"࠭࡜ࡶ࠲࠴࠻࠾࠭૓"),l1llll1i1i11i1_vr_ (u"ࠧॺࠩ૔"))
    l111llllli1i11i1_vr_ = l111llllli1i11i1_vr_.replace(l1llll1i1i11i1_vr_ (u"ࠨ࡞ࡸ࠴࠶࠽ࡣࠨ૕"),l1llll1i1i11i1_vr_ (u"ࠩॿࠫ૖")).replace(l1llll1i1i11i1_vr_ (u"ࠪࡠࡺ࠶࠱࠸ࡤࠪ૗"),l1llll1i1i11i1_vr_ (u"ࠫঀ࠭૘"))
    return l111llllli1i11i1_vr_
