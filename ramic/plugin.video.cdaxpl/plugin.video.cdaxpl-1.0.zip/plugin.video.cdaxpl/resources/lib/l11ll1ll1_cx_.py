# -*- coding: utf-8 -*-
import sys
l1l11l1_cx_ = sys.version_info [0] == 2
l1l1lll1_cx_ = 2048
l11lll1_cx_ = 7
def l11l1_cx_ (keyedStringLiteral):
	global l11l1ll1_cx_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l11l1_cx_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l1lll1_cx_ - (charIndex + stringNr) % l11lll1_cx_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l1lll1_cx_ - (charIndex + stringNr) % l11lll1_cx_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urllib2,urllib
import re,os,json,base64
import cookielib
from urlparse import urlparse,urljoin
l11ll111l1_cx_ = 15
l1llll111l1_cx_=l11l1_cx_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠷࠰࠴࠿ࠥ࡝ࡩ࡯࠸࠷࠿ࠥࡾ࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠷࠳࠱࠴࠳࠹࠱࠷࠵࠱࠵࠵࠶ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧभ")
l1111l11l1_cx_=l11l1_cx_ (u"ࡷ࠭ࠧम")
class l1llll1lll1_cx_(urllib2.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
def l111ll11l1_cx_(url,data=None):
    l11ll1l1l1_cx_ = cookielib.LWPCookieJar()
    if data:
        opener = urllib2.build_opener(l1llll1lll1_cx_, urllib2.HTTPCookieProcessor(l11ll1l1l1_cx_))
    else:
        opener = urllib2.build_opener( urllib2.HTTPCookieProcessor(l11ll1l1l1_cx_))
    opener.addheaders = [(l11l1_cx_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪय"), l1llll111l1_cx_)]
    try:
        response = opener.open(url,data,l11ll111l1_cx_)
        result= response.read()
        response.close()
    except:
        result=l11111lll1_cx_ = e.read()
    return result
def l111lllll1_cx_(l11l1ll1l1_cx_):
    if isinstance(l11l1ll1l1_cx_, unicode):
        l11l1ll1l1_cx_ = l11l1ll1l1_cx_.encode(l11l1_cx_ (u"ࠧࡶࡶࡩ࠱࠽࠭र"))
    l11l1ll1l1_cx_ = l11l1ll1l1_cx_.replace(l11l1_cx_ (u"ࠨࠨ࡯ࡸࡀࡨࡲ࠰ࠨࡪࡸࡀ࠭ऱ"),l11l1_cx_ (u"ࠩࠣࠫल"))
    s=l11l1_cx_ (u"ࠪࡎ࡮ࡔࡣ࡛ࡅࡶ࠻ࠬळ")
    l11l1ll1l1_cx_ = re.sub(s.decode(l11l1_cx_ (u"ࠫࡧࡧࡳࡦ࠸࠷ࠫऴ")),l11l1_cx_ (u"ࠬ࠭व"),l11l1ll1l1_cx_)
    l11l1ll1l1_cx_ = l11l1ll1l1_cx_.replace(l11l1_cx_ (u"࠭࡜࡯ࠩश"),l11l1_cx_ (u"ࠧࠨष")).replace(l11l1_cx_ (u"ࠨ࡞ࡵࠫस"),l11l1_cx_ (u"ࠩࠪह"))
    l11l1ll1l1_cx_ = l11l1ll1l1_cx_.replace(l11l1_cx_ (u"ࠪࠪࡳࡨࡳࡱ࠽ࠪऺ"),l11l1_cx_ (u"ࠫࠬऻ"))
    l11l1ll1l1_cx_ = l11l1ll1l1_cx_.replace(l11l1_cx_ (u"ࠬࠬࡱࡶࡱࡷ࠿़ࠬ"),l11l1_cx_ (u"࠭ࠢࠨऽ")).replace(l11l1_cx_ (u"ࠧࠧࡣࡰࡴࡀࡷࡵࡰࡶ࠾ࠫा"),l11l1_cx_ (u"ࠨࠤࠪि"))
    l11l1ll1l1_cx_ = l11l1ll1l1_cx_.replace(l11l1_cx_ (u"ࠩࠩࡳࡦࡩࡵࡵࡧ࠾ࠫी"),l11l1_cx_ (u"ࠪࣷࠬु")).replace(l11l1_cx_ (u"ࠫࠫࡕࡡࡤࡷࡷࡩࡀ࠭ू"),l11l1_cx_ (u"ࠬࣙࠧृ"))
    l11l1ll1l1_cx_ = l11l1ll1l1_cx_.replace(l11l1_cx_ (u"࠭ࠦࡢ࡯ࡳ࠿ࡴࡧࡣࡶࡶࡨ࠿ࠬॄ"),l11l1_cx_ (u"ࠧࣴࠩॅ")).replace(l11l1_cx_ (u"ࠨࠨࡤࡱࡵࡁࡏࡢࡥࡸࡸࡪࡁࠧॆ"),l11l1_cx_ (u"ࠩࣖࠫे"))
    l11l1ll1l1_cx_ = l11l1ll1l1_cx_.replace(l11l1_cx_ (u"ࠪࠪࡦࡳࡰ࠼ࠩै"),l11l1_cx_ (u"ࠫࠫ࠭ॉ"))
    l11l1ll1l1_cx_ = l11l1ll1l1_cx_.replace(l11l1_cx_ (u"ࠬࡢࡵ࠱࠳࠳࠹ࠬॊ"),l11l1_cx_ (u"࠭अࠨो")).replace(l11l1_cx_ (u"ࠧ࡝ࡷ࠳࠵࠵࠺ࠧौ"),l11l1_cx_ (u"ࠨआ्ࠪ"))
    l11l1ll1l1_cx_ = l11l1ll1l1_cx_.replace(l11l1_cx_ (u"ࠩ࡟ࡹ࠵࠷࠰࠸ࠩॎ"),l11l1_cx_ (u"ࠪऋࠬॏ")).replace(l11l1_cx_ (u"ࠫࡡࡻ࠰࠲࠲࠹ࠫॐ"),l11l1_cx_ (u"ࠬऌࠧ॑"))
    l11l1ll1l1_cx_ = l11l1ll1l1_cx_.replace(l11l1_cx_ (u"࠭࡜ࡶ࠲࠴࠵࠾॒࠭"),l11l1_cx_ (u"ࠧचࠩ॓")).replace(l11l1_cx_ (u"ࠨ࡞ࡸ࠴࠶࠷࠸ࠨ॔"),l11l1_cx_ (u"ࠩछࠫॕ"))
    l11l1ll1l1_cx_ = l11l1ll1l1_cx_.replace(l11l1_cx_ (u"ࠪࡠࡺ࠶࠱࠵࠴ࠪॖ"),l11l1_cx_ (u"ࠫे࠭ॗ")).replace(l11l1_cx_ (u"ࠬࡢࡵ࠱࠳࠷࠵ࠬक़"),l11l1_cx_ (u"࠭ुࠨख़"))
    l11l1ll1l1_cx_ = l11l1ll1l1_cx_.replace(l11l1_cx_ (u"ࠧ࡝ࡷ࠳࠵࠹࠺ࠧग़"),l11l1_cx_ (u"ࠨॆࠪज़")).replace(l11l1_cx_ (u"ࠩ࡟ࡹ࠵࠷࠴࠵ࠩड़"),l11l1_cx_ (u"ࠪेࠬढ़"))
    l11l1ll1l1_cx_ = l11l1ll1l1_cx_.replace(l11l1_cx_ (u"ࠫࡡࡻ࠰࠱ࡨ࠶ࠫफ़"),l11l1_cx_ (u"ࣹࠬࠧय़")).replace(l11l1_cx_ (u"࠭࡜ࡶ࠲࠳ࡨ࠸࠭ॠ"),l11l1_cx_ (u"ࠧࣔࠩॡ"))
    l11l1ll1l1_cx_ = l11l1ll1l1_cx_.replace(l11l1_cx_ (u"ࠨ࡞ࡸ࠴࠶࠻ࡢࠨॢ"),l11l1_cx_ (u"ࠩफ़ࠫॣ")).replace(l11l1_cx_ (u"ࠪࡠࡺ࠶࠱࠶ࡣࠪ।"),l11l1_cx_ (u"ࠫय़࠭॥"))
    l11l1ll1l1_cx_ = l11l1ll1l1_cx_.replace(l11l1_cx_ (u"ࠬࡢࡵ࠱࠳࠺ࡥࠬ०"),l11l1_cx_ (u"࠭ॺࠨ१")).replace(l11l1_cx_ (u"ࠧ࡝ࡷ࠳࠵࠼࠿ࠧ२"),l11l1_cx_ (u"ࠨॻࠪ३"))
    l11l1ll1l1_cx_ = l11l1ll1l1_cx_.replace(l11l1_cx_ (u"ࠩ࡟ࡹ࠵࠷࠷ࡤࠩ४"),l11l1_cx_ (u"ࠪঀࠬ५")).replace(l11l1_cx_ (u"ࠫࡡࡻ࠰࠲࠹ࡥࠫ६"),l11l1_cx_ (u"ࠬঁࠧ७"))
    return l11l1ll1l1_cx_
url=l11l1_cx_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡣࡥࡣ࠰ࡼ࠳ࡶ࡬࠰࡬ࡤ࡯ࡴࡹࡣ࠰ࡪࡧ࠳ࠬ८")
url=l11l1_cx_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡤࡦࡤ࠱ࡽ࠴ࡰ࡭࠱ࡲࡨࡨ࡯࡮࡬࡫࠲ࠫ९")
url=l11l1_cx_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡥࡧࡥ࠲ࡾ࠮ࡱ࡮࠲ࡃࡸࡃࡤࡰ࡯ࠪ॰")
class l1l1l1l1l1_cx_:
    @staticmethod
    def l1l1lll1l1_cx_(url):
        content = l111ll11l1_cx_(url)
        l1l1lllll1_cx_=[]
        l1llllll1_cx_=[]
        l1111111l1_cx_ = re.compile(l11l1_cx_ (u"ࠩ࠿ࡥࡷࡺࡩࡤ࡮ࡨࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡷࡺࡩࡤ࡮ࡨࡂࠬॱ"),re.DOTALL).findall(content)
        for item in l1111111l1_cx_:
            if l11l1_cx_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡻࡤ࡯ࡴࡦ࡯ࡢࡥࠧ࠭ॲ") in item:
                continue
            l111l1lll1_cx_=re.findall(l11l1_cx_ (u"ࠫࡁ࡮࠳࠿࡞ࡶ࠮ࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯࠭ࡂ࠭ࡁ࠵ࡡ࠿ࠩॳ"),item)
            if not l111l1lll1_cx_:
                h = re.findall(l11l1_cx_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧॴ"),item)
                t = re.findall(l11l1_cx_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦ࠭ࡅ࠺ࡵ࡫ࡷࡰࡪࢂࡤࡢࡶࡤ࠭ࠧࡄ࠮ࠬ࠾࡫ࡠࡩ࠴ࠫ࠿ࠪ࠱࠯ࡄ࠯࠼࠰ࡪࠪॵ"),item,re.DOTALL)
                if not t:
                    t= re.findall(l11l1_cx_ (u"ࠧ࠽ࡵࡳࡥࡳࠦࡣ࡭ࡣࡶࡷࡂࠨࡳࡦࡴ࡬ࡩࠧࡄࠨ࠯࠭ࡂ࠭ࡁ࠵ࡳࠨॶ"),item,re.DOTALL)
                    if not t:
                       t= re.findall(l11l1_cx_ (u"ࠨࡣ࡯ࡸࡂࠨࠨ࠯࠭ࡂ࠭ࠧ࠭ॷ"),item)
                if h and t:
                    l111l1lll1_cx_=[(h[0],t[0].strip())]
            year = re.findall(l11l1_cx_ (u"ࠩ࠿ࡷࡵࡧ࡮࡜ࡠࡁࡡ࠯ࡄࠨ࡝ࡦࡾ࠸ࢂ࠯࠼࠰ࠩॸ"),item)
            l11l111ll1_cx_ = re.findall(l11l1_cx_ (u"ࠪࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࡡࠢ࡝ࠩࡠࠬ࠳࠱࠿ࠪ࡝ࠥࡠࠬࡣࠧॹ"),item)
            l11ll1lll1_cx_ = re.findall(l11l1_cx_ (u"ࠫࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡨࡵ࡮࠮ࡵࡷࡥࡷ࠸ࠢ࠿࡞ࡶ࠮ࡁ࠵ࡳࡱࡣࡱࡂ࠭࠴ࠫࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩॺ"),item,re.DOTALL)
            l11l1l11l1_cx_ = re.findall(l11l1_cx_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡸࡪࡾࡴࡰࠤࡁࠬ࠳࠱࠿ࠪ࠾ࠪॻ"),item,re.DOTALL)
            if l111l1lll1_cx_:
                href = l111l1lll1_cx_[0][0]
                title= l111lllll1_cx_(l111l1lll1_cx_[0][1])
                l11l111ll1_cx_ = l11l111ll1_cx_[0] if l11l111ll1_cx_ else l11l1_cx_ (u"࠭ࠧॼ")
                l11ll1lll1_cx_ = l11ll1lll1_cx_[0].strip() if l11ll1lll1_cx_ else l11l1_cx_ (u"ࠧࠨॽ")
                l111l111l1_cx_ = re.findall(l11l1_cx_ (u"ࠨࡴࡨࡰࡂࠨࡴࡢࡩࠥࡂ࠭࠴ࠫࡀࠫ࠿࠳ࡦࡄࠧॾ"),item)
                l111l111l1_cx_ = l11l1_cx_ (u"ࠩ࠯ࠫॿ").join(l111l111l1_cx_) if l111l111l1_cx_ else l11l1_cx_ (u"ࠪࠫঀ")
                quality = re.findall(l11l1_cx_ (u"ࠫࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥࡵࡺࡧ࡬ࡪࡶࡼࠦࡃ࠮࠮ࠫࡁࠬࡀ࠴࠭ঁ"),item)
                l11l1llll1_cx_ = re.findall(l11l1_cx_ (u"ࠬࡂࡳࡱࡣࡱࡂ࠭ࡢࡤࠬࠫ࡟ࡷ࠰ࡳࡩ࡯࠾࠲ࡷࡵࡧ࡮࠿ࠩং"),item)
                l11l1llll1_cx_ = int(l11l1llll1_cx_[0])*60 if l11l1llll1_cx_ else l11l1_cx_ (u"࠭ࠧঃ")
                l1l1ll1l1_cx_={l11l1_cx_ (u"ࠧࡩࡴࡨࡪࠬ঄"):href,
                    l11l1_cx_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧঅ"):title,
                    l11l1_cx_ (u"ࠩ࡬ࡱ࡬࠭আ"):l11l111ll1_cx_,
                    l11l1_cx_ (u"ࠪࡧࡴࡪࡥࠨই"):l11ll1lll1_cx_,
                    l11l1_cx_ (u"ࠫࡾ࡫ࡡࡳࠩঈ"):year[0] if year else l11l1_cx_ (u"ࠬ࠭উ"),
                    l11l1_cx_ (u"࠭ࡰ࡭ࡱࡷࠫঊ"):l111lllll1_cx_(l11l1l11l1_cx_[0]).strip() if l11l1l11l1_cx_ else l11l1_cx_ (u"ࠧࠨঋ"),
                    l11l1_cx_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪঌ"):l11l1llll1_cx_,
                    l11l1_cx_ (u"ࠩࡪࡩࡳࡸࡥࠨ঍"):l111l111l1_cx_,
                }
                if l11l1_cx_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡣ࡯ࡩ࠴࠭঎") in href:
                    l1l1lllll1_cx_.append(l1l1ll1l1_cx_)
                else:
                    l1llllll1_cx_.append(l1l1ll1l1_cx_)
        l11ll11ll1_cx_ = re.findall(l11l1_cx_ (u"ࠫࡁࡧࠠࡤ࡮ࡤࡷࡸࡃ࡛࡝ࠩࠥࡡࡦࡸࡲࡰࡹࡢࡴࡦ࡭࡛࡝ࠩࠥࡡࠥ࡮ࡲࡦࡨࡀ࡟ࡡ࠭ࠢ࡞ࠪ࠱࠮ࡄ࠯࡛࡝ࠩࠥࡡࡃࡂࡩࠡࡥ࡯ࡥࡸࡹ࠽࡜࡞ࠪࠦࡢ࡯ࡣࡰࡰ࠰ࡧࡦࡸࡥࡵ࠯࡯ࡩ࡫ࡺ࡛࡝ࠩࠥࡡࡃ࠭এ"),content)
        l11ll11ll1_cx_ = l11ll11ll1_cx_[0] if l11ll11ll1_cx_ else False
        l111111ll1_cx_ = re.findall(l11l1_cx_ (u"ࠬࡂࡡࠡࡥ࡯ࡥࡸࡹ࠽࡜࡞ࠪࠦࡢࡧࡲࡳࡱࡺࡣࡵࡧࡧ࡜࡞ࠪࠦࡢࠦࡨࡳࡧࡩࡁࡠࡢࠧࠣ࡟ࠫ࠲࠯ࡅࠩ࡜࡞ࠪࠦࡢࡄ࠼ࡪࠢࡦࡰࡦࡹࡳ࠾࡝࡟ࠫࠧࡣࡩࡤࡱࡱ࠱ࡨࡧࡲࡦࡶ࠰ࡶ࡮࡭ࡨࡵ࡝࡟ࠫࠧࡣ࠾ࠨঐ"),content)
        l111111ll1_cx_ = l111111ll1_cx_[0] if l111111ll1_cx_ else False
        return l1llllll1_cx_,l1l1lllll1_cx_,(l11ll11ll1_cx_,l111111ll1_cx_)
    @staticmethod
    def l1lll11ll1_cx_(url):
        out = []
        content = l111ll11l1_cx_(url)
        l1ll111ll1_cx_ = re.findall(l11l1_cx_ (u"࠭࠼ࡶ࡮ࠣࡧࡱࡧࡳࡴ࠿ࠥࡩࡵ࡯ࡳࡰࡦ࡬ࡳࡸࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࠪ঑"),content,re.DOTALL)
        for l111l11ll1_cx_ in l1ll111ll1_cx_:
            l111lll1l1_cx_ = re.findall(l11l1_cx_ (u"ࠧ࠽࡮࡬ࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡱ࡯࠾ࠨ঒"),l111l11ll1_cx_,re.DOTALL)
            for l111l11l1_cx_ in l111lll1l1_cx_:
                l11l111ll1_cx_ = re.findall(l11l1_cx_ (u"ࠨ࠾࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫও"),l111l11l1_cx_)
                l111l1l1l1_cx_ = re.findall(l11l1_cx_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢ࡯ࡷࡰࡩࡷࡧ࡮ࡥࡱࠥࡂࡡࡹࠪࠩ࡞ࡧ࠯࠮ࡢࡳࠫ࠯࡟ࡷ࠯࠮࡜ࡥ࠭ࠬࡠࡸ࠰࠼࠰ࡦ࡬ࡺࡃ࠭ঔ"),l111l11l1_cx_)
                l111l1lll1_cx_ = re.findall(l11l1_cx_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣࡀࠫ࡟ࡣࡂ࡝ࠬࠫ࠿࠳ࡦࡄࠧক"),l111l11l1_cx_)
                data = re.findall(l11l1_cx_ (u"ࠫࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥࡨࡦࡺࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨখ"),l111l11l1_cx_)
                if l111l1lll1_cx_:
                    l1llllllll1_cx_,l1llll11ll1_cx_ = l111l1l1l1_cx_[0] if l111l1l1l1_cx_ else (l11l1_cx_ (u"ࠬ࠭গ"),l11l1_cx_ (u"࠭ࠧঘ"))
                    l11l111ll1_cx_ = l11l111ll1_cx_[0] if l11l111ll1_cx_ else l11l1_cx_ (u"ࠧࠨঙ")
                    out.append({l11l1_cx_ (u"ࠨࡪࡵࡩ࡫࠭চ"):l111l1lll1_cx_[0][0],l11l1_cx_ (u"ࠩࡷ࡭ࡹࡲࡥࠨছ"):l111l1lll1_cx_[0][1],l11l1_cx_ (u"ࠪ࡭ࡲ࡭ࠧজ"):l11l111ll1_cx_,
                        l11l1_cx_ (u"ࠫࡸ࡫ࡡࡴࡱࡱࠫঝ"):int(l1llllllll1_cx_),l11l1_cx_ (u"ࠬ࡫ࡰࡪࡵࡲࡨࡪ࠭ঞ"):int(l1llll11ll1_cx_)})
        return out
    @staticmethod
    def l1l1l11ll1_cx_(out):
        l1l1lllll1_cx_={}
        l1ll111ll1_cx_ = [x.get(l11l1_cx_ (u"࠭ࡳࡦࡣࡶࡳࡳ࠭ট")) for x in out]
        for s in set(l1ll111ll1_cx_):
            l1l1lllll1_cx_[l11l1_cx_ (u"ࠧࡔࡧࡽࡳࡳࠦࠥ࠱࠴ࡧࠫঠ")%s]=[out[i] for i, j in enumerate(l1ll111ll1_cx_) if j == s]
        return l1l1lllll1_cx_
    @staticmethod
    def l1l11l11l1_cx_():
        content = l111ll11l1_cx_(l11l1_cx_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡥࡧࡥ࠲ࡾ࠮ࡱ࡮࠲ࠫড"))
        stuff = re.compile(l11l1_cx_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴ࡩࡤࡢ࠯ࡻ࠲ࡵࡲ࠯ࡨࡣࡷࡹࡳࡱࡩ࠰࠰࠮ࡃ࠮ࠨ࡜ࡴࠬ࡞ࡢࡃࡣࠪ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁ࡟ࡡࡹ࡜࡯ࠢࡠ࠮ࡁ࡯࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡪࡀࠪঢ")).findall(content)
        out=[]
        for l1111llll1_cx_, title, l1111ll1l1_cx_ in stuff:
            out.append({l11l1_cx_ (u"ࠥ࡬ࡷ࡫ࡦࠣণ"):l1111llll1_cx_,l11l1_cx_ (u"ࠦࡹ࡯ࡴ࡭ࡧࠥত"):l11l1_cx_ (u"ࠧࢁࡽࠡࠪࡾࢁ࠮ࠨথ").format(title,l1111ll1l1_cx_.replace(l11l1_cx_ (u"࠭ࠦ࡯ࡤࡶࡴࡀ࠭দ"),l11l1_cx_ (u"ࠧࠨধ")))})
        return out
    @staticmethod
    def l1lllll1l1_cx_():
        content = l111ll11l1_cx_(l11l1_cx_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡥࡧࡥ࠲ࡾ࠮ࡱ࡮࠲ࠫন"))
        stuff = re.compile(l11l1_cx_ (u"ࠩ࠿ࡰ࡮ࡄ࡜ࡴࠬ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠽࠳࠴ࡩࡤࡢ࠯ࡻ࠲ࡵࡲ࠯ࡳࡧ࡯ࡩࡦࡹࡥ࠰࠰࠮ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀ࠿࠳ࡱ࡯࠾ࠨ঩")).findall(content)
        out=[]
        for l1111llll1_cx_, title, in stuff:
            out.append({l11l1_cx_ (u"ࠥ࡬ࡷ࡫ࡦࠣপ"):l1111llll1_cx_,l11l1_cx_ (u"ࠦࡹ࡯ࡴ࡭ࡧࠥফ"):title})
        return out
    @staticmethod
    def l1111l1l1_cx_(url):
        content = l111ll11l1_cx_(url)
        l1lllll1ll1_cx_ = re.compile(l11l1_cx_ (u"ࠬࡂࡴࡣࡱࡧࡽࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡢࡰࡦࡼࡂࠬব"),re.DOTALL).findall(content)
        l1llllll1l1_cx_=[]
        if l1lllll1ll1_cx_:
            l1llll1l1l1_cx_ = re.findall(l11l1_cx_ (u"࠭࠼ࡵࡴࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡶࡃ࠭ভ"),l1lllll1ll1_cx_[0],re.DOTALL)
            for l1l1ll1_cx_ in l1llll1l1l1_cx_:
                l1ll11l1l1_cx_ = re.findall(l11l1_cx_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠻࠱࠲ࡧࡩࡧ࠭ࡹ࠰ࡳࡰ࠴ࡲࡩ࡯࡭ࡶ࠳࠳࠰࠿ࠪࠤࠪম"),l1l1ll1_cx_)
                host = re.findall(l11l1_cx_ (u"ࠨࡦࡲࡱࡦ࡯࡮࠾ࠪ࠱࠯ࡄ࠯ࠢࠨয"),l1l1ll1_cx_)
                if l1ll11l1l1_cx_:
                    l1llllll1l1_cx_.append({l11l1_cx_ (u"ࠩ࡫ࡶࡪ࡬ࠧর"):l1ll11l1l1_cx_[0],l11l1_cx_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ঱"):host[0] if host else l11l1_cx_ (u"ࠫࡄ࠭ল"),l11l1_cx_ (u"ࠬࡸࡥࡴࡱ࡯ࡺࡪࡪࠧ঳"):False})
        stuff = re.compile(l11l1_cx_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡩࡧࡴࠪ঴"),re.I).findall(content)
        if stuff:
            src = re.findall(l11l1_cx_ (u"ࠧࡴࡴࡦࡁࡠࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢ࠭঵"),stuff[0],re.I)
            if src:
                title = urlparse(src[0].strip()).netloc
                l1llllll1l1_cx_.append({l11l1_cx_ (u"ࠨࡪࡵࡩ࡫࠭শ"):src[0],l11l1_cx_ (u"ࠩࡷ࡭ࡹࡲࡥࠨষ"):title,l11l1_cx_ (u"ࠪࡶࡪࡹ࡯࡭ࡸࡨࡨࠬস"):True})
        return l1llllll1l1_cx_
    @staticmethod
    def l1ll1l1l1_cx_(url):
        a=l111ll11l1_cx_(url)
        src = re.findall(l11l1_cx_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡥࡳࡹࡵ࡮ࠡࡴࡨࡰࡴࡧࡤࡪࡰࡪࠦࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠨহ"),a)
        if src:
            return src[0] if src else l11l1_cx_ (u"ࠬ࠭঺")
        return l11l1_cx_ (u"࠭ࠧ঻")
    @staticmethod
    def l11l11l1l1_cx_(url):
        content = l111ll11l1_cx_(url)
        stuff = re.compile(l11l1_cx_ (u"ࠧ࠽࡫ࡩࡶࡦࡳࡥࠩ࠰࠭ࡃ࠮ࡂ࠯ࡪࡨࡵࡥࡲ࡫࠾ࠨ়"),re.I).findall(content)
        if stuff:
            src = re.findall(l11l1_cx_ (u"ࠨࡵࡵࡧࡂࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣࠧঽ"),stuff[0],re.I)
            if src:
                return src[0] if src else l11l1_cx_ (u"ࠩࠪা")
        return l11l1_cx_ (u"ࠪࠫি")
class l1111l1ll1_cx_:
    def l11l11lll1_cx_(self,url):
        if not url:
            url = l11l1_cx_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩী")
        elif url.startswith(l11l1_cx_ (u"ࠬ࠵࠯ࠨু")):
            url = l11l1_cx_ (u"࠭ࡨࡵࡶࡳࠫূ")+url
        elif url.startswith(l11l1_cx_ (u"ࠧ࠰ࠩৃ")):
            url = urljoin(l11l1_cx_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡬ࡥࡳ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭ৄ"),url)
        return url
    @staticmethod
    def l1l1lll1l1_cx_(url=l11l1_cx_ (u"ࠩࠪ৅")):
        if not url:
            url = l11l1_cx_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࡮ࡧࡵࡦࡪ࡮ࡰ࠲ࡵࡲ࠯ࠨ৆")
        elif url.startswith(l11l1_cx_ (u"ࠫ࠴࠭ে")):
            url = urljoin(l11l1_cx_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡰࡢࡰࡨ࡬ࡰࡲ࠴ࡰ࡭࠱ࠪৈ"),url)
        content = l111ll11l1_cx_(url)
        out=[]
        l111ll1ll1_cx_ = re.compile(l11l1_cx_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡮ࡵࡧࡱࡸ࠲࡭ࡲࡪࡦࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ৉"),re.DOTALL).findall(content)
        for show in l111ll1ll1_cx_:
            l11l1111l1_cx_ = re.findall(l11l1_cx_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠳ࡸ࡫ࡲࡪࡣ࡯ࡩ࠴࠴ࠪࠪࠤࡁࡀ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭৊"),show)
            if l11l1111l1_cx_:
                l11l111ll1_cx_ = l11l1111l1_cx_[0][1]
                l11l111ll1_cx_ = urljoin(l11l1_cx_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡬ࡥࡳ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭ো"),l11l111ll1_cx_) if not l11l111ll1_cx_.startswith(l11l1_cx_ (u"ࠩ࡫ࡸࡹࡶࠧৌ")) else l11l111ll1_cx_
                title = l11l1111l1_cx_[0][0].replace(l11l1_cx_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡣ࡯ࡩ࠴্࠭"),l11l1_cx_ (u"ࠫࠬৎ")).replace(l11l1_cx_ (u"ࠬ࠳ࠧ৏"),l11l1_cx_ (u"࠭ࠠࠨ৐")).replace(l11l1_cx_ (u"ࠧ࠰ࠩ৑"),l11l1_cx_ (u"ࠨࠩ৒")).title()
                out.append({l11l1_cx_ (u"ࠩ࡫ࡶࡪ࡬ࠧ৓"):l11l1111l1_cx_[0][0],l11l1_cx_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ৔"):title,l11l1_cx_ (u"ࠫ࡮ࡳࡧࠨ৕"):l11l111ll1_cx_})
        idx = content.find(l11l1_cx_ (u"ࠬ࡮࠳࠿ࡕࡨࡶ࡮ࡧ࡬ࡦ࠾࠲࡬࠸ࡄࠧ৖"))
        if idx:
            l1lll1llll1_cx_ = re.compile(l11l1_cx_ (u"࠭࠼ࡶ࡮ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧৗ"),re.DOTALL).search(content[idx:-1])
            l1lll1llll1_cx_ = l1lll1llll1_cx_.group(1) if l1lll1llll1_cx_ else l11l1_cx_ (u"ࠧࠨ৘")
            l1lll1llll1_cx_ = re.sub(l11l1_cx_ (u"ࡳࠤ࠿ࠥ࠲࠳ࠨ࠯ࡾ࡟ࡷࢁࡢ࡮ࠪࠬࡂ࠱࠲ࡄࠢ৙"), l11l1_cx_ (u"ࠤࠥ৚"), l1lll1llll1_cx_)
            l1lllll11l1_cx_ = re.compile(l11l1_cx_ (u"ࠪࡀࡱ࡯࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠳ࡸ࡫ࡲࡪࡣ࡯ࡩ࠴࠴ࠪࡀࠫࠥࡂ࠭ࡡ࡞࠿࡟࠭࠭ࡁ࠵ࡡ࠿࠾࠲ࡰ࡮ࡄࠧ৛")).findall(l1lll1llll1_cx_)
            for href,title in l1lllll11l1_cx_:
                out.append({l11l1_cx_ (u"ࠫ࡭ࡸࡥࡧࠩড়"):href,l11l1_cx_ (u"ࠬࡺࡩࡵ࡮ࡨࠫঢ়"):title})
        return out
    @staticmethod
    def l11111l1l1_cx_(url=l11l1_cx_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡪࡣࡱࡩ࡭ࡱࡳ࠮ࡱ࡮࠲ࡷࡪࡸࡩࡢ࡮ࡨ࠳ࡩ࡫ࡴࡦ࡭ࡷࡽࡼ࠵ࠧ৞")):
        if not url:
            url = l11l1_cx_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡫ࡤࡲࡪ࡮ࡲ࡭࠯ࡲ࡯࠳ࠬয়")
        if url.startswith(l11l1_cx_ (u"ࠨ࠱࠲ࠫৠ")):
            url = l11l1_cx_ (u"ࠩ࡫ࡸࡹࡶࠧৡ")+url
        if url.startswith(l11l1_cx_ (u"ࠪ࠳ࠬৢ")):
            url = urljoin(l11l1_cx_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡯ࡨ࡯ࡧ࡫࡯ࡱ࠳ࡶ࡬࠰ࠩৣ"),url)
        url += l11l1_cx_ (u"ࠬ࠵ࠧ৤") if not url.endswith(l11l1_cx_ (u"࠭࠯ࠨ৥")) else l11l1_cx_ (u"ࠧࠨ০")
        content = l111ll11l1_cx_(url)
        out=[]
        l1l1l1ll1_cx_ = re.compile(l11l1_cx_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺ࠭ࡨࡴ࡬ࡨࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ১"),re.DOTALL).findall(content)
        for l11l1l1ll1_cx_ in l1l1l1ll1_cx_:
            l1llllllll1_cx_ = re.findall(l11l1_cx_ (u"ࠩࡶࡩࡿࡵ࡮࡝ࡵ࠭ࠬࡡࡪࠫࠪࠩ২"),l11l1l1ll1_cx_,re.I)
            l1llllllll1_cx_ = l1llllllll1_cx_[0] if l1llllllll1_cx_ else l11l1_cx_ (u"ࠪࠫ৩")
            l1llll11ll1_cx_ = re.findall(l11l1_cx_ (u"ࠫࡔࡪࡣࡪࡰࡨ࡯ࡡࡹࠪࠩ࡞ࡧ࠯࠮࠭৪"),l11l1l1ll1_cx_,re.I)
            l1llll11ll1_cx_ = l1llll11ll1_cx_[0] if l1llll11ll1_cx_ else l11l1_cx_ (u"ࠬ࠭৫")
            href = re.compile(l11l1_cx_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪࡶ࡭ࡳ࡭࡬ࡦࡲࡤ࡫ࡪ࠴ࡰࡩࡲ࡟ࡃ࡮ࡪ࠽࡝ࡦ࠮࠭ࠧ࠭৬")).findall(l11l1l1ll1_cx_)
            l11l111ll1_cx_ = re.findall(l11l1_cx_ (u"ࠧ࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ৭"),l11l1l1ll1_cx_)
            if href and l1llllllll1_cx_ and l1llll11ll1_cx_:
                l11l111ll1_cx_ = urljoin(l11l1_cx_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡬ࡥࡳ࡫࡯࡬࡮࠰ࡳࡰ࠴࠭৮"),l11l111ll1_cx_[0]) if not l11l111ll1_cx_[0].startswith(l11l1_cx_ (u"ࠩ࡫ࡸࡹࡶࠧ৯")) else l11l1_cx_ (u"ࠪࠫৰ")
                out.append({l11l1_cx_ (u"ࠫ࡭ࡸࡥࡧࠩৱ"):url+href[0],l11l1_cx_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ৲"):l11l1_cx_ (u"࠭ࡓࡦࡼࡲࡲࠥࠫࡳ࠭ࠢࡈࡴ࡮ࢀ࡯ࡥࠢࠨࡷࠬ৳")%(l1llllllll1_cx_,l1llll11ll1_cx_),l11l1_cx_ (u"ࠧࡪ࡯ࡪࠫ৴"):l11l111ll1_cx_,
                l11l1_cx_ (u"ࠨࡵࡨࡥࡸࡵ࡮ࠨ৵"):int(l1llllllll1_cx_),l11l1_cx_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࠪ৶"):int(l1llll11ll1_cx_)})
        return out
