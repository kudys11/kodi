# coding: UTF-8
import sys
l1l11l1_cx_ = sys.version_info [0] == 2
l1l1lll1_cx_ = 2048
l11lll1_cx_ = 7
def l11l1_cx_ (keyedStringLiteral):
	global l11l1ll1_cx_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l11l1_cx_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l1lll1_cx_ - (charIndex + stringNr) % l11lll1_cx_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l1lll1_cx_ - (charIndex + stringNr) % l11lll1_cx_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)