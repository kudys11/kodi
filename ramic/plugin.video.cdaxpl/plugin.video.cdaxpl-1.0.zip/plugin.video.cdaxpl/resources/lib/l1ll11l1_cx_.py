# coding: UTF-8
import sys
l1l11l1_cx_ = sys.version_info [0] == 2
l1l1lll1_cx_ = 2048
l11lll1_cx_ = 7
def l11l1_cx_ (keyedStringLiteral):
	global l11l1ll1_cx_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l11l1_cx_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l1lll1_cx_ - (charIndex + stringNr) % l11lll1_cx_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l1lll1_cx_ - (charIndex + stringNr) % l11lll1_cx_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import threading
import xbmc,xbmcgui
import time,re,os
try: from shutil import rmtree
except: rmtree = False
def lll1_cx_(l111l1l1_cx_,l11ll1_cx_=[l11l1_cx_ (u"ࠫࠬ࠸")]):
    debug=1
def l1111l1_cx_(name=l11l1_cx_ (u"ࠬ࠭࠹")):
    debug=1
def l1llll1_cx_(top):
    debug=1
def check():
    debug=1
try:
    debug=1
except: pass