# -*- coding: utf-8 -*-
import sys
l1l11l1_cx_ = sys.version_info [0] == 2
l1l1lll1_cx_ = 2048
l11lll1_cx_ = 7
def l11l1_cx_ (keyedStringLiteral):
	global l11l1ll1_cx_
	stringNr = ord (keyedStringLiteral [-1])
	rotatedStringLiteral = keyedStringLiteral [:-1]
	rotationDistance = stringNr % len (rotatedStringLiteral)
	recodedStringLiteral = rotatedStringLiteral [:rotationDistance] + rotatedStringLiteral [rotationDistance:]
	if l1l11l1_cx_:
		stringLiteral = unicode () .join ([unichr (ord (char) - l1l1lll1_cx_ - (charIndex + stringNr) % l11lll1_cx_) for charIndex, char in enumerate (recodedStringLiteral)])
	else:
		stringLiteral = str () .join ([chr (ord (char) - l1l1lll1_cx_ - (charIndex + stringNr) % l11lll1_cx_) for charIndex, char in enumerate (recodedStringLiteral)])
	return eval (stringLiteral)
import urlparse,sys,urllib
params = dict(urlparse.parse_qsl(sys.argv[2].replace(l11l1_cx_ (u"ࠫࡄ࠭ࠀ"),l11l1_cx_ (u"ࠬ࠭ࠁ"))))
mode = params.get(l11l1_cx_ (u"࠭࡭ࡰࡦࡨࠫࠂ"))
fname = params.get(l11l1_cx_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫࠃ"))
ex_link = params.get(l11l1_cx_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩࠄ"))
l111lll1_cx_ = params.get(l11l1_cx_ (u"ࠩࡳࡥ࡬࡫ࠧࠅ"))
import xbmcgui,xbmc
import time,os
l1ll1_cx_ = xbmcgui.Dialog()
import time,threading
try: from shutil import rmtree
except: rmtree = False
def lll1_cx_(l111l1l1_cx_,l11ll1_cx_=[l11l1_cx_ (u"ࠪࠫࠆ")]):
    debug=1
def l1111l1_cx_(name=l11l1_cx_ (u"ࠫࠬࠇ")):
    debug=1
def l1llll1_cx_(top):
    debug=1
def l11llll1_cx_():
    l111l1l1_cx_ = os.path.join(xbmc.translatePath(l11l1_cx_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡪࡲࡱࡪ࠭ࠏ")),l11l1_cx_ (u"࠭ࡡࡥࡦࡲࡲࡸ࠭ࠐ"))
    xbmc.log(l111l1l1_cx_)
    if lll1_cx_(l111l1l1_cx_,[l11l1_cx_ (u"ࠧࡢ࡮࡬ࡩࡳࡽࡩࡻࡣࡵࡨࠬࠑ"),l11l1_cx_ (u"ࠨࡧࡻࡸࡪࡴࡤࡦࡴ࠱ࡥࡱ࡯ࡥ࡯ࠩࠒ")])>0:
        l1111l1_cx_(l11l1_cx_ (u"ࠩࡺ࡭ࡿࡧࡲࡥࠩࠓ"))
        return
    l1l111l1_cx_ = os.path.join(xbmc.translatePath(l11l1_cx_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡵࡴࡧࡵࡨࡦࡺࡡࠨࠔ")),l11l1_cx_ (u"ࠫࡦࡪࡤࡰࡰࡢࡨࡦࡺࡡࠨࠕ"),l11l1_cx_ (u"ࠬࡹ࡫ࡪࡰ࠱ࡥࡪࡵ࡮࠯ࡰࡲࡼ࠳࠻ࠧࠖ"),l11l1_cx_ (u"࠭ࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡺࡰࡰࠬࠗ"))
    if os.path.exists(l1l111l1_cx_):
        data = open(l1l111l1_cx_,l11l1_cx_ (u"ࠧࡳࠩ࠘")).read()
        data= re.sub(l11l1_cx_ (u"ࠨ࡞࡞࠲࠯ࡢ࡝ࠨ࠙"),l11l1_cx_ (u"ࠩࠪࠚ"),data)
        if len(re.compile(l11l1_cx_ (u"ࠪࡂ࠳࠰ࠨࡱࡱ࡯ࡷࡰࡧ࡜ࡴࠬࡷࡠࡸ࠰ࡶࠪࠩࠛ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1111l1_cx_(l11l1_cx_ (u"ࠫࡸࡱࡩ࡯࠰ࡤࡩࡴࡴ࠮࡯ࡱࡻ࠲࠺࠭ࠜ"))
            return
        if len(re.compile(l11l1_cx_ (u"ࠬࡄ࠮ࠫࠪࡧࡥࡷࡳ࡯ࡸࡣ࡟ࡷ࠯ࡺ࡜ࡴࠬࡹ࠭ࠬࠝ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1111l1_cx_(l11l1_cx_ (u"࠭ࡳ࡬࡫ࡱ࠲ࡦ࡫࡯࡯࠰ࡱࡳࡽ࠴࠵ࠨࠞ"))
            return
    l1l111l1_cx_ = os.path.join(xbmc.translatePath(l11l1_cx_ (u"ࠧࡴࡲࡨࡧ࡮ࡧ࡬࠻࠱࠲ࡹࡸ࡫ࡲࡥࡣࡷࡥࠬࠟ")),l11l1_cx_ (u"ࠨࡣࡧࡨࡴࡴ࡟ࡥࡣࡷࡥࠬࠠ"),l11l1_cx_ (u"ࠩࡶ࡯࡮ࡴ࠮ࡹࡱࡱࡪࡱࡻࡥ࡯ࡥࡨࠫࠡ"),l11l1_cx_ (u"ࠪࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡾ࡭࡭ࠩࠢ"))
    if os.path.exists(l1l111l1_cx_):
        data = open(l1l111l1_cx_,l11l1_cx_ (u"ࠫࡷ࠭ࠣ")).read()
        data= re.sub(l11l1_cx_ (u"ࠬࡢ࡛࠯ࠬ࡟ࡡࠬࠤ"),l11l1_cx_ (u"࠭ࠧࠥ"),data)
        if len(re.compile(l11l1_cx_ (u"ࠧ࠿࠰࠭ࠬࡵࡵ࡬ࡴ࡭ࡤࡠࡸ࠰ࡴ࡝ࡵ࠭ࡺ࠮࠭ࠦ"),re.DOTALL|re.IGNORECASE).findall(data)):
            l1111l1_cx_(l11l1_cx_ (u"ࠨࡵ࡮࡭ࡳ࠴ࡸࡰࡰࡩࡰࡺ࡫࡮ࡤࡧࠪࠧ"))
            return
    l111l1l1_cx_ = os.path.join(xbmc.translatePath(l11l1_cx_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡻࡳࡦࡴࡧࡥࡹࡧࠧࠨ")),l11l1_cx_ (u"ࠪࡴࡷࡵࡦࡪ࡮ࡨࡷࠬࠩ"))
    if os.path.exists(l111l1l1_cx_):
        if lll1_cx_(l111l1l1_cx_,[l11l1_cx_ (u"ࠫࡰ࡯ࡤࡴࠩࠪ")])>0:
            l1111l1_cx_(l11l1_cx_ (u"ࠬࡽࡩࡻࡣࡵࡨࠬࠫ"))
            return
    l1lll1_cx_ = xbmc.translatePath(l11l1_cx_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡫ࡳࡲ࡫ࠧࠬ"))
    for f in os.listdir(l1lll1_cx_):
        if f.startswith(l11l1_cx_ (u"ࠧࡎࡏࡈࡗࠬ࠭")):
            l1111l1_cx_()
            return
def l111l1_cx_():
    try:
        debug=1
    except: pass
import resources.lib.l1ll11l1_cx_
if mode is None:
    from resources.lib import l1l1l1_cx_
    l1l1l1_cx_.l1l1l1_cx_().root()
elif mode.startswith(l11l1_cx_ (u"ࠩࡢ࡭ࡳ࡬࡯ࡠࠩ࠯"))  :
    from resources.lib import l1l1l1_cx_
    l1l1l1_cx_.l1l1l1_cx_().info()
elif mode == l11l1_cx_ (u"ࠪ࡯ࡦࡺࡥࡨࡱࡵ࡭ࡪ࠭࠰"):
    from resources.lib import l1l1l1_cx_
    l1l1l1_cx_.l1l1l1_cx_().l11l11l1_cx_()
elif mode == l11l1_cx_ (u"ࠫࡷࡵ࡫ࠨ࠱"):
    from resources.lib import l1l1l1_cx_
    l1l1l1_cx_.l1l1l1_cx_().l1l1_cx_()
elif mode == l11l1_cx_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࠲"):
    from resources.lib import l1l1l1_cx_
    l1l1l1_cx_.l1l1l1_cx_().content(ex_link)
elif mode.startswith(l11l1_cx_ (u"࠭࡟ࡠࡲࡤ࡫ࡪࡥ࡟࠻ࠩ࠳")):
    from resources.lib import l1l1l1_cx_
    l1l1l1_cx_.l1l1l1_cx_().l11l1l1_cx_(mode,ex_link)
elif mode.startswith(l11l1_cx_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ࠴")):
    from resources.lib import l1l1l1_cx_
    l1l1l1_cx_.l1l1l1_cx_().l1lllll1_cx_(mode,ex_link)
elif mode == l11l1_cx_ (u"ࠨࡲ࡯ࡥࡾࡕࡰࡦࡰࡎࡥࡹࡧ࡬ࡰࡩࠪ࠵"):
    from resources.lib import l1l1l1_cx_
    l1l1l1_cx_.l1l1l1_cx_().l1lll1l1_cx_(ex_link)
elif mode == l11l1_cx_ (u"ࠩࡶࡩࡷ࡯ࡡ࡭ࡧࡢࡷࡪࡧࡳࡰࡰࡶࠫ࠶"):
    from resources.lib import l1l1l1_cx_
    l1l1l1_cx_.l1l1l1_cx_().l1ll1ll1_cx_(ex_link)
elif mode == l11l1_cx_ (u"ࠪࡷࡪࡸࡩࡢ࡮ࡨࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭࠷"):
    from resources.lib import l1l1l1_cx_
    l1l1l1_cx_.l1l1l1_cx_().l11ll1l1_cx_(ex_link)
