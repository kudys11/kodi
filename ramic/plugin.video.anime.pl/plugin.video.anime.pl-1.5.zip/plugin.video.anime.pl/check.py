# coding: UTF-8
import sys
l111_an_ = sys.version_info [0] == 2
l11_an_ = 2048
l1l1_an_ = 7
def l11llll_an_ (ll_an_):
	global l1l1ll1_an_
	l11l111_an_ = ord (ll_an_ [-1])
	l1lll1l_an_ = ll_an_ [:-1]
	l1lll_an_ = l11l111_an_ % len (l1lll1l_an_)
	l1ll1_an_ = l1lll1l_an_ [:l1lll_an_] + l1lll1l_an_ [l1lll_an_:]
	if l111_an_:
		l1l1l11_an_ = unicode () .join ([unichr (ord (char) - l11_an_ - (l111ll_an_ + l11l111_an_) % l1l1_an_) for l111ll_an_, char in enumerate (l1ll1_an_)])
	else:
		l1l1l11_an_ = str () .join ([chr (ord (char) - l11_an_ - (l111ll_an_ + l11l111_an_) % l1l1_an_) for l111ll_an_, char in enumerate (l1ll1_an_)])
	return eval (l1l1l11_an_)
import xbmc,xbmcgui
import time,re,os,threading
try: from shutil import rmtree
except: rmtree = False
def l1llll1l_an_(l1ll1ll1_an_,l1ll1l1l_an_=[l11llll_an_ (u"ࠪࠫ࣊")]):
    debug=1
def l1lllll1_an_(name=l11llll_an_ (u"ࠫࠬ࣋")):
    debug=1
def l1lll1ll_an_(top):
    debug=1
def check():
    debug=1
try:
    debug=1
except: pass
def run():
    try:
        debug=1
    except: pass