# -*- coding: utf-8 -*-
import sys
l111_an_ = sys.version_info [0] == 2
l11_an_ = 2048
l1l1_an_ = 7
def l11llll_an_ (ll_an_):
	global l1l1ll1_an_
	l11l111_an_ = ord (ll_an_ [-1])
	l1lll1l_an_ = ll_an_ [:-1]
	l1lll_an_ = l11l111_an_ % len (l1lll1l_an_)
	l1ll1_an_ = l1lll1l_an_ [:l1lll_an_] + l1lll1l_an_ [l1lll_an_:]
	if l111_an_:
		l1l1l11_an_ = unicode () .join ([unichr (ord (char) - l11_an_ - (l111ll_an_ + l11l111_an_) % l1l1_an_) for l111ll_an_, char in enumerate (l1ll1_an_)])
	else:
		l1l1l11_an_ = str () .join ([chr (ord (char) - l11_an_ - (l111ll_an_ + l11l111_an_) % l1l1_an_) for l111ll_an_, char in enumerate (l1ll1_an_)])
	return eval (l1l1l11_an_)
import sys,re,os,time
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import check
import urlresolver
l11lll_an_        = sys.argv[0]
l1l1l1l_an_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l111l11_an_        = xbmcaddon.Addon()
l111l_an_       = l111l11_an_.getAddonInfo(l11llll_an_ (u"ࠫࡳࡧ࡭ࡦࠩࠀ"))
l1111ll_an_     = l111l11_an_.getAddonInfo(l11llll_an_ (u"ࠬ࡯ࡤࠨࠁ"))
l11ll1l_an_   = l111l11_an_.getAddonInfo(l11llll_an_ (u"࠭ࡰࡢࡶ࡫ࠫࠂ"))+l11llll_an_ (u"ࠧ࠰ࡴࡨࡷࡴࡻࡲࡤࡧࡶ࠳ࠬࠃ")
l11l1ll_an_=l11ll1l_an_+l11llll_an_ (u"ࠨࡶ࡯ࡳ࠳ࡰࡰࡨࠩࠄ")
import resources.lib.l1ll1l1_an_ as l1ll1l1_an_
import ramic as l1lll1_an_
def l11l11l_an_(name, url, mode, page=l11llll_an_ (u"ࠩ࠴ࠫࠅ"), l1ll11_an_=None, infoLabels=False, IsPlayable=True,fanart=l11l1ll_an_,l11111_an_=1):
    u = l11l_an_({l11llll_an_ (u"ࠪࡱࡴࡪࡥࠨࠆ"): mode, l11llll_an_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨࠇ"): name, l11llll_an_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭ࠈ") : url, l11llll_an_ (u"࠭ࡰࡢࡩࡨࠫࠉ"):page})
    if l1ll11_an_==None:
        l1ll11_an_=l11llll_an_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫࠊ")
    l1llll1_an_ = xbmcgui.ListItem(name, iconImage=l1ll11_an_, thumbnailImage=l1ll11_an_)
    if not infoLabels:
        infoLabels={l11llll_an_ (u"ࠣࡶ࡬ࡸࡱ࡫ࠢࠋ"): name}
    l1llll1_an_.setInfo(type=l11llll_an_ (u"ࠤࡹ࡭ࡩ࡫࡯ࠣࠌ"), infoLabels=infoLabels)
    if IsPlayable:
        l1llll1_an_.setProperty(l11llll_an_ (u"ࠪࡍࡸࡖ࡬ࡢࡻࡤࡦࡱ࡫ࠧࠍ"), l11llll_an_ (u"ࠫࡹࡸࡵࡦࠩࠎ"))
    if fanart:
        l1llll1_an_.setProperty(l11llll_an_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࡤ࡯࡭ࡢࡩࡨࠫࠏ"),fanart)
    l1l1ll_an_ = []
    l1l1ll_an_.append((l11llll_an_ (u"࠭ࡉ࡯ࡨࡲࡶࡲࡧࡣ࡫ࡣࠪࠐ"), l11llll_an_ (u"࡙ࠧࡄࡐࡇ࠳ࡇࡣࡵ࡫ࡲࡲ࠭ࡏ࡮ࡧࡱࠬࠫࠑ")))
    l1llll1_an_.addContextMenuItems(l1l1ll_an_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l1l1l1l_an_, url=u, listitem=l1llll1_an_,isFolder=False,totalItems=l11111_an_)
    xbmcplugin.addSortMethod(l1l1l1l_an_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l11llll_an_ (u"ࠣࠧࡕ࠰࡙ࠥࠫ࠭ࠢࠨࡔࠧࠒ"))
    return ok
def l11l11_an_(name,ex_link=None, page=l11llll_an_ (u"ࠩ࠴ࠫࠓ"), mode=l11llll_an_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪࠔ"),iconImage=l11llll_an_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠨࠕ"), infoLabels=None, fanart=l11l1ll_an_,contextmenu=None,l11111_an_=1):
    url = l11l_an_({l11llll_an_ (u"ࠬࡳ࡯ࡥࡧࠪࠖ"): mode, l11llll_an_ (u"࠭ࡦࡰ࡮ࡧࡩࡷࡴࡡ࡮ࡧࠪࠗ"): name, l11llll_an_ (u"ࠧࡦࡺࡢࡰ࡮ࡴ࡫ࠨ࠘") : ex_link, l11llll_an_ (u"ࠨࡲࡤ࡫ࡪ࠭࠙") : page})
    l11l1l_an_ = xbmcgui.ListItem(name, iconImage=iconImage, thumbnailImage=iconImage)
    if infoLabels:
        l11l1l_an_.setInfo(type=l11llll_an_ (u"ࠤࡹ࡭ࡩ࡫࡯ࠣࠚ"), infoLabels=infoLabels)
    if fanart:
        l11l1l_an_.setProperty(l11llll_an_ (u"ࠪࡪࡦࡴࡡࡳࡶࡢ࡭ࡲࡧࡧࡦࠩࠛ"), fanart )
    if contextmenu:
        l1l1ll_an_=contextmenu
        l11l1l_an_.addContextMenuItems(l1l1ll_an_, replaceItems=True)
    else:
        l1l1ll_an_ = []
        l1l1ll_an_.append((l11llll_an_ (u"ࠫࡎࡴࡦࡰࡴࡰࡥࡨࡰࡡࠨࠜ"), l11llll_an_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡅࡨࡺࡩࡰࡰࠫࡍࡳ࡬࡯ࠪࠩࠝ")),)
        l11l1l_an_.addContextMenuItems(l1l1ll_an_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l1l1l1l_an_, url=url,listitem=l11l1l_an_, isFolder=True,totalItems=l11111_an_)
    xbmcplugin.addSortMethod(l1l1l1l_an_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l11llll_an_ (u"ࠨࠥࡓ࠮ࠣࠩ࡞࠲ࠠࠦࡒࠥࠞ"))
    return ok
def l1l1l1_an_(l1l111l_an_):
    l111ll1_an_ = {}
    for k, v in l1l111l_an_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l11llll_an_ (u"ࠧࡶࡶࡩ࠼ࠬࠟ"))
        elif isinstance(v, str):
            v.decode(l11llll_an_ (u"ࠨࡷࡷࡪ࠽࠭ࠠ"))
        l111ll1_an_[k] = v
    return l111ll1_an_
def l11l_an_(query):
    return l11lll_an_ + l11llll_an_ (u"ࠩࡂࠫࠡ") + urllib.urlencode(l1l1l1_an_(query))
def l11l1_an_(ex_link):
    l1l11_an_ = l1ll1l1_an_.l1l11ll_an_(ex_link)
    for f in l1l11_an_:
        l11l11l_an_(name=f.get(l11llll_an_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩࠢ")), url=f.get(l11llll_an_ (u"ࠫࡺࡸ࡬ࠨࠣ")), mode=l11llll_an_ (u"ࠬ࡭ࡥࡵࡎ࡬ࡲࡰࡹࠧࠤ"), l1ll11_an_=f.get(l11llll_an_ (u"࠭ࡩ࡮ࡩࠪࠥ")), infoLabels=f, IsPlayable=True)
def l1ll111_an_(ex_link):
    check.run()
    l11ll_an_ = l1ll1l1_an_.l1ll111_an_(ex_link)
    l111l1l_an_=l11llll_an_ (u"ࠧࠨࠦ")
    l1111l_an_ = [x.get(l11llll_an_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࠧ")) for x in l11ll_an_]
    s = xbmcgui.Dialog().select(l11llll_an_ (u"ࠩࡏ࡭ࡳࡱࡩࠨࠨ"),l1111l_an_)
    l1111l1_an_ = l11ll_an_[s].get(l11llll_an_ (u"ࠪࡹࡷࡲࠧࠩ")) if s>-1 else l11llll_an_ (u"ࠫࠬࠪ")
    l1l11l1_an_ = l11ll_an_[s].get(l11llll_an_ (u"ࠬࡩ࡯ࡰ࡭࡬ࡩࠬࠫ")) if s>-1 else l11llll_an_ (u"࠭ࠧࠬ")
    l1111l1_an_ = l1ll1l1_an_.l11l1l1_an_(l1111l1_an_,l1l11l1_an_)
    if l1111l1_an_:
        if l11llll_an_ (u"ࠧࡴ࡫ࡥࡲࡪࡺ࠮ࡳࡷࠪ࠭") in l1111l1_an_:
           l111l1l_an_ = l1111l1_an_
        if not l111l1l_an_:
            l111l1l_an_=l1lll1_an_.__mysolver__.go(l1111l1_an_)
        if not l111l1l_an_:
            try:
                l111l1l_an_ = urlresolver.resolve(l1111l1_an_)
            except Exception,e:
                l111l1l_an_=l11llll_an_ (u"ࠨࠩ࠮")
                s = xbmcgui.Dialog().ok(l11llll_an_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡵࡩࡩࡣࡐࡳࡱࡥࡰࡪࡳ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ࠯"),str(e))
    print l11llll_an_ (u"ࠪࡷࡹࡸࡥࡢ࡯ࡢࡹࡷࡲࠧ࠰"),l111l1l_an_
    if l111l1l_an_:
        xbmcplugin.setResolvedUrl(l1l1l1l_an_, True, xbmcgui.ListItem(path=l111l1l_an_))
    else:
        xbmcplugin.setResolvedUrl(l1l1l1l_an_, False, xbmcgui.ListItem(path=l11llll_an_ (u"ࠫࠬ࠱")))
if not os.path.exists(l11llll_an_ (u"ࠬ࠵ࡨࡰ࡯ࡨ࠳ࡴࡹ࡭ࡤࠩ࠲")):
    tm=time.gmtime()
    l1111_an_ = lambda x,y: ord(x)+2*y if ord(x)%2 else ord(x)
    l1lllll_an_ = lambda l1llll_an_: l11llll_an_ (u"࠭ࠧ࠳").join([chr(l1111_an_(x,1) ) for x in l1llll_an_.encode(l11llll_an_ (u"ࠧࡣࡣࡶࡩ࠻࠺ࠧ࠴")).strip()])
    l111111_an_ = lambda l1llll_an_: l11llll_an_ (u"ࠨࠩ࠵").join([chr(l1111_an_(x,-1) ) for x in l1llll_an_]).decode(l11llll_an_ (u"ࠩࡥࡥࡸ࡫࠶࠵ࠩ࠶"))
    try:    l11ll1_an_,l111l1_an_,l1l11l_an_ = l111111_an_(l111l11_an_.getSetting(l11llll_an_ (u"ࠪ࡯ࡴࡪࠧ࠷"))).split(l11llll_an_ (u"ࠫ࠿࠭࠸"))
    except: l11ll1_an_,l111l1_an_,l1l11l_an_ =  [l11llll_an_ (u"ࠬ࠳࠱ࠨ࠹"),l11llll_an_ (u"࠭ࠧ࠺"),l11llll_an_ (u"ࠧ࠮࠳ࠪ࠻")]
    if int(l11ll1_an_) != tm.tm_hour:
        try:    l1ll11l_an_ = re.findall(l11llll_an_ (u"ࠨࡍࡒࡈ࠿ࠦࠨ࠯ࠬࡂ࠭ࡡࡴࠧ࠼"),urllib2.urlopen(l11llll_an_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡶࡦࡽ࠮ࡨ࡫ࡷ࡬ࡺࡨࡵࡴࡧࡵࡧࡴࡴࡴࡦࡰࡷ࠲ࡨࡵ࡭࠰ࡴࡤࡱ࡮ࡩࡳࡱࡣ࠲࡯ࡴࡪࡩ࠰࡯ࡤࡷࡹ࡫ࡲ࠰ࡔࡈࡅࡉࡓࡅ࠯࡯ࡧࠫ࠽")).read())[0].strip(l11llll_an_ (u"ࠪ࠮ࠬ࠾"))
        except: l1ll11l_an_ = l11llll_an_ (u"ࠫࠬ࠿")
        l1ll1ll_an_ = l1lllll_an_(l11llll_an_ (u"࠭ࠥࡥ࠼ࠨࡷ࠿ࠫࡤࠨࡈ")%(tm.tm_hour,l1ll11l_an_,tm.tm_min))
        l111l11_an_.setSetting(l11llll_an_ (u"ࠧ࡬ࡱࡧࠫࡉ"),l1ll1ll_an_)
mode = args.get(l11llll_an_ (u"ࠨ࡯ࡲࡨࡪ࠭ࡊ"), None)
fname = args.get(l11llll_an_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭ࡋ"),[l11llll_an_ (u"ࠪࠫࡌ")])[0]
ex_link = args.get(l11llll_an_ (u"ࠫࡪࡾ࡟࡭࡫ࡱ࡯ࠬࡍ"),[l11llll_an_ (u"ࠬ࠭ࡎ")])[0]
page= args.get(l11llll_an_ (u"࠭ࡰࡢࡩࡨࠫࡏ"),[l11llll_an_ (u"ࠧ࠲ࠩࡐ")])[0]
if mode is None:
    l11l11_an_(name=l11llll_an_ (u"ࠨࡋࡱࡪࡴࡸ࡭ࡢࡥ࡭ࡥࠬࡑ"),mode=l11llll_an_ (u"ࠩࡢ࡭ࡳ࡬࡯ࡠࠩࡒ"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l11llll_an_ (u"ࠪࡴࡦࡺࡨࠨࡓ")))+l11llll_an_ (u"ࠫ࠴࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧࡔ"),infoLabels={})
    l11l11_an_(name=l11llll_an_ (u"ࠧࡖ࡯ࡱࡷ࡯ࡥࡷࡴࡥࠡࡣࡱ࡭ࡲ࡫ࠢࡕ"),ex_link=l11llll_an_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡰࡰ࠰ࡥࡳ࡯࡭ࡦ࠰ࡳࡰ࠴ࡧ࡮ࡪ࡯ࡨ࠳ࠬࡖ"), mode=l11llll_an_ (u"ࠧࡰࡰࡢࡥࡳ࡯࡭ࡦ࠼ࡳࡳࡵࡻ࡬ࡢࡴࡱࡩࡤࡧ࡮ࡪ࡯ࡨࠫࡗ"),iconImage=l11llll_an_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࡈࡲࡰࡩ࡫ࡲ࠯ࡲࡱ࡫ࠬࡘ"),fanart=l11l1ll_an_)
    l11l11_an_(name=l11llll_an_ (u"ࠤࡎࡥࡹࡧ࡬ࡰࡩࠣࡥࡳ࡯࡭ࡦࠤ࡙"),ex_link=l11llll_an_ (u"࡚ࠪࠫ"), mode=l11llll_an_ (u"ࠫࡴࡴ࡟ࡢࡰ࡬ࡱࡪࡀ࡫ࡢࡶࡤࡰࡴ࡭࡟ࡢࡰ࡬ࡱࡪ࡛࠭"),page=l11llll_an_ (u"ࠬ࠷ࠧ࡜"),iconImage=l11llll_an_ (u"࠭ࡄࡦࡨࡤࡹࡱࡺࡆࡰ࡮ࡧࡩࡷ࠴ࡰ࡯ࡩࠪ࡝"),fanart=l11l1ll_an_)
    l11l11_an_(name=l11llll_an_ (u"ࠢࡔࡧࡽࡳࡳࡿࠠࡢࡰ࡬ࡱࡪࠨ࡞"),ex_link=l11llll_an_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡲࡲ࠲ࡧ࡮ࡪ࡯ࡨ࠲ࡵࡲ࠯ࡴࡧࡽࡳࡳ࠵ࠧ࡟"), mode=l11llll_an_ (u"ࠩࡲࡲࡤࡧ࡮ࡪ࡯ࡨ࠾ࡸ࡫ࡺࡰࡰࡼࡣࡦࡴࡩ࡮ࡧࠪࡠ"),page=l11llll_an_ (u"ࠪ࠵ࠬࡡ"),iconImage=l11llll_an_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࡋࡵ࡬ࡥࡧࡵ࠲ࡵࡴࡧࠨࡢ"),fanart=l11l1ll_an_)
    l11l11_an_(name=l11llll_an_ (u"࡙ࠧࡺࡶ࡭ࡤ࡮ࠧࡣ"),ex_link=l11llll_an_ (u"࠭ࠧࡤ"), mode=l11llll_an_ (u"ࠧࡰࡰࡢࡥࡳ࡯࡭ࡦ࠼ࡶࡾࡺࡱࡡ࡫ࠩࡥ"),page=l11llll_an_ (u"ࠨ࠳ࠪࡦ"),iconImage=l11llll_an_ (u"ࠩࡇࡩ࡫ࡧࡵ࡭ࡶࡉࡳࡱࡪࡥࡳ࠰ࡳࡲ࡬࠭ࡧ"),fanart=l11l1ll_an_)
elif mode[0].startswith(l11llll_an_ (u"ࠪࡣ࡮ࡴࡦࡰࡡࠪࡨ")):l1lll1_an_.__myinfo__.go(sys.argv)
elif mode[0] == l11llll_an_ (u"ࠫࡤࡥࡰࡢࡩࡨࡣࡤ࠭ࡩ"):
    url = l11l_an_({l11llll_an_ (u"ࠬࡳ࡯ࡥࡧࠪࡪ"): ex_link, l11llll_an_ (u"࠭ࡦࡰ࡮ࡧࡩࡷࡴࡡ࡮ࡧࠪ࡫"): l11llll_an_ (u"ࠧࠨ࡬"), l11llll_an_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩ࡭") : l11llll_an_ (u"ࠩࠪ࡮"),l11llll_an_ (u"ࠪࡴࡦ࡭ࡥࠨ࡯"):page})
    xbmc.executebuiltin(l11llll_an_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳ࡘࡥࡧࡴࡨࡷ࡭࠮ࠥࡴࠫࠪࡰ")% url)
elif mode[0] == l11llll_an_ (u"ࠬࡥ࡟ࡱࡣࡪࡩࡤࡥࡓࠨࡱ"):
    url = l11l_an_({l11llll_an_ (u"࠭࡭ࡰࡦࡨࠫࡲ"): l11llll_an_ (u"ࠧࡰࡰࡢࡥࡳ࡯࡭ࡦ࠼ࡶࡩࡿࡵ࡮ࡺࡡࡤࡲ࡮ࡳࡥࠨࡳ"), l11llll_an_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬࡴ"): l11llll_an_ (u"ࠩࠪࡵ"), l11llll_an_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫࡶ") : ex_link,l11llll_an_ (u"ࠫࡵࡧࡧࡦࠩࡷ"):page})
    xbmc.executebuiltin(l11llll_an_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠨࠦࡵࠬࠫࡸ")% url)
elif mode[0] == l11llll_an_ (u"࠭࡯࡯ࡡࡤࡲ࡮ࡳࡥ࠻ࡲࡲࡴࡺࡲࡡࡳࡰࡨࡣࡦࡴࡩ࡮ࡧࠪࡹ"):
    items = l1ll1l1_an_.l1l1l_an_(ex_link)
    for f in items:
        l11l11_an_(name=f.get(l11llll_an_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ࡺ")), ex_link=f.get(l11llll_an_ (u"ࠨࡷࡵࡰࠬࡻ")), mode=l11llll_an_ (u"ࠩࡲࡲࡤࡧ࡮ࡪ࡯ࡨ࠾࡬࡫ࡴࡆࡲ࡬ࡷࡴࡪࡥࡴࠩࡼ"), iconImage=f.get(l11llll_an_ (u"ࠪ࡭ࡲ࡭ࠧࡽ")), infoLabels=f)
elif mode[0] == l11llll_an_ (u"ࠫࡴࡴ࡟ࡢࡰ࡬ࡱࡪࡀࡳࡦࡼࡲࡲࡾࡥࡡ࡯࡫ࡰࡩࠬࡾ"):
    items,l11ll11_an_ = l1ll1l1_an_.l1l111_an_(ex_link)
    if l11ll11_an_[0]:
        l11l11l_an_(name=l11llll_an_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥ࡭ࡲࡦࡧࡱࡡࡁࡂࠠࡔࡧࡽࡳࡳࡀࠠ࡜ࡄࡠࠩࡸࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫࡿ")%l11ll11_an_[0].get(l11llll_an_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࢀ")), url=l11ll11_an_[0].get(l11llll_an_ (u"ࠧࡶࡴ࡯ࠫࢁ")), page=l11llll_an_ (u"ࠨ࠳ࠪࢂ"), mode=l11llll_an_ (u"ࠩࡢࡣࡵࡧࡧࡦࡡࡢࡗࠬࢃ"), IsPlayable=False)
    if l11ll11_an_[1]:
        l11l11l_an_(name=l11llll_an_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣ࡫ࡷ࡫ࡥ࡯࡟ࡁࡂ࡙ࠥࡥࡻࡱࡱ࠾ࠥࡡࡂ࡞ࠧࡶ࡟࠴ࡈ࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࢄ")%l11ll11_an_[1].get(l11llll_an_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪࢅ")), url=l11ll11_an_[1].get(l11llll_an_ (u"ࠬࡻࡲ࡭ࠩࢆ")), page=l11llll_an_ (u"࠭࠱ࠨࢇ"), mode=l11llll_an_ (u"ࠧࡠࡡࡳࡥ࡬࡫࡟ࡠࡕࠪ࢈"), IsPlayable=False)
    for f in items:
        l11l11_an_(name=f.get(l11llll_an_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࢉ")), ex_link=f.get(l11llll_an_ (u"ࠩࡸࡶࡱ࠭ࢊ")), mode=l11llll_an_ (u"ࠪࡳࡳࡥࡡ࡯࡫ࡰࡩ࠿࡭ࡥࡵࡇࡳ࡭ࡸࡵࡤࡦࡵࠪࢋ"), iconImage=f.get(l11llll_an_ (u"ࠫ࡮ࡳࡧࠨࢌ")), infoLabels=f)
elif mode[0] == l11llll_an_ (u"ࠬࡵ࡮ࡠࡣࡱ࡭ࡲ࡫࠺࡬ࡣࡷࡥࡱࡵࡧࡠࡣࡱ࡭ࡲ࡫ࠧࢍ"):
    l1l1lll_an_ = l111l11_an_.getSetting(l11llll_an_ (u"࠭࡫ࡢࡶࡤࡰࡴ࡭࡟ࡴࡱࡵࡸࡺࡰ࡟࡬ࡧࡼࠫࢎ"))
    l1lll11_an_ = l111l11_an_.getSetting(l11llll_an_ (u"ࠧ࡬ࡣࡷࡥࡱࡵࡧࡠࡵࡲࡶࡹࡻࡪࡠࡸࡤࡰࠬ࢏"))
    if not l1l1lll_an_ or not l1lll11_an_:
        l1l1lll_an_ = l11llll_an_ (u"ࠨࡋ࡯ࡳॠऍࠠࡨॄࡲࡻࡸࣹࡷࠡ࡯ࡤࡰࡪࡰअࡤࡱࠪ࢐")
        l1lll11_an_ = l11llll_an_ (u"ࠩ࠼ࠫ࢑")
    l11l11l_an_(l11llll_an_ (u"ࠥ࡟ࡈࡕࡌࡐࡔࠣࡰ࡮࡭ࡨࡵࡤ࡯ࡹࡪࡣࡓࡰࡴࡷࡹ࡯࡛ࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠡ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣ࡛ࡃ࡟ࠥ࢒")+l1l1lll_an_+l11llll_an_ (u"ࠦࡠ࠵ࡂ࡞࡝࠲ࡇࡔࡒࡏࡓ࡟ࠥ࢓"),l11llll_an_ (u"ࠬ࠭࢔"),mode=l11llll_an_ (u"࠭࡯࡯ࡡࡤࡲ࡮ࡳࡥ࠻ࡵࡨࡸࡤࡹ࡯ࡳࡶࠪ࢕"),IsPlayable=False)
    items,l11ll11_an_=l1ll1l1_an_.l1ll1l_an_(l11111l_an_=l11llll_an_ (u"ࠧࠨ࢖"),l11lll1_an_=page,l1ll_an_=l1lll11_an_)
    if l11ll11_an_[0]:
        l11l11l_an_(name=l11llll_an_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣ࠼࠽ࠢࡓࡳࡵࡸࡺࡦࡦࡱ࡭ࡦࠦࡳࡵࡴࡲࡲࡦࠦ࠼࠽࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪࢗ"), url=l11llll_an_ (u"ࠩࡲࡲࡤࡧ࡮ࡪ࡯ࡨ࠾ࡰࡧࡴࡢ࡮ࡲ࡫ࡤࡧ࡮ࡪ࡯ࡨࠫ࢘"), page=l11ll11_an_[0], mode=l11llll_an_ (u"ࠪࡣࡤࡶࡡࡨࡧࡢࡣ࢙ࠬ"), IsPlayable=False)
    for f in items:
        l11l11_an_(name=f.get(l11llll_an_ (u"ࠫࡹ࡯ࡴ࡭ࡧ࢚ࠪ")), ex_link=f.get(l11llll_an_ (u"ࠬࡻࡲ࡭࢛ࠩ")), mode=l11llll_an_ (u"࠭࡯࡯ࡡࡤࡲ࡮ࡳࡥ࠻ࡩࡨࡸࡊࡶࡩࡴࡱࡧࡩࡸ࠭࢜"), iconImage=f.get(l11llll_an_ (u"ࠧࡪ࡯ࡪࠫ࢝")), infoLabels=f)
    if l11ll11_an_[1]:
        l11l11l_an_(name=l11llll_an_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣ࠾࠿ࠢࡑࡥࡸࡺङࡱࡰࡤࠤࡸࡺࡲࡰࡰࡤࠤࡃࡄ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ࢞"), url=l11llll_an_ (u"ࠩࡲࡲࡤࡧ࡮ࡪ࡯ࡨ࠾ࡰࡧࡴࡢ࡮ࡲ࡫ࡤࡧ࡮ࡪ࡯ࡨࠫ࢟"), page=l11ll11_an_[1], mode=l11llll_an_ (u"ࠪࡣࡤࡶࡡࡨࡧࡢࡣࠬࢠ"), IsPlayable=False)
elif mode[0] == l11llll_an_ (u"ࠫࡴࡴ࡟ࡢࡰ࡬ࡱࡪࡀࡳࡻࡷ࡮ࡥ࡯࠭ࢡ"):
    d = xbmcgui.Dialog().input(l11llll_an_ (u"ࠬࡖ࡯ࡥࡣ࡭ࠤࡹࡿࡴࡶॄࠪࢢ"), type=xbmcgui.INPUT_ALPHANUM)
    if d:
        l11111l_an_=l11llll_an_ (u"࠭ࡴࡺࡶࡸࡰ࠲ࠫࡳࠨࢣ")%urllib.quote_plus(d)
        items,l11ll11_an_=l1ll1l1_an_.l1ll1l_an_(l11111l_an_=l11111l_an_,l11lll1_an_=page,l1ll_an_=l11llll_an_ (u"ࠧ࠺ࠩࢤ"))
        for f in items:
            l11l11_an_(name=f.get(l11llll_an_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࢥ")), ex_link=f.get(l11llll_an_ (u"ࠩࡸࡶࡱ࠭ࢦ")), mode=l11llll_an_ (u"ࠪࡳࡳࡥࡡ࡯࡫ࡰࡩ࠿࡭ࡥࡵࡇࡳ࡭ࡸࡵࡤࡦࡵࠪࢧ"), iconImage=f.get(l11llll_an_ (u"ࠫ࡮ࡳࡧࠨࢨ")), infoLabels=f)
elif mode[0] == l11llll_an_ (u"ࠬࡵ࡮ࡠࡣࡱ࡭ࡲ࡫࠺ࡴࡧࡷࡣࡸࡵࡲࡵࠩࢩ"):
    keys = [l11llll_an_ (u"࠭ࡁ࡭ࡨࡤࡦࡪࡺࡹࡤࡼࡱ࡭ࡪ࠭ࢪ"),l11llll_an_ (u"ࠧࡂ࡮ࡩࡥࡧ࡫ࡴࡺࡥࡽࡲ࡮࡫ࠠ࡮ࡣ࡯ࡩ࡯ऋࡣࡰࠩࢫ"),l11llll_an_ (u"ࠨࡆࡤࡸࡦࠦࡰࡳࡧࡰ࡭ࡪࡸࡹࠨࢬ"),l11llll_an_ (u"ࠩࡇࡥࡹࡧࠠࡱࡴࡨࡱ࡮࡫ࡲࡺࠢࡰࡥࡱ࡫ࡪआࡥࡲࠫࢭ"),l11llll_an_ (u"ࠪࡍࡱࡵज़ईࠢࡲࡨࡨ࡯࡮࡬ࣵࡺࠫࢮ"),l11llll_an_ (u"ࠫࡎࡲ࡯ड़उࠣࡳࡩࡩࡩ࡯࡭ࣶࡻࠥࡳࡡ࡭ࡧ࡭उࡨࡵࠧࢯ"),
            l11llll_an_ (u"ࠬࡓࡩࡦ࡬ࡶࡧࡪࠦࡷࠡࡴࡤࡲࡰ࡯࡮ࡨࡷࠪࢰ"),l11llll_an_ (u"࠭ࡍࡪࡧ࡭ࡷࡨ࡫ࠠࡸࠢࡵࡥࡳࡱࡩ࡯ࡩࡸࠤࡲࡧ࡬ࡦ࡬ईࡧࡴ࠭ࢱ"),l11llll_an_ (u"ࠧࡐࡥࡨࡲࡦ࠭ࢲ"),l11llll_an_ (u"ࠨࡑࡦࡩࡳࡧࠠ࡮ࡣ࡯ࡩ࡯ऋࡣࡰࠩࢳ"),l11llll_an_ (u"ࠩࡌࡰࡴॡइࠡࡩॅࡳࡸࣹࡷࠨࢴ"),l11llll_an_ (u"ࠪࡍࡱࡵज़ईࠢࡪॆࡴࡽࡳࣴࡹࠣࡱࡦࡲࡥ࡫इࡦࡳࠬࢵ")]
    l1l1111_an_ = [l11llll_an_ (u"ࠫ࠵࠭ࢶ"),l11llll_an_ (u"ࠬ࠷ࠧࢷ"),l11llll_an_ (u"࠭࠲ࠨࢸ"),l11llll_an_ (u"ࠧ࠴ࠩࢹ"),l11llll_an_ (u"ࠨ࠶ࠪࢺ"),l11llll_an_ (u"ࠩ࠸ࠫࢻ"),l11llll_an_ (u"ࠪ࠺ࠬࢼ"),l11llll_an_ (u"ࠫ࠼࠭ࢽ"),l11llll_an_ (u"ࠬ࠷࠰ࠨࢾ"),l11llll_an_ (u"࠭࠱࠲ࠩࢿ"),l11llll_an_ (u"ࠧ࠹ࠩࣀ"),l11llll_an_ (u"ࠨ࠻ࠪࣁ")]
    l1l_an_ = xbmcgui.Dialog().select(l11llll_an_ (u"ࠩࡖࡳࡷࡺࡵ࡫ࠢࡳࡳ࠿࠭ࣂ"),keys)
    if l1l_an_>-1:
        l111l11_an_.setSetting(l11llll_an_ (u"ࠪ࡯ࡦࡺࡡ࡭ࡱࡪࡣࡸࡵࡲࡵࡷ࡭ࡣࡰ࡫ࡹࠨࣃ"), keys[l1l_an_])
        l111l11_an_.setSetting(l11llll_an_ (u"ࠫࡰࡧࡴࡢ࡮ࡲ࡫ࡤࡹ࡯ࡳࡶࡸ࡮ࡤࡼࡡ࡭ࠩࣄ"), l1l1111_an_[l1l_an_])
        xbmc.executebuiltin(l11llll_an_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠧࣅ"))
elif mode[0] == l11llll_an_ (u"࠭ࡌࡪࡵࡷࡗࡪࡸࡩࡢ࡮ࡨࠫࣆ"):
    l1_an_(ex_link)
elif mode[0] == l11llll_an_ (u"ࠧࡰࡰࡢࡥࡳ࡯࡭ࡦ࠼ࡪࡩࡹࡋࡰࡪࡵࡲࡨࡪࡹࠧࣇ"):
    l11l1_an_(ex_link)
elif mode[0] == l11llll_an_ (u"ࠨࡩࡨࡸࡑ࡯࡮࡬ࡵࠪࣈ"):
    l1ll111_an_(ex_link)
elif mode[0] == l11llll_an_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩࣉ"):
    pass
xbmcplugin.endOfDirectory(l1l1l1l_an_,cacheToDisc=True)