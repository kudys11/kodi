# coding: UTF-8
import sys
l111_an_ = sys.version_info [0] == 2
l11_an_ = 2048
l1l1_an_ = 7
def l11llll_an_ (ll_an_):
	global l1l1ll1_an_
	l11l111_an_ = ord (ll_an_ [-1])
	l1lll1l_an_ = ll_an_ [:-1]
	l1lll_an_ = l11l111_an_ % len (l1lll1l_an_)
	l1ll1_an_ = l1lll1l_an_ [:l1lll_an_] + l1lll1l_an_ [l1lll_an_:]
	if l111_an_:
		l1l1l11_an_ = unicode () .join ([unichr (ord (char) - l11_an_ - (l111ll_an_ + l11l111_an_) % l1l1_an_) for l111ll_an_, char in enumerate (l1ll1_an_)])
	else:
		l1l1l11_an_ = str () .join ([chr (ord (char) - l11_an_ - (l111ll_an_ + l11l111_an_) % l1l1_an_) for l111ll_an_, char in enumerate (l1ll1_an_)])
	return eval (l1l1l11_an_)