# -*- coding: utf-8 -*-
import sys
l11l1111lll1_fo_ = sys.version_info [0] == 2
l1ll1111lll1_fo_ = 2048
l11111lll1_fo_ = 7
def l111l11lll1_fo_ (ll11lll1_fo_):
	global l11lll11lll1_fo_
	l11l1l11lll1_fo_ = ord (ll11lll1_fo_ [-1])
	l11ll11lll1_fo_ = ll11lll1_fo_ [:-1]
	l1l1ll11lll1_fo_ = l11l1l11lll1_fo_ % len (l11ll11lll1_fo_)
	l1ll11lll1_fo_ = l11ll11lll1_fo_ [:l1l1ll11lll1_fo_] + l11ll11lll1_fo_ [l1l1ll11lll1_fo_:]
	if l11l1111lll1_fo_:
		l1ll1l11lll1_fo_ = unicode () .join ([unichr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	else:
		l1ll1l11lll1_fo_ = str () .join ([chr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	return eval (l1ll1l11lll1_fo_)
import urllib2,urllib,json
import re,os
from urlparse import urlparse
import base64
import cookielib
l1111ll1l11lll1_fo_= l111l11lll1_fo_ (u"ࠤ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮࡭ࡣࡦࡾࡾࡴࡡࡴࡲ࡬ࡰࡰࡧ࠮ࡱ࡮࠲ࡰ࡮ࡹࡴࡢ࠯ࡩ࡭ࡱࡳ࡯ࡸ࠮࠴࠲࡭ࡺ࡭࡭ࠤ೪")
l111llll111lll1_fo_ = 10
l1111l11111lll1_fo_=l111l11lll1_fo_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡏࡘ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠷࠼࠳࠶࠮࠳࠷࠹࠸࠳࠿࠷ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨ೫")
def l111ll11l11lll1_fo_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l111l11lll1_fo_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ೬"), l1111l11111lll1_fo_)
    if cookies:
        req.add_header(l111l11lll1_fo_ (u"ࠧࡉ࡯ࡰ࡭࡬ࡩࠧ೭"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l111llll111lll1_fo_)
        l1l1l11111lll1_fo_ = response.read()
        response.close()
    except:
        l1l1l11111lll1_fo_=l111l11lll1_fo_ (u"࠭ࠧ೮")
    return l1l1l11111lll1_fo_
def l1l11ll111lll1_fo_(url,**kwargs):
    if not url: url = l1111ll1l11lll1_fo_
    content = l111ll11l11lll1_fo_(url)
    out=[]
    l1lll1ll1111lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠧ࠽ࡣࠣࠬ࡭ࡸࡥࡧ࠿ࠥ࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠮ࠫࡁࠬࡀ࠴ࡧ࠾ࠨ೯"),re.DOTALL).findall(content)
    l111l111111lll1_fo_=False
    l111lllll11lll1_fo_=False
    for l1lll1l1ll11lll1_fo_ in l1lll1ll1111lll1_fo_:
        href = re.compile(l111l11lll1_fo_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ೰")).findall(l1lll1l1ll11lll1_fo_)
        title = re.compile(l111l11lll1_fo_ (u"ࠩࡧࡥࡹࡧ࠭ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧೱ")).findall(l1lll1l1ll11lll1_fo_)
        date = re.compile(l111l11lll1_fo_ (u"ࠪࡨࡦࡺࡡ࠮ࡦࡤࡸࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧೲ")).findall(l1lll1l1ll11lll1_fo_)
        l111111ll11lll1_fo_=re.compile(l111l11lll1_fo_ (u"ࠫࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧೳ")).findall(l1lll1l1ll11lll1_fo_)
        if href and title:
            h = l111l11lll1_fo_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ೴")+href[0]
            t = title[0].strip()
            i = l111111ll11lll1_fo_[0] if l111111ll11lll1_fo_ else l111l11lll1_fo_ (u"࠭ࠧ೵")
            code = date[0] if date else l111l11lll1_fo_ (u"ࠧࠨ೶")
            out.append({l111l11lll1_fo_ (u"ࠨࡷࡵࡰࠬ೷"):h,l111l11lll1_fo_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ೸"):t,l111l11lll1_fo_ (u"ࠪ࡭ࡲ࡭ࠧ೹"):i,l111l11lll1_fo_ (u"ࠫࡨࡵࡤࡦࠩ೺"):code})
    if out:
        l111l111111lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥࡂࡓࡧࡳࡵछࡳࡲࡦ࠭೻")).findall(content)
        l111l111111lll1_fo_ = {l111l11lll1_fo_ (u"࠭ࡵࡳ࡮ࡳࠫ೼"): l111l111111lll1_fo_[0]} if l111l111111lll1_fo_ else False
        l111lllll11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧࡄࠠࠧ࡮ࡤࡵࡺࡵ࠻ࠡࡒࡲࡴࡷࢀࡥࡥࡰ࡬ࡥࠬ೽")).findall(content)
        l111lllll11lll1_fo_ = {l111l11lll1_fo_ (u"ࠨࡷࡵࡰࡵ࠭೾"): l111lllll11lll1_fo_[0]} if l111lllll11lll1_fo_ else False
    return (out,(l111lllll11lll1_fo_,l111l111111lll1_fo_))
def l111llll11lll1_fo_(ex_link):
    return {l111l11lll1_fo_ (u"ࠩࡰࡷ࡬࠭೿"):l111l11lll1_fo_ (u"ࠪࠫഀ"),l111l11lll1_fo_ (u"ࠫࡺࡸ࡬ࠨഁ"):ex_link}
