# -*- coding: utf-8 -*-
import sys
l11l1111lll1_fo_ = sys.version_info [0] == 2
l1ll1111lll1_fo_ = 2048
l11111lll1_fo_ = 7
def l111l11lll1_fo_ (ll11lll1_fo_):
	global l11lll11lll1_fo_
	l11l1l11lll1_fo_ = ord (ll11lll1_fo_ [-1])
	l11ll11lll1_fo_ = ll11lll1_fo_ [:-1]
	l1l1ll11lll1_fo_ = l11l1l11lll1_fo_ % len (l11ll11lll1_fo_)
	l1ll11lll1_fo_ = l11ll11lll1_fo_ [:l1l1ll11lll1_fo_] + l11ll11lll1_fo_ [l1l1ll11lll1_fo_:]
	if l11l1111lll1_fo_:
		l1ll1l11lll1_fo_ = unicode () .join ([unichr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	else:
		l1ll1l11lll1_fo_ = str () .join ([chr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	return eval (l1ll1l11lll1_fo_)
import urllib2,urllib,json
import re
from urlparse import urlparse
l111llll111lll1_fo_ = 10
l1111l11111lll1_fo_=l111l11lll1_fo_ (u"ࠫࡒࡵࡺࡪ࡮࡯ࡥ࠴࠻࠮࠱࡛ࠢࠫ࡮ࡴࡤࡰࡹࡶࠤࡓ࡚ࠠ࠲࠲࠱࠴ࡀࠦࡗࡐ࡙࠹࠸࠮ࠦࡁࡱࡲ࡯ࡩ࡜࡫ࡢࡌ࡫ࡷ࠳࠺࠹࠷࠯࠵࠹ࠤ࠭ࡑࡈࡕࡏࡏ࠰ࠥࡲࡩ࡬ࡧࠣࡋࡪࡩ࡫ࡰࠫࠣࡇ࡭ࡸ࡯࡮ࡧ࠲࠸࠽࠴࠰࠯࠴࠸࠺࠹࠴࠹࠸ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩ๦")
def l111ll11l11lll1_fo_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l111l11lll1_fo_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ๧"), l1111l11111lll1_fo_)
    if cookies:
        req.add_header(l111l11lll1_fo_ (u"ࠨࡃࡰࡱ࡮࡭ࡪࠨ๨"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l111llll111lll1_fo_)
        l1l1l11111lll1_fo_ = response.read()
        response.close()
    except:
        l1l1l11111lll1_fo_=l111l11lll1_fo_ (u"ࠧࠨ๩")
    return l1l1l11111lll1_fo_
def l1l11ll111lll1_fo_(url=l111l11lll1_fo_ (u"ࠨࠩ๪"),category=l111l11lll1_fo_ (u"ࠩ࡯ࡥࡹ࡫ࡳࡵࡡ࡫࡭࡬࡮࡬ࡪࡩ࡫ࡸࡸ࠭๫"),page=l111l11lll1_fo_ (u"ࠪ࠵ࠬ๬"),**kwargs):
    return l1ll1lllll11lll1_fo_(category,page)
def l1ll1lllll11lll1_fo_(category=l111l11lll1_fo_ (u"ࠫ࠶࠶ࠧ๭"),page=1):
    l1ll1ll11l11lll1_fo_=l111l11lll1_fo_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡱࡪࡩࡺࡺ࡭࡬࠲ࡵࡲ࠯ࡧࡴࡲࡲࡹ࠵ࡳࡩࡱࡵࡸࡨࡻࡴ࠰ࡩࡨࡸ࠲ࡹࡨࡰࡴࡷࡧࡺࡺࡳࡀࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࡿࢂࠬࡰࡢࡩࡨࡁࢀࢃࠧ๮").format(category,page)
    content = l111ll11l11lll1_fo_(l1ll1ll11l11lll1_fo_)
    out=[]
    data = json.loads(content.decode(l111l11lll1_fo_ (u"࠭ࡵࡵࡨ࠰࠼ࠬ๯")))
    l1ll1lll1l11lll1_fo_ = data.get(l111l11lll1_fo_ (u"ࠧࡴࡪࡲࡶࡹࡩࡵࡵࡵࠪ๰"),{})
    for l1ll1ll11111lll1_fo_ in sorted(l1ll1lll1l11lll1_fo_.keys(),reverse=True):
        l1ll1ll1ll11lll1_fo_ = l1ll1lll1l11lll1_fo_.get(l1ll1ll11111lll1_fo_)
        for l1ll1ll1l111lll1_fo_ in l1ll1ll1ll11lll1_fo_.get(l111l11lll1_fo_ (u"ࠨࡵ࡫ࡳࡷࡺࡣࡶࡶࡶࠫ๱"),[]):
            out.append(
                {l111l11lll1_fo_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ๲"): l111l11lll1_fo_ (u"ࠪࠩࡸࠦࠨ࡜ࡄࡠࠩࡸࡡ࠯ࡃ࡟ࠬࠫ๳")%(re.sub(l111l11lll1_fo_ (u"ࠫ࠭ࡂ࠮ࠬࡁࡁ࠭ࠬ๴"),l111l11lll1_fo_ (u"ࠬ࠭๵"),l1ll1ll1l111lll1_fo_.get(l111l11lll1_fo_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ๶"),l111l11lll1_fo_ (u"ࠧࠨ๷"))), l1ll1ll1l111lll1_fo_.get(l111l11lll1_fo_ (u"ࠨࡵࡦࡳࡷ࡫ࠧ๸"),l111l11lll1_fo_ (u"ࠩࠪ๹"))),
                  l111l11lll1_fo_ (u"ࠪࡹࡷࡲࠧ๺"):l1ll1ll1l111lll1_fo_.get(l111l11lll1_fo_ (u"ࠫࡺࡸ࡬ࠨ๻")),
                  l111l11lll1_fo_ (u"ࠬࡩ࡯ࡥࡧࠪ๼"): l111l11lll1_fo_ (u"࠭ࠥࡴ࠮ࠨࡷࠬ๽")%( l1ll1ll1l111lll1_fo_.get(l111l11lll1_fo_ (u"ࠧࡦࡸࡨࡲࡹࡥࡤࡢࡶࡨࠫ๾")), l1ll1ll1l111lll1_fo_.get(l111l11lll1_fo_ (u"ࠨࡥࡲࡱࡵ࡫ࡴࡪࡶ࡬ࡳࡳ࠭๿")))
                  })
    l111l111111lll1_fo_ = {l111l11lll1_fo_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ຀"): category, l111l11lll1_fo_ (u"ࠪࡴࡦ࡭ࡥࠨກ"): int(page)+1 } if len(out)>5 else False
    l1ll1llll111lll1_fo_ = {l111l11lll1_fo_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ຂ"): category, l111l11lll1_fo_ (u"ࠬࡶࡡࡨࡧࠪ຃"): int(page)-1 } if int(page)>1 else False
    return out,(l1ll1llll111lll1_fo_,l111l111111lll1_fo_)
def l111llll11lll1_fo_(url):
    content = l111ll11l11lll1_fo_(url)
    v=[]
    l1ll1lll1111lll1_fo_ = re.compile(l111l11lll1_fo_ (u"࠭࠼ࡪࡨࡵࡥࡲ࡫࡜ࡴࠬ࠱࠮ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩຄ")).findall(content)
    for src in l1ll1lll1111lll1_fo_:
        v.append({l111l11lll1_fo_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭຅"):urlparse(src).netloc,l111l11lll1_fo_ (u"ࠨࡷࡵࡰࠬຆ"):src})
    if not v:
        v={l111l11lll1_fo_ (u"ࠩࡰࡷ࡬࠭ງ"):l111l11lll1_fo_ (u"ࠪࡆࡷࡧ࡫ࠡ࡮࡬ࡲࡰࡻࠠ࡭ࡷࡥࠤࡵࡸࡺࡦ࡭࡬ࡩࡷࡵࡷࡢࡰ࡬ࡩࠥࡴࡡࠡ࡫ࡱࡲࡦࠦࡳࡵࡴࡲࡲࡪ࠴ࠧຈ")}
    return v
def l1l11l1l11lll1_fo_():
    content = l111ll11l11lll1_fo_(l111l11lll1_fo_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡰࡩࡨࢀࡹ࡬࡫࠱ࡴࡱ࠵࡮ࡢ࡬ࡱࡳࡼࡹࡺࡦࡡࡶ࡯ࡷࡵࡴࡺ࠰࡫ࡸࡲࡲࠧຉ"))
    cat = re.findall(l111l11lll1_fo_ (u"ࠬࡴࡧ࠮ࡥ࡯࡭ࡨࡱ࠽ࠣࡵࡨࡸࡈࡧࡴࡦࡩࡲࡶࡾࡢࠨࠩ࡞ࡧ࠯࠮ࡢࠩ࠯࠭ࡂࡹࡷࡲ࡜ࠩ࡞ࠪࠬ࠳࠱࠿ࠪ࡞ࠪࡠ࠮࠴ࠫࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬຊ"),content,re.DOTALL)
    out=[{l111l11lll1_fo_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ຋"):l111l11lll1_fo_ (u"ࠧࡏࡣ࡭ࡲࡴࡽࡳࡻࡧࠣࡗࡰࡸࣳࡵࡻࠪຌ"),l111l11lll1_fo_ (u"ࠨࡷࡵࡰࠬຍ"):l111l11lll1_fo_ (u"ࠩࠪຎ"),l111l11lll1_fo_ (u"ࠪࡴࡦࡸࡡ࡮ࡵࠪຏ"):{l111l11lll1_fo_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ຐ"):0,l111l11lll1_fo_ (u"ࠬࡶࡡࡨࡧࠪຑ"):1}}]
    for category,l111111ll11lll1_fo_,title in cat:
        print category
        if title:
            out.append({l111l11lll1_fo_ (u"࠭ࡴࡪࡶ࡯ࡩࠬຒ"):title.strip(),l111l11lll1_fo_ (u"ࠧࡶࡴ࡯ࠫຓ"):l111l11lll1_fo_ (u"ࠨࠩດ"),l111l11lll1_fo_ (u"ࠩ࡬ࡱ࡬࠭ຕ"):l111111ll11lll1_fo_,l111l11lll1_fo_ (u"ࠪࡴࡦࡸࡡ࡮ࡵࠪຖ"):{l111l11lll1_fo_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ທ"):category,l111l11lll1_fo_ (u"ࠬࡶࡡࡨࡧࠪຘ"):1}})
    return out
