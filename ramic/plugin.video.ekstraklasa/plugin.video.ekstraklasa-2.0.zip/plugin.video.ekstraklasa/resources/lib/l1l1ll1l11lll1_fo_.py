# -*- coding: utf-8 -*-
import sys
l11l1111lll1_fo_ = sys.version_info [0] == 2
l1ll1111lll1_fo_ = 2048
l11111lll1_fo_ = 7
def l111l11lll1_fo_ (ll11lll1_fo_):
	global l11lll11lll1_fo_
	l11l1l11lll1_fo_ = ord (ll11lll1_fo_ [-1])
	l11ll11lll1_fo_ = ll11lll1_fo_ [:-1]
	l1l1ll11lll1_fo_ = l11l1l11lll1_fo_ % len (l11ll11lll1_fo_)
	l1ll11lll1_fo_ = l11ll11lll1_fo_ [:l1l1ll11lll1_fo_] + l11ll11lll1_fo_ [l1l1ll11lll1_fo_:]
	if l11l1111lll1_fo_:
		l1ll1l11lll1_fo_ = unicode () .join ([unichr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	else:
		l1ll1l11lll1_fo_ = str () .join ([chr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	return eval (l1ll1l11lll1_fo_)
import urllib2,urllib,json
import re,os
from urlparse import urlparse,urljoin
import base64
import cookielib
l1111ll1l11lll1_fo_= l111l11lll1_fo_ (u"ࠨࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡲ࡬࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲࠨ઩")
l111llll111lll1_fo_ = 15
l1111l11111lll1_fo_=l111l11lll1_fo_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠴࠹࠰࠳࠲࠷࠻࠶࠵࠰࠼࠻࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬપ")
l1lll11l11lll1_fo_=l111l11lll1_fo_ (u"ࠨࠩફ")
l1lll11l11lll1_fo_=l111l11lll1_fo_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬ࡲࡻ࡯ࡳࡪࡤ࡯ࡩࡸࡻࡲࡧ࠰ࡵࡩࡻ࡯ࡥࡸࠩબ")
l11l111ll11lll1_fo_=l111l11lll1_fo_ (u"ࠪࠫભ")
def l111l1l1111lll1_fo_(url,l111l111l11lll1_fo_=l111l11lll1_fo_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࡮ࡴࡶࡪࡵ࡬ࡦࡱ࡫ࡳࡶࡴࡩ࠲ࡷ࡫ࡶࡪࡧࡺࠫમ")):
    l1l1l11111lll1_fo_=l111l11lll1_fo_ (u"ࠬ࠭ય")
    global l11l111ll11lll1_fo_
    if not l11l111ll11lll1_fo_:
        req = urllib2.Request(l111l111l11lll1_fo_,data=None,headers={l111l11lll1_fo_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪર"): l1111l11111lll1_fo_,l111l11lll1_fo_ (u"ࠧࡖࡲࡪࡶࡦࡪࡥ࠮ࡋࡱࡷࡪࡩࡵࡳࡧ࠰ࡖࡪࡷࡵࡦࡵࡷࡷࠬ઱"):1})
        response = urllib2.urlopen(req,timeout=l111llll111lll1_fo_)
        cookies=response.headers.get(l111l11lll1_fo_ (u"ࠨࡵࡨࡸ࠲ࡩ࡯ࡰ࡭࡬ࡩࠬલ"),l111l11lll1_fo_ (u"ࠩࠣࠫળ")).split(l111l11lll1_fo_ (u"ࠪࠤࠬ઴"))[0]
        response.close()
        l11l111ll11lll1_fo_ = cookies
    else:
        cookies=l11l111ll11lll1_fo_
    data = l111l11lll1_fo_ (u"ࠫࡺࡃࠥࡴࠨࡤࡰࡱࡵࡷࡄࡱࡲ࡯࡮࡫ࡳ࠾ࡱࡱࠫવ")%urllib.quote_plus(url)
    l1111ll1111lll1_fo_ = urljoin(l111l111l11lll1_fo_,l111l11lll1_fo_ (u"ࠬ࡯࡮ࡤ࡮ࡸࡨࡪࡹ࠯ࡱࡴࡲࡧࡪࡹࡳ࠯ࡲ࡫ࡴࡄࡧࡣࡵ࡫ࡲࡲࡂࡻࡰࡥࡣࡷࡩࠬશ"))
    headers={l111l11lll1_fo_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪષ"): l1111l11111lll1_fo_,l111l11lll1_fo_ (u"ࠧࡖࡲࡪࡶࡦࡪࡥ࠮ࡋࡱࡷࡪࡩࡵࡳࡧ࠰ࡖࡪࡷࡵࡦࡵࡷࡷࠬસ"):1,l111l11lll1_fo_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨહ"):cookies}
    req = urllib2.Request(l1111ll1111lll1_fo_,data,headers)
    response = urllib2.urlopen(req,timeout=l111llll111lll1_fo_)
    l1l1l11111lll1_fo_=response.read()
    if l111l11lll1_fo_ (u"ࠩࡶࡷࡱࡧࡧࡳࡧࡨࠫ઺") in l1l1l11111lll1_fo_:
        l1111ll1111lll1_fo_ = urljoin(l111l111l11lll1_fo_,l111l11lll1_fo_ (u"ࠪ࡭ࡳࡩ࡬ࡶࡦࡨࡷ࠴ࡶࡲࡰࡥࡨࡷࡸ࠴ࡰࡩࡲࡂࡥࡨࡺࡩࡰࡰࡀࡷࡸࡲࡡࡨࡴࡨࡩࠬ઻"))
        req = urllib2.Request(l1111ll1111lll1_fo_,data,headers)
        response = urllib2.urlopen(req,timeout=l111llll111lll1_fo_)
        l1l1l11111lll1_fo_=response.read()
    response.close()
    print l111l11lll1_fo_ (u"ࠫࡌࡇࡔࡆࠢ࡬ࡲ࡛ࠥࡓࡆ઼ࠩ")
    return l1l1l11111lll1_fo_
def l11l11l1l11lll1_fo_(url):
    l1l1l11111lll1_fo_=l111l11lll1_fo_ (u"ࠬ࠭ઽ")
    try:
        data = l111l11lll1_fo_ (u"࠭ࡱ࠾ࠧࡶࠪ࡭ࡲ࠽࠹࠲ࠪા")%urllib.quote_plus(url)
        l1111ll1111lll1_fo_ = l111l11lll1_fo_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡪࡰࡹ࡭ࡸ࡯ࡢ࡭ࡧࡶࡹࡷ࡬࠮ࡳࡧࡹ࡭ࡪࡽ࠯ࡪࡰࡧࡩࡽ࠴ࡰࡩࡲࡂࠫિ")+data
        headers={l111l11lll1_fo_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬી"): l1111l11111lll1_fo_,l111l11lll1_fo_ (u"ࠩࡘࡴ࡬ࡸࡡࡥࡧ࠰ࡍࡳࡹࡥࡤࡷࡵࡩ࠲ࡘࡥࡲࡷࡨࡷࡹࡹࠧુ"):1,}
        req = urllib2.Request(l1111ll1111lll1_fo_,None,headers)
        response = urllib2.urlopen(req,timeout=l111llll111lll1_fo_)
        l1l1l11111lll1_fo_=response.read()
        response.close()
        print l111l11lll1_fo_ (u"ࠪࡋࡆ࡚ࡅࠡ࡫ࡱࠤ࡚࡙ࡅࠨૂ")
    except:
        print l111l11lll1_fo_ (u"ࠫࡌࡇࡔࡆࠢ࡬ࡲ࡛ࠥࡓࡆࠢࡈࡖࡗࡕࡒࠨૃ")
        l1l1l11111lll1_fo_=l111l11lll1_fo_ (u"ࠬ࠭ૄ")
    return l1l1l11111lll1_fo_
def l111ll11l11lll1_fo_(url,data=None,cookies=None):
    l1l1l11111lll1_fo_=l111l11lll1_fo_ (u"࠭ࠧૅ")
    if l1lll11l11lll1_fo_:
        l1l1l11111lll1_fo_ = l111l1l1111lll1_fo_(url)
    if not l1l1l11111lll1_fo_:
        req = urllib2.Request(url,data)
        req.add_header(l111l11lll1_fo_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ૆"), l1111l11111lll1_fo_)
        if cookies:
            req.add_header(l111l11lll1_fo_ (u"ࠣࡅࡲࡳࡰ࡯ࡥࠣે"), cookies)
        try:
            response = urllib2.urlopen(req,timeout=l111llll111lll1_fo_)
            l1l1l11111lll1_fo_ = response.read()
            response.close()
        except:
            l1l1l11111lll1_fo_=l111l11lll1_fo_ (u"ࠩࠪૈ")
    return l1l1l11111lll1_fo_
def l111lll1l11lll1_fo_(src=l111l11lll1_fo_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡵ࠴ࡰ࡭ࠩૉ")):
    l111l1ll111lll1_fo_=l111l11lll1_fo_ (u"ࠫࡆࡈࡃࡅࡇࡉࡋࡍࡏࡊࡌࡎࡐࡒࡔࡖࡑࡓࡕࡗ࡙࡛࡝ࡘ࡚࡜ࡤࡦࡨࡪࡥࡧࡩ࡫࡭࡯ࡱ࡬࡮ࡰࡲࡴࡶࡸࡳࡵࡷࡹࡻࡽࡿࡺ࠱࠳࠵࠷࠹࠻࠶࠸࠺࠼࠯࠴࠭૊")
    src=src[::-1]
    pos = 0
    l1111l11l11lll1_fo_ =l111l11lll1_fo_ (u"ࠬ࠭ો")
    while (pos + 3 <= len(src)-1):
        l11l1111l11lll1_fo_ = ord(src[pos]);pos +=1;
        l1111l1ll11lll1_fo_ = ord(src[pos]);pos +=1;
        l1111l1l111lll1_fo_ = ord(src[pos]);pos +=1
        l1111l11l11lll1_fo_ += l111l1ll111lll1_fo_[l11l1111l11lll1_fo_>>2] + l111l1ll111lll1_fo_[((l11l1111l11lll1_fo_ << 4) + (l1111l1ll11lll1_fo_ >> 4) & 0x3f)]
        l1111l11l11lll1_fo_ += l111l1ll111lll1_fo_[((l1111l1ll11lll1_fo_ << 2) + (l1111l1l111lll1_fo_ >> 6) & 0x3f)] +  l111l1ll111lll1_fo_[(l1111l1l111lll1_fo_ & 0x3f)]
    if pos < len(src):
        l11l1111l11lll1_fo_ = ord(src[pos]);pos +=1;
        l1111l11l11lll1_fo_ += l111l1ll111lll1_fo_[l11l1111l11lll1_fo_>>2]
        if pos < len(src):
            l1111l1ll11lll1_fo_ =  ord(src[pos])
            l1111l11l11lll1_fo_ += l111l1ll111lll1_fo_[ (l11l1111l11lll1_fo_ << 4) + (l1111l1ll11lll1_fo_ >> 4) & 0x3f]
            l1111l11l11lll1_fo_ += l111l1ll111lll1_fo_[ (l1111l1ll11lll1_fo_ << 2 & 0x3f)] +l111l11lll1_fo_ (u"࠭࠽ࠨૌ")
        else:
            l1111l11l11lll1_fo_ += l111l1ll111lll1_fo_[l11l1111l11lll1_fo_ << 4 & 0x3f] +l111l11lll1_fo_ (u"ࠧ࠾࠿્ࠪ")
    return l1111l11l11lll1_fo_
def l11l11l1111lll1_fo_(user):
    url = l1111ll1l11lll1_fo_+l111l11lll1_fo_ (u"ࠣ࠱ࡸࡷࡪࡸ࠯ࠣ૎")+user+l111l11lll1_fo_ (u"ࠤ࠲ࡺ࡮ࡪࡥࡰࡵࡂࡪࡱࡧࡧࡴ࠿࡯࡭ࡻ࡫࡟ࡰࡰࡤ࡭ࡷࠬࡦࡪࡧ࡯ࡨࡸࡃࠢ૏")+urllib.quote(l111l11lll1_fo_ (u"ࠪ࡭ࡩ࠲ࡤࡶࡴࡤࡸ࡮ࡵ࡮࠭ࡶ࡬ࡸࡱ࡫ࠬࡰࡰࡤ࡭ࡷ࠲ࡰࡳ࡫ࡹࡥࡹ࡫ࠬࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡢ࠶࠹࠶࡟ࡶࡴ࡯ࠫૐ"))
    content = l111ll11l11lll1_fo_(url)
    L=[]
    if content:
        try:
            data = json.loads(content)
            L = data.get(l111l11lll1_fo_ (u"ࠫࡱ࡯ࡳࡵࠩ૑"),[])
        except:
            L = []
    return L
def l111llll11lll1_fo_(user,sort=l111l11lll1_fo_ (u"ࠬࡸࡥࡤࡧࡱࡸࠬ૒"),page=l111l11lll1_fo_ (u"࠭࠱ࠨ૓")):
    fields=l111l11lll1_fo_ (u"ࠧࡪࡦ࠯ࡹࡷ࡯ࠬࡥࡷࡵࡥࡹ࡯࡯࡯࠮ࡵࡩࡨࡵࡲࡥࡡࡶࡸࡦࡺࡵࡴ࠮ࡧࡹࡷࡧࡴࡪࡱࡱࡣ࡫ࡵࡲ࡮ࡣࡷࡸࡪࡪࠬࡵ࡫ࡷࡰࡪ࠲࡯࡯ࡣ࡬ࡶ࠱ࡶࡲࡪࡸࡤࡸࡪ࠲ࡶࡪࡧࡺࡷࡤࡺ࡯ࡵࡣ࡯࠰ࡨࡸࡥࡢࡶࡨࡨࡤࡺࡩ࡮ࡧ࠯ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡥ࠲࠵࠲ࡢࡹࡷࡲࠧ૔")
    query = {  l111l11lll1_fo_ (u"ࠨࡨ࡬ࡩࡱࡪࡳࠨ૕"):fields,
               l111l11lll1_fo_ (u"ࠩࡳࡥ࡬࡫ࠧ૖"):page,
               l111l11lll1_fo_ (u"ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡥࡲࡢࡶ࡬ࡳࠬ૗"):l111l11lll1_fo_ (u"ࠫࡼ࡯ࡤࡦࡵࡦࡶࡪ࡫࡮ࠨ૘"),
               l111l11lll1_fo_ (u"ࠬࡹ࡯ࡳࡶࠪ૙"):sort,
               l111l11lll1_fo_ (u"࠭࡬ࡪ࡯࡬ࡸࠬ૚"):50,
               l111l11lll1_fo_ (u"ࠧ࡭ࡱࡦࡥࡱ࡯ࡺࡢࡶ࡬ࡳࡳ࠭૛"):l111l11lll1_fo_ (u"ࠨࡲ࡯ࡣࡕࡒࠧ૜")
            }
    l111l111111lll1_fo_=False
    l111lllll11lll1_fo_=False
    L=[]
    if sort ==l111l11lll1_fo_ (u"ࠩ࡯࡭ࡻ࡫ࠧ૝"):
        L = l11l11l1111lll1_fo_(user)
    else:
        url = l1111ll1l11lll1_fo_+l111l11lll1_fo_ (u"ࠥ࠳ࡺࡹࡥࡳ࠱ࠥ૞")+user+l111l11lll1_fo_ (u"ࠦ࠴ࡼࡩࡥࡧࡲࡷࡄࠨ૟")+urllib.urlencode(query)
        content = l111ll11l11lll1_fo_(url)
        try:
            data = json.loads(content)
            L = data.get(l111l11lll1_fo_ (u"ࠬࡲࡩࡴࡶࠪૠ"),[])
        except:
            L=[]
        l111l111111lll1_fo_ = {l111l11lll1_fo_ (u"࠭ࡵࡴࡧࡵࠫૡ"):user,l111l11lll1_fo_ (u"ࠧࡴࡱࡵࡸࠬૢ"):sort,l111l11lll1_fo_ (u"ࠨࡲࡤ࡫ࡪ࠭ૣ"):data.get(l111l11lll1_fo_ (u"ࠩࡳࡥ࡬࡫ࠧ૤"),page)+1} if data.get(l111l11lll1_fo_ (u"ࠪ࡬ࡦࡹ࡟࡮ࡱࡵࡩࠬ૥"),False) else False
        l111lllll11lll1_fo_ = {l111l11lll1_fo_ (u"ࠫࡺࡹࡥࡳࠩ૦"):user,l111l11lll1_fo_ (u"ࠬࡹ࡯ࡳࡶࠪ૧"):sort,l111l11lll1_fo_ (u"࠭ࡰࡢࡩࡨࠫ૨"):data.get(l111l11lll1_fo_ (u"ࠧࡱࡣࡪࡩࠬ૩"),page)-1} if data.get(l111l11lll1_fo_ (u"ࠨࡲࡤ࡫ࡪ࠭૪"),page)>1 else False
    return (L,(l111lllll11lll1_fo_,l111l111111lll1_fo_))
l111ll1l111lll1_fo_=l111l11lll1_fo_ (u"ࠩࡌ࠴࡛࡟ࡖࡆ࠲ࡽ࡚ࡖࡃ࠽ࠨ૫").decode(l111l11lll1_fo_ (u"ࠪࡦࡦࡹࡥ࠷࠶ࠪ૬"))
def getVideoLinks__(l111ll11111lll1_fo_=l111l11lll1_fo_ (u"ࠫࡽ࠸ࡹࡤ࡮ࡺࡰࠬ૭")):
    l11l1111111lll1_fo_ = []
    content = l111ll11l11lll1_fo_(l111l11lll1_fo_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴ࠮ࡤࡱࡰ࠳ࡪࡳࡢࡦࡦ࠲ࡺ࡮ࡪࡥࡰ࠱ࠨࡷࠬ૮") % l111ll11111lll1_fo_)
    match = re.search(l111l11lll1_fo_ (u"࠭ࡶࡢࡴ࡟ࡷ࠰ࡩ࡯࡯ࡨ࡬࡫ࡡࡹࠪ࠾࡞ࡶ࠮࠭࠴ࠪࡀࡿࢀ࠭ࡀ࠭૯"), content)
    if match:
        try: l11l111l111lll1_fo_ = json.loads(match.group(1))
        except: l11l111l111lll1_fo_ = {}
        l11l1lll11lll1_fo_ = l11l111l111lll1_fo_.get(l111l11lll1_fo_ (u"ࠧ࡮ࡧࡷࡥࡩࡧࡴࡢࠩ૰"), {}).get(l111l11lll1_fo_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡪࡧࡶࠫ૱"), {})
        for quality, l111ll1ll11lll1_fo_ in l11l1lll11lll1_fo_.iteritems():
            for l1l1l11111lll1_fo_ in l111ll1ll11lll1_fo_:
                if quality.isdigit() and l1l1l11111lll1_fo_.get(l111l11lll1_fo_ (u"ࠩࡷࡽࡵ࡫ࠧ૲"), l111l11lll1_fo_ (u"ࠪࠫ૳")).startswith(l111l11lll1_fo_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ૴")):
                    l11l1111111lll1_fo_.append({l111l11lll1_fo_ (u"ࠬࡲࡡࡣࡧ࡯ࠫ૵"):quality,l111l11lll1_fo_ (u"࠭ࡵࡳ࡮ࠪ૶"):l1l1l11111lll1_fo_[l111l11lll1_fo_ (u"ࠧࡶࡴ࡯ࠫ૷")]})
                elif quality == l111l11lll1_fo_ (u"ࠨࡣࡸࡸࡴ࠭૸"):
                    l11l1111111lll1_fo_.append({l111l11lll1_fo_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨૹ"):quality,l111l11lll1_fo_ (u"ࠪࡹࡷࡲࠧૺ"):l1l1l11111lll1_fo_[l111l11lll1_fo_ (u"ࠫࡺࡸ࡬ࠨૻ")]})
    return l11l1111111lll1_fo_
def l11lllll11lll1_fo_(l111ll11111lll1_fo_=l111l11lll1_fo_ (u"ࠬࡾ࠲ࡺࡥࡰࡹ࠶࠭ૼ")):
    global l1lll11l11lll1_fo_
    l111l11l111lll1_fo_=l111l11lll1_fo_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠯ࡥࡲࡱ࠴࡫࡭ࡣࡧࡧ࠳ࡻ࡯ࡤࡦࡱ࠲ࠩࡸ࠭૽") % l111ll11111lll1_fo_
    content = l111ll11l11lll1_fo_(l111l11lll1_fo_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡩࡧࡩ࡭ࡻࡰࡳࡹ࡯࡯࡯࠰ࡦࡳࡲ࠵ࡥ࡮ࡤࡨࡨ࠴ࡼࡩࡥࡧࡲ࠳ࠪࡹࠧ૾") % l111ll11111lll1_fo_)
    l111l11ll11lll1_fo_=re.compile(l111l11lll1_fo_ (u"ࠨࠤࠫ࠵࠵࠾࠰ࡽ࠹࠵࠴ࢁ࠺࠸࠱ࡾ࠶࠼࠵࠯ࠢ࠻ࠪ࡟࡟ࢀࡡ࡞࡝࡟ࡠ࠮ࡡࡣࠩࠨ૿"),re.DOTALL).findall(content)
    out=[]
    if not l1lll11l11lll1_fo_:
        for quality,l111ll1ll11lll1_fo_ in l111l11ll11lll1_fo_:
            url=l111l11lll1_fo_ (u"ࠩࠪ଀")
            for type,href in re.compile(l111l11lll1_fo_ (u"ࠪࠦࡹࡿࡰࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫଁ")).findall(l111ll1ll11lll1_fo_):
                if l111l11lll1_fo_ (u"ࠫࡻ࡯ࡤࡦࡱࠪଂ") in type:
                    url= href
                    out.append({l111l11lll1_fo_ (u"ࠬࡲࡡࡣࡧ࡯ࠫଃ"):quality,l111l11lll1_fo_ (u"࠭ࡵࡳ࡮ࠪ଄"):url.replace(l111l11lll1_fo_ (u"ࠧ࡝࡞ࠪଅ"),l111l11lll1_fo_ (u"ࠨࠩଆ"))})
    if not out:
        l111l11ll11lll1_fo_=re.compile(l111l11lll1_fo_ (u"ࠩࠥࠬࡦࡻࡴࡰࠫࠥ࠾ࡡࡡࡻࠣࡶࡼࡴࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࠤࡸࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࡾ࡞ࡠࠫଇ"),re.DOTALL).findall(content)
        for quality,type,url in l111l11ll11lll1_fo_:
            url = url.replace(l111l11lll1_fo_ (u"ࠪࡠࡡ࠭ଈ"),l111l11lll1_fo_ (u"ࠫࠬଉ"))
            l1111lll111lll1_fo_ = l111ll11l11lll1_fo_(url + l111l11lll1_fo_ (u"ࠬࠬࡲࡦࡦ࡬ࡶࡪࡩࡴ࠾࠲ࠪଊ"))
            if not l1111lll111lll1_fo_:
                l1lll11l11lll1_fo_ = l111l11lll1_fo_ (u"࠭ࠧଋ")
                l1111lll111lll1_fo_ = l111ll11l11lll1_fo_(url + l111l11lll1_fo_ (u"ࠧࠧࡴࡨࡨ࡮ࡸࡥࡤࡶࡀ࠴ࠬଌ"))
            if l111ll1l111lll1_fo_ in l1111lll111lll1_fo_:
                l1111llll11lll1_fo_=re.compile(l111l11lll1_fo_ (u"ࠨࡐࡄࡑࡊࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࡜࡯ࠪ࠱࠮ࡄ࠯࡜࡯ࠩ଍")).findall(l1111lll111lll1_fo_)
                for label,url in l1111llll11lll1_fo_:
                    out.append({l111l11lll1_fo_ (u"ࠩ࡯ࡥࡧ࡫࡬ࠨ଎"):label,l111l11lll1_fo_ (u"ࠪࡹࡷࡲࠧଏ"):url})
            else:
                if l1111lll111lll1_fo_ and not l1111lll111lll1_fo_.startswith(l111l11lll1_fo_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪଐ")):
                    l1111lll111lll1_fo_ = re.findall(l111l11lll1_fo_ (u"ࠬ࠮ࡨࡵࡶࡳ࠾࠴࠵࠮ࠫࡁࠬࠨࠬ଑"), l1111lll111lll1_fo_)[0]
                l111l1lll11lll1_fo_ = l1111lll111lll1_fo_.split(l111l11lll1_fo_ (u"࠭࡬ࡪࡸࡨ࠲ࡲ࠹ࡵ࠹ࠩ଒"))[0]
                try: l111l1l1l11lll1_fo_ = l111ll11l11lll1_fo_(url)
                except: l111l1l1l11lll1_fo_=l111l11lll1_fo_ (u"ࠧࠨଓ")
                if not l111l1l1l11lll1_fo_:
                    l111l1l1l11lll1_fo_ = l111l11lll1_fo_ (u"ࠨࡋ࠳࡚࡞࡜ࡅ࠱ࡼ࡙ࡕࡴࡰࡒࡗࡪࡘࡐ࡛࡭ࡴࡗ࡭࡙ࡗ࡚࠶࡬ࡑࡖ࡭ࡳ࡬ࡓࡑࡰ࡬ࡕ࡚࡭࡛ࡌࡗࡩࡷ࡙࠶ࡘࡓࡓࡗࡉࡒࡑ࡛࡬ࡐࡔ࡭ࡴࡘࡘࡖࡏࡒࡗࡊ࡛࡛ࡓࡖ࠻ࡒࡔ࡙ࡓࡹ࡝ࡰࡐࡌ࡬ࡾࡏࡅࡃࡶࡖࡱࡐࡂࡕࡗࡘࡸ࡚ࡱࡆࡖࡔࡗ࠴ࡾࡔࡓ࠵ࡹࡐࡈࡆࡽࡍࡅࡃࡶࡕࡰࡌࡏࡓࡈࡧࡎࡗࡌࡒࡊࡒࡗࡕ࠸ࡔࡔࡆࡼࡑ࡭ࡽࡊࡔ࠱ࡔࡉࡕ࠶ࡓ࠹ࡊ࡯ࡉ࠶࡞ࢀࡅࡶ࡞ࡱࡒࡉࡏࡷࡎࡆࡅ࡮ࡑࡍ࠱ࡸࡐࡊࡉࡺࡔࡄࡂࡷࡑࡗࡎࡹࡔ࡬ࡈࡑࡖ࡙࠶ࡩࡎ࡬ࡔࡻࡎ࡭ࡰࡴࡣ࡛࡞ࡱࡒࡔࡂࡷࡥࡘࡓ࠷ࡏࡂࡱ࡭ࡖ࡛࡮ࡕࡍࡘࡪࡸ࡚࠷ࡒࡔࡔࡘࡊࡓࡒࡕ࡭ࡑ࡟ࡲࡗࡰࡰࡔࡔ࡙ࡒࡕ࡚ࡆࡗࡗࡖ࡙࠾ࡕࡐࡕࡗࡻࡑࡳ࡭ࡹࡐࡆࡪࡷࡗࡲࡊࡃࡖࡘ࡙ࡹ࡛࡫ࡇࡗࡕࡘ࠵ࡿࡎࡔ࠶ࡺࡑࡉࡇࡷࡎࡆࡄࡷࡖࡱࡆࡐࡔࡉࡨࡏࡘࡆࡓࡋࡓࡘ࡬࠶ࡎࡻࡩ࠶ࡠࡳࡓࡩࡹࡆࡗ࠴ࡗࡌࡑ࠲ࡏ࠼ࡍࡲࡌ࠲࡚ࡼࡈࡹࡓࡊࡉࡸࡏࡇࡉ࠶ࡒࡇ࠲ࡹࡑࡋࡊࡻࡎࡅࡃࡸࡑ࡮ࡏࡳࡕ࡭ࡉࡒࡗ࡚࠰ࡪࡏࡽ࡫ࡼࡏࡧࡱࡵࡤ࡜࡟ࡲࡌࡕࡇࡸࡦ࡙ࡔ࠱ࡐࡃࡲ࡮ࡡࡴࡒࡗࡪࡘࡐ࡛࡭ࡴࡖ࠳ࡕࡗࡗ࡛ࡆࡏࡎࡘࡰࡔࡘࡪࡱࡕࡕ࡚ࡓࡖࡔࡇࡘࡘࡗ࡚࠿ࡏࡑࡖࡪ࠴ࡔࡎࡧ࠱ࡐࡽࡧࡸࡘ࡬ࡋࡄࡗ࡙࡚ࡺࡕ࡬ࡈࡘࡖ࡙࠶ࡹࡏࡕ࠷ࡻࡒࡊࡁࡸࡏࡇࡅࡸࡢ࡮ࡒ࡭ࡉࡓࡗࡌࡤࡋࡔࡉࡖࡎࡖࡔࡆࡼࡑࡘࡰ࠺ࡎࡻࡋࡶࡕ࠵࠿ࡅࡓࡗࡑࡘࡕ࡙ࡊࡩࡦࡰࡑࡽࡒࡪࡒࡻࡐࡈࡆࡾ࡚ࡔࡺࡷࡧࡉࡘࡨࡍ࡬ࡔࡻࡑࡰࡉࡪࡎࡈ࠹ࡇ࡚ࡕࡖ࠻ࡌ࡮ࡖ࠺࡜࡯ࡏࡆࡍࡐࡨࡇ࡭࠴࡝ࡗ࠵ࡿࡌ࡮࠲ࡽࡨ࡙࡭ࡋࡊ࠲࡙࡝࡛ࡉ࠱࡚ࡎ࡙ࡒ࡚࡛࡫ࡗࡄࡗࡗ࠶ࡐࡔ࡬࡛࠹࡙ࡰ࡜ࡔࡕ࠲ࡻ࡚࡛ࡋ࡬ࡑࡖ࡭࠴ࡽࡓࡪࡨࡹࡨࡈࡨࡿࡍࡄࡺࡊ࡙ࡰࡌࡎ࡝ࡰࡕࡗ࠶࡙ࡑࡗࡔࡉࡔ࡙ࡏ࠱ࡍ࡬ࡄࡻࡒࡊࡁࡸࡏࡆࡼࡈࡗࡕ࠶ࡇ࡙࠴ࡱࡋࡖࡆࡩ࠼ࡑ࡯ࡋ࠳ࡐࡖࡄ࠷ࡒ࡯ࡸࡅࡖ࠳ࡖࡋࡗ࠱ࡎ࠻ࡌࡱࡋ࠸࡙ࡻࡇࡸࡒ࡯ࡗࡷࡎࡆࡉࡱࡑࡍ࠱ࡸ࡞ࡱࡒࡌࡋࡵࡏࡆࡄࡹࡒ࡯ࡉࡴࡖ࡮ࡊࡓࡘࡔ࠱࡫ࡑࡾࡎࡽࡉࡨࡲࡶࡥ࡝ࡠ࡬ࡍࡖࡐࡹࡧ࡚ࡎ࠲ࡑࡄࡳ࡯ࡘࡖࡩࡗࡏ࡚࡬ࡺࡕ࠲ࡔࡖࡖ࡚ࡌࡎࡍࡗ࡯ࡓࡗࡰࡰࡔࡔ࡙ࡒࡕ࡚ࡆࡗࡗ࡟ࡲࡘ࡛࠹ࡐࡒࡗࡉ࠺ࡓࡪࡃ࠶ࡐࡘࡆ࠺ࡍࡄࡺࡊ࡙ࡰࡌࡎࡓࡕ࠴ࡗࡖ࡜ࡒࡇࡒࡗࡍ࠶ࡒࡪࡂࡹࡐࡈࡆࡽࡍࡄࡺࡆࡕ࡚࠻ࡅࡗ࠲࡯ࡉ࡛ࡋࡧ࠺ࡐ࡭ࡍ࠸ࡔࡔࡂ࠵ࡐ࡭ࡽࡊࡔ࠱ࡔࡉࡠࡳࡗ࠱ࡎ࠻ࡌࡱࡋ࠸࡙ࡻࡇࡸࡒ࡯ࡗࡷࡎࡆࡌ࠸ࡑࡍ࠱ࡸࡐࡊࡉࡺࡔࡄࡂࡷࡐ࡭ࡎࡹࡔ࡬ࡈࡑࡖ࡙࠶ࡩࡎࡖࡄ࠸ࡒࡉࡉࡌࡤࡊࡰ࠷ࡠࡓ࠱࠲ࡏࡱ࠵ࢀࡤࡕࡩࡎࡠࡳ࠭ଔ").decode(l111l11lll1_fo_ (u"ࠩࡥࡥࡸ࡫࠶࠵ࠩକ"))
                if l111ll1l111lll1_fo_ in l111l1l1l11lll1_fo_:
                    l1111llll11lll1_fo_=re.compile(l111l11lll1_fo_ (u"ࠪࡖࡊ࡙ࡏࡍࡗࡗࡍࡔࡔ࠽ࠩ࠰࠭ࡃ࠮ࡢ࡮ࠩ࠰࠭ࡃ࠮ࡢ࡮ࠨଖ")).findall(l111l1l1l11lll1_fo_)
                    for label,l111lll1111lll1_fo_ in l1111llll11lll1_fo_:
                        out.append({l111l11lll1_fo_ (u"ࠫࡱࡧࡢࡦ࡮ࠪଗ"):label,l111l11lll1_fo_ (u"ࠬࡻࡲ࡭ࠩଘ"):l111l1lll11lll1_fo_+l111lll1111lll1_fo_})
    return out
