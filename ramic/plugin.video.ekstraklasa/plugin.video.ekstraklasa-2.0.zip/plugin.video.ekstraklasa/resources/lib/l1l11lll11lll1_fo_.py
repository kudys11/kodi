# -*- coding: utf-8 -*-
import sys
l11l1111lll1_fo_ = sys.version_info [0] == 2
l1ll1111lll1_fo_ = 2048
l11111lll1_fo_ = 7
def l111l11lll1_fo_ (ll11lll1_fo_):
	global l11lll11lll1_fo_
	l11l1l11lll1_fo_ = ord (ll11lll1_fo_ [-1])
	l11ll11lll1_fo_ = ll11lll1_fo_ [:-1]
	l1l1ll11lll1_fo_ = l11l1l11lll1_fo_ % len (l11ll11lll1_fo_)
	l1ll11lll1_fo_ = l11ll11lll1_fo_ [:l1l1ll11lll1_fo_] + l11ll11lll1_fo_ [l1l1ll11lll1_fo_:]
	if l11l1111lll1_fo_:
		l1ll1l11lll1_fo_ = unicode () .join ([unichr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	else:
		l1ll1l11lll1_fo_ = str () .join ([chr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	return eval (l1ll1l11lll1_fo_)
import urllib2,urllib,json
import re,os
from urlparse import urlparse
import base64
import cookielib
l1111ll1l11lll1_fo_= l111l11lll1_fo_ (u"ࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰࡯࡭ࡻ࡫ࡦࡰࡱࡷࡦࡦࡲ࡬ࡰ࡮࠱ࡱࡪࠨෛ")
l111llll111lll1_fo_ = 10
l1111l11111lll1_fo_=l111l11lll1_fo_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠺࠸࠯࠲࠱࠶࠺࠼࠴࠯࠻࠺ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫො")
def l111ll11l11lll1_fo_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l111l11lll1_fo_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫෝ"), l1111l11111lll1_fo_)
    if cookies:
        req.add_header(l111l11lll1_fo_ (u"ࠣࡅࡲࡳࡰ࡯ࡥࠣෞ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l111llll111lll1_fo_)
        l1l1l11111lll1_fo_ = response.read()
        response.close()
    except:
        l1l1l11111lll1_fo_=l111l11lll1_fo_ (u"ࠩࠪෟ")
    return l1l1l11111lll1_fo_
def l1l11l1l11lll1_fo_(url=l111l11lll1_fo_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮࡭࡫ࡹࡩ࡫ࡵ࡯ࡵࡤࡤࡰࡱࡵ࡬࠯࡯ࡨ࠳ࡻ࡯ࡤࡦࡱ࠲ࠫ෠")):
    content = l111ll11l11lll1_fo_(url)
    l1lllll1ll11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠫࡁ࡮࠳ࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫ࡪ࠳ࡨࡦࡣࡧࡩࡷࠦࡩࡵࡧࡰ࠱ࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠹࠾ࠨ෡"),re.DOTALL).findall(content)
    out=[]
    for l1lll11l1111lll1_fo_ in l1lllll1ll11lll1_fo_:
        l11111l1l11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ෢"),re.DOTALL).findall(l1lll11l1111lll1_fo_)
        count = re.compile(l111l11lll1_fo_ (u"࠭ࡴࡪࡶ࡯ࡩࡂࠨࡁࡳࡶ࡬ࡧࡱ࡫ࠠࡄࡱࡸࡲࡹࡀࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ෣"),re.DOTALL).findall(l1lll11l1111lll1_fo_)
        if l11111l1l11lll1_fo_ and count:
            h = l1111ll1l11lll1_fo_ + l11111l1l11lll1_fo_[0][0]
            t = l11111l1l11lll1_fo_[0][1].strip() + l111l11lll1_fo_ (u"ࠧࠡࠪ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࠨ෤") +count[0].strip() +l111l11lll1_fo_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠬࠫ෥")
            out.append({l111l11lll1_fo_ (u"ࠩࡸࡶࡱ࠭෦"):h,l111l11lll1_fo_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ෧"):t})
    return out
def l1l11ll111lll1_fo_(url,**kwargs):
    content = l111ll11l11lll1_fo_(url)
    l1lll1ll1111lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠫࡁࡺࡤ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡶࡧࡂࠬ෨"),re.DOTALL).findall(content)
    out=[]
    l111l111111lll1_fo_=False
    l111lllll11lll1_fo_=False
    for l1lll1l1ll11lll1_fo_ in l1lll1ll1111lll1_fo_:
        href = re.compile(l111l11lll1_fo_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ෩"),).findall(l1lll1l1ll11lll1_fo_)
        title = re.compile(l111l11lll1_fo_ (u"࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ෪"),re.DOTALL).findall(l1lll1l1ll11lll1_fo_)
        if href and title:
            h = l1111ll1l11lll1_fo_ + href[0]
            t = title[0].strip()
            t = re.sub(l111l11lll1_fo_ (u"ࠧࠩ࡞ࡧ࠯࠲ࡢࡤࠬࠫࠪ෫"),l111l11lll1_fo_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣ࡜ࡨ࠾࠴ࡂࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭෬"),t)
            out.append({l111l11lll1_fo_ (u"ࠩࡸࡶࡱ࠭෭"):h,l111l11lll1_fo_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ෮"):t})
    if out:
        l111l111111lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠫࡁࡧࠠࡤ࡮ࡤࡷࡸࡃࠢ࡯ࡧࡻࡸࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠥ࠭෯")).findall(content)
        l111l111111lll1_fo_ = {l111l11lll1_fo_ (u"ࠬࡻࡲ࡭ࡲࠪ෰"):l1111ll1l11lll1_fo_ + l111l111111lll1_fo_[0]} if l111l111111lll1_fo_ else False
        l111lllll11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"࠭࠼ࡢࠢࡦࡰࡦࡹࡳ࠾ࠤࡳࡶࡪࡼࡩࡰࡷࡶࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࠬ෱")).findall(content)
        l111lllll11lll1_fo_ = {l111l11lll1_fo_ (u"ࠧࡶࡴ࡯ࡴࠬෲ"):l1111ll1l11lll1_fo_ + l111lllll11lll1_fo_[0]} if l111lllll11lll1_fo_ else False
    return (out,(l111lllll11lll1_fo_,l111l111111lll1_fo_))
url=l111l11lll1_fo_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡲࡩࡷࡧࡩࡳࡴࡺࡢࡢ࡮࡯ࡳࡱ࠴࡭ࡦ࠱ࡹ࡭ࡩ࡫࡯࠰ࡧࡱ࡫ࡱࡧ࡮ࡥ࠱࠵࠹࠲࠶࠹࠮࠴࠳࠵࠼࠳ࡡࡳࡵࡨࡲࡦࡲ࠭ࡸࡧࡶࡸ࠲ࡨࡲࡰ࡯࠱࡬ࡹࡳ࡬ࠨෳ")
def l111llll11lll1_fo_(url):
    content = l111ll11l11lll1_fo_(url)
    v=[]
    src = re.compile(l111l11lll1_fo_ (u"ࠩࡧࡥࡹࡧ࠭ࡤࡱࡱࡪ࡮࡭࠽ࠣࠪ࠲࠳࠳࠰࡜࠯࡬ࡶࡳࡳ࠯ࠢࠨ෴")).findall(content)
    if src:
        v={l111l11lll1_fo_ (u"ࠪࡱࡸ࡭ࠧ෵"):l111l11lll1_fo_ (u"ࠫࠬ෶"),l111l11lll1_fo_ (u"ࠬࡻࡲ࡭ࠩ෷"):src[0].replace(l111l11lll1_fo_ (u"࠭ࡰ࡭ࡣࡼࡩࡷ࠴ࡪࡴࡱࡱࠫ෸"),l111l11lll1_fo_ (u"ࠧࡻࡧࡸࡷ࠳ࡰࡳࡰࡰࠪ෹"))}
    else:
        l1llll1ll111lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠨ࠾࡬ࡪࡷࡧ࡭ࡦࠢࠫ࠲࠯ࡅࠩ࠽࠱࡬ࡪࡷࡧ࡭ࡦࡀࠪ෺")).findall(content)
        for l1lllll1l111lll1_fo_ in l1llll1ll111lll1_fo_:
            src=re.compile(l111l11lll1_fo_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ෻")).findall(l1lllll1l111lll1_fo_)
            if src:
                v.append({l111l11lll1_fo_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ෼"):urlparse(src[0]).netloc,l111l11lll1_fo_ (u"ࠫࡺࡸ࡬ࠨ෽"):src[0]})
    if not v:
        v={l111l11lll1_fo_ (u"ࠬࡳࡳࡨࠩ෾"):l111l11lll1_fo_ (u"࠭ࡖࡪࡦࡨࡳࠥࡲࡩ࡯࡭ࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠦ࡯ࡳࠢࡱࡳࡹࠦࡳࡶࡲࡳࡳࡷࡺࡥࡥࠢࡼࡩࡹ࠭෿")}
    return v
def test():
    out,l1l1ll1111lll1_fo_ = l1lll11l1l11lll1_fo_(l111l11lll1_fo_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡱ࡯ࡶࡦࡨࡲࡳࡹࡨࡡ࡭࡮ࡲࡰ࠳ࡳࡥ࠰ࡸ࡬ࡨࡪࡵ࠯ࡦࡰࡪࡰࡦࡴࡤ࠰ࠩ฀"))
    for l1111lll1_fo_ in out:
        l1llll1l1111lll1_fo_=l111llll11lll1_fo_(l1111lll1_fo_.get(l111l11lll1_fo_ (u"ࠨࡷࡵࡰࠬก")))
        print l1llll1l1111lll1_fo_
