# -*- coding: utf-8 -*-
import sys
l11l1111lll1_fo_ = sys.version_info [0] == 2
l1ll1111lll1_fo_ = 2048
l11111lll1_fo_ = 7
def l111l11lll1_fo_ (ll11lll1_fo_):
	global l11lll11lll1_fo_
	l11l1l11lll1_fo_ = ord (ll11lll1_fo_ [-1])
	l11ll11lll1_fo_ = ll11lll1_fo_ [:-1]
	l1l1ll11lll1_fo_ = l11l1l11lll1_fo_ % len (l11ll11lll1_fo_)
	l1ll11lll1_fo_ = l11ll11lll1_fo_ [:l1l1ll11lll1_fo_] + l11ll11lll1_fo_ [l1l1ll11lll1_fo_:]
	if l11l1111lll1_fo_:
		l1ll1l11lll1_fo_ = unicode () .join ([unichr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	else:
		l1ll1l11lll1_fo_ = str () .join ([chr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	return eval (l1ll1l11lll1_fo_)
import urllib2,urllib,json
import re,os
from urlparse import urlparse
import base64
import cookielib
l1111ll1l11lll1_fo_= l111l11lll1_fo_ (u"ࠣࡪࡷࡸࡵࡀ࠯࠰ࡧࡶࡸࡦࡪࡩࡰࡵ࠱ࡴࡱࠨ௑")
l111llll111lll1_fo_ = 10
l1111l11111lll1_fo_=l111l11lll1_fo_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜ࡕࡗ࠷࠶ࠬࠤࡆࡶࡰ࡭ࡧ࡚ࡩࡧࡑࡩࡵ࠱࠸࠷࠼࠴࠳࠷ࠢࠫࡏࡍ࡚ࡍࡍ࠮ࠣࡰ࡮ࡱࡥࠡࡉࡨࡧࡰࡵࠩࠡࡅ࡫ࡶࡴࡳࡥ࠰࠶࠻࠲࠵࠴࠲࠶࠸࠷࠲࠾࠽ࠠࡔࡣࡩࡥࡷ࡯࠯࠶࠵࠺࠲࠸࠼ࠧ௒")
def l111ll11l11lll1_fo_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l111l11lll1_fo_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ௓"), l1111l11111lll1_fo_)
    if cookies:
        req.add_header(l111l11lll1_fo_ (u"ࠦࡈࡵ࡯࡬࡫ࡨࠦ௔"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l111llll111lll1_fo_)
        l1l1l11111lll1_fo_ = response.read()
        response.close()
    except:
        l1l1l11111lll1_fo_=l111l11lll1_fo_ (u"ࠬ࠭௕")
    return l1l1l11111lll1_fo_
def l1ll1lll11lll1_fo_(url=l111l11lll1_fo_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥࡴࡶࡤࡨ࡮ࡵࡳ࠯ࡲ࡯࠳ࡸࡱࡲࡰࡶࡼ࠱ࡲ࡫ࡣࡻࡱࡺࠫ௖")):
    content = l111ll11l11lll1_fo_(url)
    l1lllll1ll11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠧ࠽ࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡶࡲࡻࡻࡦ࡭ࡸࡱࡩࡠ࡮࡬࡫ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫௗ"),re.DOTALL).findall(content)
    l1lllll11l11lll1_fo_=[]
    if l1lllll1ll11lll1_fo_:
        l1lllll11l11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡹ࡯ࡴ࡭ࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࡂࠬ௘")).findall(l1lllll1ll11lll1_fo_[0])
    return l1lllll11l11lll1_fo_
url=l111l11lll1_fo_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡷࡹࡧࡤࡪࡱࡶ࠲ࡵࡲ࠯ࡴ࡭ࡵࡳࡹࡿ࠭࡮ࡧࡦࡾࡴࡽࠬࡸࡵࡽࡽࡸࡺ࡫ࡪࡧࠪ௙")
def l1l1l1ll11lll1_fo_(url):
    content = l111ll11l11lll1_fo_(url)
    l1llllll1111lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠪࡀࡹࡸࠠࡤ࡮ࡤࡷࡸࡃࠢࡥࡱ࡯ࡣࡨ࡯ࡥ࡮ࡰࡼࡣࡹࡸࠢࠡ࡫ࡷࡩࡲࡹࡣࡰࡲࡨࠤ࡮ࡺࡥ࡮ࡶࡼࡴࡪࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡥࡣࡷࡥ࠲ࡼ࡯ࡤࡣࡥࡹࡱࡧࡲࡺ࠰ࡲࡶ࡬࠵ࡅࡷࡧࡱࡸࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡳࡀࠪ௚"),re.DOTALL).findall(content)
    out=[]
    for l1l1l11lll1_fo_ in l1llllll1111lll1_fo_:
        title = re.compile(l111l11lll1_fo_ (u"ࠫࠬ࠭࠼ࡥ࡫ࡹࠤ࡮ࡺࡥ࡮ࡲࡵࡳࡵࡃࠢࡴࡷࡰࡱࡦࡸࡹࠣࠢࡶࡸࡾࡲࡥ࠾ࠤࡩࡳࡳࡺ࠭ࡴ࡫ࡽࡩ࠿ࠦ࠱ࡱࡺ࠾ࠤࡨࡵ࡬ࡰࡴ࠽ࠤ࠳࠰࠿ࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡥࡀࠪࠫࠬ௛"),re.DOTALL).findall(l1l1l11lll1_fo_)
        href = re.compile(l111l11lll1_fo_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃ࡛ࠢࡱࡥࡥࡨࢀࠠ࡮ࡧࡦࡾࠧࠦࡩࡵࡧࡰࡴࡷࡵࡰ࠾ࠤࡸࡶࡱࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀࠪ௜")).findall(l1l1l11lll1_fo_)
        if title and href:
            l1llllll1l11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ௝")).search(title[0][1]).group(1) if l111l11lll1_fo_ (u"ࠧ࠽ࠩ௞") in title[0][1] else title[0][1].strip()
            t=l11l1l111lll1_fo_(l111l11lll1_fo_ (u"ࠨࠧࡶࠤࡠࡉࡏࡍࡑࡕࠤࡱ࡯ࡧࡩࡶࡥࡰࡺ࡫࡝ࠦࡵ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ௟")%(l1llllll1l11lll1_fo_,title[0][0].strip()))
            u=href[0][0]
            c=href[0][1]
            out.append( {l111l11lll1_fo_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ௠"):t,l111l11lll1_fo_ (u"ࠪࡹࡷࡲࠧ௡"):u,l111l11lll1_fo_ (u"ࠫࡨࡵࡤࡦࠩ௢"):c} )
    return out
def l11lllll11lll1_fo_(url):
    content = l111ll11l11lll1_fo_(url)
    l1lllll1l111lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥ࡯ࡱ࡯ࡰࡠࡨ࡬ࡰࡲࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ௣"),re.DOTALL).findall(content)
    src=l111l11lll1_fo_ (u"࠭ࠧ௤")
    if l1lllll1l111lll1_fo_:
        src = re.findall(l111l11lll1_fo_ (u"ࠧࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ௥"),l1lllll1l111lll1_fo_[0])
        src = src[0] if src else l111l11lll1_fo_ (u"ࠨࠩ௦")
        if l111l11lll1_fo_ (u"ࠩࡳࡰࡦࡿࡷࡪࡴࡨࠫ௧") in src:
            src = re.findall(l111l11lll1_fo_ (u"ࠪࡨࡦࡺࡡ࠮ࡥࡲࡲ࡫࡯ࡧ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ௨"),l1lllll1l111lll1_fo_[0])
            src = src[0] if src else l111l11lll1_fo_ (u"ࠫࠬ௩")
        print src
    return src
def test():
    out = l1l1l1ll11lll1_fo_(url)
    for l1111lll1_fo_ in out:
        l11lllll11lll1_fo_(l1111lll1_fo_.get(l111l11lll1_fo_ (u"ࠬࡻࡲ࡭ࠩ௪")))
def l11l1l111lll1_fo_(l1111111111lll1_fo_):
    s=l111l11lll1_fo_ (u"࠭ࡊࡪࡐࡦ࡞ࡈࡹ࠷ࠨ௫")
    l1111111111lll1_fo_ = re.sub(s.decode(l111l11lll1_fo_ (u"ࠧࡣࡣࡶࡩ࠻࠺ࠧ௬")),l111l11lll1_fo_ (u"ࠨࠩ௭"),l1111111111lll1_fo_)
    l1111111111lll1_fo_ = re.sub(l111l11lll1_fo_ (u"ࠩࠩࡵࡺࡵࡴ࠼ࠩ௮"),l111l11lll1_fo_ (u"ࠪࠦࠬ௯"),l1111111111lll1_fo_)
    l1111111111lll1_fo_ = re.sub(l111l11lll1_fo_ (u"ࠫࠫ࠴ࠪ࠼ࠩ௰"),l111l11lll1_fo_ (u"ࠬ࠭௱"),l1111111111lll1_fo_)
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"࠭ࠦ࡯ࡤࡶࡴࡀ࠭௲"),l111l11lll1_fo_ (u"ࠧࠨ௳"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠨࠨ࡯ࡸࡀࡨࡲ࠰ࠨࡪࡸࡀ࠭௴"),l111l11lll1_fo_ (u"ࠩࠣࠫ௵"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠪࠪࡳࡪࡡࡴࡪ࠾ࠫ௶"),l111l11lll1_fo_ (u"ࠫ࠲࠭௷"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠬࠬࡱࡶࡱࡷ࠿ࠬ௸"),l111l11lll1_fo_ (u"࠭ࠢࠨ௹")).replace(l111l11lll1_fo_ (u"ࠧࠧࡣࡰࡴࡀࡷࡵࡰࡶ࠾ࠫ௺"),l111l11lll1_fo_ (u"ࠨࠤࠪ௻"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠩࠩࡳࡦࡩࡵࡵࡧ࠾ࠫ௼"),l111l11lll1_fo_ (u"ࠪࣷࠬ௽")).replace(l111l11lll1_fo_ (u"ࠫࠫࡕࡡࡤࡷࡷࡩࡀ࠭௾"),l111l11lll1_fo_ (u"ࠬࣙࠧ௿"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"࠭ࠦࡢ࡯ࡳ࠿ࡴࡧࡣࡶࡶࡨ࠿ࠬఀ"),l111l11lll1_fo_ (u"ࠧࣴࠩఁ")).replace(l111l11lll1_fo_ (u"ࠨࠨࡤࡱࡵࡁࡏࡢࡥࡸࡸࡪࡁࠧం"),l111l11lll1_fo_ (u"ࠩࣖࠫః"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠪࠪࡦࡳࡰ࠼ࠩఄ"),l111l11lll1_fo_ (u"ࠫࠫ࠭అ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠬࡢࡵ࠱࠳࠳࠹ࠬఆ"),l111l11lll1_fo_ (u"࠭अࠨఇ")).replace(l111l11lll1_fo_ (u"ࠧ࡝ࡷ࠳࠵࠵࠺ࠧఈ"),l111l11lll1_fo_ (u"ࠨआࠪఉ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠩ࡟ࡹ࠵࠷࠰࠸ࠩఊ"),l111l11lll1_fo_ (u"ࠪऋࠬఋ")).replace(l111l11lll1_fo_ (u"ࠫࡡࡻ࠰࠲࠲࠹ࠫఌ"),l111l11lll1_fo_ (u"ࠬऌࠧ఍"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"࠭࡜ࡶ࠲࠴࠵࠾࠭ఎ"),l111l11lll1_fo_ (u"ࠧचࠩఏ")).replace(l111l11lll1_fo_ (u"ࠨ࡞ࡸ࠴࠶࠷࠸ࠨఐ"),l111l11lll1_fo_ (u"ࠩछࠫ఑"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠪࡠࡺ࠶࠱࠵࠴ࠪఒ"),l111l11lll1_fo_ (u"ࠫे࠭ఓ")).replace(l111l11lll1_fo_ (u"ࠬࡢࡵ࠱࠳࠷࠵ࠬఔ"),l111l11lll1_fo_ (u"࠭ुࠨక"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠧ࡝ࡷ࠳࠵࠹࠺ࠧఖ"),l111l11lll1_fo_ (u"ࠨॆࠪగ")).replace(l111l11lll1_fo_ (u"ࠩ࡟ࡹ࠵࠷࠴࠵ࠩఘ"),l111l11lll1_fo_ (u"ࠪेࠬఙ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠫࡡࡻ࠰࠱ࡨ࠶ࠫచ"),l111l11lll1_fo_ (u"ࣹࠬࠧఛ")).replace(l111l11lll1_fo_ (u"࠭࡜ࡶ࠲࠳ࡨ࠸࠭జ"),l111l11lll1_fo_ (u"ࠧࣔࠩఝ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠨ࡞ࡸ࠴࠶࠻ࡢࠨఞ"),l111l11lll1_fo_ (u"ࠩफ़ࠫట")).replace(l111l11lll1_fo_ (u"ࠪࡠࡺ࠶࠱࠶ࡣࠪఠ"),l111l11lll1_fo_ (u"ࠫय़࠭డ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠬࡢࡵ࠱࠳࠺ࡥࠬఢ"),l111l11lll1_fo_ (u"࠭ॺࠨణ")).replace(l111l11lll1_fo_ (u"ࠧ࡝ࡷ࠳࠵࠼࠿ࠧత"),l111l11lll1_fo_ (u"ࠨॻࠪథ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠩ࡟ࡹ࠵࠷࠷ࡤࠩద"),l111l11lll1_fo_ (u"ࠪঀࠬధ")).replace(l111l11lll1_fo_ (u"ࠫࡡࡻ࠰࠲࠹ࡥࠫన"),l111l11lll1_fo_ (u"ࠬঁࠧ఩"))
    return l1111111111lll1_fo_
