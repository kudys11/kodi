# -*- coding: utf-8 -*-
import sys
l11l1111lll1_fo_ = sys.version_info [0] == 2
l1ll1111lll1_fo_ = 2048
l11111lll1_fo_ = 7
def l111l11lll1_fo_ (ll11lll1_fo_):
	global l11lll11lll1_fo_
	l11l1l11lll1_fo_ = ord (ll11lll1_fo_ [-1])
	l11ll11lll1_fo_ = ll11lll1_fo_ [:-1]
	l1l1ll11lll1_fo_ = l11l1l11lll1_fo_ % len (l11ll11lll1_fo_)
	l1ll11lll1_fo_ = l11ll11lll1_fo_ [:l1l1ll11lll1_fo_] + l11ll11lll1_fo_ [l1l1ll11lll1_fo_:]
	if l11l1111lll1_fo_:
		l1ll1l11lll1_fo_ = unicode () .join ([unichr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	else:
		l1ll1l11lll1_fo_ = str () .join ([chr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	return eval (l1ll1l11lll1_fo_)
import urllib2,urllib,json
import re,os
import urlparse
l1111ll1l11lll1_fo_= l111l11lll1_fo_ (u"ࠨࡨࡵࡶࡳ࠾࠴࠵ࡥ࡬ࡵࡷࡶࡦࡱ࡬ࡢࡵࡤ࠲ࡹࡼ࠯ࠣଙ")
l111llll111lll1_fo_ = 10
l1111l11111lll1_fo_=l111l11lll1_fo_ (u"ࠧࡎࡱࡽ࡭ࡱࡲࡡ࠰࠷࠱࠴ࠥ࠮ࡗࡪࡰࡧࡳࡼࡹࠠࡏࡖࠣ࠵࠵࠴࠰࠼࡚ࠢࡓ࡜࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠴࠹࠰࠳࠲࠷࠻࠶࠵࠰࠼࠻࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬଚ")
l1l1l1111lll1_fo_=25
def l111ll11l11lll1_fo_(url,data=None,header={}):
    headers={l111l11lll1_fo_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬଛ"): l1111l11111lll1_fo_}
    if header:
        headers.update(header)
    req = urllib2.Request(url,data,headers)
    try:
        response = urllib2.urlopen(req,timeout=l111llll111lll1_fo_)
        l1l1l11111lll1_fo_ = response.read()
        response.close()
    except:
        l1l1l11111lll1_fo_=l111l11lll1_fo_ (u"ࠩࠪଜ")
    return l1l1l11111lll1_fo_
def l1l11ll111lll1_fo_(url,type=l111l11lll1_fo_ (u"ࠪࡷࡰࡸ࡯ࡵࡻࠪଝ"),page=1,category=7,**args):
    data=None
    content = l111ll11l11lll1_fo_(url,data)
    out = l11111l1111lll1_fo_(content)
    l111l111111lll1_fo_=False
    l111lllll11lll1_fo_=False
    return out,(l111lllll11lll1_fo_,l111l111111lll1_fo_)
def l11111l1111lll1_fo_(content):
    content = content.decode(l111l11lll1_fo_ (u"ࠫࡺࡺࡦ࠮࠺ࠪଞ"))
    ids = [(a.start(), a.end()) for a in re.finditer(l111l11lll1_fo_ (u"ࠬࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡰ࡮ࡹࡴࡊࡶࡨࡱࠥ࠭ଟ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11111lll11lll1_fo_ = content[ ids[i][1]:ids[i+1][0] ].replace(l111l11lll1_fo_ (u"࠭࡜࡝ࠩଠ"),l111l11lll1_fo_ (u"ࠧࠨଡ")).encode(l111l11lll1_fo_ (u"ࠨࡷࡷࡪ࠲࠾ࠧଢ"))
        l1111111l11lll1_fo_ = re.findall(l111l11lll1_fo_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡥࡣࡷࡩࡕࡻࡢ࡭࡫ࡶ࡬ࡪࡪࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ଣ"),l11111lll11lll1_fo_,re.DOTALL)
        l111111ll11lll1_fo_ = re.findall(l111l11lll1_fo_ (u"ࠪࡀ࡮ࡳࡧࠡࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡷࡩࡲࡏ࡭ࡢࡩࡨࠦ࠳࠰ࡤࡢࡶࡤ࠱ࡴࡸࡩࡨ࡫ࡱࡥࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧତ"),l11111lll11lll1_fo_,re.DOTALL)
        l11111l1l11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ଥ")).findall(l11111lll11lll1_fo_)
        title = re.findall(l111l11lll1_fo_ (u"ࠬࡂࡨ࠴ࠢࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡸࡪࡳࡔࡪࡶ࡯ࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠴ࡀࠪଦ"),l11111lll11lll1_fo_,re.DOTALL)
        l11111ll111lll1_fo_ = re.findall(l111l11lll1_fo_ (u"࠭࠼ࡥ࡫ࡹࠤࡨࡲࡡࡴࡵࡀࠦ࡮ࡺࡥ࡮ࡎࡨࡥࡩࠦࡨࡺࡲ࡫ࡩࡳࡧࡴࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨଧ"),l11111lll11lll1_fo_,re.DOTALL)
        if l11111l1l11lll1_fo_:
            h = l11111l1l11lll1_fo_[0][0]
            t = l11l1l111lll1_fo_(l11111l1l11lll1_fo_[0][1].strip())
            i = l111111ll11lll1_fo_[0] if l111111ll11lll1_fo_ else l111l11lll1_fo_ (u"ࠧࠨନ")
            p = l11l1l111lll1_fo_(l11111ll111lll1_fo_[0].strip()) if l11111ll111lll1_fo_ else l111l11lll1_fo_ (u"ࠨࠩ଩")
            c = l11l1l111lll1_fo_(l1111111l11lll1_fo_[0].strip()) if l1111111l11lll1_fo_ else l111l11lll1_fo_ (u"ࠩࠪପ")
            out.append({l111l11lll1_fo_ (u"ࠪࡹࡷࡲࠧଫ"):h,l111l11lll1_fo_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪବ"):t,l111l11lll1_fo_ (u"ࠬ࡯࡭ࡨࠩଭ"):i,l111l11lll1_fo_ (u"࠭ࡰ࡭ࡱࡷࠫମ"):p,l111l11lll1_fo_ (u"ࠧࡤࡱࡧࡩࠬଯ"):c})
    return out
url=l111l11lll1_fo_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧ࡮ࡷࡹࡸࡡ࡬࡮ࡤࡷࡦ࠴ࡴࡷ࠱ࡶ࡯ࡷࡵࡴࡺ࠱ࡤࡶࡰࡧ࠭ࡸ࡫ࡶࡰࡦ࠳ࡰ࠮࠳࠰࠵࠲ࢀ࡯ࡣࡣࡦࡾ࠲ࡹ࡫ࡳࡱࡷ࠱ࡲ࡫ࡣࡻࡷ࠲ࡽ࠷ࡸ࡮࠲ࡧࠪର")
url=l111l11lll1_fo_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨ࡯ࡸࡺࡲࡢ࡭࡯ࡥࡸࡧ࠮ࡵࡸ࠲ࡷࡰࡸ࡯ࡵࡻ࠲ࡰࡪࡩࡨ࠮࡭ࡲࡶࡴࡴࡡ࠮࠵࠰࠶࠲ࢀ࡯ࡣࡣࡦࡾ࠲ࡹ࡫ࡳࡱࡷ࠱ࡲ࡫ࡣࡻࡷ࠲ࡲࡸ࡮ࡺ࠳࡭ࠪ଱")
url=l111l11lll1_fo_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡰࡹࡴࡳࡣ࡮ࡰࡦࡹࡡ࠯ࡶࡹ࠳ࡸࡱࡲࡰࡶࡼ࠳ࡱ࡫ࡧࡪࡣ࠰ࡻࡦࡸࡳࡻࡣࡺࡥ࠲ࡲࡥࡤࡪ࠰ࡴࡴࢀ࡮ࡢࡰ࠰ࡷࡰࡸ࡯ࡵ࠯ࡰࡩࡨࢀࡵ࠮࡫࠰ࡦࡷࡧ࡭࡬࡫࠰ࡰࡴࡺࡴࡰ࠯ࡨ࡯ࡸࡺࡲࡢ࡭࡯ࡥࡸࡧ࠯࡮ࡼࡱࡲࡻ࡭ࠧଲ")
url=l111l11lll1_fo_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡱࡳࡵࡴࡤ࡯ࡱࡧࡳࡢ࠰ࡷࡺ࠴ࡧࡲ࡬ࡣ࠰ࡻ࡮ࡹ࡬ࡢ࠯ࡳ࠱࠵࠳࠰࠮࡯ࡨࡶࡪࡨࡡࡴࡼࡺ࡭ࡱ࡯࠭࡮࡫ࡱࡥࡱ࠳࡫ࡪ࡮࡮ࡹ࠲ࡸࡹࡸࡣ࡯࡭࠲ࡧ࡬ࡦ࠯ࡽࡥࡲ࡯ࡡࡴࡶ࠰ࡷࡹࡸࡺࡦ࡮ࡤࡧ࠲ࡻࡰࡢࡦ࡯࠱ࡼ࠳ࡰࡰ࡮ࡸ࠳࠾࠻ࡶࡴ࠷࡮ࠫଳ")
url=l111l11lll1_fo_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡵ࡮ࡦࡶ࠱ࡸࡻ࠵ࡳ࠰ࡧ࡮ࡷࡹࡸࡡ࡬࡮ࡤࡷࡦ࠵࡬ࡦࡩ࡬ࡥ࠲ࡲࡥࡤࡪ࠰࠶࠲࠶࠭ࡻࡱࡥࡥࡨࢀ࠭ࡴ࡭ࡵࡳࡹ࠳࡭ࡦࡥࡽࡹ࠴ࡹࡱࡵ࠵ࡶ࠸ࠬ଴")
def l111llll11lll1_fo_(url):
    content = l111ll11l11lll1_fo_(url)
    out=[]
    l1llllllll11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"࠭࡭ࡷࡲࡀࠦ࠭ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠣࠩଵ")).findall(content)
    if not l1llllllll11lll1_fo_:
        l1llllllll11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠧࠣ࡯ࡹࡴ࠿࠮࡜ࡥ࠭࡟࠲ࡡࡪࠫࠪࠤࠪଶ")).findall(content)
    if not l1llllllll11lll1_fo_:
        l1lllllll111lll1_fo_=re.findall(l111l11lll1_fo_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡣ࡭ࡣࡶࡷࡂࠨࡰࡶ࡮ࡶࡩࡲࡨࡥࡥࡡࡨࡱࡧ࡫ࡤࠣ࠰࠭ࡨࡦࡺࡡ࠮ࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ଷ"),content)
        l1lllllll111lll1_fo_=l111l11lll1_fo_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨସ")+l1lllllll111lll1_fo_[0] if l1lllllll111lll1_fo_ else l111l11lll1_fo_ (u"ࠪࠫହ")
        if l1lllllll111lll1_fo_:
            data = l111ll11l11lll1_fo_(l1lllllll111lll1_fo_,header={l111l11lll1_fo_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ଺"):url})
            l1llllllll11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠬ࠳࡭ࡷࡲࡀࠦ࠭ࡢࡤࠬ࡞࠱ࡠࡩ࠱ࠩࠣࠩ଻")).findall(data)
            if not l1llllllll11lll1_fo_:
                l1llllllll11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"࠭ࠢ࡮ࡸࡳ࠾࠭ࡢࡤࠬ࡞࠱ࡠࡩ࠱଼ࠩࠣࠩ")).findall(content)
    if l1llllllll11lll1_fo_:
        print l1llllllll11lll1_fo_
        u2=l111l11lll1_fo_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡲ࡫࠱ࡧࡰࡳ࠮ࡰࡰࡨࡸࡦࡶࡩ࠯ࡲ࡯࠳ࡄࡨ࡯ࡥࡻࠨ࠹ࡇ࡯ࡤࠦ࠷ࡇࡁࢀ࠶ࡽࠧࡤࡲࡨࡾࠫ࠵ࡃ࡬ࡶࡳࡳࡸࡰࡤࠧ࠸ࡈࡂ࠸࠮࠱ࠨࡥࡳࡩࡿࠥ࠶ࡄࡰࡩࡹ࡮࡯ࡥࠧ࠸ࡈࡂ࡭ࡥࡵࡡࡤࡷࡸ࡫ࡴࡠࡦࡨࡸࡦ࡯࡬ࠧࡤࡲࡨࡾࠫ࠵ࡃࡲࡤࡶࡦࡳࡳࠦ࠷ࡇࠩ࠺ࡈࡉࡅࡡࡓࡹࡧࡲࡩ࡬ࡣࡦ࡮࡮ࠫ࠵ࡅ࠿ࡾ࠵ࢂࠬࡢࡰࡦࡼࠩ࠺ࡈࡰࡢࡴࡤࡱࡸࠫ࠵ࡅࠧ࠸ࡆࡘ࡫ࡲࡷ࡫ࡦࡩࠪ࠻ࡄ࠾ࡱࡱࡩࡹ࠴࡯࡯ࡧࡷ࠲ࡵࡲࠦࡣࡱࡧࡽࠪ࠻ࡂࡱࡣࡵࡥࡲࡹࠥ࠶ࡆࠨ࠹ࡇࡺࡡࡳࡩࡨࡸࠪ࠻ࡄ࠾ࡑࡑࡉ࡙࡚ࡖࠦ࠴ࡉࡩࡽࡩ࡬ࡶࡵ࡬ࡺࡪࠫ࠳ࡂࡵࡳࡳࡷࡺ࡟࠲࠲࠳ࠪࡧࡵࡤࡺࠧ࠸ࡆࡵࡧࡲࡢ࡯ࡶࠩ࠺ࡊࠥ࠶ࡄ࡮ࡻࡷࡪࠥ࠶ࡆࡀࠩ࠺ࡈࠥ࠳࠴ࡖࡉࡌࡘࠥ࠳࠴ࠨ࠹ࡉࠬࡣࡰࡰࡷࡩࡳࡺ࠭ࡵࡻࡳࡩࡂࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰࠨ࠶ࡋࡰࡳࡰࡰࡳࠪࡽ࠳࡯࡯ࡧࡷ࠱ࡦࡶࡰ࠾ࡲ࡯ࡥࡾ࡫ࡲ࠯ࡨࡵࡳࡳࡺ࠮ࡰࡰࡨࡸࡦࡶࡩ࠯ࡲ࡯ࠪࡨࡧ࡬࡭ࡤࡤࡧࡰࡃࠧଽ")
        data = l111ll11l11lll1_fo_(u2.format(l1llllllll11lll1_fo_[0],l1llllllll11lll1_fo_[0]))
        l111111l111lll1_fo_ = json.loads(data)
        out = l111111l111lll1_fo_[l111l11lll1_fo_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨା")][l111l11lll1_fo_ (u"ࠩ࠳ࠫି")][l111l11lll1_fo_ (u"ࠪࡪࡴࡸ࡭ࡢࡶࡶࠫୀ")][l111l11lll1_fo_ (u"ࠫࡼ࡯ࡤࡦࡱࠪୁ")][l111l11lll1_fo_ (u"ࠬࡳࡰ࠵ࠩୂ")]
        for l1111lll1_fo_ in out:
            l1111lll1_fo_[l111l11lll1_fo_ (u"࠭ࡴࡪࡶ࡯ࡩࠬୃ")]=l1111lll1_fo_.get(l111l11lll1_fo_ (u"ࠧࡷࡧࡵࡸ࡮ࡩࡡ࡭ࡡࡵࡩࡸࡵ࡬ࡶࡶ࡬ࡳࡳ࠭ୄ"),l111l11lll1_fo_ (u"ࠨࠩ୅"))
            l1111lll1_fo_[l111l11lll1_fo_ (u"ࠩࡵࡩࡸࡵ࡬ࡷࡧࡧࠫ୆")]=True
            print l1111lll1_fo_
    else:
        out=[{l111l11lll1_fo_ (u"ࠪࡱࡸ࡭ࠧେ"):l111l11lll1_fo_ (u"ࠫࡘࡵࡲࡳࡻ࠯ࠤࡧࡻࡴࠡࡶ࡫࡭ࡸࠦࡶࡪࡦࡨࡳࠥࡩ࡬ࡪࡲࠣ࡭ࡸࠦࡰࡳࡧࡶࡩࡳࡺ࡬ࡺࠢࡸࡲࡦࡼࡡࡪ࡮ࡤࡦࡱ࡫ࠠࡵࡱࠣࡹࡸ࡫ࡲࡴࠢࡲࡹࡹࡹࡩࡥࡧࠣࡳ࡫ࠦࡐࡰ࡮ࡤࡲࡩ࠭ୈ")}]
    return out
l1lll11l11lll1_fo_=l111l11lll1_fo_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡥࡶࡦࡳ࡫ࡢ࠯ࡳࡶࡴࡾࡹ࠯ࡲ࡯ࠫ୉")
l11l111ll11lll1_fo_=l111l11lll1_fo_ (u"࠭ࠧ୊")
def l111l1l1111lll1_fo_(url,header={}):
    l1l1l11111lll1_fo_=l111l11lll1_fo_ (u"ࠧࠨୋ")
    global l11l111ll11lll1_fo_
    if not l11l111ll11lll1_fo_:
        req = urllib2.Request(l1lll11l11lll1_fo_,data=None,headers={l111l11lll1_fo_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬୌ"): l1111l11111lll1_fo_,l111l11lll1_fo_ (u"ࠩࡘࡴ࡬ࡸࡡࡥࡧ࠰ࡍࡳࡹࡥࡤࡷࡵࡩ࠲ࡘࡥࡲࡷࡨࡷࡹࡹ୍ࠧ"):1})
        response = urllib2.urlopen(req,timeout=l111llll111lll1_fo_)
        cookies=response.headers.get(l111l11lll1_fo_ (u"ࠪࡷࡪࡺ࠭ࡤࡱࡲ࡯࡮࡫ࠧ୎"),l111l11lll1_fo_ (u"ࠫࠥ࠭୏")).split(l111l11lll1_fo_ (u"ࠬࠦࠧ୐"))[0]
        response.close()
        l11l111ll11lll1_fo_ = cookies
    else:
        cookies=l11l111ll11lll1_fo_
    data = l111l11lll1_fo_ (u"࠭ࡵ࠾ࠧࡶࠪࡦࡲ࡬ࡰࡹࡆࡳࡴࡱࡩࡦࡵࡀࡳࡳ࠭୑")%urllib.quote_plus(url)
    l1111ll1111lll1_fo_ = l1lll11l11lll1_fo_+l111l11lll1_fo_ (u"ࠧ࠰࡫ࡱࡧࡱࡻࡤࡦࡵ࠲ࡴࡷࡵࡣࡦࡵࡶ࠲ࡵ࡮ࡰࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡷࡳࡨࡦࡺࡥࠨ୒")
    headers={l111l11lll1_fo_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ୓"): l1111l11111lll1_fo_,l111l11lll1_fo_ (u"ࠩࡘࡴ࡬ࡸࡡࡥࡧ࠰ࡍࡳࡹࡥࡤࡷࡵࡩ࠲ࡘࡥࡲࡷࡨࡷࡹࡹࠧ୔"):1,l111l11lll1_fo_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ୕"):cookies}
    headers.update(header)
    req = urllib2.Request(l1111ll1111lll1_fo_,data,headers)
    response = urllib2.urlopen(req,timeout=l111llll111lll1_fo_)
    l1l1l11111lll1_fo_=response.read()
    if l111l11lll1_fo_ (u"ࠫࡸࡹ࡬ࡢࡩࡵࡩࡪ࠭ୖ") in l1l1l11111lll1_fo_:
        print l111l11lll1_fo_ (u"ࠬࡹࡳ࡭ࡣࡪࡶࡪ࡫ࠧୗ")
        l1111ll1111lll1_fo_ = l1lll11l11lll1_fo_+l111l11lll1_fo_ (u"࠭࠯ࡪࡰࡦࡰࡺࡪࡥࡴ࠱ࡳࡶࡴࡩࡥࡴࡵ࠱ࡴ࡭ࡶ࠿ࡢࡥࡷ࡭ࡴࡴ࠽ࡴࡵ࡯ࡥ࡬ࡸࡥࡦࠩ୘")
        req = urllib2.Request(l1111ll1111lll1_fo_,data,headers)
        response = urllib2.urlopen(req,timeout=l111llll111lll1_fo_)
        l1l1l11111lll1_fo_=response.read()
    response.close()
    print l111l11lll1_fo_ (u"ࠧࡈࡃࡗࡉࠥ࡯࡮ࠡࡗࡖࡉࠬ୙")
    return l1l1l11111lll1_fo_
def l1l11l1l11lll1_fo_():
    out=[
        {l111l11lll1_fo_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ୚"):l111l11lll1_fo_ (u"ࠩࡐࡥ࡬ࡧࡺࡺࡰࠣࡉࡰࡹࡴࡳࡣ࡮ࡰࡦࡹࡹࠨ୛"),l111l11lll1_fo_ (u"ࠪࡹࡷࡲࠧଡ଼"):l111l11lll1_fo_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡱࡳࡵࡴࡤ࡯ࡱࡧࡳࡢ࠰ࡷࡺ࠴ࡳࡡࡨࡣࡽࡽࡳ࠳ࡥ࡬ࡵࡷࡶࡦࡱ࡬ࡢࡵࡼࠫଢ଼"),l111l11lll1_fo_ (u"ࠬࡶࡡࡳࡣࡰࡷࠬ୞"):{l111l11lll1_fo_ (u"࠭ࡴࡺࡲࡨࠫୟ"):l111l11lll1_fo_ (u"ࠧࠨୠ"),l111l11lll1_fo_ (u"ࠨࡲࡤ࡫ࡪ࠭ୡ"):0}},
        {l111l11lll1_fo_ (u"ࠩࡷ࡭ࡹࡲࡥࠨୢ"):l111l11lll1_fo_ (u"ࠪࡆࡷࡧ࡭࡬࡫ࠪୣ"),l111l11lll1_fo_ (u"ࠫࡺࡸ࡬ࠨ୤"):l111l11lll1_fo_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡫ࡴࡶࡵࡥࡰࡲࡡࡴࡣ࠱ࡸࡻ࠵ࡢࡳࡣࡰ࡯࡮࠭୥"),l111l11lll1_fo_ (u"࠭ࡰࡢࡴࡤࡱࡸ࠭୦"):{l111l11lll1_fo_ (u"ࠧࡵࡻࡳࡩࠬ୧"):l111l11lll1_fo_ (u"ࠨࠩ୨"),l111l11lll1_fo_ (u"ࠩࡳࡥ࡬࡫ࠧ୩"):0}},
        {l111l11lll1_fo_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ୪"):l111l11lll1_fo_ (u"ࠫࡆࡱࡣ࡫ࡧࠣࡾࠥࡳࡥࡤࡼࣶࡻࠬ୫"),l111l11lll1_fo_ (u"ࠬࡻࡲ࡭ࠩ୬"):l111l11lll1_fo_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡥ࡬ࡵࡷࡶࡦࡱ࡬ࡢࡵࡤ࠲ࡹࡼ࠯ࡢ࡭ࡦ࡮ࡪ࠭୭"),l111l11lll1_fo_ (u"ࠧࡱࡣࡵࡥࡲࡹࠧ୮"):{l111l11lll1_fo_ (u"ࠨࡶࡼࡴࡪ࠭୯"):l111l11lll1_fo_ (u"ࠩࠪ୰"),l111l11lll1_fo_ (u"ࠪࡴࡦ࡭ࡥࠨୱ"):0}},
        {l111l11lll1_fo_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ୲"):l111l11lll1_fo_ (u"࡙ࠬ࡫ࡳࣵࡷࡽࠬ୳"),l111l11lll1_fo_ (u"࠭ࡵࡳ࡮ࠪ୴"):l111l11lll1_fo_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡭ࡶࡸࡷࡧ࡫࡭ࡣࡶࡥ࠳ࡺࡶ࠰ࡵ࡮ࡶࡴࡺࡹࠨ୵"),l111l11lll1_fo_ (u"ࠨࡲࡤࡶࡦࡳࡳࠨ୶"):{l111l11lll1_fo_ (u"ࠩࡷࡽࡵ࡫ࠧ୷"):l111l11lll1_fo_ (u"ࠪࠫ୸"),l111l11lll1_fo_ (u"ࠫࡵࡧࡧࡦࠩ୹"):0}},
        {l111l11lll1_fo_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ୺"):l111l11lll1_fo_ (u"࠭ࡋࡰࡰࡷࡶࡴࡽࡥࡳࡵ࡭ࡩࠥࢀࠠ࡮ࡧࡦࡾࣸࡽࠧ୻"),l111l11lll1_fo_ (u"ࠧࡶࡴ࡯ࠫ୼"):l111l11lll1_fo_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧ࡮ࡷࡹࡸࡡ࡬࡮ࡤࡷࡦ࠴ࡴࡷ࠱࡮ࡳࡳࡺࡲࡰࡹࡨࡶࡸࡰࡥࠨ୽"),l111l11lll1_fo_ (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩ୾"):{l111l11lll1_fo_ (u"ࠪࡸࡾࡶࡥࠨ୿"):l111l11lll1_fo_ (u"ࠫࠬ஀"),l111l11lll1_fo_ (u"ࠬࡶࡡࡨࡧࠪ஁"):0}},
        {l111l11lll1_fo_ (u"࠭ࡴࡪࡶ࡯ࡩࠬஂ"):l111l11lll1_fo_ (u"ࠧࡆ࡭ࡶࡸࡷࡧࡒࡢࡦࡤࡶࠬஃ"),l111l11lll1_fo_ (u"ࠨࡷࡵࡰࠬ஄"):l111l11lll1_fo_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨ࡯ࡸࡺࡲࡢ࡭࡯ࡥࡸࡧ࠮ࡵࡸ࠲ࡩࡰࡹࡴࡳࡣࡵࡥࡩࡧࡲࠨஅ"),l111l11lll1_fo_ (u"ࠪࡴࡦࡸࡡ࡮ࡵࠪஆ"):{l111l11lll1_fo_ (u"ࠫࡹࡿࡰࡦࠩஇ"):l111l11lll1_fo_ (u"ࠬ࠭ஈ"),l111l11lll1_fo_ (u"࠭ࡰࡢࡩࡨࠫஉ"):0}},
        {l111l11lll1_fo_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ஊ"):l111l11lll1_fo_ (u"ࠨࡄࡵࡥࡲࡱࡡࠡ࡭ࡲࡰࡪࡰ࡫ࡪࠩ஋"),l111l11lll1_fo_ (u"ࠩࡸࡶࡱ࠭஌"):l111l11lll1_fo_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡰࡹࡴࡳࡣ࡮ࡰࡦࡹࡡ࠯ࡶࡹ࠳ࡧࡸࡡ࡮࡭ࡤ࠱ࡰࡵ࡬ࡦ࡬࡮࡭ࠬ஍"),l111l11lll1_fo_ (u"ࠫࡵࡧࡲࡢ࡯ࡶࠫஎ"):{l111l11lll1_fo_ (u"ࠬࡺࡹࡱࡧࠪஏ"):l111l11lll1_fo_ (u"࠭ࠧஐ"),l111l11lll1_fo_ (u"ࠧࡱࡣࡪࡩࠬ஑"):0}},
        ]
    return out
def l11l1l111lll1_fo_(l1111111111lll1_fo_):
    s=l111l11lll1_fo_ (u"ࠨࡌ࡬ࡒࡨࡠࡃࡴ࠹ࠪஒ")
    l1111111111lll1_fo_ = re.sub(s.decode(l111l11lll1_fo_ (u"ࠩࡥࡥࡸ࡫࠶࠵ࠩஓ")),l111l11lll1_fo_ (u"ࠪࠫஔ"),l1111111111lll1_fo_)
    l1111111111lll1_fo_ = re.sub(l111l11lll1_fo_ (u"ࠫࠫࡷࡵࡰࡶ࠾ࠫக"),l111l11lll1_fo_ (u"ࠬࠨࠧ஖"),l1111111111lll1_fo_)
    l1111111111lll1_fo_ = re.sub(l111l11lll1_fo_ (u"࠭ࠦ࠯ࠬ࠾ࠫ஗"),l111l11lll1_fo_ (u"ࠧࠨ஘"),l1111111111lll1_fo_)
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠨࠨࡱࡦࡸࡶ࠻ࠨங"),l111l11lll1_fo_ (u"ࠩࠪச"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠪࠪࡱࡺ࠻ࡣࡴ࠲ࠪ࡬ࡺ࠻ࠨ஛"),l111l11lll1_fo_ (u"ࠫࠥ࠭ஜ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠬࠬ࡮ࡥࡣࡶ࡬ࡀ࠭஝"),l111l11lll1_fo_ (u"࠭࠭ࠨஞ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠧࠧࡳࡸࡳࡹࡁࠧட"),l111l11lll1_fo_ (u"ࠨࠤࠪ஠")).replace(l111l11lll1_fo_ (u"ࠩࠩࡥࡲࡶ࠻ࡲࡷࡲࡸࡀ࠭஡"),l111l11lll1_fo_ (u"ࠪࠦࠬ஢"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠫࠫࡵࡡࡤࡷࡷࡩࡀ࠭ண"),l111l11lll1_fo_ (u"ࣹࠬࠧத")).replace(l111l11lll1_fo_ (u"࠭ࠦࡐࡣࡦࡹࡹ࡫࠻ࠨ஥"),l111l11lll1_fo_ (u"ࠧࣔࠩ஦"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠨࠨࡤࡱࡵࡁ࡯ࡢࡥࡸࡸࡪࡁࠧ஧"),l111l11lll1_fo_ (u"ࣶࠩࠫந")).replace(l111l11lll1_fo_ (u"ࠪࠪࡦࡳࡰ࠼ࡑࡤࡧࡺࡺࡥ࠼ࠩன"),l111l11lll1_fo_ (u"ࠫࣘ࠭ப"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠬࠬࡡ࡮ࡲ࠾ࠫ஫"),l111l11lll1_fo_ (u"࠭ࠦࠨ஬"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠧ࡝ࡷ࠳࠵࠵࠻ࠧ஭"),l111l11lll1_fo_ (u"ࠨइࠪம")).replace(l111l11lll1_fo_ (u"ࠩ࡟ࡹ࠵࠷࠰࠵ࠩய"),l111l11lll1_fo_ (u"ࠪईࠬர"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠫࡡࡻ࠰࠲࠲࠺ࠫற"),l111l11lll1_fo_ (u"ࠬऍࠧல")).replace(l111l11lll1_fo_ (u"࠭࡜ࡶ࠲࠴࠴࠻࠭ள"),l111l11lll1_fo_ (u"ࠧइࠩழ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠨ࡞ࡸ࠴࠶࠷࠹ࠨவ"),l111l11lll1_fo_ (u"ࠩजࠫஶ")).replace(l111l11lll1_fo_ (u"ࠪࡠࡺ࠶࠱࠲࠺ࠪஷ"),l111l11lll1_fo_ (u"ࠫझ࠭ஸ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠬࡢࡵ࠱࠳࠷࠶ࠬஹ"),l111l11lll1_fo_ (u"࠭ूࠨ஺")).replace(l111l11lll1_fo_ (u"ࠧ࡝ࡷ࠳࠵࠹࠷ࠧ஻"),l111l11lll1_fo_ (u"ࠨृࠪ஼"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠩ࡟ࡹ࠵࠷࠴࠵ࠩ஽"),l111l11lll1_fo_ (u"ࠪैࠬா")).replace(l111l11lll1_fo_ (u"ࠫࡡࡻ࠰࠲࠶࠷ࠫி"),l111l11lll1_fo_ (u"ࠬॉࠧீ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"࠭࡜ࡶ࠲࠳ࡪ࠸࠭ு"),l111l11lll1_fo_ (u"ࠧࣴࠩூ")).replace(l111l11lll1_fo_ (u"ࠨ࡞ࡸ࠴࠵ࡪ࠳ࠨ௃"),l111l11lll1_fo_ (u"ࠩࣖࠫ௄"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠪࡠࡺ࠶࠱࠶ࡤࠪ௅"),l111l11lll1_fo_ (u"ࠫॠ࠭ெ")).replace(l111l11lll1_fo_ (u"ࠬࡢࡵ࠱࠳࠸ࡥࠬே"),l111l11lll1_fo_ (u"࠭ग़ࠨை"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠧ࡝ࡷ࠳࠵࠼ࡧࠧ௉"),l111l11lll1_fo_ (u"ࠨॼࠪொ")).replace(l111l11lll1_fo_ (u"ࠩ࡟ࡹ࠵࠷࠷࠺ࠩோ"),l111l11lll1_fo_ (u"ࠪॽࠬௌ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠫࡡࡻ࠰࠲࠹ࡦ்ࠫ"),l111l11lll1_fo_ (u"ࠬংࠧ௎")).replace(l111l11lll1_fo_ (u"࠭࡜ࡶ࠲࠴࠻ࡧ࠭௏"),l111l11lll1_fo_ (u"ࠧॼࠩௐ"))
    return l1111111111lll1_fo_
