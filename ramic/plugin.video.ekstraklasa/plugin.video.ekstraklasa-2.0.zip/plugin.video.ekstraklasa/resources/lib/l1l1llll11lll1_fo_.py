# -*- coding: utf-8 -*-
import sys
l11l1111lll1_fo_ = sys.version_info [0] == 2
l1ll1111lll1_fo_ = 2048
l11111lll1_fo_ = 7
def l111l11lll1_fo_ (ll11lll1_fo_):
	global l11lll11lll1_fo_
	l11l1l11lll1_fo_ = ord (ll11lll1_fo_ [-1])
	l11ll11lll1_fo_ = ll11lll1_fo_ [:-1]
	l1l1ll11lll1_fo_ = l11l1l11lll1_fo_ % len (l11ll11lll1_fo_)
	l1ll11lll1_fo_ = l11ll11lll1_fo_ [:l1l1ll11lll1_fo_] + l11ll11lll1_fo_ [l1l1ll11lll1_fo_:]
	if l11l1111lll1_fo_:
		l1ll1l11lll1_fo_ = unicode () .join ([unichr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	else:
		l1ll1l11lll1_fo_ = str () .join ([chr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	return eval (l1ll1l11lll1_fo_)
import urllib2
import re
l111llll111lll1_fo_=10
l1111l11111lll1_fo_ = l111l11lll1_fo_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠺࠸࠯࠲࠱࠶࠺࠼࠴࠯࠻࠺ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫప")
def l111ll11l11lll1_fo_(url):
    req = urllib2.Request(url)
    req.add_header(l111l11lll1_fo_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫఫ"), l1111l11111lll1_fo_)
    try:
        response = urllib2.urlopen(req,timeout=l111llll111lll1_fo_)
        cookies = response.headers[l111l11lll1_fo_ (u"ࠨࡵࡨࡸ࠲ࡩ࡯ࡰ࡭࡬ࡩࠬబ")]
        print l111l11lll1_fo_ (u"ࠩࡶࡩࡹ࠳ࡣࡰࡱ࡮࡭ࡪ࠭భ"),url,cookies
        l1l1l11111lll1_fo_ = response.read()
        response.close()
    except:
        l1l1l11111lll1_fo_=l111l11lll1_fo_ (u"ࠪࠫమ")
    return l1l1l11111lll1_fo_
def l1l1ll111lll1_fo_(url):
    if url.startswith(l111l11lll1_fo_ (u"ࠫ࠴࠵ࠧయ")):
        url = l111l11lll1_fo_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾ࠬర")+url
    src=l111l11lll1_fo_ (u"࠭ࠧఱ")
    l1lllll11111lll1_fo_ = l111l11lll1_fo_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡧࡸࡡ࡮࡭ࡤ࠲ࡵࡸ࡯ࡹࡻ࠱ࡲࡪࡺ࠮ࡱ࡮࠲࡭ࡳࡪࡥࡹ࠰ࡳ࡬ࡵࡅࡱ࠾ࠩల")
    content = l111ll11l11lll1_fo_(url)
    l111l11ll11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠨࡵࡵࡧࡂࡡࠢ࡝ࠩࡠࠬ࠴࠵࠮ࠬࡁࠬ࡟ࠧࡢࠧ࡞ࠩళ"),re.DOTALL).findall(content)
    if l111l11ll11lll1_fo_:
       src=l111l11ll11lll1_fo_[0]
       if src.startswith(l111l11lll1_fo_ (u"ࠩ࠲࠳ࠬఴ")):
           src = l111l11lll1_fo_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩవ")+src
    return src
