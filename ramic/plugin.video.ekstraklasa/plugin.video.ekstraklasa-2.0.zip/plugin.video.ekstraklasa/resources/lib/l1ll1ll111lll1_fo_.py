# -*- coding: utf-8 -*-
import sys
l11l1111lll1_fo_ = sys.version_info [0] == 2
l1ll1111lll1_fo_ = 2048
l11111lll1_fo_ = 7
def l111l11lll1_fo_ (ll11lll1_fo_):
	global l11lll11lll1_fo_
	l11l1l11lll1_fo_ = ord (ll11lll1_fo_ [-1])
	l11ll11lll1_fo_ = ll11lll1_fo_ [:-1]
	l1l1ll11lll1_fo_ = l11l1l11lll1_fo_ % len (l11ll11lll1_fo_)
	l1ll11lll1_fo_ = l11ll11lll1_fo_ [:l1l1ll11lll1_fo_] + l11ll11lll1_fo_ [l1l1ll11lll1_fo_:]
	if l11l1111lll1_fo_:
		l1ll1l11lll1_fo_ = unicode () .join ([unichr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	else:
		l1ll1l11lll1_fo_ = str () .join ([chr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	return eval (l1ll1l11lll1_fo_)
import urllib2,urllib,json
import re,os
from urlparse import urlparse
import base64
import cookielib
l1111ll1l11lll1_fo_= l111l11lll1_fo_ (u"ࠢࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡵࡡ࡭ࡵࡤࡶࡪࡴࡡ࠯ࡱࡵ࡫࠴ࠨಷ")
l111llll111lll1_fo_ = 10
l1111l11111lll1_fo_=l111l11lll1_fo_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣࡔ࡝࠶࠵ࠫࠣࡅࡵࡶ࡬ࡦ࡙ࡨࡦࡐ࡯ࡴ࠰࠷࠶࠻࠳࠹࠶ࠡࠪࡎࡌ࡙ࡓࡌ࠭ࠢ࡯࡭ࡰ࡫ࠠࡈࡧࡦ࡯ࡴ࠯ࠠࡄࡪࡵࡳࡲ࡫࠯࠵࠺࠱࠴࠳࠸࠵࠷࠶࠱࠽࠼ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭ಸ")
def l111ll11l11lll1_fo_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l111l11lll1_fo_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ಹ"), l1111l11111lll1_fo_)
    if cookies:
        req.add_header(l111l11lll1_fo_ (u"ࠥࡇࡴࡵ࡫ࡪࡧࠥ಺"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l111llll111lll1_fo_)
        l1l1l11111lll1_fo_ = response.read()
        response.close()
    except:
        l1l1l11111lll1_fo_=l111l11lll1_fo_ (u"ࠫࠬ಻")
    return l1l1l11111lll1_fo_
def l1l11ll111lll1_fo_(url=l111l11lll1_fo_ (u"಼ࠬ࠭"),type=l111l11lll1_fo_ (u"࠭࡬ࡢࡶࡨࡷࡹࡥࡨࡪࡩ࡫ࡰ࡮࡭ࡨࡵࡵࠪಽ"),page=l111l11lll1_fo_ (u"ࠧ࠲ࠩಾ"),**kwargs):
    if type == l111l11lll1_fo_ (u"ࠨ࡮ࡤࡸࡪࡹࡴࡠࡪ࡬࡫࡭ࡲࡩࡨࡪࡷࡷࠬಿ"):
        return l1lll1llll11lll1_fo_()
    elif type ==l111l11lll1_fo_ (u"ࠩࡰࡹࡸࡺ࡟ࡸࡣࡷࡧ࡭࠭ೀ"):
        return l1llll111111lll1_fo_()
    return [],(False,False)
def l1lll1llll11lll1_fo_():
    content = l111ll11l11lll1_fo_(l111l11lll1_fo_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡨࡱࡤࡰࡸࡧࡲࡦࡰࡤ࠲ࡴࡸࡧ࠰ࡧࡱࠫು"))
    l1lll1ll1l11lll1_fo_=re.compile(l111l11lll1_fo_ (u"ࠫࡁࡪࡩࡷࠢࡦࡰࡦࡹࡳ࠾ࠤࡪࡳࡦࡲࡶࡪࡦࡨࡳࡸࠨ࠾࠽ࡪ࠵ࡂࡁࡹࡰࡢࡰࠣࡧࡱࡧࡳࡴ࠿ࠥࡪࡱࡧࡧࡴࠢࡶࡴࡷ࡯ࡴࡦ࠯࡟ࡨ࠰ࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫೂ"),re.DOTALL).findall(content)
    out = []
    for l1llll111l11lll1_fo_ in l1lll1ll1l11lll1_fo_:
        l11111l1l11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠬࡂࡡࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠨೃ")).findall(l1llll111l11lll1_fo_)
        if l11111l1l11lll1_fo_:
            out.append({l111l11lll1_fo_ (u"࠭ࡴࡪࡶ࡯ࡩࠬೄ"):l11111l1l11lll1_fo_[0][0],l111l11lll1_fo_ (u"ࠧࡶࡴ࡯ࠫ೅"):l11111l1l11lll1_fo_[0][1]})
    return out,(False,False)
def l1llll111111lll1_fo_():
    content = l111ll11l11lll1_fo_(l111l11lll1_fo_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡢ࡮ࡶࡥࡷ࡫࡮ࡢ࠰ࡲࡶ࡬࠵ࡥ࡯ࠩೆ"))
    l1lll1ll1l11lll1_fo_=re.compile(l111l11lll1_fo_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡵࡪࡸࡱࡧࡵࡶࡦࡴ࡯ࡥࡾࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬೇ"),re.DOTALL).findall(content)
    out = []
    for l1llll111l11lll1_fo_ in l1lll1ll1l11lll1_fo_:
        l1lll1lll111lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࠫࠥࡂࡁ࡯࡭ࡨࠢࡦࡰࡦࡹࡳ࠾ࠤࡷ࡬ࡺࡳࡢࡸࡴࡤࡴࡵ࡫ࡲࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭࠭ࠧࠦࡷࡪࡦࡷ࡬ࡂࠨ࠱࠸࠲ࡳࡼࠧࠦࡨࡦ࡫ࡪ࡬ࡹࡃࠢ࠲࠴࠳ࡴࡽࠨࠠࡢ࡮ࡷࡁࠧ࠮࠮ࠫࠫࠥ࠳ࡃ࠭ೈ")).findall(l1llll111l11lll1_fo_)
        if l1lll1lll111lll1_fo_:
            out.append({l111l11lll1_fo_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ೉"):l1lll1lll111lll1_fo_[0][2].strip(),l111l11lll1_fo_ (u"ࠬ࡯࡭ࡨࠩೊ"):l1lll1lll111lll1_fo_[0][1],l111l11lll1_fo_ (u"࠭ࡵࡳ࡮ࠪೋ"):l1lll1lll111lll1_fo_[0][0]})
    return out,(False,False)
url=l111l11lll1_fo_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡵࡡ࡭ࡵࡤࡶࡪࡴࡡ࠯ࡱࡵ࡫࠴࡫࡮࠰ࡸ࡬ࡨࡪࡵ࠯ࡨࡱࡤࡰ࠲ࡩ࡯࡮ࡲ࡬ࡰࡦࡺࡩࡰࡰ࠰ࡺ࡮ࡪࡥࡰࡵ࠲࡫ࡴࡧ࡬ࡴ࠯ࡲࡪ࠲ࡹࡥࡢࡵࡲࡲ࠲࠸࠰࠲࠶࠰࠶࠵࠷࠵࠮ࡵࡲ࠱࡫ࡧࡲ࠯ࡪࡷࡱࡱ࠭ೌ")
url=l111l11lll1_fo_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡢ࡮ࡶࡥࡷ࡫࡮ࡢ࠰ࡲࡶ࡬࠵ࡥ࡯࠱ࡹ࡭ࡩ࡫࡯࠰ࡷࡨࡪࡦ࠳ࡥࡶࡴࡲࡴࡦ࠳࡬ࡦࡣࡪࡹࡪ࠵࠲࠹࠯࠳࠽࠲࠸࠰࠲࠹࠰ࡪࡨ࠳ࡡࡴࡶࡤࡲࡦ࠳ࡳ࡭ࡣࡹ࡭ࡦ࠳ࡰࡳࡣࡪࡹࡪ࠳ࡥࡶࡴࡲࡴࡦ࠳࡬ࡦࡣࡪࡹࡪ࠴ࡨࡵ࡯࡯್ࠫ")
def l111llll11lll1_fo_(url):
    content = l111ll11l11lll1_fo_(url)
    v=[]
    src = re.compile(l111l11lll1_fo_ (u"ࠩࡧࡥࡹࡧ࠭ࡤࡱࡱࡪ࡮࡭࠽ࠣࠪ࠱࠮ࡡ࠴ࡪࡴࡱࡱ࠭ࠧ࠭೎")).findall(content)
    if src:
        v={l111l11lll1_fo_ (u"ࠪࡱࡸ࡭ࠧ೏"):l111l11lll1_fo_ (u"ࠫࠬ೐"),l111l11lll1_fo_ (u"ࠬࡻࡲ࡭ࠩ೑"):src[0].replace(l111l11lll1_fo_ (u"࠭ࡰ࡭ࡣࡼࡩࡷ࠴ࡪࡴࡱࡱࠫ೒"),l111l11lll1_fo_ (u"ࠧࡻࡧࡸࡷ࠳ࡰࡳࡰࡰࠪ೓"))}
    else:
        l1llll1ll111lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠨ࠾ࡧ࡭ࡻࠦࡳࡵࡻ࡯ࡩࡂ࠴ࠪ࠽࡫ࡩࡶࡦࡳࡥࠡࠪ࠱࠮ࡄ࠯࠼࠰࡫ࡩࡶࡦࡳࡥ࠿ࠩ೔")).findall(content)
        for l1lllll1l111lll1_fo_ in l1llll1ll111lll1_fo_:
            src=re.compile(l111l11lll1_fo_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧೕ")).findall(l1lllll1l111lll1_fo_)
            if src:
                v.append({l111l11lll1_fo_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩೖ"):urlparse(src[0]).netloc,l111l11lll1_fo_ (u"ࠫࡺࡸ࡬ࠨ೗"):src[0]})
    if not v:
        v={l111l11lll1_fo_ (u"ࠬࡳࡳࡨࠩ೘"):l111l11lll1_fo_ (u"࠭ࡖࡪࡦࡨࡳࠥࡲࡩ࡯࡭ࠣࡲࡴࡺࠠࡧࡱࡸࡲࡩࠦ࡯ࡳࠢࡱࡳࡹࠦࡳࡶࡲࡳࡳࡷࡺࡥࡥࠢࡼࡩࡹ࠭೙")}
    return v
def l1l11l1l11lll1_fo_():
    out=[
        {l111l11lll1_fo_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭೚"):l111l11lll1_fo_ (u"ࠨࡎࡤࡸࡪࡹࡴࠡࡊ࡬࡫࡭ࡲࡩࡨࡪࡷࡷࠬ೛"),l111l11lll1_fo_ (u"ࠩࡸࡶࡱ࠭೜"):l111l11lll1_fo_ (u"ࠪࠫೝ"),l111l11lll1_fo_ (u"ࠫࡵࡧࡲࡢ࡯ࡶࠫೞ"):{l111l11lll1_fo_ (u"ࠬࡺࡹࡱࡧࠪ೟"):l111l11lll1_fo_ (u"࠭࡬ࡢࡶࡨࡷࡹࡥࡨࡪࡩ࡫ࡰ࡮࡭ࡨࡵࡵࠪೠ"),l111l11lll1_fo_ (u"ࠧࡱࡣࡪࡩࠬೡ"):1}},
        {l111l11lll1_fo_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧೢ"):l111l11lll1_fo_ (u"ࠩࡐࡹࡸࡺࠠࡘࡣࡷࡧ࡭࠭ೣ"),l111l11lll1_fo_ (u"ࠪࡹࡷࡲࠧ೤"):l111l11lll1_fo_ (u"ࠫࠬ೥"),l111l11lll1_fo_ (u"ࠬࡶࡡࡳࡣࡰࡷࠬ೦"):{l111l11lll1_fo_ (u"࠭ࡴࡺࡲࡨࠫ೧"):l111l11lll1_fo_ (u"ࠧ࡮ࡷࡶࡸࡤࡽࡡࡵࡥ࡫ࠫ೨"),l111l11lll1_fo_ (u"ࠨࡲࡤ࡫ࡪ࠭೩"):1}},
        ]
    return out
