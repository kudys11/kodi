# -*- coding: utf-8 -*-
import sys
l11l1111lll1_fo_ = sys.version_info [0] == 2
l1ll1111lll1_fo_ = 2048
l11111lll1_fo_ = 7
def l111l11lll1_fo_ (ll11lll1_fo_):
	global l11lll11lll1_fo_
	l11l1l11lll1_fo_ = ord (ll11lll1_fo_ [-1])
	l11ll11lll1_fo_ = ll11lll1_fo_ [:-1]
	l1l1ll11lll1_fo_ = l11l1l11lll1_fo_ % len (l11ll11lll1_fo_)
	l1ll11lll1_fo_ = l11ll11lll1_fo_ [:l1l1ll11lll1_fo_] + l11ll11lll1_fo_ [l1l1ll11lll1_fo_:]
	if l11l1111lll1_fo_:
		l1ll1l11lll1_fo_ = unicode () .join ([unichr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	else:
		l1ll1l11lll1_fo_ = str () .join ([chr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	return eval (l1ll1l11lll1_fo_)
import urllib2,urllib,json
import re,os
import urlparse
l1111ll1l11lll1_fo_= l111l11lll1_fo_ (u"ࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡲࡥࡤࡪ࠱ࡸࡻࠨം")
l111llll111lll1_fo_ = 10
l1111l11111lll1_fo_=l111l11lll1_fo_ (u"࠭ࡍࡰࡼ࡬ࡰࡱࡧ࠯࠶࠰࠳ࠤ࠭࡝ࡩ࡯ࡦࡲࡻࡸࠦࡎࡕࠢ࠴࠴࠳࠶࠻࡙ࠡࡒ࡛࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠺࠸࠯࠲࠱࠶࠺࠼࠴࠯࠻࠺ࠤࡘࡧࡦࡢࡴ࡬࠳࠺࠹࠷࠯࠵࠹ࠫഃ")
l1l1l1111lll1_fo_=25
def l111ll11l11lll1_fo_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l111l11lll1_fo_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫഄ"), l1111l11111lll1_fo_)
    if cookies:
        req.add_header(l111l11lll1_fo_ (u"ࠣࡅࡲࡳࡰ࡯ࡥࠣഅ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l111llll111lll1_fo_)
        l1l1l11111lll1_fo_ = response.read()
        response.close()
    except:
        l1l1l11111lll1_fo_=l111l11lll1_fo_ (u"ࠩࠪആ")
    return l1l1l11111lll1_fo_
def l1l11ll111lll1_fo_(url,type=l111l11lll1_fo_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬഇ"),page=1,category=7,**args):
    if type == l111l11lll1_fo_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ഈ"):
        url=l111l11lll1_fo_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡲࡥࡤࡪ࠱ࡸࡻ࠵࡬ࡦࡥ࡫ࡸࡻࡥࡡ࡫ࡣࡻ࠳࡬࡫ࡴࡠࡸ࡬ࡨࡪࡵࡳࡠࡥࡤࡸࡪ࡭࡯ࡳࡻ࠱ࡴ࡭ࡶࠧഉ")
        data=l111l11lll1_fo_ (u"࠭ࡶࡪࡦࡨࡳࡤࡹࡴࡢࡴࡷࡣࡳࡻ࡭ࡣࡧࡵࡁࠪࡪࠦࡷ࡫ࡧࡩࡴࡥࡳࡵࡱࡳࡣࡳࡻ࡭ࡣࡧࡵࡁࠪࡪࠦࡤࡣࡷࡩ࡬ࡵࡲࡺࡡ࡬ࡨࡂࠫࡤࠨഊ")%(int(page)*l1l1l1111lll1_fo_,l1l1l1111lll1_fo_,int(category))
    elif type== l111l11lll1_fo_ (u"ࠧࡱࡱࡳࡹࡱࡧࡲࠨഋ"):
        url=l111l11lll1_fo_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡮ࡨࡧ࡭࠴ࡴࡷ࠱࡯ࡩࡨ࡮ࡴࡷࡡࡤ࡮ࡦࡾ࠯ࡨࡧࡷࡣࡻ࡯ࡤࡦࡱࡶࡣࡲࡵࡳࡵࡡࡳࡳࡵࡻ࡬ࡢࡴ࠱ࡴ࡭ࡶࠧഌ")
        data=l111l11lll1_fo_ (u"ࠩࠪ഍")
    else:
        url=l111l11lll1_fo_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡰࡪࡩࡨ࠯ࡶࡹ࠳ࡱ࡫ࡣࡩࡶࡹࡣࡦࡰࡡࡹ࠱ࡪࡩࡹࡥࡶࡪࡦࡨࡳࡸࡥ࡮ࡦࡹࡨࡷࡹ࠴ࡰࡩࡲࠪഎ")
        data=l111l11lll1_fo_ (u"ࠫࡻ࡯ࡤࡦࡱࡢࡷࡹࡧࡲࡵࡡࡱࡹࡲࡨࡥࡳ࠿ࠨࡨࠫࡼࡩࡥࡧࡲࡣࡸࡺ࡯ࡱࡡࡱࡹࡲࡨࡥࡳ࠿ࠨࡨࠬഏ")%(int(page)*l1l1l1111lll1_fo_,l1l1l1111lll1_fo_)
    content = l111ll11l11lll1_fo_(url,data)
    out = l11111l1111lll1_fo_(content)
    l111l111111lll1_fo_ = {l111l11lll1_fo_ (u"ࠬࡺࡹࡱࡧࠪഐ"):type,l111l11lll1_fo_ (u"࠭ࡰࡢࡩࡨࠫ഑"):int(page)+1,l111l11lll1_fo_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩഒ"):category} if len(out) == l1l1l1111lll1_fo_ else False
    l111lllll11lll1_fo_ = {l111l11lll1_fo_ (u"ࠨࡶࡼࡴࡪ࠭ഓ"):type,l111l11lll1_fo_ (u"ࠩࡳࡥ࡬࡫ࠧഔ"):int(page)-1,l111l11lll1_fo_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬക"):category} if int(page)>0 else False
    return out,(l111lllll11lll1_fo_,l111l111111lll1_fo_)
def l11111l1111lll1_fo_(content):
    content = content.decode(l111l11lll1_fo_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬഖ"))
    ids = [(a.start(), a.end()) for a in re.finditer(l111l11lll1_fo_ (u"ࠬࡂࡴࡥࠢࡦࡰࡦࡹࡳ࠾ࠤࡹ࡭ࡩ࡫࡯ࡠ࡯ࡨࡨ࡮ࡻ࡭ࡠࡤࡲࡼࠧࡄࠧഗ"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11111lll11lll1_fo_ = content[ ids[i][1]:ids[i+1][0] ].replace(l111l11lll1_fo_ (u"࠭࡜࡝ࠩഘ"),l111l11lll1_fo_ (u"ࠧࠨങ")).encode(l111l11lll1_fo_ (u"ࠨࡷࡷࡪ࠲࠾ࠧച"))
        l111111ll11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠩ࠿࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡧ࡬ࡵ࠿ࠥ࠲࠯ࡅࠢࠨഛ")).findall(l11111lll11lll1_fo_)
        href = re.compile(l111l11lll1_fo_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧࡼࡩࡥࡧࡲ࠱࡮ࡪ࠭ࠩ࡞ࡧ࠯࠮࠳࠮ࠫࡁࠥࠫജ")).findall(l11111lll11lll1_fo_)
        title = re.compile(l111l11lll1_fo_ (u"ࠫࡁ࡯࡭ࡨࠢࡶࡶࡨࡃࠢ࠯ࠬࡂࠦࠥࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪഝ")).findall(l11111lll11lll1_fo_)
        l11111ll111lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠬࡂࡡࠡࡪࡵࡩ࡫ࡃࠢ࠯ࠬࡂࠦࠥࡩ࡬ࡢࡵࡶࡁࠧࡼࡩࡥࡧࡲࡣࡲ࡫ࡤࡪࡷࡰࡣࡩ࡫ࡳࡤࡡࡶ࡬ࡴࡸࡴࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬഞ")).findall(l11111lll11lll1_fo_)
        code = re.compile(l111l11lll1_fo_ (u"࠭࠼ࡴࡲࡤࡲࠥࡩ࡬ࡢࡵࡶࡁࠧࡼࡩࡥࡧࡲࡣࡲ࡫ࡤࡪࡷࡰࡣࡩࡧࡴࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩട")).findall(l11111lll11lll1_fo_)
        if not code:
            code = re.compile(l111l11lll1_fo_ (u"ࠧ࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠱࠮ࡄࠨࠠࡤ࡮ࡤࡷࡸࡃࠢࡷ࡫ࡧࡩࡴࡥ࡭ࡦࡦ࡬ࡹࡲࡥࡣࡢࡶࡨ࡫ࡴࡸࡹࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࠬഠ")).findall(l11111lll11lll1_fo_)
        if href and title:
            h = href[0]
            t = l11l1l111lll1_fo_(title[0].strip())
            i = urlparse.urljoin(l1111ll1l11lll1_fo_,l111111ll11lll1_fo_[0]) if l111111ll11lll1_fo_ else l111l11lll1_fo_ (u"ࠨࠩഡ")
            p = l11l1l111lll1_fo_(l11111ll111lll1_fo_[0].strip()) if l11111ll111lll1_fo_ else l111l11lll1_fo_ (u"ࠩࠪഢ")
            c = l11l1l111lll1_fo_(code[0].strip()) if code else l111l11lll1_fo_ (u"ࠪࠫണ")
            out.append({l111l11lll1_fo_ (u"ࠫࡺࡸ࡬ࠨത"):h,l111l11lll1_fo_ (u"ࠬࡺࡩࡵ࡮ࡨࠫഥ"):t,l111l11lll1_fo_ (u"࠭ࡩ࡮ࡩࠪദ"):i,l111l11lll1_fo_ (u"ࠧࡱ࡮ࡲࡸࠬധ"):p,l111l11lll1_fo_ (u"ࠨࡥࡲࡨࡪ࠭ന"):c})
    return out
def l11l1l1111lll1_fo_():
    content= l111ll11l11lll1_fo_(l1111ll1l11lll1_fo_)
    l1lll1l1l111lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠩ࠿ࡸࡦࡨ࡬ࡦࠢࡦࡰࡦࡹࡳ࠾ࠤ࡯ࡩࡦ࡭ࡵࡦࡡࡷࡥࡧࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡥࡧࡲࡥ࠿ࠩഩ"),re.DOTALL).findall(content)
    out = []
    if l1lll1l1l111lll1_fo_:
        pos = re.compile(l111l11lll1_fo_ (u"ࠪࡀࡹࡪࠠࡤ࡮ࡤࡷࡸࡃࠢ࡭ࡧࡤ࡫ࡺ࡫࡟ࡵࡣࡥࡰࡪࡥࡰࡰࡵ࡬ࡸ࡮ࡵ࡮ࠣࡀࠫ࠲࠰ࡅࠩ࠽ࠩപ")).findall(l1lll1l1l111lll1_fo_[0])
        l1lll1l11l11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠫࡁࡺࡤࠡࡥ࡯ࡥࡸࡹ࠽ࠣ࡮ࡨࡥ࡬ࡻࡥࡠࡶࡤࡦࡱ࡫࡟ࡱࡱ࡬ࡲࡹࡹࠢ࠿ࠪ࠱࠯ࡄ࠯࠼ࠨഫ")).findall(l1lll1l1l111lll1_fo_[0])
        l1lll11ll111lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠬࡂࡴࡥࠢࡦࡰࡦࡹࡳ࠾ࠤ࡯ࡩࡦ࡭ࡵࡦࡡࡷࡥࡧࡲࡥࡠࡶࡨࡥࡲࠨ࠾ࠩ࠰࠮ࡃ࠮ࡂࠧബ")).findall(l1lll1l1l111lll1_fo_[0])
        for p,l1lll11lll11lll1_fo_,name in zip(pos,l1lll1l11l11lll1_fo_,l1lll11ll111lll1_fo_):
            out.append({l111l11lll1_fo_ (u"࠭ࡴࡪࡶ࡯ࡩࠬഭ"):l111l11lll1_fo_ (u"ࠧࠦࡵࠣ࡟ࡇࡣࠥࡴ࡝࠲ࡆࡢ࠭മ")%(p,name),l111l11lll1_fo_ (u"ࠨࡥࡲࡨࡪ࠭യ"):l111l11lll1_fo_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝࡜ࡄࡠࠩࡸࡡ࠯ࡃ࡟࡞࠳ࡈࡕࡌࡐࡔࡠࠫര")%l11l1l111lll1_fo_(l1lll11lll11lll1_fo_)} )
    return out
def l111llll11lll1_fo_(id=l111l11lll1_fo_ (u"ࠪ࠶࠸࠾࠲࠸ࠩറ")):
    url=l111l11lll1_fo_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡱ࡫ࡣࡩ࠰ࡷࡺ࠴ࡲࡥࡤࡪࡷࡺࡤࡧࡪࡢࡺ࠲࡫ࡪࡺ࡟ࡱ࡮ࡤࡽࡪࡸ࡟࡯ࡧࡺ࠲ࡵ࡮ࡰࠨല")
    data=l111l11lll1_fo_ (u"ࠬ࡯ࡤ࠾ࠩള")+id+l111l11lll1_fo_ (u"࠭ࠦࡢࡦࡶࡣࡵࡧࡲࡢ࡯ࡀࠫഴ")
    content = l111ll11l11lll1_fo_(url,data)
    l1lll1l11111lll1_fo_=[]
    src = re.compile(l111l11lll1_fo_ (u"ࠧࡴࡴࡦࡁࡠࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅࠩ࡜ࠤ࡟ࠫࡢ࠭വ")).findall(content)
    if src:
        data = l111ll11l11lll1_fo_(src[0])
        l111l11ll11lll1_fo_=re.compile(l111l11lll1_fo_ (u"ࠨࡵࡵࡧࡡࡹࠪ࠾࡞ࡶ࠮ࡠࠨ࡜ࠨ࡟ࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࡠࠨ࡜ࠨ࡟ࠪശ"),re.DOTALL).findall(data)
        for l1l1l11111lll1_fo_ in l111l11ll11lll1_fo_:
            if l1l1l11111lll1_fo_.endswith(l111l11lll1_fo_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨഷ")) or l1l1l11111lll1_fo_.endswith(l111l11lll1_fo_ (u"ࠪ࠲ࡲࡶ࠴ࠨസ")):
                l1lll1l11111lll1_fo_.append({l111l11lll1_fo_ (u"ࠫࡲࡹࡧࠨഹ"):l1l1l11111lll1_fo_.split(l111l11lll1_fo_ (u"ࠬ࠴ࠧഺ"))[-1],l111l11lll1_fo_ (u"࠭ࡵࡳ࡮഻ࠪ"):l1l1l11111lll1_fo_,l111l11lll1_fo_ (u"ࠧࡳࡧࡶࡳࡱࡼࡥࡥ഼ࠩ"):True})
    if not l1lll1l11111lll1_fo_:
        l1lll1l11111lll1_fo_ = {l111l11lll1_fo_ (u"ࠨ࡯ࡶ࡫ࠬഽ"):l111l11lll1_fo_ (u"࡙ࠩ࡭ࡩ࡫࡯ࠡ࡮࡬ࡲࡰࠦ࡮ࡰࡶࠣࡪࡴࡻ࡮ࡥࠢࡲࡶࠥࡴ࡯ࡵࠢࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࠥࡿࡥࡵࠩാ")}
    return l1lll1l11111lll1_fo_
def l1l11l1l11lll1_fo_():
    out=[
        {l111l11lll1_fo_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩി"):l111l11lll1_fo_ (u"ࠫࡓࡵࡷࡦࠩീ"),l111l11lll1_fo_ (u"ࠬࡻࡲ࡭ࠩു"):l111l11lll1_fo_ (u"࠭ࠧൂ"),l111l11lll1_fo_ (u"ࠧࡱࡣࡵࡥࡲࡹࠧൃ"):{l111l11lll1_fo_ (u"ࠨࡶࡼࡴࡪ࠭ൄ"):l111l11lll1_fo_ (u"ࠩࡱࡩࡼ࡫ࡳࡵࠩ൅"),l111l11lll1_fo_ (u"ࠪࡴࡦ࡭ࡥࠨെ"):0}},
        {l111l11lll1_fo_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪേ"):l111l11lll1_fo_ (u"ࠬࡖ࡯ࡱࡷ࡯ࡥࡷࡴࡥࠨൈ"),l111l11lll1_fo_ (u"࠭ࡵࡳ࡮ࠪ൉"):l111l11lll1_fo_ (u"ࠧࠨൊ"),l111l11lll1_fo_ (u"ࠨࡲࡤࡶࡦࡳࡳࠨോ"):{l111l11lll1_fo_ (u"ࠩࡷࡽࡵ࡫ࠧൌ"):l111l11lll1_fo_ (u"ࠪࡴࡴࡶࡵ࡭ࡣࡵ്ࠫ"),l111l11lll1_fo_ (u"ࠫࡵࡧࡧࡦࠩൎ"):0}},
        {l111l11lll1_fo_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ൏"):l111l11lll1_fo_ (u"࠭ࡐࡪࡧࡵࡻࡸࢀࡡࠡࡆࡵࡹঁࡿ࡮ࡢࠩ൐"),l111l11lll1_fo_ (u"ࠧࡶࡴ࡯ࠫ൑"):l111l11lll1_fo_ (u"ࠨࠩ൒"),l111l11lll1_fo_ (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩ൓"):{l111l11lll1_fo_ (u"ࠪࡸࡾࡶࡥࠨൔ"):l111l11lll1_fo_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ൕ"),l111l11lll1_fo_ (u"ࠬࡶࡡࡨࡧࠪൖ"):l111l11lll1_fo_ (u"࠭࠰ࠨൗ"),l111l11lll1_fo_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ൘"):l111l11lll1_fo_ (u"ࠨ࠵ࠪ൙")}},
        {l111l11lll1_fo_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ൚"):l111l11lll1_fo_ (u"ࠪࡗࡰࡸࣳࡵࡻࠣࡑࡪࡩࡺࣴࡹࠪ൛"),l111l11lll1_fo_ (u"ࠫࡺࡸ࡬ࠨ൜"):l111l11lll1_fo_ (u"ࠬ࠭൝"),l111l11lll1_fo_ (u"࠭ࡰࡢࡴࡤࡱࡸ࠭൞"):{l111l11lll1_fo_ (u"ࠧࡵࡻࡳࡩࠬൟ"):l111l11lll1_fo_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪൠ"),l111l11lll1_fo_ (u"ࠩࡳࡥ࡬࡫ࠧൡ"):l111l11lll1_fo_ (u"ࠪ࠴ࠬൢ"),l111l11lll1_fo_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ൣ"):l111l11lll1_fo_ (u"ࠬ࠽ࠧ൤")}},
        {l111l11lll1_fo_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ൥"):l111l11lll1_fo_ (u"ࠧࡘࡻࡺ࡭ࡦࡪࡹࠨ൦"),l111l11lll1_fo_ (u"ࠨࡷࡵࡰࠬ൧"):l111l11lll1_fo_ (u"ࠩࠪ൨"),l111l11lll1_fo_ (u"ࠪࡴࡦࡸࡡ࡮ࡵࠪ൩"):{l111l11lll1_fo_ (u"ࠫࡹࡿࡰࡦࠩ൪"):l111l11lll1_fo_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ൫"),l111l11lll1_fo_ (u"࠭ࡰࡢࡩࡨࠫ൬"):l111l11lll1_fo_ (u"ࠧ࠱ࠩ൭"),l111l11lll1_fo_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ൮"):l111l11lll1_fo_ (u"ࠩ࠴ࠫ൯")}},
        {l111l11lll1_fo_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ൰"):l111l11lll1_fo_ (u"ࠫࡐࡵ࡮ࡧࡧࡵࡩࡳࡩࡪࡦࠢࡓࡶࡦࡹ࡯ࡸࡧࠪ൱"),l111l11lll1_fo_ (u"ࠬࡻࡲ࡭ࠩ൲"):l111l11lll1_fo_ (u"࠭ࠧ൳"),l111l11lll1_fo_ (u"ࠧࡱࡣࡵࡥࡲࡹࠧ൴"):{l111l11lll1_fo_ (u"ࠨࡶࡼࡴࡪ࠭൵"):l111l11lll1_fo_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ൶"),l111l11lll1_fo_ (u"ࠪࡴࡦ࡭ࡥࠨ൷"):l111l11lll1_fo_ (u"ࠫ࠵࠭൸"),l111l11lll1_fo_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ൹"):l111l11lll1_fo_ (u"࠭࠲ࠨൺ")}},
        {l111l11lll1_fo_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ൻ"):l111l11lll1_fo_ (u"ࠨࡔࡨࡾࡪࡸࡷࡺࠩർ"),l111l11lll1_fo_ (u"ࠩࡸࡶࡱ࠭ൽ"):l111l11lll1_fo_ (u"ࠪࠫൾ"),l111l11lll1_fo_ (u"ࠫࡵࡧࡲࡢ࡯ࡶࠫൿ"):{l111l11lll1_fo_ (u"ࠬࡺࡹࡱࡧࠪ඀"):l111l11lll1_fo_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨඁ"),l111l11lll1_fo_ (u"ࠧࡱࡣࡪࡩࠬං"):l111l11lll1_fo_ (u"ࠨ࠲ࠪඃ"),l111l11lll1_fo_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ඄"):l111l11lll1_fo_ (u"ࠪ࠸ࠬඅ")}},
        {l111l11lll1_fo_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪආ"):l111l11lll1_fo_ (u"ࠬࡇ࡫ࡢࡦࡨࡱ࡮ࡧࠧඇ"),l111l11lll1_fo_ (u"࠭ࡵࡳ࡮ࠪඈ"):l111l11lll1_fo_ (u"ࠧࠨඉ"),l111l11lll1_fo_ (u"ࠨࡲࡤࡶࡦࡳࡳࠨඊ"):{l111l11lll1_fo_ (u"ࠩࡷࡽࡵ࡫ࠧඋ"):l111l11lll1_fo_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬඌ"),l111l11lll1_fo_ (u"ࠫࡵࡧࡧࡦࠩඍ"):l111l11lll1_fo_ (u"ࠬ࠶ࠧඎ"),l111l11lll1_fo_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨඏ"):l111l11lll1_fo_ (u"ࠧ࠶ࠩඐ")}},
        {l111l11lll1_fo_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧඑ"):l111l11lll1_fo_ (u"ࠩࡒࡰࡩࡨ࡯࡫ࡧࠪඒ"),l111l11lll1_fo_ (u"ࠪࡹࡷࡲࠧඓ"):l111l11lll1_fo_ (u"ࠫࠬඔ"),l111l11lll1_fo_ (u"ࠬࡶࡡࡳࡣࡰࡷࠬඕ"):{l111l11lll1_fo_ (u"࠭ࡴࡺࡲࡨࠫඖ"):l111l11lll1_fo_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ඗"),l111l11lll1_fo_ (u"ࠨࡲࡤ࡫ࡪ࠭඘"):l111l11lll1_fo_ (u"ࠩ࠳ࠫ඙"),l111l11lll1_fo_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬක"):l111l11lll1_fo_ (u"ࠫ࠻࠭ඛ")}},
        ]
    return out
def l11l1l111lll1_fo_(l1111111111lll1_fo_):
    s=l111l11lll1_fo_ (u"ࠬࡐࡩࡏࡥ࡝ࡇࡸ࠽ࠧග")
    l1111111111lll1_fo_ = re.sub(s.decode(l111l11lll1_fo_ (u"࠭ࡢࡢࡵࡨ࠺࠹࠭ඝ")),l111l11lll1_fo_ (u"ࠧࠨඞ"),l1111111111lll1_fo_)
    l1111111111lll1_fo_ = re.sub(l111l11lll1_fo_ (u"ࠨࠨࡱࡦࡸࡶ࠻ࠨඟ"),l111l11lll1_fo_ (u"ࠩࠪච"),l1111111111lll1_fo_)
    l1111111111lll1_fo_ = re.sub(l111l11lll1_fo_ (u"ࠪࠪ࠳࠰࠻ࠨඡ"),l111l11lll1_fo_ (u"ࠫࠬජ"),l1111111111lll1_fo_)
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠬࠬ࡮ࡣࡵࡳ࠿ࠬඣ"),l111l11lll1_fo_ (u"࠭ࠧඤ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠧࠧ࡮ࡷ࠿ࡧࡸ࠯ࠧࡩࡷ࠿ࠬඥ"),l111l11lll1_fo_ (u"ࠨࠢࠪඦ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠩࠩࡲࡩࡧࡳࡩ࠽ࠪට"),l111l11lll1_fo_ (u"ࠪ࠱ࠬඨ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠫࠫࡷࡵࡰࡶ࠾ࠫඩ"),l111l11lll1_fo_ (u"ࠬࠨࠧඪ")).replace(l111l11lll1_fo_ (u"࠭ࠦࡢ࡯ࡳ࠿ࡶࡻ࡯ࡵ࠽ࠪණ"),l111l11lll1_fo_ (u"ࠧࠣࠩඬ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠨࠨࡲࡥࡨࡻࡴࡦ࠽ࠪත"),l111l11lll1_fo_ (u"ࣶࠩࠫථ")).replace(l111l11lll1_fo_ (u"ࠪࠪࡔࡧࡣࡶࡶࡨ࠿ࠬද"),l111l11lll1_fo_ (u"ࠫࣘ࠭ධ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠬࠬࡡ࡮ࡲ࠾ࡳࡦࡩࡵࡵࡧ࠾ࠫන"),l111l11lll1_fo_ (u"࠭ࣳࠨ඲")).replace(l111l11lll1_fo_ (u"ࠧࠧࡣࡰࡴࡀࡕࡡࡤࡷࡷࡩࡀ࠭ඳ"),l111l11lll1_fo_ (u"ࠨࣕࠪප"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠩࠩࡥࡲࡶ࠻ࠨඵ"),l111l11lll1_fo_ (u"ࠪࠪࠬබ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠫࡡࡻ࠰࠲࠲࠸ࠫභ"),l111l11lll1_fo_ (u"ࠬऋࠧම")).replace(l111l11lll1_fo_ (u"࠭࡜ࡶ࠲࠴࠴࠹࠭ඹ"),l111l11lll1_fo_ (u"ࠧअࠩය"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠨ࡞ࡸ࠴࠶࠶࠷ࠨර"),l111l11lll1_fo_ (u"ࠩऊࠫ඼")).replace(l111l11lll1_fo_ (u"ࠪࡠࡺ࠶࠱࠱࠸ࠪල"),l111l11lll1_fo_ (u"ࠫऋ࠭඾"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠬࡢࡵ࠱࠳࠴࠽ࠬ඿"),l111l11lll1_fo_ (u"࠭ङࠨව")).replace(l111l11lll1_fo_ (u"ࠧ࡝ࡷ࠳࠵࠶࠾ࠧශ"),l111l11lll1_fo_ (u"ࠨचࠪෂ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠩ࡟ࡹ࠵࠷࠴࠳ࠩස"),l111l11lll1_fo_ (u"ࠪॆࠬහ")).replace(l111l11lll1_fo_ (u"ࠫࡡࡻ࠰࠲࠶࠴ࠫළ"),l111l11lll1_fo_ (u"ࠬेࠧෆ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"࠭࡜ࡶ࠲࠴࠸࠹࠭෇"),l111l11lll1_fo_ (u"ࠧॅࠩ෈")).replace(l111l11lll1_fo_ (u"ࠨ࡞ࡸ࠴࠶࠺࠴ࠨ෉"),l111l11lll1_fo_ (u"ࠩॆ්ࠫ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠪࡠࡺ࠶࠰ࡧ࠵ࠪ෋"),l111l11lll1_fo_ (u"ࠫࣸ࠭෌")).replace(l111l11lll1_fo_ (u"ࠬࡢࡵ࠱࠲ࡧ࠷ࠬ෍"),l111l11lll1_fo_ (u"࣓࠭ࠨ෎"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠧ࡝ࡷ࠳࠵࠺ࡨࠧා"),l111l11lll1_fo_ (u"ࠨढ़ࠪැ")).replace(l111l11lll1_fo_ (u"ࠩ࡟ࡹ࠵࠷࠵ࡢࠩෑ"),l111l11lll1_fo_ (u"ࠪफ़ࠬි"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠫࡡࡻ࠰࠲࠹ࡤࠫී"),l111l11lll1_fo_ (u"ࠬঀࠧු")).replace(l111l11lll1_fo_ (u"࠭࡜ࡶ࠲࠴࠻࠾࠭෕"),l111l11lll1_fo_ (u"ࠧॺࠩූ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠨ࡞ࡸ࠴࠶࠽ࡣࠨ෗"),l111l11lll1_fo_ (u"ࠩॿࠫෘ")).replace(l111l11lll1_fo_ (u"ࠪࡠࡺ࠶࠱࠸ࡤࠪෙ"),l111l11lll1_fo_ (u"ࠫঀ࠭ේ"))
    return l1111111111lll1_fo_
