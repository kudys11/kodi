# -*- coding: utf-8 -*-
import sys
l11l1111lll1_fo_ = sys.version_info [0] == 2
l1ll1111lll1_fo_ = 2048
l11111lll1_fo_ = 7
def l111l11lll1_fo_ (ll11lll1_fo_):
	global l11lll11lll1_fo_
	l11l1l11lll1_fo_ = ord (ll11lll1_fo_ [-1])
	l11ll11lll1_fo_ = ll11lll1_fo_ [:-1]
	l1l1ll11lll1_fo_ = l11l1l11lll1_fo_ % len (l11ll11lll1_fo_)
	l1ll11lll1_fo_ = l11ll11lll1_fo_ [:l1l1ll11lll1_fo_] + l11ll11lll1_fo_ [l1l1ll11lll1_fo_:]
	if l11l1111lll1_fo_:
		l1ll1l11lll1_fo_ = unicode () .join ([unichr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	else:
		l1ll1l11lll1_fo_ = str () .join ([chr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	return eval (l1ll1l11lll1_fo_)
import urllib2,urllib,json
import re,os
from urlparse import urlparse
import base64
import cookielib
l1111ll1l11lll1_fo_= l111l11lll1_fo_ (u"ࠦ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡨࡲࡳࡹࡨࡡ࡭࡮ࡲࡶ࡬࡯࡮࠯ࡥࡲࡱࠧశ")
l111llll111lll1_fo_ = 10
l1111l11111lll1_fo_=l111l11lll1_fo_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘࡑ࡚࠺࠹࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠹࠾࠮࠱࠰࠵࠹࠻࠺࠮࠺࠹ࠣࡗࡦ࡬ࡡࡳ࡫࠲࠹࠸࠽࠮࠴࠸ࠪష")
def l111ll11l11lll1_fo_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l111l11lll1_fo_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪస"), l1111l11111lll1_fo_)
    if cookies:
        req.add_header(l111l11lll1_fo_ (u"ࠢࡄࡱࡲ࡯࡮࡫ࠢహ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l111llll111lll1_fo_)
        l1l1l11111lll1_fo_ = response.read()
        response.close()
    except:
        l1l1l11111lll1_fo_=l111l11lll1_fo_ (u"ࠨࠩ఺")
    return l1l1l11111lll1_fo_
def l1l11ll111lll1_fo_(url,page=l111l11lll1_fo_ (u"ࠩ࠴ࠫ఻"),**kwargs):
    if url:
        content = l111ll11l11lll1_fo_(url)
        data = False
    if not url:
        url=l111l11lll1_fo_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡧࡱࡲࡸࡧࡧ࡬࡭ࡱࡵ࡫࡮ࡴ࠮ࡤࡱࡰ࠳ࡼࡶ࠭ࡢࡦࡰ࡭ࡳ࠵ࡡࡥ࡯࡬ࡲ࠲ࡧࡪࡢࡺ࠱ࡴ࡭ࡶ఼ࠧ")
        data=l111l11lll1_fo_ (u"ࠫࡦࡩࡴࡪࡱࡱࡁ࡮ࡴࡦࡪࡰ࡬ࡸࡪࡥࡳࡤࡴࡲࡰࡱࠬࡰࡢࡩࡨࡣࡳࡵ࠽ࠦࡦࠪఽ")%int(page)
        content = l111ll11l11lll1_fo_(url,data)
    ids = [(a.start(), a.end()) for a in re.finditer(l111l11lll1_fo_ (u"ࠬࡂࡡࡳࡶ࡬ࡧࡱ࡫ࠠࡪࡦࡀࠦࡵࡵࡳࡵ࠯࡟ࡨ࠰࠭ా"), content)]
    ids.append( (-1,-1) )
    out=[]
    for i in range(len(ids[:-1])):
        l11111lll11lll1_fo_ = content[ ids[i][1]:ids[i+1][0] ]
        l111111ll11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫి")).findall(l11111lll11lll1_fo_)
        l11111l1l11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠧ࠽ࡪ࠵ࠤࡨࡲࡡࡴࡵࡀࠦࡪࡴࡴࡳࡻ࠰ࡸ࡮ࡺ࡬ࡦࠤ࠱࠮ࡄࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧీ")).findall(l11111lll11lll1_fo_)
        code = re.compile(l111l11lll1_fo_ (u"ࠨࡴࡨࡰࡂࠨࡣࡢࡶࡨ࡫ࡴࡸࡹࠡࡶࡤ࡫ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ు")).findall(l11111lll11lll1_fo_)
        if l11111l1l11lll1_fo_ and l111111ll11lll1_fo_:
            h = l11111l1l11lll1_fo_[0][0]
            t = l11111l1l11lll1_fo_[0][1].strip()
            c = code[-1] if code else l111l11lll1_fo_ (u"ࠩࠪూ")
            out.append({l111l11lll1_fo_ (u"ࠪࡹࡷࡲࠧృ"):h,l111l11lll1_fo_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪౄ"):l11l1l111lll1_fo_(t),l111l11lll1_fo_ (u"ࠬ࡯࡭ࡨࠩ౅"):l111111ll11lll1_fo_[0],l111l11lll1_fo_ (u"࠭ࡣࡰࡦࡨࠫె"):c})
    l111l111111lll1_fo_ = {l111l11lll1_fo_ (u"ࠧࡱࡣࡪࡩࠬే"):int(page)+1} if len(out)==10 and data else False
    l111lllll11lll1_fo_ = {l111l11lll1_fo_ (u"ࠨࡲࡤ࡫ࡪ࠭ై"):int(page)-1} if int(page)>1 and data else False
    return out,(l111lllll11lll1_fo_,l111l111111lll1_fo_)
def l111llll11lll1_fo_(url):
    content = l111ll11l11lll1_fo_(url)
    out=[]
    l1llll1lll11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠩ࠿ࡰ࡮ࠦࡣ࡭ࡣࡶࡷࡂࠨࡳࡶࡤࡳࡥ࡬࡫࠭࠯ࠬࡂࠦࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀ࠿࠳ࡱ࡯࠾ࠨ౉")).findall(content)
    src = re.compile(l111l11lll1_fo_ (u"ࠪࡨࡦࡺࡡ࠮ࡥࡲࡲ࡫࡯ࡧ࠾ࠤࠫ࠳࠴࠴ࠪ࡝࠰࡭ࡷࡴࡴࠩࠣࠩొ")).findall(content)
    l1llll11ll11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠫࡁࡹ࡯ࡶࡴࡦࡩࠥࡺࡹࡱࡧࡀࠦ࠳࠰ࠢࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠧో")).findall(content)
    l1llll1ll111lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠬࡂࡩࡧࡴࡤࡱࡪࠦࠨ࠯ࠬࡂ࠭ࡁ࠵ࡩࡧࡴࡤࡱࡪࡄࠧౌ")).findall(content)
    if l1llll1lll11lll1_fo_:
        for l1llll1l1l11lll1_fo_ in l1llll1lll11lll1_fo_:
            if l1llll1l1l11lll1_fo_[0] == url and src:
                pass
            else:
                l1llll11l111lll1_fo_ = l111ll11l11lll1_fo_(l1llll1l1l11lll1_fo_[0])
                src = re.compile(l111l11lll1_fo_ (u"࠭ࡤࡢࡶࡤ࠱ࡨࡵ࡮ࡧ࡫ࡪࡁࠧ࠮࠯࠰࠰࠭ࡠ࠳ࡰࡳࡰࡰ్ࠬࠦࠬ")).findall(l1llll11l111lll1_fo_)
            src = src[0] if src else l111l11lll1_fo_ (u"ࠧࠨ౎")
            out.append({l111l11lll1_fo_ (u"ࠨࡷࡵࡰࠬ౏"):src,l111l11lll1_fo_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ౐"):l1llll1l1l11lll1_fo_[1]})
            src=[]
    elif src:
        out=[{l111l11lll1_fo_ (u"ࠪࡹࡷࡲࠧ౑"):src[0],l111l11lll1_fo_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ౒"):l111l11lll1_fo_ (u"ࠬࡼࡩࡥࡧࡲࠫ౓")}]
    elif l1llll11ll11lll1_fo_:
        l1llll1l1111lll1_fo_=l1llll11ll11lll1_fo_[0].split(l111l11lll1_fo_ (u"࠭࠿ࡥࡱࡺࡲࡱࡵࡡࡥࠩ౔"))[0]
        out=[{l111l11lll1_fo_ (u"ࠧࡶࡴ࡯ౕࠫ"):l1llll1l1111lll1_fo_,l111l11lll1_fo_ (u"ࠨࡶ࡬ࡸࡱ࡫ౖࠧ"):l111l11lll1_fo_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ౗"),l111l11lll1_fo_ (u"ࠪࡶࡪࡹ࡯࡭ࡸࡨࡨࠬౘ"):True}]
    elif l1llll1ll111lll1_fo_:
        src = re.findall(l111l11lll1_fo_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩౙ"),l1llll1ll111lll1_fo_[0])
        src = src[0] if src else l111l11lll1_fo_ (u"ࠬ࠭ౚ")
        out=[{l111l11lll1_fo_ (u"࠭ࡵࡳ࡮ࠪ౛"):src,l111l11lll1_fo_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭౜"):l111l11lll1_fo_ (u"ࠨࡸ࡬ࡨࡪࡵࠧౝ")}]
    return out
def l1l11l1l11lll1_fo_():
    out=[
        {l111l11lll1_fo_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ౞"):l111l11lll1_fo_ (u"ࠪࡊࡺࡲ࡬ࠡࡏࡤࡸࡨ࡮ࠠࡓࡧࡳࡰࡦࡿࠧ౟"),l111l11lll1_fo_ (u"ࠫࡺࡸ࡬ࠨౠ"):l111l11lll1_fo_ (u"ࠬ࠭ౡ"),l111l11lll1_fo_ (u"࠭ࡰࡢࡴࡤࡱࡸ࠭ౢ"):{l111l11lll1_fo_ (u"ࠧࡱࡣࡪࡩࠬౣ"):1}},
        {l111l11lll1_fo_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ౤"):l111l11lll1_fo_ (u"ࠩࡕࡩࡻ࡯ࡥࡸࠢࡖ࡬ࡴࡽࠧ౥"),l111l11lll1_fo_ (u"ࠪࡹࡷࡲࠧ౦"):l111l11lll1_fo_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡨࡲࡳࡹࡨࡡ࡭࡮ࡲࡶ࡬࡯࡮࠯ࡥࡲࡱ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ࡳࡧࡹ࡭ࡪࡽ࠭ࡴࡪࡲࡻ࠴࠭౧"),l111l11lll1_fo_ (u"ࠬࡶࡡࡳࡣࡰࡷࠬ౨"):{}},
        {l111l11lll1_fo_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ౩"):l111l11lll1_fo_ (u"ࠧࡑࡴࡨࡱ࡮࡫ࡲࠡࡎࡨࡥ࡬ࡻࡥࠨ౪"),l111l11lll1_fo_ (u"ࠨࡷࡵࡰࠬ౫"):l111l11lll1_fo_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡦࡰࡱࡷࡦࡦࡲ࡬ࡰࡴࡪ࡭ࡳ࠴ࡣࡰ࡯࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴ࡲࡥࡢࡩࡸࡩࡸ࠵ࡰࡳࡧࡰ࡭ࡪࡸ࠭࡭ࡧࡤ࡫ࡺ࡫࠭ࡦࡲ࡯࠳ࠬ౬"),l111l11lll1_fo_ (u"ࠪࡴࡦࡸࡡ࡮ࡵࠪ౭"):{}},
        {l111l11lll1_fo_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ౮"):l111l11lll1_fo_ (u"ࠬࡉࡨࡢ࡯ࡳ࡭ࡴࡴࡳࠡ࡮ࡨࡥ࡬ࡻࡥࠡࠪࡘࡇࡑ࠯ࠧ౯"),l111l11lll1_fo_ (u"࠭ࡵࡳ࡮ࠪ౰"):l111l11lll1_fo_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲࡫ࡵ࡯ࡵࡤࡤࡰࡱࡵࡲࡨ࡫ࡱ࠲ࡨࡵ࡭࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲ࡹ࡫ࡩ࠯ࠨ౱"),l111l11lll1_fo_ (u"ࠨࡲࡤࡶࡦࡳࡳࠨ౲"):{}},
        {l111l11lll1_fo_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ౳"):l111l11lll1_fo_ (u"ࠪࡇ࡭ࡧ࡭ࡱ࡫ࡲࡲࡸ࡮ࡩࡱࠩ౴"),l111l11lll1_fo_ (u"ࠫࡺࡸ࡬ࠨ౵"):l111l11lll1_fo_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡩࡳࡴࡺࡢࡢ࡮࡯ࡳࡷ࡭ࡩ࡯࠰ࡦࡳࡲ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࡥ࡫ࡥࡲࡶࡩࡰࡰࡶ࡬࡮ࡶ࠯ࠨ౶"),l111l11lll1_fo_ (u"࠭ࡰࡢࡴࡤࡱࡸ࠭౷"):{}},
        {l111l11lll1_fo_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭౸"):l111l11lll1_fo_ (u"ࠨࡕࡦࡳࡹࡺࡩࡴࡪࠣࡔࡷ࡫࡭ࡪࡧࡵࡷ࡭࡯ࡰࠨ౹"),l111l11lll1_fo_ (u"ࠩࡸࡶࡱ࠭౺"):l111l11lll1_fo_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡻࡼࡽ࠮ࡧࡱࡲࡸࡧࡧ࡬࡭ࡱࡵ࡫࡮ࡴ࠮ࡤࡱࡰ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵࡬ࡦࡣࡪࡹࡪࡹ࠯ࡴࡥࡲࡸࡹ࡯ࡳࡩ࠯ࡳࡶࡪࡳࡩࡦࡴࡶ࡬࡮ࡶ࠯ࠨ౻"),l111l11lll1_fo_ (u"ࠫࡵࡧࡲࡢ࡯ࡶࠫ౼"):{}},
        {l111l11lll1_fo_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ౽"):l111l11lll1_fo_ (u"࠭ࡂࡶࡰࡧࡩࡸࡲࡩࡨࡣࠪ౾"),l111l11lll1_fo_ (u"ࠧࡶࡴ࡯ࠫ౿"):l111l11lll1_fo_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳࡬࡯ࡰࡶࡥࡥࡱࡲ࡯ࡳࡩ࡬ࡲ࠳ࡩ࡯࡮࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳ࡧࡻ࡮ࡥࡧࡶࡰ࡮࡭ࡡ࠰ࠩಀ"),l111l11lll1_fo_ (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩಁ"):{}},
        {l111l11lll1_fo_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩಂ"):l111l11lll1_fo_ (u"ࠫࡑࡧࠠ࡭࡫ࡪࡥࠬಃ"),l111l11lll1_fo_ (u"ࠬࡻࡲ࡭ࠩ಄"):l111l11lll1_fo_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡪࡴࡵࡴࡣࡣ࡯ࡰࡴࡸࡧࡪࡰ࠱ࡧࡴࡳ࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱࡯ࡩࡦ࡭ࡵࡦࡵ࠲ࡰࡦ࠳࡬ࡪࡩࡤ࠳ࠬಅ"),l111l11lll1_fo_ (u"ࠧࡱࡣࡵࡥࡲࡹࠧಆ"):{}},
        {l111l11lll1_fo_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧಇ"):l111l11lll1_fo_ (u"ࠩࡖࡩࡷ࡯ࡥࠡࡃࠪಈ"),l111l11lll1_fo_ (u"ࠪࡹࡷࡲࠧಉ"):l111l11lll1_fo_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡨࡲࡳࡹࡨࡡ࡭࡮ࡲࡶ࡬࡯࡮࠯ࡥࡲࡱ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯࡭ࡧࡤ࡫ࡺ࡫ࡳ࠰ࡵࡨࡶ࡮࡫࠭ࡢ࠱ࠪಊ"),l111l11lll1_fo_ (u"ࠬࡶࡡࡳࡣࡰࡷࠬಋ"):{}},
        {l111l11lll1_fo_ (u"࠭ࡴࡪࡶ࡯ࡩࠬಌ"):l111l11lll1_fo_ (u"ࠧࡕࡘࠣࡷ࡭ࡵࡷࠨ಍"),l111l11lll1_fo_ (u"ࠨࡷࡵࡰࠬಎ"):l111l11lll1_fo_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡦࡰࡱࡷࡦࡦࡲ࡬ࡰࡴࡪ࡭ࡳ࠴ࡣࡰ࡯࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴ࡺࡶ࠮ࡵ࡫ࡳࡼ࠵ࠧಏ"),l111l11lll1_fo_ (u"ࠪࡴࡦࡸࡡ࡮ࡵࠪಐ"):{}},
        ]
    return out
def l11l1l111lll1_fo_(l1111111111lll1_fo_):
    l1111111111lll1_fo_ = re.sub(l111l11lll1_fo_ (u"ࠫࠫࡡ࡞࠼࡟࠮࠿ࠬ಑"),l111l11lll1_fo_ (u"ࠬ࠭ಒ"),l1111111111lll1_fo_)
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"࠭࡜ࡶ࠲࠴࠴࠺࠭ಓ"),l111l11lll1_fo_ (u"ࠧआࠩಔ")).replace(l111l11lll1_fo_ (u"ࠨ࡞ࡸ࠴࠶࠶࠴ࠨಕ"),l111l11lll1_fo_ (u"ࠩइࠫಖ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠪࡠࡺ࠶࠱࠱࠹ࠪಗ"),l111l11lll1_fo_ (u"ࠫऌ࠭ಘ")).replace(l111l11lll1_fo_ (u"ࠬࡢࡵ࠱࠳࠳࠺ࠬಙ"),l111l11lll1_fo_ (u"࠭आࠨಚ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠧ࡝ࡷ࠳࠵࠶࠿ࠧಛ"),l111l11lll1_fo_ (u"ࠨछࠪಜ")).replace(l111l11lll1_fo_ (u"ࠩ࡟ࡹ࠵࠷࠱࠹ࠩಝ"),l111l11lll1_fo_ (u"ࠪजࠬಞ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠫࡡࡻ࠰࠲࠶࠵ࠫಟ"),l111l11lll1_fo_ (u"ࠬैࠧಠ")).replace(l111l11lll1_fo_ (u"࠭࡜ࡶ࠲࠴࠸࠶࠭ಡ"),l111l11lll1_fo_ (u"ࠧूࠩಢ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠨ࡞ࡸ࠴࠶࠺࠴ࠨಣ"),l111l11lll1_fo_ (u"ࠩेࠫತ")).replace(l111l11lll1_fo_ (u"ࠪࡠࡺ࠶࠱࠵࠶ࠪಥ"),l111l11lll1_fo_ (u"ࠫै࠭ದ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠬࡢࡵ࠱࠲ࡩ࠷ࠬಧ"),l111l11lll1_fo_ (u"࠭ࣳࠨನ")).replace(l111l11lll1_fo_ (u"ࠧ࡝ࡷ࠳࠴ࡩ࠹ࠧ಩"),l111l11lll1_fo_ (u"ࠨࣕࠪಪ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠩ࡟ࡹ࠵࠷࠵ࡣࠩಫ"),l111l11lll1_fo_ (u"ࠪय़ࠬಬ")).replace(l111l11lll1_fo_ (u"ࠫࡡࡻ࠰࠲࠷ࡤࠫಭ"),l111l11lll1_fo_ (u"ࠬॠࠧಮ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"࠭࡜ࡶ࠲࠴࠻ࡦ࠭ಯ"),l111l11lll1_fo_ (u"ࠧॻࠩರ")).replace(l111l11lll1_fo_ (u"ࠨ࡞ࡸ࠴࠶࠽࠹ࠨಱ"),l111l11lll1_fo_ (u"ࠩॼࠫಲ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠪࡠࡺ࠶࠱࠸ࡥࠪಳ"),l111l11lll1_fo_ (u"ࠫঁ࠭಴")).replace(l111l11lll1_fo_ (u"ࠬࡢࡵ࠱࠳࠺ࡦࠬವ"),l111l11lll1_fo_ (u"࠭ॻࠨಶ"))
    return l1111111111lll1_fo_
