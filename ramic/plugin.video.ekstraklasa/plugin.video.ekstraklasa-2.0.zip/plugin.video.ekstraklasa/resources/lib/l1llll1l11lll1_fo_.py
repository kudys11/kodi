# -*- coding: utf-8 -*-
import sys
l11l1111lll1_fo_ = sys.version_info [0] == 2
l1ll1111lll1_fo_ = 2048
l11111lll1_fo_ = 7
def l111l11lll1_fo_ (ll11lll1_fo_):
	global l11lll11lll1_fo_
	l11l1l11lll1_fo_ = ord (ll11lll1_fo_ [-1])
	l11ll11lll1_fo_ = ll11lll1_fo_ [:-1]
	l1l1ll11lll1_fo_ = l11l1l11lll1_fo_ % len (l11ll11lll1_fo_)
	l1ll11lll1_fo_ = l11ll11lll1_fo_ [:l1l1ll11lll1_fo_] + l11ll11lll1_fo_ [l1l1ll11lll1_fo_:]
	if l11l1111lll1_fo_:
		l1ll1l11lll1_fo_ = unicode () .join ([unichr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	else:
		l1ll1l11lll1_fo_ = str () .join ([chr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	return eval (l1ll1l11lll1_fo_)
import urllib2,urllib,json
import re,os
from urlparse import urlparse
import base64
import cookielib
l1111ll1l11lll1_fo_= l111l11lll1_fo_ (u"ࠤ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡱࡪࡩࡺࡳࡧࡳࡰࡦࡿ࠮ࡸࡱࡵࡨࡵࡸࡥࡴࡵ࠱ࡧࡴࡳ࠯ࠣข")
l111llll111lll1_fo_ = 20
l1111l11111lll1_fo_=l111l11lll1_fo_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࡝ࡏࡘ࠸࠷࠭ࠥࡇࡰࡱ࡮ࡨ࡛ࡪࡨࡋࡪࡶ࠲࠹࠸࠽࠮࠴࠸ࠣࠬࡐࡎࡔࡎࡎ࠯ࠤࡱ࡯࡫ࡦࠢࡊࡩࡨࡱ࡯ࠪࠢࡆ࡬ࡷࡵ࡭ࡦ࠱࠷࠼࠳࠶࠮࠳࠷࠹࠸࠳࠿࠷ࠡࡕࡤࡪࡦࡸࡩ࠰࠷࠶࠻࠳࠹࠶ࠨฃ")
def l111ll11l11lll1_fo_(url,data=None,cookies=None):
    req = urllib2.Request(url,data)
    req.add_header(l111l11lll1_fo_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨค"), l1111l11111lll1_fo_)
    if cookies:
        req.add_header(l111l11lll1_fo_ (u"ࠧࡉ࡯ࡰ࡭࡬ࡩࠧฅ"), cookies)
    try:
        response = urllib2.urlopen(req,timeout=l111llll111lll1_fo_)
        l1l1l11111lll1_fo_ = response.read()
        response.close()
    except:
        l1l1l11111lll1_fo_=l111l11lll1_fo_ (u"࠭ࠧฆ")
    return l1l1l11111lll1_fo_
def l1l11l1l11lll1_fo_(url=l111l11lll1_fo_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡯ࡨࡧࡿࡸࡥࡱ࡮ࡤࡽ࠳ࡽ࡯ࡳࡦࡳࡶࡪࡹࡳ࠯ࡥࡲࡱ࠴࠭ง")):
    content = l111ll11l11lll1_fo_(url)
    l1lllll1ll11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠨ࠾࡯࡭ࠥࡩ࡬ࡢࡵࡶࡁࠧࡩࡡࡵ࠯࡬ࡸࡪࡳࠠࡤࡣࡷ࠱࡮ࡺࡥ࡮࠯࡟ࡨ࠰ࠨ࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡲ࡫ࡣࡻࡴࡨࡴࡱࡧࡹ࠯ࡹࡲࡶࡩࡶࡲࡦࡵࡶ࠲ࡨࡵ࡭࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲࠲࠯ࡅࠩࠣࠢࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭จ"),re.DOTALL).findall(content)
    out=[]
    for l1lll11l1111lll1_fo_ in l1lllll1ll11lll1_fo_:
        out.append({l111l11lll1_fo_ (u"ࠩࡸࡶࡱ࠭ฉ"):l1lll11l1111lll1_fo_[0],l111l11lll1_fo_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩช"):l1lll11l1111lll1_fo_[1]})
    if out:
        out.insert(0,{l111l11lll1_fo_ (u"ࠫࡺࡸ࡬ࠨซ"):l111l11lll1_fo_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡭ࡦࡥࡽࡶࡪࡶ࡬ࡢࡻ࠱ࡻࡴࡸࡤࡱࡴࡨࡷࡸ࠴ࡣࡰ࡯࠲ࠫฌ"),l111l11lll1_fo_ (u"࠭ࡴࡪࡶ࡯ࡩࠬญ"):l111l11lll1_fo_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࡕࡳࡵࡣࡷࡲ࡮ࡵ࡮ࠡࡦࡲࡨࡦࡴࡥ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩฎ")})
    return out
def l1l11ll111lll1_fo_(url,**kwargs):
    content = l111ll11l11lll1_fo_(url)
    l1lll1ll1111lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠨ࠾ࡤࡶࡹ࡯ࡣ࡭ࡧࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡶࡹ࡯ࡣ࡭ࡧࡁࠫฏ"),re.DOTALL).findall(content)
    out=[]
    l111l111111lll1_fo_=False
    l111lllll11lll1_fo_=False
    for l1lll1l1ll11lll1_fo_ in l1lll1ll1111lll1_fo_:
        l11111l1l11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲࡶ࠾࠴࠵࡭ࡦࡥࡽࡶࡪࡶ࡬ࡢࡻ࠱ࡻࡴࡸࡤࡱࡴࡨࡷࡸ࠴ࡣࡰ࡯࠲࠲࠯ࡅࠩࠣࠢࡵࡩࡱࡃࠢࡣࡱࡲ࡯ࡲࡧࡲ࡬ࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭ฐ"),).findall(l1lll1l1ll11lll1_fo_)
        l111111ll11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠪࡨࡦࡺࡡ࠮࡯ࡨࡨ࡮ࡻ࡭࠮ࡨ࡬ࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧฑ")).findall(l1lll1l1ll11lll1_fo_)
        if l11111l1l11lll1_fo_:
            h = l11111l1l11lll1_fo_[0][0]
            t = l11111l1l11lll1_fo_[0][1].strip()
            l111111ll11lll1_fo_ = l111111ll11lll1_fo_[0] if l111111ll11lll1_fo_ else l111l11lll1_fo_ (u"ࠫࠬฒ")
            out.append({l111l11lll1_fo_ (u"ࠬࡻࡲ࡭ࠩณ"):h,l111l11lll1_fo_ (u"࠭ࡴࡪࡶ࡯ࡩࠬด"):l11l1l111lll1_fo_(t),l111l11lll1_fo_ (u"ࠧࡪ࡯ࡪࠫต"):l111111ll11lll1_fo_})
    if out and len(out)>6:
        page = re.findall(l111l11lll1_fo_ (u"ࠨ࠱ࡳࡥ࡬࡫࠯ࠩ࡞ࡧ࠯࠮࠭ถ"),url)
        l111l111111lll1_fo_ = re.sub(l111l11lll1_fo_ (u"ࠩ࠲ࡴࡦ࡭ࡥ࠰ࠧࡶࠫท")%page[0],l111l11lll1_fo_ (u"ࠪ࠳ࡵࡧࡧࡦ࠱ࠨࡨࠬธ")%(int(page[0])+1),url) if page else url+l111l11lll1_fo_ (u"ࠫࡵࡧࡧࡦ࠱࠵ࠫน")
        if l111l111111lll1_fo_:
            l111l111111lll1_fo_ = {l111l11lll1_fo_ (u"ࠬࡻࡲ࡭ࡲࠪบ"):l111l111111lll1_fo_}
        l111lllll11lll1_fo_ = re.sub(l111l11lll1_fo_ (u"࠭࠯ࡱࡣࡪࡩ࠴ࠫࡳࠨป")%page[0],l111l11lll1_fo_ (u"ࠧ࠰ࡲࡤ࡫ࡪ࠵ࠥࡥࠩผ")%(int(page[0])-1),url) if page else False
        if l111lllll11lll1_fo_:
            l111lllll11lll1_fo_ = {l111l11lll1_fo_ (u"ࠨࡷࡵࡰࡵ࠭ฝ"):l111lllll11lll1_fo_}
    return (out,(l111lllll11lll1_fo_,l111l111111lll1_fo_))
def l111llll11lll1_fo_(url):
    content = l111ll11l11lll1_fo_(url)
    v=[]
    l11111lll11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠩ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡱࡱࡶࡸ࠲ࡩ࡯࡯ࡶࡨࡲࡹࠨ࠾ࠩ࠰࠭ࡃ࠮ࡪࡩࡷࠩพ"),re.DOTALL).findall(content)
    l111ll1ll11lll1_fo_ = re.compile(l111l11lll1_fo_ (u"ࠪࠬࡠࡤ࠾࡞ࠬࠬࡀࡦࠦࡣ࡭ࡣࡶࡷࡂࠨࡰࡰࡵࡷࡰ࡮ࡴ࡫ࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࠥࡸࡥ࡭࠿ࠥࡲࡴ࡬࡯࡭࡮ࡲࡻࠧࡄࠧฟ")).findall(content)
    for l1l1l11111lll1_fo_ in l111ll1ll11lll1_fo_:
        t = l1l1l11111lll1_fo_[0].strip()
        v.append({l111l11lll1_fo_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪภ"):l11l1l111lll1_fo_(t),l111l11lll1_fo_ (u"ࠬࡻࡲ࡭ࠩม"):l1l1l11111lll1_fo_[1].strip()})
    if not v and l11111lll11lll1_fo_:
        l1lll111l111lll1_fo_ = re.findall(l111l11lll1_fo_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬย"),l11111lll11lll1_fo_[0])
        l1lll1111111lll1_fo_ =  re.findall(l111l11lll1_fo_ (u"ࠧ࠿࡝࡟ࡲࡡࡹ࡝ࠫࠪ࠱࠮ࡄ࠯࠼ࡢࠩร"),l11111lll11lll1_fo_[0])
        if len(l1lll1111111lll1_fo_)==len(l1lll111l111lll1_fo_):
            for t,h in zip(l1lll1111111lll1_fo_,l1lll111l111lll1_fo_):
                v.append({l111l11lll1_fo_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧฤ"):l11l1l111lll1_fo_(t.strip().replace(l111l11lll1_fo_ (u"ࠩ࠽ࠫล"),l111l11lll1_fo_ (u"ࠪࠫฦ"))),l111l11lll1_fo_ (u"ࠫࡺࡸ࡬ࠨว"):h.strip()})
        else:
            for i,h in enumerate(l1lll111l111lll1_fo_):
                v.append({l111l11lll1_fo_ (u"ࠬࡺࡩࡵ࡮ࡨࠫศ"):l111l11lll1_fo_ (u"࠭ࡌࡪࡰ࡮ࠤࠪࡪࠧษ")%(i+1),l111l11lll1_fo_ (u"ࠧࡶࡴ࡯ࠫส"):h.strip()})
    if not v:
        v={l111l11lll1_fo_ (u"ࠨ࡯ࡶ࡫ࠬห"):l111l11lll1_fo_ (u"࡙ࠩ࡭ࡩ࡫࡯ࠡ࡮࡬ࡲࡰࠦ࡮ࡰࡶࠣࡪࡴࡻ࡮ࡥࠢࡲࡶࠥࡴ࡯ࡵࠢࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࠥࡿࡥࡵࠩฬ")}
    return v
def l11l1l111lll1_fo_(l1111111111lll1_fo_):
    if type(l1111111111lll1_fo_) is not str:
        l1111111111lll1_fo_=l1111111111lll1_fo_.encode(l111l11lll1_fo_ (u"ࠪࡹࡹ࡬࠭࠹ࠩอ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠫࠬ࠭ࠦ࡯ࡤࡶࡴࡀ࠭ࠧࠨฮ"),l111l11lll1_fo_ (u"ࠬ࠭ฯ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"࠭ࠧࠨࠨࡴࡹࡴࡺ࠻ࠨࠩࠪะ"),l111l11lll1_fo_ (u"ࠧࠣࠩั"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠨࠩࠪࠪࡧࡪࡱࡶࡱ࠾ࠫࠬ࠭า"),l111l11lll1_fo_ (u"ࠩ࡟ࠫࠬำ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠪࠫࠬࠬࡲࡥࡳࡸࡳࡀ࠭ࠧࠨิ"),l111l11lll1_fo_ (u"ࠫࡡ࠭ࠧี"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠬ࠭ࠧࠧࡱࡤࡧࡺࡺࡥ࠼ࠩࠪࠫึ"),l111l11lll1_fo_ (u"࠭ࣳࠨื")).replace(l111l11lll1_fo_ (u"ࠧࠨࠩࠩࡓࡦࡩࡵࡵࡧ࠾ุࠫࠬ࠭"),l111l11lll1_fo_ (u"ࠨูࣕࠪ"))
    l1lll111ll11lll1_fo_=l111l11lll1_fo_ (u"ࠩ࠵࠺࠷࠹࠵ࡤ࠸࠷࠶ࡧ࠹ࡢࠨฺ")
    l1lll1111l11lll1_fo_=l111l11lll1_fo_ (u"ࠪ࠶࠻࠻ࡢ࠶ࡧ࠶ࡦ࠺ࡪ࠳ࡣࠩ฻")
    l1111111111lll1_fo_ = re.sub(l1lll111ll11lll1_fo_.decode(l111l11lll1_fo_ (u"ࠫ࡭࡫ࡸࠨ฼")),l111l11lll1_fo_ (u"ࠬ࠭฽"),l1111111111lll1_fo_)
    l1111111111lll1_fo_ = re.sub(l1lll1111l11lll1_fo_.decode(l111l11lll1_fo_ (u"࠭ࡨࡦࡺࠪ฾")),l111l11lll1_fo_ (u"ࠧࠨ฿"),l1111111111lll1_fo_)
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠨࠩࠪࠪࡦࡳࡰ࠼ࠩࠪࠫเ"),l111l11lll1_fo_ (u"ࠩࠩࠫแ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠪࡠࡺ࠶࠱࠱࠷ࠪโ"),l111l11lll1_fo_ (u"ࠫऊ࠭ใ")).replace(l111l11lll1_fo_ (u"ࠬࡢࡵ࠱࠳࠳࠸ࠬไ"),l111l11lll1_fo_ (u"࠭ऄࠨๅ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠧ࡝ࡷ࠳࠵࠵࠽ࠧๆ"),l111l11lll1_fo_ (u"ࠨउࠪ็")).replace(l111l11lll1_fo_ (u"ࠩ࡟ࡹ࠵࠷࠰࠷่ࠩ"),l111l11lll1_fo_ (u"ࠪऊ้ࠬ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠫࡡࡻ࠰࠲࠳࠼๊ࠫ"),l111l11lll1_fo_ (u"ࠬट๋ࠧ")).replace(l111l11lll1_fo_ (u"࠭࡜ࡶ࠲࠴࠵࠽࠭์"),l111l11lll1_fo_ (u"ࠧङࠩํ"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠨ࡞ࡸ࠴࠶࠺࠲ࠨ๎"),l111l11lll1_fo_ (u"ࠩॅࠫ๏")).replace(l111l11lll1_fo_ (u"ࠪࡠࡺ࠶࠱࠵࠳ࠪ๐"),l111l11lll1_fo_ (u"ࠫॆ࠭๑"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠬࡢࡵ࠱࠳࠷࠸ࠬ๒"),l111l11lll1_fo_ (u"࠭ॄࠨ๓")).replace(l111l11lll1_fo_ (u"ࠧ࡝ࡷ࠳࠵࠹࠺ࠧ๔"),l111l11lll1_fo_ (u"ࠨॅࠪ๕"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠩ࡟ࡹ࠵࠶ࡦ࠴ࠩ๖"),l111l11lll1_fo_ (u"ࠪࣷࠬ๗")).replace(l111l11lll1_fo_ (u"ࠫࡡࡻ࠰࠱ࡦ࠶ࠫ๘"),l111l11lll1_fo_ (u"ࠬࣙࠧ๙"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"࠭࡜ࡶ࠲࠴࠹ࡧ࠭๚"),l111l11lll1_fo_ (u"ࠧड़ࠩ๛")).replace(l111l11lll1_fo_ (u"ࠨ࡞ࡸ࠴࠶࠻ࡡࠨ๜"),l111l11lll1_fo_ (u"ࠩढ़ࠫ๝"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠪࡠࡺ࠶࠱࠸ࡣࠪ๞"),l111l11lll1_fo_ (u"ࠫॿ࠭๟")).replace(l111l11lll1_fo_ (u"ࠬࡢࡵ࠱࠳࠺࠽ࠬ๠"),l111l11lll1_fo_ (u"࠭ॹࠨ๡"))
    l1111111111lll1_fo_ = l1111111111lll1_fo_.replace(l111l11lll1_fo_ (u"ࠧ࡝ࡷ࠳࠵࠼ࡩࠧ๢"),l111l11lll1_fo_ (u"ࠨॾࠪ๣")).replace(l111l11lll1_fo_ (u"ࠩ࡟ࡹ࠵࠷࠷ࡣࠩ๤"),l111l11lll1_fo_ (u"ࠪॿࠬ๥"))
    return l1111111111lll1_fo_
