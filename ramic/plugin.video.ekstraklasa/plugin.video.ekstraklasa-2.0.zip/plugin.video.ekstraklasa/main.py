# -*- coding: utf-8 -*-
import sys
l11l1111lll1_fo_ = sys.version_info [0] == 2
l1ll1111lll1_fo_ = 2048
l11111lll1_fo_ = 7
def l111l11lll1_fo_ (ll11lll1_fo_):
	global l11lll11lll1_fo_
	l11l1l11lll1_fo_ = ord (ll11lll1_fo_ [-1])
	l11ll11lll1_fo_ = ll11lll1_fo_ [:-1]
	l1l1ll11lll1_fo_ = l11l1l11lll1_fo_ % len (l11ll11lll1_fo_)
	l1ll11lll1_fo_ = l11ll11lll1_fo_ [:l1l1ll11lll1_fo_] + l11ll11lll1_fo_ [l1l1ll11lll1_fo_:]
	if l11l1111lll1_fo_:
		l1ll1l11lll1_fo_ = unicode () .join ([unichr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	else:
		l1ll1l11lll1_fo_ = str () .join ([chr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	return eval (l1ll1l11lll1_fo_)
import sys,re,os
import urllib,urllib2
import urlparse
import xbmc,xbmcgui,xbmcaddon
import xbmcplugin
import urlresolver
import check
import time
import resources.lib.l1l1ll1l11lll1_fo_ as l1l1ll1l11lll1_fo_
import resources.lib.l1l1lll111lll1_fo_ as l1l1lll111lll1_fo_
l11111l11lll1_fo_        = sys.argv[0]
l1lll111lll1_fo_    = int(sys.argv[1])
args            = urlparse.parse_qs(sys.argv[2][1:])
l1l111l11lll1_fo_        = xbmcaddon.Addon()
l1lll1l11lll1_fo_       = l1l111l11lll1_fo_.getAddonInfo(l111l11lll1_fo_ (u"࠭࡮ࡢ࡯ࡨࠫ࠺"))
PATH        = l1l111l11lll1_fo_.getAddonInfo(l111l11lll1_fo_ (u"ࠧࡱࡣࡷ࡬ࠬ࠻"))
l1ll11111lll1_fo_    = xbmc.translatePath(l1l111l11lll1_fo_.getAddonInfo(l111l11lll1_fo_ (u"ࠨࡲࡵࡳ࡫࡯࡬ࡦࠩ࠼"))).decode(l111l11lll1_fo_ (u"ࠩࡸࡸ࡫࠳࠸ࠨ࠽"))
l1llll1111lll1_fo_   = PATH+l111l11lll1_fo_ (u"ࠪ࠳ࡷ࡫ࡳࡰࡷࡵࡧࡪࡹ࠯ࠨ࠾")
sys.path.append( os.path.join( l1llll1111lll1_fo_, l111l11lll1_fo_ (u"ࠦࡱ࡯ࡢࠣ࠿") ) )
l11ll11111lll1_fo_=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸ࠳ࡶ࡮ࡨࠩࡀ")
l1l1ll1l11lll1_fo_.l1lll11l11lll1_fo_ = l111l11lll1_fo_ (u"࠭ࠧࡁ")
import ramic as l11lll111lll1_fo_
if l1l111l11lll1_fo_.getSetting(l111l11lll1_fo_ (u"ࠧࡣࡴࡤࡱࡰࡧࠧࡂ"))==l111l11lll1_fo_ (u"ࠨࡶࡵࡹࡪ࠭ࡃ"):
    l1l1ll1l11lll1_fo_.l1lll11l11lll1_fo_ = l111l11lll1_fo_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡬ࡲࡻ࡯ࡳࡪࡤ࡯ࡩࡸࡻࡲࡧ࠰ࡵࡩࡻ࡯ࡥࡸࠩࡄ")
def l1ll11ll11lll1_fo_(name, url, mode, params=1, l11l11111lll1_fo_=l111l11lll1_fo_ (u"ࠪࡈࡪ࡬ࡡࡶ࡮ࡷࡊࡴࡲࡤࡦࡴ࠱ࡴࡳ࡭ࠧࡅ"), infoLabels=False, IsPlayable=True,fanart=l11ll11111lll1_fo_,l1lll11111lll1_fo_=1):
    u = l1ll1ll11lll1_fo_({l111l11lll1_fo_ (u"ࠫࡲࡵࡤࡦࠩࡆ"): mode, l111l11lll1_fo_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࡳࡧ࡭ࡦࠩࡇ"): name, l111l11lll1_fo_ (u"࠭ࡥࡹࡡ࡯࡭ࡳࡱࠧࡈ") : url, l111l11lll1_fo_ (u"ࠧࡱࡣࡵࡥࡲࡹࠧࡉ"):params})
    l11l111lll1_fo_ = xbmcgui.ListItem(name)
    l111lll111lll1_fo_=[l111l11lll1_fo_ (u"ࠨࡶ࡫ࡹࡲࡨࠧࡊ"),l111l11lll1_fo_ (u"ࠩࡳࡳࡸࡺࡥࡳࠩࡋ"),l111l11lll1_fo_ (u"ࠪࡦࡦࡴ࡮ࡦࡴࠪࡌ"),l111l11lll1_fo_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫࡍ"),l111l11lll1_fo_ (u"ࠬࡩ࡬ࡦࡣࡵࡥࡷࡺࠧࡎ"),l111l11lll1_fo_ (u"࠭ࡣ࡭ࡧࡤࡶࡱࡵࡧࡰࠩࡏ"),l111l11lll1_fo_ (u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪࡐ"),l111l11lll1_fo_ (u"ࠨ࡫ࡦࡳࡳ࠭ࡑ")]
    l1lllll11lll1_fo_ = dict(zip(l111lll111lll1_fo_,[l11l11111lll1_fo_ for x in l111lll111lll1_fo_]))
    l1lllll11lll1_fo_[l111l11lll1_fo_ (u"ࠩ࡯ࡥࡳࡪࡳࡤࡣࡳࡩࠬࡒ")] = fanart if fanart else l1lllll11lll1_fo_[l111l11lll1_fo_ (u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭ࡓ")]
    l1lllll11lll1_fo_[l111l11lll1_fo_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫࡔ")] = fanart if fanart else l1lllll11lll1_fo_[l111l11lll1_fo_ (u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨࡕ")]
    l11l111lll1_fo_.setArt(l1lllll11lll1_fo_)
    if not infoLabels:
        infoLabels={l111l11lll1_fo_ (u"ࠨࡴࡪࡶ࡯ࡩࠧࡖ"): name}
    l11l111lll1_fo_.setInfo(type=l111l11lll1_fo_ (u"ࠢࡷ࡫ࡧࡩࡴࠨࡗ"), infoLabels=infoLabels)
    if IsPlayable:
        l11l111lll1_fo_.setProperty(l111l11lll1_fo_ (u"ࠨࡋࡶࡔࡱࡧࡹࡢࡤ࡯ࡩࠬࡘ"), l111l11lll1_fo_ (u"ࠩࡷࡶࡺ࡫࡙ࠧ"))
    l111l1l11lll1_fo_ = []
    l111l1l11lll1_fo_.append((l111l11lll1_fo_ (u"ࠪࡍࡳ࡬࡯ࡳ࡯ࡤࡧ࡯ࡧ࡚ࠧ"), l111l11lll1_fo_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡄࡧࡹ࡯࡯࡯ࠪࡌࡲ࡫ࡵࠩࠨ࡛")))
    l11l111lll1_fo_.addContextMenuItems(l111l1l11lll1_fo_, replaceItems=False)
    ok = xbmcplugin.addDirectoryItem(handle=l1lll111lll1_fo_, url=u, listitem=l11l111lll1_fo_,isFolder=False,totalItems=l1lll11111lll1_fo_)
    xbmcplugin.addSortMethod(l1lll111lll1_fo_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l111l11lll1_fo_ (u"ࠧࠫࡒ࠭ࠢࠨ࡝࠱ࠦࠥࡑࠤ࡜"))
    return ok
def l1lllll111lll1_fo_(name,ex_link=None, params=1, mode=l111l11lll1_fo_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭࡝"),iconImage=l111l11lll1_fo_ (u"ࠧࡅࡧࡩࡥࡺࡲࡴࡇࡱ࡯ࡨࡪࡸ࠮ࡱࡰࡪࠫ࡞"), infoLabels=None, fanart=l11ll11111lll1_fo_,contextmenu=None):
    url = l1ll1ll11lll1_fo_({l111l11lll1_fo_ (u"ࠨ࡯ࡲࡨࡪ࠭࡟"): mode, l111l11lll1_fo_ (u"ࠩࡩࡳࡱࡪࡥࡳࡰࡤࡱࡪ࠭ࡠ"): name, l111l11lll1_fo_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫࡡ") : ex_link, l111l11lll1_fo_ (u"ࠫࡵࡧࡲࡢ࡯ࡶࠫࡢ") : params})
    l1llllll11lll1_fo_ = xbmcgui.ListItem(name)
    if infoLabels:
        l1llllll11lll1_fo_.setInfo(type=l111l11lll1_fo_ (u"ࠧࡼࡩࡥࡧࡲࠦࡣ"), infoLabels=infoLabels)
    l111lll111lll1_fo_=[l111l11lll1_fo_ (u"࠭ࡴࡩࡷࡰࡦࠬࡤ"),l111l11lll1_fo_ (u"ࠧࡱࡱࡶࡸࡪࡸࠧࡥ"),l111l11lll1_fo_ (u"ࠨࡤࡤࡲࡳ࡫ࡲࠨࡦ"),l111l11lll1_fo_ (u"ࠩࡩࡥࡳࡧࡲࡵࠩࡧ"),l111l11lll1_fo_ (u"ࠪࡧࡱ࡫ࡡࡳࡣࡵࡸࠬࡨ"),l111l11lll1_fo_ (u"ࠫࡨࡲࡥࡢࡴ࡯ࡳ࡬ࡵࠧࡩ"),l111l11lll1_fo_ (u"ࠬࡲࡡ࡯ࡦࡶࡧࡦࡶࡥࠨࡪ"),l111l11lll1_fo_ (u"࠭ࡩࡤࡱࡱࠫ࡫")]
    l1lllll11lll1_fo_ = dict(zip(l111lll111lll1_fo_,[iconImage for x in l111lll111lll1_fo_]))
    l1lllll11lll1_fo_[l111l11lll1_fo_ (u"ࠧ࡭ࡣࡱࡨࡸࡩࡡࡱࡧࠪ࡬")] = fanart if fanart else l1lllll11lll1_fo_[l111l11lll1_fo_ (u"ࠨ࡮ࡤࡲࡩࡹࡣࡢࡲࡨࠫ࡭")]
    l1lllll11lll1_fo_[l111l11lll1_fo_ (u"ࠩࡩࡥࡳࡧࡲࡵࠩ࡮")] = fanart if fanart else l1lllll11lll1_fo_[l111l11lll1_fo_ (u"ࠪࡰࡦࡴࡤࡴࡥࡤࡴࡪ࠭࡯")]
    l1llllll11lll1_fo_.setArt(l1lllll11lll1_fo_)
    if contextmenu:
        l111l1l11lll1_fo_=contextmenu
        l1llllll11lll1_fo_.addContextMenuItems(l111l1l11lll1_fo_, replaceItems=True)
    else:
        l111l1l11lll1_fo_ = []
        l111l1l11lll1_fo_.append((l111l11lll1_fo_ (u"ࠫࡎࡴࡦࡰࡴࡰࡥࡨࡰࡡࠨࡰ"), l111l11lll1_fo_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡅࡨࡺࡩࡰࡰࠫࡍࡳ࡬࡯ࠪࠩࡱ")),)
        l1llllll11lll1_fo_.addContextMenuItems(l111l1l11lll1_fo_, replaceItems=False)
    xbmcplugin.addDirectoryItem(handle=l1lll111lll1_fo_, url=url,listitem=l1llllll11lll1_fo_, isFolder=True)
    xbmcplugin.addSortMethod(l1lll111lll1_fo_, sortMethod=xbmcplugin.SORT_METHOD_NONE, label2Mask = l111l11lll1_fo_ (u"ࠨࠥࡓ࠮ࠣࠩ࡞࠲ࠠࠦࡒࠥࡲ"))
def l111l1111lll1_fo_(l11l1ll111lll1_fo_):
    l1111l11lll1_fo_ = {}
    for k, v in l11l1ll111lll1_fo_.iteritems():
        if isinstance(v, unicode):
            v = v.encode(l111l11lll1_fo_ (u"ࠧࡶࡶࡩ࠼ࠬࡳ"))
        elif isinstance(v, str):
            v.decode(l111l11lll1_fo_ (u"ࠨࡷࡷࡪ࠽࠭ࡴ"))
        l1111l11lll1_fo_[k] = v
    return l1111l11lll1_fo_
def l1ll1ll11lll1_fo_(query):
    return l11111l11lll1_fo_ + l111l11lll1_fo_ (u"ࠩࡂࠫࡵ") + urllib.urlencode(l111l1111lll1_fo_(query))
def l1ll111111lll1_fo_(ex_link):
    l1111111lll1_fo_ = l1l1ll1l11lll1_fo_.l11lllll11lll1_fo_(ex_link)
    l1l1l1l111lll1_fo_=l111l11lll1_fo_ (u"ࠪࠫࡶ")
    if len(l1111111lll1_fo_):
        if len(l1111111lll1_fo_)>1:
            l1l11ll11lll1_fo_ = [x.get(l111l11lll1_fo_ (u"ࠫࡱࡧࡢࡦ࡮ࠪࡷ")) for x in l1111111lll1_fo_]
            s = xbmcgui.Dialog().select(l111l11lll1_fo_ (u"ࠬࡊ࡯ࡴࡶजࡴࡳ࡫ࠠ࡫ࡣ࡮ࡳॠࡩࡩࠨࡸ"),l1l11ll11lll1_fo_)
        else:
            s=0
        l1l1l1l111lll1_fo_=l1111111lll1_fo_[s].get(l111l11lll1_fo_ (u"࠭ࡵࡳ࡮ࠪࡹ")) if s>-1 else l111l11lll1_fo_ (u"ࠧࠨࡺ")
        host=l1111111lll1_fo_[s].get(l111l11lll1_fo_ (u"ࠨ࡮ࡤࡦࡪࡲࠧࡻ")) if s>-1 else l111l11lll1_fo_ (u"ࠩࠪࡼ")
    if l1l1l1l111lll1_fo_:
        xbmcplugin.setResolvedUrl(l1lll111lll1_fo_, True, xbmcgui.ListItem(path=l1l1l1l111lll1_fo_))
    else:
        xbmcplugin.setResolvedUrl(l1lll111lll1_fo_, False, xbmcgui.ListItem(path=l111l11lll1_fo_ (u"ࠪࠫࡽ")))
def l11ll1l11lll1_fo_(ex_link):
    l1l1l11111lll1_fo_ = l1l1lll111lll1_fo_.l11lllll11lll1_fo_(ex_link)
    l1l1l1l111lll1_fo_=l111l11lll1_fo_ (u"ࠫࠬࡾ")
    if l1l1l11111lll1_fo_:
        if l111l11lll1_fo_ (u"ࠬ࡫ࡸࡵࡴࡤ࡫ࡴࡧ࡬ࡴࠩࡿ") in l1l1l11111lll1_fo_:
            import resources.lib.l1l1llll11lll1_fo_ as l1l1llll11lll1_fo_
            l1l1l1l111lll1_fo_ = l1l1llll11lll1_fo_.l1l1ll111lll1_fo_(l1l1l11111lll1_fo_)
        if l111l11lll1_fo_ (u"࠭࡯࡯ࡧࡷ࠲ࡹࡼࠧࢀ") in l1l1l11111lll1_fo_:
            from resources.lib.l11lll1l11lll1_fo_ import l111llll11lll1_fo_ as l1l11l1111lll1_fo_
            src = l1l11l1111lll1_fo_(l1l1l11111lll1_fo_)
            if src:
                l1l1l1l111lll1_fo_ = src[0].get(l111l11lll1_fo_ (u"ࠧࡶࡴ࡯ࠫࢁ"),l111l11lll1_fo_ (u"ࠨࠩࢂ"))
        else:
            try:
                l1l1l1l111lll1_fo_ = urlresolver.resolve(l1l1l11111lll1_fo_)
            except Exception,e:
                l1l1l1l111lll1_fo_=l111l11lll1_fo_ (u"ࠩࠪࢃ")
                s = xbmcgui.Dialog().ok(l111l11lll1_fo_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡶࡪࡪ࡝ࡑࡴࡲࡦࡱ࡫࡭࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩࢄ"),str(e))
    if l1l1l1l111lll1_fo_:
        xbmcplugin.setResolvedUrl(l1lll111lll1_fo_, True, xbmcgui.ListItem(path=l1l1l1l111lll1_fo_))
    else:
        xbmcplugin.setResolvedUrl(l1lll111lll1_fo_, False, xbmcgui.ListItem(path=l111l11lll1_fo_ (u"ࠫࠬࢅ")))
l1l11l111lll1_fo_ = lambda x,y: ord(x)+4*y if ord(x)%2 else ord(x)
l1lll1111lll1_fo_ = lambda l11l11l11lll1_fo_: l111l11lll1_fo_ (u"ࠬ࠭ࢆ").join([chr(l1l11l111lll1_fo_(x,1) ) for x in l11l11l11lll1_fo_.encode(l111l11lll1_fo_ (u"࠭ࡢࡢࡵࡨ࠺࠹࠭ࢇ")).strip()])
l11l111l11lll1_fo_ = lambda l11l11l11lll1_fo_: l111l11lll1_fo_ (u"ࠧࠨ࢈").join([chr(l1l11l111lll1_fo_(x,-1) ) for x in l11l11l11lll1_fo_]).decode(l111l11lll1_fo_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨࢉ"))
import threading
def l1l1lll11lll1_fo_():
    l1lll1ll11lll1_fo_=0
    return False
if not os.path.exists(l111l11lll1_fo_ (u"ࠪ࠳࡭ࡵ࡭ࡦ࠱ࡲࡷࡲࡩࠧࢵ")):
    tm=time.gmtime()
    try:    l11111111lll1_fo_,l1l111l111lll1_fo_,l1111l111lll1_fo_ = l11l111l11lll1_fo_(l1l111l11lll1_fo_.getSetting(l111l11lll1_fo_ (u"ࠫࡰࡵࡤࠨࢶ"))).split(l111l11lll1_fo_ (u"ࠬࡀࠧࢷ"))
    except: l11111111lll1_fo_,l1l111l111lll1_fo_,l1111l111lll1_fo_ =  [l111l11lll1_fo_ (u"࠭࠭࠲ࠩࢸ"),l111l11lll1_fo_ (u"ࠧࠨࢹ"),l111l11lll1_fo_ (u"ࠨ࠯࠴ࠫࢺ")]
    if int(l11111111lll1_fo_) != tm.tm_hour:
        try:    l1ll111l11lll1_fo_ = re.findall(l111l11lll1_fo_ (u"ࠩࡎࡓࡉࡀࠠࠩ࠰࠭ࡃ࠮ࡢ࡮ࠨࢻ"),urllib2.urlopen(l111l11lll1_fo_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡷࡧࡷ࠯ࡩ࡬ࡸ࡭ࡻࡢࡶࡵࡨࡶࡨࡵ࡮ࡵࡧࡱࡸ࠳ࡩ࡯࡮࠱ࡵࡥࡲ࡯ࡣࡴࡲࡤ࠳ࡰࡵࡤࡪ࠱ࡰࡥࡸࡺࡥࡳ࠱ࡕࡉࡆࡊࡍࡆ࠰ࡰࡨࠬࢼ")).read())[0].strip(l111l11lll1_fo_ (u"ࠫ࠯࠭ࢽ"))
        except: l1ll111l11lll1_fo_ = l111l11lll1_fo_ (u"ࠬ࠭ࢾ")
def _1ll11l111lll1_fo_(s):
    l1l1111l11lll1_fo_={}
    if   s==l111l11lll1_fo_ (u"ࠩ࡯࡭ࡻ࡫ࡦࡰࡱࡷࡦࡦࡲ࡬ࡰ࡮ࠪࣉ"):  import l1l11lll11lll1_fo_ as l1l1111l11lll1_fo_
    elif s==l111l11lll1_fo_ (u"ࠪࡪࡴࡵࡴࡣࡣ࡯ࡰࡴࡸࡧࡪࡰࠪ࣊"):    import l1l1l11l11lll1_fo_ as l1l1111l11lll1_fo_
    elif s==l111l11lll1_fo_ (u"ࠫ࡬ࡵࡡ࡭ࡵࡤࡶࡪࡴࡡࠨ࣋"):    import l1ll1ll111lll1_fo_ as l1l1111l11lll1_fo_
    elif s==l111l11lll1_fo_ (u"ࠬࡲࡡࡤࡼࡼࡲࡦࡹࡰࡪ࡮࡮ࡥࠬ࣌"):    import l11l1l1l11lll1_fo_ as l1l1111l11lll1_fo_
    elif s==l111l11lll1_fo_ (u"࠭ࡥ࡬ࡵࡷࡶࡦࡱ࡬ࡢࡵࡤࡸࡻ࠭࣍"):    import l11lll1l11lll1_fo_ as l1l1111l11lll1_fo_
    elif s==l111l11lll1_fo_ (u"ࠧ࡮ࡧࡦࡾࡷ࡫ࡰ࡭ࡣࡼࠫ࣎"): import l1llll1l11lll1_fo_ as l1l1111l11lll1_fo_
    elif s==l111l11lll1_fo_ (u"ࠨ࡯ࡨࡧࡿࡿ࡫ࡪࡲ࡯࣏ࠫ"): import l111ll111lll1_fo_ as l1l1111l11lll1_fo_
    return l1l1111l11lll1_fo_
mode = args.get(l111l11lll1_fo_ (u"ࠩࡰࡳࡩ࡫࣐ࠧ"), None)
fname = args.get(l111l11lll1_fo_ (u"ࠪࡪࡴࡲࡤࡦࡴࡱࡥࡲ࡫࣑ࠧ"),[l111l11lll1_fo_ (u"࣒ࠫࠬ")])[0]
ex_link = args.get(l111l11lll1_fo_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࣓࠭"),[l111l11lll1_fo_ (u"࠭ࠧࣔ")])[0]
params = args.get(l111l11lll1_fo_ (u"ࠧࡱࡣࡵࡥࡲࡹࠧࣕ"),[{}])[0]
if mode is None:
    l1lllll111lll1_fo_(name=l111l11lll1_fo_ (u"ࠨࡋࡱࡪࡴࡸ࡭ࡢࡥ࡭ࡥࠬࣖ"),mode=l111l11lll1_fo_ (u"ࠩࡢ࡭ࡳ࡬࡯ࡠࠩࣗ"),ex_link=None,iconImage=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo(l111l11lll1_fo_ (u"ࠪࡴࡦࡺࡨࠨࣘ")))+l111l11lll1_fo_ (u"ࠫ࠴࡯ࡣࡰࡰ࠱ࡴࡳ࡭ࠧࣙ"),infoLabels={})
    l1lllll111lll1_fo_(name=l111l11lll1_fo_ (u"ࠧࡡࡃࡐࡎࡒࡖࠥࡲࡩࡨࡪࡷ࡫ࡷ࡫ࡥ࡯࡟ࡏ࡭ࡻ࡫࡛࠰ࡅࡒࡐࡔࡘ࡝ࠣࣚ"),ex_link=l111l11lll1_fo_ (u"࠭ࠧࣛ"),params={l111l11lll1_fo_ (u"ࠧࡶࡵࡨࡶࠬࣜ"):l111l11lll1_fo_ (u"ࠨࡇ࡮ࡷࡹࡸࡡ࡬࡮ࡤࡷࡦ࠭ࣝ"),l111l11lll1_fo_ (u"ࠩࡶࡳࡷࡺࠧࣞ"):l111l11lll1_fo_ (u"ࠪࡰ࡮ࡼࡥࠨࣟ"),l111l11lll1_fo_ (u"ࠫࡵࡧࡧࡦࠩ࣠"):l111l11lll1_fo_ (u"ࠬ࠷ࠧ࣡")}, mode=l111l11lll1_fo_ (u"࠭ࡧࡦࡶ࡙࡭ࡩ࡫࡯ࡴࠩ࣢"),iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠧ࠯࠰࠲࡭ࡨࡵ࡮࠯ࡲࡱ࡫ࣣࠬ"))
    l1lllll111lll1_fo_(name=l111l11lll1_fo_ (u"ࠣࡐࡤ࡮ࡳࡵࡷࡴࡼࡨࠦࣤ"),ex_link=l111l11lll1_fo_ (u"ࠩࡈ࡯ࡸࡺࡲࡢ࡭࡯ࡥࡸࡧࠧࣥ"),params={l111l11lll1_fo_ (u"ࠪࡹࡸ࡫ࡲࠨࣦ"):l111l11lll1_fo_ (u"ࠫࡊࡱࡳࡵࡴࡤ࡯ࡱࡧࡳࡢࠩࣧ"),l111l11lll1_fo_ (u"ࠬࡹ࡯ࡳࡶࠪࣨ"):l111l11lll1_fo_ (u"࠭ࡲࡦࡥࡨࡲࡹࣩ࠭"),l111l11lll1_fo_ (u"ࠧࡱࡣࡪࡩࠬ࣪"):l111l11lll1_fo_ (u"ࠨ࠳ࠪ࣫")}, mode=l111l11lll1_fo_ (u"ࠩࡪࡩࡹ࡜ࡩࡥࡧࡲࡷࠬ࣬"),iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠪ࠲࠳࠵ࡩࡤࡱࡱ࠲ࡵࡴࡧࠨ࣭"))
    l1lllll111lll1_fo_(name=l111l11lll1_fo_ (u"ࠦࡓࡧࡪࡱࡱࡳࡹࡱࡧࡲ࡯࡫ࡨ࡮ࡸࢀࡥ࣮ࠣ"),ex_link=l111l11lll1_fo_ (u"ࠬࡋ࡫ࡴࡶࡵࡥࡰࡲࡡࡴࡣ࣯ࠪ"),params={l111l11lll1_fo_ (u"࠭ࡵࡴࡧࡵࣰࠫ"):l111l11lll1_fo_ (u"ࠧࡆ࡭ࡶࡸࡷࡧ࡫࡭ࡣࡶࡥࣱࠬ"),l111l11lll1_fo_ (u"ࠨࡵࡲࡶࡹࣲ࠭"):l111l11lll1_fo_ (u"ࠩࡹ࡭ࡸ࡯ࡴࡦࡦࠪࣳ"),l111l11lll1_fo_ (u"ࠪࡴࡦ࡭ࡥࠨࣴ"):l111l11lll1_fo_ (u"ࠫ࠶࠭ࣵ")}, mode=l111l11lll1_fo_ (u"ࠬ࡭ࡥࡵࡘ࡬ࡨࡪࡵࡳࠨࣶ"),iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"࠭࠮࠯࠱࡬ࡧࡴࡴ࠮ࡱࡰࡪࠫࣷ"))
    l1lllll111lll1_fo_(l111l11lll1_fo_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࡋ࡫ࡴࡶࡵࡥࡰࡲࡡࡴࡣ࠱ࡸࡻࡡ࠯ࡄࡑࡏࡓࡗࡣࠧࣸ"),ex_link=l111l11lll1_fo_ (u"ࠨࣹࠩ"),params={l111l11lll1_fo_ (u"ࠩࡢࡷࡪࡸࡶࡪࡥࡨࣺࠫ"):l111l11lll1_fo_ (u"ࠪࡩࡰࡹࡴࡳࡣ࡮ࡰࡦࡹࡡࡵࡸࠪࣻ"),l111l11lll1_fo_ (u"ࠫࡤࡧࡣࡵࠩࣼ"):l111l11lll1_fo_ (u"ࠬࡳࡡࡪࡰࠪࣽ")}, mode=l111l11lll1_fo_ (u"࠭ࡳࡪࡶࡨࠫࣾ"),iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠧࡦ࡭ࡶࡸࡷࡧ࡫࡭ࡣࡶࡥࡹࡼ࠮ࡱࡰࡪࠫࣿ"))
    l1lllll111lll1_fo_(l111l11lll1_fo_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣࡓ࡬ࡴࣶࡸࡾࠦ࡭ࡦࡥࡽࣷࡼࡡ࠯ࡄࡑࡏࡓࡗࡣࠧऀ"),ex_link=l111l11lll1_fo_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡷࡹࡧࡤࡪࡱࡶ࠲ࡵࡲ࠯ࡴ࡭ࡵࡳࡹࡿ࠭࡮ࡧࡦࡾࡴࡽࠧँ"),params={}, mode=l111l11lll1_fo_ (u"ࠪࡉࡸࡺࡡࡥ࡫ࡲࡷࡤࡹ࡫ࡳࡱࡷࡽࡤࡒࡩࡨࡣࠪं"),iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠫࡪࡹࡴࡢࡦ࡬ࡳࡸ࠴ࡰ࡯ࡩࠪः"))
    l1lllll111lll1_fo_(l111l11lll1_fo_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡨ࡬ࡶࡧࡠࡊࡴࡵࡴࡣࡣ࡯ࡰࠥ࡜ࡩࡥࡧࡲ࡟࠴ࡉࡏࡍࡑࡕࡡࠬऄ"),ex_link=l111l11lll1_fo_ (u"࠭ࠧअ"),params={l111l11lll1_fo_ (u"ࠧࡠࡵࡨࡶࡻ࡯ࡣࡦࠩआ"):l111l11lll1_fo_ (u"ࠨ࡮࡬ࡺࡪ࡬࡯ࡰࡶࡥࡥࡱࡲ࡯࡭ࠩइ"),l111l11lll1_fo_ (u"ࠩࡢࡥࡨࡺࠧई"):l111l11lll1_fo_ (u"ࠪࡱࡦ࡯࡮ࠨउ")}, mode=l111l11lll1_fo_ (u"ࠫࡸ࡯ࡴࡦࠩऊ"),iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠬࡲࡩࡷࡧࡩࡳࡴࡺࡢࡢ࡮࡯ࡳࡱ࠴ࡰ࡯ࡩࠪऋ"))
    l1lllll111lll1_fo_(l111l11lll1_fo_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࡑ࡫ࡣࡩࠢࡗ࡚ࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ऌ"),ex_link=l111l11lll1_fo_ (u"ࠧࠨऍ"),params={}, mode=l111l11lll1_fo_ (u"ࠨ࡮ࡨࡧ࡭ࡺࡶࠨऎ"),iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠩ࡯ࡩࡨ࡮ࡴࡷ࠰ࡳࡲ࡬࠭ए"))
    l1lllll111lll1_fo_(l111l11lll1_fo_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡰ࡮࡭ࡨࡵࡤ࡯ࡹࡪࡣࡔࡢࡤࡨࡰࡦࠦࡅ࡬ࡵࡷࡶࡦࡱ࡬ࡢࡵࡼ࡟࠴ࡉࡏࡍࡑࡕࡡࠬऐ"),ex_link=l111l11lll1_fo_ (u"ࠫࠬऑ"),params={}, mode=l111l11lll1_fo_ (u"ࠬࡲࡥࡤࡪࡷࡺࡤࡺࡡࡣࡧ࡯ࡥࡤ࠭ऒ"),iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"࠭ࡥ࡬ࡵࡷࡶࡦࡱ࡬ࡢࡵࡤ࠲ࡵࡴࡧࠨओ"))
    l1lllll111lll1_fo_(l111l11lll1_fo_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࡌ࡯ࡰࡶࡥࡥࡱࡲࡏࡳࡩ࡬ࡲࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭औ"),ex_link=l111l11lll1_fo_ (u"ࠨࠩक"),params={l111l11lll1_fo_ (u"ࠩࡢࡷࡪࡸࡶࡪࡥࡨࠫख"):l111l11lll1_fo_ (u"ࠪࡪࡴࡵࡴࡣࡣ࡯ࡰࡴࡸࡧࡪࡰࠪग"),l111l11lll1_fo_ (u"ࠫࡤࡧࡣࡵࠩघ"):l111l11lll1_fo_ (u"ࠬࡳࡡࡪࡰࠪङ")}, mode=l111l11lll1_fo_ (u"࠭ࡳࡪࡶࡨࠫच"),iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠧࡧࡱࡲࡸࡧࡧ࡬࡭ࡱࡵ࡫࡮ࡴ࠮ࡱࡰࡪࠫछ"))
    l1lllll111lll1_fo_(l111l11lll1_fo_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣࡇࡰࡣ࡯ࡷࡆࡸࡥ࡯ࡣ࡞࠳ࡈࡕࡌࡐࡔࡠࠫज"),ex_link=l111l11lll1_fo_ (u"ࠩࠪझ"),params={l111l11lll1_fo_ (u"ࠪࡣࡸ࡫ࡲࡷ࡫ࡦࡩࠬञ"):l111l11lll1_fo_ (u"ࠫ࡬ࡵࡡ࡭ࡵࡤࡶࡪࡴࡡࠨट"),l111l11lll1_fo_ (u"ࠬࡥࡡࡤࡶࠪठ"):l111l11lll1_fo_ (u"࠭࡭ࡢ࡫ࡱࠫड")}, mode=l111l11lll1_fo_ (u"ࠧࡴ࡫ࡷࡩࠬढ"),iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠨࡩࡲࡥࡱࡹࡡࡳࡧࡱࡥ࠳ࡶ࡮ࡨࠩण"))
    l1lllll111lll1_fo_(l111l11lll1_fo_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝ࡎࡧࡦࡾࡾࡱࡩ࠯ࡲ࡯࡟࠴ࡉࡏࡍࡑࡕࡡࠬत"),ex_link=l111l11lll1_fo_ (u"ࠪࠫथ"),params={l111l11lll1_fo_ (u"ࠫࡤࡹࡥࡳࡸ࡬ࡧࡪ࠭द"):l111l11lll1_fo_ (u"ࠬࡳࡥࡤࡼࡼ࡯࡮ࡶ࡬ࠨध"),l111l11lll1_fo_ (u"࠭࡟ࡢࡥࡷࠫन"):l111l11lll1_fo_ (u"ࠧ࡮ࡣ࡬ࡲࠬऩ")}, mode=l111l11lll1_fo_ (u"ࠨࡵ࡬ࡸࡪ࠭प"),iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠩࡰࡩࡨࢀࡹ࡬࡫ࡳࡰ࠳ࡶ࡮ࡨࠩफ"))
    l1lllll111lll1_fo_(l111l11lll1_fo_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞ࡏࡨࡧࡿࠦࡒࡦࡲ࡯ࡥࡾࡡ࠯ࡄࡑࡏࡓࡗࡣࠧब"),ex_link=l111l11lll1_fo_ (u"ࠫࠬभ"),params={l111l11lll1_fo_ (u"ࠬࡥࡳࡦࡴࡹ࡭ࡨ࡫ࠧम"):l111l11lll1_fo_ (u"࠭࡭ࡦࡥࡽࡶࡪࡶ࡬ࡢࡻࠪय"),l111l11lll1_fo_ (u"ࠧࡠࡣࡦࡸࠬर"):l111l11lll1_fo_ (u"ࠨ࡯ࡤ࡭ࡳ࠭ऱ")}, mode=l111l11lll1_fo_ (u"ࠩࡶ࡭ࡹ࡫ࠧल"),iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠪࡱࡪࡩࡺࡳࡧࡳࡰࡦࡿ࠮ࡱࡰࡪࠫळ"))
    l1lllll111lll1_fo_(l111l11lll1_fo_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟ࡓࡳࡱࡹࡡࡵࡕࡳࡳࡷࡺ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨऴ"),ex_link=l111l11lll1_fo_ (u"ࠬ࠭व"),params={}, mode=l111l11lll1_fo_ (u"࠭ࡰࡰ࡮ࡶࡥࡹࡹࡰࡰࡴࡷࠫश"),iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠧࡱࡱ࡯ࡷࡦࡺࡳࡱࡱࡵࡸ࠳ࡶ࡮ࡨࠩष"))
    l1lllll111lll1_fo_(l111l11lll1_fo_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣुआࡥࡽࡽࠥࡴࡡࡴࠢࡳ࡭ेࡱࡡ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩस"),ex_link=l111l11lll1_fo_ (u"ࠩࠪह"),params={l111l11lll1_fo_ (u"ࠪࡣࡸ࡫ࡲࡷ࡫ࡦࡩࠬऺ"):l111l11lll1_fo_ (u"ࠫࡱࡧࡣࡻࡻࡱࡥࡸࡶࡩ࡭࡭ࡤࠫऻ"),l111l11lll1_fo_ (u"ࠬࡥࡡࡤࡶ़ࠪ"):l111l11lll1_fo_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧऽ")}, mode=l111l11lll1_fo_ (u"ࠧࡴ࡫ࡷࡩࠬा"),iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠨ࡮ࡤࡧࡿࡿ࡮ࡢࡵࡳ࡭ࡱࡱࡡ࠯ࡲࡱ࡫ࠬि"))
    l1ll11ll11lll1_fo_(l111l11lll1_fo_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡪࡳࡱࡪ࡝࠮࠿ࡒࡴࡨࡰࡥ࠾࠯࡞࠳ࡈࡕࡌࡐࡔࡠࠫी"),l111l11lll1_fo_ (u"ࠪࠫु"),l111l11lll1_fo_ (u"ࠫࡔࡶࡣ࡫ࡧࠪू"),IsPlayable=False)
    check.run()
elif mode[0].startswith(l111l11lll1_fo_ (u"ࠬࡥࡩ࡯ࡨࡲࡣࠬृ")):l11lll111lll1_fo_.__myinfo__.go(sys.argv)
elif mode[0] ==l111l11lll1_fo_ (u"࠭ࡳࡪࡶࡨࠫॄ"):
    params = eval(params)
    l111lll11lll1_fo_ = params.get(l111l11lll1_fo_ (u"ࠧࡠࡵࡨࡶࡻ࡯ࡣࡦࠩॅ"))
    l11ll1l111lll1_fo_ = params.get(l111l11lll1_fo_ (u"ࠨࡡࡤࡧࡹ࠭ॆ"))
    l1l1111l11lll1_fo_ = _1ll11l111lll1_fo_(l111lll11lll1_fo_)
    if l11ll1l111lll1_fo_ == l111l11lll1_fo_ (u"ࠩࡰࡥ࡮ࡴࠧे"):
        items = l1l1111l11lll1_fo_.l1l11l1l11lll1_fo_()
        for l1111lll1_fo_ in items:
            l1lll1l111lll1_fo_ = l1111lll1_fo_.get(l111l11lll1_fo_ (u"ࠪࡴࡦࡸࡡ࡮ࡵࠪै"),{})
            l1lll1l111lll1_fo_[l111l11lll1_fo_ (u"ࠫࡤࡹࡥࡳࡸ࡬ࡧࡪ࠭ॉ")]=l111lll11lll1_fo_
            l1lll1l111lll1_fo_[l111l11lll1_fo_ (u"ࠬࡥࡡࡤࡶࠪॊ")]=l111l11lll1_fo_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧो")
            l1lllll111lll1_fo_(l1111lll1_fo_.get(l111l11lll1_fo_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ौ")), ex_link=l1111lll1_fo_.get(l111l11lll1_fo_ (u"ࠨࡷࡵࡰ्ࠬ")), params=l1lll1l111lll1_fo_, mode=l111l11lll1_fo_ (u"ࠩࡶ࡭ࡹ࡫ࠧॎ"),iconImage=l1111lll1_fo_.get(l111l11lll1_fo_ (u"ࠪ࡭ࡲ࡭ࠧॏ"),l1llll1111lll1_fo_+l111lll11lll1_fo_+l111l11lll1_fo_ (u"ࠫ࠳ࡶ࡮ࡨࠩॐ")))
    elif l11ll1l111lll1_fo_ == l111l11lll1_fo_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭॑"):
        params[l111l11lll1_fo_ (u"࠭࡟ࡢࡥࡷ॒ࠫ")]=l111l11lll1_fo_ (u"ࠧࡱ࡮ࡤࡽࠬ॓")
        items,l1l1ll1111lll1_fo_ = l1l1111l11lll1_fo_.l1l11ll111lll1_fo_(ex_link,**params)
        if l1l1ll1111lll1_fo_[0]:
            l1l1ll1111lll1_fo_[0].update({l111l11lll1_fo_ (u"ࠨࡡࡶࡩࡷࡼࡩࡤࡧࠪ॔"):l111lll11lll1_fo_,l111l11lll1_fo_ (u"ࠩࡢࡥࡨࡺࠧॕ"):l111l11lll1_fo_ (u"ࠪࡴࡦ࡭ࡥࠨॖ")})
            l1ll11ll11lll1_fo_(name=l111l11lll1_fo_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡧࡲࡵࡦ࡟࠿ࡀࠥࡶ࡯ࡱࡴࡽࡩࡩࡴࡩࡢࠢࡶࡸࡷࡵ࡮ࡢࠢ࠿ࡀࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ॗ"), url=l1l1ll1111lll1_fo_[0].get(l111l11lll1_fo_ (u"ࠬࡻࡲ࡭ࡲࠪक़"),l111l11lll1_fo_ (u"࠭ࠧख़")), params=l1l1ll1111lll1_fo_[0], mode=l111l11lll1_fo_ (u"ࠧࡴ࡫ࡷࡩࠬग़"), IsPlayable=False)
        for l1111lll1_fo_ in items:
            l1ll11ll11lll1_fo_(l1111lll1_fo_.get(l111l11lll1_fo_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧज़"),l111l11lll1_fo_ (u"ࠩࠪड़")), l1111lll1_fo_[l111l11lll1_fo_ (u"ࠪࡹࡷࡲࠧढ़")], params=params, mode=l111l11lll1_fo_ (u"ࠫࡸ࡯ࡴࡦࠩफ़"), IsPlayable=True,infoLabels=l1111lll1_fo_, l11l11111lll1_fo_=l1111lll1_fo_.get(l111l11lll1_fo_ (u"ࠬ࡯࡭ࡨࠩय़")))
        if l1l1ll1111lll1_fo_[1]:
            l1l1ll1111lll1_fo_[1].update({l111l11lll1_fo_ (u"࠭࡟ࡴࡧࡵࡺ࡮ࡩࡥࠨॠ"):l111lll11lll1_fo_,l111l11lll1_fo_ (u"ࠧࡠࡣࡦࡸࠬॡ"):l111l11lll1_fo_ (u"ࠨࡲࡤ࡫ࡪ࠭ॢ")})
            l1ll11ll11lll1_fo_(name=l111l11lll1_fo_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡥࡰࡺ࡫࡝࠿ࡀࠣࡲࡦࡹࡴचࡲࡱࡥࠥࡹࡴࡳࡱࡱࡥࠥࡄ࠾࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩॣ"), url=l1l1ll1111lll1_fo_[1].get(l111l11lll1_fo_ (u"ࠪࡹࡷࡲࡰࠨ।"),l111l11lll1_fo_ (u"ࠫࠬ॥")), params=l1l1ll1111lll1_fo_[1], mode=l111l11lll1_fo_ (u"ࠬࡹࡩࡵࡧࠪ०"), IsPlayable=False)
    elif l11ll1l111lll1_fo_ == l111l11lll1_fo_ (u"࠭ࡰࡢࡩࡨࠫ१"):
        params[l111l11lll1_fo_ (u"ࠧࡠࡣࡦࡸࠬ२")]=l111l11lll1_fo_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩ३")
        url = l1ll1ll11lll1_fo_({l111l11lll1_fo_ (u"ࠩࡰࡳࡩ࡫ࠧ४"): l111l11lll1_fo_ (u"ࠪࡷ࡮ࡺࡥࠨ५"), l111l11lll1_fo_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࡲࡦࡳࡥࠨ६"): fname, l111l11lll1_fo_ (u"ࠬ࡫ࡸࡠ࡮࡬ࡲࡰ࠭७") : ex_link,l111l11lll1_fo_ (u"࠭ࡰࡢࡴࡤࡱࡸ࠭८"):params, })
        xbmc.executebuiltin(l111l11lll1_fo_ (u"࡙ࠧࡄࡐࡇ࠳ࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠩࠧࡶ࠭ࠬ९")% url)
    elif l11ll1l111lll1_fo_ ==  l111l11lll1_fo_ (u"ࠨࡲ࡯ࡥࡾ࠭॰") :
        l11l1lll11lll1_fo_ = l1l1111l11lll1_fo_.l111llll11lll1_fo_(ex_link)
        l1ll1l1l11lll1_fo_ = False
        if isinstance(l11l1lll11lll1_fo_,list):
            if len(l11l1lll11lll1_fo_)>1:
                label = [x.get(l111l11lll1_fo_ (u"ࠩࡷ࡭ࡹࡲࡥࠨॱ")) for x in l11l1lll11lll1_fo_]
                s = xbmcgui.Dialog().select(l111l11lll1_fo_ (u"࡚ࠪ࡮ࡪࡥࡰࠩॲ"),label)
                l1l1l11111lll1_fo_ = l11l1lll11lll1_fo_[s].get(l111l11lll1_fo_ (u"ࠫࡺࡸ࡬ࠨॳ")) if s>-1 else l111l11lll1_fo_ (u"ࠬ࠭ॴ")
                msg = l11l1lll11lll1_fo_[s].get(l111l11lll1_fo_ (u"࠭࡭ࡴࡩࠪॵ"),l111l11lll1_fo_ (u"ࠧࠨॶ"))
                l1ll1l1l11lll1_fo_ = l11l1lll11lll1_fo_[s].get(l111l11lll1_fo_ (u"ࠨࡴࡨࡷࡴࡲࡶࡦࡦࠪॷ"),False)
            else:
                try:
                    l1l1l11111lll1_fo_ = l11l1lll11lll1_fo_[0].get(l111l11lll1_fo_ (u"ࠩࡸࡶࡱ࠭ॸ"),)
                    msg = l11l1lll11lll1_fo_[0].get(l111l11lll1_fo_ (u"ࠪࡱࡸ࡭ࠧॹ"),l111l11lll1_fo_ (u"ࠫࠬॺ"))
                    l1ll1l1l11lll1_fo_ = l11l1lll11lll1_fo_[0].get(l111l11lll1_fo_ (u"ࠬࡸࡥࡴࡱ࡯ࡺࡪࡪࠧॻ"),False)
                except:
                    l1l1l11111lll1_fo_ = l111l11lll1_fo_ (u"࠭ࠧॼ")
                    msg = l111l11lll1_fo_ (u"ࠧࡍ࡫ࡱ࡯ࠥࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠡࡣࡷࡠࡳ࠭ॽ")+ex_link
        else:
            msg = l11l1lll11lll1_fo_.get(l111l11lll1_fo_ (u"ࠨ࡯ࡶ࡫ࠬॾ"),l111l11lll1_fo_ (u"ࠩࠪॿ"))
            l1l1l11111lll1_fo_ = l11l1lll11lll1_fo_.get(l111l11lll1_fo_ (u"ࠪࡹࡷࡲࠧঀ"),l111l11lll1_fo_ (u"ࠫࠬঁ"))
        if l1l1l11111lll1_fo_:
            if not l1ll1l1l11lll1_fo_:
                try:
                    l1l1l1l111lll1_fo_ = urlresolver.resolve(l1l1l11111lll1_fo_)
                except Exception,e:
                    l1l1l1l111lll1_fo_=l111l11lll1_fo_ (u"ࠬ࠭ং")
                    xbmcgui.Dialog().ok(l111l11lll1_fo_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡲࡦࡦࡠࡔࡷࡵࡢ࡭ࡧࡰ࡟࠴ࡉࡏࡍࡑࡕࡡࠬঃ"),str(e))
            else:
                l1l1l1l111lll1_fo_=l1l1l11111lll1_fo_
            if l1l1l1l111lll1_fo_: xbmcplugin.setResolvedUrl(l1lll111lll1_fo_, True, xbmcgui.ListItem(path=l1l1l1l111lll1_fo_))
            else: xbmcplugin.setResolvedUrl(l1lll111lll1_fo_, False, xbmcgui.ListItem(path=l111l11lll1_fo_ (u"ࠧࠨ঄")))
        else:
            xbmcgui.Dialog().ok(l111l11lll1_fo_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡴࡨࡨࡢࡖࡲࡰࡤ࡯ࡩࡲࡡ࠯ࡄࡑࡏࡓࡗࡣࠧঅ"),msg)
            xbmcplugin.setResolvedUrl(l1lll111lll1_fo_, False, xbmcgui.ListItem(path=l111l11lll1_fo_ (u"ࠩࠪআ")))
elif mode[0].startswith(l111l11lll1_fo_ (u"ࠪࡴࡴࡲࡳࡢࡶࡶࡴࡴࡸࡴࠨই")):
    import l1l111111lll1_fo_ as l1l111111lll1_fo_
    if l111l11lll1_fo_ (u"ࠫࡤࡶ࡬ࡢࡻࡢࠫঈ") in mode[0]:
        l1l1l1l111lll1_fo_ = l1l111111lll1_fo_.l111llll11lll1_fo_(ex_link)
        l1l1l1l111lll1_fo_=l1l1l1l111lll1_fo_.get(l111l11lll1_fo_ (u"ࠬࡻࡲ࡭ࠩউ"),False)
        if l1l1l1l111lll1_fo_: xbmcplugin.setResolvedUrl(l1lll111lll1_fo_, True, xbmcgui.ListItem(path=l1l1l1l111lll1_fo_))
        else: xbmcplugin.setResolvedUrl(l1lll111lll1_fo_, False, xbmcgui.ListItem(path=l111l11lll1_fo_ (u"࠭ࠧঊ")))
    elif l111l11lll1_fo_ (u"ࠧࡠࡨࡲࡰࡩ࡫ࡲࡠࠩঋ") in mode[0]:
        params = eval(params)
        items = l1l111111lll1_fo_.l1llll111lll1_fo_(**params)
        for l1111lll1_fo_ in items:
            l1lllll111lll1_fo_(l1111lll1_fo_.get(l111l11lll1_fo_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧঌ")), ex_link=l1111lll1_fo_.get(l111l11lll1_fo_ (u"ࠩࡸࡶࡱ࠭঍")), params={}, mode=l111l11lll1_fo_ (u"ࠪࡴࡴࡲࡳࡢࡶࡶࡴࡴࡸࡴࡠࡥࡲࡲࡹ࡫࡮ࡵࡡࠪ঎"),iconImage=l1111lll1_fo_.get(l111l11lll1_fo_ (u"ࠫ࡮ࡳࡧࠨএ")))
    elif l111l11lll1_fo_ (u"ࠬࡥࡣࡰࡰࡷࡩࡳࡺ࡟ࠨঐ") in mode[0]:
        items,l1l1ll1111lll1_fo_ = l1l111111lll1_fo_.l11ll1ll11lll1_fo_(ex_link)
        if l1l1ll1111lll1_fo_[0]: l1ll11ll11lll1_fo_(name=l111l11lll1_fo_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡢ࡭ࡷࡨࡡࡁࡂࠠࡱࡱࡳࡶࡿ࡫ࡤ࡯࡫ࡤࠤࡸࡺࡲࡰࡰࡤࠤࡁࡂ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ঑"), url=l111l11lll1_fo_ (u"ࠧࠨ঒"), params=l1l1ll1111lll1_fo_[0], mode=l111l11lll1_fo_ (u"ࠨࡲࡲࡰࡸࡧࡴࡴࡲࡲࡶࡹࡥࡰࡢࡩࡨࡣࠬও"), IsPlayable=False)
        for l1111lll1_fo_ in items: l1ll11ll11lll1_fo_(l1111lll1_fo_.get(l111l11lll1_fo_ (u"ࠩࡷ࡭ࡹࡲࡥࠨঔ"),l111l11lll1_fo_ (u"ࠪࠫক")),  l1111lll1_fo_[l111l11lll1_fo_ (u"ࠫࡺࡸ࡬ࠨখ")], mode=l111l11lll1_fo_ (u"ࠬࡶ࡯࡭ࡵࡤࡸࡸࡶ࡯ࡳࡶࡢࡴࡱࡧࡹࡠࠩগ"), IsPlayable=True,infoLabels=l1111lll1_fo_, l11l11111lll1_fo_=l1111lll1_fo_.get(l111l11lll1_fo_ (u"࠭ࡩ࡮ࡩࠪঘ")))
        if l1l1ll1111lll1_fo_[1]: l1ll11ll11lll1_fo_(name=l111l11lll1_fo_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࡄ࠾ࠡࡰࡤࡷࡹटࡰ࡯ࡣࠣࡷࡹࡸ࡯࡯ࡣࠣࡂࡃࡡ࠯ࡄࡑࡏࡓࡗࡣࠧঙ"), url=l111l11lll1_fo_ (u"ࠨࠩচ"), params=l1l1ll1111lll1_fo_[1], mode=l111l11lll1_fo_ (u"ࠩࡳࡳࡱࡹࡡࡵࡵࡳࡳࡷࡺ࡟ࡱࡣࡪࡩࡤ࠭ছ"), IsPlayable=False)
    elif l111l11lll1_fo_ (u"ࠪࡣࡵࡧࡧࡦࡡࠪজ") in mode[0]:
        url = l1ll1ll11lll1_fo_({l111l11lll1_fo_ (u"ࠫࡲࡵࡤࡦࠩঝ"): l111l11lll1_fo_ (u"ࠬࡶ࡯࡭ࡵࡤࡸࡸࡶ࡯ࡳࡶࡢࡧࡴࡴࡴࡦࡰࡷࡣࠬঞ"), l111l11lll1_fo_ (u"࠭ࡦࡰ࡮ࡧࡩࡷࡴࡡ࡮ࡧࠪট"): l111l11lll1_fo_ (u"ࠧࠨঠ"), l111l11lll1_fo_ (u"ࠨࡧࡻࡣࡱ࡯࡮࡬ࠩড") : params,l111l11lll1_fo_ (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩঢ"):l111l11lll1_fo_ (u"ࠪࠫণ"), })
        xbmc.executebuiltin(l111l11lll1_fo_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡆࡳࡳࡺࡡࡪࡰࡨࡶ࠳࡛ࡰࡥࡣࡷࡩ࠭ࠫࡳࠪࠩত")% url)
    else:
        l1lllll111lll1_fo_(l111l11lll1_fo_ (u"ࠬࡓࡡࡨࡣࡽࡽࡳࡿࠧথ"), ex_link=l111l11lll1_fo_ (u"࠭ࠧদ"), params={l111l11lll1_fo_ (u"ࠧࡵࡻࡳࡩࠬধ"):l111l11lll1_fo_ (u"ࠨ࡯ࡤ࡫ࡦࢀࡹ࡯ࡻࠪন")}, mode=l111l11lll1_fo_ (u"ࠩࡳࡳࡱࡹࡡࡵࡵࡳࡳࡷࡺ࡟ࡧࡱ࡯ࡨࡪࡸ࡟ࠨ঩"),iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠪࡴࡴࡲࡳࡢࡶࡶࡴࡴࡸࡴ࠯ࡲࡱ࡫ࠬপ"))
        l1lllll111lll1_fo_(l111l11lll1_fo_ (u"ࠫࡉࡿࡳࡤࡻࡳࡰ࡮ࡴࡹࠨফ"), ex_link=l111l11lll1_fo_ (u"ࠬ࠭ব"), params={l111l11lll1_fo_ (u"࠭ࡴࡺࡲࡨࠫভ"):l111l11lll1_fo_ (u"ࠧࡥࡻࡶࡧࡾࡶ࡬ࡪࡰࡼࠫম")}, mode=l111l11lll1_fo_ (u"ࠨࡲࡲࡰࡸࡧࡴࡴࡲࡲࡶࡹࡥࡦࡰ࡮ࡧࡩࡷࡥࠧয"),iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠩࡳࡳࡱࡹࡡࡵࡵࡳࡳࡷࡺ࠮ࡱࡰࡪࠫর"))
elif mode[0].startswith(l111l11lll1_fo_ (u"ࠪࡰࡪࡩࡨࡵࡸࠪ঱")):
    import resources.lib.l11llll111lll1_fo_ as l11llll111lll1_fo_
    l11llll111lll1_fo_.l1l1l1111lll1_fo_ = int( l1l111l11lll1_fo_.getSetting(l111l11lll1_fo_ (u"ࠫࡱ࡫ࡣࡩࡶࡹ࡭ࡹ࡫ࡰࡱࡲࠪল")) )
    if l111l11lll1_fo_ (u"ࠬࡥࡰ࡭ࡣࡼࡣࠬ঳") in mode[0]:
        l1l1l1l111lll1_fo_ = l11llll111lll1_fo_.l111llll11lll1_fo_(ex_link)
        if isinstance(l1l1l1l111lll1_fo_,list):
            l11ll11l11lll1_fo_ = [x.get(l111l11lll1_fo_ (u"࠭࡭ࡴࡩࠪ঴"),l111l11lll1_fo_ (u"ࠧ࡭࡫ࡱ࡯ࠬ঵")) for x in l1l1l1l111lll1_fo_]
            s=xbmcgui.Dialog().select(l111l11lll1_fo_ (u"ࠨࡎ࡬ࡲࡰ࠭শ"),l11ll11l11lll1_fo_)
            l1l1l1l111lll1_fo_ = l1l1l1l111lll1_fo_[s].get(l111l11lll1_fo_ (u"ࠩࡸࡶࡱ࠭ষ"),False)
        else:
            l1l1l1l111lll1_fo_=l1l1l1l111lll1_fo_.get(l111l11lll1_fo_ (u"ࠪࡹࡷࡲࠧস"),False)
        if l1l1l1l111lll1_fo_:
            xbmcplugin.setResolvedUrl(l1lll111lll1_fo_, True, xbmcgui.ListItem(path=l1l1l1l111lll1_fo_))
        else:
            xbmcplugin.setResolvedUrl(l1lll111lll1_fo_, False, xbmcgui.ListItem(path=l111l11lll1_fo_ (u"ࠫࠬহ")))
    elif l111l11lll1_fo_ (u"ࠬࡥࡴࡢࡤࡨࡰࡦࡥࠧ঺") in mode[0]:
        items = l11llll111lll1_fo_.l11l1l1111lll1_fo_()
        for l1111lll1_fo_ in items: l1ll11ll11lll1_fo_(l1111lll1_fo_.get(l111l11lll1_fo_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ঻"),l111l11lll1_fo_ (u"ࠧࠨ়")),  l111l11lll1_fo_ (u"ࠨࠩঽ"), mode=l111l11lll1_fo_ (u"ࠩࠪা"), infoLabels=l1111lll1_fo_,IsPlayable=False,l11l11111lll1_fo_=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠪࡩࡰࡹࡴࡳࡣ࡮ࡰࡦࡹࡡ࠯ࡲࡱ࡫ࠬি"),fanart=l11ll11111lll1_fo_)
    elif l111l11lll1_fo_ (u"ࠫࡤࡶࡡࡨࡧࡢࠫী") in mode[0]:
        url = l1ll1ll11lll1_fo_({l111l11lll1_fo_ (u"ࠬࡳ࡯ࡥࡧࠪু"): l111l11lll1_fo_ (u"࠭࡬ࡦࡥ࡫ࡸࡻࡥࡣࡰࡰࡷࡩࡳࡺ࡟ࠨূ"), l111l11lll1_fo_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ࡮ࡢ࡯ࡨࠫৃ"): l111l11lll1_fo_ (u"ࠨࠩৄ"), l111l11lll1_fo_ (u"ࠩࡨࡼࡤࡲࡩ࡯࡭ࠪ৅") : l111l11lll1_fo_ (u"ࠪࠫ৆"),l111l11lll1_fo_ (u"ࠫࡵࡧࡲࡢ࡯ࡶࠫে"):params, })
        xbmc.executebuiltin(l111l11lll1_fo_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠨࠦࡵࠬࠫৈ")% url)
    elif l111l11lll1_fo_ (u"࠭࡟ࡤࡱࡱࡸࡪࡴࡴࡠࠩ৉") in mode[0]:
        params = eval(params)
        items,l1l1ll1111lll1_fo_ = l11llll111lll1_fo_.l1l11ll111lll1_fo_(ex_link,**params)
        if l1l1ll1111lll1_fo_[0]:
            l1ll11ll11lll1_fo_(name=l111l11lll1_fo_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡣ࡮ࡸࡩࡢࡂ࠼ࠡࡲࡲࡴࡷࢀࡥࡥࡰ࡬ࡥࠥࡹࡴࡳࡱࡱࡥࠥࡂ࠼࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ৊"), url=l111l11lll1_fo_ (u"ࠨࠩো"), params=l1l1ll1111lll1_fo_[0], mode=l111l11lll1_fo_ (u"ࠩ࡯ࡩࡨ࡮ࡴࡷࡡࡳࡥ࡬࡫࡟ࠨৌ"), IsPlayable=False)
        for l1111lll1_fo_ in items:
            l1ll11ll11lll1_fo_(l1111lll1_fo_.get(l111l11lll1_fo_ (u"ࠪࡸ࡮ࡺ࡬ࡦ্ࠩ"),l111l11lll1_fo_ (u"ࠫࠬৎ")),  l1111lll1_fo_[l111l11lll1_fo_ (u"ࠬࡻࡲ࡭ࠩ৏")], mode=l111l11lll1_fo_ (u"࠭࡬ࡦࡥ࡫ࡸࡻࡥࡰ࡭ࡣࡼࡣࠬ৐"), IsPlayable=True,infoLabels=l1111lll1_fo_, l11l11111lll1_fo_=l1111lll1_fo_.get(l111l11lll1_fo_ (u"ࠧࡪ࡯ࡪࠫ৑")))
        if l1l1ll1111lll1_fo_[1]:
            l1ll11ll11lll1_fo_(name=l111l11lll1_fo_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡤ࡯ࡹࡪࡣ࠾࠿ࠢࡱࡥࡸࡺङࡱࡰࡤࠤࡸࡺࡲࡰࡰࡤࠤࡃࡄ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ৒"), url=l111l11lll1_fo_ (u"ࠩࠪ৓"), params=l1l1ll1111lll1_fo_[1], mode=l111l11lll1_fo_ (u"ࠪࡰࡪࡩࡨࡵࡸࡢࡴࡦ࡭ࡥࡠࠩ৔"), IsPlayable=False)
    else:
        l1lllll111lll1_fo_(l111l11lll1_fo_ (u"ࠫࡓࡵࡷࡦࠩ৕"), ex_link=l111l11lll1_fo_ (u"ࠬ࠭৖"), params={l111l11lll1_fo_ (u"࠭ࡴࡺࡲࡨࠫৗ"):l111l11lll1_fo_ (u"ࠧ࡯ࡧࡺࡩࡸࡺࠧ৘"),l111l11lll1_fo_ (u"ࠨࡲࡤ࡫ࡪ࠭৙"):0}, mode=l111l11lll1_fo_ (u"ࠩ࡯ࡩࡨ࡮ࡴࡷࡡࡦࡳࡳࡺࡥ࡯ࡶࡢࠫ৚"),iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠪࡰࡪࡩࡨࡵࡸ࠱ࡴࡳ࡭ࠧ৛"))
        l1lllll111lll1_fo_(l111l11lll1_fo_ (u"ࠫࡕࡵࡰࡶ࡮ࡤࡶࡳ࡫ࠧড়"), ex_link=l111l11lll1_fo_ (u"ࠬ࠭ঢ়"), params={l111l11lll1_fo_ (u"࠭ࡴࡺࡲࡨࠫ৞"):l111l11lll1_fo_ (u"ࠧࡱࡱࡳࡹࡱࡧࡲࠨয়"),l111l11lll1_fo_ (u"ࠨࡲࡤ࡫ࡪ࠭ৠ"):0}, mode=l111l11lll1_fo_ (u"ࠩ࡯ࡩࡨ࡮ࡴࡷࡡࡦࡳࡳࡺࡥ࡯ࡶࡢࠫৡ"),iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠪࡰࡪࡩࡨࡵࡸ࠱ࡴࡳ࡭ࠧৢ"))
        l1lllll111lll1_fo_(l111l11lll1_fo_ (u"ࠫࡕ࡯ࡥࡳࡹࡶࡾࡦࠦࡄࡳࡷॿࡽࡳࡧࠧৣ"), ex_link=l111l11lll1_fo_ (u"ࠬ࠭৤"), params={l111l11lll1_fo_ (u"࠭ࡴࡺࡲࡨࠫ৥"):l111l11lll1_fo_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ০"),l111l11lll1_fo_ (u"ࠨࡲࡤ࡫ࡪ࠭১"):l111l11lll1_fo_ (u"ࠩ࠳ࠫ২"),l111l11lll1_fo_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ৩"):l111l11lll1_fo_ (u"ࠫ࠸࠭৪")}, mode=l111l11lll1_fo_ (u"ࠬࡲࡥࡤࡪࡷࡺࡤࡩ࡯࡯ࡶࡨࡲࡹࡥࠧ৫"), iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"࠭࡬ࡦࡥ࡫ࡸࡻ࠴ࡰ࡯ࡩࠪ৬"))
        l1lllll111lll1_fo_(l111l11lll1_fo_ (u"ࠧࡔ࡭ࡵࣷࡹࡿࠠࡎࡧࡦࡾࣸࡽࠧ৭"), ex_link=l111l11lll1_fo_ (u"ࠨࠩ৮"), params={l111l11lll1_fo_ (u"ࠩࡷࡽࡵ࡫ࠧ৯"):l111l11lll1_fo_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬৰ"),l111l11lll1_fo_ (u"ࠫࡵࡧࡧࡦࠩৱ"):l111l11lll1_fo_ (u"ࠬ࠶ࠧ৲"),l111l11lll1_fo_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ৳"):l111l11lll1_fo_ (u"ࠧ࠸ࠩ৴")}, mode=l111l11lll1_fo_ (u"ࠨ࡮ࡨࡧ࡭ࡺࡶࡠࡥࡲࡲࡹ࡫࡮ࡵࡡࠪ৵"), iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠩ࡯ࡩࡨ࡮ࡴࡷ࠰ࡳࡲ࡬࠭৶"))
        l1lllll111lll1_fo_(l111l11lll1_fo_ (u"࡛ࠪࡾࡽࡩࡢࡦࡼࠫ৷"), ex_link=l111l11lll1_fo_ (u"ࠫࠬ৸"), params={l111l11lll1_fo_ (u"ࠬࡺࡹࡱࡧࠪ৹"):l111l11lll1_fo_ (u"࠭ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨ৺"),l111l11lll1_fo_ (u"ࠧࡱࡣࡪࡩࠬ৻"):l111l11lll1_fo_ (u"ࠨ࠲ࠪৼ"),l111l11lll1_fo_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ৽"):l111l11lll1_fo_ (u"ࠪ࠵ࠬ৾")}, mode=l111l11lll1_fo_ (u"ࠫࡱ࡫ࡣࡩࡶࡹࡣࡨࡵ࡮ࡵࡧࡱࡸࡤ࠭৿"), iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠬࡲࡥࡤࡪࡷࡺ࠳ࡶ࡮ࡨࠩ਀"))
        l1lllll111lll1_fo_(l111l11lll1_fo_ (u"࠭ࡋࡰࡰࡩࡩࡷ࡫࡮ࡤ࡬ࡨࠤࡕࡸࡡࡴࡱࡺࡩࠬਁ"), ex_link=l111l11lll1_fo_ (u"ࠧࠨਂ"), params={l111l11lll1_fo_ (u"ࠨࡶࡼࡴࡪ࠭ਃ"):l111l11lll1_fo_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ਄"),l111l11lll1_fo_ (u"ࠪࡴࡦ࡭ࡥࠨਅ"):l111l11lll1_fo_ (u"ࠫ࠵࠭ਆ"),l111l11lll1_fo_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧਇ"):l111l11lll1_fo_ (u"࠭࠲ࠨਈ")}, mode=l111l11lll1_fo_ (u"ࠧ࡭ࡧࡦ࡬ࡹࡼ࡟ࡤࡱࡱࡸࡪࡴࡴࡠࠩਉ"), iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠨ࡮ࡨࡧ࡭ࡺࡶ࠯ࡲࡱ࡫ࠬਊ"))
        l1lllll111lll1_fo_(l111l11lll1_fo_ (u"ࠩࡕࡩࡿ࡫ࡲࡸࡻࠪ਋"), ex_link=l111l11lll1_fo_ (u"ࠪࠫ਌"), params={l111l11lll1_fo_ (u"ࠫࡹࡿࡰࡦࠩ਍"):l111l11lll1_fo_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧ਎"),l111l11lll1_fo_ (u"࠭ࡰࡢࡩࡨࠫਏ"):l111l11lll1_fo_ (u"ࠧ࠱ࠩਐ"),l111l11lll1_fo_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ਑"):l111l11lll1_fo_ (u"ࠩ࠷ࠫ਒")}, mode=l111l11lll1_fo_ (u"ࠪࡰࡪࡩࡨࡵࡸࡢࡧࡴࡴࡴࡦࡰࡷࡣࠬਓ"), iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠫࡱ࡫ࡣࡩࡶࡹ࠲ࡵࡴࡧࠨਔ"))
        l1lllll111lll1_fo_(l111l11lll1_fo_ (u"ࠬࡇ࡫ࡢࡦࡨࡱ࡮ࡧࠧਕ"), ex_link=l111l11lll1_fo_ (u"࠭ࠧਖ"), params={l111l11lll1_fo_ (u"ࠧࡵࡻࡳࡩࠬਗ"):l111l11lll1_fo_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪਘ"),l111l11lll1_fo_ (u"ࠩࡳࡥ࡬࡫ࠧਙ"):l111l11lll1_fo_ (u"ࠪ࠴ࠬਚ"),l111l11lll1_fo_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ਛ"):l111l11lll1_fo_ (u"ࠬ࠻ࠧਜ")}, mode=l111l11lll1_fo_ (u"࠭࡬ࡦࡥ࡫ࡸࡻࡥࡣࡰࡰࡷࡩࡳࡺ࡟ࠨਝ"), iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠧ࡭ࡧࡦ࡬ࡹࡼ࠮ࡱࡰࡪࠫਞ"))
        l1lllll111lll1_fo_(l111l11lll1_fo_ (u"ࠨࡑ࡯ࡨࡧࡵࡪࡦࠩਟ"), ex_link=l111l11lll1_fo_ (u"ࠩࠪਠ"), params={l111l11lll1_fo_ (u"ࠪࡸࡾࡶࡥࠨਡ"):l111l11lll1_fo_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾ࠭ਢ"),l111l11lll1_fo_ (u"ࠬࡶࡡࡨࡧࠪਣ"):l111l11lll1_fo_ (u"࠭࠰ࠨਤ"),l111l11lll1_fo_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩਥ"):l111l11lll1_fo_ (u"ࠨ࠸ࠪਦ")}, mode=l111l11lll1_fo_ (u"ࠩ࡯ࡩࡨ࡮ࡴࡷࡡࡦࡳࡳࡺࡥ࡯ࡶࡢࠫਧ"), iconImage=l1llll1111lll1_fo_+l111l11lll1_fo_ (u"ࠪࡰࡪࡩࡨࡵࡸ࠱ࡴࡳ࡭ࠧਨ"))
elif mode[0] ==l111l11lll1_fo_ (u"ࠫࡊࡹࡴࡢࡦ࡬ࡳࡸࡥࡳ࡬ࡴࡲࡸࡾ࠭਩"):
    out=l1l1lll111lll1_fo_.l1l1l1ll11lll1_fo_(ex_link)
    for f in out:
        l1ll11ll11lll1_fo_(name=f.get(l111l11lll1_fo_ (u"ࠬࡺࡩࡵ࡮ࡨࠫਪ")), url=f.get(l111l11lll1_fo_ (u"࠭ࡵࡳ࡮ࠪਫ")), mode=l111l11lll1_fo_ (u"ࠧࡆࡵࡷࡥࡩ࡯࡯ࡴࡡࡳࡰࡦࡿࠧਬ"), l11l11111lll1_fo_=f.get(l111l11lll1_fo_ (u"ࠨ࡫ࡰ࡫ࠬਭ")), infoLabels=f, IsPlayable=True,fanart=f.get(l111l11lll1_fo_ (u"ࠩ࡬ࡱ࡬࠭ਮ")))
elif mode[0] ==l111l11lll1_fo_ (u"ࠪࡉࡸࡺࡡࡥ࡫ࡲࡷࡤࡹ࡫ࡳࡱࡷࡽࡤࡒࡩࡨࡣࠪਯ"):
    data = l1l1lll111lll1_fo_.l1ll1lll11lll1_fo_()
    if data:
        label = [l1l1lll111lll1_fo_.l11l1l111lll1_fo_(x[1].strip()) for x in data]
        value = [x[0].strip() for x in data]
        for t,v in zip(label,value):
            l1lllll111lll1_fo_(t,ex_link=v,params={}, mode=l111l11lll1_fo_ (u"ࠫࡊࡹࡴࡢࡦ࡬ࡳࡸࡥࡳ࡬ࡴࡲࡸࡾ࠭ਰ"),iconImage=l111l11lll1_fo_ (u"ࠬࡊࡥࡧࡣࡸࡰࡹࡌ࡯࡭ࡦࡨࡶ࠳ࡶ࡮ࡨࠩ਱"))
elif mode[0] ==l111l11lll1_fo_ (u"࠭ࡅࡴࡶࡤࡨ࡮ࡵࡳࡠࡲ࡯ࡥࡾ࠭ਲ"):
    l11ll1l11lll1_fo_(ex_link)
elif mode[0] == l111l11lll1_fo_ (u"ࠧࡐࡲࡦ࡮ࡪ࠭ਲ਼"):
    l1l111l11lll1_fo_.openSettings()
elif mode[0] ==l111l11lll1_fo_ (u"ࠨࡩࡨࡸࡑ࡯࡮࡬ࡵࠪ਴"):
    l1ll111111lll1_fo_(ex_link)
elif mode[0] ==l111l11lll1_fo_ (u"ࠩࡪࡩࡹ࡜ࡩࡥࡧࡲࡷࠬਵ"):
    params = eval(params)
    l11l11l111lll1_fo_,l1l1ll1111lll1_fo_ = l1l1ll1l11lll1_fo_.l111llll11lll1_fo_(**params)
    if l1l1ll1111lll1_fo_[0]:
        l1ll11ll11lll1_fo_(name=l111l11lll1_fo_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞࠾࠿ࠤࡵࡵࡰࡳࡼࡨࡨࡳ࡯ࡡࠡࡵࡷࡶࡴࡴࡡࠡ࠾࠿࡟࠴ࡉࡏࡍࡑࡕࡡࠬਸ਼"), url=ex_link, mode=l111l11lll1_fo_ (u"ࠫࡤࡥࡰࡢࡩࡨࡣࡤ࠭਷"), params=l1l1ll1111lll1_fo_[0], IsPlayable=False)
    items=len(l11l11l111lll1_fo_)
    for f in l11l11l111lll1_fo_:
        f[l111l11lll1_fo_ (u"ࠬࡩ࡯ࡥࡧࠪਸ")]= f.get(l111l11lll1_fo_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࡠࡨࡲࡶࡲࡧࡴࡵࡧࡧࠫਹ"),l111l11lll1_fo_ (u"ࠧࠨ਺"))
        f[l111l11lll1_fo_ (u"ࠨࡥࡲࡨࡪ࠭਻")]=l111l11lll1_fo_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢ࡯࡭࡬࡮ࡴࡨࡴࡨࡩࡳࡣ࡯࡯ࡃ࡬ࡶࡠ࠵ࡃࡐࡎࡒࡖࡢ਼࠭") if f.get(l111l11lll1_fo_ (u"ࠪࡳࡳࡧࡩࡳࠩ਽"),False) else f[l111l11lll1_fo_ (u"ࠫࡨࡵࡤࡦࠩਾ")]
        l1ll11ll11lll1_fo_(name=f.get(l111l11lll1_fo_ (u"ࠬࡺࡩࡵ࡮ࡨࠫਿ")), url=f.get(l111l11lll1_fo_ (u"࠭ࡩࡥࠩੀ")), mode=l111l11lll1_fo_ (u"ࠧࡨࡧࡷࡐ࡮ࡴ࡫ࡴࠩੁ"), l11l11111lll1_fo_=f.get(l111l11lll1_fo_ (u"ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡣ࠷࠺࠰ࡠࡷࡵࡰࠬੂ")), infoLabels=f, IsPlayable=True,l1lll11111lll1_fo_=items,fanart=f.get(l111l11lll1_fo_ (u"ࠩ࡬ࡱ࡬࠭੃")))
    if l1l1ll1111lll1_fo_[1]:
        l1ll11ll11lll1_fo_(name=l111l11lll1_fo_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡦࡱࡻࡥ࡞ࡀࡁࠤࡳࡧࡳࡵछࡳࡲࡦࠦࡳࡵࡴࡲࡲࡦࠦ࠾࠿࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ੄"), url=ex_link, mode=l111l11lll1_fo_ (u"ࠫࡤࡥࡰࡢࡩࡨࡣࡤ࠭੅"), params=l1l1ll1111lll1_fo_[1], IsPlayable=False)
elif mode[0] == l111l11lll1_fo_ (u"ࠬࡥ࡟ࡱࡣࡪࡩࡤࡥࠧ੆"):
    url = l1ll1ll11lll1_fo_({l111l11lll1_fo_ (u"࠭࡭ࡰࡦࡨࠫੇ"): l111l11lll1_fo_ (u"ࠧࡨࡧࡷ࡚࡮ࡪࡥࡰࡵࠪੈ"), l111l11lll1_fo_ (u"ࠨࡨࡲࡰࡩ࡫ࡲ࡯ࡣࡰࡩࠬ੉"): l111l11lll1_fo_ (u"ࠩࠪ੊"), l111l11lll1_fo_ (u"ࠪࡩࡽࡥ࡬ࡪࡰ࡮ࠫੋ") : ex_link, l111l11lll1_fo_ (u"ࠫࡵࡧࡲࡢ࡯ࡶࠫੌ"): params})
    xbmc.executebuiltin(l111l11lll1_fo_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠨࠦࡵ੍ࠬࠫ")% url)
elif mode[0] == l111l11lll1_fo_ (u"࠭ࡏࡱࡥ࡭ࡩࠬ੎"):
    l1l111l11lll1_fo_.openSettings()
elif mode[0] == l111l11lll1_fo_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ੏"):
    pass
else:
    xbmcplugin.setResolvedUrl(l1lll111lll1_fo_, False, xbmcgui.ListItem(path=l111l11lll1_fo_ (u"ࠨࠩ੐")))
xbmcplugin.endOfDirectory(l1lll111lll1_fo_)
