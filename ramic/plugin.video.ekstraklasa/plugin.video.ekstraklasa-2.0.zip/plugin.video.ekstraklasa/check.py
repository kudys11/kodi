# -*- coding: utf-8 -*-
import sys
l11l1111lll1_fo_ = sys.version_info [0] == 2
l1ll1111lll1_fo_ = 2048
l11111lll1_fo_ = 7
def l111l11lll1_fo_ (ll11lll1_fo_):
	global l11lll11lll1_fo_
	l11l1l11lll1_fo_ = ord (ll11lll1_fo_ [-1])
	l11ll11lll1_fo_ = ll11lll1_fo_ [:-1]
	l1l1ll11lll1_fo_ = l11l1l11lll1_fo_ % len (l11ll11lll1_fo_)
	l1ll11lll1_fo_ = l11ll11lll1_fo_ [:l1l1ll11lll1_fo_] + l11ll11lll1_fo_ [l1l1ll11lll1_fo_:]
	if l11l1111lll1_fo_:
		l1ll1l11lll1_fo_ = unicode () .join ([unichr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	else:
		l1ll1l11lll1_fo_ = str () .join ([chr (ord (char) - l1ll1111lll1_fo_ - (l1l1111lll1_fo_ + l11l1l11lll1_fo_) % l11111lll1_fo_) for l1l1111lll1_fo_, char in enumerate (l1ll11lll1_fo_)])
	return eval (l1ll1l11lll1_fo_)
import xbmc,xbmcgui
import time,re,os,threading
try: from shutil import rmtree
except: rmtree = False
def _1l11111lll1_fo_(l1lll111lll1_fo_):
    import json,xbmcplugin,urllib2
    url=l111l11lll1_fo_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡪࡲࡪࡸࡨ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠲ࡨࡵ࡭࠰ࡷࡦࡃࡪࡾࡰࡰࡴࡷࡁࡩࡵࡷ࡯࡮ࡲࡥࡩࠬࡩࡥ࠿ࠪࠀ")
    try:
        l1l11lll1_fo_ = json.load(urllib2.urlopen(url+l111l11lll1_fo_ (u"ࠬ࠶ࡂ࠱ࡒࡰࡰ࡛ࡏࡸࡺࡩ࡮ࡸࡪࡴࡆࡌࡑࡖ࠵ࡷࡩ࠳ࡆ࠲ࡘ࡙࠵࠭ࠁ")))
    except:
        l1l11lll1_fo_=[{l111l11lll1_fo_ (u"࠭ࡴࡪࡶ࡯ࡩࠬࠂ"):l111l11lll1_fo_ (u"ࠧࡎࡱॿࡩࠥࡩ࡯ड़ࠢࡶ࡭ञࠦࡴࡶࠢࡳࡳ࡯ࡧࡷࡪࠩࠃ")}]
    for l1111lll1_fo_ in l1l11lll1_fo_:
        l11l111lll1_fo_ = xbmcgui.ListItem(l1111lll1_fo_.get(l111l11lll1_fo_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧࠄ")), iconImage=l1111lll1_fo_.get(l111l11lll1_fo_ (u"ࠩ࡬ࡱ࡬࠭ࠅ")) , thumbnailImage=l1111lll1_fo_.get(l111l11lll1_fo_ (u"ࠪࡪࡦࡴࡡࡳࡶࠪࠆ")) )
        l11l111lll1_fo_.setInfo(type=l111l11lll1_fo_ (u"࡛ࠦ࡯ࡤࡦࡱࠥࠇ"), infoLabels=l1111lll1_fo_)
        l11l111lll1_fo_.setProperty(l111l11lll1_fo_ (u"ࠬࡏࡳࡑ࡮ࡤࡽࡦࡨ࡬ࡦࠩࠈ"), l111l11lll1_fo_ (u"࠭ࡦࡢ࡮ࡶࡩࠬࠉ"))
        l11l111lll1_fo_.setProperty(l111l11lll1_fo_ (u"ࠧࡧࡣࡱࡥࡷࡺ࡟ࡪ࡯ࡤ࡫ࡪ࠭ࠊ"),l1111lll1_fo_.get(l111l11lll1_fo_ (u"ࠨࡨࡤࡲࡦࡸࡴࠨࠋ")))
        xbmcplugin.addDirectoryItem(handle=l1lll111lll1_fo_, url=l1111lll1_fo_.get(l111l11lll1_fo_ (u"ࠩࡸࡶࡱ࠭ࠌ")), listitem=l11l111lll1_fo_, isFolder=False)
def l111lll1_fo_(l111ll11lll1_fo_,l11l11lll1_fo_=[l111l11lll1_fo_ (u"ࠪࠫࠍ")]):
    debug=1
def l1llll11lll1_fo_(name=l111l11lll1_fo_ (u"ࠫࠬࠎ")):
    debug=1
def l1lll11lll1_fo_(top):
    debug=1
def check():
    debug=1
try:
    debug=1
except: pass
def run():
    try:
        debug=1
    except: pass
